%% chapter_AI_CV_template_matching_01.m
% Comprehensive Template Matching Implementation
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_template_matching_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Load test image and define template
test_image = imread('coins.png');
if size(test_image, 3) == 3
    test_image = rgb2gray(test_image);
end
test_image = im2double(test_image);

% Extract template from a region of interest
template_region = test_image(85:130, 130:175);  % Extract one coin as template

% Basic normalised cross-correlation
correlation_map = normxcorr2(template_region, test_image);

% Find correlation peaks
correlation_threshold = 0.7;
[peak_y, peak_x] = find(correlation_map >= correlation_threshold);

% Convert correlation coordinates to image coordinates
template_height = size(template_region, 1);
template_width = size(template_region, 2);
match_x = peak_x - template_width + 1;
match_y = peak_y - template_height + 1;

% Manual implementation of normalised cross-correlation for educational purposes

% Apply manual implementation for comparison
manual_correlation = manualNormXCorr2(template_region, test_image);

% Multi-scale template matching

% Apply multi-scale matching
scale_range = 0.5:0.1:1.5;
[multiscale_matches, match_scales] = multiScaleTemplateMatch(...
    template_region, test_image, scale_range, 0.6);

% Rotation-invariant template matching

% Apply rotation-invariant matching
angle_range = -30:10:30;
rotation_matches = rotationInvariantMatch(template_region, test_image, angle_range, 0.65);

% Non-maximum suppression for overlapping detections

% Apply non-maximum suppression
if ~isempty(multiscale_matches)
    filtered_multiscale = nonMaxSuppressionTemplates(multiscale_matches, 30);
else
    filtered_multiscale = [];
end

% Template matching quality assessment

% Assess matching quality
basic_quality = assessTemplateMatchQuality(template_region, test_image, ...
    [match_x, match_y, repmat([template_width, template_height], length(match_x), 1)]);

% Display comprehensive results
figure;

% Original image with template region highlighted
subplot(2,4,1);
imshow(test_image); hold on;
rectangle('Position', [130, 85, size(template_region, 2), size(template_region, 1)], ...
    'EdgeColor', 'r', 'LineWidth', 2);
title('Original Image with Template');

% Template
subplot(2,4,2);
imshow(template_region);
title('Template Region');

% Correlation map
subplot(2,4,3);
imshow(correlation_map, []);
title('Correlation Map');
colorbar;

% Basic matches
subplot(2,4,4);
imshow(test_image); hold on;
for i = 1:length(match_x)
    rectangle('Position', [match_x(i), match_y(i), template_width, template_height], ...
        'EdgeColor', 'g', 'LineWidth', 2);
end
title(sprintf('Basic Matches (%d)', length(match_x)));

% Multi-scale matches
subplot(2,4,5);
imshow(test_image); hold on;
if ~isempty(filtered_multiscale)
    for i = 1:size(filtered_multiscale, 1)
        rectangle('Position', [filtered_multiscale(i,1), filtered_multiscale(i,2), ...
            filtered_multiscale(i,3), filtered_multiscale(i,4)], ...
            'EdgeColor', 'b', 'LineWidth', 2);
    end
end
title(sprintf('Multi-scale Matches (%d)', size(filtered_multiscale, 1)));

% Rotation-invariant matches
subplot(2,4,6);
imshow(test_image); hold on;
if ~isempty(rotation_matches)
    for i = 1:size(rotation_matches, 1)
        rectangle('Position', [rotation_matches(i,1), rotation_matches(i,2), ...
            rotation_matches(i,3), rotation_matches(i,4)], ...
            'EdgeColor', 'm', 'LineWidth', 2);
    end
end
title(sprintf('Rotation-invariant (%d)', size(rotation_matches, 1)));

% Correlation statistics
subplot(2,4,7);
histogram(correlation_map(:), 50);
title('Correlation Distribution');
xlabel('Correlation Value');
ylabel('Frequency');

% Performance comparison
subplot(2,4,8);
methods = {'Basic', 'Multi-scale', 'Rotation'};
detection_counts = [length(match_x), size(filtered_multiscale, 1), size(rotation_matches, 1)];
bar(detection_counts);
set(gca, 'XTickLabel', methods);
title('Detection Performance');
ylabel('Number of Detections');

% Print quantitative analysis
fprintf('Template Matching Performance Analysis:\n');
fprintf('Template size: %dx%d pixels\n', size(template_region, 2), size(template_region, 1));
fprintf('Basic matching: %d detections (threshold: %.2f)\n', length(match_x), correlation_threshold);
fprintf('Multi-scale matching: %d detections\n', size(filtered_multiscale, 1));
fprintf('Rotation-invariant: %d detections\n', size(rotation_matches, 1));
fprintf('Average correlation: %.3f ㊣ %.3f\n', basic_quality.mean_correlation, basic_quality.std_correlation);
fprintf('Correlation map range: [%.3f, %.3f]\n', min(correlation_map(:)), max(correlation_map(:)));

% Local functions (moved to end so this listing is a valid MATLAB script)
function correlation_result = manualNormXCorr2(template, image)
    [t_rows, t_cols] = size(template);
    [i_rows, i_cols] = size(image);
    
    % Pad image for full correlation
    padded_image = padarray(image, [t_rows-1, t_cols-1], 'symmetric');
    
    % Result size
    result_rows = i_rows + t_rows - 1;
    result_cols = i_cols + t_cols - 1;
    correlation_result = zeros(result_rows, result_cols);
    
    % Normalise template
    template_mean = mean(template(:));
    template_centered = template - template_mean;
    template_norm = sqrt(sum(template_centered(:).^2));
    
    % Compute correlation at each position
    for i = 1:result_rows
        for j = 1:result_cols
            % Extract image patch
            patch = padded_image(i:i+t_rows-1, j:j+t_cols-1);
            
            % Normalise patch
            patch_mean = mean(patch(:));
            patch_centered = patch - patch_mean;
            patch_norm = sqrt(sum(patch_centered(:).^2));
            
            % Compute normalised correlation
            if patch_norm > 0 && template_norm > 0
                correlation_result(i, j) = sum(template_centered(:) .* patch_centered(:)) / ...
                                         (template_norm * patch_norm);
            end
        end
    end
end

function [matches, scales] = multiScaleTemplateMatch(template, image, scale_range, threshold)
    matches = [];
    scales = [];
    
    num_scales = length(scale_range);
    for i = 1:num_scales
        scale = scale_range(i);
        
        % Resize template
        scaled_template = imresize(template, scale);
        
        % Skip if template becomes too small
        if min(size(scaled_template)) < 5
            continue;
        end
        
        % Perform correlation
        correlation_map = normxcorr2(scaled_template, image);
        
        % Find peaks
        [peak_y, peak_x] = find(correlation_map >= threshold);
        
        if ~isempty(peak_y)
            % Convert to image coordinates
            template_height = size(scaled_template, 1);
            template_width = size(scaled_template, 2);
            
            match_x = peak_x - template_width + 1;
            match_y = peak_y - template_height + 1;
            
            % Store matches with scale information
            for j = 1:length(match_x)
                matches = [matches; match_x(j), match_y(j), template_width, template_height];
                scales = [scales; scale];
            end
        end
    end
end

function rotation_matches = rotationInvariantMatch(template, image, angle_range, threshold)
    rotation_matches = [];
    
    for angle = angle_range
        % Rotate template
        rotated_template = imrotate(template, angle, 'bicubic', 'crop');
        
        % Remove zero padding effects
        mask = rotated_template > 0;
        if sum(mask(:)) < 0.5 * numel(mask)
            continue;  % Skip if too much information lost
        end
        
        % Perform correlation
        correlation_map = normxcorr2(rotated_template, image);
        
        % Find peaks
        [peak_y, peak_x] = find(correlation_map >= threshold);
        
        if ~isempty(peak_y)
            template_height = size(rotated_template, 1);
            template_width = size(rotated_template, 2);
            
            match_x = peak_x - template_width + 1;
            match_y = peak_y - template_height + 1;
            
            % Store matches with rotation information
            for j = 1:length(match_x)
                rotation_matches = [rotation_matches; ...
                    match_x(j), match_y(j), template_width, template_height, angle];
            end
        end
    end
end

function filtered_matches = nonMaxSuppressionTemplates(matches, overlap_threshold)
    if isempty(matches)
        filtered_matches = [];
        return;
    end
    
    % Calculate match scores (assuming correlation values are available)
    % For this example, we'll use a simple distance-based approach
    
    filtered_matches = [];
    remaining_indices = 1:size(matches, 1);
    
    while ~isempty(remaining_indices)
        % Take the first remaining match
        current_idx = remaining_indices(1);
        current_match = matches(current_idx, :);
        filtered_matches = [filtered_matches; current_match];
        
        % Remove current match from remaining
        remaining_indices(1) = [];
        
        % Remove overlapping matches
        if ~isempty(remaining_indices)
            remaining_matches = matches(remaining_indices, :);
            
            % Calculate overlaps (simplified rectangular overlap)
            distances = sqrt((remaining_matches(:,1) - current_match(1)).^2 + ...
                           (remaining_matches(:,2) - current_match(2)).^2);
            
            % Remove matches that are too close
            overlap_indices = distances < overlap_threshold;
            remaining_indices(overlap_indices) = [];
        end
    end
end

function quality_metrics = assessTemplateMatchQuality(template, image, matches)
    quality_metrics = struct();
    
    if isempty(matches)
        quality_metrics.mean_correlation = 0;
        quality_metrics.detection_count = 0;
        return;
    end
    
    correlations = zeros(size(matches, 1), 1);
    
    for i = 1:size(matches, 1)
        x = round(matches(i, 1));
        y = round(matches(i, 2));
        width = round(matches(i, 3));
        height = round(matches(i, 4));
        
        % Extract patch and compute correlation
        if x > 0 && y > 0 && x+width-1 <= size(image, 2) && y+height-1 <= size(image, 1)
            patch = image(y:y+height-1, x:x+width-1);
            resized_template = imresize(template, [height, width]);
            
            % Compute normalised correlation
            template_norm = resized_template - mean(resized_template(:));
            patch_norm = patch - mean(patch(:));
            
            if std(template_norm(:)) > 0 && std(patch_norm(:)) > 0
                correlations(i) = corr2(template_norm, patch_norm);
            end
        end
    end
    
    quality_metrics.mean_correlation = mean(correlations);
    quality_metrics.std_correlation = std(correlations);
    quality_metrics.detection_count = size(matches, 1);
    quality_metrics.correlations = correlations;
end
