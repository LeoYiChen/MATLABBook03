%% chapter_AI_CV_lab1_complete.m
% Advanced Performance Evaluation Framework Implementation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_lab1_complete
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% Advanced Performance Evaluation Framework for Computer Vision
% Author: Dr Yi Chen
% Created: January 2025
% MATLAB Version: R2024a or later
% Description: Comprehensive evaluation framework with cross-validation,
%              bootstrap validation, and statistical testing





























% Execute main function
evaluationResults = advancedPerformanceEvaluation();

% Local functions (moved to end so this listing is a valid MATLAB script)
function evaluationResults = advancedPerformanceEvaluation()
    %% Main function for advanced performance evaluation
    % This function demonstrates state-of-the-art evaluation techniques
    % for computer vision algorithms
    
    fprintf('Advanced Performance Evaluation Framework\n');
    fprintf('========================================\n');
    
    % Create synthetic dataset with realistic characteristics
    [features, labels, metadata] = createRealisticDataset();
    
    % Implement comprehensive evaluation framework
    evaluationResults = performComprehensiveEvaluation(features, labels, metadata);
    
    % Generate detailed evaluation report
    generateEvaluationReport(evaluationResults);
    
    % Visualise evaluation results
    visualiseEvaluationResults(evaluationResults);
end

function [features, labels, metadata] = createRealisticDataset()
    %% Create realistic dataset with challenging characteristics
    % Includes class imbalance, group dependencies, and temporal correlation
    
    fprintf('Creating realistic dataset with challenging characteristics...\n');
    
    numSamples = 2000;
    numFeatures = 50;
    numClasses = 4;
    
    % Generate features with realistic correlation structure
    correlationMatrix = generateCorrelationStructure(numFeatures);
    features = mvnrnd(zeros(1, numFeatures), correlationMatrix, numSamples);
    
    % Create imbalanced class distribution
    classProportions = [0.5, 0.3, 0.15, 0.05]; % Realistic imbalance
    labels = generateImbalancedLabels(numSamples, classProportions);
    
    % Add metadata for grouped cross-validation
    metadata = struct();
    metadata.groups = generateGroupStructure(numSamples);
    metadata.timeStamps = generateTemporalStructure(numSamples);
    metadata.demographics = generateDemographicData(numSamples);
    
    fprintf('Dataset created: %d samples, %d features, %d classes\n', ...
        numSamples, numFeatures, numClasses);
end

function corrMatrix = generateCorrelationStructure(numFeatures)
    %% Generate realistic correlation structure for features
    
    % Create block correlation structure
    blockSize = 10;
    numBlocks = ceil(numFeatures / blockSize);
    corrMatrix = eye(numFeatures);
    
    for block = 1:numBlocks
        startIdx = (block - 1) * blockSize + 1;
        endIdx = min(block * blockSize, numFeatures);
        blockIndices = startIdx:endIdx;
        
        % Within-block correlation
        withinBlockCorr = 0.3 + rand() * 0.4; % 0.3 to 0.7 correlation
        for i = blockIndices
            for j = blockIndices
                if i ~= j
                    corrMatrix(i, j) = withinBlockCorr * exp(-abs(i - j) / 3);
                end
            end
        end
    end
    
    % Ensure positive definite
    corrMatrix = corrMatrix + 0.1 * eye(numFeatures);
end

function labels = generateImbalancedLabels(numSamples, proportions)
    %% Generate class labels with specified proportions
    
    labels = zeros(numSamples, 1);
    currentIdx = 1;
    
    for class = 1:length(proportions)
        numClassSamples = round(proportions(class) * numSamples);
        if class == length(proportions)
            numClassSamples = numSamples - currentIdx + 1; % Ensure exact total
        end
        
        endIdx = currentIdx + numClassSamples - 1;
        labels(currentIdx:endIdx) = class;
        currentIdx = endIdx + 1;
    end
    
    % Shuffle to randomise order
    labels = labels(randperm(numSamples));
end

function groups = generateGroupStructure(numSamples)
    %% Generate group structure for grouped cross-validation
    
    numGroups = round(numSamples / 25); % Average 25 samples per group
    groups = zeros(numSamples, 1);
    
    currentIdx = 1;
    for group = 1:numGroups
        groupSize = randi([15, 35]); % Variable group sizes
        if group == numGroups
            groupSize = numSamples - currentIdx + 1;
        end
        
        endIdx = min(currentIdx + groupSize - 1, numSamples);
        groups(currentIdx:endIdx) = group;
        currentIdx = endIdx + 1;
    end
end

function timeStamps = generateTemporalStructure(numSamples)
    %% Generate temporal structure with realistic dependencies
    
    baseTime = datetime('2023-01-01');
    timeIntervals = exprnd(24, numSamples, 1); % Exponential intervals in hours
    timeStamps = baseTime + hours(cumsum(timeIntervals));
end

function demographics = generateDemographicData(numSamples)
    %% Generate demographic data for fairness assessment
    
    demographics = struct();
    
    % Age groups
    demographics.ageGroup = randi([1, 5], numSamples, 1); % 5 age groups
    
    % Gender (binary for simplicity)
    demographics.gender = randi([1, 2], numSamples, 1);
    
    % Geographic region
    demographics.region = randi([1, 4], numSamples, 1); % 4 regions
    
    % Socioeconomic status
    demographics.socioeconomic = randi([1, 3], numSamples, 1); % 3 levels
end

function results = performComprehensiveEvaluation(features, labels, metadata)
    %% Perform comprehensive evaluation using multiple methodologies
    
    fprintf('Performing comprehensive evaluation...\n');
    
    results = struct();
    
    % 1. Stratified K-Fold Cross-Validation
    results.stratifiedCV = performStratifiedCrossValidation(features, labels, 5);
    
    % 2. Grouped Cross-Validation
    results.groupedCV = performGroupedCrossValidation(features, labels, metadata.groups);
    
    % 3. Bootstrap Validation
    results.bootstrap = performBootstrapValidation(features, labels, 1000);
    
    % 4. Temporal Cross-Validation
    results.temporalCV = performTemporalCrossValidation(features, labels, metadata.timeStamps);
    
    % 5. Fairness Assessment
    results.fairness = performFairnessAssessment(features, labels, metadata.demographics);
    
    % 6. Statistical Significance Testing
    results.significance = performSignificanceTestingFramework(results);
    
    fprintf('Comprehensive evaluation completed\n');
end

function cvResults = performStratifiedCrossValidation(features, labels, numFolds)
    %% Implement stratified k-fold cross-validation
    
    fprintf('Performing stratified %d-fold cross-validation...\n', numFolds);
    
    cv = cvpartition(labels, 'KFold', numFolds, 'Stratify', true);
    
    cvResults = struct();
    cvResults.method = 'Stratified K-Fold';
    cvResults.numFolds = numFolds;
    cvResults.foldResults = cell(numFolds, 1);
    
    for fold = 1:numFolds
        trainIdx = training(cv, fold);
        testIdx = test(cv, fold);
        
        % Train and evaluate model
        foldResult = trainAndEvaluateModel(features(trainIdx, :), labels(trainIdx), ...
                                          features(testIdx, :), labels(testIdx));
        cvResults.foldResults{fold} = foldResult;
    end
    
    % Aggregate results
    cvResults = aggregateCVResults(cvResults);
end

function cvResults = performGroupedCrossValidation(features, labels, groups)
    %% Implement grouped cross-validation to prevent data leakage
    
    fprintf('Performing grouped cross-validation...\n');
    
    uniqueGroups = unique(groups);
    numGroups = length(uniqueGroups);
    numFolds = min(5, numGroups);
    
    groupCV = cvpartition(numGroups, 'KFold', numFolds);
    
    cvResults = struct();
    cvResults.method = 'Grouped K-Fold';
    cvResults.numFolds = numFolds;
    cvResults.foldResults = cell(numFolds, 1);
    
    for fold = 1:numFolds
        trainGroups = uniqueGroups(training(groupCV, fold));
        testGroups = uniqueGroups(test(groupCV, fold));
        
        trainIdx = ismember(groups, trainGroups);
        testIdx = ismember(groups, testGroups);
        
        % Train and evaluate model
        foldResult = trainAndEvaluateModel(features(trainIdx, :), labels(trainIdx), ...
                                          features(testIdx, :), labels(testIdx));
        cvResults.foldResults{fold} = foldResult;
    end
    
    % Aggregate results
    cvResults = aggregateCVResults(cvResults);
end

function bootResults = performBootstrapValidation(features, labels, numBootstrap)
    %% Implement bootstrap validation with bias correction
    
    fprintf('Performing bootstrap validation with %d samples...\n', numBootstrap);
    
    numSamples = size(features, 1);
    accuracies = zeros(numBootstrap, 1);
    
    for bootstrap = 1:numBootstrap
        % Bootstrap sampling
        bootIdx = randsample(numSamples, numSamples, true);
        oobIdx = setdiff(1:numSamples, unique(bootIdx));
        
        if ~isempty(oobIdx)
            % Train on bootstrap sample, test on out-of-bag
            result = trainAndEvaluateModel(features(bootIdx, :), labels(bootIdx), ...
                                          features(oobIdx, :), labels(oobIdx));
            accuracies(bootstrap) = result.accuracy;
        end
    end
    
    % Remove failed bootstraps
    validAccuracies = accuracies(accuracies > 0);
    
    bootResults = struct();
    bootResults.method = 'Bootstrap';
    bootResults.numBootstrap = length(validAccuracies);
    bootResults.accuracies = validAccuracies;
    bootResults.meanAccuracy = mean(validAccuracies);
    bootResults.stdAccuracy = std(validAccuracies);
    bootResults.ci95 = [prctile(validAccuracies, 2.5), prctile(validAccuracies, 97.5)];
    bootResults.bcaCI95 = computeBCaCI(validAccuracies, 0.95);
end

function tempResults = performTemporalCrossValidation(features, labels, timeStamps)
    %% Implement temporal cross-validation for time-series data
    
    fprintf('Performing temporal cross-validation...\n');
    
    % Sort by time
    [sortedTimes, sortIdx] = sort(timeStamps);
    sortedFeatures = features(sortIdx, :);
    sortedLabels = labels(sortIdx);
    
    numSamples = length(sortedLabels);
    numFolds = 5;
    
    tempResults = struct();
    tempResults.method = 'Temporal';
    tempResults.numFolds = numFolds;
    tempResults.foldResults = cell(numFolds, 1);
    
    for fold = 1:numFolds
        % Use expanding window approach
        trainEnd = round(numSamples * (0.5 + 0.1 * fold));
        testStart = trainEnd + 1;
        testEnd = min(testStart + round(numSamples * 0.1), numSamples);
        
        if testEnd > testStart
            trainIdx = 1:trainEnd;
            testIdx = testStart:testEnd;
            
            foldResult = trainAndEvaluateModel(sortedFeatures(trainIdx, :), sortedLabels(trainIdx), ...
                                              sortedFeatures(testIdx, :), sortedLabels(testIdx));
            tempResults.foldResults{fold} = foldResult;
        end
    end
    
    % Aggregate results
    tempResults = aggregateCVResults(tempResults);
end

function fairnessResults = performFairnessAssessment(features, labels, demographics)
    %% Assess fairness across different demographic groups
    
    fprintf('Performing fairness assessment...\n');
    
    fairnessResults = struct();
    
    % Assess fairness across different demographic attributes
    demographicFields = fieldnames(demographics);
    
    for i = 1:length(demographicFields)
        field = demographicFields{i};
        groups = demographics.*(field);
        
        fieldResults = assessFairnessAcrossGroups(features, labels, groups, field);
        fairnessResults.*(field) = fieldResults;
    end
    
    % Compute overall fairness metrics
    fairnessResults.overallFairness = computeOverallFairnessMetrics(fairnessResults);
end

function groupResults = assessFairnessAcrossGroups(features, labels, groups, groupName)
    %% Assess fairness metrics for specific demographic group
    
    uniqueGroups = unique(groups);
    numGroups = length(uniqueGroups);
    
    groupResults = struct();
    groupResults.groupName = groupName;
    groupResults.numGroups = numGroups;
    groupResults.groupMetrics = cell(numGroups, 1);
    
    for group = 1:numGroups
        groupIdx = groups == uniqueGroups(group);
        
        if sum(groupIdx) > 10 % Minimum sample size
            groupFeatures = features(groupIdx, :);
            groupLabels = labels(groupIdx);
            
            % Perform cross-validation for this group
            cv = cvpartition(groupLabels, 'KFold', 3);
            groupAccuracies = zeros(3, 1);
            
            for fold = 1:3
                trainIdx = training(cv, fold);
                testIdx = test(cv, fold);
                
                result = trainAndEvaluateModel(groupFeatures(trainIdx, :), groupLabels(trainIdx), ...
                                              groupFeatures(testIdx, :), groupLabels(testIdx));
                groupAccuracies(fold) = result.accuracy;
            end
            
            groupMetric = struct();
            groupMetric.groupId = uniqueGroups(group);
            groupMetric.sampleSize = sum(groupIdx);
            groupMetric.meanAccuracy = mean(groupAccuracies);
            groupMetric.stdAccuracy = std(groupAccuracies);
            
            groupResults.groupMetrics{group} = groupMetric;
        end
    end
    
    % Compute fairness metrics
    groupResults.fairnessMetrics = computeFairnessMetrics(groupResults.groupMetrics);
end

function result = trainAndEvaluateModel(trainFeatures, trainLabels, testFeatures, testLabels)
    %% Train and evaluate a simple classification model
    
    try
        % Use logistic regression for demonstration
        if length(unique(trainLabels)) > 2
            % Multiclass classification
            model = fitcecoc(trainFeatures, trainLabels);
        else
            % Binary classification
            model = fitclinear(trainFeatures, trainLabels);
        end
        
        % Make predictions
        predictions = predict(model, testFeatures);
        
        % Compute metrics
        result = struct();
        result.accuracy = mean(predictions == testLabels);
        result.predictions = predictions;
        result.trueLabels = testLabels;
        
        % Confusion matrix
        result.confusionMatrix = confusionmat(testLabels, predictions);
        
        % Per-class metrics
        uniqueClasses = unique(testLabels);
        numClasses = length(uniqueClasses);
        
        result.precision = zeros(numClasses, 1);
        result.recall = zeros(numClasses, 1);
        result.f1Score = zeros(numClasses, 1);
        
        for i = 1:numClasses
            tp = sum(predictions == uniqueClasses(i) & testLabels == uniqueClasses(i));
            fp = sum(predictions == uniqueClasses(i) & testLabels ~= uniqueClasses(i));
            fn = sum(predictions ~= uniqueClasses(i) & testLabels == uniqueClasses(i));
            
            result.precision(i) = tp / (tp + fp + eps);
            result.recall(i) = tp / (tp + fn + eps);
            result.f1Score(i) = 2 * result.precision(i) * result.recall(i) / ...
                               (result.precision(i) + result.recall(i) + eps);
        end
        
        result.success = true;
        
    catch ME
        fprintf('Model training failed: %s\n', ME.message);
        result = struct();
        result.accuracy = 0;
        result.success = false;
    end
end

function cvResults = aggregateCVResults(cvResults)
    %% Aggregate cross-validation results across folds
    
    foldResults = cvResults.foldResults;
    validFolds = cellfun(@(x) isfield(x, 'success') && x.success, foldResults);
    validResults = foldResults(validFolds);
    
    if ~isempty(validResults)
        accuracies = cellfun(@(x) x.accuracy, validResults);
        
        cvResults.meanAccuracy = mean(accuracies);
        cvResults.stdAccuracy = std(accuracies);
        cvResults.minAccuracy = min(accuracies);
        cvResults.maxAccuracy = max(accuracies);
        cvResults.ci95 = computeConfidenceInterval(accuracies, 0.95);
        cvResults.numValidFolds = length(validResults);
    else
        cvResults.meanAccuracy = 0;
        cvResults.stdAccuracy = 0;
        cvResults.numValidFolds = 0;
    end
end

function ci = computeConfidenceInterval(data, confidenceLevel)
    %% Compute confidence interval using t-distribution
    
    alpha = 1 - confidenceLevel;
    n = length(data);
    
    meanData = mean(data);
    stdData = std(data);
    
    tCrit = tinv(1 - alpha/2, n - 1);
    margin = tCrit * stdData / sqrt(n);
    
    ci = [meanData - margin, meanData + margin];
end

function bcaCI = computeBCaCI(data, confidenceLevel)
    %% Compute bias-corrected and accelerated confidence interval
    
    % Simplified BCa CI computation
    alpha = 1 - confidenceLevel;
    
    meanData = mean(data);
    biasCorrection = norminv(sum(data < meanData) / length(data));
    acceleration = 0; % Simplified - would need jackknife for exact calculation
    
    z_alpha2 = norminv(alpha / 2);
    z_1alpha2 = norminv(1 - alpha / 2);
    
    alpha1 = normcdf(biasCorrection + (biasCorrection + z_alpha2) / ...
                    (1 - acceleration * (biasCorrection + z_alpha2)));
    alpha2 = normcdf(biasCorrection + (biasCorrection + z_1alpha2) / ...
                    (1 - acceleration * (biasCorrection + z_1alpha2)));
    
    alpha1 = max(0, min(1, alpha1));
    alpha2 = max(0, min(1, alpha2));
    
    bcaCI = [prctile(data, alpha1 * 100), prctile(data, alpha2 * 100)];
end

function fairnessMetrics = computeFairnessMetrics(groupMetrics)
    %% Compute fairness metrics across groups
    
    validGroups = cellfun(@(x) ~isempty(x), groupMetrics);
    validMetrics = groupMetrics(validGroups);
    
    if length(validMetrics) < 2
        fairnessMetrics = struct();
        return;
    end
    
    accuracies = cellfun(@(x) x.meanAccuracy, validMetrics);
    
    fairnessMetrics = struct();
    fairnessMetrics.equalisedOdds = max(accuracies) - min(accuracies);
    fairnessMetrics.demographicParity = std(accuracies);
    fairnessMetrics.maxGroupAccuracy = max(accuracies);
    fairnessMetrics.minGroupAccuracy = min(accuracies);
    fairnessMetrics.averageAccuracy = mean(accuracies);
end

function overallMetrics = computeOverallFairnessMetrics(fairnessResults)
    %% Compute overall fairness assessment
    
    fields = fieldnames(fairnessResults);
    fields = fields(~strcmp(fields, 'overallFairness'));
    
    overallMetrics = struct();
    
    if ~isempty(fields)
        maxEqOdds = 0;
        maxDemParity = 0;
        
        for i = 1:length(fields)
            field = fields{i};
            if isfield(fairnessResults.*(field), 'fairnessMetrics')
                metrics = fairnessResults.*(field).fairnessMetrics;
                if isfield(metrics, 'equalisedOdds')
                    maxEqOdds = max(maxEqOdds, metrics.equalisedOdds);
                end
                if isfield(metrics, 'demographicParity')
                    maxDemParity = max(maxDemParity, metrics.demographicParity);
                end
            end
        end
        
        overallMetrics.maxEqualisedOdds = maxEqOdds;
        overallMetrics.maxDemographicParity = maxDemParity;
        overallMetrics.fairnessScore = 1 / (1 + maxEqOdds + maxDemParity);
    end
end

function sigResults = performSignificanceTestingFramework(evaluationResults)
    %% Perform comprehensive statistical significance testing
    
    fprintf('Performing statistical significance testing...\n');
    
    sigResults = struct();
    
    % Extract accuracies from different methods
    methods = fieldnames(evaluationResults);
    methodAccuracies = cell(length(methods), 1);
    methodNames = cell(length(methods), 1);
    
    validMethods = 0;
    for i = 1:length(methods)
        method = methods{i};
        if isfield(evaluationResults.*(method), 'foldResults') && ...
           ~strcmp(method, 'fairness') && ~strcmp(method, 'significance')
            
            validMethods = validMethods + 1;
            foldResults = evaluationResults.*(method).foldResults;
            validFolds = cellfun(@(x) isfield(x, 'success') && x.success, foldResults);
            
            if sum(validFolds) > 0
                accuracies = cellfun(@(x) x.accuracy, foldResults(validFolds));
                methodAccuracies{validMethods} = accuracies;
                methodNames{validMethods} = method;
            end
        end
    end
    
    % Trim to valid methods
    methodAccuracies = methodAccuracies(1:validMethods);
    methodNames = methodNames(1:validMethods);
    
    % Pairwise significance tests
    if validMethods >= 2
        sigResults.pairwiseTests = performPairwiseTests(methodAccuracies, methodNames);
        
        % Multiple comparison correction
        pValues = extractPValues(sigResults.pairwiseTests);
        sigResults.correctedTests = correctMultipleComparisons(pValues, 'bonferroni');
    end
    
    % ANOVA if multiple methods
    if validMethods >= 3
        sigResults.anova = performANOVATest(methodAccuracies, methodNames);
    end
end

function pairwiseResults = performPairwiseTests(methodAccuracies, methodNames)
    %% Perform pairwise statistical tests between methods
    
    numMethods = length(methodAccuracies);
    pairwiseResults = cell(numMethods, numMethods);
    
    for i = 1:numMethods
        for j = (i+1):numMethods
            if ~isempty(methodAccuracies{i}) && ~isempty(methodAccuracies{j})
                
                % Paired t-test
                [h_ttest, p_ttest] = ttest(methodAccuracies{i}, methodAccuracies{j});
                
                % Wilcoxon signed-rank test
                [p_wilcoxon, h_wilcoxon] = signrank(methodAccuracies{i}, methodAccuracies{j});
                
                testResult = struct();
                testResult.method1 = methodNames{i};
                testResult.method2 = methodNames{j};
                testResult.ttest_h = h_ttest;
                testResult.ttest_p = p_ttest;
                testResult.wilcoxon_h = h_wilcoxon;
                testResult.wilcoxon_p = p_wilcoxon;
                testResult.effectSize = computeEffectSize(methodAccuracies{i}, methodAccuracies{j});
                
                pairwiseResults{i, j} = testResult;
            end
        end
    end
end

function anovaResults = performANOVATest(methodAccuracies, methodNames)
    %% Perform ANOVA test across multiple methods
    
    % Combine data for ANOVA
    allData = [];
    groupLabels = [];
    
    for i = 1:length(methodAccuracies)
        data = methodAccuracies{i};
        allData = [allData; data(:)];
        groupLabels = [groupLabels; repmat(i, length(data), 1)];
    end
    
    % Perform one-way ANOVA
    [p, tbl, stats] = anova1(allData, groupLabels, 'off');
    
    anovaResults = struct();
    anovaResults.pValue = p;
    anovaResults.table = tbl;
    anovaResults.stats = stats;
    anovaResults.methodNames = methodNames;
    
    % Post-hoc tests if significant
    if p < 0.05
        [comparison, means, h] = multcompare(stats, 'Display', 'off');
        anovaResults.postHoc = struct();
        anovaResults.postHoc.comparison = comparison;
        anovaResults.postHoc.means = means;
        anovaResults.postHoc.significant = h;
    end
end

function effectSize = computeEffectSize(group1, group2)
    %% Compute Cohen's d effect size
    
    mean1 = mean(group1);
    mean2 = mean(group2);
    
    std1 = std(group1);
    std2 = std(group2);
    
    n1 = length(group1);
    n2 = length(group2);
    
    pooledStd = sqrt(((n1 - 1) * std1^2 + (n2 - 1) * std2^2) / (n1 + n2 - 2));
    effectSize = (mean1 - mean2) / pooledStd;
end

function pValues = extractPValues(pairwiseTests)
    %% Extract p-values from pairwise tests
    
    pValues = [];
    [rows, cols] = size(pairwiseTests);
    
    for i = 1:rows
        for j = 1:cols
            if ~isempty(pairwiseTests{i, j})
                pValues = [pValues; pairwiseTests{i, j}.ttest_p];
            end
        end
    end
end

function correctedResults = correctMultipleComparisons(pValues, method)
    %% Apply multiple comparison correction
    
    switch method
        case 'bonferroni'
            correctedP = pValues * length(pValues);
            correctedP = min(correctedP, 1);
            
        case 'holm'
            [sortedP, sortIdx] = sort(pValues);
            correctedP = zeros(size(pValues));
            
            for i = 1:length(sortedP)
                adjustment = length(pValues) - i + 1;
                correctedP(sortIdx(i)) = min(1, sortedP(i) * adjustment);
            end
            
        case 'fdr'
            [sortedP, sortIdx] = sort(pValues);
            correctedP = zeros(size(pValues));
            
            for i = length(sortedP):-1:1
                if i == length(sortedP)
                    correctedP(sortIdx(i)) = sortedP(i);
                else
                    correctedP(sortIdx(i)) = min(correctedP(sortIdx(i+1)), ...
                                               sortedP(i) * length(pValues) / i);
                end
            end
    end
    
    correctedResults = struct();
    correctedResults.method = method;
    correctedResults.originalP = pValues;
    correctedResults.correctedP = correctedP;
    correctedResults.significant = correctedP < 0.05;
    correctedResults.numSignificant = sum(correctedResults.significant);
end

function generateEvaluationReport(evaluationResults)
    %% Generate comprehensive evaluation report
    
    fprintf('\n' + string(repmat('=', 1, 70)) + '\n');
    fprintf('COMPREHENSIVE PERFORMANCE EVALUATION REPORT\n');
    fprintf(string(repmat('=', 1, 70)) + '\n');
    
    % Cross-validation results
    if isfield(evaluationResults, 'stratifiedCV')
        fprintf('\nSTRATIFIED CROSS-VALIDATION:\n');
        cv = evaluationResults.stratifiedCV;
        fprintf('  Mean Accuracy: %.3f ㊣ %.3f\n', cv.meanAccuracy, cv.stdAccuracy);
        fprintf('  95%% CI: [%.3f, %.3f]\n', cv.ci95(1), cv.ci95(2));
        fprintf('  Valid Folds: %d/%d\n', cv.numValidFolds, cv.numFolds);
    end
    
    if isfield(evaluationResults, 'groupedCV')
        fprintf('\nGROUPED CROSS-VALIDATION:\n');
        cv = evaluationResults.groupedCV;
        fprintf('  Mean Accuracy: %.3f ㊣ %.3f\n', cv.meanAccuracy, cv.stdAccuracy);
        fprintf('  95%% CI: [%.3f, %.3f]\n', cv.ci95(1), cv.ci95(2));
        fprintf('  Valid Folds: %d/%d\n', cv.numValidFolds, cv.numFolds);
    end
    
    if isfield(evaluationResults, 'bootstrap')
        fprintf('\nBOOTSTRAP VALIDATION:\n');
        boot = evaluationResults.bootstrap;
        fprintf('  Mean Accuracy: %.3f ㊣ %.3f\n', boot.meanAccuracy, boot.stdAccuracy);
        fprintf('  95%% CI: [%.3f, %.3f]\n', boot.ci95(1), boot.ci95(2));
        fprintf('  BCa CI: [%.3f, %.3f]\n', boot.bcaCI95(1), boot.bcaCI95(2));
        fprintf('  Bootstrap Samples: %d\n', boot.numBootstrap);
    end
    
    % Fairness assessment
    if isfield(evaluationResults, 'fairness')
        fprintf('\nFAIRNESS ASSESSMENT:\n');
        fairness = evaluationResults.fairness;
        
        if isfield(fairness, 'overallFairness')
            overall = fairness.overallFairness;
            fprintf('  Fairness Score: %.3f\n', overall.fairnessScore);
            fprintf('  Max Equalised Odds: %.3f\n', overall.maxEqualisedOdds);
            fprintf('  Max Demographic Parity: %.3f\n', overall.maxDemographicParity);
        end
    end
    
    % Statistical significance
    if isfield(evaluationResults, 'significance')
        fprintf('\nSTATISTICAL SIGNIFICANCE:\n');
        sig = evaluationResults.significance;
        
        if isfield(sig, 'anova')
            fprintf('  ANOVA p-value: %.4f\n', sig.anova.pValue);
            if sig.anova.pValue < 0.05
                fprintf('  Significant differences detected between methods\n');
            else
                fprintf('  No significant differences between methods\n');
            end
        end
        
        if isfield(sig, 'correctedTests')
            fprintf('  Multiple comparison correction applied\n');
            fprintf('  Significant pairwise differences: %d\n', sig.correctedTests.numSignificant);
        end
    end
    
    fprintf('\n' + string(repmat('=', 1, 70)) + '\n');
end

function visualiseEvaluationResults(evaluationResults)
    %% Visualise comprehensive evaluation results
    
    figure('Position', [100, 100, 1200, 800]);
    
    % Extract method results for comparison
    methods = {'stratifiedCV', 'groupedCV', 'bootstrap', 'temporalCV'};
    methodLabels = {'Stratified CV', 'Grouped CV', 'Bootstrap', 'Temporal CV'};
    
    meanAccuracies = [];
    stdAccuracies = [];
    validMethods = {};
    
    for i = 1:length(methods)
        if isfield(evaluationResults, methods{i})
            result = evaluationResults.*(methods{i});
            if isfield(result, 'meanAccuracy')
                meanAccuracies = [meanAccuracies; result.meanAccuracy];
                stdAccuracies = [stdAccuracies; result.stdAccuracy];
                validMethods{end+1} = methodLabels{i};
            end
        end
    end
    
    % Method comparison
    subplot(2, 3, 1);
    if ~isempty(meanAccuracies)
        bar(meanAccuracies);
        hold on;
        errorbar(1:length(meanAccuracies), meanAccuracies, stdAccuracies, 'k.', 'LineWidth', 2);
        hold off;
        set(gca, 'XTickLabel', validMethods);
        xtickangle(45);
        ylabel('Accuracy');
        title('Method Comparison');
        grid on;
    end
    
    % Bootstrap distribution
    subplot(2, 3, 2);
    if isfield(evaluationResults, 'bootstrap')
        boot = evaluationResults.bootstrap;
        histogram(boot.accuracies, 30, 'Normalization', 'pdf');
        xlabel('Accuracy');
        ylabel('Density');
        title('Bootstrap Distribution');
        grid on;
    end
    
    % Confidence intervals
    subplot(2, 3, 3);
    if ~isempty(meanAccuracies)
        ciData = [];
        for i = 1:length(methods)
            if isfield(evaluationResults, methods{i}) && ...
               isfield(evaluationResults.*(methods{i}), 'ci95')
                ciData = [ciData; evaluationResults.*(methods{i}).ci95];
            end
        end
        
        if ~isempty(ciData)
            errorbar(1:size(ciData, 1), meanAccuracies(1:size(ciData, 1)), ...
                    meanAccuracies(1:size(ciData, 1)) - ciData(:, 1), ...
                    ciData(:, 2) - meanAccuracies(1:size(ciData, 1)), 'o-');
            set(gca, 'XTickLabel', validMethods(1:size(ciData, 1)));
            xtickangle(45);
            ylabel('Accuracy');
            title('95% Confidence Intervals');
            grid on;
        end
    end
    
    % Fairness assessment
    subplot(2, 3, 4);
    if isfield(evaluationResults, 'fairness')
        fairness = evaluationResults.fairness;
        fields = fieldnames(fairness);
        fields = fields(~strcmp(fields, 'overallFairness'));
        
        if ~isempty(fields)
            fairnessScores = [];
            for i = 1:length(fields)
                field = fields{i};
                if isfield(fairness.*(field), 'fairnessMetrics') && ...
                   isfield(fairness.*(field).fairnessMetrics, 'equalisedOdds')
                    fairnessScores = [fairnessScores; fairness.*(field).fairnessMetrics.equalisedOdds];
                end
            end
            
            if ~isempty(fairnessScores)
                bar(fairnessScores);
                set(gca, 'XTickLabel', fields);
                xtickangle(45);
                ylabel('Equalised Odds Difference');
                title('Fairness Assessment');
                grid on;
            end
        end
    end
    
    % Method stability
    subplot(2, 3, 5);
    if ~isempty(stdAccuracies)
        bar(stdAccuracies);
        set(gca, 'XTickLabel', validMethods);
        xtickangle(45);
        ylabel('Standard Deviation');
        title('Method Stability');
        grid on;
    end
    
    % Overall summary
    subplot(2, 3, 6);
    if ~isempty(meanAccuracies)
        % Create radar plot-like visualization
        angles = linspace(0, 2*pi, length(meanAccuracies) + 1);
        values = [meanAccuracies; meanAccuracies(1)]; % Close the loop
        
        polarplot(angles, values, 'o-', 'LineWidth', 2);
        theta*ticks(rad2deg(angles(1:end-1)));
        theta*ticklabels(validMethods);
        title('Overall Performance');
    end
    
    sgtitle('Comprehensive Performance Evaluation Results', 'FontSize', 14);
end
