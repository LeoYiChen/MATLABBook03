%% chapter_AI_CV_bundle_adjustment_01.m
% Bundle Adjustment Implementation and 3D Reconstruction Optimisation
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_bundle_adjustment_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Comprehensive Bundle Adjustment Implementation for Structure from Motion
fprintf('Bundle Adjustment: Global Optimization for 3*D Reconstruction\n');
fprintf('===========================================================\n');

% Use the feature tracks from previous section to initialize bundle adjustment
% For demonstration, create simplified bundle adjustment problem

% Initialize camera parameters and 3*D points from feature tracks


% Initialize bundle adjustment problem
if exist('featureTracks', 'var') && ~isempty(featureTracks)
[cameras, points3D, observations] = initializeBundleAdjustment(featureTracks, cameraParams, numImages);
else
% Create synthetic data for demonstration
fprintf('Creating synthetic bundle adjustment problem...\n');
[cameras, points3D, observations] = createSyntheticBundleAdjustmentProblem();
end


% Bundle adjustment optimization







% Perform bundle adjustment
if ~isempty(cameras) && ~isempty(points3D) && ~isempty(observations)
options = struct();
options.maxIterations = 20; % Reduced for demonstration
options.tolerance = 1e-3;
options.verbose = true;

 
[optimizedCameras, optimized3DPoints, baStatistics] = bundleAdjustment(cameras, points3D, observations, options);

% Analyze optimization results
fprintf('\nBundle Adjustment Results:\n');
fprintf('==========================\n');
fprintf('Initial RMSE: %.3f pixels\n', baStatistics.initialRMSE);
fprintf('Final RMSE: %.3f pixels\n', baStatistics.finalRMSE);
fprintf('Improvement: %.3f pixels (%.1f%%)\n', ...
    baStatistics.initialRMSE - baStatistics.finalRMSE, ...
    100 * (baStatistics.initialRMSE - baStatistics.finalRMSE) / baStatistics.initialRMSE);
fprintf('Iterations: %d\n', baStatistics.iterations);

% Visualize optimization convergence
figure;
plot(0:(length(baStatistics.rmseHistory)-1), baStatistics.rmseHistory, 'b-o', 'LineWidth', 2);
xlabel('Iteration');
ylabel('RMSE (pixels)');
title('Bundle Adjustment Convergence');
grid on;

% 3*D reconstruction visualization
figure;

% Plot optimized 3*D points
subplot(1, 2, 1);
if size(optimized3DPoints, 1) > 0
    scatter3(optimized3DPoints(:, 1), optimized3DPoints(:, 2), optimized3DPoints(:, 3), ...
        20, optimized3DPoints(:, 3), 'filled');
    colorbar;
    title('Optimized 3*D Points');
    xlabel('X (mm)');
    ylabel('Y (mm)');
    zlabel('Z (mm)');
    axis equal;
    
    % Plot camera positions
    hold on;
    for i = 1:length(optimizedCameras)
        camera = optimizedCameras(i);
        camera_center = -camera.R' * camera.t;
        plot3(camera_center(1), camera_center(2), camera_center(3), 'ro', 'MarkerSize', 8, 'LineWidth', 2);
    end
    hold off;
    legend('3*D Points', 'Cameras');
else
    text(0.5, 0.5, 'No 3*D points to display', 'Units', 'normalized', 'HorizontalAlignment', 'center');
    title('3*D Reconstruction');
end

% Plot reprojection errors
subplot(1, 2, 2);
if ~isempty(observations)
    reprojectionErrors = [];
    for i = 1:length(observations)
        obs = observations(i);
        
        if obs.pointId <= size(optimized3DPoints, 1) && obs.imageId <= length(optimizedCameras)
            point3D = [optimized3DPoints(obs.pointId, :), 1]';
            camera = optimizedCameras(obs.imageId);
            
            P = camera.K * [camera.R, camera.t];
            projected = P * point3D;
            
            if projected(3) > 0
                projectedX = projected(1) / projected(3);
                projectedY = projected(2) / projected(3);
                
                errorX = obs.x - projectedX;
                errorY = obs.y - projectedY;
                error = sqrt(errorX^2 + errorY^2);
                reprojectionErrors(end+1) = error;
            end
        end
    end
    
    if ~isempty(reprojectionErrors)
        histogram(reprojectionErrors, 20);
        xlabel('Reprojection Error (pixels)');
        ylabel('Frequency');
        title('Reprojection Error Distribution');
        
        % Add statistics
        text(0.7, 0.8, sprintf('Mean: %.2f px\nStd: %.2f px\nMax: %.2f px', ...
            mean(reprojectionErrors), std(reprojectionErrors), max(reprojectionErrors)), ...
            'Units', 'normalized', 'FontSize', 10, 'BackgroundColor', 'white');
    end
end
else
fprintf('Insufficient data for bundle adjustment\n');
end

% Advanced bundle adjustment techniques
fprintf('\nAdvanced Bundle Adjustment Techniques:\n');
fprintf('=====================================\n');
fprintf('1. Robust cost functions (Huber, Cauchy) for outlier handling\n');
fprintf('2. Incremental bundle adjustment for large-scale problems\n');
fprintf('3. Hierarchical optimization for computational efficiency\n');
fprintf('4. Sparse matrix techniques for large systems\n');
fprintf('5. GPU acceleration for parallel computation\n');
fprintf('6. Automatic parameter selection and regularization\n');
fprintf('7. Multi-threading for Jacobian computation\n');
fprintf('8. Memory-efficient implementations for mobile devices\n');

% Implementation considerations
fprintf('\nImplementation Best Practices:\n');
fprintf('=============================\n');
fprintf('1. Use sparse matrix representations for efficiency\n');
fprintf('2. Implement robust cost functions for outlier rejection\n');
fprintf('3. Apply proper parameter scaling for numerical stability\n');
fprintf('4. Monitor convergence criteria carefully\n');
fprintf('5. Validate results through cross-validation\n');
fprintf('6. Consider incremental approaches for large problems\n');
fprintf('7. Implement proper error handling and recovery\n');
fprintf('8. Use established libraries (Ceres, g2o) when possible\n');

% Local functions (moved to end so this listing is a valid MATLAB script)
function [initialCameras, initial3DPoints, observations] = initializeBundleAdjustment(featureTracks, cameraParams, numImages)

 
% Extract valid tracks (length >= 3 for stable triangulation)
validTracks = featureTracks([featureTracks.imageIds] >= 3);

if isempty(validTracks)
    fprintf('Warning: No tracks with sufficient length for bundle adjustment\n');
    initialCameras = [];
    initial3DPoints = [];
    observations = [];
    return;
end

% Initialize camera parameters
initialCameras = struct();
for i = 1:numImages
    if i <= length(cameraParams) && ~isempty(cameraParams{i})
        initialCameras(i).K = cameraParams{i}.K;
        initialCameras(i).R = cameraParams{i}.R;
        initialCameras(i).t = cameraParams{i}.t;
    else
        % Default camera parameters
        initialCameras(i).K = [800, 0, 320; 0, 800, 240; 0, 0, 1];
        initialCameras(i).R = eye(3);
        initialCameras(i).t = [0; 0; 0];
    end
end

% Triangulate initial 3*D points from tracks
initial3DPoints = [];
observations = [];

for trackIdx = 1:length(validTracks)
    track = validTracks(trackIdx);
    
    if length(track.imageIds) >= 2
        % Use first two views for triangulation
        imageId1 = track.imageIds(1);
        imageId2 = track.imageIds(2);
        
        P1 = initialCameras(imageId1).K * [initialCameras(imageId1).R, initialCameras(imageId1).t];
        P2 = initialCameras(imageId2).K * [initialCameras(imageId2).R, initialCameras(imageId2).t];
        
        point1 = track.points(1, :);
        point2 = track.points(2, :);
        
        % Triangulate 3*D point
        point3D = triangulatePoint(P1, P2, point1, point2);
        
        if ~any(isnan(point3D)) && point3D(3) > 0 % Valid point in front of cameras
            initial3DPoints = [initial3DPoints; point3D'];
            
            % Create observations for all views in track
            for i = 1:length(track.imageIds)
                obs = struct();
                obs.pointId = size(initial3DPoints, 1);
                obs.imageId = track.imageIds(i);
                obs.x = track.points(i, 1);
                obs.y = track.points(i, 2);
                observations = [observations; obs];
            end
        end
    end
end

fprintf('Initialized %d cameras and %d 3*D points\n', numImages, size(initial3DPoints, 1));
fprintf('Total observations: %d\n', length(observations));
end

function point3D = triangulatePoint(P1, P2, point1, point2)
% Triangulate 3*D point from two views using linear method

 
% Convert to homogeneous coordinates
x1 = [point1, 1]';
x2 = [point2, 1]';

% Create constraint matrix A
A = [x1(1) * P1(3, :) - P1(1, :);
     x1(2) * P1(3, :) - P1(2, :);
     x2(1) * P2(3, :) - P2(1, :);
     x2(2) * P2(3, :) - P2(2, :)];

% Solve using SVD
[~, ~, V] = svd(A);
X = V(:, end);

% Convert to Euclidean coordinates
if abs(X(4)) > 1e-10
    point3D = X(1:3) / X(4);
else
    point3D = [NaN; NaN; NaN];
end
end

function [cameras, points3D, observations] = createSyntheticBundleAdjustmentProblem()
% Create a synthetic bundle adjustment problem for demonstration

 
numCameras = 6;
numPoints = 50;

% Camera parameters
K = [800, 0, 320; 0, 800, 240; 0, 0, 1];

% Create cameras in circular arrangement
cameras = struct();
radius = 1000; % mm
center = [0, 0, 500];

for i = 1:numCameras
    angle = (i - 1) * 2 * pi / numCameras;
    camera_pos = center + [radius * cos(angle), radius * sin(angle), 200];
    
    % Camera looks towards center
    look_direction = center - camera_pos;
    look_direction = look_direction / norm(look_direction);
    
    % Construct rotation matrix
    up = [0, 0, 1];
    right = cross(look_direction, up);
    right = right / norm(right);
    up_corrected = cross(right, look_direction);
    
    R = [right; up_corrected; -look_direction];
    t = -R * camera_pos';
    
    cameras(i).K = K;
    cameras(i).R = R;
    cameras(i).t = t;
end

% Create 3*D points
points3D = [rand(numPoints, 1) * 400 - 200, ...  % X: -200 to 200
            rand(numPoints, 1) * 400 - 200, ...  % Y: -200 to 200
            rand(numPoints, 1) * 200 + 400];     % Z: 400 to 600

% Generate observations
observations = [];
observationId = 1;

for pointId = 1:numPoints
    point3D = [points3D(pointId, :), 1]';
    
    for cameraId = 1:numCameras
        % Project point to image
        P = cameras(cameraId).K * [cameras(cameraId).R, cameras(cameraId).t];
        projected = P * point3D;
        
        if projected(3) > 0 % Point in front of camera
            x = projected(1) / projected(3);
            y = projected(2) / projected(3);
            
            % Check if point is within image bounds
            if x >= 50 && x <= 590 && y >= 50 && y <= 430
                % Add noise to simulate real observations
                noise = randn(1, 2) * 0.5; % 0.5 pixel standard deviation
                
                obs = struct();
                obs.pointId = pointId;
                obs.imageId = cameraId;
                obs.x = x + noise(1);
                obs.y = y + noise(2);
                observations = [observations; obs];
                observationId = observationId + 1;
            end
        end
    end
end

fprintf('Created synthetic problem: %d cameras, %d points, %d observations\n', ...
    numCameras, numPoints, length(observations));
end

function [optimizedCameras, optimized3DPoints, statistics] = bundleAdjustment(cameras, points3D, observations, options)
fprintf('Performing bundle adjustment optimization...\n');

 
if nargin < 4
    options = struct();
    options.maxIterations = 50;
    options.tolerance = 1e-6;
    options.robustThreshold = 2.0; % pixels
    options.verbose = true;
end

% Convert to parameter vector for optimization
[paramVector, paramInfo] = packParameters(cameras, points3D);

% Optimization using Levenberg-Marquardt (simplified implementation)
statistics = struct();
statistics.initialRMSE = computeRMSE(paramVector, observations, paramInfo);
statistics.iterations = 0;
statistics.rmseHistory = [statistics.initialRMSE];

if options.verbose
    fprintf('Initial RMSE: %.3f pixels\n', statistics.initialRMSE);
end

% Simplified optimization loop
lambda = 0.001; % Damping parameter
currentParams = paramVector;
currentRMSE = statistics.initialRMSE;

for iter = 1:options.maxIterations
    % Compute Jacobian and residuals
    [residuals, jacobian] = computeJacobianAndResiduals(currentParams, observations, paramInfo);
    
    % Levenberg-Marquardt update
    JtJ = jacobian' * jacobian;
    JtR = jacobian' * residuals;
    
    % Add damping to diagonal
    dampedJtJ = JtJ + lambda * diag(diag(JtJ));
    
    try
        % Solve for parameter update
        delta*Params = -dampedJtJ \ JtR;
        
        % Update parameters
        newParams = currentParams + delta*Params;
        newRMSE = computeRMSE(newParams, observations, paramInfo);
        
        % Check for improvement
        if newRMSE < currentRMSE
            % Accept update
            currentParams = newParams;
            currentRMSE = newRMSE;
            lambda = lambda * 0.1; % Decrease damping
            
            if options.verbose && mod(iter, 5) == 0
                fprintf('Iteration %d: RMSE = %.3f pixels\n', iter, currentRMSE);
            end
            
            % Check convergence
            if abs(statistics.rmseHistory(end) - currentRMSE) < options.tolerance
                if options.verbose
                    fprintf('Converged after %d iterations\n', iter);
                end
                break;
            end
        else
            % Reject update, increase damping
            lambda = lambda * 10;
        end
        
        statistics.rmseHistory(end+1) = currentRMSE;
        statistics.iterations = iter;
        
    catch ME
        if options.verbose
            fprintf('Optimization failed at iteration %d: %s\n', iter, ME.message);
        end
        break;
    end
end

% Unpack optimized parameters
[optimizedCameras, optimized3DPoints] = unpackParameters(currentParams, paramInfo);
statistics.finalRMSE = currentRMSE;

if options.verbose
    fprintf('Final RMSE: %.3f pixels\n', statistics.finalRMSE);
    fprintf('Improvement: %.3f pixels (%.1f%%)\n', ...
        statistics.initialRMSE - statistics.finalRMSE, ...
        100 * (statistics.initialRMSE - statistics.finalRMSE) / statistics.initialRMSE);
end
end

function [paramVector, paramInfo] = packParameters(cameras, points3D)
% Pack camera and point parameters into a single vector

 
numCameras = length(cameras);
numPoints = size(points3D, 1);

% Camera parameters: rotation (3) + translation (3) per camera
% Assume intrinsics are fixed
cameraParams = [];
for i = 1:numCameras
    % Convert rotation matrix to Rodriguez vector
    rodVector = rotationMatrixToRodrigues(cameras(i).R);
    cameraParams = [cameraParams; rodVector; cameras(i).t];
end

% 3*D point parameters
pointParams = points3D(:);

% Combine all parameters
paramVector = [cameraParams; pointParams];

% Store parameter structure information
paramInfo = struct();
paramInfo.numCameras = numCameras;
paramInfo.numPoints = numPoints;
paramInfo.cameraParamSize = 6; % 3 rotation + 3 translation
paramInfo.cameraStartIdx = 1;
paramInfo.pointsStartIdx = numCameras * 6 + 1;

% Store original intrinsics (assumed fixed)
paramInfo.intrinsics = cell(numCameras, 1);
for i = 1:numCameras
    paramInfo.intrinsics{i} = cameras(i).K;
end
end

function [cameras, points3D] = unpackParameters(paramVector, paramInfo)
% Unpack parameter vector back to camera and point structures

 
% Extract camera parameters
cameras = struct();
for i = 1:paramInfo.numCameras
    startIdx = (i-1) * paramInfo.cameraParamSize + paramInfo.cameraStartIdx;
    endIdx = startIdx + paramInfo.cameraParamSize - 1;
    
    cameraParams = paramVector(startIdx:endIdx);
    
    % Rotation (Rodriguez vector to matrix)
    rodVector = cameraParams(1:3);
    R = rodriguesToRotationMatrix(rodVector);
    
    % Translation
    t = cameraParams(4:6);
    
    cameras(i).K = paramInfo.intrinsics{i};
    cameras(i).R = R;
    cameras(i).t = t;
end

% Extract 3*D points
pointParams = paramVector(paramInfo.pointsStartIdx:end);
points3D = reshape(pointParams, [], 3);
end

function rodVector = rotationMatrixToRodrigues(R)
% Convert rotation matrix to Rodriguez vector (simplified)
theta = acos((trace(R) - 1) / 2);

 
if abs(theta) < 1e-6
    rodVector = [0; 0; 0];
else
    k = (1 / (2 * sin(theta))) * [R(3,2) - R(2,3); R(1,3) - R(3,1); R(2,1) - R(1,2)];
    rodVector = theta * k;
end
end

function R = rodriguesToRotationMatrix(rodVector)
% Convert Rodriguez vector to rotation matrix
theta = norm(rodVector);

 
if theta < 1e-6
    R = eye(3);
else
    k = rodVector / theta;
    K = [0, -k(3), k(2); k(3), 0, -k(1); -k(2), k(1), 0]; % Skew symmetric matrix
    R = eye(3) + sin(theta) * K + (1 - cos(theta)) * K^2;
end
end

function rmse = computeRMSE(paramVector, observations, paramInfo)
% Compute root mean square reprojection error

 
[cameras, points3D] = unpackParameters(paramVector, paramInfo);

totalError = 0;
numObservations = length(observations);

for i = 1:numObservations
    obs = observations(i);
    
    % Get 3*D point
    point3D = [points3D(obs.pointId, :), 1]';
    
    % Get camera
    camera = cameras(obs.imageId);
    
    % Project point
    P = camera.K * [camera.R, camera.t];
    projected = P * point3D;
    
    if projected(3) > 0
        projectedX = projected(1) / projected(3);
        projectedY = projected(2) / projected(3);
        
        % Compute reprojection error
        errorX = obs.x - projectedX;
        errorY = obs.y - projectedY;
        error = sqrt(errorX^2 + errorY^2);
        
        totalError = totalError + error^2;
    else
        % Point behind camera - large error
        totalError = totalError + 1000^2;
    end
end

rmse = sqrt(totalError / numObservations);
end

function [residuals, jacobian] = computeJacobianAndResiduals(paramVector, observations, paramInfo)
% Compute residuals and Jacobian matrix (simplified numerical differentiation)

 
numObservations = length(observations);
numParams = length(paramVector);

% Compute residuals
residuals = zeros(2 * numObservations, 1);

[cameras, points3D] = unpackParameters(paramVector, paramInfo);

for i = 1:numObservations
    obs = observations(i);
    
    % Get 3*D point
    point3D = [points3D(obs.pointId, :), 1]';
    
    % Get camera
    camera = cameras(obs.imageId);
    
    % Project point
    P = camera.K * [camera.R, camera.t];
    projected = P * point3D;
    
    if projected(3) > 0
        projectedX = projected(1) / projected(3);
        projectedY = projected(2) / projected(3);
        
        % Compute residuals
        residuals(2*i-1) = obs.x - projectedX;
        residuals(2*i) = obs.y - projectedY;
    else
        % Point behind camera
        residuals(2*i-1) = 1000;
        residuals(2*i) = 1000;
    end
end

% Compute Jacobian using numerical differentiation (simplified)
jacobian = zeros(2 * numObservations, numParams);
epsilon = 1e-6;

for j = 1:numParams
    % Perturb parameter
    paramVector_plus = paramVector;
    paramVector_plus(j) = paramVector_plus(j) + epsilon;
    
    % Compute residuals with perturbed parameters
    rmse_plus = computeRMSE(paramVector_plus, observations, paramInfo);
    rmse_minus = computeRMSE(paramVector, observations, paramInfo);
    
    % Numerical derivative (simplified)
    jacobian(:, j) = (rmse_plus - rmse_minus) / epsilon;
end
end
