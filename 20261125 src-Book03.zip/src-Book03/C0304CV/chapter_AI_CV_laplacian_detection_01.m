%% chapter_AI_CV_laplacian_detection_01.m
% Laplacian and Zero-crossing Edge Detection
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_laplacian_detection_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Load test image suitable for second-order analysis
test_image = imread('circuit.tif');
test_image = im2double(test_image);

% Apply Laplacian of Gaussian edge detection with different scales
edges_log_small = edge(test_image, 'log', [], 0.5);   % Small scale
edges_log_medium = edge(test_image, 'log', [], 1.0);  % Medium scale
edges_log_large = edge(test_image, 'log', [], 2.0);   % Large scale

% Manual implementation of LoG for educational purposes

% Apply manual LoG implementation
log_response_05 = applyLoG(test_image, 0.5);
log_response_10 = applyLoG(test_image, 1.0);
log_response_20 = applyLoG(test_image, 2.0);

% Zero-crossing detection function

% Detect zero crossings with different thresholds
zero_crossings_05 = detectZeroCrossings(log_response_05, 0.01);
zero_crossings_10 = detectZeroCrossings(log_response_10, 0.01);
zero_crossings_20 = detectZeroCrossings(log_response_20, 0.01);

% Compare with simple Laplacian (no Gaussian smoothing)
laplacian_kernel = [0 1 0; 1 -4 1; 0 1 0];
simple_laplacian = imfilter(test_image, laplacian_kernel, 'symmetric');
zero_crossings_simple = detectZeroCrossings(simple_laplacian, 0.05);

% Multi-scale edge analysis

% Apply multi-scale LoG analysis
sigmas = [0.5, 1.0, 1.5, 2.0, 2.5];
multiscale_result = multiScaleLoG(test_image, sigmas, 0.008);

% Scale-space analysis

scale_space_representation = buildScaleSpace(test_image, sigmas);

% Edge strength analysis across scales

edge_strengths = analyzeEdgeStrength(test_image, sigmas);

% Display comprehensive results
figure;

% Original and LoG responses
subplot(3,4,1); imshow(test_image); title('Original Image');
subplot(3,4,2); imshow(log_response_05, []); title('LoG Response (考=0.5)');
subplot(3,4,3); imshow(log_response_10, []); title('LoG Response (考=1.0)');
subplot(3,4,4); imshow(log_response_20, []); title('LoG Response (考=2.0)');

% Zero crossings at different scales
subplot(3,4,5); imshow(zero_crossings_05); title('Zero Crossings (考=0.5)');
subplot(3,4,6); imshow(zero_crossings_10); title('Zero Crossings (考=1.0)');
subplot(3,4,7); imshow(zero_crossings_20); title('Zero Crossings (考=2.0)');
subplot(3,4,8); imshow(multiscale_result); title('Multi-scale Edges');

% MATLAB built-in LoG results
subplot(3,4,9); imshow(edges_log_small); title('MATLAB LoG (考=0.5)');
subplot(3,4,10); imshow(edges_log_medium); title('MATLAB LoG (考=1.0)');
subplot(3,4,11); imshow(edges_log_large); title('MATLAB LoG (考=2.0)');

% Scale-space visualization
subplot(3,4,12);
plot(sigmas, edge_strengths, 'b-o', 'LineWidth', 2, 'MarkerSize', 6);
xlabel('Scale (考)');
ylabel('Total Edge Strength');
title('Edge Strength vs Scale');
grid on;

% Kernel visualization for educational purposes
figure;
sigma_demo = 1.0;
kernel_size = 2 * ceil(3 * sigma_demo) + 1;
[x, y] = meshgrid(-(kernel_size-1)/2:(kernel_size-1)/2, ...
                  -(kernel_size-1)/2:(kernel_size-1)/2);
gaussian = exp(-(x.^2 + y.^2) / (2 * sigma_demo^2));
log_kernel = -1/(pi * sigma_demo^4) * (1 - (x.^2 + y.^2)/(2 * sigma_demo^2)) .* gaussian;

subplot(1,3,1); surf(x, y, gaussian); title('Gaussian Component');
xlabel('x'); ylabel('y'); zlabel('Amplitude');
subplot(1,3,2); surf(x, y, log_kernel); title('LoG Kernel');
xlabel('x'); ylabel('y'); zlabel('Amplitude');
subplot(1,3,3); imagesc(log_kernel); title('LoG Kernel (2*D View)');
axis equal tight; colorbar;

fprintf('Laplacian Edge Detection Analysis:\n');
fprintf('Scale 考=0.5: %d edge pixels\n', sum(zero_crossings_05(:)));
fprintf('Scale 考=1.0: %d edge pixels\n', sum(zero_crossings_10(:)));
fprintf('Scale 考=2.0: %d edge pixels\n', sum(zero_crossings_20(:)));
fprintf('Multi-scale result: %d edge pixels\n', sum(multiscale_result(:)));

% Local functions (moved to end so this listing is a valid MATLAB script)
function log_filtered = applyLoG(image, sigma)
    % Create LoG kernel
    kernel_size = 2 * ceil(3 * sigma) + 1;
    [x, y] = meshgrid(-(kernel_size-1)/2:(kernel_size-1)/2, ...
                      -(kernel_size-1)/2:(kernel_size-1)/2);
    
    % LoG formula: -1/(羽考) * (1 - (x+y)/(2考)) * exp(-(x+y)/(2考))
    gaussian = exp(-(x.^2 + y.^2) / (2 * sigma^2));
    log_kernel = -1/(pi * sigma^4) * (1 - (x.^2 + y.^2)/(2 * sigma^2)) .* gaussian;
    
    % Normalise kernel to sum to zero
    log_kernel = log_kernel - mean(log_kernel(:));
    
    % Apply convolution
    log_filtered = imfilter(image, log_kernel, 'symmetric');
end

function zero_crossings = detectZeroCrossings(log_response, threshold)
    [rows, cols] = size(log_response);
    zero_crossings = false(rows, cols);
    
    for i = 2:rows-1
        for j = 2:cols-1
            % Check for zero crossings in 4-connected neighbourhood
            center = log_response(i, j);
            neighbours = [log_response(i-1, j), log_response(i+1, j), ...
                         log_response(i, j-1), log_response(i, j+1)];
            
            % Check if there's a sign change and sufficient magnitude
            if any(sign(center) ~= sign(neighbours)) && abs(center) > threshold
                zero_crossings(i, j) = true;
            end
        end
    end
end

function multiscale_edges = multiScaleLoG(image, sigmas, threshold)
    multiscale_edges = false(size(image));
    responses = zeros([size(image), length(sigmas)]);
    
    for i = 1:length(sigmas)
        % Apply LoG at current scale
        log_response = applyLoG(image, sigmas(i));
        responses(:,:,i) = log_response;
        
        % Detect zero crossings
        zero_crossings = detectZeroCrossings(log_response, threshold);
        multiscale_edges = multiscale_edges | zero_crossings;
    end
end

function scale_space = buildScaleSpace(image, sigmas)
    scale_space = zeros([size(image), length(sigmas)]);
    for i = 1:length(sigmas)
        smoothed = imgaussfilt(image, sigmas(i));
        scale_space(:,:,i) = smoothed;
    end
end

function strength_analysis = analyzeEdgeStrength(image, sigmas)
    strength_analysis = zeros(size(sigmas));
    for i = 1:length(sigmas)
        log_response = applyLoG(image, sigmas(i));
        zero_crossings = detectZeroCrossings(log_response, 0.01);
        strength_analysis(i) = sum(abs(log_response(zero_crossings)));
    end
end
