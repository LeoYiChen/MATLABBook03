%% chapter_AI_CV_explainable_ai_01.m
% Comprehensive Explainable AI Framework for Computer Vision Systems
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_explainable_ai_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Comprehensive Explainable AI Framework for Computer Vision
fprintf('Explainable AI Framework for Computer Vision\n');
fprintf('===========================================\n');

% Create explainable AI framework
explainableFramework = createExplainableAIFramework();


% 1. Gradient-based Attribution Methods











% 2. Perturbation-based Explanation Methods










% 3. Attention-based Explanations


% 4. Counterfactual Explanations

% 5. Explanation Visualization and Evaluation




% 6. Explanation Quality Evaluation





% Test the explainable AI framework
fprintf('\nTesting explainable AI framework...\n');

% Create test image and model
testImage = imread('peppers.png');
if size(testImage, 3) == 3
    testImage = rgb2gray(testImage);
end
testImage = imresize(testImage, [128, 128]);

% Create simple model structure
simpleModel = struct();
simpleModel.type = 'cnn';
simpleModel.layers = {'conv1', 'conv2', 'conv3', 'fc'};

targetClass = 1;

% Generate explanations using different methods
fprintf('\nGenerating explanations using various methods...\n');

integratedGradExplanation = gradientBasedAttribution(simpleModel, testImage, targetClass, 'integrated_gradients');
gradCAMExplanation = gradientBasedAttribution(simpleModel, testImage, targetClass, 'gradcam');
limeExplanation = perturbationBasedExplanation(simpleModel, testImage, targetClass, 'lime');
occlusionExplanation = perturbationBasedExplanation(simpleModel, testImage, targetClass, 'occlusion');

% Extract attention maps
attentionMaps = extractAttentionMaps(simpleModel, testImage);

% Generate counterfactual explanations
counterfactuals = generateCounterfactualExplanations(simpleModel, testImage, targetClass, 2);

% Visualize explanations
visualizeExplanations(testImage, integratedGradExplanation, 'Integrated Gradients', targetClass);
visualizeExplanations(testImage, gradCAMExplanation, 'Grad-CAM', targetClass);
visualizeExplanations(testImage, limeExplanation, 'LIME', targetClass);
visualizeExplanations(testImage, occlusionExplanation, 'Occlusion Analysis', targetClass);

% Evaluate explanation quality
integratedGradEval = evaluateExplanationQuality(integratedGradExplanation);
gradCAMEval = evaluateExplanationQuality(gradCAMExplanation);
limeEval = evaluateExplanationQuality(limeExplanation);
occlusionEval = evaluateExplanationQuality(occlusionExplanation);

% Visualize counterfactual explanations
figure;
subplot(1, 4, 1);
imshow(counterfactuals.original);
title('Original Image');

subplot(1, 4, 2);
imshow(counterfactuals.counterfactual);
title('Counterfactual');

subplot(1, 4, 3);
imshow(counterfactuals.difference, []);
colormap(gca, hot);
colorbar;
title('Difference Map');

subplot(1, 4, 4);
text(0.1, 0.5, sprintf(['Target Class: %d\n' ...
                       'Desired Class: %d\n' ...
                       'Iterations: %d'], ...
                      counterfactuals.targetClass, ...
                      counterfactuals.desiredClass, ...
                      counterfactuals.iterations), ...
     'FontSize', 12, 'VerticalAlignment', 'middle');
axis off;
title('Counterfactual Info');

sgtitle('Counterfactual Explanations');

% Compare explanation methods
figure;
methods = {'Integrated Gradients', 'Grad-CAM', 'LIME', 'Occlusion'};
explanationMaps = {integratedGradExplanation, gradCAMExplanation, limeExplanation, occlusionExplanation};
evaluations = {integratedGradEval, gradCAMEval, limeEval, occlusionEval};

for i = 1:4
    subplot(2, 4, i);
    imshow(explanationMaps{i}, []);
    colormap(gca, hot);
    title(methods{i});
    
    subplot(2, 4, i + 4);
    eval = evaluations{i};
    metrics = [eval.correlation, eval.fidelity, eval.auc, 1 - eval.mse];
    bar(metrics);
    set(gca, 'XTickLabel', {'Correlation', 'Fidelity', 'AUC', '1-MSE'});
    xtickangle(45);
    title(sprintf('%s Metrics', methods{i}));
    ylim([0, 1]);
end

sgtitle('Explainable AI Methods Comparison');

% Display comprehensive explainable AI summary
fprintf('\n' + string(repmat('=', 1, 70)) + '\n');
fprintf('EXPLAINABLE AI FRAMEWORK SUMMARY\n');
fprintf(string(repmat('=', 1, 70)) + '\n');

fprintf('\nFRAMEWORK CONFIGURATION:\n');
fprintf('  Available methods: %s\n', strjoin(explainableFramework.methods, ', '));
fprintf('  Visualization modes: %s\n', strjoin(explainableFramework.visualisationModes, ', '));
fprintf('  Target audiences: %s\n', strjoin(explainableFramework.targetAudiences, ', '));

fprintf('\nEXPLANATION METHODS TESTED:\n');
fprintf('  Integrated Gradients: Gradient-based attribution\n');
fprintf('  Grad-CAM: Class activation mapping\n');
fprintf('  LIME: Local interpretable model-agnostic explanations\n');
fprintf('  Occlusion Analysis: Perturbation-based sensitivity\n');
fprintf('  Counterfactuals: What-if analysis\n');

fprintf('\nEVALUATION METRICS:\n');
methods = {'Integrated Gradients', 'Grad-CAM', 'LIME', 'Occlusion'};
evaluations = {integratedGradEval, gradCAMEval, limeEval, occlusionEval};

for i = 1:length(methods)
    eval = evaluations{i};
    fprintf('  %s:\n', methods{i});
    fprintf('    Correlation: %.3f\n', eval.correlation);
    fprintf('    MSE: %.3f\n', eval.mse);
    fprintf('    AUC: %.3f\n', eval.auc);
    fprintf('    Fidelity: %.3f\n', eval.fidelity);
end

fprintf('\nCOUNTERFACTUAL ANALYSIS:\n');
fprintf('  Original class: %d\n', counterfactuals.targetClass);
fprintf('  Target class: %d\n', counterfactuals.desiredClass);
fprintf('  Convergence iterations: %d\n', counterfactuals.iterations);
fprintf('  Mean pixel change: %.2f\n', mean(counterfactuals.difference(:)));
fprintf('  Max pixel change: %.2f\n', max(counterfactuals.difference(:)));

fprintf('\nEXPLAINABLE AI BENEFITS:\n');
fprintf('========================\n');
fprintf(' Increased trust and adoption in critical applications\n');
fprintf(' Better understanding of model behaviour and limitations\n');
fprintf(' Improved debugging and model development\n');
fprintf(' Regulatory compliance and audit trails\n');
fprintf(' Educational value for domain experts\n');
fprintf(' Detection of model biases and unfairness\n');
fprintf(' Enhanced human-AI collaboration\n');

fprintf('\nEXPLANATION METHOD COMPARISON:\n');
fprintf('=============================\n');
fprintf(' Gradient-based methods: Fast, model-specific, gradient quality dependent\n');
fprintf(' Perturbation-based methods: Model-agnostic, slower, more robust\n');
fprintf(' Attention mechanisms: Built-in explanations, architecture dependent\n');
fprintf(' Counterfactuals: Intuitive what-if scenarios, computationally expensive\n');

fprintf('\nAPPLICATION DOMAINS:\n');
fprintf('===================\n');
fprintf(' Medical diagnosis: Highlighting diagnostic features\n');
fprintf(' Autonomous systems: Understanding decision rationale\n');
fprintf(' Security applications: Identifying threat indicators\n');
fprintf(' Financial services: Credit decision explanations\n');
fprintf(' Legal applications: Evidence analysis\n');
fprintf(' Quality control: Defect identification reasoning\n');

fprintf('\nCHALLENGES AND LIMITATIONS:\n');
fprintf('==========================\n');
fprintf(' Explanation faithfulness vs interpretability trade-off\n');
fprintf(' Computational overhead for complex explanations\n');
fprintf(' Lack of standardized evaluation metrics\n');
fprintf(' User study validation requirements\n');
fprintf(' Explanation stability across similar inputs\n');
fprintf(' Adversarial attacks on explanation methods\n');

fprintf('\nFUTURE DIRECTIONS:\n');
fprintf('==================\n');
fprintf(' Interactive explanation interfaces\n');
fprintf(' Multi-modal explanation generation\n');
fprintf(' Causal reasoning in explanations\n');
fprintf(' Personalized explanation strategies\n');
fprintf(' Explanation quality assessment automation\n');
fprintf(' Integration with uncertainty quantification\n');

fprintf('\nBEST PRACTICES:\n');
fprintf('===============\n');
fprintf(' Choose explanation methods appropriate for application\n');
fprintf(' Validate explanations with domain experts\n');
fprintf(' Consider multiple explanation perspectives\n');
fprintf(' Evaluate explanation quality quantitatively\n');
fprintf(' Design explanations for target audience\n');
fprintf(' Maintain explanation consistency and stability\n');
fprintf(' Document explanation methodology and limitations\n');

fprintf('\n' + string(repmat('=', 1, 70)) + '\n');

% Local functions (moved to end so this listing is a valid MATLAB script)
function framework = createExplainableAIFramework()
    % Create framework for explainable AI in computer vision
    
    fprintf('Creating explainable AI framework...\n');
    
    framework = struct();
    framework.name = 'MATLAB Explainable Computer Vision';
    framework.methods = {'gradcam', 'lime', 'shap', 'integrated_gradients', 'occlusion'};
    framework.visualisationModes = {'heatmap', 'overlay', 'segmentation', 'text'};
    framework.targetAudiences = {'developer', 'domain_expert', 'end_user', 'regulator'};
    
    % Framework parameters
    framework.params = struct();
    framework.params.gradcam_layer = 'final_conv'; % Target layer for GradCAM
    framework.params.lime_num_samples = 1000; % Number of samples for LIME
    framework.params.occlusion_window_size = 16; % Window size for occlusion analysis
    framework.params.explanation_threshold = 0.1; % Minimum relevance threshold
    
    fprintf('Explainable AI framework initialized\n');
end

function attributions = gradientBasedAttribution(model, inputImage, targetClass, method)
    % Compute gradient-based attributions for model predictions
    
    if nargin < 4
        method = 'integrated_gradients';
    end
    
    fprintf('Computing gradient-based attributions using %s...\n', method);
    
    switch method
        case 'integrated_gradients'
            attributions = integratedGradients(model, inputImage, targetClass);
            
        case 'gradcam'
            attributions = gradCAM(model, inputImage, targetClass);
            
        case 'guided_backprop'
            attributions = guidedBackpropagation(model, inputImage, targetClass);
            
        case 'vanilla_gradients'
            attributions = vanillaGradients(model, inputImage, targetClass);
            
        otherwise
            error('Unknown gradient-based method: %s', method);
    end
    
    fprintf('Gradient-based attribution completed\n');
end

function attributions = integratedGradients(model, inputImage, targetClass)
    % Compute Integrated Gradients attributions
    
    % Parameters
    numSteps = 50;
    baseline = zeros(size(inputImage)); % Black baseline
    
    % Prepare input
    normalizedImage = double(inputImage) / 255;
    
    % Generate interpolated images
    interpolatedImages = generateInterpolatedImages(baseline, normalizedImage, numSteps);
    
    % Compute gradients for each interpolated image
    gradients = zeros([size(normalizedImage), numSteps]);
    
    for step = 1:numSteps
        % Compute gradient for interpolated image
        grad = computeImageGradient(model, interpolatedImages(:, :, :, step), targetClass);
        gradients(:, :, :, step) = grad;
    end
    
    % Integrate gradients along path
    avgGradients = mean(gradients, 4);
    
    % Multiply by input difference
    inputDiff = normalizedImage - baseline;
    attributions = inputDiff .* avgGradients;
    
    % Sum across channels if RGB
    if size(attributions, 3) > 1
        attributions = sum(abs(attributions), 3);
    end
end

function interpolatedImages = generateInterpolatedImages(baseline, inputImage, numSteps)
    % Generate interpolated images between baseline and input
    
    [height, width, channels] = size(inputImage);
    interpolatedImages = zeros(height, width, channels, numSteps);
    
    for step = 1:numSteps
        alpha = (step - 1) / (numSteps - 1);
        interpolatedImages(:, :, :, step) = baseline + alpha * (inputImage - baseline);
    end
end

function gradient = computeImageGradient(model, image, targetClass)
    % Compute gradient of model output with respect to input image
    
    % This is a simplified gradient computation
    % In practice, would use automatic differentiation
    
    epsilon = 1e-3;
    [height, width, channels] = size(image);
    gradient = zeros(size(image));
    
    % Numerical gradient computation (simplified)
    for c = 1:channels
        for i = 1:height
            for j = 1:width
                % Forward difference
                imagePlus = image;
                imagePlus(i, j, c) = imagePlus(i, j, c) + epsilon;
                
                imageMinus = image;
                imageMinus(i, j, c) = imageMinus(i, j, c) - epsilon;
                
                % Compute predictions
                predPlus = simulateModelPrediction(model, imagePlus, targetClass);
                predMinus = simulateModelPrediction(model, imageMinus, targetClass);
                
                % Compute gradient
                gradient(i, j, c) = (predPlus - predMinus) / (2 * epsilon);
            end
        end
    end
end

function prediction = simulateModelPrediction(model, image, targetClass)
    % Simulate model prediction (simplified)
    
    % Extract simple features
    grayImage = rgb2gray(image);
    
    % Compute basic statistics
    meanIntensity = mean(grayImage(:));
    stdIntensity = std(grayImage(:));
    
    % Compute edges
    edges = edge(grayImage, 'canny');
    edgeDensity = sum(edges(:)) / numel(edges);
    
    % Simple linear combination (simulated classifier)
    weights = [0.3, 0.4, 0.3]; % Weights for features
    features = [meanIntensity, stdIntensity * 10, edgeDensity * 100];
    
    prediction = sum(weights .* features) + randn() * 0.01; % Add small noise
end

function attributions = gradCAM(model, inputImage, targetClass)
    % Compute Grad-CAM attributions
    
    % Simulate feature extraction from final convolutional layer
    featureMaps = extractFeatureMaps(inputImage);
    
    % Compute gradients of target class with respect to feature maps
    gradients = computeFeatureGradients(model, featureMaps, targetClass);
    
    % Global average pooling of gradients
    weights = squeeze(mean(mean(gradients, 1), 2));
    
    % Weighted combination of feature maps
    [height, width, numMaps] = size(featureMaps);
    gradcamMap = zeros(height, width);
    
    for i = 1:numMaps
        gradcamMap = gradcamMap + weights(i) * featureMaps(:, :, i);
    end
    
    % Apply ReLU
    gradcamMap = max(gradcamMap, 0);
    
    % Resize to input image size
    attributions = imresize(gradcamMap, [size(inputImage, 1), size(inputImage, 2)]);
    
    % Normalize
    attributions = (attributions - min(attributions(:))) / (max(attributions(:)) - min(attributions(:)) + eps);
end

function featureMaps = extractFeatureMaps(inputImage)
    % Extract feature maps from convolutional layers (simplified)
    
    grayImage = rgb2gray(inputImage);
    
    % Create multiple feature maps using different filters
    filters = {
        [-1, 0, 1; -2, 0, 2; -1, 0, 1], % Vertical edges
        [-1, -2, -1; 0, 0, 0; 1, 2, 1], % Horizontal edges
        [0, -1, 0; -1, 5, -1; 0, -1, 0], % Sharpening
        ones(3, 3) / 9, % Smoothing
        [1, 0, -1; 0, 0, 0; -1, 0, 1] % Diagonal edges
    };
    
    numFilters = length(filters);
    [height, width] = size(grayImage);
    featureMaps = zeros(height, width, numFilters);
    
    for i = 1:numFilters
        filtered = imfilter(double(grayImage), filters{i}, 'same');
        featureMaps(:, :, i) = filtered;
    end
end

function gradients = computeFeatureGradients(model, featureMaps, targetClass)
    % Compute gradients of target class with respect to feature maps
    
    [height, width, numMaps] = size(featureMaps);
    gradients = zeros(size(featureMaps));
    
    epsilon = 1e-3;
    
    for i = 1:numMaps
        for y = 1:height
            for x = 1:width
                % Perturb feature map
                featureMapsPlus = featureMaps;
                featureMapsPlus(y, x, i) = featureMapsPlus(y, x, i) + epsilon;
                
                featureMapsMinus = featureMaps;
                featureMapsMinus(y, x, i) = featureMapsMinus(y, x, i) - epsilon;
                
                % Compute predictions
                predPlus = simulateFeaturePrediction(model, featureMapsPlus, targetClass);
                predMinus = simulateFeaturePrediction(model, featureMapsMinus, targetClass);
                
                % Compute gradient
                gradients(y, x, i) = (predPlus - predMinus) / (2 * epsilon);
            end
        end
    end
end

function prediction = simulateFeaturePrediction(model, featureMaps, targetClass)
    % Simulate prediction from feature maps
    
    % Global average pooling
    pooledFeatures = squeeze(mean(mean(featureMaps, 1), 2));
    
    % Simple linear classifier
    weights = randn(length(pooledFeatures), 1) * 0.1;
    prediction = sum(pooledFeatures .* weights);
end

function attributions = guidedBackpropagation(model, inputImage, targetClass)
    % Compute Guided Backpropagation attributions
    
    % Compute vanilla gradients
    gradients = computeImageGradient(model, double(inputImage) / 255, targetClass);
    
    % Apply guided backpropagation rule (keep only positive gradients)
    attributions = max(gradients, 0);
    
    % Sum across channels if RGB
    if size(attributions, 3) > 1
        attributions = sum(attributions, 3);
    end
end

function attributions = vanillaGradients(model, inputImage, targetClass)
    % Compute vanilla gradients
    
    attributions = computeImageGradient(model, double(inputImage) / 255, targetClass);
    
    % Sum across channels if RGB
    if size(attributions, 3) > 1
        attributions = sum(abs(attributions), 3);
    end
end

function explanations = perturbationBasedExplanation(model, inputImage, targetClass, method)
    % Generate perturbation-based explanations
    
    if nargin < 4
        method = 'lime';
    end
    
    fprintf('Generating perturbation-based explanations using %s...\n', method);
    
    switch method
        case 'lime'
            explanations = limeExplanation(model, inputImage, targetClass);
            
        case 'shap'
            explanations = shapExplanation(model, inputImage, targetClass);
            
        case 'occlusion'
            explanations = occlusionAnalysis(model, inputImage, targetClass);
            
        case 'meaningful_perturbations'
            explanations = meaningfulPerturbations(model, inputImage, targetClass);
            
        otherwise
            error('Unknown perturbation method: %s', method);
    end
    
    fprintf('Perturbation-based explanation completed\n');
end

function explanations = limeExplanation(model, inputImage, targetClass)
    % Generate LIME (Local Interpretable Model-agnostic Explanations)
    
    numSamples = 1000;
    segmentSize = 16; % Size of superpixels
    
    % Create superpixel segmentation
    segments = createSuperpixelSegmentation(inputImage, segmentSize);
    numSegments = max(segments(:));
    
    % Generate perturbed samples
    [perturbedSamples, features] = generateLIMESamples(inputImage, segments, numSamples);
    
    % Get model predictions for perturbed samples
    predictions = zeros(numSamples, 1);
    for i = 1:numSamples
        predictions(i) = simulateModelPrediction(model, perturbedSamples(:, :, :, i), targetClass);
    end
    
    % Fit linear model
    weights = computeLIMEWeights(features, predictions);
    
    % Create explanation map
    explanations = zeros(size(inputImage, 1), size(inputImage, 2));
    for seg = 1:numSegments
        segmentMask = segments == seg;
        explanations(segmentMask) = weights(seg);
    end
end

function segments = createSuperpixelSegmentation(image, segmentSize)
    % Create superpixel segmentation (simplified)
    
    [height, width, ~] = size(image);
    segments = zeros(height, width);
    
    segmentId = 1;
    for y = 1:segmentSize:height
        for x = 1:segmentSize:width
            yEnd = min(y + segmentSize - 1, height);
            xEnd = min(x + segmentSize - 1, width);
            
            segments(y:yEnd, x:xEnd) = segmentId;
            segmentId = segmentId + 1;
        end
    end
end

function [perturbedSamples, features] = generateLIMESamples(inputImage, segments, numSamples)
    % Generate perturbed samples for LIME
    
    numSegments = max(segments(:));
    [height, width, channels] = size(inputImage);
    
    perturbedSamples = zeros(height, width, channels, numSamples);
    features = zeros(numSamples, numSegments);
    
    for sample = 1:numSamples
        % Random binary mask for segments
        segmentMask = rand(numSegments, 1) > 0.5;
        features(sample, :) = segmentMask;
        
        % Create perturbed image
        perturbedImage = inputImage;
        for seg = 1:numSegments
            if ~segmentMask(seg)
                % Replace segment with noise or mean color
                segmentPixels = segments == seg;
                if channels == 1
                    perturbedImage(segmentPixels) = mean(inputImage(:));
                else
                    for c = 1:channels
                        channelData = perturbedImage(:, :, c);
                        channelData(segmentPixels) = mean(inputImage(:, :, c), 'all');
                        perturbedImage(:, :, c) = channelData;
                    end
                end
            end
        end
        
        perturbedSamples(:, :, :, sample) = perturbedImage;
    end
end

function weights = computeLIMEWeights(features, predictions)
    % Compute LIME weights using linear regression
    
    % Add regularization to prevent overfitting
    lambda = 0.01;
    
    % Ridge regression
    X = features;
    y = predictions;
    
    % Add bias term
    X = [ones(size(X, 1), 1), X];
    
    % Solve ridge regression
    weights_full = (X' * X + lambda * eye(size(X, 2))) \ (X' * y);
    
    % Remove bias term
    weights = weights_full(2:end);
end

function explanations = shapExplanation(model, inputImage, targetClass)
    % Generate SHAP (SHapley Additive exPlanations)
    
    numSamples = 500;
    
    % Create feature representation (superpixels)
    segments = createSuperpixelSegmentation(inputImage, 16);
    numFeatures = max(segments(:));
    
    % Compute SHAP values
    shapValues = zeros(numFeatures, 1);
    
    for feature = 1:numFeatures
        shapValues(feature) = computeShapleyValue(model, inputImage, segments, feature, targetClass, numSamples);
    end
    
    % Create explanation map
    explanations = zeros(size(inputImage, 1), size(inputImage, 2));
    for feature = 1:numFeatures
        featureMask = segments == feature;
        explanations(featureMask) = shapValues(feature);
    end
end

function shapValue = computeShapleyValue(model, inputImage, segments, targetFeature, targetClass, numSamples)
    % Compute Shapley value for a specific feature
    
    numFeatures = max(segments(:));
    otherFeatures = setdiff(1:numFeatures, targetFeature);
    
    marginalContributions = [];
    
    for sample = 1:numSamples
        % Random subset of other features
        subsetSize = randi([0, length(otherFeatures)]);
        if subsetSize > 0
            subset = otherFeatures(randperm(length(otherFeatures), subsetSize));
        else
            subset = [];
        end
        
        % Compute marginal contribution
        valueWithFeature = evaluateFeatureSubset(model, inputImage, segments, [subset, targetFeature], targetClass);
        valueWithoutFeature = evaluateFeatureSubset(model, inputImage, segments, subset, targetClass);
        
        marginalContribution = valueWithFeature - valueWithoutFeature;
        marginalContributions = [marginalContributions; marginalContribution];
    end
    
    shapValue = mean(marginalContributions);
end

function value = evaluateFeatureSubset(model, inputImage, segments, activeFeatures, targetClass)
    % Evaluate model with only specified features active
    
    % Create masked image
    maskedImage = zeros(size(inputImage));
    
    for feature = activeFeatures
        featureMask = segments == feature;
        
        if size(inputImage, 3) == 1
            maskedImage(featureMask) = inputImage(featureMask);
        else
            for c = 1:size(inputImage, 3)
                channelData = maskedImage(:, :, c);
                channelData(featureMask) = inputImage(featureMask + (c-1)*numel(segments));
                maskedImage(:, :, c) = channelData;
            end
        end
    end
    
    % Evaluate model
    value = simulateModelPrediction(model, maskedImage, targetClass);
end

function explanations = occlusionAnalysis(model, inputImage, targetClass)
    % Perform occlusion-based sensitivity analysis
    
    windowSize = 16;
    stride = 8;
    
    [height, width, channels] = size(inputImage);
    
    % Get baseline prediction
    baselinePrediction = simulateModelPrediction(model, inputImage, targetClass);
    
    % Create explanation map
    explanations = zeros(height, width);
    
    % Slide occlusion window
    for y = 1:stride:(height - windowSize + 1)
        for x = 1:stride:(width - windowSize + 1)
            % Create occluded image
            occludedImage = inputImage;
            occludedImage(y:(y+windowSize-1), x:(x+windowSize-1), :) = 0;
            
            % Get prediction for occluded image
            occludedPrediction = simulateModelPrediction(model, occludedImage, targetClass);
            
            % Compute sensitivity
            sensitivity = baselinePrediction - occludedPrediction;
            
            % Assign sensitivity to window region
            explanations(y:(y+windowSize-1), x:(x+windowSize-1)) = sensitivity;
        end
    end
end

function explanations = meaningfulPerturbations(model, inputImage, targetClass)
    % Find meaningful perturbations that change predictions
    
    numIterations = 100;
    learningRate = 0.1;
    
    % Initialize perturbation mask
    [height, width, channels] = size(inputImage);
    mask = 0.5 * ones(height, width);
    
    % Get baseline prediction
    baselinePrediction = simulateModelPrediction(model, inputImage, targetClass);
    
    for iteration = 1:numIterations
        % Apply mask to image
        perturbedImage = inputImage;
        for c = 1:channels
            perturbedImage(:, :, c) = perturbedImage(:, :, c) .* mask;
        end
        
        % Get prediction
        perturbedPrediction = simulateModelPrediction(model, perturbedImage, targetClass);
        
        % Compute loss (difference from baseline)
        loss = abs(perturbedPrediction - baselinePrediction);
        
        % Compute gradient of loss with respect to mask
        epsilon = 1e-3;
        gradient = zeros(size(mask));
        
        for i = 1:min(10, height) % Limit computation for demo
            for j = 1:min(10, width)
                maskPlus = mask;
                maskPlus(i, j) = maskPlus(i, j) + epsilon;
                
                maskMinus = mask;
                maskMinus(i, j) = maskMinus(i, j) - epsilon;
                
                % Apply perturbed masks
                imagePlus = inputImage;
                imageMinus = inputImage;
                for c = 1:channels
                    imagePlus(:, :, c) = imagePlus(:, :, c) .* maskPlus;
                    imageMinus(:, :, c) = imageMinus(:, :, c) .* maskMinus;
                end
                
                predPlus = simulateModelPrediction(model, imagePlus, targetClass);
                predMinus = simulateModelPrediction(model, imageMinus, targetClass);
                
                lossPlus = abs(predPlus - baselinePrediction);
                lossMinus = abs(predMinus - baselinePrediction);
                
                gradient(i, j) = (lossPlus - lossMinus) / (2 * epsilon);
            end
        end
        
        % Update mask
        mask = mask + learningRate * gradient;
        mask = max(0, min(1, mask)); % Clamp to [0, 1]
    end
    
    explanations = 1 - mask; % Invert for explanation (higher values = more important)
end

function attentionMaps = extractAttentionMaps(model, inputImage, layers)
    % Extract attention maps from model layers
    
    if nargin < 3
        layers = {'conv1', 'conv2', 'conv3'};
    end
    
    fprintf('Extracting attention maps from model layers...\n');
    
    attentionMaps = cell(length(layers), 1);
    
    for i = 1:length(layers)
        layer = layers{i};
        attentionMaps{i} = extractLayerAttention(model, inputImage, layer);
    end
    
    fprintf('Attention map extraction completed\n');
end

function attentionMap = extractLayerAttention(model, inputImage, layerName)
    % Extract attention map from specific layer
    
    % Simulate attention extraction from convolutional layer
    featureMaps = extractFeatureMaps(inputImage);
    
    % Compute attention weights based on feature activation strength
    [height, width, numMaps] = size(featureMaps);
    attention = zeros(height, width);
    
    for i = 1:numMaps
        % Normalize feature map
        normalizedMap = (featureMaps(:, :, i) - min(featureMaps(:, :, i), [], 'all')) / ...
                       (max(featureMaps(:, :, i), [], 'all') - min(featureMaps(:, :, i), [], 'all') + eps);
        
        % Weight by activation strength
        attention = attention + normalizedMap .* mean(normalizedMap, 'all');
    end
    
    % Normalize attention map
    attentionMap = (attention - min(attention(:))) / (max(attention(:)) - min(attention(:)) + eps);
    
    % Resize to input image size
    attentionMap = imresize(attentionMap, [size(inputImage, 1), size(inputImage, 2)]);
end

function counterfactuals = generateCounterfactualExplanations(model, inputImage, targetClass, desiredClass)
    % Generate counterfactual explanations
    
    fprintf('Generating counterfactual explanations...\n');
    
    if nargin < 4
        % Find a different class
        desiredClass = mod(targetClass, 10) + 1;
    end
    
    % Initialize counterfactual as copy of original
    counterfactual = double(inputImage);
    
    % Optimization parameters
    numIterations = 100;
    learningRate = 0.01;
    
    for iteration = 1:numIterations
        % Get current prediction
        currentPrediction = simulateModelPrediction(model, counterfactual, targetClass);
        desiredPrediction = simulateModelPrediction(model, counterfactual, desiredClass);
        
        % Compute loss (want to minimize target class, maximize desired class)
        loss = currentPrediction - desiredPrediction;
        
        % Compute gradient
        gradient = computeImageGradient(model, counterfactual / 255, targetClass) - ...
                  computeImageGradient(model, counterfactual / 255, desiredClass);
        
        % Update image
        counterfactual = counterfactual - learningRate * gradient * 255;
        
        % Clamp to valid range
        counterfactual = max(0, min(255, counterfactual));
        
        % Check convergence
        if abs(loss) < 0.1
            break;
        end
    end
    
    counterfactuals = struct();
    counterfactuals.original = inputImage;
    counterfactuals.counterfactual = uint8(counterfactual);
    counterfactuals.difference = abs(double(inputImage) - counterfactual);
    counterfactuals.targetClass = targetClass;
    counterfactuals.desiredClass = desiredClass;
    counterfactuals.iterations = iteration;
    
    fprintf('Counterfactual generation completed in %d iterations\n', iteration);
end

function visualizeExplanations(inputImage, explanations, method, targetClass)
    % Visualize explanations in various formats
    
    fprintf('Visualizing explanations for %s method...\n', method);
    
    figure;
    
    % Original image
    subplot(2, 3, 1);
    if size(inputImage, 3) == 1
        imshow(inputImage, []);
    else
        imshow(inputImage);
    end
    title('Original Image');
    
    % Explanation heatmap
    subplot(2, 3, 2);
    imshow(explanations, []);
    colormap(gca, hot);
    colorbar;
    title(sprintf('%s Explanation', method));
    
    % Overlay explanation on image
    subplot(2, 3, 3);
    overlayExplanation(inputImage, explanations);
    title('Explanation Overlay');
    
    % Thresholded explanation
    subplot(2, 3, 4);
    threshold = prctile(explanations(:), 80); % Top 20% of explanations
    thresholdedExplanation = explanations > threshold;
    imshow(thresholdedExplanation);
    title('Top 20% Important Regions');
    
    % Explanation histogram
    subplot(2, 3, 5);
    histogram(explanations(:), 50);
    xlabel('Explanation Value');
    ylabel('Frequency');
    title('Explanation Distribution');
    
    % Statistics
    subplot(2, 3, 6);
    stats = computeExplanationStatistics(explanations);
    statsText = sprintf(['Mean: %.3f\n' ...
                        'Std: %.3f\n' ...
                        'Max: %.3f\n' ...
                        'Min: %.3f\n' ...
                        'Sparsity: %.2f%%'], ...
                       stats.mean, stats.std, stats.max, stats.min, stats.sparsity);
    text(0.1, 0.5, statsText, 'FontSize', 12, 'VerticalAlignment', 'middle');
    axis off;
    title('Explanation Statistics');
    
    sgtitle(sprintf('Explainable AI Analysis - %s (Class: %d)', method, targetClass));
end

function overlayExplanation(inputImage, explanations)
    % Overlay explanation heatmap on original image
    
    % Normalize explanation
    normalizedExplanation = (explanations - min(explanations(:))) / ...
                           (max(explanations(:)) - min(explanations(:)) + eps);
    
    % Create color map
    explanationColormap = hot(256);
    explanationColored = ind2rgb(uint8(normalizedExplanation * 255), explanationColormap);
    
    % Convert input image to RGB if grayscale
    if size(inputImage, 3) == 1
        displayImage = repmat(inputImage, [1, 1, 3]);
    else
        displayImage = inputImage;
    end
    
    % Alpha blending
    alpha = 0.4;
    overlayImage = (1 - alpha) * double(displayImage) / 255 + alpha * explanationColored;
    
    imshow(overlayImage);
end

function stats = computeExplanationStatistics(explanations)
    % Compute statistics for explanation quality
    
    stats = struct();
    
    explanationVector = explanations(:);
    
    stats.mean = mean(explanationVector);
    stats.std = std(explanationVector);
    stats.max = max(explanationVector);
    stats.min = min(explanationVector);
    
    % Sparsity (percentage of near-zero values)
    threshold = 0.01 * max(explanationVector);
    stats.sparsity = sum(explanationVector < threshold) / length(explanationVector) * 100;
    
    % Concentration (how focused the explanation is)
    normalizedExplanation = explanationVector / sum(explanationVector);
    stats.entropy = -sum(normalizedExplanation .* log(normalizedExplanation + eps));
    stats.gini = computeGiniCoefficient(explanationVector);
end

function gini = computeGiniCoefficient(values)
    % Compute Gini coefficient for explanation concentration
    
    sortedValues = sort(values);
    n = length(sortedValues);
    
    gini = (2 * sum((1:n) .* sortedValues)) / (n * sum(sortedValues)) - (n + 1) / n;
end

function evaluation = evaluateExplanationQuality(explanations, groundTruthMask)
    % Evaluate explanation quality against ground truth
    
    fprintf('Evaluating explanation quality...\n');
    
    evaluation = struct();
    
    if nargin < 2 || isempty(groundTruthMask)
        % Generate synthetic ground truth for demonstration
        groundTruthMask = createSyntheticGroundTruth(size(explanations));
    end
    
    % Normalize explanations and ground truth
    normalizedExplanations = (explanations - min(explanations(:))) / ...
                            (max(explanations(:)) - min(explanations(:)) + eps);
    normalizedGroundTruth = double(groundTruthMask) / max(groundTruthMask(:));
    
    % Compute evaluation metrics
    evaluation.correlation = corr(normalizedExplanations(:), normalizedGroundTruth(:));
    evaluation.mse = mean((normalizedExplanations(:) - normalizedGroundTruth(:)).^2);
    evaluation.mae = mean(abs(normalizedExplanations(:) - normalizedGroundTruth(:)));
    
    % Intersection over Union for top-k regions
    topK = 0.2; % Top 20% of regions
    evaluation.iou = computeTopKIoU(normalizedExplanations, normalizedGroundTruth, topK);
    
    % Area Under ROC Curve
    evaluation.auc = computeAUC(normalizedExplanations, normalizedGroundTruth);
    
    % Fidelity metrics
    evaluation.fidelity = computeFidelity(explanations);
    
    fprintf('Explanation quality evaluation completed\n');
end

function groundTruth = createSyntheticGroundTruth(imageSize)
    % Create synthetic ground truth explanation mask
    
    groundTruth = zeros(imageSize);
    
    % Create circular region of importance
    centerY = imageSize(1) / 2;
    centerX = imageSize(2) / 2;
    radius = min(imageSize) / 4;
    
    [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
    circle = (X - centerX).^2 + (Y - centerY).^2 <= radius^2;
    
    groundTruth(circle) = 1;
end

function iou = computeTopKIoU(explanations, groundTruth, k)
    % Compute IoU for top-k explanation regions
    
    % Get top-k% of explanation regions
    threshold = prctile(explanations(:), (1 - k) * 100);
    explanationMask = explanations >= threshold;
    
    % Get top-k% of ground truth regions
    gtThreshold = prctile(groundTruth(:), (1 - k) * 100);
    gtMask = groundTruth >= gtThreshold;
    
    % Compute IoU
    intersection = sum(explanationMask(:) & gtMask(:));
    union = sum(explanationMask(:) | gtMask(:));
    
    iou = intersection / (union + eps);
end

function auc = computeAUC(explanations, groundTruth)
    % Compute Area Under ROC Curve
    
    % Flatten arrays
    expFlat = explanations(:);
    gtFlat = groundTruth(:) > 0.5; % Convert to binary
    
    % Sort by explanation values
    [~, sortIdx] = sort(expFlat, 'descend');
    sortedGT = gtFlat(sortIdx);
    
    % Compute ROC curve
    numPositives = sum(gtFlat);
    numNegatives = length(gtFlat) - numPositives;
    
    if numPositives == 0 || numNegatives == 0
        auc = 0.5;
        return;
    end
    
    tpr = cumsum(sortedGT) / numPositives;
    fpr = cumsum(~sortedGT) / numNegatives;
    
    % Compute AUC using trapezoidal rule
    auc = trapz(fpr, tpr);
end

function fidelity = computeFidelity(explanations)
    % Compute explanation fidelity (simplified)
    
    % Measure how well explanation preserves important information
    % This is a simplified metric - real fidelity would require model predictions
    
    % Compute local variance as a proxy for information content
    localVariance = stdfilt(explanations, ones(3, 3)).^2;
    
    % Higher local variance indicates better preservation of information
    fidelity = mean(localVariance(:));
end
