%% chapter_AI_CV_particle_filter_01.m
% Particle Filter Implementation for Object Tracking
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_particle_filter_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Particle Filter for Visual Object Tracking
% Create a more complex tracking scenario with nonlinear dynamics

% Parameters
num_particles = 500;
num_frames = 150;
dt = 1.0;

% Create complex trajectory with nonlinear motion
t = (0:num_frames-1) * dt;
omega = 0.05;  % Angular frequency
radius = 50;

% Spiral trajectory with variable speed
true_x = 200 + radius * cos(omega * t) .* (1 + 0.01 * t);
true_y = 200 + radius * sin(omega * t) .* (1 + 0.01 * t);
true_vx = gradient(true_x);
true_vy = gradient(true_y);

% Add some random acceleration for complexity
accel_noise = 0.5;
true_vx = true_vx + accel_noise * cumsum(randn(size(t)));
true_vy = true_vy + accel_noise * cumsum(randn(size(t)));

% Recompute positions with acceleration
true_x = cumsum([true_x(1), true_vx(1:end-1) * dt]);
true_y = cumsum([true_y(1), true_vy(1:end-1) * dt]);

true_states = [true_x', true_y', true_vx', true_vy'];

% Create measurements with varying noise and occasional outliers
measurement_noise_base = 3.0;
measurements = zeros(num_frames, 2);

for i = 1:num_frames
    % Varying measurement noise (simulating changing conditions)
    noise_scale = 1 + 0.5 * sin(0.1 * i);
    meas_noise = measurement_noise_base * noise_scale;
    
    % Add outliers occasionally
    if rand < 0.05  % 5% outlier rate
        measurements(i, :) = [true_x(i) + 50*randn, true_y(i) + 50*randn];
    else
        measurements(i, :) = [true_x(i) + meas_noise*randn, true_y(i) + meas_noise*randn];
    end
end

% Particle Filter Implementation

% Motion model for particle prediction

% Observation model for weight computation

% Effective Sample Size calculation

% Systematic resampling

% Set particle filter parameters
pf_params.dt = dt;
pf_params.init_pos_std = 20;
pf_params.init_vel_std = 10;
pf_params.friction = 0.98;
pf_params.accel_noise = 2.0;
pf_params.pos_noise = 1.0;
pf_params.measurement_noise = measurement_noise_base;
pf_params.outlier_threshold = 20;

% Run particle filter
[pf_states, particles_hist, weights_hist] = particleFilterTracker(...
    measurements, num_particles, @motionModel, @observationModel, pf_params);

% Adaptive particle filter with varying number of particles

% Run adaptive particle filter
[apf_states, particle_counts] = adaptiveParticleFilter(...
    measurements, @motionModel, @observationModel, pf_params);

% Multi-modal particle filter (handles multiple hypotheses)

% Run multi-modal particle filter
[mmf_states, mode_weights] = multiModalParticleFilter(...
    measurements, 3, 150, @motionModel, @observationModel, pf_params);

% Performance evaluation

% Evaluate all filters
pf_metrics = evaluateParticleFilter(true_states, pf_states);
apf_metrics = evaluateParticleFilter(true_states, apf_states);
mmf_metrics = evaluateParticleFilter(true_states, mmf_states);

% Display comprehensive results
figure;

% Trajectory comparison
subplot(2,4,1);
plot(true_x, true_y, 'g-', 'LineWidth', 3, 'DisplayName', 'True Trajectory');
hold on;
plot(measurements(:,1), measurements(:,2), 'r.', 'MarkerSize', 6, 'DisplayName', 'Measurements');
plot(pf_states(:,1), pf_states(:,2), 'b-', 'LineWidth', 2, 'DisplayName', 'Particle Filter');
plot(apf_states(:,1), apf_states(:,2), 'm--', 'LineWidth', 2, 'DisplayName', 'Adaptive PF');
xlabel('X Position'); ylabel('Y Position');
title('Particle Filter Tracking');
legend('show'); grid on;

% Position errors
subplot(2,4,2);
plot(t, pf_metrics.position_errors, 'b-', 'LineWidth', 2, 'DisplayName', 'Standard PF');
hold on;
plot(t, apf_metrics.position_errors, 'm-', 'LineWidth', 2, 'DisplayName', 'Adaptive PF');
plot(t, mmf_metrics.position_errors, 'c-', 'LineWidth', 2, 'DisplayName', 'Multi-modal PF');
xlabel('Time'); ylabel('Position Error');
title('Tracking Error Comparison');
legend('show'); grid on;

% Particle distribution at selected frames
subplot(2,4,3);
selected_frames = [20, 50, 80];
colors = ['r', 'g', 'b'];
for i = 1:length(selected_frames)
    frame = selected_frames(i);
    particles = squeeze(particles_hist(:, :, frame));
    weights = weights_hist(:, frame);
    
    % Plot particles with size proportional to weights
    scatter(particles(:,1), particles(:,2), 20*weights*num_particles, colors(i), 'filled', 'Alpha', 0.6);
    hold on;
end
plot(true_x, true_y, 'k-', 'LineWidth', 2);
xlabel('X Position'); ylabel('Y Position');
title('Particle Distribution Evolution');
grid on;

% Adaptive particle count
subplot(2,4,4);
plot(t, particle_counts, 'r-', 'LineWidth', 2);
xlabel('Time'); ylabel('Number of Particles');
title('Adaptive Particle Count');
grid on;

% Mode weights for multi-modal filter
subplot(2,4,5);
for mode = 1:size(mode_weights, 1)
    plot(t, mode_weights(mode, :), 'LineWidth', 2, 'DisplayName', sprintf('Mode %d', mode));
    hold on;
end
xlabel('Time'); ylabel('Mode Weight');
title('Multi-modal Filter Modes');
legend('show'); grid on;

% Effective sample size
subplot(2,4,6);
ess_values = zeros(num_frames, 1);
for frame = 1:num_frames
    ess_values(frame) = calculateESS(weights_hist(:, frame));
end
plot(t, ess_values, 'k-', 'LineWidth', 2);
hold on;
plot(t, num_particles/2 * ones(size(t)), 'r--', 'LineWidth', 2, 'DisplayName', 'Resampling Threshold');
xlabel('Time'); ylabel('Effective Sample Size');
title('Filter Degeneracy Monitoring');
legend('show'); grid on;

% Particle diversity over time
subplot(2,4,7);
diversity_values = zeros(num_frames, 1);
for frame = 1:num_frames
    particles = squeeze(particles_hist(:, :, frame));
    % Calculate particle spread as measure of diversity
    particle_cov = cov(particles(:, 1:2));
    diversity_values(frame) = trace(particle_cov);
end
plot(t, diversity_values, 'g-', 'LineWidth', 2);
xlabel('Time'); ylabel('Particle Diversity');
title('Particle Set Diversity');
grid on;

% Performance comparison
subplot(2,4,8);
methods = {'Standard PF', 'Adaptive PF', 'Multi-modal PF'};
rmse_values = [pf_metrics.position_rmse, apf_metrics.position_rmse, mmf_metrics.position_rmse];
bar(rmse_values);
set(gca, 'XTickLabel', methods);
title('Position RMSE Comparison');
ylabel('RMSE (pixels)');

% Advanced particle filter diagnostics
figure;

% Weight distribution analysis
subplot(2,3,1);
final_weights = weights_hist(:, end);
histogram(final_weights, 30);
xlabel('Particle Weight');
ylabel('Frequency');
title('Final Weight Distribution');

% State estimation uncertainty over time
subplot(2,3,2);
uncertainty_values = zeros(num_frames, 1);
for frame = 1:num_frames
    particles = squeeze(particles_hist(:, :, frame));
    weights = weights_hist(:, frame);
    
    % Weighted covariance of particles
    weighted_mean = sum(particles .* weights, 1);
    centered_particles = particles - weighted_mean;
    weighted_cov = (centered_particles' * diag(weights) * centered_particles) / (1 - sum(weights.^2));
    uncertainty_values(frame) = trace(weighted_cov(1:2, 1:2));
end
plot(t, uncertainty_values, 'b-', 'LineWidth', 2);
xlabel('Time'); ylabel('Position Uncertainty');
title('State Estimation Uncertainty');
grid on;

% Resampling frequency analysis
subplot(2,3,3);
resampling_events = ess_values < num_particles / 2;
resampling_frequency = movmean(double(resampling_events), 10);
plot(t, 100 * resampling_frequency, 'r-', 'LineWidth', 2);
xlabel('Time'); ylabel('Resampling Frequency (%)');
title('Resampling Activity');
grid on;

% Particle trajectory visualisation
subplot(2,3,4);
% Show trajectories of a subset of particles
num_particles_to_show = 20;
particle_indices = randperm(num_particles, num_particles_to_show);
colors = jet(num_particles_to_show);

for i = 1:num_particles_to_show
    p_idx = particle_indices(i);
    particle_trajectory_x = squeeze(particles_hist(p_idx, 1, :));
    particle_trajectory_y = squeeze(particles_hist(p_idx, 2, :));
    plot(particle_trajectory_x, particle_trajectory_y, 'Color', colors(i, :), 'LineWidth', 1, 'Alpha', 0.6);
    hold on;
end
plot(true_x, true_y, 'k-', 'LineWidth', 3, 'DisplayName', 'True Trajectory');
plot(pf_states(:,1), pf_states(:,2), 'r-', 'LineWidth', 2, 'DisplayName', 'PF Estimate');
xlabel('X Position'); ylabel('Y Position');
title('Particle Trajectories');
legend('show'); grid on;

% Innovation analysis
subplot(2,3,5);
innovations = zeros(num_frames, 2);
for frame = 2:num_frames
    predicted_measurement = pf_states(frame-1, 1:2);
    if ~any(isnan(measurements(frame, :)))
        innovations(frame, :) = measurements(frame, :) - predicted_measurement;
    end
end
plot(t, innovations(:,1), 'r-', 'LineWidth', 2, 'DisplayName', 'X Innovation');
hold on;
plot(t, innovations(:,2), 'b-', 'LineWidth', 2, 'DisplayName', 'Y Innovation');
xlabel('Time'); ylabel('Innovation');
title('Innovation Sequence');
legend('show'); grid on;

% Computational performance analysis
subplot(2,3,6);
computational_load = particle_counts / max(particle_counts);
tracking_accuracy = 1 ./ (1 + apf_metrics.position_errors / max(apf_metrics.position_errors));
plot(t, computational_load, 'g-', 'LineWidth', 2, 'DisplayName', 'Computational Load');
hold on;
plot(t, tracking_accuracy, 'b-', 'LineWidth', 2, 'DisplayName', 'Tracking Accuracy');
xlabel('Time'); ylabel('Normalised Value');
title('Computational Load vs Accuracy');
legend('show'); grid on;

% Robustness analysis under different noise conditions

% Perform robustness analysis
noise_levels = 0:2:10;
robustness_results = analyseFilterRobustness(true_states, measurements, noise_levels, pf_params);

% Print comprehensive analysis
fprintf('Particle Filter Tracking Performance Analysis:\n');
fprintf('Number of particles: %d\n', num_particles);
fprintf('Trajectory length: %d frames\n', num_frames);
fprintf('Motion model: Nonlinear with friction\n');

fprintf('\nStandard Particle Filter:\n');
fprintf('Position RMSE: %.2f pixels\n', pf_metrics.position_rmse);
fprintf('Mean position error: %.2f ㊣ %.2f pixels\n', pf_metrics.mean_position_error, pf_metrics.std_position_error);
fprintf('Maximum position error: %.2f pixels\n', pf_metrics.max_position_error);
fprintf('Velocity RMSE: %.2f pixels/frame\n', pf_metrics.velocity_rmse);

fprintf('\nAdaptive Particle Filter:\n');
fprintf('Position RMSE: %.2f pixels\n', apf_metrics.position_rmse);
fprintf('Mean position error: %.2f ㊣ %.2f pixels\n', apf_metrics.mean_position_error, apf_metrics.std_position_error);
fprintf('Mean particle count: %.1f\n', mean(particle_counts));
fprintf('Particle count range: %d - %d\n', min(particle_counts), max(particle_counts));
fprintf('Computational efficiency gain: %.1fx\n', num_particles / mean(particle_counts));

fprintf('\nMulti-modal Particle Filter:\n');
fprintf('Position RMSE: %.2f pixels\n', mmf_metrics.position_rmse);
fprintf('Mean position error: %.2f ㊣ %.2f pixels\n', mmf_metrics.mean_position_error, mmf_metrics.std_position_error);
fprintf('Number of modes: %d\n', size(mode_weights, 1));
fprintf('Dominant mode persistence: %.1f%%\n', 100 * max(mean(mode_weights, 2)));

fprintf('\nFilter Diagnostics:\n');
fprintf('Average ESS: %.1f (%.1f%% of particles)\n', mean(ess_values), 100*mean(ess_values)/num_particles);
fprintf('Resampling frequency: %.1f%%\n', 100*sum(ess_values < num_particles/2)/num_frames);
fprintf('Mean particle diversity: %.1f\n', mean(diversity_values));
fprintf('Final weight concentration: %.4f\n', max(final_weights));

fprintf('\nComparative Performance:\n');
fprintf('PF vs Truth correlation: %.3f\n', corr(pf_metrics.position_errors, sqrt(sum((measurements - true_states(:,1:2)).^2, 2))));
fprintf('Best performing method: %s\n', methods{find(rmse_values == min(rmse_values), 1)});
fprintf('Performance improvement (best vs worst): %.1f%%\n', 100 * (max(rmse_values) - min(rmse_values)) / max(rmse_values));

fprintf('\nRobustness Analysis:\n');
for n = 1:length(noise_levels)
    fprintf('Noise level %.1f: RMSE = %.2f pixels\n', noise_levels(n), robustness_results.rmse(n));
end

% Additional analysis: Filter consistency and theoretical bounds
fprintf('\nFilter Consistency Analysis:\n');
normalized_errors_squared = zeros(num_frames, 1);
for k = 1:num_frames
    particles = squeeze(particles_hist(:, :, k));
    weights = weights_hist(:, k);
    
    % Compute weighted covariance
    weighted_mean = sum(particles .* weights, 1);
    centered_particles = particles - weighted_mean;
    weighted_cov = (centered_particles' * diag(weights) * centered_particles) / (1 - sum(weights.^2));
    
    % Normalised error
    error = (true_states(k, 1:2)' - weighted_mean(1:2)');
    if det(weighted_cov(1:2, 1:2)) > 1e-6
        normalized_errors_squared(k) = error' / weighted_cov(1:2, 1:2) * error;
    end
end

% Chi-square test for filter consistency (95% should be below 5.991 for 2 DOF)
consistency_ratio = sum(normalized_errors_squared < 5.991) / num_frames;
fprintf('Filter consistency (95%% bound): %.1f%% (should be ＞95%%)\n', 100 * consistency_ratio);

if consistency_ratio < 0.90
    fprintf('Warning: Filter may be overconfident (too narrow uncertainty)\n');
elseif consistency_ratio > 0.98
    fprintf('Warning: Filter may be underconfident (too wide uncertainty)\n');
else
    fprintf('Filter appears well-calibrated\n');
end

% Local functions (moved to end so this listing is a valid MATLAB script)
function [pf_states, particles_history, weights_history] = particleFilterTracker(measurements, num_particles, motion_model, observation_model, params)
    num_frames = size(measurements, 1);
    state_dim = 4;  % [x, y, vx, vy]
    
    % Initialize particles
    particles = zeros(num_particles, state_dim);
    weights = ones(num_particles, 1) / num_particles;
    
    % Initialize around first measurement
    particles(:, 1) = measurements(1, 1) + params.init_pos_std * randn(num_particles, 1);
    particles(:, 2) = measurements(1, 2) + params.init_pos_std * randn(num_particles, 1);
    particles(:, 3) = params.init_vel_std * randn(num_particles, 1);
    particles(:, 4) = params.init_vel_std * randn(num_particles, 1);
    
    % Storage for results
    pf_states = zeros(num_frames, state_dim);
    particles_history = zeros(num_particles, state_dim, num_frames);
    weights_history = zeros(num_particles, num_frames);
    
    for frame = 1:num_frames
        % Prediction step: propagate particles according to motion model
        particles = motion_model(particles, params);
        
        % Update step: compute weights based on observations
        if ~any(isnan(measurements(frame, :)))
            for p = 1:num_particles
                weights(p) = observation_model(particles(p, :), measurements(frame, :), params);
            end
            
            % Normalize weights
            weights = weights / (sum(weights) + eps);
        end
        
        % Estimate state as weighted average
        pf_states(frame, :) = sum(particles .* weights, 1);
        
        % Store history
        particles_history(:, :, frame) = particles;
        weights_history(:, frame) = weights;
        
        % Resampling (systematic resampling)
        if calculateESS(weights) < num_particles / 2
            particles = systematicResample(particles, weights);
            weights = ones(num_particles, 1) / num_particles;
        end
    end
end

function new_particles = motionModel(particles, params)
    num_particles = size(particles, 1);
    dt = params.dt;
    
    % Nonlinear motion with friction and random acceleration
    friction = params.friction;
    accel_noise = params.accel_noise;
    
    new_particles = particles;
    
    % Position update
    new_particles(:, 1) = particles(:, 1) + dt * particles(:, 3);
    new_particles(:, 2) = particles(:, 2) + dt * particles(:, 4);
    
    % Velocity update with friction and noise
    new_particles(:, 3) = friction * particles(:, 3) + accel_noise * randn(num_particles, 1);
    new_particles(:, 4) = friction * particles(:, 4) + accel_noise * randn(num_particles, 1);
    
    % Add process noise to positions
    pos_noise = params.pos_noise;
    new_particles(:, 1) = new_particles(:, 1) + pos_noise * randn(num_particles, 1);
    new_particles(:, 2) = new_particles(:, 2) + pos_noise * randn(num_particles, 1);
end

function weight = observationModel(particle_state, measurement, params)
    predicted_measurement = particle_state(1:2);  % Observe position only
    
    % Gaussian likelihood with adaptive noise
    measurement_noise = params.measurement_noise;
    
    % Robust likelihood (handles outliers better)
    distance = norm(predicted_measurement - measurement);
    
    if distance < params.outlier_threshold
        % Normal Gaussian likelihood
        weight = exp(-0.5 * (distance / measurement_noise)^2);
    else
        % Reduced weight for potential outliers
        weight = 0.1 * exp(-0.5 * (distance / (5 * measurement_noise))^2);
    end
end

function ess = calculateESS(weights)
    ess = 1 / sum(weights.^2);
end

function resampled_particles = systematicResample(particles, weights)
    num_particles = size(particles, 1);
    cumulative_weights = cumsum(weights);
    
    % Generate systematic samples
    u = (0:num_particles-1) / num_particles + rand / num_particles;
    
    resampled_particles = zeros(size(particles));
    j = 1;
    
    for i = 1:num_particles
        while u(i) > cumulative_weights(j)
            j = j + 1;
        end
        resampled_particles(i, :) = particles(j, :);
    end
end

function [apf_states, particle_counts] = adaptiveParticleFilter(measurements, motion_model, observation_model, params)
    num_frames = size(measurements, 1);
    state_dim = 4;
    
    min_particles = 100;
    max_particles = 1000;
    target_ess_ratio = 0.5;
    
    % Initialize
    num_particles = 300;
    particles = zeros(num_particles, state_dim);
    weights = ones(num_particles, 1) / num_particles;
    
    % Initialize particles
    particles(:, 1) = measurements(1, 1) + params.init_pos_std * randn(num_particles, 1);
    particles(:, 2) = measurements(1, 2) + params.init_pos_std * randn(num_particles, 1);
    particles(:, 3) = params.init_vel_std * randn(num_particles, 1);
    particles(:, 4) = params.init_vel_std * randn(num_particles, 1);
    
    % Storage
    apf_states = zeros(num_frames, state_dim);
    particle_counts = zeros(num_frames, 1);
    
    for frame = 1:num_frames
        % Prediction
        particles = motion_model(particles, params);
        
        % Update weights
        if ~any(isnan(measurements(frame, :)))
            for p = 1:num_particles
                weights(p) = observation_model(particles(p, :), measurements(frame, :), params);
            end
            weights = weights / (sum(weights) + eps);
        end
        
        % State estimate
        apf_states(frame, :) = sum(particles .* weights, 1);
        particle_counts(frame) = num_particles;
        
        % Adaptive resampling
        ess = calculateESS(weights);
        ess_ratio = ess / num_particles;
        
        if ess_ratio < target_ess_ratio
            % Resample
            particles = systematicResample(particles, weights);
            weights = ones(num_particles, 1) / num_particles;
            
            % Adapt number of particles based on uncertainty
            uncertainty = trace(cov(particles));
            if uncertainty > 1000  % High uncertainty
                num_particles = min(max_particles, round(num_particles * 1.2));
            elseif uncertainty < 100  % Low uncertainty
                num_particles = max(min_particles, round(num_particles * 0.9));
            end
            
            % Adjust particle set size
            if size(particles, 1) ~= num_particles
                if size(particles, 1) > num_particles
                    % Reduce particles
                    indices = randperm(size(particles, 1), num_particles);
                    particles = particles(indices, :);
                else
                    % Increase particles by replication
                    extra_needed = num_particles - size(particles, 1);
                    extra_indices = randi(size(particles, 1), extra_needed, 1);
                    particles = [particles; particles(extra_indices, :)];
                end
                weights = ones(num_particles, 1) / num_particles;
            end
        end
    end
end

function [mmf_states, mode_weights] = multiModalParticleFilter(measurements, num_modes, particles_per_mode, motion_model, observation_model, params)
    num_frames = size(measurements, 1);
    state_dim = 4;
    total_particles = num_modes * particles_per_mode;
    
    % Initialize multiple modes
    all_particles = zeros(total_particles, state_dim);
    mode_weights = zeros(num_modes, num_frames);
    mmf_states = zeros(num_frames, state_dim);
    
    % Initialize each mode with different hypothesis
    for mode = 1:num_modes
        start_idx = (mode - 1) * particles_per_mode + 1;
        end_idx = mode * particles_per_mode;
        
        % Different initial positions for each mode
        offset_x = 30 * (mode - (num_modes+1)/2);
        offset_y = 30 * (mode - (num_modes+1)/2);
        
        all_particles(start_idx:end_idx, 1) = measurements(1, 1) + offset_x + params.init_pos_std * randn(particles_per_mode, 1);
        all_particles(start_idx:end_idx, 2) = measurements(1, 2) + offset_y + params.init_pos_std * randn(particles_per_mode, 1);
        all_particles(start_idx:end_idx, 3) = params.init_vel_std * randn(particles_per_mode, 1);
        all_particles(start_idx:end_idx, 4) = params.init_vel_std * randn(particles_per_mode, 1);
    end
    
    weights = ones(total_particles, 1) / total_particles;
    
    for frame = 1:num_frames
        % Prediction
        all_particles = motion_model(all_particles, params);
        
        % Update weights
        if ~any(isnan(measurements(frame, :)))
            for p = 1:total_particles
                weights(p) = observation_model(all_particles(p, :), measurements(frame, :), params);
            end
            weights = weights / (sum(weights) + eps);
        end
        
        % Calculate mode weights and states
        for mode = 1:num_modes
            start_idx = (mode - 1) * particles_per_mode + 1;
            end_idx = mode * particles_per_mode;
            
            mode_weight = sum(weights(start_idx:end_idx));
            mode_weights(mode, frame) = mode_weight;
        end
        
        % Overall state estimate (weighted by mode importance)
        mmf_states(frame, :) = sum(all_particles .* weights, 1);
        
        % Resample within each mode
        for mode = 1:num_modes
            start_idx = (mode - 1) * particles_per_mode + 1;
            end_idx = mode * particles_per_mode;
            
            mode_particles = all_particles(start_idx:end_idx, :);
            mode_weights_norm = weights(start_idx:end_idx) / sum(weights(start_idx:end_idx) + eps);
            
            if calculateESS(mode_weights_norm) < particles_per_mode / 3
                resampled_mode_particles = systematicResample(mode_particles, mode_weights_norm);
                all_particles(start_idx:end_idx, :) = resampled_mode_particles;
            end
        end
        
        % Reset weights after resampling
        weights = ones(total_particles, 1) / total_particles;
    end
end

function metrics = evaluateParticleFilter(true_states, estimated_states)
    position_errors = sqrt(sum((true_states(:, 1:2) - estimated_states(:, 1:2)).^2, 2));
    velocity_errors = sqrt(sum((true_states(:, 3:4) - estimated_states(:, 3:4)).^2, 2));
    
    metrics.mean_position_error = mean(position_errors);
    metrics.std_position_error = std(position_errors);
    metrics.max_position_error = max(position_errors);
    metrics.position_rmse = sqrt(mean(position_errors.^2));
    metrics.velocity_rmse = sqrt(mean(velocity_errors.^2));
    metrics.position_errors = position_errors;
end

function robustness_results = analyseFilterRobustness(true_states, measurements, noise_levels, pf_params)
    num_noise_levels = length(noise_levels);
    robustness_results = struct();
    
    for n = 1:num_noise_levels
        % Add additional noise
        noisy_measurements = measurements + noise_levels(n) * randn(size(measurements));
        
        % Update parameters for current noise level
        current_params = pf_params;
        current_params.measurement_noise = pf_params.measurement_noise + noise_levels(n);
        
        % Run particle filter
        [pf_states_robust, ~, ~] = particleFilterTracker(...
            noisy_measurements, 300, @motionModel, @observationModel, current_params);
        
        % Calculate performance metrics
        position_errors = sqrt(sum((true_states(:, 1:2) - pf_states_robust(:, 1:2)).^2, 2));
        robustness_results.rmse(n) = sqrt(mean(position_errors.^2));
        robustness_results.mean_error(n) = mean(position_errors);
        robustness_results.max_error(n) = max(position_errors);
    end
    
    robustness_results.noise_levels = noise_levels;
end
