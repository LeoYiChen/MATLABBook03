%% chapter_AI_CV_benchmarking_01.m
% Comprehensive Benchmarking and Comparative Analysis Framework
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_benchmarking_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Comprehensive Benchmarking and Comparative Analysis Framework
fprintf('Benchmarking and Comparative Analysis Framework\n');
fprintf('==============================================\n');

% Create benchmark dataset and simulate multiple algorithms
[benchmarkData, algorithmResults] = createBenchmarkScenario();



% 1. Statistical Analysis of Algorithm Performance

% 2. Ranking and Tournament Analysis


% 3. Efficiency Analysis


% 4. Robustness Analysis

% 5. Comprehensive Benchmark Report Generation




% Test the benchmarking framework
fprintf('\nTesting comprehensive benchmarking framework...\n');

% Generate comprehensive benchmark report
fullBenchmarkReport = generateBenchmarkReport(benchmarkData, algorithmResults);

% Visualise benchmark results
figure;

% Performance comparison across tasks
subplot(3, 4, 1);
taskPerformances = [mean(algorithmResults.classification, 2), ...
                   mean(algorithmResults.detection, 2), ...
                   mean(algorithmResults.segmentation, 2)];
bar(taskPerformances);
set(gca, 'XTickLabel', algorithmResults.algorithmNames);
xtickangle(45);
legend(benchmarkData.tasks);
title('Performance Across Tasks');
ylabel('Score');

% Runtime vs Performance trade-off
subplot(3, 4, 2);
avgPerformance = mean(algorithmResults.classification, 2);
avgRuntime = mean(algorithmResults.runtime, 2);
scatter(avgRuntime, avgPerformance, 100, 'filled');
xlabel('Runtime (FPS)');
ylabel('Performance');
title('Performance vs Speed Trade-off');

% Memory efficiency
subplot(3, 4, 3);
avgMemory = mean(algorithmResults.memory, 2);
scatter(avgMemory, avgPerformance, 100, 'filled');
xlabel('Memory Usage (MB)');
ylabel('Performance');
title('Performance vs Memory Trade-off');

% Algorithm rankings
subplot(3, 4, 4);
rankings = [fullBenchmarkReport.overallRankings.performanceRanking, ...
           fullBenchmarkReport.overallRankings.efficiencyRanking, ...
           fullBenchmarkReport.robustness.robustnessRanking];
imagesc(rankings);
colorbar;
set(gca, 'XTickLabel', {'Performance', 'Efficiency', 'Robustness'});
set(gca, 'YTickLabel', algorithmResults.algorithmNames);
title('Algorithm Rankings');

% Performance distribution
subplot(3, 4, 5);
boxplot(algorithmResults.classification', 'Labels', algorithmResults.algorithmNames);
xtickangle(45);
title('Classification Performance Distribution');
ylabel('Accuracy');

% Robustness analysis
subplot(3, 4, 6);
robustnessMetrics = [fullBenchmarkReport.robustness.meanPerformance, ...
                    fullBenchmarkReport.robustness.coefficientOfVariation];
bar(robustnessMetrics);
set(gca, 'XTickLabel', algorithmResults.algorithmNames);
xtickangle(45);
legend({'Mean Performance', 'Coefficient of Variation'});
title('Robustness Analysis');

% Efficiency metrics
subplot(3, 4, 7);
efficiencyMetrics = [fullBenchmarkReport.efficiency.performancePerSecond, ...
                    fullBenchmarkReport.efficiency.performancePerMB];
bar(efficiencyMetrics);
set(gca, 'XTickLabel', algorithmResults.algorithmNames);
xtickangle(45);
legend({'Perf/Speed', 'Perf/Memory'});
title('Efficiency Metrics');

% Win-loss matrix
subplot(3, 4, 8);
winMatrix = fullBenchmarkReport.ranking.winMatrix;
imagesc(winMatrix);
colorbar;
set(gca, 'XTickLabel', algorithmResults.algorithmNames);
set(gca, 'YTickLabel', algorithmResults.algorithmNames);
xtickangle(45);
title('Win-Loss Matrix');

% Overall scores
subplot(3, 4, 9);
overallScores = fullBenchmarkReport.overallRankings.performanceScores;
bar(overallScores);
set(gca, 'XTickLabel', algorithmResults.algorithmNames);
xtickangle(45);
title('Overall Performance Scores');
ylabel('Normalized Score');

% Statistical significance
subplot(3, 4, 10);
if isfield(fullBenchmarkReport.classification, 'anovaResults')
    pValue = fullBenchmarkReport.classification.anovaResults.pValue;
    bar([pValue, 0.05]);
    set(gca, 'XTickLabel', {'ANOVA p-value', 'Significance Threshold'});
    title('Statistical Significance');
    ylabel('p-value');
end

% Model complexity vs performance
subplot(3, 4, 11);
avgModelSize = mean(algorithmResults.modelSize, 2);
scatter(avgModelSize, avgPerformance, 100, 'filled');
xlabel('Model Size (M parameters)');
ylabel('Performance');
title('Complexity vs Performance');

% Pareto frontier
subplot(3, 4, 12);
paretoIndices = fullBenchmarkReport.efficiency.paretoEfficiency;
scatter(avgRuntime(~paretoIndices), avgPerformance(~paretoIndices), 50, 'b', 'filled');
hold on;
scatter(avgRuntime(paretoIndices), avgPerformance(paretoIndices), 100, 'r', 'filled');
hold off;
xlabel('Runtime (FPS)');
ylabel('Performance');
title('Pareto Efficient Algorithms');
legend({'Non-Pareto', 'Pareto Efficient'});

sgtitle('Comprehensive Benchmark Analysis Results');

% Display detailed benchmark report
fprintf('\n' + string(repmat('=', 1, 70)) + '\n');
fprintf('COMPREHENSIVE BENCHMARK REPORT\n');
fprintf(string(repmat('=', 1, 70)) + '\n');

fprintf('\nBENCHMARK OVERVIEW:\n');
fprintf('  Name: %s\n', fullBenchmarkReport.benchmarkName);
fprintf('  Number of Algorithms: %d\n', fullBenchmarkReport.numAlgorithms);
fprintf('  Tasks Evaluated: %s\n', strjoin(benchmarkData.tasks, ', '));
fprintf('  Datasets Used: %s\n', strjoin(benchmarkData.datasets, ', '));

fprintf('\nOVERALL RANKINGS:\n');
fprintf('================\n');
fprintf('Performance Ranking:\n');
for i = 1:min(5, length(algorithmResults.algorithmNames))
    algIdx = fullBenchmarkReport.overallRankings.performanceRanking(i);
    algName = algorithmResults.algorithmNames{algIdx};
    score = fullBenchmarkReport.overallRankings.performanceScores(algIdx);
    fprintf('  %d. %s (Score: %.3f)\n', i, algName, score);
end

fprintf('\nEfficiency Ranking:\n');
for i = 1:min(5, length(algorithmResults.algorithmNames))
    algIdx = fullBenchmarkReport.overallRankings.efficiencyRanking(i);
    algName = algorithmResults.algorithmNames{algIdx};
    score = fullBenchmarkReport.overallRankings.efficiencyScores(algIdx);
    fprintf('  %d. %s (Score: %.3f)\n', i, algName, score);
end

fprintf('\nROBUSTNESS ANALYSIS:\n');
fprintf('===================\n');
for i = 1:min(3, length(algorithmResults.algorithmNames))
    algIdx = fullBenchmarkReport.robustness.robustnessRanking(i);
    algName = algorithmResults.algorithmNames{algIdx};
    meanPerf = fullBenchmarkReport.robustness.meanPerformance(algIdx);
    cv = fullBenchmarkReport.robustness.coefficientOfVariation(algIdx);
    fprintf('  %d. %s (Mean: %.3f, CV: %.3f)\n', i, algName, meanPerf, cv);
end

fprintf('\nKEY FINDINGS:\n');
fprintf('=============\n');
for i = 1:length(fullBenchmarkReport.keyFindings)
    fprintf(' %s\n', fullBenchmarkReport.keyFindings{i});
end

if isfield(fullBenchmarkReport.classification, 'anovaResults')
    fprintf('\nSTATISTICAL ANALYSIS:\n');
    fprintf('====================\n');
    fprintf('ANOVA p-value: %.4f\n', fullBenchmarkReport.classification.anovaResults.pValue);
    if fullBenchmarkReport.classification.anovaResults.pValue < 0.05
        fprintf('Significant differences detected between algorithms\n');
    else
        fprintf('No significant differences detected between algorithms\n');
    end
end

fprintf('\nRECOMMENDATIONS:\n');
fprintf('===============\n');

% Performance recommendation
bestPerformer = algorithmResults.algorithmNames{fullBenchmarkReport.overallRankings.performanceRanking(1)};
fprintf(' For maximum performance: %s\n', bestPerformer);

% Efficiency recommendation
mostEfficient = algorithmResults.algorithmNames{fullBenchmarkReport.overallRankings.efficiencyRanking(1)};
fprintf(' For best efficiency: %s\n', mostEfficient);

% Robustness recommendation
mostRobust = algorithmResults.algorithmNames{fullBenchmarkReport.robustness.robustnessRanking(1)};
fprintf(' For maximum robustness: %s\n', mostRobust);

% Pareto efficient algorithms
paretoAlgs = algorithmResults.algorithmNames(fullBenchmarkReport.efficiency.paretoEfficiency);
fprintf(' Pareto efficient algorithms: %s\n', strjoin(paretoAlgs, ', '));

fprintf('\nBENCHMARKING BEST PRACTICES:\n');
fprintf('===========================\n');
fprintf(' Use multiple complementary metrics\n');
fprintf(' Evaluate across diverse datasets and conditions\n');
fprintf(' Consider efficiency alongside performance\n');
fprintf(' Assess statistical significance of differences\n');
fprintf(' Account for robustness and consistency\n');
fprintf(' Report confidence intervals and effect sizes\n');
fprintf(' Consider real-world deployment constraints\n');
fprintf(' Ensure reproducible experimental conditions\n');

fprintf('\n' + string(repmat('=', 1, 70)) + '\n');

% Local functions (moved to end so this listing is a valid MATLAB script)
function [data, results] = createBenchmarkScenario()
    % Create comprehensive benchmark scenario with multiple algorithms
    
    fprintf('Creating benchmark scenario...\n');
    
    % Benchmark configuration
    data = struct();
    data.name = 'Computer Vision Benchmark 2024';
    data.tasks = {'classification', 'detection', 'segmentation'};
    data.datasets = {'ImageNet-subset', 'COCO-val', 'Cityscapes-test'};
    data.metrics = {'accuracy', 'mAP', 'IoU'};
    
    % Simulate algorithm performance across different scenarios
    numAlgorithms = 8;
    algorithmNames = {
        'ResNet-50', 'EfficientNet-B4', 'Vision Transformer', 'MobileNet-V3',
        'YOLO-v5', 'Faster R-CNN', 'Mask R-CNN', 'DeepLab-v3+'
    };
    
    % Performance matrices for different tasks
    results = struct();
    results.algorithmNames = algorithmNames;
    
    % Classification results (accuracy)
    results.classification = generatePerformanceMatrix(numAlgorithms, 3, [0.75, 0.95]);
    
    % Detection results (mAP)
    results.detection = generatePerformanceMatrix(numAlgorithms, 3, [0.45, 0.75]);
    
    % Segmentation results (IoU)
    results.segmentation = generatePerformanceMatrix(numAlgorithms, 3, [0.65, 0.85]);
    
    % Runtime performance (FPS)
    results.runtime = generatePerformanceMatrix(numAlgorithms, 3, [15, 120]);
    
    % Memory usage (MB)
    results.memory = generatePerformanceMatrix(numAlgorithms, 3, [200, 1500]);
    
    % Model size (parameters in millions)
    results.modelSize = generatePerformanceMatrix(numAlgorithms, 3, [5, 150]);
    
    fprintf('Created benchmark with %d algorithms across %d tasks\n', ...
        numAlgorithms, length(data.tasks));
end

function perfMatrix = generatePerformanceMatrix(numAlgorithms, numDatasets, valueRange)
    % Generate realistic performance matrix with controlled characteristics
    
    perfMatrix = zeros(numAlgorithms, numDatasets);
    
    for alg = 1:numAlgorithms
        % Each algorithm has a base performance level
        basePerformance = valueRange(1) + (valueRange(2) - valueRange(1)) * rand();
        
        for dataset = 1:numDatasets
            % Add dataset-specific variation
            datasetVariation = (rand() - 0.5) * 0.1 * (valueRange(2) - valueRange(1));
            
            % Add noise
            noise = randn() * 0.02 * (valueRange(2) - valueRange(1));
            
            perfMatrix(alg, dataset) = basePerformance + datasetVariation + noise;
        end
    end
    
    % Ensure values are within valid range
    perfMatrix = max(valueRange(1), min(valueRange(2), perfMatrix));
end

function statsResults = analyzeAlgorithmPerformance(performanceMatrix, algorithmNames, datasetNames)
    % Perform comprehensive statistical analysis of algorithm performance
    
    if nargin < 2
        algorithmNames = arrayfun(@(x) sprintf('Algorithm_%d', x), 1:size(performanceMatrix, 1), 'UniformOutput', false);
    end
    if nargin < 3
        datasetNames = arrayfun(@(x) sprintf('Dataset_%d', x), 1:size(performanceMatrix, 2), 'UniformOutput', false);
    end
    
    fprintf('Analyzing algorithm performance statistics...\n');
    
    statsResults = struct();
    statsResults.algorithmNames = algorithmNames;
    statsResults.datasetNames = datasetNames;
    statsResults.performanceMatrix = performanceMatrix;
    
    [numAlgorithms, numDatasets] = size(performanceMatrix);
    
    % Descriptive statistics
    statsResults.meanPerformance = mean(performanceMatrix, 2);
    statsResults.stdPerformance = std(performanceMatrix, 0, 2);
    statsResults.minPerformance = min(performanceMatrix, [], 2);
    statsResults.maxPerformance = max(performanceMatrix, [], 2);
    
    % Dataset-wise statistics
    statsResults.datasetMeans = mean(performanceMatrix, 1);
    statsResults.datasetStds = std(performanceMatrix, 0, 1);
    
    % Ranking analysis
    [~, rankings] = sort(performanceMatrix, 1, 'descend');
    statsResults.rankings = rankings;
    statsResults.averageRank = mean(rankings, 2);
    
    % Statistical significance testing (ANOVA)
    if numDatasets > 1
        % Reshape data for ANOVA
        allScores = performanceMatrix(:);
        algorithmLabels = repmat((1:numAlgorithms)', numDatasets, 1);
        datasetLabels = repelem((1:numDatasets)', numAlgorithms);
        
        try
            [p, tbl, stats] = anova2(performanceMatrix, 1, 'off');
            statsResults.anovaResults = struct();
            statsResults.anovaResults.pValue = p(1); % Algorithm effect
            statsResults.anovaResults.table = tbl;
            statsResults.anovaResults.stats = stats;
            
            % Post-hoc analysis if significant
            if p(1) < 0.05
                [comparison, means, h, gnames] = multcompare(stats, 'Alpha', 0.05, 'Display', 'off');
                statsResults.postHoc = struct();
                statsResults.postHoc.comparison = comparison;
                statsResults.postHoc.means = means;
                statsResults.postHoc.significantPairs = comparison(comparison(:, 6) < 0.05, :);
            end
            
        catch ME
            fprintf('ANOVA analysis failed: %s\n', ME.message);
        end
    end
    
    % Coefficient of variation
    statsResults.coefficientOfVariation = statsResults.stdPerformance ./ (statsResults.meanPerformance + eps);
    
    fprintf('Statistical analysis completed\n');
end

function rankingResults = performRankingAnalysis(performanceMatrix, algorithmNames)
    % Perform comprehensive ranking analysis
    
    fprintf('Performing ranking analysis...\n');
    
    rankingResults = struct();
    rankingResults.algorithmNames = algorithmNames;
    
    [numAlgorithms, numDatasets] = size(performanceMatrix);
    
    % Standard ranking (highest performance = rank 1)
    [~, rankings] = sort(performanceMatrix, 1, 'descend');
    rankingResults.rankings = rankings;
    
    % Average rank
    rankingResults.averageRank = mean(rankings, 2);
    
    % Rank standard deviation
    rankingResults.rankStd = std(rankings, 0, 2);
    
    % Win-loss records
    winMatrix = zeros(numAlgorithms, numAlgorithms);
    
    for i = 1:numAlgorithms
        for j = 1:numAlgorithms
            if i ~= j
                wins = sum(performanceMatrix(i, :) > performanceMatrix(j, :));
                winMatrix(i, j) = wins / numDatasets;
            end
        end
    end
    
    rankingResults.winMatrix = winMatrix;
    rankingResults.winRate = mean(winMatrix, 2);
    
    % Friedman test for ranking significance
    if numDatasets > 6 && numAlgorithms > 2
        try
            [p, tbl, stats] = friedman(performanceMatrix', 1, 'off');
            rankingResults.friedmanTest = struct();
            rankingResults.friedmanTest.pValue = p;
            rankingResults.friedmanTest.chiSquare = tbl{2, 5};
            rankingResults.friedmanTest.significant = p < 0.05;
            
            % Post-hoc ranking comparisons
            if p < 0.05
                rankingResults.friedmanTest.criticalDifference = computeCriticalDifference(numAlgorithms, numDatasets);
            end
            
        catch ME
            fprintf('Friedman test failed: %s\n', ME.message);
        end
    end
    
    % Borda count ranking
    bordaScores = zeros(numAlgorithms, 1);
    for dataset = 1:numDatasets
        [~, datasetRanking] = sort(performanceMatrix(:, dataset), 'descend');
        for rank = 1:numAlgorithms
            alg = datasetRanking(rank);
            bordaScores(alg) = bordaScores(alg) + (numAlgorithms - rank);
        end
    end
    
    rankingResults.bordaScores = bordaScores;
    [~, rankingResults.bordaRanking] = sort(bordaScores, 'descend');
    
    fprintf('Ranking analysis completed\n');
end

function cd = computeCriticalDifference(numAlgorithms, numDatasets)
    % Compute critical difference for Friedman test post-hoc analysis
    
    % Critical value for 汐 = 0.05
    qAlpha = 2.576; % For 汐 = 0.05, two-tailed
    
    cd = qAlpha * sqrt((numAlgorithms * (numAlgorithms + 1)) / (6 * numDatasets));
end

function efficiencyResults = analyzeEfficiency(performanceScores, runtimeScores, memoryScores, modelSizes)
    % Analyze algorithm efficiency across multiple dimensions
    
    fprintf('Analyzing algorithm efficiency...\n');
    
    efficiencyResults = struct();
    
    numAlgorithms = size(performanceScores, 1);
    
    % Performance-efficiency trade-offs
    avgPerformance = mean(performanceScores, 2);
    avgRuntime = mean(runtimeScores, 2);
    avgMemory = mean(memoryScores, 2);
    avgModelSize = mean(modelSizes, 2);
    
    % Efficiency metrics
    efficiencyResults.performancePerSecond = avgPerformance ./ (1 ./ avgRuntime); % Performance * FPS
    efficiencyResults.performancePerMB = avgPerformance ./ avgMemory;
    efficiencyResults.performancePerParameter = avgPerformance ./ avgModelSize;
    
    % Multi-objective efficiency score (Pareto efficiency)
    efficiencyResults.paretoEfficiency = computeParetoEfficiency(avgPerformance, avgRuntime, avgMemory);
    
    % Normalize metrics for comparison
    normalizedPerformance = (avgPerformance - min(avgPerformance)) / (max(avgPerformance) - min(avgPerformance));
    normalizedSpeed = (avgRuntime - min(avgRuntime)) / (max(avgRuntime) - min(avgRuntime));
    normalizedMemory = 1 - (avgMemory - min(avgMemory)) / (max(avgMemory) - min(avgMemory)); % Lower is better
    
    % Composite efficiency score
    efficiencyResults.compositeScore = (normalizedPerformance + normalizedSpeed + normalizedMemory) / 3;
    
    % Rank algorithms by different criteria
    [~, efficiencyResults.performanceRanking] = sort(avgPerformance, 'descend');
    [~, efficiencyResults.speedRanking] = sort(avgRuntime, 'descend');
    [~, efficiencyResults.memoryRanking] = sort(avgMemory, 'ascend');
    [~, efficiencyResults.compositeRanking] = sort(efficiencyResults.compositeScore, 'descend');
    
    efficiencyResults.avgPerformance = avgPerformance;
    efficiencyResults.avgRuntime = avgRuntime;
    efficiencyResults.avgMemory = avgMemory;
    efficiencyResults.avgModelSize = avgModelSize;
    
    fprintf('Efficiency analysis completed\n');
end

function paretoIndices = computeParetoEfficiency(performance, runtime, memory)
    % Compute Pareto efficient algorithms
    
    numAlgorithms = length(performance);
    paretoIndices = false(numAlgorithms, 1);
    
    for i = 1:numAlgorithms
        isDominated = false;
        
        for j = 1:numAlgorithms
            if i ~= j
                % Check if algorithm j dominates algorithm i
                if performance(j) >= performance(i) && runtime(j) >= runtime(i) && memory(j) <= memory(i)
                    % At least one criterion must be strictly better
                    if performance(j) > performance(i) || runtime(j) > runtime(i) || memory(j) < memory(i)
                        isDominated = true;
                        break;
                    end
                end
            end
        end
        
        if ~isDominated
            paretoIndices(i) = true;
        end
    end
end

function robustnessResults = analyzeRobustness(performanceMatrix, algorithmNames)
    % Analyze algorithm robustness across different conditions
    
    fprintf('Analyzing algorithm robustness...\n');
    
    robustnessResults = struct();
    robustnessResults.algorithmNames = algorithmNames;
    
    [numAlgorithms, numDatasets] = size(performanceMatrix);
    
    % Robustness metrics
    robustnessResults.meanPerformance = mean(performanceMatrix, 2);
    robustnessResults.stdPerformance = std(performanceMatrix, 0, 2);
    robustnessResults.minPerformance = min(performanceMatrix, [], 2);
    robustnessResults.maxPerformance = max(performanceMatrix, [], 2);
    robustnessResults.range = robustnessResults.maxPerformance - robustnessResults.minPerformance;
    
    % Coefficient of variation (relative variability)
    robustnessResults.coefficientOfVariation = robustnessResults.stdPerformance ./ ...
                                              (robustnessResults.meanPerformance + eps);
    
    % Robustness score (combines mean performance with consistency)
    alpha = 0.7; % Weight for mean performance vs consistency
    normalizedMean = (robustnessResults.meanPerformance - min(robustnessResults.meanPerformance)) / ...
                    (max(robustnessResults.meanPerformance) - min(robustnessResults.meanPerformance));
    normalizedConsistency = 1 - (robustnessResults.coefficientOfVariation - min(robustnessResults.coefficientOfVariation)) / ...
                           (max(robustnessResults.coefficientOfVariation) - min(robustnessResults.coefficientOfVariation));
    
    robustnessResults.robustnessScore = alpha * normalizedMean + (1 - alpha) * normalizedConsistency;
    
    % Worst-case performance ranking
    [~, robustnessResults.worstCaseRanking] = sort(robustnessResults.minPerformance, 'descend');
    
    % Best-case performance ranking
    [~, robustnessResults.bestCaseRanking] = sort(robustnessResults.maxPerformance, 'descend');
    
    % Overall robustness ranking
    [~, robustnessResults.robustnessRanking] = sort(robustnessResults.robustnessScore, 'descend');
    
    % Consistency ranking (lower coefficient of variation is better)
    [~, robustnessResults.consistencyRanking] = sort(robustnessResults.coefficientOfVariation, 'ascend');
    
    fprintf('Robustness analysis completed\n');
end

function benchmarkReport = generateBenchmarkReport(benchmarkData, algorithmResults)
    % Generate comprehensive benchmark report
    
    fprintf('Generating comprehensive benchmark report...\n');
    
    benchmarkReport = struct();
    benchmarkReport.benchmarkName = benchmarkData.name;
    benchmarkReport.timestamp = datetime('now');
    benchmarkReport.numAlgorithms = length(algorithmResults.algorithmNames);
    
    % Analyze each performance dimension
    classificationStats = analyzeAlgorithmPerformance(algorithmResults.classification, ...
        algorithmResults.algorithmNames, benchmarkData.datasets);
    detectionStats = analyzeAlgorithmPerformance(algorithmResults.detection, ...
        algorithmResults.algorithmNames, benchmarkData.datasets);
    segmentationStats = analyzeAlgorithmPerformance(algorithmResults.segmentation, ...
        algorithmResults.algorithmNames, benchmarkData.datasets);
    
    % Ranking analysis
    classificationRanking = performRankingAnalysis(algorithmResults.classification, algorithmResults.algorithmNames);
    detectionRanking = performRankingAnalysis(algorithmResults.detection, algorithmResults.algorithmNames);
    
    % Efficiency analysis
    efficiencyAnalysis = analyzeEfficiency(algorithmResults.classification, algorithmResults.runtime, ...
        algorithmResults.memory, algorithmResults.modelSize);
    
    % Robustness analysis
    robustnessAnalysis = analyzeRobustness(algorithmResults.classification, algorithmResults.algorithmNames);
    
    % Store all analyses
    benchmarkReport.classification = classificationStats;
    benchmarkReport.detection = detectionStats;
    benchmarkReport.segmentation = segmentationStats;
    benchmarkReport.ranking = classificationRanking;
    benchmarkReport.efficiency = efficiencyAnalysis;
    benchmarkReport.robustness = robustnessAnalysis;
    
    % Overall rankings
    benchmarkReport.overallRankings = computeOverallRankings(algorithmResults);
    
    % Key findings
    benchmarkReport.keyFindings = generateKeyFindings(benchmarkReport);
    
    fprintf('Benchmark report generated successfully\n');
end

function overallRankings = computeOverallRankings(algorithmResults)
    % Compute overall rankings across all tasks
    
    overallRankings = struct();
    
    % Normalize all performance metrics
    classificationNorm = normalizeMatrix(algorithmResults.classification);
    detectionNorm = normalizeMatrix(algorithmResults.detection);
    segmentationNorm = normalizeMatrix(algorithmResults.segmentation);
    
    % Compute overall score (equal weighting)
    overallScore = (mean(classificationNorm, 2) + mean(detectionNorm, 2) + mean(segmentationNorm, 2)) / 3;
    
    [~, overallRankings.performanceRanking] = sort(overallScore, 'descend');
    overallRankings.performanceScores = overallScore;
    
    % Efficiency-weighted ranking
    runtimeNorm = normalizeMatrix(algorithmResults.runtime);
    memoryNorm = normalizeMatrix(-algorithmResults.memory); % Negative because lower is better
    
    efficiencyScore = (overallScore + mean(runtimeNorm, 2) + mean(memoryNorm, 2)) / 3;
    [~, overallRankings.efficiencyRanking] = sort(efficiencyScore, 'descend');
    overallRankings.efficiencyScores = efficiencyScore;
end

function normalizedMatrix = normalizeMatrix(matrix)
    % Normalize matrix to [0, 1] range
    
    minVals = min(matrix(:));
    maxVals = max(matrix(:));
    
    normalizedMatrix = (matrix - minVals) / (maxVals - minVals + eps);
end

function findings = generateKeyFindings(report)
    % Generate key findings from benchmark analysis
    
    findings = {};
    
    % Best performing algorithm
    bestAlgorithm = report.algorithmNames{report.overallRankings.performanceRanking(1)};
    findings{end+1} = sprintf('Best overall performer: %s', bestAlgorithm);
    
    % Most efficient algorithm
    mostEfficient = report.algorithmNames{report.overallRankings.efficiencyRanking(1)};
    findings{end+1} = sprintf('Most efficient algorithm: %s', mostEfficient);
    
    % Most robust algorithm
    mostRobust = report.algorithmNames{report.robustness.robustnessRanking(1)};
    findings{end+1} = sprintf('Most robust algorithm: %s', mostRobust);
    
    % Statistical significance
    if isfield(report.classification, 'anovaResults') && report.classification.anovaResults.pValue < 0.05
        findings{end+1} = 'Statistically significant differences found between algorithms';
        
        if isfield(report.classification, 'postHoc')
            numSignificantPairs = size(report.classification.postHoc.significantPairs, 1);
            findings{end+1} = sprintf('%d significant pairwise differences identified', numSignificantPairs);
        end
    end
    
    % Performance consistency
    avgCV = mean(report.robustness.coefficientOfVariation);
    if avgCV < 0.1
        findings{end+1} = 'Algorithms show consistent performance across datasets';
    else
        findings{end+1} = 'High performance variability observed across datasets';
    end
end
