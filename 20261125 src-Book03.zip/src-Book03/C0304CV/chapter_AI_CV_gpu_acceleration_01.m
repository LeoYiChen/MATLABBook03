%% chapter_AI_CV_gpu_acceleration_01.m
% Comprehensive Parallel Computing and GPU Acceleration Framework
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_gpu_acceleration_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Comprehensive Parallel Computing and GPU Acceleration Framework
fprintf('Parallel Computing and GPU Acceleration Framework\n');
fprintf('================================================\n');

% Check GPU availability and capabilities
gpuInfo = checkGPUCapabilities();


% 1. Basic Parallel Computing with CPU


end

    
    % Combine results from all workers
    for worker = 1:length(localResults)
        workerResults = localResults{worker};
        if ~isempty(workerResults)
            startIdx = (worker - 1) * imagesPerWorker + 1;
            endIdx = min(worker * imagesPerWorker, numImages);
            results(startIdx:endIdx) = workerResults;
        end
    end
end

% 2. GPU Array Operations

% 3. GPU Image Processing



% 4. Custom GPU Kernels



% 5. Memory Management and Optimisation




% Test all parallel computing and GPU acceleration features
fprintf('\nTesting comprehensive parallel computing framework...\n');

% Run all demonstrations
cpuParallelResults = demonstrateCPUParallelisation();
gpuArrayResults = demonstrateGPUArrays();
gpuImageResults = demonstrateGPUImageProcessing();
kernelResults = demonstrateCustomGPUKernels();
memoryResults = demonstrateGPUMemoryOptimisation();

% Visualise parallel computing results
figure;

% CPU parallelisation speedups
subplot(3, 4, 1);
if ~isempty(cpuParallelResults)
    speedups = [1, cpuParallelResults.parforSpeedup, cpuParallelResults.spmdSpeedup];
    methods = {'Sequential', 'Parfor', 'SPMD'};
    bar(speedups);
    set(gca, 'XTickLabel', methods);
    title('CPU Parallelisation Speedups');
    ylabel('Speedup Factor');
end

% GPU array operations
subplot(3, 4, 2);
if gpuArrayResults.available
    times = [gpuArrayResults.cpuTime, gpuArrayResults.gpuTime, gpuArrayResults.totalGPUTime];
    methods = {'CPU', 'GPU Compute', 'GPU Total'};
    bar(times);
    set(gca, 'XTickLabel', methods);
    title('GPU Array Performance');
    ylabel('Time (seconds)');
end

% GPU image processing
subplot(3, 4, 3);
if gpuImageResults.available
    speedup = gpuImageResults.speedup;
    bar([1, speedup]);
    set(gca, 'XTickLabel', {'CPU', 'GPU'});
    title('GPU Image Processing Speedup');
    ylabel('Speedup Factor');
end

% Custom GPU kernels
subplot(3, 4, 4);
if kernelResults.available
    speedup = kernelResults.speedup;
    bar([1, speedup]);
    set(gca, 'XTickLabel', {'Built-in', 'Custom'});
    title('Custom GPU Kernel Performance');
    ylabel('Speedup Factor');
end

% Memory strategies comparison
subplot(3, 4, [5, 6]);
if memoryResults.available
    bar(memoryResults.executionTimes);
    set(gca, 'XTickLabel', memoryResults.strategies);
    xtickangle(45);
    title('GPU Memory Strategy Performance');
    ylabel('Execution Time (seconds)');
end

% Memory usage comparison
subplot(3, 4, [7, 8]);
if memoryResults.available
    bar(memoryResults.memoryUsage / 1e6);
    set(gca, 'XTickLabel', memoryResults.strategies);
    xtickangle(45);
    title('GPU Memory Usage');
    ylabel('Peak Memory (MB)');
end

% Overall speedup comparison
subplot(3, 4, [9, 10]);
categories = {'CPU Parfor', 'CPU SPMD', 'GPU Arrays', 'GPU Images', 'GPU Kernels'};
speedups = [1, 1, 1, 1, 1]; % Default values

idx = 1;
if ~isempty(cpuParallelResults)
    speedups(idx) = cpuParallelResults.parforSpeedup;
    idx = idx + 1;
    speedups(idx) = cpuParallelResults.spmdSpeedup;
    idx = idx + 1;
end

if gpuArrayResults.available
    speedups(idx) = gpuArrayResults.speedup;
    idx = idx + 1;
end

if gpuImageResults.available
    speedups(idx) = gpuImageResults.speedup;
    idx = idx + 1;
end

if kernelResults.available
    speedups(idx) = kernelResults.speedup;
end

bar(speedups);
set(gca, 'XTickLabel', categories);
xtickangle(45);
title('Overall Parallel Computing Speedups');
ylabel('Speedup Factor');

% Performance vs memory trade-off
subplot(3, 4, [11, 12]);
if memoryResults.available
    scatter(memoryResults.memoryUsage / 1e6, 1 ./ memoryResults.executionTimes, 100, 'filled');
    xlabel('Memory Usage (MB)');
    ylabel('Performance (1/Time)');
    title('Performance vs Memory Trade-off');
    
    % Add labels
    for i = 1:length(memoryResults.strategies)
        text(memoryResults.memoryUsage(i) / 1e6, 1 / memoryResults.executionTimes(i), ...
             memoryResults.strategies{i}, 'VerticalAlignment', 'bottom');
    end
end

sgtitle('Parallel Computing and GPU Acceleration Results');

% Display comprehensive parallel computing summary
fprintf('\n' + string(repmat('=', 1, 70)) + '\n');
fprintf('PARALLEL COMPUTING AND GPU ACCELERATION SUMMARY\n');
fprintf(string(repmat('=', 1, 70)) + '\n');

fprintf('\nGPU CAPABILITIES:\n');
if gpuInfo.available
    fprintf('  Device: %s\n', gpuInfo.name);
    fprintf('  Compute Capability: %s\n', gpuInfo.computeCapability);
    fprintf('  Total Memory: %.1f GB\n', gpuInfo.totalMemory / 1e9);
    fprintf('  Multiprocessors: %d\n', gpuInfo.multiprocessorCount);
else
    fprintf('  GPU not available\n');
end

fprintf('\nCPU PARALLELISATION:\n');
if ~isempty(cpuParallelResults)
    fprintf('  Workers: %d\n', cpuParallelResults.numWorkers);
    fprintf('  Parfor speedup: %.1fx\n', cpuParallelResults.parforSpeedup);
    fprintf('  SPMD speedup: %.1fx\n', cpuParallelResults.spmdSpeedup);
    fprintf('  Efficiency (parfor): %.1f%%\n', (cpuParallelResults.parforSpeedup / cpuParallelResults.numWorkers) * 100);
end

if gpuArrayResults.available
    fprintf('\nGPU ARRAY OPERATIONS:\n');
    fprintf('  GPU computation speedup: %.1fx\n', gpuArrayResults.speedup);
    fprintf('  Overall speedup (including transfers): %.1fx\n', gpuArrayResults.overallSpeedup);
    fprintf('  Transfer overhead: %.1f%%\n', ((gpuArrayResults.transferTime + gpuArrayResults.gatherTime) / gpuArrayResults.totalGPUTime) * 100);
end

if gpuImageResults.available
    fprintf('\nGPU IMAGE PROCESSING:\n');
    fprintf('  Processing speedup: %.1fx\n', gpuImageResults.speedup);
    fprintf('  Numerical accuracy: %.2e max error\n', gpuImageResults.avgError);
end

if kernelResults.available
    fprintf('\nCUSTOM GPU KERNELS:\n');
    fprintf('  Custom kernel speedup: %.1fx\n', kernelResults.speedup);
    fprintf('  Numerical accuracy: %.2e max error\n', kernelResults.maxError);
end

if memoryResults.available
    fprintf('\nGPU MEMORY OPTIMISATION:\n');
    for i = 1:length(memoryResults.strategies)
        efficiency = memoryResults.memoryUsage(1) / memoryResults.memoryUsage(i);
        fprintf('  %s: %.1fx memory reduction\n', memoryResults.strategies{i}, efficiency);
    end
end

fprintf('\nPARALLEL COMPUTING BEST PRACTICES:\n');
fprintf('==================================\n');
fprintf(' Use parfor for embarrassingly parallel problems\n');
fprintf(' Minimise data transfer between CPU and GPU\n');
fprintf(' Batch operations to maximise GPU utilisation\n');
fprintf(' Use appropriate data types (single precision often sufficient)\n');
fprintf(' Pre-allocate GPU arrays when possible\n');
fprintf(' Consider memory bandwidth limitations\n');
fprintf(' Profile code to identify bottlenecks\n');
fprintf(' Use built-in GPU-accelerated functions when available\n');
fprintf(' Implement streaming for large datasets\n');
fprintf(' Balance parallelism with memory usage\n');

fprintf('\nDEPLOYMENT CONSIDERATIONS:\n');
fprintf('=========================\n');
fprintf(' GPU memory requirements vs available hardware\n');
fprintf(' Power consumption and thermal constraints\n');
fprintf(' Driver compatibility and maintenance\n');
fprintf(' Fallback strategies for CPU-only systems\n');
fprintf(' Performance profiling across different hardware\n');
fprintf(' Licensing considerations for deployment platforms\n');

fprintf('\n' + string(repmat('=', 1, 70)) + '\n');

% Local functions (moved to end so this listing is a valid MATLAB script)
function info = checkGPUCapabilities()
    % Check available GPU resources and capabilities
    
    fprintf('Checking GPU capabilities...\n');
    
    info = struct();
    
    try
        % Check if GPU is available
        gpu = gpuDevice();
        
        info.available = true;
        info.name = gpu.Name;
        info.computeCapability = gpu.ComputeCapability;
        info.maxThreadsPerBlock = gpu.MaxThreadsPerBlock;
        info.maxGridSize = gpu.MaxGridSize;
        info.totalMemory = gpu.TotalMemory;
        info.availableMemory = gpu.AvailableMemory;
        info.multiprocessorCount = gpu.MultiprocessorCount;
        
        fprintf('GPU detected: %s\n', info.name);
        fprintf('Compute capability: %s\n', info.computeCapability);
        fprintf('Total memory: %.1f GB\n', info.totalMemory / 1e9);
        
    catch ME
        info.available = false;
        info.error = ME.message;
        fprintf('GPU not available: %s\n', ME.message);
    end
end

function parallelResults = demonstrateCPUParallelisation()
    % Demonstrate CPU-based parallel computing techniques
    
    fprintf('Demonstrating CPU parallelisation...\n');
    
    parallelResults = struct();
    
    % Check parallel pool
    if isempty(gcp('nocreate'))
        parpool('local'); % Start parallel pool
    end
    
    % Test data
    numImages = 100;
    imageSize = [512, 512];
    images = cell(numImages, 1);
    
    for i = 1:numImages
        images{i} = uint8(rand(imageSize) * 255);
    end
    
    % Sequential processing
    tic;
    results_sequential = processImagesSequential(images);
    time_sequential = toc;
    
    % Parallel processing with parfor
    tic;
    results_parallel = processImagesParallel(images);
    time_parallel = toc;
    
    % Parallel processing with spmd
    tic;
    results_spmd = processImagesSPMD(images);
    time_spmd = toc;
    
    % Store results
    parallelResults.sequentialTime = time_sequential;
    parallelResults.parallelTime = time_parallel;
    parallelResults.spmdTime = time_spmd;
    parallelResults.parforSpeedup = time_sequential / time_parallel;
    parallelResults.spmdSpeedup = time_sequential / time_spmd;
    parallelResults.numWorkers = gcp().NumWorkers;
    
    fprintf('CPU parallelisation completed\n');
    fprintf('  Sequential: %.4f seconds\n', time_sequential);
    fprintf('  Parfor: %.4f seconds (%.1fx speedup)\n', time_parallel, parallelResults.parforSpeedup);
    fprintf('  SPMD: %.4f seconds (%.1fx speedup)\n', time_spmd, parallelResults.spmdSpeedup);
end

function results = processImagesSequential(images)
    % Sequential image processing
    
    numImages = length(images);
    results = cell(numImages, 1);
    
    for i = 1:numImages
        % Apply Gaussian filter and edge detection
        filtered = imgaussfilt(images{i}, 2);
        edges = edge(filtered, 'canny');
        results{i} = edges;
    end
end

function results = processImagesParallel(images)
    % Parallel image processing using parfor
    
    numImages = length(images);
    results = cell(numImages, 1);
    
    parfor i = 1:numImages
        % Apply Gaussian filter and edge detection
        filtered = imgaussfilt(images{i}, 2);
        edges = edge(filtered, 'canny');
        results{i} = edges;
    end

function results = processImagesSPMD(images)
    % Parallel processing using SPMD (Single Program, Multiple Data)
    
    numImages = length(images);
    results = cell(numImages, 1);
    
    spmd
        % Distribute work among workers
        numWorkers = numlabs;
        workerIndex = labindex;
        
        % Calculate work distribution
        imagesPerWorker = ceil(numImages / numWorkers);
        startIdx = (workerIndex - 1) * imagesPerWorker + 1;
        endIdx = min(workerIndex * imagesPerWorker, numImages);
        
        % Process assigned images
        localResults = cell(endIdx - startIdx + 1, 1);
        
        for i = startIdx:endIdx
            localIdx = i - startIdx + 1;
            filtered = imgaussfilt(images{i}, 2);
            edges = edge(filtered, 'canny');
            localResults{localIdx} = edges;
        end
    end

function gpuResults = demonstrateGPUArrays()
    % Demonstrate GPU array operations
    
    fprintf('Demonstrating GPU array operations...\n');
    
    gpuResults = struct();
    
    if ~gpuInfo.available
        fprintf('GPU not available, skipping GPU demonstrations\n');
        gpuResults.available = false;
        return;
    end
    
    gpuResults.available = true;
    
    % Test data
    n = 4096;
    A_cpu = rand(n, n, 'single');
    B_cpu = rand(n, n, 'single');
    
    % Transfer to GPU
    tic;
    A_gpu = gpuArray(A_cpu);
    B_gpu = gpuArray(B_cpu);
    transfer_time = toc;
    
    % CPU matrix multiplication
    tic;
    C_cpu = A_cpu * B_cpu;
    cpu_time = toc;
    
    % GPU matrix multiplication
    tic;
    C_gpu = A_gpu * B_gpu;
    wait(gpuDevice); % Synchronise GPU
    gpu_time = toc;
    
    % Transfer result back to CPU
    tic;
    C_result = gather(C_gpu);
    gather_time = toc;
    
    % Verify correctness
    max_error = max(abs(C_cpu(:) - C_result(:)));
    
    % Store results
    gpuResults.transferTime = transfer_time;
    gpuResults.cpuTime = cpu_time;
    gpuResults.gpuTime = gpu_time;
    gpuResults.gatherTime = gather_time;
    gpuResults.totalGPUTime = transfer_time + gpu_time + gather_time;
    gpuResults.speedup = cpu_time / gpu_time;
    gpuResults.overallSpeedup = cpu_time / gpuResults.totalGPUTime;
    gpuResults.maxError = max_error;
    
    fprintf('GPU array operations completed\n');
    fprintf('  CPU time: %.4f seconds\n', cpu_time);
    fprintf('  GPU computation: %.4f seconds (%.1fx speedup)\n', gpu_time, gpuResults.speedup);
    fprintf('  Total GPU time: %.4f seconds (%.1fx speedup)\n', gpuResults.totalGPUTime, gpuResults.overallSpeedup);
    fprintf('  Max error: %.2e\n', max_error);
end

function imageGPUResults = demonstrateGPUImageProcessing()
    % Demonstrate GPU-accelerated image processing
    
    fprintf('Demonstrating GPU image processing...\n');
    
    imageGPUResults = struct();
    
    if ~gpuInfo.available
        fprintf('GPU not available, skipping GPU image processing\n');
        imageGPUResults.available = false;
        return;
    end
    
    imageGPUResults.available = true;
    
    % Create test images
    numImages = 50;
    imageSize = [1024, 1024];
    images = cell(numImages, 1);
    
    for i = 1:numImages
        images{i} = rand(imageSize, 'single');
    end
    
    % CPU image processing
    tic;
    results_cpu = processImagesCPU(images);
    cpu_time = toc;
    
    % GPU image processing
    tic;
    results_gpu = processImagesGPU(images);
    gpu_time = toc;
    
    % Verify results
    totalError = 0;
    for i = 1:numImages
        totalError = totalError + sum(abs(results_cpu{i}(:) - results_gpu{i}(:)));
    end
    avgError = totalError / (numImages * prod(imageSize));
    
    imageGPUResults.cpuTime = cpu_time;
    imageGPUResults.gpuTime = gpu_time;
    imageGPUResults.speedup = cpu_time / gpu_time;
    imageGPUResults.avgError = avgError;
    
    fprintf('GPU image processing completed\n');
    fprintf('  CPU time: %.4f seconds\n', cpu_time);
    fprintf('  GPU time: %.4f seconds (%.1fx speedup)\n', gpu_time, imageGPUResults.speedup);
    fprintf('  Average error: %.2e\n', avgError);
end

function results = processImagesCPU(images)
    % CPU-based image processing pipeline
    
    numImages = length(images);
    results = cell(numImages, 1);
    
    for i = 1:numImages
        img = images{i};
        
        % Gaussian filter
        filtered = imgaussfilt(img, 2);
        
        % Sobel edge detection
        [Gx, Gy] = gradient(filtered);
        magnitude = sqrt(Gx.^2 + Gy.^2);
        
        % Threshold
        threshold = 0.1;
        edges = magnitude > threshold;
        
        results{i} = single(edges);
    end
end

function results = processImagesGPU(images)
    % GPU-accelerated image processing pipeline
    
    numImages = length(images);
    results = cell(numImages, 1);
    
    for i = 1:numImages
        % Transfer to GPU
        img_gpu = gpuArray(images{i});
        
        % Gaussian filter
        filtered_gpu = imgaussfilt(img_gpu, 2);
        
        % Sobel edge detection
        [Gx_gpu, Gy_gpu] = gradient(filtered_gpu);
        magnitude_gpu = sqrt(Gx_gpu.^2 + Gy_gpu.^2);
        
        % Threshold
        threshold = 0.1;
        edges_gpu = magnitude_gpu > threshold;
        
        % Transfer back to CPU
        results{i} = gather(single(edges_gpu));
    end
end

function kernelResults = demonstrateCustomGPUKernels()
    % Demonstrate custom GPU kernel development
    
    fprintf('Demonstrating custom GPU kernels...\n');
    
    kernelResults = struct();
    
    if ~gpuInfo.available
        fprintf('GPU not available, skipping custom kernels\n');
        kernelResults.available = false;
        return;
    end
    
    kernelResults.available = true;
    
    % Test data
    imageSize = [2048, 2048];
    image = rand(imageSize, 'single');
    kernelSize = 5;
    
    % Built-in convolution
    kernel = fspecial('gaussian', kernelSize, 1);
    tic;
    result_builtin = imfilter(image, kernel, 'same');
    builtin_time = toc;
    
    % Custom GPU kernel convolution
    tic;
    result_custom = customGPUConvolution(image, kernel);
    custom_time = toc;
    
    % Verify results
    max_error = max(abs(result_builtin(:) - result_custom(:)));
    
    kernelResults.builtinTime = builtin_time;
    kernelResults.customTime = custom_time;
    kernelResults.speedup = builtin_time / custom_time;
    kernelResults.maxError = max_error;
    
    fprintf('Custom GPU kernels completed\n');
    fprintf('  Built-in convolution: %.4f seconds\n', builtin_time);
    fprintf('  Custom GPU kernel: %.4f seconds (%.1fx speedup)\n', custom_time, kernelResults.speedup);
    fprintf('  Max error: %.2e\n', max_error);
end

function result = customGPUConvolution(image, kernel)
    % Custom GPU convolution implementation
    
    % Transfer data to GPU
    image_gpu = gpuArray(image);
    kernel_gpu = gpuArray(kernel);
    
    % Get dimensions
    [imgHeight, imgWidth] = size(image);
    [kernelHeight, kernelWidth] = size(kernel);
    
    % Pad image
    padH = floor(kernelHeight / 2);
    padW = floor(kernelWidth / 2);
    padded_image = padarray(image_gpu, [padH, padW], 'replicate');
    
    % Create output array
    result_gpu = zeros(imgHeight, imgWidth, 'gpuArray');
    
    % Apply convolution using arrayfun (element-wise GPU kernel)
    result_gpu = arrayfun(@convolutionKernel, ...
        (1:imgHeight)', ones(imgWidth, 1) * (1:imgWidth), ...
        padded_image, kernel_gpu, kernelHeight, kernelWidth, padH, padW);
    
    % Transfer result back to CPU
    result = gather(result_gpu);
end

function output = convolutionKernel(row, col, paddedImage, kernel, kernelH, kernelW, padH, padW)
    % GPU kernel function for convolution
    
    output = 0;
    
    for ki = 1:kernelH
        for kj = 1:kernelW
            imgRow = row + ki - 1;
            imgCol = col + kj - 1;
            
            output = output + paddedImage(imgRow, imgCol) * kernel(ki, kj);
        end
    end
end

function memoryResults = demonstrateGPUMemoryOptimisation()
    % Demonstrate GPU memory management techniques
    
    fprintf('Demonstrating GPU memory optimisation...\n');
    
    memoryResults = struct();
    
    if ~gpuInfo.available
        fprintf('GPU not available, skipping memory optimisation\n');
        memoryResults.available = false;
        return;
    end
    
    memoryResults.available = true;
    
    % Memory usage monitoring
    initialMemory = gpuDevice().AvailableMemory;
    
    % Test different memory strategies
    memoryResults.strategies = {};
    memoryResults.executionTimes = [];
    memoryResults.memoryUsage = [];
    
    % Strategy 1: Naive approach (create everything on GPU)
    tic;
    [time1, memory1] = naiveGPUStrategy();
    memoryResults.strategies{end+1} = 'Naive';
    memoryResults.executionTimes(end+1) = time1;
    memoryResults.memoryUsage(end+1) = memory1;
    
    % Strategy 2: Memory-conscious approach
    tic;
    [time2, memory2] = memoryConsciousStrategy();
    memoryResults.strategies{end+1} = 'Memory-conscious';
    memoryResults.executionTimes(end+1) = time2;
    memoryResults.memoryUsage(end+1) = memory2;
    
    % Strategy 3: Streaming approach
    tic;
    [time3, memory3] = streamingStrategy();
    memoryResults.strategies{end+1} = 'Streaming';
    memoryResults.executionTimes(end+1) = time3;
    memoryResults.memoryUsage(end+1) = memory3;
    
    memoryResults.initialMemory = initialMemory;
    
    fprintf('GPU memory optimisation completed\n');
    for i = 1:length(memoryResults.strategies)
        fprintf('  %s: %.4f seconds, %.1f MB peak usage\n', ...
            memoryResults.strategies{i}, memoryResults.executionTimes(i), ...
            memoryResults.memoryUsage(i) / 1e6);
    end
end

function [execTime, peakMemory] = naiveGPUStrategy()
    % Naive GPU strategy - create all data on GPU at once
    
    initialMemory = gpuDevice().AvailableMemory;
    
    tic;
    
    % Create large arrays on GPU
    A = gpuArray.rand(2000, 2000, 'single');
    B = gpuArray.rand(2000, 2000, 'single');
    C = gpuArray.rand(2000, 2000, 'single');
    
    % Perform operations
    result1 = A * B;
    result2 = result1 + C;
    result3 = sin(result2);
    
    wait(gpuDevice);
    execTime = toc;
    
    currentMemory = gpuDevice().AvailableMemory;
    peakMemory = initialMemory - currentMemory;
    
    % Clean up
    clear A B C result1 result2 result3;
end

function [execTime, peakMemory] = memoryConsciousStrategy()
    % Memory-conscious strategy - reuse memory where possible
    
    initialMemory = gpuDevice().AvailableMemory;
    
    tic;
    
    % Create arrays
    A = gpuArray.rand(2000, 2000, 'single');
    B = gpuArray.rand(2000, 2000, 'single');
    
    % Perform operations with in-place updates where possible
    result = A * B;  % Result overwrites A
    clear A;  % Explicit cleanup
    
    C = gpuArray.rand(2000, 2000, 'single');
    result = result + C;  % In-place addition
    clear C;
    
    result = sin(result);  % In-place operation
    
    wait(gpuDevice);
    execTime = toc;
    
    currentMemory = gpuDevice().AvailableMemory;
    peakMemory = initialMemory - currentMemory;
    
    clear result;
end

function [execTime, peakMemory] = streamingStrategy()
    % Streaming strategy - process data in chunks
    
    initialMemory = gpuDevice().AvailableMemory;
    minMemory = initialMemory;
    
    tic;
    
    totalSize = 2000;
    chunkSize = 500;
    
    % Process in chunks
    for i = 1:chunkSize:totalSize
        endIdx = min(i + chunkSize - 1, totalSize);
        
        % Create chunk
        A_chunk = gpuArray.rand(endIdx - i + 1, totalSize, 'single');
        B_chunk = gpuArray.rand(totalSize, endIdx - i + 1, 'single');
        
        % Process chunk
        result_chunk = A_chunk * B_chunk;
        result_chunk = sin(result_chunk);
        
        % Monitor memory
        currentMemory = gpuDevice().AvailableMemory;
        minMemory = min(minMemory, currentMemory);
        
        % Clean up chunk
        clear A_chunk B_chunk result_chunk;
    end
    
    wait(gpuDevice);
    execTime = toc;
    
    peakMemory = initialMemory - minMemory;
end
