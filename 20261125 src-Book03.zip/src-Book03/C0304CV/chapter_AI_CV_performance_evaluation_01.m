%% chapter_AI_CV_performance_evaluation_01.m
% Comprehensive Performance Evaluation Framework for Computer Vision Systems
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_performance_evaluation_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Comprehensive Performance Evaluation Framework for Computer Vision
fprintf('Computer Vision Performance Evaluation Framework\n');
fprintf('===============================================\n');

% Create synthetic evaluation dataset for demonstration
[predictions, groundTruth, confidenceScores, boundingBoxes] = createEvaluationDataset();


% 1. Classification Metrics Computation



% 2. ROC and Precision-Recall Analysis




% 3. Detection Metrics (IoU, mAP)





% 4. Calibration Analysis

% 5. Comprehensive Evaluation Report

% Test the performance evaluation framework
fprintf('\nTesting comprehensive performance evaluation...\n');

% Compute all metrics
classMetrics = computeClassificationMetrics(predictions, groundTruth);
rocMetrics = computeROCMetrics(confidenceScores, predictions == groundTruth, true);
detectionMetrics = computeDetectionMetrics(boundingBoxes.predicted, boundingBoxes.groundTruth, boundingBoxes.detectionScores);
calibrationMetrics = analyzeCalibration(predictions == groundTruth, confidenceScores);

% Generate comprehensive report
evaluationReport = generateEvaluationReport(predictions, groundTruth, confidenceScores, boundingBoxes);

% Visualise evaluation results
figure;

% Confusion matrix
subplot(3, 4, 1);
confMat = classMetrics.confusionMatrix;
imagesc(confMat);
colorbar;
title('Confusion Matrix');
xlabel('Predicted Class');
ylabel('True Class');

% ROC curve
subplot(3, 4, 2);
plot(rocMetrics.fpr, rocMetrics.tpr, 'b-', 'LineWidth', 2);
hold on;
plot([0, 1], [0, 1], 'r--', 'LineWidth', 1);
hold off;
xlabel('False Positive Rate');
ylabel('True Positive Rate');
title(sprintf('ROC Curve (AUC = %.3f)', rocMetrics.auc));
grid on;

% Precision-Recall curve
subplot(3, 4, 3);
plot(rocMetrics.recall, rocMetrics.precision, 'g-', 'LineWidth', 2);
xlabel('Recall');
ylabel('Precision');
title(sprintf('PR Curve (AP = %.3f)', rocMetrics.averagePrecision));
grid on;

% Per-class metrics
subplot(3, 4, 4);
numClasses = size(confMat, 1);
classNames = arrayfun(@(x) sprintf('C%d', x), 1:numClasses, 'UniformOutput', false);

precision = zeros(numClasses, 1);
recall = zeros(numClasses, 1);
f1Score = zeros(numClasses, 1);

for i = 1:numClasses
    className = sprintf('Class_%d', i);
    if isfield(classMetrics.classMetrics, className)
        precision(i) = classMetrics.classMetrics.*(className).precision;
        recall(i) = classMetrics.classMetrics.*(className).recall;
        f1Score(i) = classMetrics.classMetrics.*(className).f1Score;
    end
end

bar([precision, recall, f1Score]);
set(gca, 'XTickLabel', classNames);
legend({'Precision', 'Recall', 'F1-Score'});
title('Per-Class Metrics');
ylabel('Score');

% IoU distribution
subplot(3, 4, 5);
iouValues = detectionMetrics.iouMatrix(:);
histogram(iouValues, 20);
xlabel('IoU');
ylabel('Frequency');
title('IoU Distribution');

% Detection precision-recall
subplot(3, 4, 6);
plot(detectionMetrics.recall, detectionMetrics.precision, 'm-', 'LineWidth', 2);
xlabel('Recall');
ylabel('Precision');
title(sprintf('Detection PR (AP = %.3f)', detectionMetrics.averagePrecision));
grid on;

% Calibration plot
subplot(3, 4, 7);
plot(calibrationMetrics.binConfidence, calibrationMetrics.binAccuracy, 'ro-', 'LineWidth', 2);
hold on;
plot([0, 1], [0, 1], 'k--', 'LineWidth', 1);
hold off;
xlabel('Mean Predicted Probability');
ylabel('Fraction of Positives');
title(sprintf('Calibration (ECE = %.3f)', calibrationMetrics.ece));
grid on;

% Reliability histogram
subplot(3, 4, 8);
bar(calibrationMetrics.binCenters, calibrationMetrics.binCounts);
xlabel('Confidence');
ylabel('Count');
title('Confidence Distribution');

% Score distribution
subplot(3, 4, 9);
correctMask = predictions == groundTruth;
histogram(confidenceScores(correctMask), 20, 'FaceAlpha', 0.5, 'EdgeColor', 'none');
hold on;
histogram(confidenceScores(~correctMask), 20, 'FaceAlpha', 0.5, 'EdgeColor', 'none');
hold off;
xlabel('Confidence Score');
ylabel('Frequency');
title('Score Distribution');
legend({'Correct', 'Incorrect'});

% Performance summary
subplot(3, 4, 10);
summaryMetrics = [
    evaluationReport.summary.accuracy,
    evaluationReport.summary.auc,
    evaluationReport.summary.averagePrecision,
    1 - evaluationReport.summary.calibrationError
];
metricNames = {'Accuracy', 'AUC', 'AP', 'Calibration'};

bar(summaryMetrics);
set(gca, 'XTickLabel', metricNames);
xtickangle(45);
title('Performance Summary');
ylabel('Score');
ylim([0, 1]);

% Error analysis
subplot(3, 4, 11);
errorsByClass = diag(confMat) ./ sum(confMat, 2);
bar(1 - errorsByClass);
set(gca, 'XTickLabel', classNames);
title('Error Rate by Class');
ylabel('Error Rate');

% Threshold analysis
subplot(3, 4, 12);
thresholds = 0:0.1:1;
accuracyAtThreshold = zeros(size(thresholds));

for i = 1:length(thresholds)
    threshold = thresholds(i);
    thresholdPredictions = confidenceScores >= threshold;
    
    if sum(thresholdPredictions) > 0
        accuracyAtThreshold(i) = mean((predictions == groundTruth)(thresholdPredictions));
    end
end

plot(thresholds, accuracyAtThreshold, 'c-', 'LineWidth', 2);
xlabel('Confidence Threshold');
ylabel('Accuracy');
title('Accuracy vs Threshold');
grid on;

sgtitle('Comprehensive Performance Evaluation Results');

% Display detailed evaluation report
fprintf('\n' + string(repmat('=', 1, 60)) + '\n');
fprintf('COMPREHENSIVE PERFORMANCE EVALUATION REPORT\n');
fprintf(string(repmat('=', 1, 60)) + '\n');

fprintf('\nCLASSIFICATION PERFORMANCE:\n');
fprintf('  Overall Accuracy: %.3f\n', evaluationReport.summary.accuracy);
fprintf('  Macro F1-Score: %.3f\n', classMetrics.macroF1Score);
fprintf('  Weighted F1-Score: %.3f\n', classMetrics.weightedF1Score);
fprintf('  Cohen''s Kappa: %.3f\n', classMetrics.cohensKappa);

fprintf('\nROC ANALYSIS:\n');
fprintf('  AUC-ROC: %.3f\n', evaluationReport.summary.auc);
fprintf('  Average Precision: %.3f\n', evaluationReport.summary.averagePrecision);
fprintf('  Optimal Threshold: %.3f\n', rocMetrics.optimalThreshold);

if ~isempty(boundingBoxes)
    fprintf('\nDETECTION PERFORMANCE:\n');
    fprintf('  Average Precision (IoU=0.5): %.3f\n', detectionMetrics.averagePrecision);
    fprintf('  True Positives: %d\n', detectionMetrics.truePositives);
    fprintf('  False Positives: %d\n', detectionMetrics.falsePositives);
    fprintf('  False Negatives: %d\n', detectionMetrics.falseNegatives);
end

fprintf('\nCALIBRATION ANALYSIS:\n');
fprintf('  Expected Calibration Error: %.3f\n', evaluationReport.summary.calibrationError);
fprintf('  Maximum Calibration Error: %.3f\n', calibrationMetrics.mce);

fprintf('\nPERFORMANCE INSIGHTS:\n');
fprintf('==============================\n');
if evaluationReport.summary.accuracy > 0.9
    fprintf(' Excellent classification performance\n');
elseif evaluationReport.summary.accuracy > 0.8
    fprintf(' Good classification performance\n');
else
    fprintf(' Classification performance needs improvement\n');
end

if evaluationReport.summary.auc > 0.9
    fprintf(' Excellent discriminative ability\n');
elseif evaluationReport.summary.auc > 0.8
    fprintf(' Good discriminative ability\n');
else
    fprintf(' Discriminative ability needs improvement\n');
end

if evaluationReport.summary.calibrationError < 0.05
    fprintf(' Well-calibrated confidence estimates\n');
elseif evaluationReport.summary.calibrationError < 0.1
    fprintf(' Moderately calibrated confidence estimates\n');
else
    fprintf(' Poorly calibrated confidence estimates - consider calibration techniques\n');
end

fprintf('\nRECOMMENDATIONS:\n');
fprintf('===============\n');
fprintf('1. Model Performance:\n');
if evaluationReport.summary.accuracy < 0.85
    fprintf('    Consider ensemble methods or model architecture improvements\n');
    fprintf('    Increase training data or apply data augmentation\n');
    fprintf('    Investigate class imbalance issues\n');
end

fprintf('\n2. Calibration:\n');
if evaluationReport.summary.calibrationError > 0.05
    fprintf('    Apply Platt scaling or isotonic regression for calibration\n');
    fprintf('    Consider temperature scaling for neural networks\n');
    fprintf('    Validate calibration on held-out data\n');
end

fprintf('\n3. Detection Performance:\n');
if ~isempty(boundingBoxes) && detectionMetrics.averagePrecision < 0.5
    fprintf('    Improve localisation accuracy\n');
    fprintf('    Adjust anchor sizes and aspect ratios\n');
    fprintf('    Increase IoU threshold for training\n');
end

fprintf('\n4. Deployment Considerations:\n');
fprintf('    Monitor performance on production data\n');
fprintf('    Implement A/B testing for model updates\n');
fprintf('    Set up performance alerts and monitoring\n');
fprintf('    Regular model retraining with new data\n');

fprintf('\n' + string(repmat('=', 1, 60)) + '\n');

% Local functions (moved to end so this listing is a valid MATLAB script)
function [pred, gt, conf, boxes] = createEvaluationDataset()
    % Create synthetic evaluation dataset with various scenarios
    
    fprintf('Creating synthetic evaluation dataset...\n');
    
    numSamples = 1000;
    numClasses = 5;
    
    % Generate ground truth labels
    gt = randi(numClasses, numSamples, 1);
    
    % Generate predictions with varying accuracy by class
    pred = zeros(numSamples, 1);
    conf = zeros(numSamples, 1);
    
    for i = 1:numSamples
        trueClass = gt(i);
        
        % Simulate different class-specific accuracies
        classAccuracy = 0.7 + (trueClass - 1) * 0.05; % 70% to 90% accuracy range
        
        if rand() < classAccuracy
            % Correct prediction
            pred(i) = trueClass;
            conf(i) = 0.8 + rand() * 0.19; % High confidence for correct predictions
        else
            % Incorrect prediction
            wrongClasses = setdiff(1:numClasses, trueClass);
            pred(i) = wrongClasses(randi(length(wrongClasses)));
            conf(i) = 0.4 + rand() * 0.4; % Lower confidence for incorrect predictions
        end
    end
    
    % Generate bounding box data for detection evaluation
    boxes = struct();
    numDetections = 500;
    
    % Ground truth bounding boxes
    boxes.groundTruth = rand(numDetections, 4) * 100; % [x, y, width, height]
    boxes.groundTruth(:, 3:4) = 10 + boxes.groundTruth(:, 3:4) * 20; % Reasonable sizes
    
    % Predicted bounding boxes with noise
    boxes.predicted = boxes.groundTruth + randn(size(boxes.groundTruth)) * 5;
    boxes.predicted(:, 3:4) = max(5, boxes.predicted(:, 3:4)); % Ensure positive sizes
    
    % Detection confidence scores
    boxes.detectionScores = 0.3 + rand(numDetections, 1) * 0.7;
    
    fprintf('Created evaluation dataset: %d samples, %d classes\n', numSamples, numClasses);
end

function metrics = computeClassificationMetrics(predictions, groundTruth, classNames)
    % Compute comprehensive classification metrics
    
    if nargin < 3
        classNames = arrayfun(@(x) sprintf('Class_%d', x), 1:max(groundTruth), 'UniformOutput', false);
    end
    
    fprintf('Computing classification metrics...\n');
    
    metrics = struct();
    
    % Confusion matrix
    confMat = confusionmat(groundTruth, predictions);
    metrics.confusionMatrix = confMat;
    
    % Overall accuracy
    metrics.accuracy = sum(predictions == groundTruth) / length(groundTruth);
    
    % Per-class metrics
    numClasses = length(classNames);
    metrics.classMetrics = struct();
    
    precision = zeros(numClasses, 1);
    recall = zeros(numClasses, 1);
    f1Score = zeros(numClasses, 1);
    specificity = zeros(numClasses, 1);
    
    for i = 1:numClasses
        % True positives, false positives, false negatives, true negatives
        tp = confMat(i, i);
        fp = sum(confMat(:, i)) - tp;
        fn = sum(confMat(i, :)) - tp;
        tn = sum(confMat(:)) - tp - fp - fn;
        
        % Calculate metrics
        precision(i) = tp / (tp + fp + eps);
        recall(i) = tp / (tp + fn + eps);
        f1Score(i) = 2 * precision(i) * recall(i) / (precision(i) + recall(i) + eps);
        specificity(i) = tn / (tn + fp + eps);
        
        % Store class-specific metrics
        className = classNames{i};
        metrics.classMetrics.*(className) = struct();
        metrics.classMetrics.*(className).precision = precision(i);
        metrics.classMetrics.*(className).recall = recall(i);
        metrics.classMetrics.*(className).f1Score = f1Score(i);
        metrics.classMetrics.*(className).specificity = specificity(i);
        metrics.classMetrics.*(className).support = sum(groundTruth == i);
    end
    
    % Macro and micro averages
    metrics.macroPrecision = mean(precision);
    metrics.macroRecall = mean(recall);
    metrics.macroF1Score = mean(f1Score);
    
    % Weighted averages
    support = arrayfun(@(i) sum(groundTruth == i), 1:numClasses);
    totalSupport = sum(support);
    
    metrics.weightedPrecision = sum(precision .* support') / totalSupport;
    metrics.weightedRecall = sum(recall .* support') / totalSupport;
    metrics.weightedF1Score = sum(f1Score .* support') / totalSupport;
    
    % Cohen's Kappa
    metrics.cohensKappa = computeCohensKappa(confMat);
    
    % Matthews Correlation Coefficient (for binary classification)
    if numClasses == 2
        metrics.mcc = computeMCC(confMat);
    end
    
    fprintf('Classification metrics computed\n');
end

function kappa = computeCohensKappa(confMat)
    % Compute Cohen's Kappa coefficient
    
    n = sum(confMat(:));
    po = trace(confMat) / n; % Observed agreement
    
    % Expected agreement
    rowSums = sum(confMat, 2);
    colSums = sum(confMat, 1);
    pe = sum(rowSums .* colSums') / n^2;
    
    kappa = (po - pe) / (1 - pe + eps);
end

function mcc = computeMCC(confMat)
    % Compute Matthews Correlation Coefficient for binary classification
    
    tp = confMat(1, 1);
    tn = confMat(2, 2);
    fp = confMat(2, 1);
    fn = confMat(1, 2);
    
    numerator = tp * tn - fp * fn;
    denominator = sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn));
    
    mcc = numerator / (denominator + eps);
end

function rocMetrics = computeROCMetrics(scores, labels, positiveClass)
    % Compute ROC and Precision-Recall metrics
    
    if nargin < 3
        positiveClass = 1;
    end
    
    fprintf('Computing ROC and PR metrics...\n');
    
    rocMetrics = struct();
    
    % Convert to binary problem
    binaryLabels = (labels == positiveClass);
    
    % ROC curve
    [X, Y, T, AUC] = perfcurve(binaryLabels, scores, true);
    
    rocMetrics.fpr = X; % False positive rate
    rocMetrics.tpr = Y; % True positive rate (sensitivity/recall)
    rocMetrics.thresholds = T;
    rocMetrics.auc = AUC;
    
    % Precision-Recall curve
    [precision, recall, prThresholds] = computePrecisionRecallCurve(scores, binaryLabels);
    
    rocMetrics.precision = precision;
    rocMetrics.recall = recall;
    rocMetrics.prThresholds = prThresholds;
    rocMetrics.averagePrecision = computeAveragePrecision(precision, recall);
    
    % Optimal threshold selection
    rocMetrics.optimalThreshold = findOptimalThreshold(X, Y, T);
    
    fprintf('ROC analysis completed: AUC = %.3f, AP = %.3f\n', ...
        rocMetrics.auc, rocMetrics.averagePrecision);
end

function [precision, recall, thresholds] = computePrecisionRecallCurve(scores, labels)
    % Compute precision-recall curve
    
    % Sort scores in descending order
    [sortedScores, sortIdx] = sort(scores, 'descend');
    sortedLabels = labels(sortIdx);
    
    % Unique thresholds
    thresholds = unique(sortedScores);
    thresholds = [thresholds; min(thresholds) - 1]; % Add lowest threshold
    
    precision = zeros(length(thresholds), 1);
    recall = zeros(length(thresholds), 1);
    
    totalPositives = sum(labels);
    
    for i = 1:length(thresholds)
        threshold = thresholds(i);
        predictions = scores >= threshold;
        
        tp = sum(predictions & labels);
        fp = sum(predictions & ~labels);
        
        precision(i) = tp / (tp + fp + eps);
        recall(i) = tp / (totalPositives + eps);
    end
end

function ap = computeAveragePrecision(precision, recall)
    % Compute Average Precision using interpolation
    
    % Sort by recall
    [sortedRecall, sortIdx] = sort(recall);
    sortedPrecision = precision(sortIdx);
    
    % Remove duplicates
    [uniqueRecall, uniqueIdx] = unique(sortedRecall);
    uniquePrecision = sortedPrecision(uniqueIdx);
    
    % Interpolate precision
    ap = 0;
    for i = 1:(length(uniqueRecall)-1)
        recallDiff = uniqueRecall(i+1) - uniqueRecall(i);
        ap = ap + uniquePrecision(i) * recallDiff;
    end
end

function optimalThreshold = findOptimalThreshold(fpr, tpr, thresholds)
    % Find optimal threshold using Youden's index
    
    youdenIndex = tpr - fpr;
    [~, maxIdx] = max(youdenIndex);
    optimalThreshold = thresholds(maxIdx);
end

function detectionMetrics = computeDetectionMetrics(predictedBoxes, groundTruthBoxes, scores, iouThreshold)
    % Compute object detection metrics
    
    if nargin < 4
        iouThreshold = 0.5;
    end
    
    fprintf('Computing detection metrics...\n');
    
    detectionMetrics = struct();
    
    % Compute IoU for all prediction-ground truth pairs
    iouMatrix = computeIoUMatrix(predictedBoxes, groundTruthBoxes);
    
    % Match predictions to ground truth
    [matches, matchScores] = matchDetections(iouMatrix, scores, iouThreshold);
    
    % Compute precision-recall for detection
    [precision, recall, ap] = computeDetectionPR(matches, matchScores, length(groundTruthBoxes));
    
    detectionMetrics.iouMatrix = iouMatrix;
    detectionMetrics.matches = matches;
    detectionMetrics.precision = precision;
    detectionMetrics.recall = recall;
    detectionMetrics.averagePrecision = ap;
    detectionMetrics.iouThreshold = iouThreshold;
    
    % Additional metrics
    detectionMetrics.totalDetections = size(predictedBoxes, 1);
    detectionMetrics.totalGroundTruth = size(groundTruthBoxes, 1);
    detectionMetrics.truePositives = sum(matches);
    detectionMetrics.falsePositives = detectionMetrics.totalDetections - detectionMetrics.truePositives;
    detectionMetrics.falseNegatives = detectionMetrics.totalGroundTruth - detectionMetrics.truePositives;
    
    fprintf('Detection metrics computed: AP = %.3f at IoU = %.2f\n', ap, iouThreshold);
end

function iouMatrix = computeIoUMatrix(boxes1, boxes2)
    % Compute Intersection over Union matrix
    
    numBoxes1 = size(boxes1, 1);
    numBoxes2 = size(boxes2, 1);
    iouMatrix = zeros(numBoxes1, numBoxes2);
    
    for i = 1:numBoxes1
        for j = 1:numBoxes2
            iouMatrix(i, j) = computeIoU(boxes1(i, :), boxes2(j, :));
        end
    end
end

function iou = computeIoU(box1, box2)
    % Compute Intersection over Union for two bounding boxes
    % Format: [x, y, width, height]
    
    % Convert to [x1, y1, x2, y2] format
    x1_1 = box1(1);
    y1_1 = box1(2);
    x2_1 = box1(1) + box1(3);
    y2_1 = box1(2) + box1(4);
    
    x1_2 = box2(1);
    y1_2 = box2(2);
    x2_2 = box2(1) + box2(3);
    y2_2 = box2(2) + box2(4);
    
    % Compute intersection
    intersectionX1 = max(x1_1, x1_2);
    intersectionY1 = max(y1_1, y1_2);
    intersectionX2 = min(x2_1, x2_2);
    intersectionY2 = min(y2_1, y2_2);
    
    % Check if there's an intersection
    if intersectionX2 > intersectionX1 && intersectionY2 > intersectionY1
        intersectionArea = (intersectionX2 - intersectionX1) * (intersectionY2 - intersectionY1);
    else
        intersectionArea = 0;
    end
    
    % Compute union
    area1 = box1(3) * box1(4);
    area2 = box2(3) * box2(4);
    unionArea = area1 + area2 - intersectionArea;
    
    % Compute IoU
    iou = intersectionArea / (unionArea + eps);
end

function [matches, matchScores] = matchDetections(iouMatrix, scores, iouThreshold)
    % Match detections to ground truth using greedy algorithm
    
    [numDetections, numGroundTruth] = size(iouMatrix);
    matches = false(numDetections, 1);
    matchScores = scores;
    
    % Sort detections by confidence score
    [~, sortIdx] = sort(scores, 'descend');
    
    usedGroundTruth = false(numGroundTruth, 1);
    
    for i = 1:numDetections
        detIdx = sortIdx(i);
        
        % Find best matching ground truth
        [maxIoU, gtIdx] = max(iouMatrix(detIdx, :));
        
        % Check if IoU exceeds threshold and ground truth not already used
        if maxIoU >= iouThreshold && ~usedGroundTruth(gtIdx)
            matches(detIdx) = true;
            usedGroundTruth(gtIdx) = true;
        end
    end
end

function [precision, recall, ap] = computeDetectionPR(matches, scores, numGroundTruth)
    % Compute precision-recall curve for detection
    
    % Sort by confidence score
    [~, sortIdx] = sort(scores, 'descend');
    sortedMatches = matches(sortIdx);
    
    % Compute cumulative precision and recall
    tp = cumsum(sortedMatches);
    fp = cumsum(~sortedMatches);
    
    precision = tp ./ (tp + fp + eps);
    recall = tp / numGroundTruth;
    
    % Compute Average Precision using 11-point interpolation
    ap = 0;
    for t = 0:0.1:1
        precisionAtRecall = max(precision(recall >= t));
        if isempty(precisionAtRecall)
            precisionAtRecall = 0;
        end
        ap = ap + precisionAtRecall / 11;
    end
end

function calibrationMetrics = analyzeCalibration(predictions, confidences, numBins)
    % Analyze model calibration
    
    if nargin < 3
        numBins = 10;
    end
    
    fprintf('Analyzing model calibration...\n');
    
    calibrationMetrics = struct();
    
    % Create confidence bins
    binEdges = linspace(0, 1, numBins + 1);
    binCenters = (binEdges(1:end-1) + binEdges(2:end)) / 2;
    
    % Compute accuracy and confidence for each bin
    binAccuracy = zeros(numBins, 1);
    binConfidence = zeros(numBins, 1);
    binCounts = zeros(numBins, 1);
    
    for i = 1:numBins
        binMask = confidences > binEdges(i) & confidences <= binEdges(i+1);
        
        if i == numBins % Include 1.0 in the last bin
            binMask = confidences > binEdges(i) & confidences <= binEdges(i+1) | confidences == 1.0;
        end
        
        binCounts(i) = sum(binMask);
        
        if binCounts(i) > 0
            binAccuracy(i) = mean(predictions(binMask));
            binConfidence(i) = mean(confidences(binMask));
        end
    end
    
    % Expected Calibration Error (ECE)
    ece = sum(binCounts .* abs(binAccuracy - binConfidence)) / length(predictions);
    
    % Maximum Calibration Error (MCE)
    mce = max(abs(binAccuracy - binConfidence));
    
    % Store results
    calibrationMetrics.binEdges = binEdges;
    calibrationMetrics.binCenters = binCenters;
    calibrationMetrics.binAccuracy = binAccuracy;
    calibrationMetrics.binConfidence = binConfidence;
    calibrationMetrics.binCounts = binCounts;
    calibrationMetrics.ece = ece;
    calibrationMetrics.mce = mce;
    
    fprintf('Calibration analysis completed: ECE = %.3f, MCE = %.3f\n', ece, mce);
end

function evaluationReport = generateEvaluationReport(predictions, groundTruth, confidences, boundingBoxes)
    % Generate comprehensive evaluation report
    
    fprintf('Generating comprehensive evaluation report...\n');
    
    evaluationReport = struct();
    evaluationReport.timestamp = datetime('now');
    
    % Classification metrics
    classificationMetrics = computeClassificationMetrics(predictions, groundTruth);
    evaluationReport.classification = classificationMetrics;
    
    % ROC analysis
    rocMetrics = computeROCMetrics(confidences, predictions == groundTruth, true);
    evaluationReport.roc = rocMetrics;
    
    % Detection metrics (if bounding box data available)
    if ~isempty(boundingBoxes)
        detectionMetrics = computeDetectionMetrics(boundingBoxes.predicted, ...
            boundingBoxes.groundTruth, boundingBoxes.detectionScores);
        evaluationReport.detection = detectionMetrics;
    end
    
    % Calibration analysis
    calibrationMetrics = analyzeCalibration(predictions == groundTruth, confidences);
    evaluationReport.calibration = calibrationMetrics;
    
    % Summary statistics
    evaluationReport.summary = struct();
    evaluationReport.summary.totalSamples = length(predictions);
    evaluationReport.summary.accuracy = classificationMetrics.accuracy;
    evaluationReport.summary.auc = rocMetrics.auc;
    evaluationReport.summary.averagePrecision = rocMetrics.averagePrecision;
    evaluationReport.summary.calibrationError = calibrationMetrics.ece;
    
    fprintf('Evaluation report generated successfully\n');
end
