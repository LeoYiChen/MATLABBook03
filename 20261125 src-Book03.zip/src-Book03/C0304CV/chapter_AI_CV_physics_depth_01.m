%% chapter_AI_CV_physics_depth_01.m
% Physics-based Depth Estimation: Defocus and Photometric Methods
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_physics_depth_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Physics-based Depth Estimation Implementation
fprintf('Physics-based Depth Estimation: Defocus and Photometric Methods\n');
fprintf('===============================================================\n');

% 1. Depth from Defocus Implementation


% 2. Photometric Stereo Implementation



% 3. Atmospheric Perspective Depth Estimation




% Create test data for physics-based depth estimation
fprintf('Creating test data for physics-based depth estimation...\n');

% Generate synthetic images for defocus testing
imageSize = [200, 300, 3];
[testImage1, testImage2, trueDepth] = createDefocusTestImages(imageSize);


% Test depth from defocus
cameraParams = struct();
cameraParams.focalLength = 50;          % mm
cameraParams.apertureDiameter = 5;      % mm
cameraParams.focusDistance1 = 400;      % mm (near focus)
cameraParams.focusDistance2 = 1200;     % mm (far focus)
cameraParams.pixelSize = 0.005;         % mm per pixel

depthFromDefocusResult = depthFromDefocus(testImage1, testImage2, cameraParams);

% Create test data for photometric stereo
numLights = 4;
lightDirections = [
    [1, 0, 1];    % Light from right
    [-1, 0, 1];   % Light from left
    [0, 1, 1];    % Light from top
    [0, -1, 1]    % Light from bottom
];

% Normalize light directions
for i = 1:size(lightDirections, 1)
    lightDirections(i, :) = lightDirections(i, :) / norm(lightDirections(i, :));
end

% Generate synthetic photometric stereo images
[photometricImages, trueNormals] = createPhotometricStereoImages(imageSize, lightDirections);


% Test photometric stereo
[psDepthMap, psNormalMap] = photometricStereo(photometricImages, lightDirections');

% Test atmospheric depth estimation
% Create hazy image
hazyImage = createHazyImage(imageSize);
atmosphericDepthResult = atmosphericDepthEstimation(hazyImage);


% Visualize physics-based depth estimation results
figure;

% Depth from defocus results
subplot(2, 4, 1);
imshow(testImage1);
title('Image 1 (Near Focus)');

subplot(2, 4, 2);
imshow(testImage2);
title('Image 2 (Far Focus)');

subplot(2, 4, 3);
imshow(trueDepth, []);
colormap(gca, 'jet');
colorbar;
title('True Depth');

subplot(2, 4, 4);
imshow(depthFromDefocusResult, []);
colormap(gca, 'jet');
colorbar;
title('Defocus Depth Estimate');

% Photometric stereo results
subplot(2, 4, 5);
if ~isempty(photometricImages)
    imshow(photometricImages{1});
end
title('Photometric Image 1');

subplot(2, 4, 6);
normal_rgb = (psNormalMap + 1) / 2; % Convert to [0,1] range for display
imshow(normal_rgb);
title('Estimated Normals');

subplot(2, 4, 7);
imshow(psDepthMap, []);
colormap(gca, 'jet');
colorbar;
title('Photometric Depth');

% Atmospheric depth
subplot(2, 4, 8);
imshow(atmosphericDepthResult, []);
colormap(gca, 'jet');
colorbar;
title('Atmospheric Depth');

sgtitle('Physics-based Depth Estimation Methods');

% Performance analysis and comparison
fprintf('\nPhysics-based Depth Estimation Analysis:\n');
fprintf('=======================================\n');

fprintf('Depth from Defocus:\n');
fprintf('  Advantages: Works with single camera, good for close objects\n');
fprintf('  Limitations: Requires multiple focus settings, sensitive to noise\n');
fprintf('  Applications: Microscopy, macro photography, material inspection\n');

fprintf('\nPhotometric Stereo:\n');
fprintf('  Advantages: High surface detail, robust to texture variations\n');
fprintf('  Limitations: Requires controlled lighting, assumes Lambertian surfaces\n');
fprintf('  Applications: 3*D scanning, surface inspection, archaeology\n');

fprintf('\nAtmospheric Perspective:\n');
fprintf('  Advantages: Works with single image, no special equipment\n');
fprintf('  Limitations: Limited to outdoor scenes with haze/fog\n');
fprintf('  Applications: Landscape photography, autonomous driving\n');

% Comparison with learning-based methods
fprintf('\nPhysics-based vs Learning-based Comparison:\n');
fprintf('==========================================\n');
fprintf('Physics-based Advantages:\n');
fprintf('+ Physically interpretable results\n');
fprintf('+ No training data required\n');
fprintf('+ Predictable behavior\n');
fprintf('+ Work well in controlled conditions\n');

fprintf('\nLearning-based Advantages:\n');
fprintf('+ Handle complex scenes and lighting\n');
fprintf('+ Robust to noise and variations\n');
fprintf('+ Can learn from diverse data\n');
fprintf('+ Better generalization across domains\n');

fprintf('\nHybrid Approaches:\n');
fprintf('+ Combine physical models with learned priors\n');
fprintf('+ Use physics for initialization and learning for refinement\n');
fprintf('+ Maintain interpretability while improving robustness\n');

% Best practices summary
fprintf('\nBest Practices for Physics-based Depth Estimation:\n');
fprintf('=================================================\n');
fprintf('1. Choose method based on imaging constraints and requirements\n');
fprintf('2. Calibrate camera and lighting parameters carefully\n');
fprintf('3. Consider environmental factors (lighting, atmosphere)\n');
fprintf('4. Validate assumptions (Lambertian surfaces, atmospheric conditions)\n');
fprintf('5. Combine multiple cues when possible for robustness\n');
fprintf('6. Use physics-based methods for initialization in learning systems\n');
fprintf('7. Consider computational requirements for real-time applications\n');
fprintf('8. Validate results against ground truth when available\n');

% Local functions (moved to end so this listing is a valid MATLAB script)
function depthMap = depthFromDefocus(image1, image2, cameraParams)
    % Estimate depth from defocus blur using two differently focused images
    % image1: focused at near distance
    % image2: focused at far distance
    
    fprintf('Computing depth from defocus blur...\n');
    
    % Convert to grayscale if needed
    if size(image1, 3) == 3
        gray1 = rgb2gray(image1);
        gray2 = rgb2gray(image2);
    else
        gray1 = image1;
        gray2 = image2;
    end
    
    % Convert to double for processing
    gray1 = double(gray1);
    gray2 = double(gray2);
    
    [height, width] = size(gray1);
    depthMap = zeros(height, width);
    
    % Processing parameters
    windowSize = 15; % Local analysis window
    halfWindow = floor(windowSize / 2);
    
    % Camera parameters for defocus calculation
    focalLength = cameraParams.focalLength; % mm
    apertureDiameter = cameraParams.apertureDiameter; % mm
    focusDistance1 = cameraParams.focusDistance1; % mm (near focus)
    focusDistance2 = cameraParams.focusDistance2; % mm (far focus)
    pixelSize = cameraParams.pixelSize; % mm per pixel
    
    fprintf('Camera parameters:\n');
    fprintf('  Focal length: %.1f mm\n', focalLength);
    fprintf('  Aperture diameter: %.1f mm\n', apertureDiameter);
    fprintf('  Focus distances: %.1f mm, %.1f mm\n', focusDistance1, focusDistance2);
    
    % Compute local blur measures
    for y = (halfWindow + 1):(height - halfWindow)
        for x = (halfWindow + 1):(width - halfWindow)
            % Extract local windows
            window1 = gray1((y-halfWindow):(y+halfWindow), (x-halfWindow):(x+halfWindow));
            window2 = gray2((y-halfWindow):(y+halfWindow), (x-halfWindow):(x+halfWindow));
            
            % Compute local variance as blur measure
            variance1 = var(window1(:));
            variance2 = var(window2(:));
            
            % Compute relative blur ratio
            if variance1 + variance2 > 0
                blurRatio = variance1 / (variance1 + variance2);
            else
                blurRatio = 0.5; % Default for textureless regions
            end
            
            % Convert blur ratio to depth estimate
            % This is a simplified model - real implementation would use
            % more sophisticated circle of confusion analysis
            depth = estimateDepthFromBlurRatio(blurRatio, focalLength, apertureDiameter, ...
                                             focusDistance1, focusDistance2);
            
            depthMap(y, x) = depth;
        end
        
        if mod(y, 50) == 0
            fprintf('Processing row %d/%d\n', y, height);
        end
    end
    
    % Apply spatial smoothing
    depthMap = imgaussfilt(depthMap, 2);
    
    fprintf('Depth from defocus computation completed\n');
end

function depth = estimateDepthFromBlurRatio(blurRatio, focalLength, apertureDiameter, focusDist1, focusDist2)
    % Estimate depth based on relative blur between two focus settings
    
    % Interpolate between focus distances based on blur ratio
    % This is a simplified model - real applications would use more sophisticated optics
    
    if blurRatio > 0.6
        % More in focus at near distance
        depth = focusDist1 + (focusDist2 - focusDist1) * (1 - blurRatio) * 2;
    elseif blurRatio < 0.4
        % More in focus at far distance  
        depth = focusDist2 + (focusDist1 - focusDist2) * blurRatio * 2;
    else
        % Intermediate focus
        depth = (focusDist1 + focusDist2) / 2;
    end
    
    % Ensure depth is within reasonable range
    depth = max(focusDist1 * 0.5, min(focusDist2 * 2, depth));
end

function [depthMap, normalMap] = photometricStereo(images, lightDirections, albedoMap)
    % Estimate surface normals and depth using photometric stereo
    % images: cell array of images under different lighting
    % lightDirections: 3*xN matrix of light directions
    % albedoMap: surface albedo (optional)
    
    fprintf('Computing depth using photometric stereo...\n');
    
    numImages = length(images);
    [height, width, ~] = size(images{1});
    
    % Convert images to grayscale and normalize
    grayImages = cell(numImages, 1);
    for i = 1:numImages
        if size(images{i}, 3) == 3
            grayImages{i} = rgb2gray(images{i});
        else
            grayImages{i} = images{i};
        end
        grayImages{i} = double(grayImages{i}) / 255;
    end
    
    % Initialize output arrays
    normalMap = zeros(height, width, 3);
    depthMap = zeros(height, width);
    
    if nargin < 3 || isempty(albedoMap)
        albedoMap = ones(height, width); % Assume unit albedo
    end
    
    fprintf('Processing %d images with %d light directions\n', numImages, size(lightDirections, 2));
    
    % Solve for surface normals at each pixel
    for y = 1:height
        for x = 1:width
            % Extract intensities for this pixel across all images
            intensities = zeros(numImages, 1);
            for i = 1:numImages
                intensities(i) = grayImages{i}(y, x);
            end
            
            % Solve for surface normal using least squares
            % I = 老 * n ﹞ l, where I is intensity, 老 is albedo, n is normal, l is light direction
            if sum(intensities) > 0.1 % Avoid dark regions
                normal = solveSurfaceNormal(intensities, lightDirections', albedoMap(y, x));
                normalMap(y, x, :) = normal;
            end
        end
        
        if mod(y, 50) == 0
            fprintf('Processing row %d/%d\n', y, height);
        end
    end
    
    % Integrate surface normals to recover depth
    depthMap = integrateNormals(normalMap);
    
    fprintf('Photometric stereo computation completed\n');
end

function normal = solveSurfaceNormal(intensities, lightDirections, albedo)
    % Solve for surface normal from intensities and light directions
    
    % Remove zero intensities and corresponding light directions
    validIdx = intensities > 0.01;
    if sum(validIdx) < 3
        normal = [0, 0, 1]; % Default to surface normal pointing towards camera
        return;
    end
    
    validIntensities = intensities(validIdx);
    validLights = lightDirections(validIdx, :);
    
    try
        % Solve: I = 老 * L * n
        % where I is intensities, L is light directions, n is normal, 老 is albedo
        n_scaled = validLights \ validIntensities;
        
        % Extract albedo and normal
        albedo_estimated = norm(n_scaled);
        if albedo_estimated > 0
            normal = n_scaled / albedo_estimated;
        else
            normal = [0, 0, 1];
        end
        
        % Ensure normal points towards camera (positive z)
        if normal(3) < 0
            normal = -normal;
        end
        
        % Normalize
        normal = normal / norm(normal);
        
    catch
        normal = [0, 0, 1]; % Default normal
    end
end

function depthMap = integrateNormals(normalMap)
    % Integrate surface normals to recover depth map
    % This is a simplified integration - real implementations use more sophisticated methods
    
    [height, width, ~] = size(normalMap);
    depthMap = zeros(height, width);
    
    % Extract normal components
    nx = normalMap(:, :, 1);
    ny = normalMap(:, :, 2);
    nz = normalMap(:, :, 3);
    
    % Avoid division by zero
    nz(abs(nz) < 0.1) = 0.1;
    
    % Compute gradients: p = -nx/nz, q = -ny/nz
    p = -nx ./ nz;
    q = -ny ./ nz;
    
    % Simple integration by cumulative sum (Frankot-Chellappa would be better)
    for y = 2:height
        for x = 2:width
            % Integrate gradients
            depthMap(y, x) = depthMap(y-1, x) + q(y, x) + depthMap(y, x-1) + p(y, x) - depthMap(y-1, x-1);
        end
    end
    
    % Normalize depth map
    depthMap = depthMap - min(depthMap(:));
    if max(depthMap(:)) > 0
        depthMap = depthMap / max(depthMap(:));
    end
end

function depthMap = atmosphericDepthEstimation(image, atmosphereParams)
    % Estimate depth using atmospheric perspective (haze/fog effects)
    
    fprintf('Computing depth from atmospheric perspective...\n');
    
    if size(image, 3) == 3
        grayImage = rgb2gray(image);
    else
        grayImage = image;
    end
    
    grayImage = double(grayImage) / 255;
    [height, width] = size(grayImage);
    
    % Atmospheric scattering model parameters
    if nargin < 2
        atmosphereParams = struct();
        atmosphereParams.scatteringCoeff = 0.1; % Scattering coefficient
        atmosphereParams.airlight = 0.8;        % Airlight intensity
        atmosphereParams.maxDepth = 5000;       % Maximum depth in mm
    end
    
    % Estimate atmospheric transmission
    % Dark channel prior can be used for haze removal and depth estimation
    darkChannel = computeDarkChannel(image);
    
    % Estimate airlight
    airlight = estimateAirlight(image, darkChannel);
    
    % Estimate transmission map
    transmissionMap = estimateTransmission(image, airlight, atmosphereParams.scatteringCoeff);
    
    % Convert transmission to depth
    % t = exp(-汕 * d), where t is transmission, 汕 is scattering coefficient, d is depth
    depthMap = -log(max(transmissionMap, 0.1)) / atmosphereParams.scatteringCoeff;
    
    % Scale to meaningful depth range
    depthMap = depthMap * atmosphereParams.maxDepth / max(depthMap(:));
    
    fprintf('Atmospheric depth estimation completed\n');
end

function darkChannel = computeDarkChannel(image)
    % Compute dark channel prior for haze analysis
    
    if size(image, 3) == 1
        image = repmat(image, [1, 1, 3]);
    end
    
    % Dark channel is minimum over color channels in local patch
    patchSize = 15;
    minImage = min(image, [], 3);
    
    % Apply morphological erosion to get local minimum
    se = strel('square', patchSize);
    darkChannel = imerode(minImage, se);
end

function airlight = estimateAirlight(image, darkChannel)
    % Estimate atmospheric light from brightest pixels in dark channel
    
    [~, indices] = sort(darkChannel(:), 'descend');
    numPixels = round(0.001 * numel(darkChannel)); % Top 0.1%
    
    airlight = [0, 0, 0];
    for i = 1:numPixels
        [y, x] = ind2sub(size(darkChannel), indices(i));
        
        if size(image, 3) == 3
            pixelValue = squeeze(image(y, x, :));
        else
            pixelValue = [image(y, x), image(y, x), image(y, x)];
        end
        
        if sum(pixelValue) > sum(airlight)
            airlight = pixelValue;
        end
    end
    
    airlight = double(airlight) / 255;
end

function transmission = estimateTransmission(image, airlight, omega)
    % Estimate transmission map for atmospheric scattering
    
    if nargin < 3
        omega = 0.95; % Keep some haze for natural appearance
    end
    
    image = double(image) / 255;
    
    % Normalize by airlight
    normalizedImage = zeros(size(image));
    for c = 1:size(image, 3)
        normalizedImage(:, :, c) = image(:, :, c) / max(airlight(c), 0.01);
    end
    
    % Transmission is 1 minus dark channel of normalized image
    transmission = 1 - omega * computeDarkChannel(normalizedImage);
    
    % Apply guided filter for smoothing (simplified version)
    transmission = imgaussfilt(transmission, 3);
    
    % Ensure minimum transmission
    transmission = max(transmission, 0.1);
end

function [img1, img2, depth] = createDefocusTestImages(imageSize)
    % Create synthetic images with different focus settings
    
    % Create base scene
    img1 = rand(imageSize) * 0.3 + 0.3; % Base texture
    depth = zeros(imageSize(1), imageSize(2));
    
    % Add objects at different depths
    % Near object (well focused in img1)
    centerY = round(imageSize(1) * 0.3);
    centerX = round(imageSize(2) * 0.3);
    radius = 30;
    
    [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
    nearMask = (X - centerX).^2 + (Y - centerY).^2 <= radius^2;
    
    for c = 1:3
        img1(nearMask(:, :, 1)) = 0.8; % Bright, sharp object
    end
    depth(nearMask) = 500; % 500*mm depth
    
    % Far object (well focused in img2)
    centerY2 = round(imageSize(1) * 0.7);
    centerX2 = round(imageSize(2) * 0.7);
    radius2 = 25;
    
    farMask = (X - centerX2).^2 + (Y - centerY2).^2 <= radius2^2;
    
    for c = 1:3
        img1(farMask(:, :, 1)) = 0.2; % Dark object
    end
    depth(farMask) = 1500; % 1500*mm depth
    
    % Background
    backgroundMask = ~nearMask & ~farMask;
    depth(backgroundMask) = 1000; % 1000*mm depth
    
    % Create img2 with different focus (simplified simulation)
    img2 = img1;
    
    % Blur near objects in img2 (focused at far distance)
    blurKernel = fspecial('gaussian', [5, 5], 2);
    for c = 1:3
        channel = img2(:, :, c);
        blurredChannel = imfilter(channel, blurKernel, 'same');
        channel(nearMask) = blurredChannel(nearMask);
        img2(:, :, c) = channel;
    end
    
    % Blur far objects in img1 (focused at near distance)
    for c = 1:3
        channel = img1(:, :, c);
        blurredChannel = imfilter(channel, blurKernel, 'same');
        channel(farMask) = blurredChannel(farMask);
        img1(:, :, c) = channel;
    end
end

function [images, normals] = createPhotometricStereoImages(imageSize, lightDirs)
    % Create synthetic images for photometric stereo testing
    
    numLights = size(lightDirs, 1);
    images = cell(numLights, 1);
    
    % Create synthetic surface (hemisphere)
    [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
    centerX = imageSize(2) / 2;
    centerY = imageSize(1) / 2;
    radius = min(imageSize(1:2)) / 3;
    
    % Initialize normals
    normals = zeros(imageSize(1), imageSize(2), 3);
    normals(:, :, 3) = 1; % Default normal pointing up
    
    % Create hemisphere surface
    distances = sqrt((X - centerX).^2 + (Y - centerY).^2);
    hemisphereMask = distances <= radius;
    
    for y = 1:imageSize(1)
        for x = 1:imageSize(2)
            if hemisphereMask(y, x)
                % Compute surface normal for hemisphere
                dx = (x - centerX) / radius;
                dy = (y - centerY) / radius;
                dz = sqrt(max(0, 1 - dx^2 - dy^2));
                
                normal = [dx, dy, dz];
                normal = normal / norm(normal);
                normals(y, x, :) = normal;
            end
        end
    end
    
    % Generate images under different lighting conditions
    albedo = 0.8; % Surface albedo
    
    for lightIdx = 1:numLights
        lightDir = lightDirs(lightIdx, :);
        
        % Compute intensity based on Lambertian reflectance
        intensity = zeros(imageSize(1), imageSize(2));
        
        for y = 1:imageSize(1)
            for x = 1:imageSize(2)
                normal = squeeze(normals(y, x, :))';
                
                % Lambertian shading: I = albedo * max(0, n ﹞ l)
                dotProduct = max(0, dot(normal, lightDir));
                intensity(y, x) = albedo * dotProduct;
            end
        end
        
        % Add small amount of ambient lighting
        intensity = intensity + 0.1;
        
        % Convert to RGB image
        images{lightIdx} = repmat(intensity, [1, 1, 3]);
    end
end

function hazyImage = createHazyImage(imageSize)
    % Create synthetic hazy image for atmospheric depth testing
    
    % Create base scene
    hazyImage = rand(imageSize) * 0.5 + 0.2;
    
    % Add depth-dependent haze
    [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
    
    % Create depth gradient (far objects more hazy)
    depthGradient = Y / imageSize(1); % 0 to 1 from top to bottom
    
    % Apply atmospheric scattering effect
    airlight = 0.8;
    scattering = 0.3;
    
    transmission = exp(-scattering * depthGradient * 5);
    
    for c = 1:3
        channel = hazyImage(:, :, c);
        channel = channel .* transmission + airlight * (1 - transmission);
        hazyImage(:, :, c) = channel;
    end
end
