%% chapter_AI_CV_multimodal_medical_01.m
% Multi-modal Medical Image Processing and Analysis System
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_multimodal_medical_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Multi-modal Medical Image Processing and Analysis System
fprintf('Multi-modal Medical Image Processing System\n');
fprintf('==========================================\n');

% Create synthetic medical images for different modalities
[ctImage, mriImage, petImage] = createSyntheticMedicalImages();






% 1. Medical Image Registration

% 2. Multi-modal Image Fusion



% 3. Quantitative Image Analysis

% 4. Medical Image Quality Assessment

% Test the multi-modal medical image processing system
fprintf('\nTesting multi-modal medical image processing...\n');

% Register MRI to CT space
[registeredMRI, tformMRItoCT] = registerMedicalImages(mriImage, ctImage, 'intensity');

% Register PET to CT space  
[registeredPET, tformPETtoCT] = registerMedicalImages(petImage, ctImage, 'intensity');

% Create multi-modal image set
multimodalImages = {double(ctImage), double(registeredMRI), double(registeredPET)};

% Perform image fusion
fusedImageWeighted = fuseMultimodalImages(multimodalImages, 'weighted', [0.4, 0.4, 0.2]);
fusedImagePCA = fuseMultimodalImages(multimodalImages, 'principal_component');

% Create simple anatomical label map for quantitative analysis
labelMap = createAnatomicalLabels(size(ctImage));


% Perform quantitative analysis
quantitativeResults = performQuantitativeAnalysis(multimodalImages, labelMap);

% Assess image quality for each modality
ctQuality = assessMedicalImageQuality(ctImage, 'ct');
mriQuality = assessMedicalImageQuality(mriImage, 'mri');
petQuality = assessMedicalImageQuality(petImage, 'pet');

% Visualise results
figure;

% Original images
subplot(3, 4, 1);
imshow(ctImage, []);
title('CT Image');
colormap(gray);

subplot(3, 4, 2);
imshow(mriImage, []);
title('MRI Image');

subplot(3, 4, 3);
imshow(petImage, []);
title('PET Image');
colormap(hot);

subplot(3, 4, 4);
imshow(labelMap, []);
title('Anatomical Labels');
colormap(jet);

% Registered images
subplot(3, 4, 5);
imshow(registeredMRI, []);
title('Registered MRI');

subplot(3, 4, 6);
imshow(registeredPET, []);
title('Registered PET');

% Fused images
subplot(3, 4, 7);
imshow(fusedImageWeighted, []);
title('Weighted Fusion');

subplot(3, 4, 8);
imshow(fusedImagePCA, []);
title('PCA Fusion');

% Difference images
subplot(3, 4, 9);
diffMRI = abs(double(registeredMRI) - double(ctImage));
imshow(diffMRI, []);
title('CT-MRI Difference');

subplot(3, 4, 10);
diffPET = abs(double(registeredPET) - double(ctImage));
imshow(diffPET, []);
title('CT-PET Difference');

% Quality visualisation
subplot(3, 4, 11);
qualityScores = [ctQuality.overallQuality, mriQuality.overallQuality, petQuality.overallQuality];
bar(qualityScores);
set(gca, 'XTickLabel', {'CT', 'MRI', 'PET'});
title('Image Quality Scores');
ylabel('Quality Score');

% Registration accuracy
subplot(3, 4, 12);
registrationErrors = [0, norm(tformMRItoCT.T - eye(3), 'fro'), norm(tformPETtoCT.T - eye(3), 'fro')];
bar(registrationErrors);
set(gca, 'XTickLabel', {'CT (ref)', 'MRI', 'PET'});
title('Registration Error');
ylabel('Transform Error');

sgtitle('Multi-modal Medical Image Processing Results');

% Display quantitative results
fprintf('\nQuantitative Analysis Results:\n');
fprintf('=============================\n');

modalities = fieldnames(quantitativeResults);
for i = 1:length(modalities)
    fprintf('\n%s:\n', modalities{i});
    regions = fieldnames(quantitativeResults.*(modalities{i}));
    
    for j = 1:length(regions)
        regionData = quantitativeResults.*(modalities{i}).*(regions{j});
        fprintf('  %s: Mean=%.2f, Std=%.2f, Volume=%d pixels\n', ...
            regions{j}, regionData.mean, regionData.std, regionData.volume);
    end
end

% Display quality assessment results
fprintf('\nImage Quality Assessment:\n');
fprintf('========================\n');
fprintf('CT Image Quality: %.3f\n', ctQuality.overallQuality);
fprintf('  Contrast: %.2f, Sharpness: %.2f, Noise: %.2f\n', ...
    ctQuality.contrast, ctQuality.sharpness, ctQuality.noiseEstimate);

fprintf('MRI Image Quality: %.3f\n', mriQuality.overallQuality);
fprintf('  Contrast: %.2f, Sharpness: %.2f, Inhomogeneity: %.3f\n', ...
    mriQuality.contrast, mriQuality.sharpness, mriQuality.inhomogeneity);

fprintf('PET Image Quality: %.3f\n', petQuality.overallQuality);
fprintf('  Max SUV: %.2f, Total Counts: %.0f\n', ...
    petQuality.maxSUV, petQuality.totalCounts);

% Advanced multi-modal analysis summary
fprintf('\nMulti-modal Processing Summary:\n');
fprintf('==============================\n');
fprintf('1. Image Registration: Spatial alignment of different modalities\n');
fprintf('2. Image Fusion: Integration of complementary information\n');
fprintf('3. Quantitative Analysis: Objective measurements across regions\n');
fprintf('4. Quality Assessment: Modality-specific quality metrics\n');

fprintf('\nClinical Applications:\n');
fprintf('=====================\n');
fprintf(' Oncology: Combined anatomical and functional tumour assessment\n');
fprintf(' Neurology: Structural and functional brain imaging\n');
fprintf(' Cardiology: Comprehensive cardiac evaluation\n');
fprintf(' Treatment Planning: Multi-modal guidance for interventions\n');

fprintf('\nTechnical Considerations:\n');
fprintf('========================\n');
fprintf(' Registration accuracy critical for quantitative analysis\n');
fprintf(' Fusion method selection depends on clinical application\n');
fprintf(' Quality assessment essential for reliable measurements\n');
fprintf(' Standardisation important for multi-centre studies\n');

% Local functions (moved to end so this listing is a valid MATLAB script)
function [ct, mri, pet] = createSyntheticMedicalImages()
    % Create synthetic medical images simulating different modalities
    
    fprintf('Creating synthetic multi-modal medical images...\n');
    
    imageSize = [256, 256];
    
    % Create anatomical phantom
    phantom = createAnatomicalPhantom(imageSize);
    
    % CT Image - High resolution bone/tissue contrast
    ct = createCTImage(phantom, imageSize);
    
    % MRI Image - Excellent soft tissue contrast
    mri = createMRIImage(phantom, imageSize);
    
    % PET Image - Functional/metabolic information
    pet = createPETImage(phantom, imageSize);
    
    fprintf('Created synthetic medical images: CT, MRI, and PET\n');
end

function phantom = createAnatomicalPhantom(imageSize)
    % Create basic anatomical phantom structure
    
    phantom = struct();
    [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
    centerX = imageSize(2) / 2;
    centerY = imageSize(1) / 2;
    
    % Body outline (ellipse)
    bodyA = imageSize(2) * 0.4;
    bodyB = imageSize(1) * 0.45;
    phantom.body = ((X - centerX) / bodyA).^2 + ((Y - centerY) / bodyB).^2 <= 1;
    
    % Organ structures
    % Heart region
    heartCenterX = centerX - 30;
    heartCenterY = centerY - 20;
    phantom.heart = ((X - heartCenterX) / 25).^2 + ((Y - heartCenterY) / 30).^2 <= 1;
    phantom.heart = phantom.heart & phantom.body;
    
    % Lung regions
    lungY = centerY - 10;
    leftLungX = centerX - 60;
    rightLungX = centerX + 60;
    
    phantom.leftLung = ((X - leftLungX) / 35).^2 + ((Y - lungY) / 40).^2 <= 1;
    phantom.rightLung = ((X - rightLungX) / 35).^2 + ((Y - lungY) / 40).^2 <= 1;
    phantom.leftLung = phantom.leftLung & phantom.body;
    phantom.rightLung = phantom.rightLung & phantom.body;
    
    % Liver region
    liverCenterX = centerX + 40;
    liverCenterY = centerY + 30;
    phantom.liver = ((X - liverCenterX) / 45).^2 + ((Y - liverCenterY) / 35).^2 <= 1;
    phantom.liver = phantom.liver & phantom.body;
    
    % Bone structures (ribs)
    phantom.bones = false(imageSize);
    for rib = 1:6
        ribY = centerY - 60 + rib * 15;
        ribLeft = ((X - (centerX - 80)) / 5).^2 + ((Y - ribY) / 3).^2 <= 1;
        ribRight = ((X - (centerX + 80)) / 5).^2 + ((Y - ribY) / 3).^2 <= 1;
        phantom.bones = phantom.bones | ribLeft | ribRight;
    end
    phantom.bones = phantom.bones & phantom.body;
    
    % Tumour/lesion
    tumourX = centerX + 25;
    tumourY = centerY + 15;
    phantom.tumour = ((X - tumourX) / 8).^2 + ((Y - tumourY) / 8).^2 <= 1;
    phantom.tumour = phantom.tumour & phantom.body;
end

function ctImage = createCTImage(phantom, imageSize)
    % Create CT image with bone and tissue contrast
    
    ctImage = zeros(imageSize);
    
    % Hounsfield units simulation
    ctImage(phantom.body) = 50;        % Soft tissue
    ctImage(phantom.heart) = 60;       % Heart muscle
    ctImage(phantom.leftLung) = -800;  % Air-filled lungs
    ctImage(phantom.rightLung) = -800;
    ctImage(phantom.liver) = 65;       % Liver tissue
    ctImage(phantom.bones) = 800;      % Bone
    ctImage(phantom.tumour) = 80;      % Tumour (slightly enhanced)
    
    % Add noise typical of CT
    noise = 15 * randn(imageSize);
    ctImage = ctImage + noise;
    
    % Add beam hardening artifacts
    [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
    centerX = imageSize(2) / 2;
    beamHardening = 10 * cos(2 * pi * (X - centerX) / imageSize(2));
    ctImage = ctImage + beamHardening .* phantom.body;
    
    % Normalize to typical CT range
    ctImage = int16(ctImage);
end

function mriImage = createMRIImage(phantom, imageSize)
    % Create MRI image with excellent soft tissue contrast
    
    mriImage = zeros(imageSize);
    
    % T1-weighted signal intensities
    mriImage(phantom.body) = 100;      % General soft tissue
    mriImage(phantom.heart) = 120;     % Heart muscle
    mriImage(phantom.leftLung) = 20;   % Lungs (low signal)
    mriImage(phantom.rightLung) = 20;
    mriImage(phantom.liver) = 110;     % Liver
    mriImage(phantom.bones) = 40;      % Bone (low T1 signal)
    mriImage(phantom.tumour) = 140;    % Tumour (enhanced)
    
    % Add MRI-specific noise (Rician)
    noise = 8 * randn(imageSize);
    mriImage = sqrt((mriImage + noise).^2 + (8 * randn(imageSize)).^2);
    
    % Add intensity inhomogeneity (bias field)
    [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
    centerX = imageSize(2) / 2;
    centerY = imageSize(1) / 2;
    biasField = 1 + 0.2 * cos(2 * pi * (X - centerX) / imageSize(2)) * ...
                cos(2 * pi * (Y - centerY) / imageSize(1));
    mriImage = mriImage .* biasField;
    
    % Ensure positive values
    mriImage = max(0, mriImage);
end

function petImage = createPETImage(phantom, imageSize)
    % Create PET image showing metabolic activity
    
    petImage = zeros(imageSize);
    
    % Standardised uptake values (SUV)
    petImage(phantom.body) = 1.5;      % Background tissue
    petImage(phantom.heart) = 8.0;     % High cardiac uptake
    petImage(phantom.leftLung) = 0.3;  % Low lung uptake
    petImage(phantom.rightLung) = 0.3;
    petImage(phantom.liver) = 3.0;     % Moderate liver uptake
    petImage(phantom.tumour) = 12.0;   % High tumour uptake
    
    % Apply Gaussian smoothing to simulate PET resolution
    petImage = imgaussfilt(petImage, 3);
    
    % Add Poisson noise characteristic of PET
    petImage = max(0, petImage);
    petImage = double(petImage);
    
    % Scale for Poisson noise simulation
    scaleFactor = 100;
    petImage = poissrnd(petImage * scaleFactor) / scaleFactor;
    
    % Add background noise
    backgroundNoise = 0.1 * randn(imageSize);
    petImage = petImage + backgroundNoise;
    petImage = max(0, petImage);
end

function [registeredImage, tform] = registerMedicalImages(movingImage, fixedImage, registrationType)
    % Register medical images using different registration techniques
    
    if nargin < 3
        registrationType = 'intensity';
    end
    
    fprintf('Registering medical images using %s-based registration...\n', registrationType);
    
    try
        switch registrationType
            case 'intensity'
                % Intensity-based registration
                [optimizer, metric] = imregconfig('monomodal');
                optimizer.InitialRadius = 0.009;
                optimizer.Epsilon = 1.5e-4;
                optimizer.GrowthFactor = 1.01;
                optimizer.MaximumIterations = 300;
                
                tform = imregtform(movingImage, fixedImage, 'rigid', optimizer, metric);
                
            case 'feature'
                % Feature-based registration using SURF features
                movingPoints = detectSURFFeatures(movingImage);
                fixedPoints = detectSURFFeatures(fixedImage);
                
                [movingFeatures, movingValidPoints] = extractFeatures(movingImage, movingPoints);
                [fixedFeatures, fixedValidPoints] = extractFeatures(fixedImage, fixedPoints);
                
                indexPairs = matchFeatures(movingFeatures, fixedFeatures);
                
                movingMatched = movingValidPoints(indexPairs(:,1), :);
                fixedMatched = fixedValidPoints(indexPairs(:,2), :);
                
                tform = estimateGeometricTransform(movingMatched, fixedMatched, 'rigid');
                
            otherwise
                error('Unknown registration type: %s', registrationType);
        end
        
        % Apply transformation
        outputView = imref2d(size(fixedImage));
        registeredImage = imwarp(movingImage, tform, 'OutputView', outputView);
        
        fprintf('Registration completed successfully\n');
        
    catch ME
        fprintf('Registration failed: %s\n', ME.message);
        fprintf('Using identity transformation\n');
        registeredImage = movingImage;
        tform = affine2d(eye(3));
    end
end

function fusedImage = fuseMultimodalImages(images, fusionMethod, weights)
    % Fuse multiple medical images using different fusion techniques
    
    if nargin < 2
        fusionMethod = 'weighted';
    end
    
    if nargin < 3
        numImages = length(images);
        weights = ones(1, numImages) / numImages; % Equal weights
    end
    
    fprintf('Fusing %d medical images using %s method...\n', length(images), fusionMethod);
    
    % Normalise all images to [0, 1] range
    normalisedImages = cell(size(images));
    for i = 1:length(images)
        img = double(images{i});
        img = (img - min(img(:))) / (max(img(:)) - min(img(:)) + eps);
        normalisedImages{i} = img;
    end
    
    switch fusionMethod
        case 'weighted'
            % Weighted average fusion
            fusedImage = zeros(size(normalisedImages{1}));
            for i = 1:length(normalisedImages)
                fusedImage = fusedImage + weights(i) * normalisedImages{i};
            end
            
        case 'principal_component'
            % Principal component analysis fusion
            [height, width] = size(normalisedImages{1});
            imageMatrix = zeros(height * width, length(normalisedImages));
            
            for i = 1:length(normalisedImages)
                imageMatrix(:, i) = normalisedImages{i}(:);
            end
            
            [coeff, score, ~] = pca(imageMatrix);
            
            % Use first principal component
            fusedVector = score(:, 1);
            fusedImage = reshape(fusedVector, height, width);
            
            % Normalise to [0, 1]
            fusedImage = (fusedImage - min(fusedImage(:))) / ...
                        (max(fusedImage(:)) - min(fusedImage(:)) + eps);
            
        case 'wavelet'
            % Wavelet-based fusion
            fusedImage = waveletFusion(normalisedImages);
            
        case 'gradient'
            % Gradient-based fusion
            fusedImage = gradientBasedFusion(normalisedImages);
            
        otherwise
            error('Unknown fusion method: %s', fusionMethod);
    end
    
    fprintf('Image fusion completed\n');
end

function fusedImage = waveletFusion(images)
    % Wavelet-based image fusion
    
    % Simple wavelet fusion using approximation coefficients
    fusedImage = zeros(size(images{1}));
    
    for i = 1:length(images)
        % Apply wavelet transform
        [c, s] = wavedec2(images{i}, 1, 'db4');
        
        % Contribute to fused result
        if i == 1
            fusedCoeffs = c;
            fusedSizes = s;
        else
            % Average the coefficients
            fusedCoeffs = (fusedCoeffs + c) / 2;
        end
    end
    
    % Reconstruct fused image
    fusedImage = waverec2(fusedCoeffs, fusedSizes, 'db4');
end

function fusedImage = gradientBasedFusion(images)
    % Gradient-based fusion selecting highest gradient regions
    
    fusedImage = zeros(size(images{1}));
    
    % Compute gradients for each image
    gradients = cell(size(images));
    for i = 1:length(images)
        [Gx, Gy] = gradient(images{i});
        gradients{i} = sqrt(Gx.^2 + Gy.^2);
    end
    
    % Select pixel with highest gradient at each location
    [height, width] = size(images{1});
    for y = 1:height
        for x = 1:width
            gradientValues = zeros(1, length(images));
            for i = 1:length(images)
                gradientValues(i) = gradients{i}(y, x);
            end
            
            [~, maxIdx] = max(gradientValues);
            fusedImage(y, x) = images{maxIdx}(y, x);
        end
    end
end

function analysisResults = performQuantitativeAnalysis(multimodalImages, labelMap)
    % Perform quantitative analysis on multi-modal medical images
    
    fprintf('Performing quantitative multi-modal image analysis...\n');
    
    analysisResults = struct();
    
    % Regional analysis based on anatomical labels
    uniqueLabels = unique(labelMap);
    uniqueLabels = uniqueLabels(uniqueLabels > 0); % Exclude background
    
    for modalityIdx = 1:length(multimodalImages)
        modalityName = sprintf('Modality_%d', modalityIdx);
        analysisResults.*(modalityName) = struct();
        
        image = double(multimodalImages{modalityIdx});
        
        for labelIdx = 1:length(uniqueLabels)
            label = uniqueLabels(labelIdx);
            regionMask = labelMap == label;
            
            if sum(regionMask(:)) > 0
                regionPixels = image(regionMask);
                
                % Statistical measures
                stats = struct();
                stats.mean = mean(regionPixels);
                stats.std = std(regionPixels);
                stats.median = median(regionPixels);
                stats.min = min(regionPixels);
                stats.max = max(regionPixels);
                stats.volume = sum(regionMask(:)); % In pixels
                
                % Texture features
                stats.entropy = entropy(uint8(255 * regionPixels / max(regionPixels(:))));
                
                % Store results
                regionName = sprintf('Region_%d', label);
                analysisResults.*(modalityName).*(regionName) = stats;
            end
        end
    end
    
    fprintf('Quantitative analysis completed\n');
end

function qualityMetrics = assessMedicalImageQuality(image, imageType)
    % Assess quality of medical images using appropriate metrics
    
    if nargin < 2
        imageType = 'general';
    end
    
    fprintf('Assessing medical image quality (%s)...\n', imageType);
    
    qualityMetrics = struct();
    image = double(image);
    
    % Basic quality metrics
    qualityMetrics.contrast = std(image(:));
    qualityMetrics.brightness = mean(image(:));
    qualityMetrics.snr = qualityMetrics.brightness / std(image(:) - mean(image(:)));
    
    % Sharpness measures
    [Gx, Gy] = gradient(image);
    gradientMagnitude = sqrt(Gx.^2 + Gy.^2);
    qualityMetrics.sharpness = mean(gradientMagnitude(:));
    
    % Noise estimation
    laplacianKernel = [0 -1 0; -1 4 -1; 0 -1 0];
    laplacianResponse = abs(imfilter(image, laplacianKernel, 'same'));
    qualityMetrics.noiseEstimate = std(laplacianResponse(:));
    
    % Modality-specific metrics
    switch imageType
        case 'ct'
            % CT-specific quality measures
            qualityMetrics.dynamicRange = max(image(:)) - min(image(:));
            
            % Uniformity in air regions (if present)
            airMask = image < -500; % Typical air HU values
            if sum(airMask(:)) > 100
                qualityMetrics.airUniformity = std(image(airMask));
            else
                qualityMetrics.airUniformity = NaN;
            end
            
        case 'mri'
            % MRI-specific quality measures
            % Signal-to-noise ratio estimation
            backgroundMask = image < 0.1 * max(image(:));
            if sum(backgroundMask(:)) > 100
                backgroundNoise = std(image(backgroundMask));
                signalRegion = image > 0.5 * max(image(:));
                if sum(signalRegion(:)) > 100
                    signalMean = mean(image(signalRegion));
                    qualityMetrics.mri_snr = signalMean / backgroundNoise;
                end
            end
            
            % Intensity inhomogeneity
            smoothed = imgaussfilt(image, 20);
            inhomogeneity = image ./ (smoothed + eps);
            qualityMetrics.inhomogeneity = std(inhomogeneity(:));
            
        case 'pet'
            % PET-specific quality measures
            % Count statistics
            qualityMetrics.totalCounts = sum(image(:));
            qualityMetrics.maxSUV = max(image(:));
            
            % Uniformity in background regions
            backgroundMask = image < 0.3 * max(image(:));
            if sum(backgroundMask(:)) > 100
                qualityMetrics.backgroundUniformity = std(image(backgroundMask)) / ...
                                                     mean(image(backgroundMask));
            end
    end
    
    % Overall quality score
    qualityScore = (qualityMetrics.contrast / 100 + ...
                   qualityMetrics.sharpness / 50 + ...
                   (1 / (1 + qualityMetrics.noiseEstimate / 10))) / 3;
    qualityMetrics.overallQuality = min(1, max(0, qualityScore));
    
    fprintf('Image quality assessment completed\n');
end

function labels = createAnatomicalLabels(imageSize)
    % Create anatomical region labels
    phantom = createAnatomicalPhantom(imageSize);
    
    labels = zeros(imageSize);
    labels(phantom.heart) = 1;        % Heart
    labels(phantom.leftLung) = 2;     % Left lung
    labels(phantom.rightLung) = 3;    % Right lung  
    labels(phantom.liver) = 4;        % Liver
    labels(phantom.tumour) = 5;       % Tumour
end

% Local function copied from another listing in this chapter
function matches = matchFeatures(descriptors1, descriptors2, points1, points2, threshold)
% Find matches between feature descriptors using nearest neighbor ratio test

 
if isempty(descriptors1) || isempty(descriptors2)
    matches = [];
    return;
end

matches = [];

for i = 1:size(descriptors1, 1)
    desc1 = descriptors1(i, :);
    
    % Compute distances to all descriptors in second image
    distances = sqrt(sum((descriptors2 - desc1).^2, 2));
    
    % Find two nearest neighbors
    [sortedDist, sortedIdx] = sort(distances);
    
    if length(sortedDist) >= 2
        % Ratio test for distinctive matches
        ratio = sortedDist(1) / sortedDist(2);
        
        if ratio < threshold && sortedDist(1) < 0.5 % Additional distance threshold
            matches(end+1, :) = [i, sortedIdx(1), sortedDist(1), ratio];
        end
    end
end
end
