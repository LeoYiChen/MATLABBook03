%% chapter_AI_CV_cnn_architecture_01.m
% Comprehensive CNN Architecture Implementation and Analysis
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_cnn_architecture_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Create comprehensive CNN architecture with analysis tools
% Load and prepare image dataset
imds = imageDatastore(fullfile(matlabroot, 'toolbox', 'nnet', 'nndemos', ...
    'nndatasets', 'DigitDataset'), 'IncludeSubfolders', true, 'LabelSource', 'foldernames');

% Split dataset for training and validation
[imdsTrain, imdsValidation] = splitEachLabel(imds, 0.7, 'randomize');

% Define CNN architecture with detailed layer analysis
inputSize = [28 28 1];
numClasses = 10;

% Create layer-by-layer architecture
layers = [
    imageInputLayer(inputSize, 'Name', 'input')
    
    % First convolutional block
    convolution2dLayer(5, 20, 'Padding', 'same', 'Name', 'conv1')
    batchNormalizationLayer('Name', 'bn1')
    reluLayer('Name', 'relu1')
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool1')
    
    % Second convolutional block
    convolution2dLayer(5, 50, 'Padding', 'same', 'Name', 'conv2')
    batchNormalizationLayer('Name', 'bn2')
    reluLayer('Name', 'relu2')
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool2')
    
    % Third convolutional block
    convolution2dLayer(3, 100, 'Padding', 'same', 'Name', 'conv3')
    batchNormalizationLayer('Name', 'bn3')
    reluLayer('Name', 'relu3')
    
    % Fully connected layers
    fullyConnectedLayer(128, 'Name', 'fc1')
    reluLayer('Name', 'relu4')
    dropoutLayer(0.5, 'Name', 'dropout1')
    
    fullyConnectedLayer(numClasses, 'Name', 'fc2')
    softmaxLayer('Name', 'softmax')
    classificationLayer('Name', 'output')
];

% Create layer graph for analysis
lgraph = layerGraph(layers);

% Analyse network architecture

% Analyse the network
analyseNetworkArchitecture(lgraph);

% Calculate theoretical receptive field sizes

receptive_fields = calculateReceptiveFields(lgraph);
fprintf('\nTheoretical receptive field sizes:\n');
field_names = fieldnames(receptive_fields);
for i = 1:length(field_names)
    fprintf('%s: %dx%d\n', field_names{i}, receptive_fields.*(field_names{i}), receptive_fields.*(field_names{i}));
end

% Parameter count analysis

param_analysis = analyseParameters(lgraph);
fprintf('\nParameter Analysis:\n');
fprintf('Total parameters: %d\n', param_analysis.total_parameters);
fprintf('Trainable parameters: %d\n', param_analysis.trainable_parameters);

% Training options with comprehensive monitoring
options = trainingOptions('adam', ...
    'InitialLearnRate', 0.001, ...
    'MaxEpochs', 20, ...
    'MiniBatchSize', 64, ...
    'ValidationData', imdsValidation, ...
    'ValidationFrequency', 50, ...
    'Verbose', false, ...
    'Plots', 'training-progress', ...
    'LearnRateSchedule', 'piecewise', ...
    'LearnRateDropFactor', 0.1, ...
    'LearnRateDropPeriod', 10);

% Train the network
fprintf('\nTraining CNN...\n');
net = trainNetwork(imdsTrain, lgraph, options);

% Comprehensive evaluation
YPred = classify(net, imdsValidation);
YValidation = imdsValidation.Labels;
accuracy = sum(YPred == YValidation) / numel(YValidation);

fprintf('Validation Accuracy: %.2f%%\n', accuracy * 100);

% Feature visualisation and analysis

% Visualise features from different layers
visualiseFeatures(net, imdsValidation, 'conv1');
visualiseFeatures(net, imdsValidation, 'conv2');
visualiseFeatures(net, imdsValidation, 'conv3');

% Filter visualisation

% Visualise learned filters
visualiseFilters(net, 'conv1');
visualiseFilters(net, 'conv2');

% Performance analysis across different architectural choices

compareArchitectures();

% Computational complexity analysis

analyseComplexity(lgraph, inputSize);

% Local functions (moved to end so this listing is a valid MATLAB script)
function analyseNetworkArchitecture(lgraph)
    fprintf('CNN Architecture Analysis:\n');
    fprintf('========================\n');
    
    % Get layer information
    layerNames = {lgraph.Layers.Name};
    layerTypes = arrayfun(@(x) class(x), lgraph.Layers, 'UniformOutput', false);
    
    fprintf('Total layers: %d\n', length(layerNames));
    
    % Count layer types
    convLayers = sum(contains(layerTypes, 'Convolution2DLayer'));
    poolLayers = sum(contains(layerTypes, 'MaxPooling2DLayer'));
    fcLayers = sum(contains(layerTypes, 'FullyConnectedLayer'));
    
    fprintf('Convolutional layers: %d\n', convLayers);
    fprintf('Pooling layers: %d\n', poolLayers);
    fprintf('Fully connected layers: %d\n', fcLayers);
    
    % Analyse receptive field sizes
    fprintf('\nReceptive field analysis:\n');
    for i = 1:length(lgraph.Layers)
        layer = lgraph.Layers(i);
        if isa(layer, 'nnet.cnn.layer.Convolution2DLayer')
            fprintf('%s: Filter size %dx%d, %d filters\n', ...
                layer.Name, layer.FilterSize(1), layer.FilterSize(2), layer.NumFilters);
        elseif isa(layer, 'nnet.cnn.layer.MaxPooling2DLayer')
            fprintf('%s: Pool size %dx%d, Stride %d\n', ...
                layer.Name, layer.PoolSize(1), layer.PoolSize(2), layer.Stride(1));
        end
    end
end

function receptive_fields = calculateReceptiveFields(lgraph)
    receptive_fields = struct();
    current_rf = 1;
    current_stride = 1;
    
    layer_count = 0;
    for i = 1:length(lgraph.Layers)
        layer = lgraph.Layers(i);
        
        if isa(layer, 'nnet.cnn.layer.Convolution2DLayer')
            layer_count = layer_count + 1;
            filter_size = layer.FilterSize(1);
            stride = layer.Stride(1);
            
            % Update receptive field
            current_rf = current_rf + (filter_size - 1) * current_stride;
            current_stride = current_stride * stride;
            
            receptive_fields.*(sprintf('conv%d', layer_count)) = current_rf;
            
        elseif isa(layer, 'nnet.cnn.layer.MaxPooling2DLayer')
            pool_size = layer.PoolSize(1);
            stride = layer.Stride(1);
            
            current_rf = current_rf + (pool_size - 1) * current_stride;
            current_stride = current_stride * stride;
        end
    end
end

function param_analysis = analyseParameters(lgraph)
    param_analysis = struct();
    total_params = 0;
    trainable_params = 0;
    
    for i = 1:length(lgraph.Layers)
        layer = lgraph.Layers(i);
        layer_params = 0;
        layer_trainable = 0;
        
        if isa(layer, 'nnet.cnn.layer.Convolution2DLayer')
            % Conv layer: (filter_h * filter_w * input_channels + 1) * num_filters
            if i == 1
                input_channels = 1; % Assuming grayscale input
            else
                % Get previous conv layer's output channels
                prev_layer = lgraph.Layers(i-3); % Account for BN and ReLU
                if isa(prev_layer, 'nnet.cnn.layer.Convolution2DLayer')
                    input_channels = prev_layer.NumFilters;
                else
                    input_channels = 1;
                end
            end
            
            filter_params = layer.FilterSize(1) * layer.FilterSize(2) * input_channels * layer.NumFilters;
            bias_params = layer.NumFilters;
            layer_params = filter_params + bias_params;
            layer_trainable = layer_params;
            
        elseif isa(layer, 'nnet.cnn.layer.FullyConnectedLayer')
            % FC layer parameters depend on input size
            layer_params = layer.OutputSize * 1000 + layer.OutputSize; % Approximation
            layer_trainable = layer_params;
            
        elseif isa(layer, 'nnet.cnn.layer.BatchNormalizationLayer')
            % BN has scale and offset parameters
            % Approximation based on previous layer
            if i > 1 && isa(lgraph.Layers(i-1), 'nnet.cnn.layer.Convolution2DLayer')
                layer_params = lgraph.Layers(i-1).NumFilters * 2;
                layer_trainable = layer_params;
            end
        end
        
        total_params = total_params + layer_params;
        trainable_params = trainable_params + layer_trainable;
        
        param_analysis.*(layer.Name) = layer_params;
    end
    
    param_analysis.total_parameters = total_params;
    param_analysis.trainable_parameters = trainable_params;
end

function visualiseFeatures(net, imds, layerName)
    % Get a sample image
    img = readimage(imds, 1);
    
    % Extract features from specified layer
    features = activations(net, img, layerName, 'OutputAs', 'channels');
    
    % Visualise feature maps
    figure;
    numFeatures = min(16, size(features, 3)); % Show up to 16 feature maps
    
    for i = 1:numFeatures
        subplot(4, 4, i);
        featureMap = features(:, :, i);
        imagesc(featureMap);
        colormap('gray');
        title(sprintf('Feature %d', i));
        axis off;
    end
    sgtitle(sprintf('Feature Maps from %s Layer', layerName));
end

function visualiseFilters(net, layerName)
    % Get the layer
    layerIdx = find(strcmp({net.Layers.Name}, layerName));
    if isempty(layerIdx)
        fprintf('Layer %s not found\n', layerName);
        return;
    end
    
    layer = net.Layers(layerIdx);
    if ~isa(layer, 'nnet.cnn.layer.Convolution2DLayer')
        fprintf('Layer %s is not a convolutional layer\n', layerName);
        return;
    end
    
    % Get filter weights
    weights = layer.Weights;
    [h, w, c, numFilters] = size(weights);
    
    % Visualise filters
    figure;
    numToShow = min(16, numFilters);
    
    for i = 1:numToShow
        subplot(4, 4, i);
        
        if c == 1
            % Grayscale filter
            imagesc(weights(:, :, 1, i));
        else
            % Multi-channel filter - show first channel
            imagesc(weights(:, :, 1, i));
        end
        
        colormap('gray');
        title(sprintf('Filter %d', i));
        axis off;
    end
    sgtitle(sprintf('Learned Filters in %s Layer', layerName));
end

function compareArchitectures()
    % Simple architecture
    simple_layers = [
        imageInputLayer([28 28 1])
        convolution2dLayer(5, 10)
        reluLayer
        fullyConnectedLayer(10)
        softmaxLayer
        classificationLayer
    ];
    
    % Deep architecture
    deep_layers = [
        imageInputLayer([28 28 1])
        convolution2dLayer(3, 32, 'Padding', 'same')
        reluLayer
        convolution2dLayer(3, 32, 'Padding', 'same')
        reluLayer
        maxPooling2dLayer(2, 'Stride', 2)
        convolution2dLayer(3, 64, 'Padding', 'same')
        reluLayer
        convolution2dLayer(3, 64, 'Padding', 'same')
        reluLayer
        maxPooling2dLayer(2, 'Stride', 2)
        fullyConnectedLayer(128)
        reluLayer
        dropoutLayer(0.5)
        fullyConnectedLayer(10)
        softmaxLayer
        classificationLayer
    ];
    
    architectures = {simple_layers, deep_layers};
    arch_names = {'Simple CNN', 'Deep CNN'};
    
    fprintf('\nArchitecture Comparison:\n');
    fprintf('========================\n');
    
    for i = 1:length(architectures)
        layers = architectures{i};
        
        % Count parameters (simplified)
        total_layers = length(layers);
        conv_layers = sum(arrayfun(@(x) isa(x, 'nnet.cnn.layer.Convolution2DLayer'), layers));
        fc_layers = sum(arrayfun(@(x) isa(x, 'nnet.cnn.layer.FullyConnectedLayer'), layers));
        
        fprintf('%s:\n', arch_names{i});
        fprintf('  Total layers: %d\n', total_layers);
        fprintf('  Convolutional layers: %d\n', conv_layers);
        fprintf('  Fully connected layers: %d\n', fc_layers);
    end
end

function analyseComplexity(lgraph, inputSize)
    fprintf('\nComputational Complexity Analysis:\n');
    fprintf('==================================\n');
    
    total_flops = 0;
    current_size = inputSize;
    
    for i = 1:length(lgraph.Layers)
        layer = lgraph.Layers(i);
        layer_flops = 0;
        
        if isa(layer, 'nnet.cnn.layer.Convolution2DLayer')
            % FLOPS for convolution
            filter_size = layer.FilterSize(1) * layer.FilterSize(2);
            if i == 1
                input_channels = inputSize(3);
            else
                % Approximate based on previous conv layer
                prev_conv_idx = find(arrayfun(@(x) isa(x, 'nnet.cnn.layer.Convolution2DLayer'), lgraph.Layers(1:i-1)), 1, 'last');
                if ~isempty(prev_conv_idx)
                    input_channels = lgraph.Layers(prev_conv_idx).NumFilters;
                else
                    input_channels = inputSize(3);
                end
            end
            
            output_size = current_size(1) * current_size(2);
            layer_flops = filter_size * input_channels * layer.NumFilters * output_size;
            
            % Update current size (assuming same padding)
            current_size = [current_size(1), current_size(2), layer.NumFilters];
            
        elseif isa(layer, 'nnet.cnn.layer.MaxPooling2DLayer')
            % Update size after pooling
            current_size(1) = floor(current_size(1) / layer.Stride(1));
            current_size(2) = floor(current_size(2) / layer.Stride(2));
            
        elseif isa(layer, 'nnet.cnn.layer.FullyConnectedLayer')
            % FLOPS for fully connected layer
            input_size_fc = prod(current_size);
            layer_flops = input_size_fc * layer.OutputSize;
            current_size = [1, 1, layer.OutputSize];
        end
        
        total_flops = total_flops + layer_flops;
        
        if layer_flops > 0
            fprintf('%s: %.2e FLOPS\n', layer.Name, layer_flops);
        end
    end
    
    fprintf('Total FLOPS: %.2e\n', total_flops);
    fprintf('Total FLOPS (millions): %.2f\n', total_flops / 1e6);
end
