%% chapter_AI_CV_fingerprint_matching_01.m
% Advanced Fingerprint Matching and Verification System
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_fingerprint_matching_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Advanced Fingerprint Matching and Verification System
fprintf('Fingerprint Matching and Verification System\n');
fprintf('===========================================\n');

% Create template and query fingerprints for matching demonstration
templateFingerprint = createFingerprintTemplate();
queryFingerprint = createQueryFingerprint(templateFingerprint);



% 1. Minutiae-based Matching Algorithm




% Perform matching
matchingResult = matchFingerprints(templateFingerprint, queryFingerprint);

% 2. Advanced Matching with Multiple Algorithms

% Perform advanced matching
advancedMatchResult = advancedMatching(templateFingerprint, queryFingerprint);

% 3. Performance Evaluation and ROC Analysis

% Create small dataset for performance evaluation
templateSet = cell(5, 1);
querySet = cell(5, 1);

for i = 1:5
    templateSet{i} = createFingerprintTemplate();
    querySet{i} = createQueryFingerprint(templateSet{i});
end

% Evaluate performance
performanceResults = evaluateMatchingPerformance(templateSet, querySet, @matchFingerprints);

% 4. Visualization and Analysis



% Visualize matching results
visualizeMatchingResults(templateFingerprint, queryFingerprint, matchingResult);

% Plot ROC curve
if exist('performanceResults', 'var')
    figure;
    plot(performanceResults.FAR * 100, (1 - performanceResults.FRR) * 100, 'b-', 'LineWidth', 2);
    xlabel('False Accept Rate (%)');
    ylabel('True Accept Rate (%)');
    title('ROC Curve for Fingerprint Matching');
    grid on;
    
    % Add EER point
    eerIdx = find(abs(performanceResults.FAR - performanceResults.FRR) == ...
                  min(abs(performanceResults.FAR - performanceResults.FRR)), 1);
    hold on;
    plot(performanceResults.FAR(eerIdx) * 100, (1 - performanceResults.FRR(eerIdx)) * 100, ...
         'ro', 'MarkerSize', 8, 'LineWidth', 2);
    text(performanceResults.FAR(eerIdx) * 100 + 2, (1 - performanceResults.FRR(eerIdx)) * 100, ...
         sprintf('EER = %.2f%%', performanceResults.EER * 100), 'FontSize', 10);
    hold off;
end

% Summary of matching techniques
fprintf('\nFingerprint Matching Algorithm Summary:\n');
fprintf('======================================\n');
fprintf('1. Minutiae-based matching:\n');
fprintf('   - Point pattern matching with geometric constraints\n');
fprintf('   - Robust to partial fingerprints and noise\n');
fprintf('   - Standard approach in most commercial systems\n');

fprintf('\n2. Ridge-based matching:\n');
fprintf('   - Correlation of ridge flow patterns\n');
fprintf('   - Complementary to minutiae-based approaches\n');
fprintf('   - Useful for poor quality images\n');

fprintf('\n3. Hybrid approaches:\n');
fprintf('   - Combination of multiple matching algorithms\n');
fprintf('   - Score-level or feature-level fusion\n');
fprintf('   - Improved accuracy and robustness\n');

fprintf('\n4. Performance considerations:\n');
fprintf('   - Speed vs accuracy trade-offs\n');
fprintf('   - Database size scalability\n');
fprintf('   - False accept/reject rate balance\n');

% Best practices for fingerprint matching
fprintf('\nBest Practices for Fingerprint Matching:\n');
fprintf('=======================================\n');
fprintf('1. Use multiple complementary algorithms for robustness\n');
fprintf('2. Implement quality-based adaptive matching\n');
fprintf('3. Consider geometric transformation models carefully\n');
fprintf('4. Validate performance across diverse populations\n');
fprintf('5. Monitor system performance in deployment\n');
fprintf('6. Implement secure template storage and comparison\n');
fprintf('7. Consider privacy-preserving matching techniques\n');
fprintf('8. Regular system calibration and maintenance\n');

% Local functions (moved to end so this listing is a valid MATLAB script)
function template = createFingerprintTemplate()
    % Create template fingerprint with known minutiae
    
    template = struct();
    
    % Simulate minutiae points
    numMinutiae = 15;
    template.minutiae = [];
    
    % Generate minutiae with specific patterns
    for i = 1:numMinutiae
        minutia = struct();
        
        % Random position within fingerprint region
        minutia.x = 50 + rand() * 200;
        minutia.y = 50 + rand() * 200;
        
        % Random angle
        minutia.angle = rand() * 2 * pi;
        
        % Random type
        if rand() > 0.7
            minutia.type = 'bifurcation';
        else
            minutia.type = 'ending';
        end
        
        % Quality based on position (center has higher quality)
        centerDistance = sqrt((minutia.x - 150)^2 + (minutia.y - 150)^2);
        minutia.quality = max(0.1, 1 - centerDistance / 100);
        
        template.minutiae = [template.minutiae; minutia];
    end
    
    % Additional template information
    template.imageSize = [300, 300];
    template.quality = mean([template.minutiae.quality]);
    template.id = 'template_001';
    
    fprintf('Created template with %d minutiae (quality: %.3f)\n', ...
        length(template.minutiae), template.quality);
end

function query = createQueryFingerprint(template)
    % Create query fingerprint based on template with transformations
    
    query = struct();
    query.minutiae = [];
    
    % Simulation parameters
    translation = [rand()*20 - 10, rand()*20 - 10]; % ㊣10 pixel translation
    rotation = (rand() - 0.5) * 0.3; % ㊣0.15 radian rotation
    scaling = 0.95 + rand() * 0.1; % 0.95 to 1.05 scaling
    noiseLevel = 0.1; % Noise in minutiae positions
    
    % Transform template minutiae to create query
    for i = 1:length(template.minutiae)
        if rand() > 0.2 % 80% retention rate (simulate partial fingerprint)
            
            minutia = template.minutiae(i);
            
            % Apply geometric transformation
            x_orig = minutia.x - 150; % Center around origin
            y_orig = minutia.y - 150;
            
            % Scale
            x_scaled = x_orig * scaling;
            y_scaled = y_orig * scaling;
            
            % Rotate
            x_rot = x_scaled * cos(rotation) - y_scaled * sin(rotation);
            y_rot = x_scaled * sin(rotation) + y_scaled * cos(rotation);
            
            % Translate and recenter
            x_final = x_rot + 150 + translation(1);
            y_final = y_rot + 150 + translation(2);
            
            % Add noise
            x_final = x_final + (rand() - 0.5) * noiseLevel * 10;
            y_final = y_final + (rand() - 0.5) * noiseLevel * 10;
            
            % Create query minutia
            queryMinutia = struct();
            queryMinutia.x = x_final;
            queryMinutia.y = y_final;
            queryMinutia.angle = minutia.angle + rotation + (rand() - 0.5) * noiseLevel;
            queryMinutia.type = minutia.type;
            queryMinutia.quality = minutia.quality * (0.8 + rand() * 0.4); % Quality variation
            
            query.minutiae = [query.minutiae; queryMinutia];
        end
    end
    
    % Add some spurious minutiae
    numSpurious = 2;
    for i = 1:numSpurious
        spuriousMinutia = struct();
        spuriousMinutia.x = 50 + rand() * 200;
        spuriousMinutia.y = 50 + rand() * 200;
        spuriousMinutia.angle = rand() * 2 * pi;
        spuriousMinutia.type = 'ending';
        spuriousMinutia.quality = 0.3 + rand() * 0.3;
        
        query.minutiae = [query.minutiae; spuriousMinutia];
    end
    
    query.imageSize = template.imageSize;
    query.quality = mean([query.minutiae.quality]);
    query.id = 'query_001';
    
    fprintf('Created query with %d minutiae (quality: %.3f)\n', ...
        length(query.minutiae), query.quality);
    fprintf('Applied transformation: translation=[%.1f,%.1f], rotation=%.3f rad, scale=%.3f\n', ...
        translation(1), translation(2), rotation, scaling);
end

function matchResult = matchFingerprints(template, query, matchingParams)
    % Perform minutiae-based fingerprint matching
    
    if nargin < 3
        matchingParams = struct();
        matchingParams.spatialTolerance = 10; % pixels
        matchingParams.angularTolerance = pi/6; % 30 degrees
        matchingParams.minMatches = 6; % Minimum matched minutiae
        matchingParams.maxIterations = 100;
    end
    
    fprintf('Performing minutiae-based matching...\n');
    
    templateMinutiae = template.minutiae;
    queryMinutiae = query.minutiae;
    
    if length(templateMinutiae) < 3 || length(queryMinutiae) < 3
        matchResult = struct('score', 0, 'matched', 0, 'transformation', []);
        return;
    end
    
    bestScore = 0;
    bestMatches = 0;
    bestTransformation = [];
    
    % Try different alignment hypotheses
    numHypotheses = min(matchingParams.maxIterations, ...
                       length(templateMinutiae) * length(queryMinutiae));
    
    for iter = 1:numHypotheses
        % Select random minutiae pair for alignment hypothesis
        templateIdx = randi(length(templateMinutiae));
        queryIdx = randi(length(queryMinutiae));
        
        templatePoint = templateMinutiae(templateIdx);
        queryPoint = queryMinutiae(queryIdx);
        
        % Compute transformation based on this pair
        transformation = computeTransformation(templatePoint, queryPoint);
        
        % Apply transformation and count matches
        [score, numMatches] = scoreAlignment(templateMinutiae, queryMinutiae, ...
                                           transformation, matchingParams);
        
        % Update best match if current is better
        if score > bestScore
            bestScore = score;
            bestMatches = numMatches;
            bestTransformation = transformation;
        end
    end
    
    % Create match result
    matchResult = struct();
    matchResult.score = bestScore;
    matchResult.matched = bestMatches;
    matchResult.transformation = bestTransformation;
    matchResult.templateCount = length(templateMinutiae);
    matchResult.queryCount = length(queryMinutiae);
    matchResult.matchRatio = bestMatches / min(length(templateMinutiae), length(queryMinutiae));
    
    fprintf('Matching completed: score=%.3f, matches=%d/%d\n', ...
        bestScore, bestMatches, min(length(templateMinutiae), length(queryMinutiae)));
end

function transformation = computeTransformation(templatePoint, queryPoint)
    % Compute rigid transformation based on minutiae pair alignment
    
    % Translation to align positions
    tx = queryPoint.x - templatePoint.x;
    ty = queryPoint.y - templatePoint.y;
    
    % Rotation to align angles
    rotation = queryPoint.angle - templatePoint.angle;
    
    % Normalize rotation to [-羽, 羽]
    while rotation > pi
        rotation = rotation - 2*pi;
    end
    while rotation < -pi
        rotation = rotation + 2*pi;
    end
    
    transformation = struct();
    transformation.translation = [tx, ty];
    transformation.rotation = rotation;
    transformation.scale = 1.0; % Assume no scaling for simplicity
end

function [score, numMatches] = scoreAlignment(templateMinutiae, queryMinutiae, transformation, params)
    % Score the alignment of minutiae under given transformation
    
    matches = [];
    usedQuery = false(length(queryMinutiae), 1);
    
    % For each template minutia, find best matching query minutia
    for i = 1:length(templateMinutiae)
        templateMinutia = templateMinutiae(i);
        
        bestDistance = inf;
        bestQueryIdx = 0;
        
        for j = 1:length(queryMinutiae)
            if usedQuery(j)
                continue;
            end
            
            queryMinutia = queryMinutiae(j);
            
            % Transform template minutia to query coordinate system
            transformedMinutia = applyTransformation(templateMinutia, transformation);
            
            % Compute spatial distance
            spatialDistance = sqrt((transformedMinutia.x - queryMinutia.x)^2 + ...
                                 (transformedMinutia.y - queryMinutia.y)^2);
            
            % Compute angular distance
            angleDiff = abs(transformedMinutia.angle - queryMinutia.angle);
            angleDiff = min(angleDiff, 2*pi - angleDiff);
            
            % Check if within tolerance
            if spatialDistance <= params.spatialTolerance && ...
               angleDiff <= params.angularTolerance && ...
               strcmp(transformedMinutia.type, queryMinutia.type)
                
                % Compute match quality
                qualityScore = (templateMinutia.quality + queryMinutia.quality) / 2;
                distanceScore = 1 - spatialDistance / params.spatialTolerance;
                angleScore = 1 - angleDiff / params.angularTolerance;
                
                matchDistance = 1 - (qualityScore * distanceScore * angleScore);
                
                if matchDistance < bestDistance
                    bestDistance = matchDistance;
                    bestQueryIdx = j;
                end
            end
        end
        
        if bestQueryIdx > 0
            matches = [matches; i, bestQueryIdx, 1 - bestDistance];
            usedQuery(bestQueryIdx) = true;
        end
    end
    
    numMatches = size(matches, 1);
    
    if numMatches >= params.minMatches
        % Compute overall match score
        qualityScores = matches(:, 3);
        score = mean(qualityScores) * (numMatches / max(length(templateMinutiae), length(queryMinutiae)));
    else
        score = 0;
    end
end

function transformedMinutia = applyTransformation(minutia, transformation)
    % Apply geometric transformation to minutia
    
    transformedMinutia = minutia;
    
    % Apply translation
    transformedMinutia.x = minutia.x + transformation.translation(1);
    transformedMinutia.y = minutia.y + transformation.translation(2);
    
    % Apply rotation to angle
    transformedMinutia.angle = minutia.angle + transformation.rotation;
    
    % Normalize angle
    transformedMinutia.angle = mod(transformedMinutia.angle, 2*pi);
end

function advancedResult = advancedMatching(template, query)
    % Advanced matching using multiple algorithms and fusion
    
    fprintf('Performing advanced multi-algorithm matching...\n');
    
    % Algorithm 1: Standard minutiae matching
    standardResult = matchFingerprints(template, query);
    
    % Algorithm 2: Relaxed parameters matching
    relaxedParams = struct();
    relaxedParams.spatialTolerance = 15;
    relaxedParams.angularTolerance = pi/4;
    relaxedParams.minMatches = 4;
    relaxedParams.maxIterations = 150;
    
    relaxedResult = matchFingerprints(template, query, relaxedParams);
    
    % Algorithm 3: Ridge-based matching simulation
    ridgeResult = struct();
    ridgeResult.score = 0.3 + rand() * 0.4; % Simulated ridge matching score
    ridgeResult.matched = randi([5, 10]);
    
    % Score fusion using weighted combination
    weights = [0.5, 0.3, 0.2]; % Weights for different algorithms
    scores = [standardResult.score, relaxedResult.score, ridgeResult.score];
    
    fusedScore = sum(weights .* scores);
    
    % Create advanced result
    advancedResult = struct();
    advancedResult.standardScore = standardResult.score;
    advancedResult.relaxedScore = relaxedResult.score;
    advancedResult.ridgeScore = ridgeResult.score;
    advancedResult.fusedScore = fusedScore;
    advancedResult.bestMatch = standardResult;
    
    % Quality assessment
    if fusedScore > 0.7
        advancedResult.decision = 'MATCH';
        advancedResult.confidence = 'HIGH';
    elseif fusedScore > 0.4
        advancedResult.decision = 'MATCH';
        advancedResult.confidence = 'MEDIUM';
    elseif fusedScore > 0.2
        advancedResult.decision = 'NO_MATCH';
        advancedResult.confidence = 'MEDIUM';
    else
        advancedResult.decision = 'NO_MATCH';
        advancedResult.confidence = 'HIGH';
    end
    
    fprintf('Advanced matching results:\n');
    fprintf('  Standard score: %.3f\n', advancedResult.standardScore);
    fprintf('  Relaxed score: %.3f\n', advancedResult.relaxedScore);
    fprintf('  Ridge score: %.3f\n', advancedResult.ridgeScore);
    fprintf('  Fused score: %.3f\n', advancedResult.fusedScore);
    fprintf('  Decision: %s (%s confidence)\n', ...
        advancedResult.decision, advancedResult.confidence);
end

function performanceMetrics = evaluateMatchingPerformance(templateSet, querySet, algorithm)
    % Evaluate matching performance using ROC analysis
    
    fprintf('Evaluating matching performance...\n');
    
    numTemplates = length(templateSet);
    numQueries = length(querySet);
    
    % Generate match scores
    genuineScores = [];
    impostorScores = [];
    
    for i = 1:numTemplates
        for j = 1:numQueries
            matchResult = algorithm(templateSet{i}, querySet{j});
            
            if i == j % Genuine match (same finger)
                genuineScores = [genuineScores; matchResult.score];
            else % Impostor match (different fingers)
                impostorScores = [impostorScores; matchResult.score];
            end
        end
    end
    
    % Compute ROC curve
    thresholds = 0:0.01:1;
    FAR = zeros(size(thresholds)); % False Accept Rate
    FRR = zeros(size(thresholds)); % False Reject Rate
    
    for i = 1:length(thresholds)
        threshold = thresholds(i);
        
        % False accepts (impostors accepted)
        FAR(i) = sum(impostorScores >= threshold) / length(impostorScores);
        
        % False rejects (genuines rejected)
        FRR(i) = sum(genuineScores < threshold) / length(genuineScores);
    end
    
    % Find EER (Equal Error Rate)
    [~, eerIdx] = min(abs(FAR - FRR));
    EER = (FAR(eerIdx) + FRR(eerIdx)) / 2;
    
    % Compute AUC (Area Under Curve)
    AUC = trapz(FAR, 1 - FRR);
    
    performanceMetrics = struct();
    performanceMetrics.genuineScores = genuineScores;
    performanceMetrics.impostorScores = impostorScores;
    performanceMetrics.FAR = FAR;
    performanceMetrics.FRR = FRR;
    performanceMetrics.thresholds = thresholds;
    performanceMetrics.EER = EER;
    performanceMetrics.AUC = AUC;
    
    fprintf('Performance evaluation completed:\n');
    fprintf('  EER: %.3f%%\n', EER * 100);
    fprintf('  AUC: %.3f\n', AUC);
    fprintf('  Genuine scores: %.3f ㊣ %.3f\n', mean(genuineScores), std(genuineScores));
    fprintf('  Impostor scores: %.3f ㊣ %.3f\n', mean(impostorScores), std(impostorScores));
end

function visualizeMatchingResults(template, query, matchResult)
    % Visualize fingerprint matching results
    
    figure;
    
    % Template fingerprint
    subplot(1, 3, 1);
    plotFingerprint(template, 'Template Fingerprint');
    
    % Query fingerprint  
    subplot(1, 3, 2);
    plotFingerprint(query, 'Query Fingerprint');
    
    % Matching visualization
    subplot(1, 3, 3);
    visualizeMatching(template, query, matchResult);
    
    sgtitle(sprintf('Fingerprint Matching: Score = %.3f', matchResult.score));
end

function plotFingerprint(fingerprint, titleStr)
    % Plot fingerprint minutiae
    
    % Create synthetic fingerprint image background
    img = 0.5 * ones(fingerprint.imageSize);
    imshow(img);
    hold on;
    
    % Plot minutiae
    minutiae = fingerprint.minutiae;
    
    for i = 1:length(minutiae)
        minutia = minutiae(i);
        
        % Color based on type
        if strcmp(minutia.type, 'ending')
            color = 'ro';
        else
            color = 'bs';
        end
        
        plot(minutia.x, minutia.y, color, 'MarkerSize', 6, 'LineWidth', 2);
        
        % Direction arrow
        arrowLength = 8;
        dx = arrowLength * cos(minutia.angle);
        dy = arrowLength * sin(minutia.angle);
        quiver(minutia.x, minutia.y, dx, dy, 0, 'g', 'LineWidth', 1.5);
    end
    
    hold off;
    title(titleStr);
    axis equal;
    xlim([0, fingerprint.imageSize(2)]);
    ylim([0, fingerprint.imageSize(1)]);
end

function visualizeMatching(template, query, matchResult)
    % Visualize matching between template and query
    
    % Simple visualization showing match statistics
    img = 0.3 * ones(template.imageSize);
    imshow(img);
    
    % Add text information
    textInfo = {
        sprintf('Match Score: %.3f', matchResult.score),
        sprintf('Matched: %d minutiae', matchResult.matched),
        sprintf('Template: %d minutiae', matchResult.templateCount),
        sprintf('Query: %d minutiae', matchResult.queryCount),
        sprintf('Match Ratio: %.2f', matchResult.matchRatio)
    };
    
    for i = 1:length(textInfo)
        text(10, 20 + i*25, textInfo{i}, 'Color', 'white', 'FontSize', 10);
    end
    
    % Decision indicator
    if matchResult.score > 0.5
        decisionColor = 'green';
        decisionText = 'MATCH';
    else
        decisionColor = 'red';
        decisionText = 'NO MATCH';
    end
    
    text(template.imageSize(2)/2, template.imageSize(1)/2, decisionText, ...
        'Color', decisionColor, 'FontSize', 20, 'FontWeight', 'bold', ...
        'HorizontalAlignment', 'center');
    
    title('Matching Result');
end
