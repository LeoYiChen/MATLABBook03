%% chapter_AI_CV_svm_classification_01.m
% Support Vector Machine Classification for Object Recognition
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_svm_classification_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Load and prepare image dataset for SVM classification
% Create synthetic dataset for demonstration
num_samples_per_class = 200;
num_classes = 3;

% Generate feature vectors representing different object types
% Class 1: Circular objects (high roundness, medium area)
class1_features = [0.8 + 0.1*randn(num_samples_per_class, 1), ...  % Roundness
                   50 + 10*randn(num_samples_per_class, 1), ...      % Area
                   0.3 + 0.1*randn(num_samples_per_class, 1)];       % Aspect ratio

% Class 2: Rectangular objects (low roundness, variable area)
class2_features = [0.2 + 0.1*randn(num_samples_per_class, 1), ...
                   70 + 20*randn(num_samples_per_class, 1), ...
                   1.5 + 0.3*randn(num_samples_per_class, 1)];

% Class 3: Elongated objects (medium roundness, high aspect ratio)
class3_features = [0.5 + 0.15*randn(num_samples_per_class, 1), ...
                   40 + 15*randn(num_samples_per_class, 1), ...
                   2.5 + 0.5*randn(num_samples_per_class, 1)];

% Combine features and labels
features = [class1_features; class2_features; class3_features];
labels = [ones(num_samples_per_class, 1); ...
          2*ones(num_samples_per_class, 1); ...
          3*ones(num_samples_per_class, 1)];

% Add feature names for interpretability
feature_names = {'Roundness', 'Area', 'Aspect_Ratio'};

% Split data into training and testing sets
cv_partition = cvpartition(labels, 'HoldOut', 0.3);
train_idx = training(cv_partition);
test_idx = test(cv_partition);

X_train = features(train_idx, :);
y_train = labels(train_idx);
X_test = features(test_idx, :);
y_test = labels(test_idx);

% Feature normalisation (important for SVM)
[X_train_norm, norm_params] = normalize(X_train);
X_test_norm = normalize(X_test, 'center', norm_params.Center, 'scale', norm_params.Scale);

% Train different SVM models
% Linear SVM
svm_linear = fitcsvm(X_train_norm, y_train, 'KernelFunction', 'linear');

% RBF SVM with different gamma values
svm_rbf_auto = fitcsvm(X_train_norm, y_train, 'KernelFunction', 'rbf');
svm_rbf_narrow = fitcsvm(X_train_norm, y_train, 'KernelFunction', 'rbf', 'KernelScale', 0.5);
svm_rbf_wide = fitcsvm(X_train_norm, y_train, 'KernelFunction', 'rbf', 'KernelScale', 2.0);

% Polynomial SVM
svm_poly = fitcsvm(X_train_norm, y_train, 'KernelFunction', 'polynomial', 'PolynomialOrder', 3);

% Multi-class SVM using one-vs-one approach
svm_multiclass = fitcecoc(X_train_norm, y_train, 'Learners', 'svm');

% Hyperparameter optimisation
hyperparameter_opts = struct('AcquisitionFunctionName', 'expected-improvement-plus', ...
                            'MaxObjectiveEvaluations', 30, ...
                            'Verbose', 0);

optimised_svm = fitcsvm(X_train_norm, y_train, 'OptimizeHyperparameters', 'auto', ...
                       'HyperparameterOptimizationOptions', hyperparameter_opts);

% Cross-validation for model selection
k_fold = 5;
cv_linear = crossval(svm_linear, 'KFold', k_fold);
cv_rbf = crossval(svm_rbf_auto, 'KFold', k_fold);
cv_poly = crossval(svm_poly, 'KFold', k_fold);

% Calculate cross-validation errors
cv_error_linear = kfoldLoss(cv_linear);
cv_error_rbf = kfoldLoss(cv_rbf);
cv_error_poly = kfoldLoss(cv_poly);

% Prediction and evaluation
predictions_linear = predict(svm_linear, X_test_norm);
predictions_rbf = predict(svm_rbf_auto, X_test_norm);
predictions_poly = predict(svm_poly, X_test_norm);
predictions_multiclass = predict(svm_multiclass, X_test_norm);
predictions_optimised = predict(optimised_svm, X_test_norm);

% Performance metrics calculation

% Calculate metrics for different models
class_names = {'Circular', 'Rectangular', 'Elongated'};
metrics_linear = calculateClassificationMetrics(y_test, predictions_linear, class_names);
metrics_rbf = calculateClassificationMetrics(y_test, predictions_rbf, class_names);
metrics_poly = calculateClassificationMetrics(y_test, predictions_poly, class_names);
metrics_multiclass = calculateClassificationMetrics(y_test, predictions_multiclass, class_names);

% Support vector analysis
support_vectors_linear = svm_linear.SupportVectors;
support_vector_labels_linear = svm_linear.SupportVectorLabels;
num_support_vectors_linear = size(support_vectors_linear, 1);

support_vectors_rbf = svm_rbf_auto.SupportVectors;
num_support_vectors_rbf = size(support_vectors_rbf, 1);

% Decision boundary visualisation for 2*D case

% Feature importance analysis

% Analyze feature importance
feature_importance_linear = analyzeFeatureImportance(svm_linear, X_test_norm, y_test, feature_names);
feature_importance_rbf = analyzeFeatureImportance(svm_rbf_auto, X_test_norm, y_test, feature_names);

% Display comprehensive results
figure;

% Data visualisation
subplot(2,4,1);
plotDecisionBoundary(svm_linear, X_train_norm, y_train, [1, 2], 'Linear SVM Decision Boundary');

subplot(2,4,2);
plotDecisionBoundary(svm_rbf_auto, X_train_norm, y_train, [1, 2], 'RBF SVM Decision Boundary');

% Performance comparison
subplot(2,4,3);
models = {'Linear', 'RBF', 'Polynomial', 'Multi-class'};
accuracies = [metrics_linear.accuracy, metrics_rbf.accuracy, ...
              metrics_poly.accuracy, metrics_multiclass.accuracy];
bar(accuracies);
set(gca, 'XTickLabel', models);
title('Model Accuracy Comparison');
ylabel('Accuracy');
ylim([0, 1]);

% Cross-validation comparison
subplot(2,4,4);
cv_models = {'Linear', 'RBF', 'Polynomial'};
cv_errors = [cv_error_linear, cv_error_rbf, cv_error_poly];
bar(cv_errors);
set(gca, 'XTickLabel', cv_models);
title('Cross-validation Error');
ylabel('Error Rate');

% Confusion matrix for best model
subplot(2,4,5);
confusionchart(y_test, predictions_rbf, 'RowSummary', 'row-normalized', ...
               'ColumnSummary', 'column-normalized');
title('RBF SVM Confusion Matrix');

% Feature importance
subplot(2,4,6);
bar(feature_importance_rbf);
set(gca, 'XTickLabel', feature_names);
title('Feature Importance (RBF SVM)');
ylabel('Importance Score');

% Support vector analysis
subplot(2,4,7);
models_sv = {'Linear', 'RBF'};
num_sv = [num_support_vectors_linear, num_support_vectors_rbf];
bar(num_sv);
set(gca, 'XTickLabel', models_sv);
title('Number of Support Vectors');
ylabel('Count');

% Model complexity vs performance
subplot(2,4,8);
complexity_metrics = [num_support_vectors_linear/size(X_train, 1), ...
                     num_support_vectors_rbf/size(X_train, 1)];
performance_metrics = [metrics_linear.accuracy, metrics_rbf.accuracy];
scatter(complexity_metrics, performance_metrics, 100, 'filled');
xlabel('Support Vector Ratio');
ylabel('Test Accuracy');
title('Complexity vs Performance');
grid on;

% Print comprehensive analysis
fprintf('SVM Classification Performance Analysis:\n');
fprintf('Dataset: %d samples, %d features, %d classes\n', size(features, 1), size(features, 2), num_classes);
fprintf('Training set: %d samples, Test set: %d samples\n', sum(train_idx), sum(test_idx));

fprintf('\nModel Performance:\n');
fprintf('Linear SVM: %.3f accuracy, %d support vectors (%.1f%%)\n', ...
    metrics_linear.accuracy, num_support_vectors_linear, ...
    100*num_support_vectors_linear/size(X_train, 1));

fprintf('RBF SVM: %.3f accuracy, %d support vectors (%.1f%%)\n', ...
    metrics_rbf.accuracy, num_support_vectors_rbf, ...
    100*num_support_vectors_rbf/size(X_train, 1));

fprintf('Polynomial SVM: %.3f accuracy\n', metrics_poly.accuracy);
fprintf('Multi-class SVM: %.3f accuracy\n', metrics_multiclass.accuracy);

fprintf('\nCross-validation Errors:\n');
fprintf('Linear: %.3f, RBF: %.3f, Polynomial: %.3f\n', ...
    cv_error_linear, cv_error_rbf, cv_error_poly);

fprintf('\nFeature Importance (RBF SVM):\n');
for i = 1:length(feature_names)
    fprintf('%s: %.3f\n', feature_names{i}, feature_importance_rbf(i));
end

fprintf('\nPer-class Performance (RBF SVM):\n');
for i = 1:length(class_names)
    fprintf('%s: Precision=%.3f, Recall=%.3f, F1=%.3f\n', ...
        class_names{i}, metrics_rbf.precision(i), metrics_rbf.recall(i), metrics_rbf.f1_score(i));
end

% Local functions (moved to end so this listing is a valid MATLAB script)
function metrics = calculateClassificationMetrics(y_true, y_pred, class_names)
    % Confusion matrix
    conf_matrix = confusionmat(y_true, y_pred);
    
    % Overall accuracy
    accuracy = sum(y_true == y_pred) / length(y_true);
    
    % Per-class metrics
    num_classes = length(unique(y_true));
    precision = zeros(num_classes, 1);
    recall = zeros(num_classes, 1);
    f1_score = zeros(num_classes, 1);
    
    for i = 1:num_classes
        tp = conf_matrix(i, i);
        fp = sum(conf_matrix(:, i)) - tp;
        fn = sum(conf_matrix(i, :)) - tp;
        
        precision(i) = tp / (tp + fp + eps);
        recall(i) = tp / (tp + fn + eps);
        f1_score(i) = 2 * precision(i) * recall(i) / (precision(i) + recall(i) + eps);
    end
    
    % Macro averages
    macro_precision = mean(precision);
    macro_recall = mean(recall);
    macro_f1 = mean(f1_score);
    
    % Store results
    metrics.confusion_matrix = conf_matrix;
    metrics.accuracy = accuracy;
    metrics.precision = precision;
    metrics.recall = recall;
    metrics.f1_score = f1_score;
    metrics.macro_precision = macro_precision;
    metrics.macro_recall = macro_recall;
    metrics.macro_f1 = macro_f1;
end

function plotDecisionBoundary(svm_model, X, y, feature_indices, title_str)
    if length(feature_indices) ~= 2
        error('Can only plot 2*D decision boundaries');
    end
    
    % Extract 2*D features
    X_2d = X(:, feature_indices);
    
    % Create mesh grid
    x1_range = linspace(min(X_2d(:,1))-0.5, max(X_2d(:,1))+0.5, 100);
    x2_range = linspace(min(X_2d(:,2))-0.5, max(X_2d(:,2))+0.5, 100);
    [X1_mesh, X2_mesh] = meshgrid(x1_range, x2_range);
    
    % For 2*D visualisation, create 3*D points with mean of third feature
    if size(X, 2) > 2
        X3_mean = mean(X(:, 3));
        mesh_points = [X1_mesh(:), X2_mesh(:), repmat(X3_mean, numel(X1_mesh), 1)];
    else
        mesh_points = [X1_mesh(:), X2_mesh(:)];
    end
    
    % Predict on mesh
    try
        mesh_predictions = predict(svm_model, mesh_points);
        mesh_scores = reshape(mesh_predictions, size(X1_mesh));
        
        % Plot decision boundary
        contour(X1_mesh, X2_mesh, mesh_scores, [1.5, 2.5], 'LineWidth', 2);
        hold on;
        
        % Plot data points
        colors = ['r', 'g', 'b'];
        for class = 1:3
            class_indices = (y == class);
            if sum(class_indices) > 0
                scatter(X_2d(class_indices, 1), X_2d(class_indices, 2), ...
                       50, colors(class), 'filled', 'DisplayName', class_names{class});
            end
        end
        
        xlabel(feature_names{feature_indices(1)});
        ylabel(feature_names{feature_indices(2)});
        title(title_str);
        legend('show');
        grid on;
    catch
        % Fallback: just plot data points
        colors = ['r', 'g', 'b'];
        for class = 1:3
            class_indices = (y == class);
            if sum(class_indices) > 0
                scatter(X_2d(class_indices, 1), X_2d(class_indices, 2), ...
                       50, colors(class), 'filled', 'DisplayName', class_names{class});
            end
        end
        xlabel(feature_names{feature_indices(1)});
        ylabel(feature_names{feature_indices(2)});
        title(title_str);
        legend('show');
        grid on;
    end
end

function importance = analyzeFeatureImportance(svm_model, X, y, feature_names)
    num_features = size(X, 2);
    importance = zeros(num_features, 1);
    
    % Calculate baseline accuracy
    baseline_pred = predict(svm_model, X);
    baseline_accuracy = sum(y == baseline_pred) / length(y);
    
    % Permutation importance
    for i = 1:num_features
        X_permuted = X;
        X_permuted(:, i) = X_permuted(randperm(size(X, 1)), i);  % Permute feature i
        
        permuted_pred = predict(svm_model, X_permuted);
        permuted_accuracy = sum(y == permuted_pred) / length(y);
        
        importance(i) = baseline_accuracy - permuted_accuracy;
    end
end
