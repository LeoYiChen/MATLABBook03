%% chapter_AI_CV_colour_transform_01.m
% Comprehensive Colour Space Transformation Example
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_colour_transform_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Load sample colour image
rgbImage = imread('peppers.png');

% Convert to different colour spaces
labImage = rgb2lab(rgbImage);
hsvImage = rgb2hsv(rgbImage);
ycbcrImage = rgb2ycbcr(rgbImage);

% Extract individual channels for analysis
L_channel = labImage(:,:,1);  % Lightness
a_channel = labImage(:,:,2);  % Green-red component
b_channel = labImage(:,:,3);  % Blue-yellow component

H_channel = hsvImage(:,:,1);  % Hue
S_channel = hsvImage(:,:,2);  % Saturation
V_channel = hsvImage(:,:,3);  % Value

% Demonstrate colour-based segmentation using HSV
hue_mask = (H_channel > 0.1) & (H_channel < 0.3);  % Green range
saturation_mask = S_channel > 0.3;  % Sufficiently saturated
combined_mask = hue_mask & saturation_mask;

% Apply mask to original image
segmented_image = rgbImage;
segmented_image(repmat(~combined_mask, [1, 1, 3])) = 0;

% Display results
figure;
subplot(2,3,1); imshow(rgbImage); title('Original RGB');
subplot(2,3,2); imshow(L_channel, []); title('CIELAB L* Channel');
subplot(2,3,3); imshow(a_channel, []); title('CIELAB a* Channel');
subplot(2,3,4); imshow(H_channel, []); title('HSV Hue Channel');
subplot(2,3,5); imshow(combined_mask); title('Colour-based Mask');
subplot(2,3,6); imshow(segmented_image); title('Segmented Result');
