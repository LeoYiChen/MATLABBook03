%% chapter_AI_CV_binary_descriptors_01.m
% Binary Descriptors and ORB Implementation
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_binary_descriptors_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Load test images for binary descriptor demonstration
image1 = imread('coins.png');
image2 = imrotate(image1, 25);  % Rotation test
image2 = imresize(image2, 0.9); % Scale change
image2 = imnoise(image2, 'gaussian', 0, 0.005); % Light noise

if size(image1, 3) == 3
    image1 = rgb2gray(image1);
    image2 = rgb2gray(image2);
end

image1 = im2double(image1);
image2 = im2double(image2);

% ORB feature detection and description
orb_points1 = detectORBFeatures(image1);
orb_points2 = detectORBFeatures(image2);

[orb_features1, orb_valid_points1] = extractFeatures(image1, orb_points1);
[orb_features2, orb_valid_points2] = extractFeatures(image2, orb_points2);

% Binary feature matching
orb_index_pairs = matchFeatures(orb_features1, orb_features2, 'Method', 'Exhaustive');
orb_matched_points1 = orb_valid_points1(orb_index_pairs(:,1));
orb_matched_points2 = orb_valid_points2(orb_index_pairs(:,2));

% Manual BRIEF-like descriptor implementation
function brief_descriptor = computeBRIEFDescriptor(image, keypoint, patch_size, num_tests)
    if nargin < 3, patch_size = 31; end
    if nargin < 4, num_tests = 256; end
    
    x = round(keypoint.Location(1));
    y = round(keypoint.Location(2));
    half_size = floor(patch_size / 2);
    
    % Extract patch around keypoint
    if y-half_size > 0 && y+half_size <= size(image,1) && ...
       x-half_size > 0 && x+half_size <= size(image,2)
        
        patch = image(y-half_size:y+half_size, x-half_size:x+half_size);
        
        % Pre-defined random sampling pattern (normally stored)
        rng(42); % Fixed seed for reproducibility
        test_pattern = zeros(num_tests, 4);
        for i = 1:num_tests
            % Generate random pairs within patch
            test_pattern(i, :) = [randi(patch_size, 1, 2), randi(patch_size, 1, 2)];
        end
        
        % Compute binary descriptor
        brief_descriptor = false(num_tests, 1);
        for i = 1:num_tests
            y1 = test_pattern(i, 1);
            x1 = test_pattern(i, 2);
            y2 = test_pattern(i, 3);
            x2 = test_pattern(i, 4);
            
            brief_descriptor(i) = patch(y1, x1) < patch(y2, x2);
        end
    else
        brief_descriptor = false(num_tests, 1);
    end
end

% Oriented BRIEF implementation
function [oriented_descriptor, orientation] = computeOrientedBRIEF(image, keypoint)
    x = round(keypoint.Location(1));
    y = round(keypoint.Location(2));
    patch_size = 31;
    half_size = floor(patch_size / 2);
    
    if y-half_size > 0 && y+half_size <= size(image,1) && ...
       x-half_size > 0 && x+half_size <= size(image,2)
        
        patch = image(y-half_size:y+half_size, x-half_size:x+half_size);
        
        % Compute image moments for orientation
        [X, Y] = meshgrid(-half_size:half_size, -half_size:half_size);
        
        % First-order moments
        m10 = sum(sum(X .* patch));
        m01 = sum(sum(Y .* patch));
        
        % Principal orientation
        orientation = atan2(m01, m10);
        
        % Create rotation matrix
        cos_theta = cos(orientation);
        sin_theta = sin(orientation);
        rotation_matrix = [cos_theta, -sin_theta; sin_theta, cos_theta];
        
        % Generate rotated sampling pattern
        num_tests = 256;
        rng(42); % Fixed seed
        original_pattern = zeros(num_tests, 4);
        for i = 1:num_tests
            original_pattern(i, :) = [randi(patch_size, 1, 2), randi(patch_size, 1, 2)];
        end
        
        % Rotate sampling points
        oriented_descriptor = false(num_tests, 1);
        for i = 1:num_tests
            % Convert to centered coordinates
            p1 = [original_pattern(i, 2) - half_size - 1; original_pattern(i, 1) - half_size - 1];
            p2 = [original_pattern(i, 4) - half_size - 1; original_pattern(i, 3) - half_size - 1];
            
            % Apply rotation
            p1_rot = rotation_matrix * p1;
            p2_rot = rotation_matrix * p2;
            
            % Convert back to patch coordinates
            x1_rot = round(p1_rot(1) + half_size + 1);
            y1_rot = round(p1_rot(2) + half_size + 1);
            x2_rot = round(p2_rot(1) + half_size + 1);
            y2_rot = round(p2_rot(2) + half_size + 1);
            
            % Check bounds and compute comparison
            if x1_rot > 0 && x1_rot <= patch_size && y1_rot > 0 && y1_rot <= patch_size && ...
               x2_rot > 0 && x2_rot <= patch_size && y2_rot > 0 && y2_rot <= patch_size
                oriented_descriptor(i) = patch(y1_rot, x1_rot) < patch(y2_rot, x2_rot);
            end
        end
    else
        oriented_descriptor = false(256, 1);
        orientation = 0;
    end
end

% Compute manual descriptors for comparison
if ~isempty(orb_valid_points1)
    sample_point1 = orb_valid_points1(1);
    sample_point2 = orb_valid_points2(1);
    
    brief_desc1 = computeBRIEFDescriptor(image1, sample_point1);
    brief_desc2 = computeBRIEFDescriptor(image2, sample_point2);
    
    [oriented_desc1, orient1] = computeOrientedBRIEF(image1, sample_point1);
    [oriented_desc2, orient2] = computeOrientedBRIEF(image2, sample_point2);
end

% Binary descriptor matching function
function matches = matchBinaryDescriptors(desc1, desc2, threshold)
    if nargin < 3, threshold = 50; end  % Hamming distance threshold
    
    matches = [];
    for i = 1:size(desc1, 1)
        distances = sum(xor(desc1(i, :), desc2), 2);  % Hamming distance
        [min_dist, min_idx] = min(distances);
        
        if min_dist < threshold
            % Check for unique match (ratio test adapted for binary)
            distances(min_idx) = inf;
            second_min = min(distances);
            
            if min_dist < 0.8 * second_min  % Ratio test
                matches = [matches; i, min_idx, min_dist];
            end
        end
    end
end

% Performance comparison between descriptor types
function performance_stats = analyzeDescriptorPerformance(features, image_pair)
    stats.descriptor_size = size(features, 2);
    stats.computation_time = []; % Would measure in practice
    stats.memory_usage = whos('features').bytes;
    
    if size(features, 1) > 0
        stats.descriptor_sparsity = mean(features(:) == 0);
        stats.mean_hamming_weight = mean(sum(features, 2));
    else
        stats.descriptor_sparsity = 0;
        stats.mean_hamming_weight = 0;
    end
    
    performance_stats = stats;
end

% Analyze ORB performance
orb_performance = analyzeDescriptorPerformance(orb_features1, []);

% Robust geometric verification
if size(orb_matched_points1, 1) >= 4
    try
        [orb_transform, orb_inlier_idx] = estimateGeometricTransform2D(...
            orb_matched_points1, orb_matched_points2, 'similarity', ...
            'MaxDistance', 4, 'Confidence', 95);
        
        orb_inliers1 = orb_matched_points1(orb_inlier_idx);
        orb_inliers2 = orb_matched_points2(orb_inlier_idx);
        orb_inlier_ratio = length(orb_inlier_idx) / size(orb_matched_points1, 1);
    catch
        orb_inliers1 = [];
        orb_inliers2 = [];
        orb_inlier_ratio = 0;
    end
end

% FAST corner detection for comparison (ORB uses FAST)
fast_corners1 = detectFASTFeatures(image1);
fast_corners2 = detectFASTFeatures(image2);

% Descriptor distinctiveness analysis
function distinctiveness = analyzeDescriptorDistinctiveness(features)
    if size(features, 1) < 2
        distinctiveness = [];
        return;
    end
    
    % Compute all pairwise Hamming distances
    num_features = size(features, 1);
    distances = zeros(num_features, num_features);
    
    for i = 1:num_features
        for j = i+1:num_features
            hamming_dist = sum(xor(features(i, :), features(j, :)));
            distances(i, j) = hamming_dist;
            distances(j, i) = hamming_dist;
        end
    end
    
    % Remove diagonal (self-comparisons)
    distances(distances == 0) = inf;
    
    distinctiveness.mean_distance = mean(distances(~isinf(distances)));
    distinctiveness.min_distance = min(distances(~isinf(distances)));
    distinctiveness.std_distance = std(distances(~isinf(distances)));
end

orb_distinctiveness = analyzeDescriptorDistinctiveness(orb_features1);

% Display comprehensive results
figure;

% Feature detection comparison
subplot(2,4,1);
imshow(image1); hold on;
plot(fast_corners1.Location(:,1), fast_corners1.Location(:,2), 'r+', 'MarkerSize', 4);
title(sprintf('FAST Corners (%d)', length(fast_corners1)));

subplot(2,4,2);
imshow(image1); hold on;
plot(orb_valid_points1.Location(:,1), orb_valid_points1.Location(:,2), 'g+', 'MarkerSize', 4);
title(sprintf('ORB Features (%d)', length(orb_valid_points1)));

subplot(2,4,3);
imshow(image2); hold on;
plot(orb_valid_points2.Location(:,1), orb_valid_points2.Location(:,2), 'g+', 'MarkerSize', 4);
title(sprintf('ORB Features (%d)', length(orb_valid_points2)));

% Feature matching visualization
if exist('orb_inliers1', 'var') && ~isempty(orb_inliers1)
    subplot(2,4,4);
    showMatchedFeatures(image1, image2, orb_inliers1, orb_inliers2);
    title(sprintf('ORB Matches (%d)', length(orb_inliers1)));
end

% Binary descriptor visualization
subplot(2,4,5);
if ~isempty(orb_features1)
    imagesc(orb_features1(1:min(50, size(orb_features1,1)), :));
    colormap('gray'); title('ORB Descriptors (Binary)');
    xlabel('Descriptor Dimension'); ylabel('Feature Index');
end

subplot(2,4,6);
if ~isempty(orb_features1)
    histogram(sum(orb_features1, 2), 30);
    title('Hamming Weight Distribution');
    xlabel('Number of 1*s in Descriptor'); ylabel('Frequency');
end

% Performance metrics
subplot(2,4,7);
if exist('orb_distinctiveness', 'var') && ~isempty(orb_distinctiveness)
    metrics = {'Mean Dist', 'Min Dist', 'Std Dist'};
    values = [orb_distinctiveness.mean_distance, orb_distinctiveness.min_distance, orb_distinctiveness.std_distance];
    bar(values);
    set(gca, 'XTickLabel', metrics);
    title('Descriptor Distinctiveness');
    ylabel('Hamming Distance');
end

subplot(2,4,8);
descriptor_sizes = [128, 64, 32];  % SIFT, SURF, ORB
descriptor_names = {'SIFT', 'SURF', 'ORB'};
bar(descriptor_sizes);
set(gca, 'XTickLabel', descriptor_names);
title('Descriptor Size Comparison');
ylabel('Dimensions');

% Print comprehensive analysis
fprintf('Binary Descriptor Performance Analysis:\n');
fprintf('ORB Features: %d (Image 1), %d (Image 2)\n', ...
    length(orb_valid_points1), length(orb_valid_points2));
fprintf('ORB Matches: %d total', size(orb_matched_points1, 1));

if exist('orb_inlier_ratio', 'var')
    fprintf(', %d inliers (%.1f%%)\n', ...
        length(orb_inliers1), orb_inlier_ratio * 100);
else
    fprintf(', 0 inliers\n');
end

fprintf('ORB Descriptor: %d bits, %.1f average Hamming weight\n', ...
    orb_performance.descriptor_size, orb_performance.mean_hamming_weight);

if ~isempty(orb_distinctiveness)
    fprintf('Descriptor distinctiveness: %.1f ㊣ %.1f Hamming distance\n', ...
        orb_distinctiveness.mean_distance, orb_distinctiveness.std_distance);
end

fprintf('Memory usage: ORB = %d bytes, SIFT equivalent ＞ %d bytes\n', ...
    orb_performance.memory_usage, orb_performance.memory_usage * 32);  % 32*x for float vs binary

% Local function copied from another listing in this chapter
function matches = matchFeatures(descriptors1, descriptors2, points1, points2, threshold)
% Find matches between feature descriptors using nearest neighbor ratio test

 
if isempty(descriptors1) || isempty(descriptors2)
    matches = [];
    return;
end

matches = [];

for i = 1:size(descriptors1, 1)
    desc1 = descriptors1(i, :);
    
    % Compute distances to all descriptors in second image
    distances = sqrt(sum((descriptors2 - desc1).^2, 2));
    
    % Find two nearest neighbors
    [sortedDist, sortedIdx] = sort(distances);
    
    if length(sortedDist) >= 2
        % Ratio test for distinctive matches
        ratio = sortedDist(1) / sortedDist(2);
        
        if ratio < threshold && sortedDist(1) < 0.5 % Additional distance threshold
            matches(end+1, :) = [i, sortedIdx(1), sortedDist(1), ratio];
        end
    end
end
end
