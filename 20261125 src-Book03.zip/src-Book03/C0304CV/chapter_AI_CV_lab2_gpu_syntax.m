%% chapter_AI_CV_lab2_gpu_syntax.m
% GPU acceleration syntax in MATLAB.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_lab2_gpu_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Transfer data to GPU
gpuData = gpuArray(cpuData);

% Perform GPU computation
result = arrayfun(@gpuFunction, gpuData);

% Transfer result back to CPU
cpuResult = gather(result);
