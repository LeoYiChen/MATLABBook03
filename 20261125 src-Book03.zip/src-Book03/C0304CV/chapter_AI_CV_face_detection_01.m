%% chapter_AI_CV_face_detection_01.m
% Advanced Face Detection and Alignment System
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_face_detection_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Advanced Face Detection and Alignment System
fprintf('Face Detection and Alignment System\n');
fprintf('==================================\n');

% Create or load test images with faces
testImages = createTestFaceImages();




% 1. Face Detection using Cascade Object Detector

% 2. Enhanced Face Detection with Multiple Detectors

% 3. Facial Landmark Detection



% 4. Face Alignment

% 5. Comprehensive Face Processing Pipeline


% Test the face processing pipeline
fprintf('\nTesting face processing pipeline on synthetic images...\n');

for i = 1:length(testImages)
    fprintf('\nProcessing test image %d:\n', i);
    
    % Process the image
    faces = processFaceImage(testImages{i});
    
    if ~isempty(faces)
        fprintf('Found %d face(s)\n', length(faces));
        for j = 1:length(faces)
            face = faces(j);
            fprintf('  Face %d: Quality = %.3f (%s), Confidence = %.3f\n', ...
                j, face.quality.overall, face.quality.classification, face.confidence);
        end
    end
end

% 6. Visualization Functions


% Visualize results for first test image
if ~isempty(testImages)
    % Test detection on first image
    detResults = enhancedFaceDetection(testImages{1});
    visualizeFaceDetection(testImages{1}, detResults);
    
    if detResults.numFaces > 0
        % Test landmark detection on first face
        landmarks = detectFacialLandmarks(testImages{1}, detResults.boundingBoxes(1, :));
        visualizeLandmarks(testImages{1}, landmarks);
        
        % Test alignment
        alignedFace = alignFace(testImages{1}, landmarks, [100, 100]);
        figure;
        subplot(1, 2, 1);
        imshow(testImages{1});
        title('Original Image');
        
        subplot(1, 2, 2);
        imshow(alignedFace);
        title('Aligned Face');
    end
end

% Summary of techniques and best practices
fprintf('\nFace Detection and Alignment Summary:\n');
fprintf('====================================\n');
fprintf('1. Multi-detector approach for robustness\n');
fprintf('2. Landmark-based alignment for normalization\n');
fprintf('3. Quality assessment for reliability\n');
fprintf('4. Efficient processing pipelines\n');

fprintf('\nBest Practices:\n');
fprintf('===============\n');
fprintf('1. Use multiple detection algorithms for different pose variations\n');
fprintf('2. Implement robust landmark detection with fallback mechanisms\n');
fprintf('3. Apply quality assessment to filter poor detections\n');
fprintf('4. Consider computational efficiency for real-time applications\n');
fprintf('5. Validate performance across diverse demographic groups\n');
fprintf('6. Handle edge cases (partial occlusion, extreme poses)\n');
fprintf('7. Implement secure and privacy-preserving processing\n');
fprintf('8. Regular performance monitoring and system updates\n');

% Local functions (moved to end so this listing is a valid MATLAB script)
function images = createTestFaceImages()
    % Create synthetic face images for demonstration
    
    fprintf('Creating synthetic face images for testing...\n');
    
    images = cell(4, 1);
    imageSize = [200, 200, 3];
    
    for i = 1:4
        % Create synthetic face image
        img = createSyntheticFace(imageSize, i);
        images{i} = img;
    end
    
    fprintf('Created %d test face images\n', length(images));
end

function faceImg = createSyntheticFace(imageSize, faceID)
    % Create synthetic face image with basic facial features
    
    faceImg = zeros(imageSize, 'uint8');
    
    % Face region (oval)
    [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
    centerX = imageSize(2) / 2 + (rand() - 0.5) * 20; % Small random offset
    centerY = imageSize(1) / 2 + (rand() - 0.5) * 20;
    
    % Face shape parameters
    faceWidth = 60 + rand() * 20;
    faceHeight = 80 + rand() * 20;
    
    % Create face oval
    faceRegion = ((X - centerX) / faceWidth).^2 + ((Y - centerY) / faceHeight).^2 <= 1;
    
    % Base skin color
    skinColor = [220, 180, 140] + randi([-20, 20], [1, 3]); % Variation in skin tone
    
    for c = 1:3
        channel = faceImg(:, :, c);
        channel(faceRegion) = skinColor(c);
        faceImg(:, :, c) = channel;
    end
    
    % Add facial features
    faceImg = addFacialFeatures(faceImg, centerX, centerY, faceWidth, faceHeight);
    
    % Add background
    background = uint8(rand(imageSize) * 100 + 50); % Random background
    for c = 1:3
        channel = faceImg(:, :, c);
        bgChannel = background(:, :, min(c, size(background, 3)));
        channel(~faceRegion) = bgChannel(~faceRegion);
        faceImg(:, :, c) = channel;
    end
end

function faceImg = addFacialFeatures(faceImg, centerX, centerY, faceWidth, faceHeight)
    % Add basic facial features to synthetic face
    
    [imageHeight, imageWidth, ~] = size(faceImg);
    
    % Eye positions
    eyeY = centerY - faceHeight * 0.15;
    leftEyeX = centerX - faceWidth * 0.25;
    rightEyeX = centerX + faceWidth * 0.25;
    
    eyeRadius = 8;
    
    % Left eye
    if leftEyeX >= eyeRadius && leftEyeX <= imageWidth - eyeRadius && ...
       eyeY >= eyeRadius && eyeY <= imageHeight - eyeRadius
        
        [X, Y] = meshgrid(1:imageWidth, 1:imageHeight);
        leftEyeMask = (X - leftEyeX).^2 + (Y - eyeY).^2 <= eyeRadius^2;
        
        faceImg(leftEyeMask) = 50; % Dark eye color
    end
    
    % Right eye
    if rightEyeX >= eyeRadius && rightEyeX <= imageWidth - eyeRadius && ...
       eyeY >= eyeRadius && eyeY <= imageHeight - eyeRadius
        
        rightEyeMask = (X - rightEyeX).^2 + (Y - eyeY).^2 <= eyeRadius^2;
        faceImg(rightEyeMask) = 50; % Dark eye color
    end
    
    % Nose (simple triangle)
    noseX = centerX;
    noseY = centerY;
    noseSize = 8;
    
    for dy = -noseSize:noseSize
        for dx = -noseSize:noseSize
            x = round(noseX + dx);
            y = round(noseY + dy);
            
            if x >= 1 && x <= imageWidth && y >= 1 && y <= imageHeight
                if abs(dx) <= abs(dy) + noseSize/2 && dy >= -noseSize/2
                    for c = 1:3
                        faceImg(y, x, c) = max(0, double(faceImg(y, x, c)) - 30);
                    end
                end
            end
        end
    end
    
    % Mouth
    mouthY = centerY + faceHeight * 0.3;
    mouthWidth = 20;
    mouthHeight = 5;
    
    for dy = -mouthHeight:mouthHeight
        for dx = -mouthWidth:mouthWidth
            x = round(centerX + dx);
            y = round(mouthY + dy);
            
            if x >= 1 && x <= imageWidth && y >= 1 && y <= imageHeight
                if dx^2 / mouthWidth^2 + dy^2 / mouthHeight^2 <= 1
                    faceImg(y, x, :) = 100; % Dark mouth color
                end
            end
        end
    end
end

function faceDetectionResults = detectFaces(image)
    % Detect faces using Viola-Jones cascade detector
    
    fprintf('Detecting faces in image...\n');
    
    % Create face detector
    faceDetector = vision.CascadeObjectDetector('FrontalFaceCART');
    
    % Convert to grayscale if needed
    if size(image, 3) == 3
        grayImage = rgb2gray(image);
    else
        grayImage = image;
    end
    
    % Detect faces
    bboxes = step(faceDetector, grayImage);
    
    % Store results
    faceDetectionResults = struct();
    faceDetectionResults.boundingBoxes = bboxes;
    faceDetectionResults.numFaces = size(bboxes, 1);
    faceDetectionResults.confidence = ones(size(bboxes, 1), 1); % Default confidence
    
    fprintf('Detected %d faces\n', faceDetectionResults.numFaces);
end

function enhancedResults = enhancedFaceDetection(image)
    % Enhanced face detection using multiple cascade detectors
    
    fprintf('Performing enhanced face detection...\n');
    
    % Convert to grayscale
    if size(image, 3) == 3
        grayImage = rgb2gray(image);
    else
        grayImage = image;
    end
    
    % Multiple detectors for different views
    detectors = {
        vision.CascadeObjectDetector('FrontalFaceCART'),
        vision.CascadeObjectDetector('ProfileFace'),
        vision.CascadeObjectDetector('FrontalFaceLBP')
    };
    
    detectorNames = {'Frontal', 'Profile', 'LBP'};
    
    allBboxes = [];
    allConfidences = [];
    allTypes = {};
    
    for i = 1:length(detectors)
        try
            bboxes = step(detectors{i}, grayImage);
            
            if ~isempty(bboxes)
                % Add detection type and confidence
                numDetections = size(bboxes, 1);
                confidences = ones(numDetections, 1) * (1 - 0.1 * (i-1)); % Decreasing confidence
                types = repmat({detectorNames{i}}, numDetections, 1);
                
                allBboxes = [allBboxes; bboxes];
                allConfidences = [allConfidences; confidences];
                allTypes = [allTypes; types];
            end
            
        catch ME
            fprintf('Warning: Detector %s failed: %s\n', detectorNames{i}, ME.message);
        end
    end
    
    % Non-maximum suppression to remove overlapping detections
    if ~isempty(allBboxes)
        [selectedBboxes, selectedIndices] = selectStrongestBbox(allBboxes, allConfidences);
        finalConfidences = allConfidences(selectedIndices);
        finalTypes = allTypes(selectedIndices);
    else
        selectedBboxes = [];
        finalConfidences = [];
        finalTypes = {};
    end
    
    enhancedResults = struct();
    enhancedResults.boundingBoxes = selectedBboxes;
    enhancedResults.confidences = finalConfidences;
    enhancedResults.detectorTypes = finalTypes;
    enhancedResults.numFaces = size(selectedBboxes, 1);
    
    fprintf('Enhanced detection found %d faces\n', enhancedResults.numFaces);
end

function landmarks = detectFacialLandmarks(image, faceRegion)
    % Detect facial landmarks within detected face region
    
    fprintf('Detecting facial landmarks...\n');
    
    % Extract face region
    if size(faceRegion, 1) == 1 && size(faceRegion, 2) == 4
        % faceRegion is bounding box [x, y, width, height]
        x = max(1, round(faceRegion(1)));
        y = max(1, round(faceRegion(2)));
        width = round(faceRegion(3));
        height = round(faceRegion(4));
        
        x2 = min(size(image, 2), x + width - 1);
        y2 = min(size(image, 1), y + height - 1);
        
        faceImage = image(y:y2, x:x2, :);
        offset = [x-1, y-1]; % Offset to convert back to original coordinates
    else
        faceImage = image;
        offset = [0, 0];
    end
    
    % Convert to grayscale
    if size(faceImage, 3) == 3
        grayFace = rgb2gray(faceImage);
    else
        grayFace = faceImage;
    end
    
    [faceHeight, faceWidth] = size(grayFace);
    
    % Simplified landmark detection using template matching and heuristics
    landmarks = struct();
    
    % Estimate eye positions based on facial proportions
    landmarks.leftEye = [faceWidth * 0.3, faceHeight * 0.35] + offset;
    landmarks.rightEye = [faceWidth * 0.7, faceHeight * 0.35] + offset;
    
    % Refine eye positions using template matching
    landmarks.leftEye = refineEyePosition(grayFace, landmarks.leftEye - offset) + offset;
    landmarks.rightEye = refineEyePosition(grayFace, landmarks.rightEye - offset) + offset;
    
    % Other facial landmarks based on proportions
    landmarks.noseTip = [faceWidth * 0.5, faceHeight * 0.55] + offset;
    landmarks.mouthLeft = [faceWidth * 0.35, faceHeight * 0.75] + offset;
    landmarks.mouthRight = [faceWidth * 0.65, faceHeight * 0.75] + offset;
    landmarks.mouthCenter = [faceWidth * 0.5, faceHeight * 0.75] + offset;
    
    % Face outline points
    landmarks.leftCheek = [faceWidth * 0.15, faceHeight * 0.5] + offset;
    landmarks.rightCheek = [faceWidth * 0.85, faceHeight * 0.5] + offset;
    landmarks.chin = [faceWidth * 0.5, faceHeight * 0.9] + offset;
    
    fprintf('Detected %d facial landmarks\n', length(fieldnames(landmarks)));
end

function refinedPosition = refineEyePosition(grayImage, estimatedPosition)
    % Refine eye position using template matching
    
    % Create simple eye template
    eyeTemplate = createEyeTemplate();
    
    % Search region around estimated position
    searchRadius = 10;
    [imageHeight, imageWidth] = size(grayImage);
    
    x = round(estimatedPosition(1));
    y = round(estimatedPosition(2));
    
    % Define search region
    x1 = max(1, x - searchRadius);
    x2 = min(imageWidth, x + searchRadius);
    y1 = max(1, y - searchRadius);
    y2 = min(imageHeight, y + searchRadius);
    
    searchRegion = grayImage(y1:y2, x1:x2);
    
    % Template matching
    try
        correlation = normxcorr2(eyeTemplate, searchRegion);
        
        % Find peak correlation
        [maxCorr, maxIdx] = max(correlation(:));
        [peakY, peakX] = ind2sub(size(correlation), maxIdx);
        
        % Convert back to image coordinates
        templateSize = size(eyeTemplate);
        refinedX = x1 + peakX - templateSize(2);
        refinedY = y1 + peakY - templateSize(1);
        
        refinedPosition = [refinedX, refinedY];
        
    catch
        % If template matching fails, return original estimate
        refinedPosition = estimatedPosition;
    end
end

function eyeTemplate = createEyeTemplate()
    % Create simple eye template for matching
    
    templateSize = [11, 15];
    eyeTemplate = zeros(templateSize);
    
    % Create simple eye shape
    [X, Y] = meshgrid(1:templateSize(2), 1:templateSize(1));
    centerX = templateSize(2) / 2;
    centerY = templateSize(1) / 2;
    
    % Elliptical eye shape
    eyeMask = ((X - centerX) / 6).^2 + ((Y - centerY) / 4).^2 <= 1;
    eyeTemplate(eyeMask) = -1; % Dark eye region
    
    % Pupil
    pupilMask = ((X - centerX) / 3).^2 + ((Y - centerY) / 3).^2 <= 1;
    eyeTemplate(pupilMask) = -2; % Darker pupil
    
    % Normalize template
    eyeTemplate = eyeTemplate / norm(eyeTemplate(:));
end

function alignedFace = alignFace(image, landmarks, targetSize)
    % Align face based on eye positions
    
    if nargin < 3
        targetSize = [100, 100];
    end
    
    fprintf('Aligning face to standard pose...\n');
    
    % Extract eye positions
    leftEye = landmarks.leftEye;
    rightEye = landmarks.rightEye;
    
    % Compute eye center and angle
    eyeCenter = (leftEye + rightEye) / 2;
    eyeAngle = atan2(rightEye(2) - leftEye(2), rightEye(1) - leftEye(1));
    
    % Desired eye positions in aligned face
    desiredLeftEye = [targetSize(2) * 0.35, targetSize(1) * 0.35];
    desiredRightEye = [targetSize(2) * 0.65, targetSize(1) * 0.35];
    desiredEyeCenter = (desiredLeftEye + desiredRightEye) / 2;
    
    % Compute transformation
    % 1. Translate to center eyes at origin
    % 2. Rotate to align eyes horizontally
    % 3. Scale to match desired eye distance
    % 4. Translate to desired position
    
    currentEyeDistance = norm(rightEye - leftEye);
    desiredEyeDistance = norm(desiredRightEye - desiredLeftEye);
    scale = desiredEyeDistance / currentEyeDistance;
    
    % Create transformation matrix
    T1 = [1, 0, -eyeCenter(1); 0, 1, -eyeCenter(2); 0, 0, 1]; % Center
    R = [cos(-eyeAngle), -sin(-eyeAngle), 0; sin(-eyeAngle), cos(-eyeAngle), 0; 0, 0, 1]; % Rotate
    S = [scale, 0, 0; 0, scale, 0; 0, 0, 1]; % Scale
    T2 = [1, 0, desiredEyeCenter(1); 0, 1, desiredEyeCenter(2); 0, 0, 1]; % Translate
    
    % Combined transformation
    combinedTransform = T2 * S * R * T1;
    
    % Apply transformation
    tform = affine2d(combinedTransform');
    alignedFace = imwarp(image, tform, 'OutputView', imref2d(targetSize));
    
    fprintf('Face alignment completed\n');
end

function processedFaces = processFaceImage(image, options)
    % Complete face processing pipeline
    
    if nargin < 2
        options = struct();
        options.detectionMethod = 'enhanced';
        options.alignmentSize = [100, 100];
        options.qualityAssessment = true;
    end
    
    fprintf('Processing face image through complete pipeline...\n');
    
    processedFaces = [];
    
    % Face detection
    if strcmp(options.detectionMethod, 'enhanced')
        detectionResults = enhancedFaceDetection(image);
    else
        detectionResults = detectFaces(image);
    end
    
    if detectionResults.numFaces == 0
        fprintf('No faces detected in image\n');
        return;
    end
    
    % Process each detected face
    for i = 1:detectionResults.numFaces
        faceData = struct();
        
        % Extract face region
        bbox = detectionResults.boundingBoxes(i, :);
        faceData.boundingBox = bbox;
        faceData.confidence = detectionResults.confidences(i);
        
        % Detect landmarks
        landmarks = detectFacialLandmarks(image, bbox);
        faceData.landmarks = landmarks;
        
        % Align face
        alignedFace = alignFace(image, landmarks, options.alignmentSize);
        faceData.alignedFace = alignedFace;
        
        % Quality assessment
        if options.qualityAssessment
            quality = assessFaceQuality(alignedFace, landmarks);
            faceData.quality = quality;
        end
        
        processedFaces = [processedFaces; faceData];
    end
    
    fprintf('Processed %d faces successfully\n', length(processedFaces));
end

function quality = assessFaceQuality(faceImage, landmarks)
    % Assess quality of detected/aligned face
    
    quality = struct();
    
    % Convert to grayscale for analysis
    if size(faceImage, 3) == 3
        grayFace = rgb2gray(faceImage);
    else
        grayFace = faceImage;
    end
    
    % Sharpness (gradient magnitude)
    [Gx, Gy] = gradient(double(grayFace));
    gradMagnitude = sqrt(Gx.^2 + Gy.^2);
    quality.sharpness = mean(gradMagnitude(:));
    
    % Contrast (standard deviation)
    quality.contrast = std(double(grayFace(:)));
    
    % Illumination uniformity
    quality.illumination = 1 / (1 + std(double(grayFace(:))));
    
    % Landmark confidence (based on expected positions)
    if ~isempty(landmarks)
        % Check if eyes are horizontally aligned
        leftEye = landmarks.leftEye;
        rightEye = landmarks.rightEye;
        eyeAngle = abs(atan2(rightEye(2) - leftEye(2), rightEye(1) - leftEye(1)));
        quality.alignment = 1 - min(1, eyeAngle / (pi/6)); % Penalty for misalignment
    else
        quality.alignment = 0;
    end
    
    % Overall quality score
    quality.overall = (quality.sharpness/50 + quality.contrast/50 + ...
                      quality.illumination + quality.alignment) / 4;
    quality.overall = min(1, max(0, quality.overall));
    
    % Quality classification
    if quality.overall > 0.7
        quality.classification = 'Good';
    elseif quality.overall > 0.4
        quality.classification = 'Fair';
    else
        quality.classification = 'Poor';
    end
end

function visualizeFaceDetection(image, detectionResults)
    % Visualize face detection results
    
    figure;
    imshow(image);
    hold on;
    
    if detectionResults.numFaces > 0
        % Draw bounding boxes
        for i = 1:detectionResults.numFaces
            bbox = detectionResults.boundingBoxes(i, :);
            confidence = detectionResults.confidences(i);
            
            % Draw rectangle
            rectangle('Position', bbox, 'EdgeColor', 'red', 'LineWidth', 2);
            
            % Add confidence label
            text(bbox(1), bbox(2) - 5, sprintf('%.2f', confidence), ...
                'Color', 'red', 'FontSize', 12, 'FontWeight', 'bold');
        end
    end
    
    hold off;
    title(sprintf('Face Detection Results (%d faces)', detectionResults.numFaces));
end

function visualizeLandmarks(image, landmarks)
    % Visualize facial landmarks
    
    figure;
    imshow(image);
    hold on;
    
    landmarkNames = fieldnames(landmarks);
    colors = lines(length(landmarkNames));
    
    for i = 1:length(landmarkNames)
        landmarkPos = landmarks.*(landmarkNames{i});
        plot(landmarkPos(1), landmarkPos(2), 'o', 'Color', colors(i, :), ...
             'MarkerSize', 8, 'LineWidth', 2);
        
        text(landmarkPos(1) + 3, landmarkPos(2), landmarkNames{i}, ...
             'Color', colors(i, :), 'FontSize', 8);
    end
    
    hold off;
    title('Facial Landmarks');
end
