%% chapter_AI_CV_code_optimisation_01.m
% Comprehensive Code Optimisation Framework for Computer Vision Applications
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_code_optimisation_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Comprehensive Code Optimisation Framework for Computer Vision
fprintf('Code Optimisation Framework for Computer Vision\n');
fprintf('==============================================\n');

% Create test datasets for optimisation demonstrations
[testImages, testData] = createOptimisationTestData();


% 1. Vectorisation Optimisation




% 2. Memory Access Optimisation





% 3. Image Processing Optimisation




% 4. Loop Optimisation Techniques




% 5. Advanced Optimisation Strategies







% Test all optimisation strategies
fprintf('\nTesting comprehensive code optimisation framework...\n');

% Run all optimisation demonstrations
vectorisationResults = demonstrateVectorisation();
memoryResults = demonstrateMemoryOptimisation();
imageResults = demonstrateImageProcessingOptimisation();
loopResults = demonstrateLoopOptimisation();
advancedResults = demonstrateAdvancedOptimisation();

% Visualise optimisation results
figure;

% Vectorisation speedups
subplot(3, 4, 1);
speedups = [1, vectorisationResults.speedupVectorised, vectorisationResults.speedupBLAS];
methods = {'Scalar', 'Vectorised', 'BLAS'};
bar(speedups);
set(gca, 'XTickLabel', methods);
title('Vectorisation Speedups');
ylabel('Speedup Factor');

% Memory access patterns
subplot(3, 4, 2);
memoryTimes = [memoryResults.rowMajorTime, memoryResults.columnMajorTime, ...
              memoryResults.blockedTime, memoryResults.vectorisedTime];
memoryMethods = {'Row-major', 'Column-major', 'Blocked', 'Vectorised'};
bar(memoryTimes);
set(gca, 'XTickLabel', memoryMethods);
xtickangle(45);
title('Memory Access Performance');
ylabel('Time (seconds)');

% Image processing optimisation
subplot(3, 4, 3);
imageSpeedups = [1, imageResults.speedupSeparable, imageResults.speedupBuiltin];
imageMethods = {'Naive', 'Separable', 'Built-in'};
bar(imageSpeedups);
set(gca, 'XTickLabel', imageMethods);
title('Image Processing Speedups');
ylabel('Speedup Factor');

% Loop optimisation
subplot(3, 4, 4);
loopSpeedups = [1, loopResults.speedupUnrolled, loopResults.speedupBlocked, loopResults.speedupBuiltin];
loopMethods = {'Basic', 'Unrolled', 'Blocked', 'BLAS'};
bar(loopSpeedups);
set(gca, 'XTickLabel', loopMethods);
xtickangle(45);
title('Loop Optimisation Speedups');
ylabel('Speedup Factor');

% Data structure comparison
subplot(3, 4, 5);
dataComparison = [advancedResults.dataStructures.denseTime, advancedResults.dataStructures.sparseTime];
bar(dataComparison);
set(gca, 'XTickLabel', {'Dense', 'Sparse'});
title('Data Structure Performance');
ylabel('Time (seconds)');

% Algorithm selection
subplot(3, 4, 6);
if isfield(advancedResults.algorithms, 'dataSizes')
    dataSizes = advancedResults.algorithms.dataSizes;
    loglog(dataSizes, advancedResults.algorithms.quickSortTimes, 'b-o');
    hold on;
    loglog(dataSizes, advancedResults.algorithms.mergeSortTimes, 'r-s');
    loglog(dataSizes, advancedResults.algorithms.builtinSortTimes, 'g-^');
    hold off;
    xlabel('Data Size');
    ylabel('Time (seconds)');
    title('Algorithm Scaling');
    legend({'QuickSort', 'MergeSort', 'Built-in'});
    grid on;
end

% Precision comparison
subplot(3, 4, 7);
precisionComparison = [advancedResults.precision.doubleTime, advancedResults.precision.singleTime];
bar(precisionComparison);
set(gca, 'XTickLabel', {'Double', 'Single'});
title('Precision Performance');
ylabel('Time (seconds)');

% Memory efficiency
subplot(3, 4, 8);
memoryEfficiency = [advancedResults.dataStructures.memoryRatio, advancedResults.precision.memoryReduction];
memoryCategories = {'Sparse vs Dense', 'Single vs Double'};
bar(memoryEfficiency);
set(gca, 'XTickLabel', memoryCategories);
xtickangle(45);
title('Memory Efficiency');
ylabel('Memory Reduction Factor');

% Overall optimisation impact
subplot(3, 4, [9, 10]);
optimisationCategories = {'Vectorisation', 'Memory Access', 'Image Processing', 'Loop Optimisation', 'Data Structures', 'Precision'};
maxSpeedups = [vectorisationResults.speedupBLAS, memoryResults.speedupVectorised, ...
              imageResults.speedupBuiltin, loopResults.speedupBuiltin, ...
              advancedResults.dataStructures.sparseSpeedup, advancedResults.precision.singleSpeedup];

bar(maxSpeedups);
set(gca, 'XTickLabel', optimisationCategories);
xtickangle(45);
title('Maximum Achievable Speedups');
ylabel('Speedup Factor');

% Optimisation trade-offs
subplot(3, 4, [11, 12]);
accuracyLoss = [0, 0, 0, 0, 0, advancedResults.precision.accuracyLoss * 1e6]; % Convert to micro-units
yyaxis left;
bar(maxSpeedups);
ylabel('Speedup Factor');
yyaxis right;
bar(accuracyLoss, 'r');
ylabel('Accuracy Loss (℅10^{-6})');
set(gca, 'XTickLabel', optimisationCategories);
xtickangle(45);
title('Performance vs Accuracy Trade-offs');

sgtitle('Comprehensive Code Optimisation Results');

% Display optimisation summary
fprintf('\n' + string(repmat('=', 1, 60)) + '\n');
fprintf('CODE OPTIMISATION SUMMARY\n');
fprintf(string(repmat('=', 1, 60)) + '\n');

fprintf('\nVECTORISATION OPTIMISATION:\n');
fprintf('  Vectorised speedup: %.1fx\n', vectorisationResults.speedupVectorised);
fprintf('  BLAS speedup: %.1fx\n', vectorisationResults.speedupBLAS);

fprintf('\nMEMORY ACCESS OPTIMISATION:\n');
fprintf('  Blocked speedup: %.1fx\n', memoryResults.speedupBlocked);
fprintf('  Vectorised speedup: %.1fx\n', memoryResults.speedupVectorised);

fprintf('\nIMAGE PROCESSING OPTIMISATION:\n');
fprintf('  Separable filter speedup: %.1fx\n', imageResults.speedupSeparable);
fprintf('  Built-in function speedup: %.1fx\n', imageResults.speedupBuiltin);

fprintf('\nLOOP OPTIMISATION:\n');
fprintf('  Unrolled loops speedup: %.1fx\n', loopResults.speedupUnrolled);
fprintf('  Blocked loops speedup: %.1fx\n', loopResults.speedupBlocked);
fprintf('  BLAS speedup: %.1fx\n', loopResults.speedupBuiltin);

fprintf('\nADVANCED OPTIMISATIONS:\n');
fprintf('  Sparse matrix speedup: %.1fx\n', advancedResults.dataStructures.sparseSpeedup);
fprintf('  Single precision speedup: %.1fx\n', advancedResults.precision.singleSpeedup);
fprintf('  Memory reduction (sparse): %.1fx\n', advancedResults.dataStructures.memoryRatio);
fprintf('  Memory reduction (single): %.1fx\n', advancedResults.precision.memoryReduction);

fprintf('\nOPTIMISATION BEST PRACTICES:\n');
fprintf('============================\n');
fprintf(' Use vectorised operations instead of explicit loops\n');
fprintf(' Optimise memory access patterns for cache efficiency\n');
fprintf(' Leverage built-in MATLAB functions when possible\n');
fprintf(' Consider separable filters for 2*D operations\n');
fprintf(' Use appropriate data types and structures\n');
fprintf(' Profile code to identify bottlenecks\n');
fprintf(' Balance performance with numerical accuracy\n');
fprintf(' Pre-allocate arrays to avoid dynamic memory allocation\n');

fprintf('\n' + string(repmat('=', 1, 60)) + '\n');

% Local functions (moved to end so this listing is a valid MATLAB script)
function [images, data] = createOptimisationTestData()
    % Create test data for optimisation demonstrations
    
    fprintf('Creating optimisation test data...\n');
    
    % Generate test images of different sizes
    imageSizes = {[256, 256], [512, 512], [1024, 1024], [2048, 2048]};
    images = cell(length(imageSizes), 1);
    
    for i = 1:length(imageSizes)
        size = imageSizes{i};
        images{i} = uint8(rand(size) * 255);
    end
    
    % Generate test data structures
    data = struct();
    data.matrices = {
        rand(1000, 1000, 'single'),
        rand(2000, 2000, 'single'),
        rand(500, 500, 100, 'single')  % 3*D array
    };
    
    data.vectors = {
        rand(1000000, 1, 'single'),
        rand(5000000, 1, 'single')
    };
    
    fprintf('Created test data with %d image sizes and %d data structures\n', ...
        length(imageSizes), length(data.matrices) + length(data.vectors));
end

function optimisationResults = demonstrateVectorisation()
    % Demonstrate vectorisation optimisation techniques
    
    fprintf('Demonstrating vectorisation optimisation...\n');
    
    optimisationResults = struct();
    
    % Test data
    n = 1000000;
    a = rand(n, 1, 'single');
    b = rand(n, 1, 'single');
    c = rand(n, 1, 'single');
    
    % Scalar implementation (slow)
    tic;
    result_scalar = scalarComputation(a, b, c);
    time_scalar = toc;
    
    % Vectorised implementation (fast)
    tic;
    result_vectorised = vectorisedComputation(a, b, c);
    time_vectorised = toc;
    
    % BLAS-optimised implementation (fastest)
    tic;
    result_blas = blasOptimisedComputation(a, b, c);
    time_blas = toc;
    
    % Store results
    optimisationResults.scalarTime = time_scalar;
    optimisationResults.vectorisedTime = time_vectorised;
    optimisationResults.blasTime = time_blas;
    optimisationResults.speedupVectorised = time_scalar / time_vectorised;
    optimisationResults.speedupBLAS = time_scalar / time_blas;
    
    % Verify correctness
    optimisationResults.correctnessCheck = struct();
    optimisationResults.correctnessCheck.vectorisedCorrect = max(abs(result_scalar - result_vectorised)) < 1e-6;
    optimisationResults.correctnessCheck.blasCorrect = max(abs(result_scalar - result_blas)) < 1e-6;
    
    fprintf('Vectorisation demonstration completed\n');
    fprintf('  Scalar time: %.4f seconds\n', time_scalar);
    fprintf('  Vectorised time: %.4f seconds (%.1fx speedup)\n', time_vectorised, optimisationResults.speedupVectorised);
    fprintf('  BLAS time: %.4f seconds (%.1fx speedup)\n', time_blas, optimisationResults.speedupBLAS);
end

function result = scalarComputation(a, b, c)
    % Scalar implementation (inefficient)
    
    n = length(a);
    result = zeros(n, 1, 'single');
    
    for i = 1:n
        result(i) = sqrt(a(i)^2 + b(i)^2) + sin(c(i)) * cos(c(i));
    end
end

function result = vectorisedComputation(a, b, c)
    % Vectorised implementation (efficient)
    
    result = sqrt(a.^2 + b.^2) + sin(c) .* cos(c);
end

function result = blasOptimisedComputation(a, b, c)
    % BLAS-optimised implementation using built-in functions
    
    % Use optimised norm computation
    norms = hypot(a, b);  % Optimised sqrt(a^2 + b^2)
    
    % Use optimised trigonometric computation
    trigTerms = sin(c) .* cos(c);
    
    result = norms + trigTerms;
end

function memoryResults = demonstrateMemoryOptimisation()
    % Demonstrate memory access pattern optimisation
    
    fprintf('Demonstrating memory optimisation...\n');
    
    memoryResults = struct();
    
    % Create large test matrix
    n = 2000;
    matrix = rand(n, n, 'single');
    
    % Row-major access (cache-friendly in MATLAB)
    tic;
    result_rowmajor = rowMajorAccess(matrix);
    time_rowmajor = toc;
    
    % Column-major access (cache-unfriendly)
    tic;
    result_colmajor = columnMajorAccess(matrix);
    time_colmajor = toc;
    
    % Block-wise access (cache-optimised)
    tic;
    result_blocked = blockedAccess(matrix, 64);
    time_blocked = toc;
    
    % Vectorised access (optimal)
    tic;
    result_vectorised = vectorisedAccess(matrix);
    time_vectorised = toc;
    
    % Store results
    memoryResults.rowMajorTime = time_rowmajor;
    memoryResults.columnMajorTime = time_colmajor;
    memoryResults.blockedTime = time_blocked;
    memoryResults.vectorisedTime = time_vectorised;
    
    memoryResults.speedupBlocked = time_colmajor / time_blocked;
    memoryResults.speedupVectorised = time_colmajor / time_vectorised;
    
    fprintf('Memory optimisation demonstration completed\n');
    fprintf('  Row-major: %.4f seconds\n', time_rowmajor);
    fprintf('  Column-major: %.4f seconds\n', time_colmajor);
    fprintf('  Blocked: %.4f seconds (%.1fx speedup over column-major)\n', time_blocked, memoryResults.speedupBlocked);
    fprintf('  Vectorised: %.4f seconds (%.1fx speedup over column-major)\n', time_vectorised, memoryResults.speedupVectorised);
end

function result = rowMajorAccess(matrix)
    % Row-major memory access pattern
    
    [rows, cols] = size(matrix);
    result = 0;
    
    for i = 1:rows
        for j = 1:cols
            result = result + matrix(i, j)^2;
        end
    end
end

function result = columnMajorAccess(matrix)
    % Column-major memory access pattern (inefficient in MATLAB)
    
    [rows, cols] = size(matrix);
    result = 0;
    
    for j = 1:cols
        for i = 1:rows
            result = result + matrix(i, j)^2;
        end
    end
end

function result = blockedAccess(matrix, blockSize)
    % Block-wise memory access for better cache utilisation
    
    [rows, cols] = size(matrix);
    result = 0;
    
    for iBlock = 1:blockSize:rows
        for jBlock = 1:blockSize:cols
            % Define block boundaries
            iEnd = min(iBlock + blockSize - 1, rows);
            jEnd = min(jBlock + blockSize - 1, cols);
            
            % Process block
            block = matrix(iBlock:iEnd, jBlock:jEnd);
            result = result + sum(block(:).^2);
        end
    end
end

function result = vectorisedAccess(matrix)
    % Vectorised access (optimal)
    
    result = sum(matrix(:).^2);
end

function imageResults = demonstrateImageProcessingOptimisation()
    % Demonstrate image processing optimisation techniques
    
    fprintf('Demonstrating image processing optimisation...\n');
    
    imageResults = struct();
    
    % Create test image
    imageSize = [1024, 1024];
    testImage = uint8(rand(imageSize) * 255);
    
    % Gaussian filter implementations
    sigma = 2.0;
    kernelSize = 2 * ceil(3 * sigma) + 1;
    
    % Naive implementation
    tic;
    result_naive = naiveGaussianFilter(testImage, sigma, kernelSize);
    time_naive = toc;
    
    % Separable implementation
    tic;
    result_separable = separableGaussianFilter(testImage, sigma);
    time_separable = toc;
    
    % Built-in optimised implementation
    tic;
    result_builtin = imgaussfilt(testImage, sigma);
    time_builtin = toc;
    
    % Integral image implementation for box filter
    tic;
    result_integral = integralImageFilter(testImage, 9);
    time_integral = toc;
    
    % Store results
    imageResults.naiveTime = time_naive;
    imageResults.separableTime = time_separable;
    imageResults.builtinTime = time_builtin;
    imageResults.integralTime = time_integral;
    
    imageResults.speedupSeparable = time_naive / time_separable;
    imageResults.speedupBuiltin = time_naive / time_builtin;
    
    fprintf('Image processing optimisation completed\n');
    fprintf('  Naive Gaussian: %.4f seconds\n', time_naive);
    fprintf('  Separable Gaussian: %.4f seconds (%.1fx speedup)\n', time_separable, imageResults.speedupSeparable);
    fprintf('  Built-in Gaussian: %.4f seconds (%.1fx speedup)\n', time_builtin, imageResults.speedupBuiltin);
    fprintf('  Integral box filter: %.4f seconds\n', time_integral);
end

function filtered = naiveGaussianFilter(image, sigma, kernelSize)
    % Naive 2*D Gaussian filter implementation
    
    % Create 2*D Gaussian kernel
    kernel = fspecial('gaussian', kernelSize, sigma);
    
    % Apply convolution
    filtered = imfilter(double(image), kernel, 'same', 'replicate');
    filtered = uint8(filtered);
end

function filtered = separableGaussianFilter(image, sigma)
    % Separable Gaussian filter implementation
    
    % Create 1*D Gaussian kernel
    kernelSize = 2 * ceil(3 * sigma) + 1;
    x = linspace(-(kernelSize-1)/2, (kernelSize-1)/2, kernelSize);
    kernel1D = exp(-x.^2 / (2 * sigma^2));
    kernel1D = kernel1D / sum(kernel1D);
    
    % Apply separable convolution
    imageDouble = double(image);
    
    % Horizontal pass
    temp = imfilter(imageDouble, kernel1D, 'same', 'replicate');
    
    % Vertical pass
    filtered = imfilter(temp, kernel1D', 'same', 'replicate');
    filtered = uint8(filtered);
end

function filtered = integralImageFilter(image, filterSize)
    % Box filter using integral image for O(1) filtering
    
    % Compute integral image
    integralImg = cumsum(cumsum(double(image), 1), 2);
    
    % Pad integral image
    paddedIntegral = padarray(integralImg, [1, 1], 0, 'pre');
    
    [rows, cols] = size(image);
    filtered = zeros(rows, cols);
    
    halfSize = floor(filterSize / 2);
    
    for i = 1:rows
        for j = 1:cols
            % Define box boundaries (with boundary checks)
            x1 = max(1, j - halfSize);
            y1 = max(1, i - halfSize);
            x2 = min(cols, j + halfSize);
            y2 = min(rows, i + halfSize);
            
            % Compute box sum using integral image
            boxSum = paddedIntegral(y2+1, x2+1) - paddedIntegral(y1, x2+1) - ...
                    paddedIntegral(y2+1, x1) + paddedIntegral(y1, x1);
            
            % Compute average
            boxArea = (x2 - x1 + 1) * (y2 - y1 + 1);
            filtered(i, j) = boxSum / boxArea;
        end
    end
    
    filtered = uint8(filtered);
end

function loopResults = demonstrateLoopOptimisation()
    % Demonstrate loop optimisation techniques
    
    fprintf('Demonstrating loop optimisation...\n');
    
    loopResults = struct();
    
    % Test data
    n = 1000;
    A = rand(n, n, 'single');
    B = rand(n, n, 'single');
    
    % Basic nested loops
    tic;
    C_basic = basicMatrixMultiply(A, B);
    time_basic = toc;
    
    % Loop unrolling
    tic;
    C_unrolled = unrolledMatrixMultiply(A, B);
    time_unrolled = toc;
    
    % Cache-blocked implementation
    tic;
    C_blocked = blockedMatrixMultiply(A, B, 64);
    time_blocked = toc;
    
    % Built-in optimised implementation
    tic;
    C_builtin = A * B;
    time_builtin = toc;
    
    % Store results
    loopResults.basicTime = time_basic;
    loopResults.unrolledTime = time_unrolled;
    loopResults.blockedTime = time_blocked;
    loopResults.builtinTime = time_builtin;
    
    loopResults.speedupUnrolled = time_basic / time_unrolled;
    loopResults.speedupBlocked = time_basic / time_blocked;
    loopResults.speedupBuiltin = time_basic / time_builtin;
    
    % Verify correctness
    loopResults.correctnessCheck = struct();
    loopResults.correctnessCheck.unrolledCorrect = max(abs(C_basic(:) - C_unrolled(:))) < 1e-4;
    loopResults.correctnessCheck.blockedCorrect = max(abs(C_basic(:) - C_blocked(:))) < 1e-4;
    
    fprintf('Loop optimisation demonstration completed\n');
    fprintf('  Basic loops: %.4f seconds\n', time_basic);
    fprintf('  Unrolled loops: %.4f seconds (%.1fx speedup)\n', time_unrolled, loopResults.speedupUnrolled);
    fprintf('  Blocked loops: %.4f seconds (%.1fx speedup)\n', time_blocked, loopResults.speedupBlocked);
    fprintf('  Built-in BLAS: %.4f seconds (%.1fx speedup)\n', time_builtin, loopResults.speedupBuiltin);
end

function C = basicMatrixMultiply(A, B)
    % Basic matrix multiplication with nested loops
    
    [m, k] = size(A);
    [~, n] = size(B);
    C = zeros(m, n, 'single');
    
    for i = 1:m
        for j = 1:n
            for l = 1:k
                C(i, j) = C(i, j) + A(i, l) * B(l, j);
            end
        end
    end
end

function C = unrolledMatrixMultiply(A, B)
    % Matrix multiplication with loop unrolling
    
[m, k] = size(A);
    [~, n] = size(B);
    C = zeros(m, n, 'single');
    
    % Unroll inner loop by factor of 4
    for i = 1:m
        for j = 1:n
            sum_val = 0;
            l = 1;
            
            % Process 4 elements at a time
            while l <= k - 3
                sum_val = sum_val + A(i, l) * B(l, j) + ...
                         A(i, l+1) * B(l+1, j) + ...
                         A(i, l+2) * B(l+2, j) + ...
                         A(i, l+3) * B(l+3, j);
                l = l + 4;
            end
            
            % Handle remaining elements
            while l <= k
                sum_val = sum_val + A(i, l) * B(l, j);
                l = l + 1;
            end
            
            C(i, j) = sum_val;
        end
    end
end

function C = blockedMatrixMultiply(A, B, blockSize)
    % Cache-blocked matrix multiplication
    
    [m, k] = size(A);
    [~, n] = size(B);
    C = zeros(m, n, 'single');
    
    for i = 1:blockSize:m
        for j = 1:blockSize:n
            for l = 1:blockSize:k
                % Define block boundaries
                iEnd = min(i + blockSize - 1, m);
                jEnd = min(j + blockSize - 1, n);
                lEnd = min(l + blockSize - 1, k);
                
                % Multiply blocks
                C(i:iEnd, j:jEnd) = C(i:iEnd, j:jEnd) + ...
                                   A(i:iEnd, l:lEnd) * B(l:lEnd, j:jEnd);
            end
        end
    end
end

function advancedResults = demonstrateAdvancedOptimisation()
    % Demonstrate advanced optimisation strategies
    
    fprintf('Demonstrating advanced optimisation strategies...\n');
    
    advancedResults = struct();
    
    % Data structure optimisation
    dataResults = optimiseDataStructures();
    advancedResults.dataStructures = dataResults;
    
    % Algorithm selection optimisation
    algorithmResults = optimiseAlgorithmSelection();
    advancedResults.algorithms = algorithmResults;
    
    % Precision optimisation
    precisionResults = optimisePrecision();
    advancedResults.precision = precisionResults;
    
    fprintf('Advanced optimisation demonstration completed\n');
end

function results = optimiseDataStructures()
    % Compare different data structures for computer vision tasks
    
    results = struct();
    
    % Test data: sparse vs dense matrices
    n = 5000;
    density = 0.01; % 1% non-zero elements
    
    % Create sparse matrix
    numNonZero = round(n * n * density);
    rows = randi(n, numNonZero, 1);
    cols = randi(n, numNonZero, 1);
    values = rand(numNonZero, 1);
    sparseMat = sparse(rows, cols, values, n, n);
    
    % Create equivalent dense matrix
    denseMat = full(sparseMat);
    
    % Vector multiplication timing
    testVector = rand(n, 1);
    
    % Sparse multiplication
    tic;
    result_sparse = sparseMat * testVector;
    time_sparse = toc;
    
    % Dense multiplication
    tic;
    result_dense = denseMat * testVector;
    time_dense = toc;
    
    results.sparseTime = time_sparse;
    results.denseTime = time_dense;
    results.sparseSpeedup = time_dense / time_sparse;
    results.memoryRatio = whos('denseMat').bytes / whos('sparseMat').bytes;
    
    fprintf('  Sparse matrix: %.4f seconds\n', time_sparse);
    fprintf('  Dense matrix: %.4f seconds\n', time_dense);
    fprintf('  Sparse speedup: %.1fx\n', results.sparseSpeedup);
    fprintf('  Memory reduction: %.1fx\n', results.memoryRatio);
end

function results = optimiseAlgorithmSelection()
    % Demonstrate algorithm selection based on data characteristics
    
    results = struct();
    
    % Different sorting algorithms for different data sizes
    dataSizes = [100, 1000, 10000, 100000];
    
    results.quickSortTimes = zeros(size(dataSizes));
    results.mergeSortTimes = zeros(size(dataSizes));
    results.builtinSortTimes = zeros(size(dataSizes));
    
    for i = 1:length(dataSizes)
        n = dataSizes(i);
        testData = rand(n, 1);
        
        % Quick sort (simplified implementation)
        tic;
        sorted_quick = quickSort(testData);
        results.quickSortTimes(i) = toc;
        
        % Merge sort (simplified implementation)
        tic;
        sorted_merge = mergeSort(testData);
        results.mergeSortTimes(i) = toc;
        
        % Built-in sort
        tic;
        sorted_builtin = sort(testData);
        results.builtinSortTimes(i) = toc;
    end
    
    results.dataSizes = dataSizes;
end

function sortedArray = quickSort(array)
    % Simple quicksort implementation
    
    if length(array) <= 1
        sortedArray = array;
        return;
    end
    
    pivot = array(1);
    left = array(array < pivot);
    middle = array(array == pivot);
    right = array(array > pivot);
    
    sortedArray = [quickSort(left); middle; quickSort(right)];
end

function sortedArray = mergeSort(array)
    % Simple merge sort implementation
    
    if length(array) <= 1
        sortedArray = array;
        return;
    end
    
    mid = floor(length(array) / 2);
    left = mergeSort(array(1:mid));
    right = mergeSort(array(mid+1:end));
    
    sortedArray = mergeArrays(left, right);
end

function merged = mergeArrays(left, right)
    % Merge two sorted arrays
    
    merged = zeros(length(left) + length(right), 1);
    i = 1; j = 1; k = 1;
    
    while i <= length(left) && j <= length(right)
        if left(i) <= right(j)
            merged(k) = left(i);
            i = i + 1;
        else
            merged(k) = right(j);
            j = j + 1;
        end
        k = k + 1;
    end
    
    % Copy remaining elements
    while i <= length(left)
        merged(k) = left(i);
        i = i + 1;
        k = k + 1;
    end
    
    while j <= length(right)
        merged(k) = right(j);
        j = j + 1;
        k = k + 1;
    end
end

function results = optimisePrecision()
    % Demonstrate precision optimisation
    
    results = struct();
    
    % Test data
    n = 10000;
    data_double = rand(n, n);
    data_single = single(data_double);
    data_half = half(data_single); % If available
    
    % Matrix operations with different precisions
    tic;
    result_double = data_double * data_double';
    time_double = toc;
    
    tic;
    result_single = data_single * data_single';
    time_single = toc;
    
    results.doubleTime = time_double;
    results.singleTime = time_single;
    results.singleSpeedup = time_double / time_single;
    
    % Memory comparison
    results.doubleMemory = whos('data_double').bytes;
    results.singleMemory = whos('data_single').bytes;
    results.memoryReduction = results.doubleMemory / results.singleMemory;
    
    % Accuracy comparison
    results.accuracyLoss = max(abs(double(result_single(:)) - result_double(:)));
    
    fprintf('  Double precision: %.4f seconds\n', time_double);
    fprintf('  Single precision: %.4f seconds (%.1fx speedup)\n', time_single, results.singleSpeedup);
    fprintf('  Memory reduction: %.1fx\n', results.memoryReduction);
    fprintf('  Max accuracy loss: %.2e\n', results.accuracyLoss);
end
