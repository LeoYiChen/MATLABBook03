%% chapter_AI_CV_frequency_enhancement_01.m
% Frequency Domain Enhancement Techniques
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_frequency_enhancement_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Load test image for frequency domain processing
test_image = imread('cameraman.tif');
test_image = im2double(test_image);

% Compute 2*D FFT and center zero frequency
fft_image = fft2(test_image);
fft_centered = fftshift(fft_image);

% Calculate magnitude and phase spectra
magnitude_spectrum = log(abs(fft_centered) + 1);  % Log scale for visualisation
phase_spectrum = angle(fft_centered);

% Get image dimensions for filter design
[rows, cols] = size(test_image);
center_row = floor(rows/2) + 1;
center_col = floor(cols/2) + 1;

% Create coordinate grids for filter design
[X, Y] = meshgrid(1:cols, 1:rows);
X = X - center_col;
Y = Y - center_row;
distance_from_center = sqrt(X.^2 + Y.^2);

% Design different frequency domain filters
% Low-pass filter (smoothing)
cutoff_low = 30;
lowpass_filter = double(distance_from_center <= cutoff_low);

% High-pass filter (sharpening)
cutoff_high = 20;
highpass_filter = double(distance_from_center >= cutoff_high);

% Band-pass filter
cutoff_low_band = 10;
cutoff_high_band = 50;
bandpass_filter = double((distance_from_center >= cutoff_low_band) & ...
                        (distance_from_center <= cutoff_high_band));

% Gaussian low-pass filter (smooth transition)
sigma_freq = 25;
gaussian_lowpass = exp(-(distance_from_center.^2) / (2 * sigma_freq^2));

% Butterworth high-pass filter
cutoff_butterworth = 30;
order = 2;
butterworth_highpass = 1 ./ (1 + (cutoff_butterworth ./ ...
                              (distance_from_center + eps)).^(2 * order));

% Apply filters in frequency domain
filtered_fft_lowpass = fft_centered .* lowpass_filter;
filtered_fft_highpass = fft_centered .* highpass_filter;
filtered_fft_bandpass = fft_centered .* bandpass_filter;
filtered_fft_gaussian = fft_centered .* gaussian_lowpass;
filtered_fft_butterworth = fft_centered .* butterworth_highpass;

% Convert back to spatial domain
filtered_lowpass = real(ifft2(ifftshift(filtered_fft_lowpass)));
filtered_highpass = real(ifft2(ifftshift(filtered_fft_highpass)));
filtered_bandpass = real(ifft2(ifftshift(filtered_fft_bandpass)));
filtered_gaussian = real(ifft2(ifftshift(filtered_fft_gaussian)));
filtered_butterworth = real(ifft2(ifftshift(filtered_fft_butterworth)));

% Unsharp masking enhancement
unsharp_mask = test_image - filtered_gaussian;
alpha = 1.5;  % Enhancement factor
unsharp_enhanced = test_image + alpha * unsharp_mask;
unsharp_enhanced = max(0, min(1, unsharp_enhanced));  % Clamp to valid range

% High-frequency emphasis enhancement
emphasis_factor = 2.0;
hf_emphasis_filter = 1 + emphasis_factor * butterworth_highpass;
filtered_fft_emphasis = fft_centered .* hf_emphasis_filter;
hf_emphasis_enhanced = real(ifft2(ifftshift(filtered_fft_emphasis)));
hf_emphasis_enhanced = max(0, min(1, hf_emphasis_enhanced));

% Display comprehensive results
figure;

% Original image and spectrum
subplot(4,4,1); imshow(test_image); title('Original Image');
subplot(4,4,2); imshow(magnitude_spectrum, []); title('Magnitude Spectrum');
subplot(4,4,3); imshow(phase_spectrum, []); title('Phase Spectrum');

% Filter visualisations
subplot(4,4,4); imshow(lowpass_filter); title('Low-pass Filter');
subplot(4,4,5); imshow(filtered_lowpass); title('Low-pass Filtered');
subplot(4,4,6); imshow(highpass_filter); title('High-pass Filter');
subplot(4,4,7); imshow(filtered_highpass, []); title('High-pass Filtered');
subplot(4,4,8); imshow(gaussian_lowpass); title('Gaussian Low-pass');

subplot(4,4,9); imshow(filtered_gaussian); title('Gaussian Filtered');
subplot(4,4,10); imshow(butterworth_highpass); title('Butterworth High-pass');
subplot(4,4,11); imshow(filtered_butterworth, []); title('Butterworth Filtered');
subplot(4,4,12); imshow(unsharp_enhanced); title('Unsharp Masking');

% Enhancement comparison
subplot(4,4,13); imshow(hf_emphasis_enhanced); title('HF Emphasis');
subplot(4,4,14); imshow(abs(unsharp_mask), []); title('Unsharp Mask');

% Frequency response analysis
subplot(4,4,15);
freq_axis = 0:min(rows,cols)/2-1;
radial_lowpass = gaussian_lowpass(center_row, center_col:end);
radial_highpass = butterworth_highpass(center_row, center_col:end);
plot(freq_axis, radial_lowpass(1:length(freq_axis)), 'b-', 'LineWidth', 2);
hold on;
plot(freq_axis, radial_highpass(1:length(freq_axis)), 'r-', 'LineWidth', 2);
legend('Gaussian LP', 'Butterworth HP');
title('Filter Responses');
xlabel('Frequency'); ylabel('Magnitude');

% Quality assessment
subplot(4,4,16);
original_edges = edge(test_image, 'canny');
enhanced_edges = edge(unsharp_enhanced, 'canny');
edge_enhancement = sum(enhanced_edges(:)) / sum(original_edges(:));

methods = {'Original', 'Gaussian LP', 'Unsharp', 'HF Emphasis'};
edge_counts = [sum(original_edges(:)), sum(edge(filtered_gaussian, 'canny'), 'all'), ...
               sum(enhanced_edges(:)), sum(edge(hf_emphasis_enhanced, 'canny'), 'all')];
bar(edge_counts);
set(gca, 'XTickLabel', methods);
title('Edge Content Analysis');
ylabel('Edge Pixels');

fprintf('Frequency Domain Enhancement Analysis:\n');
fprintf('Original edge pixels: %d\n', sum(original_edges(:)));
fprintf('Unsharp masking edge enhancement: %.2fx\n', edge_enhancement);
fprintf('High-frequency emphasis factor: %.1f\n', emphasis_factor);
