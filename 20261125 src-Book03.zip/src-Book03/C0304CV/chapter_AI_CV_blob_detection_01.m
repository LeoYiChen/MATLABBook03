%% chapter_AI_CV_blob_detection_01.m
% Scale-Space Blob Detection Implementation
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_blob_detection_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Load test image suitable for blob detection
test_image = imread('coins.png');
if size(test_image, 3) == 3
    test_image = rgb2gray(test_image);
end
test_image = im2double(test_image);

% MATLAB built-in blob detection using MSER
mser_regions = detectMSERFeatures(test_image);
mser_locations = mser_regions.Location;

% Manual implementation of Laplacian of Gaussian blob detection

% Apply LoG blob detection
[log_blobs, scale_space, log_responses] = detectLoGBlobs(test_image, 1, 10, 10, 0.01);

% Difference of Gaussians (DoG) implementation

% Apply DoG blob detection
[dog_blobs, dog_responses] = detectDoGBlobs(test_image, 1, 10, 10, 0.005);

% Determinant of Hessian blob detection

% Apply Hessian blob detection
[hessian_blobs, hessian_responses] = detectHessianBlobs(test_image, 1, 8, 8, 0.001);

% Blob overlap and non-maximum suppression

% Apply non-maximum suppression
log_blobs_filtered = suppressOverlappingBlobs(log_blobs, 2.0);
dog_blobs_filtered = suppressOverlappingBlobs(dog_blobs, 2.0);
hessian_blobs_filtered = suppressOverlappingBlobs(hessian_blobs, 2.0);

% Display comprehensive results
figure;

% Original image with different blob detections
subplot(2,4,1);
imshow(test_image); hold on;
if ~isempty(mser_locations)
    plot(mser_locations(:,1), mser_locations(:,2), 'r+', 'MarkerSize', 8, 'LineWidth', 2);
end
title('MSER Regions');

subplot(2,4,2);
imshow(test_image); hold on;
if ~isempty(log_blobs_filtered)
    for i = 1:min(20, size(log_blobs_filtered, 1))
        x = log_blobs_filtered(i, 1);
        y = log_blobs_filtered(i, 2);
        sigma = log_blobs_filtered(i, 3);
        viscircles([x, y], 2*sigma, 'EdgeColor', 'g', 'LineWidth', 1.5);
    end
end
title('LoG Blobs');

subplot(2,4,3);
imshow(test_image); hold on;
if ~isempty(dog_blobs_filtered)
    for i = 1:min(20, size(dog_blobs_filtered, 1))
        x = dog_blobs_filtered(i, 1);
        y = dog_blobs_filtered(i, 2);
        sigma = dog_blobs_filtered(i, 3);
        viscircles([x, y], 2*sigma, 'EdgeColor', 'b', 'LineWidth', 1.5);
    end
end
title('DoG Blobs');

subplot(2,4,4);
imshow(test_image); hold on;
if ~isempty(hessian_blobs_filtered)
    for i = 1:min(20, size(hessian_blobs_filtered, 1))
        x = hessian_blobs_filtered(i, 1);
        y = hessian_blobs_filtered(i, 2);
        sigma = hessian_blobs_filtered(i, 3);
        viscircles([x, y], 2*sigma, 'EdgeColor', 'm', 'LineWidth', 1.5);
    end
end
title('Hessian Blobs');

% Scale-space visualization
subplot(2,4,5); imshow(scale_space(:,:,3), []); title('Gaussian Scale 考=2.15');
subplot(2,4,6); imshow(log_responses(:,:,5), []); title('LoG Response 考=3.16');
subplot(2,4,7); imshow(dog_responses(:,:,5), []); title('DoG Response');
subplot(2,4,8); imshow(hessian_responses(:,:,4), []); title('Hessian Response');

% Quantitative analysis
fprintf('Blob Detection Performance Analysis:\n');
fprintf('MSER regions: %d detected\n', length(mser_regions));
fprintf('LoG blobs: %d detected (%d after NMS)\n', size(log_blobs, 1), size(log_blobs_filtered, 1));
fprintf('DoG blobs: %d detected (%d after NMS)\n', size(dog_blobs, 1), size(dog_blobs_filtered, 1));
fprintf('Hessian blobs: %d detected (%d after NMS)\n', size(hessian_blobs, 1), size(hessian_blobs_filtered, 1));

if ~isempty(log_blobs_filtered)
    fprintf('LoG blob scales range: %.2f to %.2f\n', min(log_blobs_filtered(:,3)), max(log_blobs_filtered(:,3)));
end

% Local functions (moved to end so this listing is a valid MATLAB script)
function [blobs, scale_space, log_responses] = detectLoGBlobs(image, min_sigma, max_sigma, num_scales, threshold)
    % Generate scale space
    sigmas = logspace(log10(min_sigma), log10(max_sigma), num_scales);
    [rows, cols] = size(image);
    scale_space = zeros(rows, cols, num_scales);
    log_responses = zeros(rows, cols, num_scales);
    
    % Apply LoG at each scale
    for i = 1:num_scales
        sigma = sigmas(i);
        
        % Create LoG kernel
        kernel_size = 2 * ceil(3 * sigma) + 1;
        [x, y] = meshgrid(-(kernel_size-1)/2:(kernel_size-1)/2, ...
                          -(kernel_size-1)/2:(kernel_size-1)/2);
        
        % Normalised LoG
        log_kernel = -1/(pi * sigma^4) * (1 - (x.^2 + y.^2)/(2 * sigma^2)) .* ...
                     exp(-(x.^2 + y.^2) / (2 * sigma^2));
        log_kernel = log_kernel - mean(log_kernel(:));
        
        % Apply filter and normalise by scale
        log_response = imfilter(image, log_kernel, 'symmetric');
        log_responses(:,:,i) = sigma^2 * log_response;  % Scale normalisation
        
        % Store smoothed image for visualisation
        scale_space(:,:,i) = imgaussfilt(image, sigma);
    end
    
    % Find local maxima in scale-space
    blobs = [];
    for i = 2:num_scales-1  % Avoid boundary scales
        for x = 3:cols-2
            for y = 3:rows-2
                current_response = log_responses(y, x, i);
                
                % Check if it's a local maximum in space and scale
                if current_response > threshold
                    % Spatial neighbourhood (3*x3)
                    spatial_neighbourhood = log_responses(y-1:y+1, x-1:x+1, i);
                    
                    % Scale neighbourhood
                    scale_neighbourhood = [log_responses(y, x, i-1), ...
                                         current_response, ...
                                         log_responses(y, x, i+1)];
                    
                    % Check if current point is maximum
                    if current_response >= max(spatial_neighbourhood(:)) && ...
                       current_response >= max(scale_neighbourhood)
                        
                        % Add blob: [x, y, sigma, response]
                        blobs = [blobs; x, y, sigmas(i), current_response];
                    end
                end
            end
        end
    end
    
    % Sort by response strength
    if ~isempty(blobs)
        [~, sort_idx] = sort(blobs(:,4), 'descend');
        blobs = blobs(sort_idx, :);
    end
end

function [dog_blobs, dog_responses] = detectDoGBlobs(image, min_sigma, max_sigma, num_scales, threshold)
    % Generate Gaussian scale space
    sigmas = logspace(log10(min_sigma), log10(max_sigma), num_scales);
    [rows, cols] = size(image);
    gaussian_space = zeros(rows, cols, num_scales);
    dog_responses = zeros(rows, cols, num_scales-1);
    
    % Build Gaussian pyramid
    for i = 1:num_scales
        gaussian_space(:,:,i) = imgaussfilt(image, sigmas(i));
    end
    
    % Compute Difference of Gaussians
    for i = 1:num_scales-1
        dog_responses(:,:,i) = gaussian_space(:,:,i+1) - gaussian_space(:,:,i);
    end
    
    % Find local extrema in DoG space
    dog_blobs = [];
    for i = 2:num_scales-2  % Avoid boundary scales
        for x = 3:cols-2
            for y = 3:rows-2
                current_response = dog_responses(y, x, i);
                
                if abs(current_response) > threshold
                    % Check 3*D neighbourhood (3*x3x3)
                    neighbourhood = dog_responses(y-1:y+1, x-1:x+1, i-1:i+1);
                    
                    % Check if extremum (maximum or minimum)
                    if current_response >= max(neighbourhood(:)) || ...
                       current_response <= min(neighbourhood(:))
                        
                        % Add blob: [x, y, sigma, response]
                        sigma = sigmas(i) * sqrt(2);  % Effective scale
                        dog_blobs = [dog_blobs; x, y, sigma, abs(current_response)];
                    end
                end
            end
        end
    end
    
    % Sort by response strength
    if ~isempty(dog_blobs)
        [~, sort_idx] = sort(dog_blobs(:,4), 'descend');
        dog_blobs = dog_blobs(sort_idx, :);
    end
end

function [hessian_blobs, hessian_responses] = detectHessianBlobs(image, min_sigma, max_sigma, num_scales, threshold)
    sigmas = logspace(log10(min_sigma), log10(max_sigma), num_scales);
    [rows, cols] = size(image);
    hessian_responses = zeros(rows, cols, num_scales);
    
    for i = 1:num_scales
        sigma = sigmas(i);
        
        % Compute second derivatives
        [Ix, Iy] = gradient(double(image));
        [Ixx, Ixy] = gradient(Ix);
        [~, Iyy] = gradient(Iy);
        
        % Apply Gaussian smoothing
        gaussian_kernel = fspecial('gaussian', 2*ceil(3*sigma)+1, sigma);
        Ixx_smooth = imfilter(Ixx, gaussian_kernel, 'symmetric');
        Iyy_smooth = imfilter(Iyy, gaussian_kernel, 'symmetric');
        Ixy_smooth = imfilter(Ixy, gaussian_kernel, 'symmetric');
        
        % Compute determinant of Hessian (normalised by scale)
        det_hessian = Ixx_smooth .* Iyy_smooth - Ixy_smooth.^2;
        hessian_responses(:,:,i) = sigma^4 * det_hessian;
    end
    
    % Find local maxima
    hessian_blobs = [];
    for i = 2:num_scales-1
        for x = 3:cols-2
            for y = 3:rows-2
                current_response = hessian_responses(y, x, i);
                
                if current_response > threshold
                    % Check 3*D neighbourhood
                    neighbourhood = hessian_responses(y-1:y+1, x-1:x+1, i-1:i+1);
                    
                    if current_response >= max(neighbourhood(:))
                        hessian_blobs = [hessian_blobs; x, y, sigmas(i), current_response];
                    end
                end
            end
        end
    end
    
    % Sort by response strength
    if ~isempty(hessian_blobs)
        [~, sort_idx] = sort(hessian_blobs(:,4), 'descend');
        hessian_blobs = hessian_blobs(sort_idx, :);
    end
end

function filtered_blobs = suppressOverlappingBlobs(blobs, overlap_threshold)
    if isempty(blobs)
        filtered_blobs = [];
        return;
    end
    
    filtered_blobs = [];
    for i = 1:size(blobs, 1)
        current_blob = blobs(i, :);
        
        % Check overlap with already selected blobs
        if isempty(filtered_blobs)
            filtered_blobs = current_blob;
        else
            % Calculate distances and relative scales
            distances = sqrt((filtered_blobs(:,1) - current_blob(1)).^2 + ...
                           (filtered_blobs(:,2) - current_blob(2)).^2);
            scale_ratios = min(filtered_blobs(:,3), current_blob(3)) ./ ...
                          max(filtered_blobs(:,3), current_blob(3));
            
            % Check for significant overlap
            overlap_criterion = distances < overlap_threshold * max(filtered_blobs(:,3), current_blob(3));
            
            if ~any(overlap_criterion & scale_ratios > 0.5)
                filtered_blobs = [filtered_blobs; current_blob];
            end
        end
    end
end
