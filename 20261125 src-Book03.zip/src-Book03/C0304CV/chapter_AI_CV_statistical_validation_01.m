%% chapter_AI_CV_statistical_validation_01.m
% Advanced Cross-Validation and Statistical Testing Framework
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_statistical_validation_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Advanced Cross-Validation and Statistical Testing Framework
fprintf('Cross-Validation and Statistical Testing Framework\n');
fprintf('=================================================\n');

% Create dataset for cross-validation demonstration
[dataset, labels, metadata] = createCrossValidationDataset();


% 1. Standard Cross-Validation Methods




% 2. Grouped and Time-Series Cross-Validation

% 3. Bootstrap Sampling and Confidence Intervals


% 4. Statistical Significance Testing




% 5. Multiple Comparisons Correction

% Test the statistical validation framework
fprintf('\nTesting cross-validation and statistical testing framework...\n');

% Perform different types of cross-validation
standardCV = performCrossValidation(dataset, labels, 'stratified', 5);
groupedCV = performGroupedCrossValidation(dataset, labels, metadata.groups, 'group_kfold');
bootstrapResults = performBootstrapValidation(dataset, labels, 100);

% Create second algorithm results for comparison
dataset2 = dataset + randn(size(dataset)) * 0.1; % Slightly different algorithm
secondCV = performCrossValidation(dataset2, labels, 'stratified', 5);

% Statistical significance testing
testResults = performStatisticalTests(standardCV.allAccuracies, secondCV.allAccuracies, 'paired_ttest');

% Multiple comparisons example
pValues = [0.01, 0.03, 0.04, 0.08, 0.12];
correctedResults = correctMultipleComparisons(pValues, 'bonferroni');

% Visualise validation results
figure;

% Cross-validation results comparison
subplot(2, 4, 1);
cvMethods = {'Standard', 'Grouped', 'Bootstrap'};
cvMeans = [standardCV.meanAccuracy, groupedCV.meanAccuracy, bootstrapResults.meanAccuracy];
cvStds = [standardCV.stdAccuracy, groupedCV.stdAccuracy, bootstrapResults.stdAccuracy];

bar(cvMeans);
hold on;
errorbar(1:3, cvMeans, cvStds, 'k.', 'LineWidth', 2);
hold off;
set(gca, 'XTickLabel', cvMethods);
title('CV Method Comparison');
ylabel('Accuracy');

% Fold-wise accuracy distribution
subplot(2, 4, 2);
boxplot([standardCV.allAccuracies, groupedCV.allAccuracies], ...
        'Labels', {'Standard', 'Grouped'});
title('Accuracy Distribution');
ylabel('Accuracy');

% Bootstrap distribution
subplot(2, 4, 3);
histogram(bootstrapResults.accuracies, 20, 'Normalization', 'pdf');
xlabel('Accuracy');
ylabel('Density');
title('Bootstrap Distribution');

% Confidence intervals
subplot(2, 4, 4);
ciData = [standardCV.accuracyCI; groupedCV.accuracyCI; bootstrapResults.ci95];
errorbar(1:3, cvMeans, cvMeans - ciData(:, 1), ciData(:, 2) - cvMeans, 'o-');
set(gca, 'XTickLabel', cvMethods);
title('95% Confidence Intervals');
ylabel('Accuracy');

% Algorithm comparison
subplot(2, 4, 5);
comparisonData = [standardCV.allAccuracies, secondCV.allAccuracies];
boxplot(comparisonData, 'Labels', {'Algorithm 1', 'Algorithm 2'});
title('Algorithm Comparison');
ylabel('Accuracy');

% P-value distribution for multiple comparisons
subplot(2, 4, 6);
bar([correctedResults.originalPValues; correctedResults.correctedPValues]');
legend({'Original', 'Corrected'});
title('Multiple Comparisons Correction');
ylabel('P-value');

% Statistical test results
subplot(2, 4, 7);
testStats = [testResults.pValue, testResults.effectSize];
bar(testStats);
set(gca, 'XTickLabel', {'P-value', 'Effect Size'});
title('Statistical Test Results');

% Permutation test distribution (if available)
subplot(2, 4, 8);
if strcmp(testResults.testType, 'permutation')
    histogram(testResults.permutationDistribution, 50, 'Normalization', 'pdf');
    xline(testResults.observedDifference, 'r-', 'LineWidth', 2);
    title('Permutation Distribution');
    xlabel('Difference');
    ylabel('Density');
else
    text(0.5, 0.5, 'Permutation test not performed', 'HorizontalAlignment', 'center');
    title('Permutation Test');
end

sgtitle('Cross-Validation and Statistical Testing Results');

% Display comprehensive validation report
fprintf('\n' + string(repmat('=', 1, 60)) + '\n');
fprintf('STATISTICAL VALIDATION REPORT\n');
fprintf(string(repmat('=', 1, 60)) + '\n');

fprintf('\nCROSS-VALIDATION RESULTS:\n');
fprintf('  Standard 5-Fold CV: %.3f ㊣ %.3f\n', standardCV.meanAccuracy, standardCV.stdAccuracy);
fprintf('  Grouped CV: %.3f ㊣ %.3f\n', groupedCV.meanAccuracy, groupedCV.stdAccuracy);
fprintf('  Bootstrap (n=%d): %.3f ㊣ %.3f\n', bootstrapResults.numBootstrap, ...
    bootstrapResults.meanAccuracy, bootstrapResults.stdAccuracy);

fprintf('\nCONFIDENCE INTERVALS (95%%):\n');
fprintf('  Standard CV: [%.3f, %.3f]\n', standardCV.accuracyCI(1), standardCV.accuracyCI(2));
fprintf('  Grouped CV: [%.3f, %.3f]\n', groupedCV.accuracyCI(1), groupedCV.accuracyCI(2));
fprintf('  Bootstrap: [%.3f, %.3f]\n', bootstrapResults.ci95(1), bootstrapResults.ci95(2));

fprintf('\nSTATISTICAL SIGNIFICANCE TEST:\n');
fprintf('  Test Type: %s\n', testResults.testType);
fprintf('  P-value: %.4f\n', testResults.pValue);
fprintf('  Effect Size (Cohen''s d): %.3f\n', testResults.effectSize);
fprintf('  Significant at 汐=0.05: %s\n', string(testResults.hypothesis));

fprintf('\nMULTIPLE COMPARISONS CORRECTION:\n');
fprintf('  Method: %s\n', correctedResults.method);
fprintf('  Original significant tests: %d/%d\n', sum(correctedResults.originalPValues < 0.05), length(pValues));
fprintf('  Corrected significant tests: %d/%d\n', correctedResults.numSignificant, length(pValues));

fprintf('\nVALIDATION RECOMMENDATIONS:\n');
fprintf('============================\n');

if standardCV.stdAccuracy > 0.05
    fprintf(' High variance in CV results - consider more folds or larger dataset\n');
end

if abs(standardCV.meanAccuracy - groupedCV.meanAccuracy) > 0.02
    fprintf(' Significant difference between standard and grouped CV\n');
    fprintf('  This suggests potential data leakage or temporal dependencies\n');
end

if testResults.pValue < 0.05 && abs(testResults.effectSize) < 0.2
    fprintf(' Statistically significant but small effect size\n');
    fprintf('  Consider practical significance of the difference\n');
end

fprintf('\nBEST PRACTICES:\n');
fprintf('==============\n');
fprintf(' Use stratified CV for imbalanced datasets\n');
fprintf(' Apply grouped CV when samples are not independent\n');
fprintf(' Bootstrap for robust confidence interval estimation\n');
fprintf(' Correct for multiple comparisons in extensive evaluations\n');
fprintf(' Report both statistical and practical significance\n');
fprintf(' Consider effect sizes alongside p-values\n');

fprintf('\n' + string(repmat('=', 1, 60)) + '\n');

% Local functions (moved to end so this listing is a valid MATLAB script)
function [data, labels, meta] = createCrossValidationDataset()
    % Create synthetic dataset with realistic characteristics
    
    fprintf('Creating cross-validation dataset...\n');
    
    numSamples = 2000;
    numFeatures = 50;
    numClasses = 4;
    
    % Generate feature data with class-specific characteristics
    data = zeros(numSamples, numFeatures);
    labels = zeros(numSamples, 1);
    
    samplesPerClass = numSamples / numClasses;
    
    for class = 1:numClasses
        startIdx = (class - 1) * samplesPerClass + 1;
        endIdx = class * samplesPerClass;
        
        % Class-specific feature distributions
        classMean = randn(1, numFeatures) * 2;
        classStd = 0.5 + rand(1, numFeatures) * 1.5;
        
        for i = startIdx:endIdx
            data(i, :) = classMean + classStd .* randn(1, numFeatures);
            labels(i) = class;
        end
    end
    
    % Add some correlation structure
    correlationMatrix = toeplitz(0.9.^(0:(numFeatures-1)));
    data = data * chol(correlationMatrix);
    
    % Create metadata for grouped cross-validation
    meta = struct();
    meta.groups = ceil((1:numSamples) / 20)'; % Groups of 20 samples
    meta.timeStamps = datetime('2023-01-01') + hours(cumsum(rand(numSamples, 1) * 24));
    meta.subjects = randi(50, numSamples, 1); % 50 different subjects
    
    fprintf('Created dataset: %d samples, %d features, %d classes\n', ...
        numSamples, numFeatures, numClasses);
end

function cvResults = performCrossValidation(data, labels, cvMethod, numFolds)
    % Perform various cross-validation methods
    
    if nargin < 3
        cvMethod = 'kfold';
    end
    if nargin < 4
        numFolds = 5;
    end
    
    fprintf('Performing %s cross-validation with %d folds...\n', cvMethod, numFolds);
    
    cvResults = struct();
    cvResults.method = cvMethod;
    cvResults.numFolds = numFolds;
    
    numSamples = size(data, 1);
    
    switch cvMethod
        case 'kfold'
            indices = crossvalind('Kfold', numSamples, numFolds);
            
        case 'stratified'
            indices = crossvalind('Kfold', labels, numFolds);
            
        case 'holdout'
            indices = crossvalind('HoldOut', numSamples, 0.2); % 20% test set
            numFolds = 2; % Training and test
            
        case 'loo'
            indices = (1:numSamples)'; % Leave-one-out
            numFolds = numSamples;
            
        otherwise
            error('Unknown cross-validation method: %s', cvMethod);
    end
    
    % Store fold assignments
    cvResults.foldIndices = indices;
    
    % Perform cross-validation
    foldResults = cell(numFolds, 1);
    
    for fold = 1:numFolds
        if strcmp(cvMethod, 'loo')
            testIdx = fold;
            trainIdx = setdiff(1:numSamples, testIdx);
        elseif strcmp(cvMethod, 'holdout')
            if fold == 1
                trainIdx = find(indices == 0);
                testIdx = find(indices == 1);
            else
                continue; % Only one split for holdout
            end
        else
            testIdx = find(indices == fold);
            trainIdx = find(indices ~= fold);
        end
        
        % Train and test simple classifier
        foldResult = trainAndTestClassifier(data(trainIdx, :), labels(trainIdx), ...
                                          data(testIdx, :), labels(testIdx));
        foldResult.trainIdx = trainIdx;
        foldResult.testIdx = testIdx;
        
        foldResults{fold} = foldResult;
    end
    
    % Remove empty cells (for holdout)
    foldResults = foldResults(~cellfun(@isempty, foldResults));
    cvResults.foldResults = foldResults;
    
    % Aggregate results
    cvResults = aggregateCVResults(cvResults);
    
    fprintf('Cross-validation completed\n');
end

function result = trainAndTestClassifier(trainData, trainLabels, testData, testLabels)
    % Train and test simple classifier for CV demonstration
    
    result = struct();
    
    try
        % Simple linear discriminant classifier
        classifier = fitcdiscr(trainData, trainLabels);
        
        % Make predictions
        predictions = predict(classifier, testData);
        [~, scores] = predict(classifier, testData);
        
        % Compute metrics
        result.accuracy = mean(predictions == testLabels);
        result.predictions = predictions;
        result.trueLabels = testLabels;
        result.scores = scores;
        
        % Confusion matrix
        result.confusionMatrix = confusionmat(testLabels, predictions);
        
        % Per-class metrics
        numClasses = length(unique(trainLabels));
        result.precision = zeros(numClasses, 1);
        result.recall = zeros(numClasses, 1);
        
        for class = 1:numClasses
            tp = sum(predictions == class & testLabels == class);
            fp = sum(predictions == class & testLabels ~= class);
            fn = sum(predictions ~= class & testLabels == class);
            
            result.precision(class) = tp / (tp + fp + eps);
            result.recall(class) = tp / (tp + fn + eps);
        end
        
        result.success = true;
        
    catch ME
        fprintf('Classifier training failed: %s\n', ME.message);
        result.accuracy = 0;
        result.success = false;
    end
end

function cvResults = aggregateCVResults(cvResults)
    % Aggregate cross-validation results across folds
    
    foldResults = cvResults.foldResults;
    numFolds = length(foldResults);
    
    % Extract metrics from each fold
    accuracies = zeros(numFolds, 1);
    precisions = [];
    recalls = [];
    
    for fold = 1:numFolds
        if foldResults{fold}.success
            accuracies(fold) = foldResults{fold}.accuracy;
            
            if fold == 1
                numClasses = length(foldResults{fold}.precision);
                precisions = zeros(numFolds, numClasses);
                recalls = zeros(numFolds, numClasses);
            end
            
            precisions(fold, :) = foldResults{fold}.precision';
            recalls(fold, :) = foldResults{fold}.recall';
        end
    end
    
    % Compute summary statistics
    cvResults.meanAccuracy = mean(accuracies);
    cvResults.stdAccuracy = std(accuracies);
    cvResults.accuracyCI = computeConfidenceInterval(accuracies, 0.95);
    
    if ~isempty(precisions)
        cvResults.meanPrecision = mean(precisions, 1);
        cvResults.stdPrecision = std(precisions, 0, 1);
        cvResults.meanRecall = mean(recalls, 1);
        cvResults.stdRecall = std(recalls, 0, 1);
    end
    
    cvResults.allAccuracies = accuracies;
end

function ci = computeConfidenceInterval(data, confidenceLevel)
    % Compute confidence interval using t-distribution
    
    alpha = 1 - confidenceLevel;
    n = length(data);
    
    meanData = mean(data);
    stdData = std(data);
    
    % t-critical value
    tCrit = tinv(1 - alpha/2, n - 1);
    
    margin = tCrit * stdData / sqrt(n);
    
    ci = [meanData - margin, meanData + margin];
end

function groupedCVResults = performGroupedCrossValidation(data, labels, groups, cvType)
    % Perform grouped cross-validation to prevent data leakage
    
    if nargin < 4
        cvType = 'group_kfold';
    end
    
    fprintf('Performing grouped cross-validation (%s)...\n', cvType);
    
    uniqueGroups = unique(groups);
    numGroups = length(uniqueGroups);
    
    groupedCVResults = struct();
    groupedCVResults.cvType = cvType;
    groupedCVResults.numGroups = numGroups;
    
    switch cvType
        case 'group_kfold'
            numFolds = min(5, numGroups);
            groupFolds = crossvalind('Kfold', numGroups, numFolds);
            
        case 'leave_one_group_out'
            numFolds = numGroups;
            groupFolds = 1:numGroups;
            
        case 'group_holdout'
            numFolds = 2;
            testGroupRatio = 0.2;
            numTestGroups = max(1, round(numGroups * testGroupRatio));
            testGroups = randperm(numGroups, numTestGroups);
            groupFolds = ones(numGroups, 1);
            groupFolds(testGroups) = 2;
            
        otherwise
            error('Unknown grouped CV type: %s', cvType);
    end
    
    foldResults = cell(numFolds, 1);
    
    for fold = 1:numFolds
        if strcmp(cvType, 'leave_one_group_out')
            testGroups = uniqueGroups(fold);
            trainGroups = uniqueGroups(setdiff(1:numGroups, fold));
        elseif strcmp(cvType, 'group_holdout')
            if fold == 1
                trainGroups = uniqueGroups(groupFolds == 1);
                testGroups = uniqueGroups(groupFolds == 2);
            else
                continue;
            end
        else
            testGroups = uniqueGroups(groupFolds == fold);
            trainGroups = uniqueGroups(groupFolds ~= fold);
        end
        
        % Get sample indices for train/test groups
        trainIdx = ismember(groups, trainGroups);
        testIdx = ismember(groups, testGroups);
        
        % Train and test
        foldResult = trainAndTestClassifier(data(trainIdx, :), labels(trainIdx), ...
                                          data(testIdx, :), labels(testIdx));
        foldResult.trainGroups = trainGroups;
        foldResult.testGroups = testGroups;
        foldResult.trainIdx = find(trainIdx);
        foldResult.testIdx = find(testIdx);
        
        foldResults{fold} = foldResult;
    end
    
    % Remove empty cells
    foldResults = foldResults(~cellfun(@isempty, foldResults));
    groupedCVResults.foldResults = foldResults;
    
    % Aggregate results
    groupedCVResults = aggregateCVResults(groupedCVResults);
    
    fprintf('Grouped cross-validation completed\n');
end

function bootstrapResults = performBootstrapValidation(data, labels, numBootstrap)
    % Perform bootstrap validation for robust performance estimation
    
    if nargin < 3
        numBootstrap = 1000;
    end
    
    fprintf('Performing bootstrap validation with %d samples...\n', numBootstrap);
    
    numSamples = size(data, 1);
    bootstrapAccuracies = zeros(numBootstrap, 1);
    
    for bootstrap = 1:numBootstrap
        % Bootstrap sampling with replacement
        bootstrapIdx = randi(numSamples, numSamples, 1);
        
        % Out-of-bag samples for testing
        oobIdx = setdiff(1:numSamples, unique(bootstrapIdx));
        
        if ~isempty(oobIdx)
            % Train on bootstrap sample, test on out-of-bag
            result = trainAndTestClassifier(data(bootstrapIdx, :), labels(bootstrapIdx), ...
                                          data(oobIdx, :), labels(oobIdx));
            
            if result.success
                bootstrapAccuracies(bootstrap) = result.accuracy;
            end
        end
    end
    
    % Remove failed bootstraps
    validBootstraps = bootstrapAccuracies > 0;
    bootstrapAccuracies = bootstrapAccuracies(validBootstraps);
    
    bootstrapResults = struct();
    bootstrapResults.numBootstrap = sum(validBootstraps);
    bootstrapResults.accuracies = bootstrapAccuracies;
    bootstrapResults.meanAccuracy = mean(bootstrapAccuracies);
    bootstrapResults.stdAccuracy = std(bootstrapAccuracies);
    
    % Confidence intervals using percentile method
    bootstrapResults.ci95 = [prctile(bootstrapAccuracies, 2.5), prctile(bootstrapAccuracies, 97.5)];
    bootstrapResults.ci90 = [prctile(bootstrapAccuracies, 5), prctile(bootstrapAccuracies, 95)];
    
    % Bias-corrected and accelerated (BCa) confidence interval
    bootstrapResults.bcaCI95 = computeBCaConfidenceInterval(bootstrapAccuracies, 0.95);
    
    fprintf('Bootstrap validation completed\n');
end

function bcaCI = computeBCaConfidenceInterval(bootstrapStats, confidenceLevel)
    % Compute bias-corrected and accelerated confidence interval
    
    alpha = 1 - confidenceLevel;
    
    % Original statistic (approximated as mean of bootstrap statistics)
    originalStat = mean(bootstrapStats);
    
    % Bias correction
    numBootstrap = length(bootstrapStats);
    biasCorrection = norminv(sum(bootstrapStats < originalStat) / numBootstrap);
    
    % Acceleration (simplified calculation)
    acceleration = 0; % Would require jackknife estimation for exact calculation
    
    % Adjusted quantiles
    z_alpha2 = norminv(alpha / 2);
    z_1alpha2 = norminv(1 - alpha / 2);
    
    alpha1 = normcdf(biasCorrection + (biasCorrection + z_alpha2) / (1 - acceleration * (biasCorrection + z_alpha2)));
    alpha2 = normcdf(biasCorrection + (biasCorrection + z_1alpha2) / (1 - acceleration * (biasCorrection + z_1alpha2)));
    
    % Ensure valid percentiles
    alpha1 = max(0, min(1, alpha1));
    alpha2 = max(0, min(1, alpha2));
    
    bcaCI = [prctile(bootstrapStats, alpha1 * 100), prctile(bootstrapStats, alpha2 * 100)];
end

function testResults = performStatisticalTests(results1, results2, testType)
    % Perform statistical tests to compare algorithm performance
    
    if nargin < 3
        testType = 'paired_ttest';
    end
    
    fprintf('Performing statistical significance test (%s)...\n', testType);
    
    testResults = struct();
    testResults.testType = testType;
    
    switch testType
        case 'paired_ttest'
            [h, p, ci, stats] = ttest(results1, results2);
            testResults.hypothesis = h;
            testResults.pValue = p;
            testResults.confidenceInterval = ci;
            testResults.tStatistic = stats.tstat;
            testResults.degreesOfFreedom = stats.df;
            
        case 'wilcoxon'
            [p, h, stats] = signrank(results1, results2);
            testResults.hypothesis = h;
            testResults.pValue = p;
            testResults.signedRank = stats.signedrank;
            
        case 'mcnemar'
            % McNemar's test for comparing classifier performance
            testResults = performMcNemarTest(results1, results2);
            
        case 'permutation'
            testResults = performPermutationTest(results1, results2);
            
        otherwise
            error('Unknown test type: %s', testType);
    end
    
    % Effect size calculation
    testResults.effectSize = computeEffectSize(results1, results2);
    
    fprintf('Statistical test completed: p = %.4f\n', testResults.pValue);
end

function mcnemarResults = performMcNemarTest(predictions1, predictions2)
    % Perform McNemar's test for classifier comparison
    
    mcnemarResults = struct();
    mcnemarResults.testType = 'mcnemar';
    
    % Contingency table
    correct1 = predictions1;
    correct2 = predictions2;
    
    % McNemar table: [both_correct, only_1_correct; only_2_correct, both_wrong]
    bothCorrect = sum(correct1 & correct2);
    only1Correct = sum(correct1 & ~correct2);
    only2Correct = sum(~correct1 & correct2);
    bothWrong = sum(~correct1 & ~correct2);
    
    mcnemarTable = [bothCorrect, only1Correct; only2Correct, bothWrong];
    mcnemarResults.contingencyTable = mcnemarTable;
    
    % McNemar statistic
    b = only1Correct;
    c = only2Correct;
    
    if b + c > 20
        % Chi-square approximation
        mcnemarStat = (b - c)^2 / (b + c);
        pValue = 1 - chi2cdf(mcnemarStat, 1);
    else
        % Exact binomial test
        pValue = 2 * binocdf(min(b, c), b + c, 0.5);
    end
    
    mcnemarResults.mcnemarStatistic = mcnemarStat;
    mcnemarResults.pValue = pValue;
    mcnemarResults.hypothesis = pValue < 0.05;
end

function permResults = performPermutationTest(group1, group2, numPermutations)
    % Perform permutation test for comparing two groups
    
    if nargin < 3
        numPermutations = 10000;
    end
    
    permResults = struct();
    permResults.numPermutations = numPermutations;
    
    % Observed difference
    observedDiff = mean(group1) - mean(group2);
    permResults.observedDifference = observedDiff;
    
    % Combined data
    combinedData = [group1; group2];
    n1 = length(group1);
    n2 = length(group2);
    totalN = n1 + n2;
    
    % Permutation distribution
    permDifferences = zeros(numPermutations, 1);
    
    for perm = 1:numPermutations
        % Random permutation
        permIndices = randperm(totalN);
        
        % Split into two groups
        permGroup1 = combinedData(permIndices(1:n1));
        permGroup2 = combinedData(permIndices((n1+1):end));
        
        % Compute difference
        permDifferences(perm) = mean(permGroup1) - mean(permGroup2);
    end
    
    % P-value (two-tailed)
    permResults.pValue = mean(abs(permDifferences) >= abs(observedDiff));
    permResults.hypothesis = permResults.pValue < 0.05;
    permResults.permutationDistribution = permDifferences;
end

function effectSize = computeEffectSize(group1, group2)
    % Compute Cohen's d effect size
    
    mean1 = mean(group1);
    mean2 = mean(group2);
    
    std1 = std(group1);
    std2 = std(group2);
    
    n1 = length(group1);
    n2 = length(group2);
    
    % Pooled standard deviation
    pooledStd = sqrt(((n1 - 1) * std1^2 + (n2 - 1) * std2^2) / (n1 + n2 - 2));
    
    effectSize = (mean1 - mean2) / pooledStd;
end

function correctedResults = correctMultipleComparisons(pValues, method)
    % Apply multiple comparisons correction
    
    if nargin < 2
        method = 'bonferroni';
    end
    
    fprintf('Applying %s correction for multiple comparisons...\n', method);
    
    correctedResults = struct();
    correctedResults.method = method;
    correctedResults.originalPValues = pValues;
    
    numTests = length(pValues);
    
    switch method
        case 'bonferroni'
            correctedPValues = pValues * numTests;
            correctedPValues = min(correctedPValues, 1); % Cap at 1
            
        case 'holm'
            [sortedP, sortIdx] = sort(pValues);
            correctedP = zeros(size(pValues));
            
            for i = 1:numTests
                adjustment = numTests - i + 1;
                correctedP(sortIdx(i)) = min(1, sortedP(i) * adjustment);
            end
            
            correctedPValues = correctedP;
            
        case 'bh' % Benjamini-Hochberg
            [sortedP, sortIdx] = sort(pValues);
            correctedP = zeros(size(pValues));
            
            for i = numTests:-1:1
                if i == numTests
                    correctedP(sortIdx(i)) = sortedP(i);
                else
                    correctedP(sortIdx(i)) = min(correctedP(sortIdx(i+1)), ...
                                               sortedP(i) * numTests / i);
                end
            end
            
            correctedPValues = correctedP;
            
        otherwise
            error('Unknown correction method: %s', method);
    end
    
    correctedResults.correctedPValues = correctedPValues;
    correctedResults.significantTests = correctedPValues < 0.05;
    correctedResults.numSignificant = sum(correctedResults.significantTests);
    
    fprintf('Multiple comparisons correction completed\n');
end
