%% chapter_AI_CV_gan_implementation_01.m
% GAN Implementation with Comprehensive Training Analysis
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_gan_implementation_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Comprehensive GAN Implementation and Training Analysis
fprintf('Generative Adversarial Network Implementation\n');
fprintf('=============================================\n');

% Define network parameters
imageSize = [64, 64, 3];  % RGB images
latentDimension = 100;
batchSize = 32;
numEpochs = 50;
learningRate = 0.0002;

% Generator architecture

% Helper function for reshaping latent vector

% Discriminator architecture

% Create networks
generator_layers = createGenerator(latentDimension, imageSize);
discriminator_layers = createDiscriminator(imageSize);

% Convert to layer graphs
generator_lgraph = layerGraph(generator_layers);
discriminator_lgraph = layerGraph(discriminator_layers);

fprintf('Generator layers: %d\n', length(generator_layers));
fprintf('Discriminator layers: %d\n', length(discriminator_layers));

% Create synthetic training data (in practice, use real dataset)
numTrainingImages = 1000;
trainingData = createSyntheticTrainingData(imageSize, numTrainingImages);


% Helper functions for creating different image types




% Custom training loop for GAN

% Discriminator training function

% Generator training function

% Binary cross-entropy loss function

% Training progress monitoring

% Set training options
training_options = struct();
training_options.num_epochs = 20; % Reduced for demonstration
training_options.batch_size = batchSize;
training_options.learning_rate = learningRate;
training_options.latent_dimension = latentDimension;

% Train the GAN (note: this is a simplified version)
fprintf('Note: Full GAN training requires extensive computational resources.\n');
fprintf('This is a demonstration of the architecture and training structure.\n');

% For demonstration, we'll show the loss computation without full training
sample_real = randn(imageSize(1), imageSize(2), imageSize(3), 4, 'single');
sample_noise = randn(latentDimension, 4, 'single');

% Initialize networks for demonstration
generator_net = dlnetwork(generator_lgraph);
discriminator_net = dlnetwork(discriminator_lgraph);

try
    % Demonstrate forward pass
    sample_real_dl = dlarray(sample_real, 'SSCB');
    sample_noise_dl = dlarray(sample_noise, 'CB');
    
    generated_samples = forward(generator_net, sample_noise_dl);
    disc_output_real = forward(discriminator_net, sample_real_dl);
    disc_output_fake = forward(discriminator_net, generated_samples);
    
    fprintf('Generator output size: [%s]\n', num2str(size(generated_samples)));
    fprintf('Discriminator output size: [%s]\n', num2str(size(disc_output_real)));
    
    % Compute sample losses
    real_loss = binaryCrossEntropy(disc_output_real, ones(size(disc_output_real), 'like', disc_output_real));
    fake_loss = binaryCrossEntropy(disc_output_fake, zeros(size(disc_output_fake), 'like', disc_output_fake));
    gen_loss = binaryCrossEntropy(disc_output_fake, ones(size(disc_output_fake), 'like', disc_output_fake));
    
    fprintf('Sample discriminator real loss: %.4f\n', extractdata(real_loss));
    fprintf('Sample discriminator fake loss: %.4f\n', extractdata(fake_loss));
    fprintf('Sample generator loss: %.4f\n', extractdata(gen_loss));
    
catch ME
    fprintf('Error in forward pass: %s\n', ME.message);
    fprintf('This may be due to MATLAB version or toolbox limitations.\n');
end

% Analysis and visualization functions


analyzeGANArchitecture(generator_lgraph, discriminator_lgraph);

% GAN training stability analysis

% Create synthetic loss history for demonstration
demo_losses = struct();
demo_losses.generator = 2 * exp(-0.1 * (1:20)) + 0.5 + 0.1 * randn(1, 20);
demo_losses.discriminator = 1.5 * exp(-0.05 * (1:20)) + 0.3 + 0.1 * randn(1, 20);
demo_losses.discriminator_real = demo_losses.discriminator * 0.6;
demo_losses.discriminator_fake = demo_losses.discriminator * 0.4;

stability_metrics = analyzeTrainingStability(demo_losses);

% Visualize training progress
figure;

subplot(2, 2, 1);
plot(1:length(demo_losses.generator), demo_losses.generator, 'b-', 'LineWidth', 2, 'DisplayName', 'Generator');
hold on;
plot(1:length(demo_losses.discriminator), demo_losses.discriminator, 'r-', 'LineWidth', 2, 'DisplayName', 'Discriminator');
xlabel('Epoch');
ylabel('Loss');
title('GAN Training Losses');
legend('show');
grid on;

subplot(2, 2, 2);
plot(1:length(demo_losses.discriminator_real), demo_losses.discriminator_real, 'g-', 'LineWidth', 2, 'DisplayName', 'Real');
hold on;
plot(1:length(demo_losses.discriminator_fake), demo_losses.discriminator_fake, 'm-', 'LineWidth', 2, 'DisplayName', 'Fake');
xlabel('Epoch');
ylabel('Loss');
title('Discriminator Losses');
legend('show');
grid on;

subplot(2, 2, 3);
loss_ratio = demo_losses.generator ./ (demo_losses.discriminator + eps);
plot(1:length(loss_ratio), loss_ratio, 'k-', 'LineWidth', 2);
xlabel('Epoch');
ylabel('Generator/Discriminator Loss Ratio');
title('Training Balance');
grid on;

subplot(2, 2, 4);
if length(demo_losses.generator) > 5
    gen_smooth = movmean(demo_losses.generator, 5);
    disc_smooth = movmean(demo_losses.discriminator, 5);
    plot(1:length(gen_smooth), gen_smooth, 'b-', 'LineWidth', 2, 'DisplayName', 'Generator (smoothed)');
    hold on;
    plot(1:length(disc_smooth), disc_smooth, 'r-', 'LineWidth', 2, 'DisplayName', 'Discriminator (smoothed)');
    xlabel('Epoch');
    ylabel('Loss');
    title('Smoothed Loss Trends');
    legend('show');
    grid on;
end

% Mode collapse detection

mode_collapse_analysis();

% GAN variants comparison

compareGANVariants();

% Practical implementation guidelines
fprintf('\nGAN Implementation Best Practices:\n');
fprintf('==================================\n');
fprintf('1. Architecture Design:\n');
fprintf('   - Use DCGAN guidelines for stable architectures\n');
fprintf('   - Batch normalization in generator, not in discriminator output\n');
fprintf('   - LeakyReLU in discriminator, ReLU in generator\n');
fprintf('   - Use transposed convolutions instead of upsampling + conv\n');

fprintf('\n2. Training Strategies:\n');
fprintf('   - Balance generator and discriminator training\n');
fprintf('   - Use different learning rates (often lower for discriminator)\n');
fprintf('   - Monitor loss ratios and adjust training frequency\n');
fprintf('   - Implement gradient penalty or spectral normalization\n');

fprintf('\n3. Hyperparameter Tuning:\n');
fprintf('   - Start with Adam optimizer (汕=0.5, 汕=0.999)\n');
fprintf('   - Learning rates around 0.0002\n');
fprintf('   - Batch sizes of 32-128 work well\n');
fprintf('   - Experiment with noise dimension (50-1000)\n');

fprintf('\n4. Evaluation Metrics:\n');
fprintf('   - Inception Score for image quality and diversity\n');
fprintf('   - FID for comparing generated and real distributions\n');
fprintf('   - Visual inspection for mode collapse\n');
fprintf('   - Latent space interpolation for smoothness\n');

fprintf('\n5. Common Issues and Solutions:\n');
fprintf('   - Mode collapse: Use feature matching, minibatch discrimination\n');
fprintf('   - Training instability: Reduce learning rates, add noise\n');
fprintf('   - Poor quality: Check architecture, increase capacity\n');
fprintf('   - Slow convergence: Adjust loss functions, try WGAN\n');

% Local functions (moved to end so this listing is a valid MATLAB script)
function generator_layers = createGenerator(latentDim, outputSize)
    % Calculate upsampling stages needed
    initialSize = 4;
    numUpsampleStages = log2(outputSize(1) / initialSize);
    
    if numUpsampleStages ~= round(numUpsampleStages)
        error('Output size must be power of 2 times initial size');
    end
    
    % Initial dense layer to reshape latent vector
    numInitialFilters = 512;
    initialOutputSize = initialSize * initialSize * numInitialFilters;
    
    generator_layers = [
        featureInputLayer(latentDim, 'Name', 'latent_input')
        
        % Dense layer and reshape
        fullyConnectedLayer(initialOutputSize, 'Name', 'fc1')
        functionLayer(@(x) reshapeLatentVector(x, initialSize, numInitialFilters), ...
            'Name', 'reshape', 'NumInputs', 1, 'NumOutputs', 1)
        batchNormalizationLayer('Name', 'bn1')
        reluLayer('Name', 'relu1')
        
        % Upsampling blocks
        transposedConv2dLayer(4, 256, 'Stride', 2, 'Cropping', 'same', 'Name', 'tconv1')
        batchNormalizationLayer('Name', 'bn2')
        reluLayer('Name', 'relu2')
        
        transposedConv2dLayer(4, 128, 'Stride', 2, 'Cropping', 'same', 'Name', 'tconv2')
        batchNormalizationLayer('Name', 'bn3')
        reluLayer('Name', 'relu3')
        
        transposedConv2dLayer(4, 64, 'Stride', 2, 'Cropping', 'same', 'Name', 'tconv3')
        batchNormalizationLayer('Name', 'bn4')
        reluLayer('Name', 'relu4')
        
        transposedConv2dLayer(4, 32, 'Stride', 2, 'Cropping', 'same', 'Name', 'tconv4')
        batchNormalizationLayer('Name', 'bn5')
        reluLayer('Name', 'relu5')
        
        % Final output layer
        transposedConv2dLayer(4, outputSize(3), 'Stride', 1, 'Cropping', 'same', 'Name', 'tconv_final')
        tanhLayer('Name', 'tanh_output')
    ];
end

function output = reshapeLatentVector(input, spatialSize, numChannels)
    batchSize = size(input, 1);
    output = reshape(input, [spatialSize, spatialSize, numChannels, batchSize]);
end

function discriminator_layers = createDiscriminator(inputSize)
    discriminator_layers = [
        imageInputLayer(inputSize, 'Name', 'image_input', 'Normalization', 'none')
        
        % Convolutional downsampling
        convolution2dLayer(4, 32, 'Stride', 2, 'Padding', 'same', 'Name', 'conv1')
        leakyReluLayer(0.2, 'Name', 'lrelu1')
        
        convolution2dLayer(4, 64, 'Stride', 2, 'Padding', 'same', 'Name', 'conv2')
        batchNormalizationLayer('Name', 'bn1')
        leakyReluLayer(0.2, 'Name', 'lrelu2')
        
        convolution2dLayer(4, 128, 'Stride', 2, 'Padding', 'same', 'Name', 'conv3')
        batchNormalizationLayer('Name', 'bn2')
        leakyReluLayer(0.2, 'Name', 'lrelu3')
        
        convolution2dLayer(4, 256, 'Stride', 2, 'Padding', 'same', 'Name', 'conv4')
        batchNormalizationLayer('Name', 'bn3')
        leakyReluLayer(0.2, 'Name', 'lrelu4')
        
        % Classification
        globalAveragePooling2dLayer('Name', 'gap')
        fullyConnectedLayer(1, 'Name', 'fc_final')
        sigmoidLayer('Name', 'sigmoid_output')
    ];
end

function data = createSyntheticTrainingData(imageSize, numImages)
    % Create diverse synthetic patterns for training
    data = zeros([imageSize, numImages], 'single');
    
    for i = 1:numImages
        % Create different types of patterns
        pattern_type = mod(i-1, 4) + 1;
        
        switch pattern_type
            case 1
                % Geometric patterns
                img = createGeometricImage(imageSize);
            case 2
                % Gradient patterns
                img = createGradientImage(imageSize);
            case 3
                % Texture patterns
                img = createTextureImage(imageSize);
            case 4
                % Organic patterns
                img = createOrganicImage(imageSize);
        end
        
        data(:, :, :, i) = img;
    end
end

function img = createGeometricImage(imageSize)
    img = zeros(imageSize, 'single');
    
    % Add geometric shapes
    for shape = 1:randi([3, 8])
        shape_type = randi(3);
        color = rand(1, 3);
        
        switch shape_type
            case 1 % Rectangle
                x = randi([1, imageSize(2)-10]);
                y = randi([1, imageSize(1)-10]);
                w = randi([5, 20]);
                h = randi([5, 20]);
                img(y:min(y+h, imageSize(1)), x:min(x+w, imageSize(2)), :) = ...
                    reshape(color, [1, 1, 3]);
                
            case 2 % Circle
                cx = randi([10, imageSize(2)-10]);
                cy = randi([10, imageSize(1)-10]);
                radius = randi([3, 10]);
                [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
                mask = (X - cx).^2 + (Y - cy).^2 <= radius^2;
                for c = 1:3
                    channel = img(:, :, c);
                    channel(mask) = color(c);
                    img(:, :, c) = channel;
                end
                
            case 3 % Triangle (simplified)
                vertices = rand(3, 2) .* [imageSize(2), imageSize(1)];
                % Simplified triangle filling
                bbox = [min(vertices(:,1)), max(vertices(:,1)), ...
                        min(vertices(:,2)), max(vertices(:,2))];
                bbox = round(bbox);
                bbox = max(bbox, 1);
                bbox(2) = min(bbox(2), imageSize(2));
                bbox(4) = min(bbox(4), imageSize(1));
                
                for c = 1:3
                    img(bbox(3):bbox(4), bbox(1):bbox(2), c) = color(c);
                end
        end
    end
    
    % Normalise to [-1, 1] range for tanh output
    img = (img - 0.5) * 2;
end

function img = createGradientImage(imageSize)
    [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
    
    % Random gradient direction
    theta = rand() * 2 * pi;
    direction = [cos(theta), sin(theta)];
    
    % Create gradient
    gradient = (X * direction(1) + Y * direction(2)) / sqrt(imageSize(1)^2 + imageSize(2)^2);
    gradient = (gradient - min(gradient(:))) / (max(gradient(:)) - min(gradient(:)));
    
    % Apply to RGB channels with different weights
    img = zeros(imageSize, 'single');
    colors = rand(1, 3);
    for c = 1:3
        img(:, :, c) = gradient * colors(c);
    end
    
    % Normalise to [-1, 1]
    img = (img - 0.5) * 2;
end

function img = createTextureImage(imageSize)
    % Create noise-based texture
    img = randn(imageSize, 'single') * 0.1;
    
    % Add periodic components
    [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
    
    % Multiple frequency components
    for freq = 1:3
        period = imageSize(1) / (2^freq);
        amplitude = rand() * 0.3;
        phase = rand() * 2 * pi;
        
        pattern = amplitude * sin(2*pi*X/period + phase) .* cos(2*pi*Y/period + phase);
        
        channel = randi(3);
        img(:, :, channel) = img(:, :, channel) + pattern;
    end
    
    % Normalise to [-1, 1]
    img = tanh(img);
end

function img = createOrganicImage(imageSize)
    img = zeros(imageSize, 'single');
    [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
    
    % Multiple organic blobs
    for blob = 1:randi([3, 8])
        cx = rand() * imageSize(2);
        cy = rand() * imageSize(1);
        scale_x = rand() * 20 + 10;
        scale_y = rand() * 20 + 10;
        
        pattern = exp(-((X-cx).^2/(2*scale_x^2) + (Y-cy).^2/(2*scale_y^2)));
        
        color = rand(1, 3);
        for c = 1:3
            img(:, :, c) = img(:, :, c) + pattern * color(c);
        end
    end
    
    % Normalise to [-1, 1]
    img = tanh(img);
end

function [trained_generator, trained_discriminator, losses] = trainGAN(generator_lgraph, discriminator_lgraph, trainingData, options)
    % Initialize networks
    generator = dlnetwork(generator_lgraph);
    discriminator = dlnetwork(discriminator_lgraph);
    
    % Training options
    num_epochs = options.num_epochs;
    batch_size = options.batch_size;
    learning_rate = options.learning_rate;
    latent_dim = options.latent_dimension;
    
    % Optimizers
    generator_optimizer = [];
    discriminator_optimizer = [];
    
    % Training statistics
    losses.generator = [];
    losses.discriminator = [];
    losses.discriminator_real = [];
    losses.discriminator_fake = [];
    
    num_batches = floor(size(trainingData, 4) / batch_size);
    
    fprintf('Starting GAN training...\n');
    fprintf('Epochs: %d, Batch size: %d, Batches per epoch: %d\n', ...
        num_epochs, batch_size, num_batches);
    
    for epoch = 1:num_epochs
        epoch_gen_loss = 0;
        epoch_disc_loss = 0;
        epoch_disc_real_loss = 0;
        epoch_disc_fake_loss = 0;
        
        for batch = 1:num_batches
            % Get real batch
            batch_start = (batch - 1) * batch_size + 1;
            batch_end = batch * batch_size;
            real_batch = trainingData(:, :, :, batch_start:batch_end);
            real_batch = dlarray(real_batch, 'SSCB'); % Spatial, Spatial, Channel, Batch
            
            % Generate fake batch
            noise = randn(latent_dim, batch_size, 'single');
            noise = dlarray(noise, 'CB'); % Channel, Batch
            
            % Train discriminator
            [disc_loss, disc_real_loss, disc_fake_loss] = trainDiscriminator(discriminator, generator, real_batch, noise);
            
            % Train generator
            gen_loss = trainGenerator(generator, discriminator, noise);
            
            % Accumulate losses
            epoch_gen_loss = epoch_gen_loss + extractdata(gen_loss);
            epoch_disc_loss = epoch_disc_loss + extractdata(disc_loss);
            epoch_disc_real_loss = epoch_disc_real_loss + extractdata(disc_real_loss);
            epoch_disc_fake_loss = epoch_disc_fake_loss + extractdata(disc_fake_loss);
        end
        
        % Average losses
        avg_gen_loss = epoch_gen_loss / num_batches;
        avg_disc_loss = epoch_disc_loss / num_batches;
        avg_disc_real_loss = epoch_disc_real_loss / num_batches;
        avg_disc_fake_loss = epoch_disc_fake_loss / num_batches;
        
        % Store losses
        losses.generator(end+1) = avg_gen_loss;
        losses.discriminator(end+1) = avg_disc_loss;
        losses.discriminator_real(end+1) = avg_disc_real_loss;
        losses.discriminator_fake(end+1) = avg_disc_fake_loss;
        
        % Print progress
        if mod(epoch, 5) == 0 || epoch == 1
            fprintf('Epoch %d: Gen Loss %.4f, Disc Loss %.4f\n', ...
                epoch, avg_gen_loss, avg_disc_loss);
        end
        
        % Generate samples for monitoring
        if mod(epoch, 10) == 0
            monitorTrainingProgress(generator, latent_dim, epoch);
        end
    end
    
    trained_generator = generator;
    trained_discriminator = discriminator;
end

function [disc_loss, real_loss, fake_loss] = trainDiscriminator(discriminator, generator, real_data, noise)
    % Forward pass for real data
    real_predictions = forward(discriminator, real_data);
    real_labels = ones(size(real_predictions), 'like', real_predictions);
    real_loss = binaryCrossEntropy(real_predictions, real_labels);
    
    % Generate fake data
    fake_data = forward(generator, noise);
    fake_predictions = forward(discriminator, fake_data);
    fake_labels = zeros(size(fake_predictions), 'like', fake_predictions);
    fake_loss = binaryCrossEntropy(fake_predictions, fake_labels);
    
    % Total discriminator loss
    disc_loss = (real_loss + fake_loss) / 2;
end

function gen_loss = trainGenerator(generator, discriminator, noise)
    % Generate fake data
    fake_data = forward(generator, noise);
    
    % Get discriminator predictions for fake data
    fake_predictions = forward(discriminator, fake_data);
    
    % Generator wants discriminator to think fake data is real
    real_labels = ones(size(fake_predictions), 'like', fake_predictions);
    gen_loss = binaryCrossEntropy(fake_predictions, real_labels);
end

function loss = binaryCrossEntropy(predictions, targets)
    % Clamp predictions to prevent log(0)
    predictions = max(min(predictions, 1 - 1e-7), 1e-7);
    loss = -mean(targets .* log(predictions) + (1 - targets) .* log(1 - predictions), 'all');
end

function monitorTrainingProgress(generator, latent_dim, epoch)
    % Generate sample images
    num_samples = 16;
    noise = randn(latent_dim, num_samples, 'single');
    noise = dlarray(noise, 'CB');
    
    generated_images = forward(generator, noise);
    generated_images = extractdata(generated_images);
    
    % Convert from [-1, 1] to [0, 1] range
    generated_images = (generated_images + 1) / 2;
    
    % Display generated images
    figure(100);
    for i = 1:num_samples
        subplot(4, 4, i);
        img = generated_images(:, :, :, i);
        img = permute(img, [1, 2, 3]); % Reorder dimensions if needed
        
        if size(img, 3) == 1
            imshow(img, []);
        else
            imshow(img);
        end
        axis off;
    end
    sgtitle(sprintf('Generated Images - Epoch %d', epoch));
    drawnow;
end

function analyzeGANArchitecture(generator_lgraph, discriminator_lgraph)
    fprintf('\nGAN Architecture Analysis:\n');
    fprintf('==========================\n');
    
    % Analyze generator
    gen_layers = generator_lgraph.Layers;
    gen_conv_count = sum(arrayfun(@(x) isa(x, 'nnet.cnn.layer.TransposedConvolution2DLayer'), gen_layers));
    gen_bn_count = sum(arrayfun(@(x) isa(x, 'nnet.cnn.layer.BatchNormalizationLayer'), gen_layers));
    
    fprintf('Generator:\n');
    fprintf('  Total layers: %d\n', length(gen_layers));
    fprintf('  Transposed conv layers: %d\n', gen_conv_count);
    fprintf('  Batch norm layers: %d\n', gen_bn_count);
    
    % Analyze discriminator
    disc_layers = discriminator_lgraph.Layers;
    disc_conv_count = sum(arrayfun(@(x) isa(x, 'nnet.cnn.layer.Convolution2DLayer'), disc_layers));
    disc_bn_count = sum(arrayfun(@(x) isa(x, 'nnet.cnn.layer.BatchNormalizationLayer'), disc_layers));
    
  fprintf('Discriminator:\n');
    fprintf('  Total layers: %d\n', length(disc_layers));
    fprintf('  Conv layers: %d\n', disc_conv_count);
    fprintf('  Batch norm layers: %d\n', disc_bn_count);
    
    % Parameter estimation
    gen_params = estimateNetworkParameters(gen_layers, 'generator');
    disc_params = estimateNetworkParameters(disc_layers, 'discriminator');
    
    fprintf('  Generator parameters: ~%.1e\n', gen_params);
    fprintf('  Discriminator parameters: ~%.1e\n', disc_params);
    fprintf('  Total GAN parameters: ~%.1e\n', gen_params + disc_params);
end

function param_count = estimateNetworkParameters(layers, net_type)
    param_count = 0;
    
    for i = 1:length(layers)
        layer = layers(i);
        
        if isa(layer, 'nnet.cnn.layer.Convolution2DLayer') || ...
           isa(layer, 'nnet.cnn.layer.TransposedConvolution2DLayer')
            % Rough parameter estimation for conv layers
            if strcmp(net_type, 'generator')
                if i <= 3
                    input_channels = 100; % Latent dimension
                else
                    input_channels = 256; % Estimated
                end
            else
                input_channels = 64; % Estimated for discriminator
            end
            
            filter_size = 4; % Common filter size
            output_channels = 64; % Estimated
            
            weights = filter_size * filter_size * input_channels * output_channels;
            biases = output_channels;
            param_count = param_count + weights + biases;
            
        elseif isa(layer, 'nnet.cnn.layer.FullyConnectedLayer')
            % FC layer parameters
            if isprop(layer, 'OutputSize')
                output_size = layer.OutputSize;
                input_size = 1000; % Estimated
                param_count = param_count + input_size * output_size + output_size;
            end
            
        elseif isa(layer, 'nnet.cnn.layer.BatchNormalizationLayer')
            % BN parameters (scale and offset)
            param_count = param_count + 128; % Estimated channel count * 2
        end
    end
end

function stability_metrics = analyzeTrainingStability(losses)
    stability_metrics = struct();
    
    if isfield(losses, 'generator') && length(losses.generator) > 1
        gen_losses = losses.generator;
        disc_losses = losses.discriminator;
        
        % Loss trends
        stability_metrics.gen_trend = polyfit(1:length(gen_losses), gen_losses, 1);
        stability_metrics.disc_trend = polyfit(1:length(disc_losses), disc_losses, 1);
        
        % Loss variance (stability indicator)
        stability_metrics.gen_variance = var(gen_losses);
        stability_metrics.disc_variance = var(disc_losses);
        
        % Nash equilibrium indicator (ratio of losses)
        loss_ratio = gen_losses ./ (disc_losses + eps);
        stability_metrics.equilibrium_variance = var(loss_ratio);
        
        fprintf('\nTraining Stability Analysis:\n');
        fprintf('============================\n');
        fprintf('Generator loss trend: %.6f (slope)\n', stability_metrics.gen_trend(1));
        fprintf('Discriminator loss trend: %.6f (slope)\n', stability_metrics.disc_trend(1));
        fprintf('Generator loss variance: %.6f\n', stability_metrics.gen_variance);
        fprintf('Discriminator loss variance: %.6f\n', stability_metrics.disc_variance);
        fprintf('Equilibrium variance: %.6f\n', stability_metrics.equilibrium_variance);
        
        % Stability assessment
        if abs(stability_metrics.gen_trend(1)) < 0.01 && abs(stability_metrics.disc_trend(1)) < 0.01
            fprintf('Assessment: Training appears stable\n');
        elseif stability_metrics.gen_trend(1) > 0.05
            fprintf('Assessment: Generator loss increasing - possible mode collapse\n');
        elseif stability_metrics.disc_trend(1) > 0.05
            fprintf('Assessment: Discriminator loss increasing - generator winning\n');
        else
            fprintf('Assessment: Training dynamics unclear\n');
        end
    else
        fprintf('Insufficient loss history for stability analysis\n');
    end
end

function mode_collapse_analysis()
    fprintf('\nMode Collapse Detection Strategies:\n');
    fprintf('===================================\n');
    fprintf('1. Inception Score (IS): Measures quality and diversity\n');
    fprintf('2. Fr谷chet Inception Distance (FID): Compares feature distributions\n');
    fprintf('3. Precision and Recall: Measures fidelity vs diversity trade-off\n');
    fprintf('4. Visual inspection: Check for repeated patterns\n');
    fprintf('5. Latent space interpolation: Smooth transitions indicate good coverage\n');
    
    fprintf('\nMode Collapse Mitigation Techniques:\n');
    fprintf('1. Unrolled GANs: Discriminator considers future generator updates\n');
    fprintf('2. Feature matching: Generator matches discriminator feature statistics\n');
    fprintf('3. Minibatch discrimination: Discriminator sees multiple samples\n');
    fprintf('4. Historical averaging: Prevents rapid parameter changes\n');
    fprintf('5. WGAN: Uses Wasserstein distance for better gradients\n');
end

function compareGANVariants()
    fprintf('\nGAN Variants Comparison:\n');
    fprintf('========================\n');
    
    variants = {
        'Vanilla GAN', 'Original adversarial training', 'Mode collapse, training instability';
        'DCGAN', 'Deep convolutional architecture', 'Better image generation, more stable';
        'WGAN', 'Wasserstein distance objective', 'Improved training stability, meaningful loss';
        'WGAN-GP', 'Gradient penalty regularization', 'Avoids weight clipping issues';
        'Progressive GAN', 'Gradual resolution increase', 'High-resolution generation';
        'StyleGAN', 'Style-based generator', 'Fine-grained control, high quality';
        'BigGAN', 'Large-scale training', 'State-of-the-art image quality';
        'CycleGAN', 'Unpaired image translation', 'Domain adaptation without pairs';
        'Pix2Pix', 'Paired image translation', 'Supervised image-to-image translation';
        'conditional GAN', 'Label-conditioned generation', 'Controlled generation'
    };
    
    fprintf('%-15*s %-35*s %-40*s\n', 'Variant', 'Key Innovation', 'Advantages/Applications');
    fprintf('%s\n', repmat('-', 1, 90));
    
    for i = 1:size(variants, 1)
        fprintf('%-15*s %-35*s %-40*s\n', variants{i, 1}, variants{i, 2}, variants{i, 3});
    end
end
