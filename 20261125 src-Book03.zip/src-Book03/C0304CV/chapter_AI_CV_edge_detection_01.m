%% chapter_AI_CV_edge_detection_01.m
% Comprehensive Edge Detection Methods Comparison
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_edge_detection_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Load test image with diverse edge characteristics
test_image = imread('coins.png');
test_image = im2double(test_image);

% Apply different edge detection methods
edges_roberts = edge(test_image, 'roberts');
edges_prewitt = edge(test_image, 'prewitt');
edges_sobel = edge(test_image, 'sobel');
edges_canny = edge(test_image, 'canny');

% Canny with different parameters to demonstrate sensitivity
edges_canny_low = edge(test_image, 'canny', [0.05, 0.15]);
edges_canny_high = edge(test_image, 'canny', [0.15, 0.35]);
edges_canny_sigma = edge(test_image, 'canny', [], 2.0);  % Higher sigma

% Manual gradient calculation for educational purposes
% Sobel kernels
sobel_x = [-1 0 1; -2 0 2; -1 0 1];
sobel_y = [-1 -2 -1; 0 0 0; 1 2 1];

% Apply convolution manually
grad_x = imfilter(test_image, sobel_x, 'symmetric');
grad_y = imfilter(test_image, sobel_y, 'symmetric');

% Calculate gradient magnitude and direction
gradient_magnitude = sqrt(grad_x.^2 + grad_y.^2);
gradient_direction = atan2(grad_y, grad_x);

% Prewitt kernels for comparison
prewitt_x = [-1 0 1; -1 0 1; -1 0 1];
prewitt_y = [-1 -1 -1; 0 0 0; 1 1 1];

grad_x_prewitt = imfilter(test_image, prewitt_x, 'symmetric');
grad_y_prewitt = imfilter(test_image, prewitt_y, 'symmetric');
gradient_magnitude_prewitt = sqrt(grad_x_prewitt.^2 + grad_y_prewitt.^2);

% Roberts cross-gradient operators
roberts_x = [1 0; 0 -1];
roberts_y = [0 1; -1 0];

grad_x_roberts = imfilter(test_image, roberts_x, 'symmetric');
grad_y_roberts = imfilter(test_image, roberts_y, 'symmetric');
gradient_magnitude_roberts = sqrt(grad_x_roberts.^2 + grad_y_roberts.^2);

% Non-maximum suppression demonstration

% Apply non-maximum suppression to Sobel gradient
suppressed_sobel = nonMaxSuppression(gradient_magnitude, gradient_direction);

% Quantitative edge analysis

% Analyze different methods
metrics_roberts = analyzeEdges(edges_roberts, test_image);
metrics_sobel = analyzeEdges(edges_sobel, test_image);
metrics_canny = analyzeEdges(edges_canny, test_image);

% Display comprehensive results
figure;
subplot(3,4,1); imshow(test_image); title('Original Image');
subplot(3,4,2); imshow(edges_roberts); title('Roberts Operator');
subplot(3,4,3); imshow(edges_prewitt); title('Prewitt Operator');
subplot(3,4,4); imshow(edges_sobel); title('Sobel Operator');

subplot(3,4,5); imshow(gradient_magnitude, []); title('Gradient Magnitude');
subplot(3,4,6); imshow(gradient_direction, []); title('Gradient Direction');
subplot(3,4,7); imshow(suppressed_sobel, []); title('Non-max Suppressed');
subplot(3,4,8); imshow(edges_canny); title('Canny Edges');

subplot(3,4,9); imshow(edges_canny_low); title('Canny (Low Thresh)');
subplot(3,4,10); imshow(edges_canny_high); title('Canny (High Thresh)');
subplot(3,4,11); imshow(edges_canny_sigma); title('Canny (考=2.0)');

% Comparative analysis plot
subplot(3,4,12);
methods = {'Roberts', 'Sobel', 'Canny'};
edge_densities = [metrics_roberts.edge_density, metrics_sobel.edge_density, metrics_canny.edge_density];
edge_strengths = [metrics_roberts.avg_edge_strength, metrics_sobel.avg_edge_strength, metrics_canny.avg_edge_strength];

yyaxis left;
bar(1:3, edge_densities, 'FaceColor', 'blue', 'FaceAlpha', 0.7);
ylabel('Edge Density');
yyaxis right;
bar(1:3, edge_strengths, 'FaceColor', 'red', 'FaceAlpha', 0.7);
ylabel('Average Edge Strength');
set(gca, 'XTickLabel', methods);
title('Edge Detection Metrics');

% Print quantitative results
fprintf('Edge Detection Performance Analysis:\n');
fprintf('Method\t\tDensity\t\tAvg Strength\tConnectivity\n');
fprintf('Roberts\t\t%.4f\t\t%.3f\t\t%.3f\n', metrics_roberts.edge_density, ...
    metrics_roberts.avg_edge_strength, metrics_roberts.connectivity);
fprintf('Sobel\t\t%.4f\t\t%.3f\t\t%.3f\n', metrics_sobel.edge_density, ...
    metrics_sobel.avg_edge_strength, metrics_sobel.connectivity);
fprintf('Canny\t\t%.4f\t\t%.3f\t\t%.3f\n', metrics_canny.edge_density, ...
    metrics_canny.avg_edge_strength, metrics_canny.connectivity);

% Local functions (moved to end so this listing is a valid MATLAB script)
function suppressed = nonMaxSuppression(magnitude, direction)
    [rows, cols] = size(magnitude);
    suppressed = zeros(rows, cols);
    
    % Convert angles to degrees and normalise to 0-180
    angle = rad2deg(direction);
    angle(angle < 0) = angle(angle < 0) + 180;
    
    for i = 2:rows-1
        for j = 2:cols-1
            try
                q = 255;
                r = 255;
                
                % Angle 0
                if (0 <= angle(i,j) < 22.5) || (157.5 <= angle(i,j) <= 180)
                    q = magnitude(i, j+1);
                    r = magnitude(i, j-1);
                % Angle 45
                elseif (22.5 <= angle(i,j) < 67.5)
                    q = magnitude(i+1, j-1);
                    r = magnitude(i-1, j+1);
                % Angle 90
                elseif (67.5 <= angle(i,j) < 112.5)
                    q = magnitude(i+1, j);
                    r = magnitude(i-1, j);
                % Angle 135
                elseif (112.5 <= angle(i,j) < 157.5)
                    q = magnitude(i-1, j-1);
                    r = magnitude(i+1, j+1);
                end
                
                if (magnitude(i,j) >= q) && (magnitude(i,j) >= r)
                    suppressed(i,j) = magnitude(i,j);
                else
                    suppressed(i,j) = 0;
                end
            catch
                % Handle boundary conditions
            end
        end
    end
end

function metrics = analyzeEdges(edge_image, original_image)
    metrics.edge_density = sum(edge_image(:)) / numel(edge_image);
    metrics.total_edge_length = sum(edge_image(:));
    
    % Calculate edge connectivity (simplified)
    se = strel('square', 3);
    dilated = imdilate(edge_image, se);
    metrics.connectivity = sum(dilated(:)) / sum(edge_image(:));
    
    % Edge strength assessment
    if exist('original_image', 'var')
        [gx, gy] = gradient(double(original_image));
        edge_locations = edge_image > 0;
        edge_strengths = sqrt(gx.^2 + gy.^2);
        metrics.avg_edge_strength = mean(edge_strengths(edge_locations));
    end
end
