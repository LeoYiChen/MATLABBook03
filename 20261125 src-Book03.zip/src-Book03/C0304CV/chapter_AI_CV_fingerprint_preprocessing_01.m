%% chapter_AI_CV_fingerprint_preprocessing_01.m
% Comprehensive Fingerprint Image Preprocessing Pipeline
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_fingerprint_preprocessing_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Comprehensive Fingerprint Image Preprocessing System
fprintf('Fingerprint Image Preprocessing: Enhancing Quality for Recognition\n');
fprintf('================================================================\n');

% Load fingerprint image (create synthetic example for demonstration)
fingerprintImage = createSyntheticFingerprint([300, 300]);


% Display original fingerprint
figure;
subplot(2, 4, 1);
imshow(fingerprintImage);
title('Original Fingerprint');

% 1. Image Quality Assessment


% Assess image quality
imageQuality = assessImageQuality(fingerprintImage);

% 2. Fingerprint Segmentation

% Perform segmentation
[fingerprintMask, segmentedFingerprint] = segmentFingerprint(fingerprintImage);

% Display segmentation results
subplot(2, 4, 2);
imshow(fingerprintMask);
title('Segmentation Mask');

subplot(2, 4, 3);
imshow(segmentedFingerprint);
title('Segmented Fingerprint');

% 3. Direction Field Estimation


% Compute direction field
ridgeDirections = computeDirectionField(segmentedFingerprint, 12);

% Visualize direction field
subplot(2, 4, 4);
visualizeDirectionField(segmentedFingerprint, ridgeDirections, 12);
title('Ridge Direction Field');


% 4. Ridge Enhancement using Gabor Filters


% Enhance fingerprint using Gabor filters
enhancedFingerprint = enhanceRidges(segmentedFingerprint, ridgeDirections, 12);

% Display enhanced fingerprint
subplot(2, 4, 5);
imshow(enhancedFingerprint);
title('Enhanced Fingerprint');

% 5. Ridge Thinning (Skeletonization)

% Thin the enhanced fingerprint
skeletonFingerprint = thinRidges(enhancedFingerprint, 120);

% Display thinned fingerprint
subplot(2, 4, 6);
imshow(skeletonFingerprint);
title('Thinned Ridge Structure');

% 6. Comprehensive preprocessing pipeline

% Run complete preprocessing pipeline
[finalProcessed, allResults] = preprocessFingerprint(fingerprintImage);

% Display final result
subplot(2, 4, 7);
imshow(finalProcessed);
title('Final Processed Image');

% Quality comparison
subplot(2, 4, 8);
% Create quality comparison plot
qualityMetrics = {
    allResults.quality.meanVariance,
    allResults.quality.meanGradient,
    allResults.quality.meanCoherence
};
qualityLabels = {'Variance', 'Gradient', 'Coherence'};

bar(cell2mat(qualityMetrics));
set(gca, 'XTickLabel', qualityLabels);
title('Image Quality Metrics');
ylabel('Metric Value');

% Print comprehensive preprocessing summary
fprintf('\nFingerprint Preprocessing Summary:\n');
fprintf('==================================\n');
fprintf('Original image quality: %s\n', allResults.quality.overallQuality);
fprintf('Segmentation: Foreground pixels = %d (%.1f%%)\n', ...
    sum(allResults.mask(:)), 100 * sum(allResults.mask(:)) / numel(allResults.mask));
fprintf('Enhancement: Gabor filtering applied\n');
fprintf('Thinning: Ridge skeleton extracted\n');

% Advanced preprocessing techniques
fprintf('\nAdvanced Preprocessing Techniques:\n');
fprintf('=================================\n');
fprintf('1. Adaptive enhancement based on local quality\n');
fprintf('2. Multi-scale Gabor filtering for different ridge frequencies\n');
fprintf('3. Contextual post-filtering for noise removal\n');
fprintf('4. Quality-guided parameter selection\n');
fprintf('5. Machine learning-based enhancement\n');
fprintf('6. Distortion correction for sensor artifacts\n');
fprintf('7. Template matching for pattern completion\n');
fprintf('8. Anisotropic diffusion for edge-preserving smoothing\n');

% Performance considerations
fprintf('\nPerformance Optimization:\n');
fprintf('========================\n');
fprintf('1. Block-wise processing for memory efficiency\n');
fprintf('2. Parallel processing for multiple images\n');
fprintf('3. GPU acceleration for filter operations\n');
fprintf('4. Look-up tables for trigonometric functions\n');
fprintf('5. Hierarchical processing for speed\n');
fprintf('6. Adaptive quality assessment to skip poor regions\n');
fprintf('7. Efficient data structures for sparse representations\n');
fprintf('8. Multi-threading for independent operations\n');

% Local functions (moved to end so this listing is a valid MATLAB script)
function fpImage = createSyntheticFingerprint(imageSize)
    % Create synthetic fingerprint image for demonstration
    [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
    
    % Create base ridge pattern
    centerX = imageSize(2) / 2;
    centerY = imageSize(1) / 2;
    
    % Generate whorl-like pattern
    angle = atan2(Y - centerY, X - centerX);
    radius = sqrt((X - centerX).^2 + (Y - centerY).^2);
    
    % Create ridge structure
    ridgeSpacing = 8; % Average ridge spacing in pixels
    ridgePattern = sin(2 * pi * radius / ridgeSpacing + 2 * angle);
    
    % Add noise and variations
    noise = 0.3 * randn(imageSize);
    fpImage = ridgePattern + noise;
    
    % Create foreground mask (elliptical fingerprint region)
    a = imageSize(2) * 0.4; % Semi-major axis
    b = imageSize(1) * 0.35; % Semi-minor axis
    foregroundMask = ((X - centerX) / a).^2 + ((Y - centerY) / b).^2 <= 1;
    
    % Apply foreground mask
    fpImage = fpImage .* foregroundMask;
    
    % Normalize to [0, 1] range
    fpImage = (fpImage - min(fpImage(:))) / (max(fpImage(:)) - min(fpImage(:)));
    
    % Add some realistic imperfections
    % Dry finger simulation (low contrast regions)
    dryRegion = (X > centerX + 50) & (Y < centerY - 30);
    fpImage(dryRegion) = fpImage(dryRegion) * 0.7;
    
    % Wet finger simulation (blurred regions)
    wetRegion = (X < centerX - 40) & (Y > centerY + 40);
    if any(wetRegion(:))
        wetKernel = fspecial('gaussian', [5, 5], 1.5);
        fpImage(wetRegion) = imfilter(fpImage(wetRegion), wetKernel, 'same');
    end
    
    % Convert to uint8
    fpImage = uint8(fpImage * 255);
end

function qualityMetrics = assessImageQuality(fpImage)
    % Assess fingerprint image quality using various metrics
    
    fprintf('Assessing fingerprint image quality...\n');
    
    % Convert to double for processing
    img = double(fpImage) / 255;
    
    % Local variance (indicator of ridge clarity)
    localVar = stdfilt(img, ones(5, 5)).^2;
    
    % Gradient magnitude (edge strength)
    [Gx, Gy] = gradient(img);
    gradMagnitude = sqrt(Gx.^2 + Gy.^2);
    
    % Coherence (directional consistency)
    coherence = computeCoherence(img);
    
    % Overall quality metrics
    qualityMetrics = struct();
    qualityMetrics.meanVariance = mean(localVar(:));
    qualityMetrics.meanGradient = mean(gradMagnitude(:));
    qualityMetrics.meanCoherence = mean(coherence(:));
    
    % Quality classification
    if qualityMetrics.meanVariance > 0.02 && qualityMetrics.meanGradient > 0.1
        qualityMetrics.overallQuality = 'Good';
    elseif qualityMetrics.meanVariance > 0.01 && qualityMetrics.meanGradient > 0.05
        qualityMetrics.overallQuality = 'Fair';
    else
        qualityMetrics.overallQuality = 'Poor';
    end
    
    fprintf('Image quality assessment:\n');
    fprintf('  Mean variance: %.4f\n', qualityMetrics.meanVariance);
    fprintf('  Mean gradient: %.4f\n', qualityMetrics.meanGradient);
    fprintf('  Mean coherence: %.4f\n', qualityMetrics.meanCoherence);
    fprintf('  Overall quality: %s\n', qualityMetrics.overallQuality);
end

function coherence = computeCoherence(img)
    % Compute local coherence (directional consistency)
    
    [Gx, Gy] = gradient(img);
    
    % Local structure tensor
    windowSize = 5;
    w = ones(windowSize, windowSize) / windowSize^2;
    
    Gxx = imfilter(Gx.^2, w, 'same');
    Gyy = imfilter(Gy.^2, w, 'same');
    Gxy = imfilter(Gx .* Gy, w, 'same');
    
    % Coherence measure
    coherence = ((Gxx - Gyy).^2 + 4 * Gxy.^2) ./ ((Gxx + Gyy).^2 + eps);
end

function [foregroundMask, segmentedImage] = segmentFingerprint(fpImage, qualityThreshold)
    % Segment fingerprint image to separate foreground from background
    
    if nargin < 2
        qualityThreshold = 0.01;
    end
    
    fprintf('Segmenting fingerprint image...\n');
    
    % Convert to double
    img = double(fpImage) / 255;
    [height, width] = size(img);
    
    % Block-wise analysis for segmentation
    blockSize = 16;
    numBlocksY = floor(height / blockSize);
    numBlocksX = floor(width / blockSize);
    
    foregroundMask = false(height, width);
    
    for by = 1:numBlocksY
        for bx = 1:numBlocksX
            % Extract block
            yRange = (by-1)*blockSize + (1:blockSize);
            xRange = (bx-1)*blockSize + (1:blockSize);
            
            if max(yRange) <= height && max(xRange) <= width
                block = img(yRange, xRange);
                
                % Compute block statistics
                blockVar = var(block(:));
                blockMean = mean(block(:));
                
                % Classification criteria
                if blockVar > qualityThreshold && blockMean > 0.1 && blockMean < 0.9
                    foregroundMask(yRange, xRange) = true;
                end
            end
        end
    end
    
    % Morphological operations to clean up segmentation
    se = strel('disk', 3);
    foregroundMask = imopen(foregroundMask, se);
    foregroundMask = imclose(foregroundMask, se);
    
    % Remove small connected components
    foregroundMask = bwareaopen(foregroundMask, 500);
    
    % Create segmented image
    segmentedImage = fpImage;
    segmentedImage(~foregroundMask) = 0;
    
    fprintf('Segmentation completed\n');
end

function directionField = computeDirectionField(fpImage, blockSize)
    % Compute local ridge direction field
    
    if nargin < 2
        blockSize = 16;
    end
    
    fprintf('Computing ridge direction field...\n');
    
    % Convert to double
    img = double(fpImage) / 255;
    [height, width] = size(img);
    
    % Gradient computation
    [Gx, Gy] = gradient(img);
    
    % Block-wise direction estimation
    numBlocksY = ceil(height / blockSize);
    numBlocksX = ceil(width / blockSize);
    
    directionField = zeros(numBlocksY, numBlocksX);
    
    for by = 1:numBlocksY
        for bx = 1:numBlocksX
            % Extract block coordinates
            yStart = (by-1) * blockSize + 1;
            yEnd = min(by * blockSize, height);
            xStart = (bx-1) * blockSize + 1;
            xEnd = min(bx * blockSize, width);
            
            % Extract gradients for block
            blockGx = Gx(yStart:yEnd, xStart:xEnd);
            blockGy = Gy(yStart:yEnd, xStart:xEnd);
            
            % Compute orientation using gradient analysis
            % Average squared gradients
            Gxx = sum(blockGx(:).^2);
            Gyy = sum(blockGy(:).^2);
            Gxy = sum(blockGx(:) .* blockGy(:));
            
            % Ridge orientation (perpendicular to gradient direction)
            if Gxx + Gyy > 0
                theta = 0.5 * atan2(2 * Gxy, Gxx - Gyy);
                directionField(by, bx) = theta + pi/2; % Ridge direction
            else
                directionField(by, bx) = 0;
            end
        end
    end
    
    % Smooth direction field
    directionField = smoothDirectionField(directionField);
    
    fprintf('Direction field computation completed\n');
end

function smoothedField = smoothDirectionField(directionField)
    % Smooth direction field using circular statistics
    
    % Convert to complex representation for averaging
    complexField = exp(2*i * directionField);
    
    % Apply gaussian smoothing
    smoothedComplex = imgaussfilt(real(complexField), 1) + ...
                     1*i * imgaussfilt(imag(complexField), 1);
    
    % Convert back to angles
    smoothedField = angle(smoothedComplex) / 2;
    
    % Ensure angles are in [0, pi) range
    smoothedField = mod(smoothedField, pi);
end

function visualizeDirectionField(img, dirField, blockSize)
    % Visualize ridge direction field as overlaid arrows
    
    imshow(img);
    hold on;
    
    [height, width] = size(img);
    [numBlocksY, numBlocksX] = size(dirField);
    
    % Draw direction vectors
    for by = 1:2:numBlocksY % Subsample for clarity
        for bx = 1:2:numBlocksX
            % Block center coordinates
            y = (by - 0.5) * blockSize;
            x = (bx - 0.5) * blockSize;
            
            if y <= height && x <= width
                % Direction angle
                theta = dirField(by, bx);
                
                % Vector components
                dx = cos(theta) * blockSize * 0.4;
                dy = sin(theta) * blockSize * 0.4;
                
                % Draw arrow
                quiver(x, y, dx, dy, 0, 'r', 'LineWidth', 1.5, 'MaxHeadSize', 0.3);
            end
        end
    end
    
    hold off;
end

function enhancedImage = enhanceRidges(fpImage, directionField, blockSize)
    % Enhance ridge patterns using oriented Gabor filters
    
    fprintf('Enhancing ridge patterns with Gabor filters...\n');
    
    % Convert to double
    img = double(fpImage) / 255;
    [height, width] = size(img);
    
    % Gabor filter parameters
    ridgeFreq = 1/8; % Average ridge frequency (cycles per pixel)
    sigma = 4;       % Gaussian envelope size
    
    enhancedImage = zeros(size(img));
    
    [numBlocksY, numBlocksX] = size(directionField);
    
    for by = 1:numBlocksY
        for bx = 1:numBlocksX
            % Block coordinates
            yStart = (by-1) * blockSize + 1;
            yEnd = min(by * blockSize, height);
            xStart = (bx-1) * blockSize + 1;
            xEnd = min(bx * blockSize, width);
            
            % Local orientation
            theta = directionField(by, bx);
            
            % Create Gabor filter for this orientation
            gaborFilter = createGaborFilter(sigma, theta, ridgeFreq, blockSize);
            
            % Extract and filter block
            block = img(yStart:yEnd, xStart:xEnd);
            
            % Ensure block size matches filter size
            [blockH, blockW] = size(block);
            [filterH, filterW] = size(gaborFilter);
            
            if blockH == filterH && blockW == filterW
                filteredBlock = imfilter(block, gaborFilter, 'same');
                enhancedImage(yStart:yEnd, xStart:xEnd) = filteredBlock;
            else
                % Handle size mismatch for edge blocks
                enhancedImage(yStart:yEnd, xStart:xEnd) = block;
            end
        end
    end
    
    % Normalize to [0, 1] range
    enhancedImage = (enhancedImage - min(enhancedImage(:))) / ...
                   (max(enhancedImage(:)) - min(enhancedImage(:)) + eps);
    
    % Convert to uint8
    enhancedImage = uint8(enhancedImage * 255);
    
    fprintf('Ridge enhancement completed\n');
end

function gaborFilter = createGaborFilter(sigma, theta, freq, size)
    % Create 2*D Gabor filter for ridge enhancement
    
    % Create coordinate grid
    halfSize = floor(size / 2);
    [x, y] = meshgrid(-halfSize:halfSize, -halfSize:halfSize);
    
    % Rotate coordinates
    xRot = x * cos(theta) + y * sin(theta);
    yRot = -x * sin(theta) + y * cos(theta);
    
    % Gabor function
    gaussian = exp(-(xRot.^2 + yRot.^2) / (2 * sigma^2));
    sinusoid = cos(2 * pi * freq * xRot);
    
    gaborFilter = gaussian .* sinusoid;
    
    % Normalize to zero mean
    gaborFilter = gaborFilter - mean(gaborFilter(:));
end

function skeletonImage = thinRidges(fpImage, threshold)
    % Thin ridges to single-pixel width using morphological operations
    
    if nargin < 2
        threshold = 128;
    end
    
    fprintf('Thinning ridge structures...\n');
    
    % Binarize image
    binaryImage = fpImage > threshold;
    
    % Morphological thinning
    skeletonImage = bwmorph(binaryImage, 'thin', Inf);
    
    % Clean up skeleton
    skeletonImage = bwmorph(skeletonImage, 'clean');
    skeletonImage = bwmorph(skeletonImage, 'spur', 3);
    
    fprintf('Ridge thinning completed\n');
end

function [processedImage, intermediateResults] = preprocessFingerprint(inputImage, options)
    % Complete fingerprint preprocessing pipeline
    
    if nargin < 2
        options = struct();
        options.segmentationThreshold = 0.01;
        options.blockSize = 12;
        options.enhancementSigma = 4;
        options.binarizationThreshold = 120;
    end
    
    fprintf('Running complete preprocessing pipeline...\n');
    
    % Store intermediate results
    intermediateResults = struct();
    intermediateResults.original = inputImage;
    
    % Quality assessment
    quality = assessImageQuality(inputImage);
    intermediateResults.quality = quality;
    
    % Segmentation
    [mask, segmented] = segmentFingerprint(inputImage, options.segmentationThreshold);
    intermediateResults.mask = mask;
    intermediateResults.segmented = segmented;
    
    % Direction field estimation
    directions = computeDirectionField(segmented, options.blockSize);
    intermediateResults.directions = directions;
    
    % Ridge enhancement
    enhanced = enhanceRidges(segmented, directions, options.blockSize);
    intermediateResults.enhanced = enhanced;
    
    % Ridge thinning
    skeleton = thinRidges(enhanced, options.binarizationThreshold);
    intermediateResults.skeleton = skeleton;
    
    % Final processed image
    processedImage = skeleton;
    
    fprintf('Preprocessing pipeline completed\n');
end
