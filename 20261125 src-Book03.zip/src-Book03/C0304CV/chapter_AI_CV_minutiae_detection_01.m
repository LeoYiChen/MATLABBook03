%% chapter_AI_CV_minutiae_detection_01.m
% Advanced Minutiae Detection and Feature Extraction System
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_minutiae_detection_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Advanced Minutiae Detection and Feature Extraction
fprintf('Minutiae Detection and Feature Extraction System\n');
fprintf('===============================================\n');

% Use the preprocessed fingerprint from previous section
if exist('finalProcessed', 'var')
    skeletonImage = finalProcessed;
else
    % Create synthetic skeleton for demonstration
    skeletonImage = createSyntheticSkeleton([300, 300]);
end


% 1. Minutiae Detection using Crossing Number Method




% Detect minutiae
detectedMinutiae = detectMinutiae(skeletonImage);

% 2. Minutiae Post-processing and Filtering

% Filter detected minutiae
filteredMinutiae = filterMinutiae(detectedMinutiae);

% 3. Feature Vector Construction

% Construct different types of feature vectors
spatialFeatures = constructFeatureVector(filteredMinutiae, 'spatial');
relativeFeatures = constructFeatureVector(filteredMinutiae, 'relative');

% 4. Minutiae Visualization and Analysis

% Visualize results
if exist('skeletonImage', 'var')
    visualizeMinutiae(skeletonImage, filteredMinutiae, 'Detected Minutiae');
end

% 5. Advanced Minutiae Analysis

% Perform minutiae analysis
minutiaeAnalysis = analyzeMinutiaeStatistics(filteredMinutiae);

% 6. Feature Quality Assessment

% Assess feature quality
if ~isempty(spatialFeatures)
    spatialQuality = assessFeatureQuality(spatialFeatures, filteredMinutiae);
end

% Advanced techniques summary
fprintf('\nAdvanced Minutiae Detection Techniques:\n');
fprintf('======================================\n');
fprintf('1. Machine learning-based minutiae detection\n');
fprintf('2. Multi-scale analysis for robust detection\n');
fprintf('3. Contextual validation using local patterns\n');
fprintf('4. Quality-guided feature selection\n');
fprintf('5. Adaptive thresholding based on local characteristics\n');
fprintf('6. Integration of ridge and minutiae information\n');
fprintf('7. Uncertainty quantification for reliability assessment\n');
fprintf('8. Real-time optimization for mobile applications\n');

% Best practices
fprintf('\nBest Practices for Minutiae Detection:\n');
fprintf('=====================================\n');
fprintf('1. Use high-quality preprocessing to improve detection accuracy\n');
fprintf('2. Implement robust validation to filter spurious minutiae\n');
fprintf('3. Consider multiple feature representations for robustness\n');
fprintf('4. Adapt parameters based on image quality assessment\n');
fprintf('5. Validate results against manual annotations when possible\n');
fprintf('6. Consider computational efficiency for real-time applications\n');
fprintf('7. Implement quality metrics for system monitoring\n');
fprintf('8. Regular performance evaluation against diverse datasets\n');

% Local functions (moved to end so this listing is a valid MATLAB script)
function skeleton = createSyntheticSkeleton(imageSize)
    % Create synthetic fingerprint skeleton with known minutiae
    skeleton = false(imageSize);
    
    [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
    centerX = imageSize(2) / 2;
    centerY = imageSize(1) / 2;
    
    % Create several ridge lines with minutiae
    for ridge = 1:8
        angle = (ridge - 1) * pi / 4;
        
        % Ridge line parameters
        startX = centerX + 80 * cos(angle);
        startY = centerY + 80 * sin(angle);
        endX = centerX + 120 * cos(angle);
        endY = centerY + 120 * sin(angle);
        
        % Draw ridge line
        numPoints = 50;
        x_coords = linspace(startX, endX, numPoints);
        y_coords = linspace(startY, endY, numPoints);
        
        for i = 1:numPoints
            x = round(x_coords(i));
            y = round(y_coords(i));
            
            if x >= 1 && x <= imageSize(2) && y >= 1 && y <= imageSize(1)
                skeleton(y, x) = true;
                
                % Add some thickness
                for dx = -1:1
                    for dy = -1:1
                        if x+dx >= 1 && x+dx <= imageSize(2) && ...
                           y+dy >= 1 && y+dy <= imageSize(1)
                            if rand() > 0.3 % Random thinning for realism
                                skeleton(y+dy, x+dx) = true;
                            end
                        end
                    end
                end
            end
        end
        
        % Add bifurcation in some ridges
        if mod(ridge, 3) == 0
            bifurcationX = centerX + 100 * cos(angle);
            bifurcationY = centerY + 100 * sin(angle);
            
            % Branch off in another direction
            branchAngle = angle + pi/4;
            for j = 1:20
                x = round(bifurcationX + j * cos(branchAngle));
                y = round(bifurcationY + j * sin(branchAngle));
                
                if x >= 1 && x <= imageSize(2) && y >= 1 && y <= imageSize(1)
                    skeleton(y, x) = true;
                end
            end
        end
    end
end

function minutiae = detectMinutiae(skeletonImg)
    % Detect minutiae points using crossing number analysis
    
    fprintf('Detecting minutiae using crossing number method...\n');
    
    [height, width] = size(skeletonImg);
    minutiae = [];
    
    % Define 8-connected neighborhood offsets
    neighborhoods = [-1,-1; -1,0; -1,1; 0,1; 1,1; 1,0; 1,-1; 0,-1];
    
    % Scan each pixel in the skeleton
    for y = 2:(height-1)
        for x = 2:(width-1)
            if skeletonImg(y, x) % If pixel is part of skeleton
                
                % Extract 8-connected neighborhood
                neighborhood = zeros(1, 8);
                for i = 1:8
                    ny = y + neighborhoods(i, 1);
                    nx = x + neighborhoods(i, 2);
                    neighborhood(i) = skeletonImg(ny, nx);
                end
                
                % Compute crossing number
                crossingNumber = 0;
                for i = 1:8
                    next_i = mod(i, 8) + 1;
                    crossingNumber = crossingNumber + abs(neighborhood(i) - neighborhood(next_i));
                end
                crossingNumber = crossingNumber / 2;
                
                % Classify based on crossing number
                if crossingNumber == 1
                    % Ridge ending
                    minutia = struct();
                    minutia.x = x;
                    minutia.y = y;
                    minutia.type = 'ending';
                    minutia.angle = computeMinutiaAngle(skeletonImg, x, y, 'ending');
                    minutia.quality = assessMinutiaQuality(skeletonImg, x, y);
                    minutiae = [minutiae; minutia];
                    
                elseif crossingNumber == 3
                    % Bifurcation
                    minutia = struct();
                    minutia.x = x;
                    minutia.y = y;
                    minutia.type = 'bifurcation';
                    minutia.angle = computeMinutiaAngle(skeletonImg, x, y, 'bifurcation');
                    minutia.quality = assessMinutiaQuality(skeletonImg, x, y);
                    minutiae = [minutiae; minutia];
                end
            end
        end
    end
    
    fprintf('Found %d minutiae points\n', length(minutiae));
end

function angle = computeMinutiaAngle(skeleton, x, y, type)
    % Compute minutia angle based on local ridge direction
    
    % Define search radius
    radius = 10;
    [height, width] = size(skeleton);
    
    % Find connected ridge pixels in neighborhood
    ridgePixels = [];
    
    for dy = -radius:radius
        for dx = -radius:radius
            nx = x + dx;
            ny = y + dy;
            
            if nx >= 1 && nx <= width && ny >= 1 && ny <= height
                if skeleton(ny, nx) && (dx ~= 0 || dy ~= 0)
                    % Check if pixel is connected to minutia
                    if isConnected(skeleton, x, y, nx, ny, radius)
                        ridgePixels = [ridgePixels; nx, ny];
                    end
                end
            end
        end
    end
    
    if size(ridgePixels, 1) >= 2
        % Compute direction based on ridge pixels
        if strcmp(type, 'ending')
            % For endings, use direction to furthest connected pixel
            distances = sqrt(sum((ridgePixels - [x, y]).^2, 2));
            [~, maxIdx] = max(distances);
            furtherestPixel = ridgePixels(maxIdx, :);
            angle = atan2(furtherestPixel(2) - y, furtherestPixel(1) - x);
            
        else % bifurcation
            % For bifurcations, use principal direction
            centeredPixels = ridgePixels - [x, y];
            if size(centeredPixels, 1) > 2
                [~, ~, V] = svd(centeredPixels');
                principalDirection = V(:, 1);
                angle = atan2(principalDirection(2), principalDirection(1));
            else
                angle = 0;
            end
        end
    else
        angle = 0;
    end
    
    % Normalize angle to [0, 2羽)
    angle = mod(angle, 2*pi);
end

function connected = isConnected(skeleton, x1, y1, x2, y2, maxDistance)
    % Check if two points are connected via skeleton path
    
    % Simple connectivity check using Euclidean distance
    distance = sqrt((x2-x1)^2 + (y2-y1)^2);
    connected = distance <= maxDistance;
    
    % In a more sophisticated implementation, this would use
    % actual path tracing along the skeleton
end

function quality = assessMinutiaQuality(skeleton, x, y)
    % Assess minutia quality based on local characteristics
    
    % Simple quality measure based on local skeleton density
    radius = 5;
    [height, width] = size(skeleton);
    
    localRegion = false(2*radius+1, 2*radius+1);
    
    for dy = -radius:radius
        for dx = -radius:radius
            nx = x + dx;
            ny = y + dy;
            
            if nx >= 1 && nx <= width && ny >= 1 && ny <= height
                localRegion(dy+radius+1, dx+radius+1) = skeleton(ny, nx);
            end
        end
    end
    
    % Quality based on local connectivity and ridge clarity
    skeletonDensity = sum(localRegion(:)) / numel(localRegion);
    quality = min(1.0, skeletonDensity * 10); % Normalize to [0, 1]
end

function filteredMinutiae = filterMinutiae(minutiae, filterOptions)
    % Filter spurious minutiae based on quality and spatial criteria
    
    if nargin < 2
        filterOptions = struct();
        filterOptions.minQuality = 0.3;
        filterOptions.minDistance = 10; % Minimum distance between minutiae
        filterOptions.borderDistance = 15; % Distance from image border
        filterOptions.imageSize = [300, 300]; % Image dimensions
    end
    
    fprintf('Filtering spurious minutiae...\n');
    
    if isempty(minutiae)
        filteredMinutiae = [];
        return;
    end
    
    % Convert struct array to cell array for easier processing
    numMinutiae = length(minutiae);
    validFlags = true(numMinutiae, 1);
    
    % Quality filtering
    for i = 1:numMinutiae
        if minutiae(i).quality < filterOptions.minQuality
            validFlags(i) = false;
        end
    end
    
    fprintf('Quality filtering: %d/%d minutiae retained\n', sum(validFlags), numMinutiae);
    
    % Border distance filtering
    for i = 1:numMinutiae
        if validFlags(i)
            x = minutiae(i).x;
            y = minutiae(i).y;
            
            if x <= filterOptions.borderDistance || ...
               x >= filterOptions.imageSize(2) - filterOptions.borderDistance || ...
               y <= filterOptions.borderDistance || ...
               y >= filterOptions.imageSize(1) - filterOptions.borderDistance
                validFlags(i) = false;
            end
        end
    end
    
    fprintf('Border filtering: %d/%d minutiae retained\n', sum(validFlags), numMinutiae);
    
    % Distance filtering (remove closely spaced minutiae)
    for i = 1:numMinutiae
        if validFlags(i)
            for j = (i+1):numMinutiae
                if validFlags(j)
                    distance = sqrt((minutiae(i).x - minutiae(j).x)^2 + ...
                                  (minutiae(i).y - minutiae(j).y)^2);
                    
                    if distance < filterOptions.minDistance
                        % Keep the higher quality minutia
                        if minutiae(i).quality > minutiae(j).quality
                            validFlags(j) = false;
                        else
                            validFlags(i) = false;
                            break;
                        end
                    end
                end
            end
        end
    end
    
    fprintf('Distance filtering: %d/%d minutiae retained\n', sum(validFlags), numMinutiae);
    
    % Extract filtered minutiae
    filteredMinutiae = minutiae(validFlags);
    
    fprintf('Final minutiae count: %d\n', length(filteredMinutiae));
end

function featureVector = constructFeatureVector(minutiae, method)
    % Construct feature vector from minutiae for matching
    
    if nargin < 2
        method = 'spatial';
    end
    
    fprintf('Constructing feature vector using %s method...\n', method);
    
    if isempty(minutiae)
        featureVector = [];
        return;
    end
    
    switch method
        case 'spatial'
            % Simple spatial coordinate and angle features
            numMinutiae = length(minutiae);
            featureVector = zeros(numMinutiae, 4);
            
            for i = 1:numMinutiae
                featureVector(i, :) = [minutiae(i).x, minutiae(i).y, ...
                                     minutiae(i).angle, minutiae(i).quality];
            end
            
        case 'relative'
            % Relative minutiae features (distances and angles between pairs)
            numMinutiae = length(minutiae);
            numPairs = numMinutiae * (numMinutiae - 1) / 2;
            featureVector = zeros(numPairs, 4);
            
            pairIdx = 1;
            for i = 1:numMinutiae
                for j = (i+1):numMinutiae
                    % Distance between minutiae
                    dx = minutiae(j).x - minutiae(i).x;
                    dy = minutiae(j).y - minutiae(i).y;
                    distance = sqrt(dx^2 + dy^2);
                    
                    % Angle between minutiae
                    angle = atan2(dy, dx);
                    
                    % Angle difference
                    angleDiff = abs(minutiae(i).angle - minutiae(j).angle);
                    angleDiff = min(angleDiff, 2*pi - angleDiff);
                    
                    % Type encoding (ending=1, bifurcation=2)
                    type1 = strcmp(minutiae(i).type, 'bifurcation') + 1;
                    type2 = strcmp(minutiae(j).type, 'bifurcation') + 1;
                    typeCombination = type1 * 10 + type2;
                    
                    featureVector(pairIdx, :) = [distance, angle, angleDiff, typeCombination];
                    pairIdx = pairIdx + 1;
                end
            end
            
        case 'triangular'
            % Triangular minutiae features
            numMinutiae = length(minutiae);
            if numMinutiae < 3
                featureVector = [];
                return;
            end
            
            numTriangles = nchoosek(numMinutiae, 3);
            featureVector = zeros(numTriangles, 6);
            
            triangleIdx = 1;
            for i = 1:numMinutiae
                for j = (i+1):numMinutiae
                    for k = (j+1):numMinutiae
                        % Triangle side lengths
                        d12 = sqrt((minutiae(i).x - minutiae(j).x)^2 + ...
                                 (minutiae(i).y - minutiae(j).y)^2);
                        d13 = sqrt((minutiae(i).x - minutiae(k).x)^2 + ...
                                 (minutiae(i).y - minutiae(k).y)^2);
                        d23 = sqrt((minutiae(j).x - minutiae(k).x)^2 + ...
                                 (minutiae(j).y - minutiae(k).y)^2);
                        
                        % Sort sides for invariance
                        sides = sort([d12, d13, d23]);
                        
                        % Triangle angles
                        cosA = (sides(2)^2 + sides(3)^2 - sides(1)^2) / (2*sides(2)*sides(3));
                        cosB = (sides(1)^2 + sides(3)^2 - sides(2)^2) / (2*sides(1)*sides(3));
                        cosC = (sides(1)^2 + sides(2)^2 - sides(3)^2) / (2*sides(1)*sides(2));
                        
                        angleA = acos(max(-1, min(1, cosA)));
                        angleB = acos(max(-1, min(1, cosB)));
                        angleC = acos(max(-1, min(1, cosC)));
                        
                        featureVector(triangleIdx, :) = [sides, angleA, angleB, angleC];
                        triangleIdx = triangleIdx + 1;
                    end
                end
            end
            
        otherwise
            error('Unknown feature construction method: %s', method);
    end
    
    fprintf('Feature vector constructed: %dx%d matrix\n', size(featureVector, 1), size(featureVector, 2));
end

function visualizeMinutiae(image, minutiae, title_str)
    % Visualize detected minutiae on fingerprint image
    
    figure;
    if size(image, 3) == 1
        imshow(image, []);
    else
        imshow(image);
    end
    
    hold on;
    
    if ~isempty(minutiae)
        % Plot minutiae points
        endings = [];
        bifurcations = [];
        
        for i = 1:length(minutiae)
            if strcmp(minutiae(i).type, 'ending')
                endings = [endings; minutiae(i).x, minutiae(i).y];
            else
                bifurcations = [bifurcations; minutiae(i).x, minutiae(i).y];
            end
            
            % Draw direction arrow
            arrowLength = 10;
            dx = arrowLength * cos(minutiae(i).angle);
            dy = arrowLength * sin(minutiae(i).angle);
            
            quiver(minutiae(i).x, minutiae(i).y, dx, dy, 0, 'g', ...
                   'LineWidth', 2, 'MaxHeadSize', 0.5);
        end
        
        % Plot different minutiae types with different colors
        if ~isempty(endings)
            plot(endings(:, 1), endings(:, 2), 'ro', 'MarkerSize', 8, 'LineWidth', 2);
        end
        
        if ~isempty(bifurcations)
            plot(bifurcations(:, 1), bifurcations(:, 2), 'bs', 'MarkerSize', 8, 'LineWidth', 2);
        end
        
        % Create legend
        legend_entries = {};
        if ~isempty(endings)
            legend_entries{end+1} = 'Ridge Endings';
        end
        if ~isempty(bifurcations)
            legend_entries{end+1} = 'Bifurcations';
        end
        legend_entries{end+1} = 'Directions';
        
        legend(legend_entries, 'Location', 'best');
    end
    
    hold off;
    title(title_str);
end

function analysis = analyzeMinutiaeStatistics(minutiae)
    % Comprehensive statistical analysis of detected minutiae
    
    analysis = struct();
    
    if isempty(minutiae)
        analysis.totalCount = 0;
        return;
    end
    
    % Basic counts
    endings = sum(strcmp({minutiae.type}, 'ending'));
    bifurcations = sum(strcmp({minutiae.type}, 'bifurcation'));
    
    analysis.totalCount = length(minutiae);
    analysis.endingCount = endings;
    analysis.bifurcationCount = bifurcations;
    analysis.endingRatio = endings / length(minutiae);
    
    % Quality statistics
    qualities = [minutiae.quality];
    analysis.meanQuality = mean(qualities);
    analysis.stdQuality = std(qualities);
    analysis.minQuality = min(qualities);
    analysis.maxQuality = max(qualities);
    
    % Spatial distribution
    x_coords = [minutiae.x];
    y_coords = [minutiae.y];
    
    analysis.centroidX = mean(x_coords);
    analysis.centroidY = mean(y_coords);
    analysis.spatialSpread = std(sqrt((x_coords - analysis.centroidX).^2 + ...
                                    (y_coords - analysis.centroidY).^2));
    
    % Angular distribution
    angles = [minutiae.angle];
    analysis.meanAngle = atan2(mean(sin(angles)), mean(cos(angles)));
    analysis.angularVariance = 1 - sqrt(mean(cos(angles))^2 + mean(sin(angles))^2);
    
    % Density estimation
    if length(minutiae) > 1
        distances = pdist([x_coords', y_coords']);
        analysis.meanNearestNeighborDistance = mean(distances);
        analysis.minDistance = min(distances);
    else
        analysis.meanNearestNeighborDistance = NaN;
        analysis.minDistance = NaN;
    end
    
    % Print analysis
    fprintf('\nMinutiae Statistical Analysis:\n');
    fprintf('=============================\n');
    fprintf('Total minutiae: %d\n', analysis.totalCount);
    fprintf('  Ridge endings: %d (%.1f%%)\n', analysis.endingCount, analysis.endingRatio*100);
    fprintf('  Bifurcations: %d (%.1f%%)\n', analysis.bifurcationCount, (1-analysis.endingRatio)*100);
    fprintf('Quality statistics:\n');
    fprintf('  Mean quality: %.3f ㊣ %.3f\n', analysis.meanQuality, analysis.stdQuality);
    fprintf('  Quality range: [%.3f, %.3f]\n', analysis.minQuality, analysis.maxQuality);
    fprintf('Spatial distribution:\n');
    fprintf('  Centroid: (%.1f, %.1f)\n', analysis.centroidX, analysis.centroidY);
    fprintf('  Spatial spread: %.1f pixels\n', analysis.spatialSpread);
    fprintf('  Mean NN distance: %.1f pixels\n', analysis.meanNearestNeighborDistance);
    fprintf('Angular characteristics:\n');
    fprintf('  Mean direction: %.1f degrees\n', rad2deg(analysis.meanAngle));
    fprintf('  Angular variance: %.3f\n', analysis.angularVariance);
end

function featureQuality = assessFeatureQuality(features, minutiae)
    % Assess the quality of extracted features for matching
    
    featureQuality = struct();
    
    if isempty(features) || isempty(minutiae)
        featureQuality.overall = 0;
        return;
    end
    
    % Number of features
    featureQuality.featureCount = size(features, 1);
    
    % Feature diversity (variance in feature values)
    featureQuality.featureVariance = mean(var(features, 0, 1));
    
    % Minutiae quality contribution
    qualities = [minutiae.quality];
    featureQuality.avgMinutiaQuality = mean(qualities);
    
    % Overall quality score
    countScore = min(1, featureQuality.featureCount / 20); % Normalize by target count
    diversityScore = min(1, featureQuality.featureVariance / 100); % Normalize
    qualityScore = featureQuality.avgMinutiaQuality;
    
    featureQuality.overall = (countScore + diversityScore + qualityScore) / 3;
    
    fprintf('\nFeature Quality Assessment:\n');
    fprintf('==========================\n');
    fprintf('Feature count: %d\n', featureQuality.featureCount);
    fprintf('Feature diversity: %.3f\n', featureQuality.featureVariance);
    fprintf('Average minutia quality: %.3f\n', featureQuality.avgMinutiaQuality);
    fprintf('Overall feature quality: %.3f\n', featureQuality.overall);
end
