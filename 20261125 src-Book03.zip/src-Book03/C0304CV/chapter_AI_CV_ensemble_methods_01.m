%% chapter_AI_CV_ensemble_methods_01.m
% Ensemble Methods and Random Forest Implementation
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_ensemble_methods_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Generate more complex dataset for ensemble demonstration
num_samples = 1000;
num_features = 10;
num_classes = 4;

% Create synthetic image feature dataset
% Features represent different image characteristics
rng(42); % For reproducibility

% Generate features with different patterns for each class
features = zeros(num_samples, num_features);
labels = zeros(num_samples, 1);

samples_per_class = num_samples / num_classes;

for class = 1:num_classes
    start_idx = (class-1) * samples_per_class + 1;
    end_idx = class * samples_per_class;
    
    % Different feature patterns for each class
    if class == 1
        % Class 1: High values in first half of features
        features(start_idx:end_idx, 1:5) = 0.8 + 0.2*randn(samples_per_class, 5);
        features(start_idx:end_idx, 6:10) = 0.2 + 0.1*randn(samples_per_class, 5);
    elseif class == 2
        % Class 2: High values in second half of features
        features(start_idx:end_idx, 1:5) = 0.2 + 0.1*randn(samples_per_class, 5);
        features(start_idx:end_idx, 6:10) = 0.8 + 0.2*randn(samples_per_class, 5);
    elseif class == 3
        % Class 3: High values in odd-indexed features
        features(start_idx:end_idx, 1:2:end) = 0.7 + 0.2*randn(samples_per_class, 5);
        features(start_idx:end_idx, 2:2:end) = 0.3 + 0.1*randn(samples_per_class, 5);
    else
        % Class 4: Mixed pattern
        features(start_idx:end_idx, :) = 0.5 + 0.3*randn(samples_per_class, num_features);
    end
    
    labels(start_idx:end_idx) = class;
end

% Add some noise to make the problem more challenging
features = features + 0.1*randn(size(features));

% Split into training and testing sets
cv_partition = cvpartition(labels, 'HoldOut', 0.3);
train_idx = training(cv_partition);
test_idx = test(cv_partition);

X_train = features(train_idx, :);
y_train = labels(train_idx);
X_test = features(test_idx, :);
y_test = labels(test_idx);

% Single Decision Tree (baseline)
single_tree = fitctree(X_train, y_train);
predictions_single = predict(single_tree, X_test);
accuracy_single = sum(y_test == predictions_single) / length(y_test);

% Bagging with decision trees
num_trees_bagging = 50;
bagged_trees = TreeBagger(num_trees_bagging, X_train, y_train, ...
                         'Method', 'classification', ...
                         'OOBPrediction', 'on');

predictions_bagging = predict(bagged_trees, X_test);
predictions_bagging = str2double(predictions_bagging);
accuracy_bagging = sum(y_test == predictions_bagging) / length(y_test);

% Random Forest with different parameters
num_trees_rf = [10, 50, 100, 200];
rf_accuracies = zeros(size(num_trees_rf));

for i = 1:length(num_trees_rf)
    rf_model = TreeBagger(num_trees_rf(i), X_train, y_train, ...
                         'Method', 'classification', ...
                         'NumPredictorsToSample', 'sqrt', ...  % sqrt(num_features)
                         'OOBPrediction', 'on');
    
    predictions_rf = predict(rf_model, X_test);
    predictions_rf = str2double(predictions_rf);
    rf_accuracies(i) = sum(y_test == predictions_rf) / length(y_test);
end

% Best Random Forest model
best_rf_idx = find(rf_accuracies == max(rf_accuracies), 1);
best_num_trees = num_trees_rf(best_rf_idx);

rf_best = TreeBagger(best_num_trees, X_train, y_train, ...
                    'Method', 'classification', ...
                    'NumPredictorsToSample', 'sqrt', ...
                    'OOBPrediction', 'on');

predictions_rf_best = predict(rf_best, X_test);
predictions_rf_best = str2double(predictions_rf_best);

% AdaBoost ensemble
ada_boost = fitcensemble(X_train, y_train, 'Method', 'AdaBoostM1', ...
                        'NumLearningCycles', 100);
predictions_adaboost = predict(ada_boost, X_test);
accuracy_adaboost = sum(y_test == predictions_adaboost) / length(y_test);

% Gradient Boosting
gradient_boost = fitcensemble(X_train, y_train, 'Method', 'LogitBoost', ...
                             'NumLearningCycles', 100);
predictions_gradboost = predict(gradient_boost, X_test);
accuracy_gradboost = sum(y_test == predictions_gradboost) / length(y_test);

% Feature importance analysis
feature_importance_rf = rf_best.OOBPermutedPredictorDeltaError;

% Out-of-bag error analysis
oob_error_rf = oobError(rf_best);
oob_error_bagging = oobError(bagged_trees);

% Ensemble diversity analysis

diversity_rf = calculateEnsembleDiversity(rf_best, X_test);
diversity_bagging = calculateEnsembleDiversity(bagged_trees, X_test);

% Prediction confidence analysis

confidence_rf = calculatePredictionConfidence(rf_best, X_test);

% Learning curve analysis

tree_counts_curve = 5:10:105;
[train_errors_lc, test_errors_lc] = computeLearningCurve(X_train, y_train, X_test, y_test, tree_counts_curve);

% Ensemble comparison with different base learners
svm_ensemble = fitcensemble(X_train, y_train, 'Method', 'Bag', ...
                           'Learners', 'svm', 'NumLearningCycles', 50);
predictions_svm_ensemble = predict(svm_ensemble, X_test);
accuracy_svm_ensemble = sum(y_test == predictions_svm_ensemble) / length(y_test);

% Voting classifier (manual implementation)

% Create diverse base models for voting
base_models = {single_tree, rf_best, ada_boost};
voting_predictions = votingClassifier(base_models, X_test);
accuracy_voting = sum(y_test == voting_predictions) / length(y_test);

% Display comprehensive results
figure;

% Individual vs ensemble performance
subplot(2,4,1);
methods = {'Single Tree', 'Bagging', 'Random Forest', 'AdaBoost', 'GradBoost', 'SVM Ensemble', 'Voting'};
accuracies = [accuracy_single, accuracy_bagging, max(rf_accuracies), ...
              accuracy_adaboost, accuracy_gradboost, accuracy_svm_ensemble, accuracy_voting];
bar(accuracies);
set(gca, 'XTickLabel', methods, 'XTickLabelRotation', 45);
title('Model Performance Comparison');
ylabel('Accuracy');
ylim([0, 1]);

% Random Forest: Number of trees vs accuracy
subplot(2,4,2);
plot(num_trees_rf, rf_accuracies, 'b-o', 'LineWidth', 2, 'MarkerSize', 6);
xlabel('Number of Trees');
ylabel('Accuracy');
title('Random Forest: Trees vs Performance');
grid on;

% Feature importance
subplot(2,4,3);
bar(feature_importance_rf);
xlabel('Feature Index');
ylabel('Importance Score');
title('Feature Importance (Random Forest)');

% Out-of-bag error progression
subplot(2,4,4);
plot(oob_error_rf, 'r-', 'LineWidth', 2);
xlabel('Number of Trees');
ylabel('Out-of-Bag Error');
title('OOB Error vs Trees');
grid on;

% Learning curves
subplot(2,4,5);
plot(tree_counts_curve, train_errors_lc, 'b-', 'LineWidth', 2, 'DisplayName', 'Training Error');
hold on;
plot(tree_counts_curve, test_errors_lc, 'r-', 'LineWidth', 2, 'DisplayName', 'Test Error');
xlabel('Number of Trees');
ylabel('Error Rate');
title('Learning Curves');
legend('show');
grid on;

% Prediction confidence distribution
subplot(2,4,6);
histogram(confidence_rf, 20);
xlabel('Prediction Confidence');
ylabel('Frequency');
title('Confidence Distribution');

% Ensemble diversity comparison
subplot(2,4,7);
diversity_methods = {'Random Forest', 'Bagging'};
diversity_scores = [diversity_rf, diversity_bagging];
bar(diversity_scores);
set(gca, 'XTickLabel', diversity_methods);
title('Ensemble Diversity');
ylabel('Diversity Score');

% Error correlation analysis
subplot(2,4,8);
errors_single = (y_test ~= predictions_single);
errors_rf = (y_test ~= predictions_rf_best);
error_correlation = corrcoef(double(errors_single), double(errors_rf));
imagesc(error_correlation);
colorbar;
title('Error Correlation Matrix');
set(gca, 'XTickLabel', {'Single', 'RF'}, 'YTickLabel', {'Single', 'RF'});

% Print comprehensive analysis
fprintf('Ensemble Methods Performance Analysis:\n');
fprintf('Dataset: %d samples, %d features, %d classes\n', num_samples, num_features, num_classes);
fprintf('Training: %d samples, Testing: %d samples\n', sum(train_idx), sum(test_idx));

fprintf('\nModel Accuracies:\n');
fprintf('Single Decision Tree: %.3f\n', accuracy_single);
fprintf('Bagging (50 trees): %.3f\n', accuracy_bagging);
fprintf('Random Forest (%d trees): %.3f\n', best_num_trees, max(rf_accuracies));
fprintf('AdaBoost: %.3f\n', accuracy_adaboost);
fprintf('Gradient Boosting: %.3f\n', accuracy_gradboost);
fprintf('SVM Ensemble: %.3f\n', accuracy_svm_ensemble);
fprintf('Voting Classifier: %.3f\n', accuracy_voting);

fprintf('\nEnsemble Analysis:\n');
fprintf('Random Forest diversity: %.3f\n', diversity_rf);
fprintf('Bagging diversity: %.3f\n', diversity_bagging);
fprintf('Final OOB error (RF): %.3f\n', oob_error_rf(end));

fprintf('\nTop 3 Important Features (Random Forest):\n');
[sorted_importance, sort_idx] = sort(feature_importance_rf, 'descend');
for i = 1:min(3, length(sorted_importance))
    fprintf('Feature %d: %.4f\n', sort_idx(i), sorted_importance(i));
end

fprintf('\nBest Random Forest Configuration:\n');
fprintf('Number of trees: %d\n', best_num_trees);
fprintf('Features per split: sqrt(%d) = %d\n', num_features, floor(sqrt(num_features)));
fprintf('Performance improvement over single tree: %.3f\n', max(rf_accuracies) - accuracy_single);

% Local functions (moved to end so this listing is a valid MATLAB script)
function diversity_score = calculateEnsembleDiversity(ensemble_model, X)
    num_trees = ensemble_model.NumTrees;
    num_samples = size(X, 1);
    
    % Get predictions from individual trees
    tree_predictions = zeros(num_samples, num_trees);
    
    for i = 1:num_trees
        tree_pred = predict(ensemble_model.Trees{i}, X);
        if iscell(tree_pred)
            tree_pred = str2double(tree_pred);
        end
        tree_predictions(:, i) = tree_pred;
    end
    
    % Calculate pairwise disagreement
    disagreements = 0;
    total_pairs = 0;
    
    for i = 1:num_trees
        for j = i+1:num_trees
            disagreement = sum(tree_predictions(:, i) ~= tree_predictions(:, j));
            disagreements = disagreements + disagreement;
            total_pairs = total_pairs + 1;
        end
    end
    
    diversity_score = disagreements / (total_pairs * num_samples);
end

function confidence_scores = calculatePredictionConfidence(ensemble_model, X)
    [~, prediction_scores] = predict(ensemble_model, X);
    
    if iscell(prediction_scores)
        % Handle TreeBagger output
        prediction_scores = cell2mat(prediction_scores);
    end
    
    % Confidence as maximum probability
    confidence_scores = max(prediction_scores, [], 2);
end

function [train_errors, test_errors] = computeLearningCurve(X_train, y_train, X_test, y_test, tree_counts)
    train_errors = zeros(size(tree_counts));
    test_errors = zeros(size(tree_counts));
    
    for i = 1:length(tree_counts)
        model = TreeBagger(tree_counts(i), X_train, y_train, ...
                          'Method', 'classification', ...
                          'NumPredictorsToSample', 'sqrt');
        
        % Training error
        train_pred = predict(model, X_train);
        train_pred = str2double(train_pred);
        train_errors(i) = 1 - sum(y_train == train_pred) / length(y_train);
        
        % Test error
        test_pred = predict(model, X_test);
        test_pred = str2double(test_pred);
        test_errors(i) = 1 - sum(y_test == test_pred) / length(y_test);
    end
end

function ensemble_predictions = votingClassifier(models, X)
    num_models = length(models);
    num_samples = size(X, 1);
    
    all_predictions = zeros(num_samples, num_models);
    
    for i = 1:num_models
        pred = predict(models{i}, X);
        if iscell(pred)
            pred = str2double(pred);
        end
        all_predictions(:, i) = pred;
    end
    
    % Majority voting
    ensemble_predictions = mode(all_predictions, 2);
end
