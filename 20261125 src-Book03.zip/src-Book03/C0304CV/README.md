# C0304CV - Supplementary MATLAB Source Code

| Field | Value |
| --- | --- |
| Book | MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications |
| Chapter | Computer Vision and Image Processing |
| Package version | 1.0.1 |
| Release stamp | 2026-11-10 |
| Source manuscript | `P03-20261111` |
| Source chapter file | `P0302main/C0304CV/` (included by `P03_20261005.tex`) |
| Code files | 59 (59 `.m`, 0 `.f`) |
| Code lines relocated | 32,310 |

## Why this folder exists

The editor reported that a large volume of programming code was present in the
manuscript and requested that it be moved to a professional repository with the
links supplied as supplementary material. The printed book is subject to a
length target below 1100 pages and to the Springer hard-copy limit of fewer
than 950 print pages. Accordingly, every `lstlisting` (and every MATLAB
`verbatim`) environment in the chapter has been removed from the main body and
deposited here. Only the filename, the listing caption and a reference to this
folder remain in the printed text.

## Naming convention

A file is named after the `label` of the listing it came from:

```latex
\begin{lstlisting}[..., caption={Basic matrix operations ...},
                     label={chapter_Introduction_example_01}]
```

is saved as `chapter_Introduction_example_01.m`.

- Listings without a `label` receive a generated name `C0304CV_code_NNN.m`.
- Code held in a `verbatim` environment receives `C0304CV_verbatim_NN.m`
  (or `.f` for the single illustrative Fortran 77 block).
- Where two listings shared the same label, the later file carries a numeric
  suffix (`_02`, `_03`, ...) so nothing is overwritten. This is recorded in
  the table below.

Each file begins with a header comment giving the caption, the original label,
this folder, the version stamp and the public repository URL.

## Finding a file from the book

The main text now shows a one-line note of the form:

> **Source code 3.4:** `chapter_ICT_example_01.m` - *caption*
> (supplementary material: `src-Book03/C0304CV/`)

The original listing numbers and all `\ref{...}` cross-references are
unchanged, so the in-text reference maps directly to a filename.

## Repository

```
https://github.com/LeoYiChen/MATLABBook03
```

Clone or download `src-Book03/` from this public repository, or use the
Springer supplementary archive. The same address is printed in the preface of
the book. Keep the `src-Book03/` folder name so that the in-text
`src-Book03/C0304CV/` paths resolve.

## Companion documents

- `VERSION.md` - version, release stamp and release notes
- `USER-GUIDE.md` - how to download, locate and run the code
- `MANIFEST.sha256` - SHA-256 ledger of every file in this folder

## Files

| Filename | Source listing label | Caption |
| --- | --- | --- |
| `chapter_AI_CV_adaptive_filtering_01.m` | `chapter_AI_CV_adaptive_filtering_01` | Adaptive Filtering Techniques Demonstration |
| `chapter_AI_CV_automated_inspection_01.m` | `chapter_AI_CV_automated_inspection_01` | Comprehensive Automated Visual Inspection System for Manufacturing Quality Control |
| `chapter_AI_CV_basic_filtering_01.m` | `chapter_AI_CV_basic_filtering_01` | Gaussian and Median Filtering Comparison |
| `chapter_AI_CV_benchmarking_01.m` | `chapter_AI_CV_benchmarking_01` | Comprehensive Benchmarking and Comparative Analysis Framework |
| `chapter_AI_CV_binary_descriptors_01.m` | `chapter_AI_CV_binary_descriptors_01` | Binary Descriptors and ORB Implementation |
| `chapter_AI_CV_blob_detection_01.m` | `chapter_AI_CV_blob_detection_01` | Scale-Space Blob Detection Implementation |
| `chapter_AI_CV_bundle_adjustment_01.m` | `chapter_AI_CV_bundle_adjustment_01` | Bundle Adjustment Implementation and 3D Reconstruction Optimisation |
| `chapter_AI_CV_cnn_architecture_01.m` | `chapter_AI_CV_cnn_architecture_01` | Comprehensive CNN Architecture Implementation and Analysis |
| `chapter_AI_CV_cnn_depth_estimation_01.m` | `chapter_AI_CV_cnn_depth_estimation_01` | CNN-based Monocular Depth Estimation Implementation and Analysis |
| `chapter_AI_CV_code_optimisation_01.m` | `chapter_AI_CV_code_optimisation_01` | Comprehensive Code Optimisation Framework for Computer Vision Applications |
| `chapter_AI_CV_colour_transform_01.m` | `chapter_AI_CV_colour_transform_01` | Comprehensive Colour Space Transformation Example |
| `chapter_AI_CV_deep_face_recognition_01.m` | `chapter_AI_CV_deep_face_recognition_01` | Deep Learning Face Recognition System Implementation |
| `chapter_AI_CV_defect_classification_01.m` | `chapter_AI_CV_defect_classification_01` | Advanced Defect Detection and Classification System for Industrial Quality Control |
| `chapter_AI_CV_deformable_templates_01.m` | `chapter_AI_CV_deformable_templates_01` | Deformable Template Matching Implementation |
| `chapter_AI_CV_disparity_computation_01.m` | `chapter_AI_CV_disparity_computation_01` | Advanced Disparity Map Computation and Analysis |
| `chapter_AI_CV_edge_computing_01.m` | `chapter_AI_CV_edge_computing_01` | Comprehensive Edge Computing Framework for Computer Vision |
| `chapter_AI_CV_edge_detection_01.m` | `chapter_AI_CV_edge_detection_01` | Comprehensive Edge Detection Methods Comparison |
| `chapter_AI_CV_ensemble_methods_01.m` | `chapter_AI_CV_ensemble_methods_01` | Ensemble Methods and Random Forest Implementation |
| `chapter_AI_CV_explainable_ai_01.m` | `chapter_AI_CV_explainable_ai_01` | Comprehensive Explainable AI Framework for Computer Vision Systems |
| `chapter_AI_CV_face_detection_01.m` | `chapter_AI_CV_face_detection_01` | Advanced Face Detection and Alignment System |
| `chapter_AI_CV_feature_extraction_01.m` | `chapter_AI_CV_feature_extraction_01` | Advanced Feature Extraction Techniques and Multi-layer Analysis |
| `chapter_AI_CV_feature_tracking_01.m` | `chapter_AI_CV_feature_tracking_01` | Advanced Feature Tracking and Correspondence Analysis for Structure from Motion |
| `chapter_AI_CV_fine_tuning_01.m` | `chapter_AI_CV_fine_tuning_01` | Comprehensive Transfer Learning and Fine-tuning Implementation |
| `chapter_AI_CV_fingerprint_matching_01.m` | `chapter_AI_CV_fingerprint_matching_01` | Advanced Fingerprint Matching and Verification System |
| `chapter_AI_CV_fingerprint_preprocessing_01.m` | `chapter_AI_CV_fingerprint_preprocessing_01` | Comprehensive Fingerprint Image Preprocessing Pipeline |
| `chapter_AI_CV_format_comparison_01.m` | `chapter_AI_CV_format_comparison_01` | Image Format Comparison and Quality Assessment |
| `chapter_AI_CV_frequency_enhancement_01.m` | `chapter_AI_CV_frequency_enhancement_01` | Frequency Domain Enhancement Techniques |
| `chapter_AI_CV_gan_applications_01.m` | `chapter_AI_CV_gan_applications_01` | GAN Applications: Image Translation and Enhancement |
| `chapter_AI_CV_gan_implementation_01.m` | `chapter_AI_CV_gan_implementation_01` | GAN Implementation with Comprehensive Training Analysis |
| `chapter_AI_CV_gpu_acceleration_01.m` | `chapter_AI_CV_gpu_acceleration_01` | Comprehensive Parallel Computing and GPU Acceleration Framework |
| `chapter_AI_CV_harris_corner_01.m` | `chapter_AI_CV_harris_corner_01` | Comprehensive Harris Corner Detection Implementation |
| `chapter_AI_CV_histogram_enhancement_01.m` | `chapter_AI_CV_histogram_enhancement_01` | Comprehensive Histogram-Based Enhancement Techniques |
| `chapter_AI_CV_industry40_integration_01.m` | `chapter_AI_CV_industry40_integration_01` | Industry 4.0 Computer Vision Integration and Digital Twin Implementation |
| `chapter_AI_CV_kalman_tracking_01.m` | `chapter_AI_CV_kalman_tracking_01` | Kalman Filter Implementation for Object Tracking |
| `chapter_AI_CV_lab1_complete.m` | `chapter_AI_CV_lab1_complete` | Advanced Performance Evaluation Framework Implementation. |
| `chapter_AI_CV_lab1_cv_syntax.m` | `chapter_AI_CV_lab1_cv_syntax` | Cross-validation framework implementation syntax. |
| `chapter_AI_CV_lab2_complete.m` | `chapter_AI_CV_lab2_complete` | Real-time Image Processing Optimisation Framework. |
| `chapter_AI_CV_lab2_gpu_syntax.m` | `chapter_AI_CV_lab2_gpu_syntax` | GPU acceleration syntax in MATLAB. |
| `chapter_AI_CV_lab3_complete.m` | `chapter_AI_CV_lab3_complete` | Quantum-Inspired Computer Vision Framework. |
| `chapter_AI_CV_lab3_quantum_syntax.m` | `chapter_AI_CV_lab3_quantum_syntax` | Quantum state representation syntax. |
| `chapter_AI_CV_lab4_complete.m` | `chapter_AI_CV_lab4_complete` | Comprehensive Neuromorphic Vision System Implementation. |
| `chapter_AI_CV_lab4_snn_syntax.m` | `chapter_AI_CV_lab4_snn_syntax` | Spiking neural network syntax. |
| `chapter_AI_CV_lab5_complete.m` | `chapter_AI_CV_lab5_complete` | Comprehensive Explainable AI Framework Implementation. |
| `chapter_AI_CV_lab5_grad_syntax.m` | `chapter_AI_CV_lab5_grad_syntax` | Gradient-based explanation syntax. |
| `chapter_AI_CV_laplacian_detection_01.m` | `chapter_AI_CV_laplacian_detection_01` | Laplacian and Zero-crossing Edge Detection |
| `chapter_AI_CV_lesion_detection_01.m` | `chapter_AI_CV_lesion_detection_01` | Automated Lesion Detection and Segmentation System |
| `chapter_AI_CV_minutiae_detection_01.m` | `chapter_AI_CV_minutiae_detection_01` | Advanced Minutiae Detection and Feature Extraction System |
| `chapter_AI_CV_modern_cnns_01.m` | `chapter_AI_CV_modern_cnns_01` | Modern CNN Architectures Implementation and Comparison |
| `chapter_AI_CV_multimodal_medical_01.m` | `chapter_AI_CV_multimodal_medical_01` | Multi-modal Medical Image Processing and Analysis System |
| `chapter_AI_CV_neuromorphic_simulation_01.m` | `chapter_AI_CV_neuromorphic_simulation_01` | Neuromorphic Vision System Simulation and Event-Driven Processing Framework |
| `chapter_AI_CV_particle_filter_01.m` | `chapter_AI_CV_particle_filter_01` | Particle Filter Implementation for Object Tracking |
| `chapter_AI_CV_performance_evaluation_01.m` | `chapter_AI_CV_performance_evaluation_01` | Comprehensive Performance Evaluation Framework for Computer Vision Systems |
| `chapter_AI_CV_physics_depth_01.m` | `chapter_AI_CV_physics_depth_01` | Physics-based Depth Estimation: Defocus and Photometric Methods |
| `chapter_AI_CV_quantum_simulation_01.m` | `chapter_AI_CV_quantum_simulation_01` | Quantum-Inspired Computer Vision Algorithms and Simulation Framework |
| `chapter_AI_CV_sift_surf_01.m` | `chapter_AI_CV_sift_surf_01` | SIFT and SURF Feature Descriptor Implementation and Comparison |
| `chapter_AI_CV_statistical_validation_01.m` | `chapter_AI_CV_statistical_validation_01` | Advanced Cross-Validation and Statistical Testing Framework |
| `chapter_AI_CV_stereo_calibration_01.m` | `chapter_AI_CV_stereo_calibration_01` | Comprehensive Stereo Vision Calibration and Rectification System |
| `chapter_AI_CV_svm_classification_01.m` | `chapter_AI_CV_svm_classification_01` | Support Vector Machine Classification for Object Recognition |
| `chapter_AI_CV_template_matching_01.m` | `chapter_AI_CV_template_matching_01` | Comprehensive Template Matching Implementation |
