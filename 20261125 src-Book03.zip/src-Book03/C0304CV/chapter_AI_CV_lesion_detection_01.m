%% chapter_AI_CV_lesion_detection_01.m
% Automated Lesion Detection and Segmentation System
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_lesion_detection_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Automated Lesion Detection and Segmentation System
fprintf('Automated Lesion Detection and Segmentation System\n');
fprintf('=================================================\n');

% Create synthetic medical image with lesions for demonstration
[medicalImage, lesionMask, lesionInfo] = createMedicalImageWithLesions();


% 1. Preprocessing for Lesion Detection

% 2. Candidate Lesion Detection





% 3. Feature Extraction for Candidate Classification


% 4. Lesion Classification and Segmentation






% 5. Comprehensive Lesion Analysis System


% Test the lesion detection system
fprintf('\nTesting automated lesion detection system...\n');

% Preprocess the medical image
preprocessedImage = preprocessMedicalImage(medicalImage);

% Perform comprehensive analysis
results = performLesionAnalysis(medicalImage, lesionMask);

% Visualise results
figure;

% Original image
subplot(2, 4, 1);
imshow(medicalImage, []);
title('Original Medical Image');

% Ground truth
subplot(2, 4, 2);
imshow(label2rgb(lesionMask, 'jet', 'k'));
title('Ground Truth Lesions');

% Preprocessed image
subplot(2, 4, 3);
imshow(preprocessedImage, []);
title('Preprocessed Image');

% Detected candidates
subplot(2, 4, 4);
imshow(medicalImage, []);
hold on;
for i = 1:length(results.candidates)
    candidate = results.candidates(i);
    if results.classifications(i).isLesion
        circle = viscircles([candidate.x, candidate.y], candidate.radius, 'Color', 'r', 'LineWidth', 2);
    else
        circle = viscircles([candidate.x, candidate.y], candidate.radius, 'Color', 'b', 'LineWidth', 1);
    end
end
hold off;
title('Detected Candidates');

% Classification results
subplot(2, 4, 5);
scores = [results.classifications.score];
histogram(scores, 10);
xlabel('Classification Score');
ylabel('Frequency');
title('Classification Scores');

% Segmentation overlay
subplot(2, 4, 6);
imshow(medicalImage, []);
hold on;
for i = 1:length(results.segmentations)
    if ~isempty(results.segmentations{i})
        seg = results.segmentations{i};
        if ~isempty(seg.contour)
            plot(seg.contour(:, 2) + seg.x_offset, seg.contour(:, 1) + seg.y_offset, 'r-', 'LineWidth', 2);
        end
    end
end
hold off;
title('Segmentation Results');

% Performance metrics
subplot(2, 4, 7);
metrics = [results.evaluation.precision, results.evaluation.recall, results.evaluation.f1Score];
bar(metrics);
set(gca, 'XTickLabel', {'Precision', 'Recall', 'F1-Score'});
title('Performance Metrics');
ylabel('Score');

% Detection summary
subplot(2, 4, 8);
counts = [results.evaluation.truePositives, results.evaluation.falsePositives, results.evaluation.falseNegatives];
bar(counts);
set(gca, 'XTickLabel', {'TP', 'FP', 'FN'});
title('Detection Counts');
ylabel('Count');

sgtitle('Automated Lesion Detection and Segmentation Results');

% Display detailed results
fprintf('\nDetailed Analysis Results:\n');
fprintf('=========================\n');
fprintf('Total candidates detected: %d\n', length(results.candidates));
fprintf('Lesions identified: %d\n', sum([results.classifications.isLesion]));
fprintf('Ground truth lesions: %d\n', results.evaluation.groundTruthCount);

fprintf('\nPerformance Metrics:\n');
fprintf('  Precision: %.3f\n', results.evaluation.precision);
fprintf('  Recall: %.3f\n', results.evaluation.recall);
fprintf('  F1-Score: %.3f\n', results.evaluation.f1Score);

fprintf('\nLesion Classification Summary:\n');
lesionTypes = {results.classifications.type};
uniqueTypes = unique(lesionTypes);
for i = 1:length(uniqueTypes)
    count = sum(strcmp(lesionTypes, uniqueTypes{i}));
    fprintf('  %s: %d lesions\n', uniqueTypes{i}, count);
end

% Technical summary
fprintf('\nTechnical Implementation Summary:\n');
fprintf('================================\n');
fprintf('1. Multi-scale blob detection for candidate identification\n');
fprintf('2. Comprehensive feature extraction (intensity, shape, texture)\n');
fprintf('3. Rule-based classification (can be replaced with ML models)\n');
fprintf('4. Active contour segmentation for precise delineation\n');
fprintf('5. Quantitative evaluation against ground truth\n');

fprintf('\nClinical Applications:\n');
fprintf('=====================\n');
fprintf(' Lung nodule detection in chest CT\n');
fprintf(' Breast lesion detection in mammography\n');
fprintf(' Brain tumour detection in MRI\n');
fprintf(' Liver lesion detection in CT/MRI\n');
fprintf(' Skin lesion analysis in dermoscopy\n');

fprintf('\nFuture Improvements:\n');
fprintf('===================\n');
fprintf(' Deep learning-based detection and classification\n');
fprintf(' Multi-modal lesion analysis\n');
fprintf(' Temporal analysis for lesion growth tracking\n');
fprintf(' Uncertainty quantification for clinical decision support\n');
fprintf(' Integration with radiomics analysis\n');

% Local functions (moved to end so this listing is a valid MATLAB script)
function [image, mask, info] = createMedicalImageWithLesions()
    % Create synthetic medical image with various types of lesions
    
    fprintf('Creating synthetic medical image with lesions...\n');
    
    imageSize = [512, 512];
    image = zeros(imageSize);
    mask = zeros(imageSize);
    
    % Create background tissue
    [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
    
    % Add realistic background texture
    backgroundIntensity = 100;
    backgroundTexture = 20 * (sin(X/20) + cos(Y/15)) + 10 * randn(imageSize);
    image = backgroundIntensity + backgroundTexture;
    
    % Define different types of lesions
    lesionTypes = {'solid_nodule', 'ground_glass', 'cavity', 'mass'};
    numLesions = 8;
    
    info = struct();
    info.lesions = [];
    
    for i = 1:numLesions
        lesionType = lesionTypes{randi(length(lesionTypes))};
        
        % Random lesion parameters
        centerX = 50 + rand() * (imageSize(2) - 100);
        centerY = 50 + rand() * (imageSize(1) - 100);
        
        switch lesionType
            case 'solid_nodule'
                radius = 8 + rand() * 15;
                intensity = 180 + rand() * 40;
                
                % Create circular lesion
                lesionMask = ((X - centerX).^2 + (Y - centerY).^2) <= radius^2;
                
                % Add some irregularity
                irregularity = 0.3 * radius * sin(8 * atan2(Y - centerY, X - centerX));
                lesionMask = ((X - centerX).^2 + (Y - centerY).^2) <= (radius + irregularity).^2;
                
                image(lesionMask) = intensity;
                mask(lesionMask) = i;
                
            case 'ground_glass'
                radius = 12 + rand() * 20;
                intensity = backgroundIntensity + 20 + rand() * 15;
                
                % Create diffuse lesion with gradient edges
                distance = sqrt((X - centerX).^2 + (Y - centerY).^2);
                lesionMask = distance <= radius;
                
                % Apply Gaussian falloff
                weights = exp(-(distance.^2) / (2 * (radius/3)^2));
                weights(distance > radius) = 0;
                
                image = image + weights * (intensity - backgroundIntensity);
                mask(lesionMask) = i;
                
            case 'cavity'
                outerRadius = 10 + rand() * 12;
                innerRadius = outerRadius * (0.3 + rand() * 0.4);
                wallIntensity = 200 + rand() * 30;
                cavityIntensity = 30 + rand() * 20;
                
                % Create ring-shaped lesion
                distance = sqrt((X - centerX).^2 + (Y - centerY).^2);
                outerMask = distance <= outerRadius;
                innerMask = distance <= innerRadius;
                wallMask = outerMask & ~innerMask;
                
                image(wallMask) = wallIntensity;
                image(innerMask) = cavityIntensity;
                mask(outerMask) = i;
                
            case 'mass'
                width = 15 + rand() * 25;
                height = 15 + rand() * 25;
                intensity = 160 + rand() * 50;
                
                % Create elliptical lesion
                lesionMask = ((X - centerX) / width).^2 + ((Y - centerY) / height).^2 <= 1;
                
                % Add lobulated contour
                angles = atan2(Y - centerY, X - centerX);
                contourModulation = 0.2 * sin(4 * angles);
                scaledDistance = sqrt(((X - centerX) / width).^2 + ((Y - centerY) / height).^2);
                lesionMask = scaledDistance <= (1 + contourModulation);
                
                image(lesionMask) = intensity;
                mask(lesionMask) = i;
        end
        
        % Store lesion information
        lesion = struct();
        lesion.type = lesionType;
        lesion.center = [centerX, centerY];
        lesion.id = i;
        info.lesions = [info.lesions; lesion];
    end
    
    % Add noise
    image = image + 5 * randn(imageSize);
    
    % Ensure valid intensity range
    image = max(0, min(255, image));
    image = uint8(image);
    
    fprintf('Created medical image with %d lesions\n', numLesions);
end

function preprocessedImage = preprocessMedicalImage(image, options)
    % Preprocess medical image for lesion detection
    
    if nargin < 2
        options = struct();
        options.enhanceContrast = true;
        options.denoise = true;
        options.normalise = true;
    end
    
    fprintf('Preprocessing medical image for lesion detection...\n');
    
    preprocessedImage = double(image);
    
    % Noise reduction
    if options.denoise
        preprocessedImage = medfilt2(preprocessedImage, [3, 3]);
        preprocessedImage = imgaussfilt(preprocessedImage, 0.5);
    end
    
    % Contrast enhancement
    if options.enhanceContrast
        % Adaptive histogram equalisation
        preprocessedImage = uint8(preprocessedImage);
        preprocessedImage = adapthisteq(preprocessedImage);
        preprocessedImage = double(preprocessedImage);
    end
    
    % Intensity normalisation
    if options.normalise
        preprocessedImage = (preprocessedImage - min(preprocessedImage(:))) / ...
                           (max(preprocessedImage(:)) - min(preprocessedImage(:)));
    end
    
    fprintf('Preprocessing completed\n');
end

function candidates = detectLesionCandidates(image, detectionMethod)
    % Detect potential lesion candidates using various methods
    
    if nargin < 2
        detectionMethod = 'blob';
    end
    
    fprintf('Detecting lesion candidates using %s method...\n', detectionMethod);
    
    switch detectionMethod
        case 'blob'
            candidates = detectBlobCandidates(image);
        case 'template'
            candidates = detectTemplateCandidates(image);
        case 'threshold'
            candidates = detectThresholdCandidates(image);
        otherwise
            error('Unknown detection method: %s', detectionMethod);
    end
    
    fprintf('Detected %d lesion candidates\n', length(candidates));
end

function candidates = detectBlobCandidates(image)
    % Detect blob-like lesion candidates
    
    candidates = [];
    
    % Multi-scale blob detection using LoG
    scales = [2, 4, 6, 8, 10, 12];
    responses = zeros([size(image), length(scales)]);
    
    for i = 1:length(scales)
        sigma = scales(i);
        h = -fspecial('log', 2*ceil(3*sigma)+1, sigma);
        response = imfilter(double(image), h, 'same');
        responses(:, :, i) = response * sigma^2; % Normalise
    end
    
    % Find local maxima across scales
    [height, width] = size(image);
    
    for scale = 1:length(scales)
        response = responses(:, :, scale);
        
        % Find local maxima
        localMaxima = imregionalmax(response);
        
        % Threshold to remove weak responses
        threshold = 0.3 * max(response(:));
        strongMaxima = localMaxima & (response > threshold);
        
        % Extract candidate locations
        [y, x] = find(strongMaxima);
        
        for j = 1:length(y)
            candidate = struct();
            candidate.x = x(j);
            candidate.y = y(j);
            candidate.scale = scales(scale);
            candidate.response = response(y(j), x(j));
            candidate.radius = scales(scale) * sqrt(2);
            candidates = [candidates; candidate];
        end
    end
end

function candidates = detectTemplateCandidates(image)
    % Detect lesions using template matching
    
    candidates = [];
    
    % Create circular templates of different sizes
    templateSizes = [8, 12, 16, 20];
    
    for size = templateSizes
        % Create circular template
        template = createCircularTemplate(size);
        
        % Normalised cross-correlation
        correlation = normxcorr2(template, double(image));
        
        % Find peaks
        threshold = 0.6;
        peaks = correlation > threshold;
        
        % Find local maxima
        peaks = peaks & imregionalmax(correlation);
        
        [y, x] = find(peaks);
        
        % Convert coordinates back to image space
        templateRadius = size / 2;
        for j = 1:length(y)
            candidate = struct();
            candidate.x = x(j) - size + templateRadius;
            candidate.y = y(j) - size + templateRadius;
            candidate.scale = size;
            candidate.response = correlation(y(j), x(j));
            candidate.radius = templateRadius;
            
            % Check if within image bounds
            if candidate.x > 0 && candidate.x <= size(image, 2) && ...
               candidate.y > 0 && candidate.y <= size(image, 1)
                candidates = [candidates; candidate];
            end
        end
    end
end

function template = createCircularTemplate(diameter)
    % Create circular template for lesion detection
    
    template = zeros(diameter, diameter);
    center = diameter / 2;
    radius = diameter / 2 - 1;
    
    [X, Y] = meshgrid(1:diameter, 1:diameter);
    distance = sqrt((X - center).^2 + (Y - center).^2);
    
    % Create Gaussian blob
    template = exp(-(distance.^2) / (2 * (radius/3)^2));
    template(distance > radius) = 0;
    
    % Normalise
    template = template / sum(template(:));
end

function candidates = detectThresholdCandidates(image)
    % Detect lesions using intensity thresholding
    
    candidates = [];
    
    % Multi-level thresholding
    thresholds = [0.6, 0.7, 0.8]; % Relative to image maximum
    
    for threshold = thresholds
        intensityThreshold = threshold * max(image(:));
        
        % Binary threshold
        binaryImage = image > intensityThreshold;
        
        % Remove small objects
        binaryImage = bwareaopen(binaryImage, 20);
        
        % Find connected components
        cc = bwconncomp(binaryImage);
        stats = regionprops(cc, 'Area', 'Centroid', 'BoundingBox');
        
        for j = 1:length(stats)
            if stats(j).Area > 10 % Minimum size threshold
                candidate = struct();
                candidate.x = stats(j).Centroid(1);
                candidate.y = stats(j).Centroid(2);
                candidate.area = stats(j).Area;
                candidate.radius = sqrt(stats(j).Area / pi);
                candidate.threshold = threshold;
                candidate.response = mean(image(cc.PixelIdxList{j}));
                candidates = [candidates; candidate];
            end
        end
    end
end

function features = extractLesionFeatures(image, candidates)
    % Extract features from lesion candidates for classification
    
    fprintf('Extracting features from %d candidates...\n', length(candidates));
    
    features = [];
    
    for i = 1:length(candidates)
        candidate = candidates(i);
        
        % Define region of interest around candidate
        roiSize = 32;
        x = round(candidate.x);
        y = round(candidate.y);
        
        % Extract ROI
        x1 = max(1, x - roiSize/2);
        x2 = min(size(image, 2), x + roiSize/2);
        y1 = max(1, y - roiSize/2);
        y2 = min(size(image, 1), y + roiSize/2);
        
        roi = image(y1:y2, x1:x2);
        
        % Feature extraction
        candidateFeatures = struct();
        
        % Intensity features
        candidateFeatures.meanIntensity = mean(roi(:));
        candidateFeatures.stdIntensity = std(roi(:));
        candidateFeatures.maxIntensity = max(roi(:));
        candidateFeatures.minIntensity = min(roi(:));
        
        % Geometric features
        candidateFeatures.area = candidate.area;
        candidateFeatures.radius = candidate.radius;
        candidateFeatures.compactness = (4 * pi * candidate.area) / (perimeter(roi)^2);
        
        % Texture features
        candidateFeatures.entropy = entropy(uint8(255 * roi / max(roi(:))));
        
        % Gradient features
        [Gx, Gy] = gradient(roi);
        gradientMagnitude = sqrt(Gx.^2 + Gy.^2);
        candidateFeatures.gradientMean = mean(gradientMagnitude(:));
        candidateFeatures.gradientStd = std(gradientMagnitude(:));
        
        % Shape features (simplified)
        candidateFeatures.aspectRatio = size(roi, 2) / size(roi, 1);
        
        features = [features; candidateFeatures];
    end
    
    fprintf('Feature extraction completed\n');
end

function p = perimeter(binaryImage)
    % Calculate perimeter of binary image
    boundary = bwperim(binaryImage > mean(binaryImage(:)));
    p = sum(boundary(:));
end

function [classifications, segmentations] = classifyAndSegmentLesions(image, candidates, features)
    % Classify candidates and perform precise segmentation
    
    fprintf('Classifying and segmenting lesion candidates...\n');
    
    classifications = [];
    segmentations = cell(length(candidates), 1);
    
    for i = 1:length(candidates)
        candidate = candidates(i);
        candidateFeatures = features(i);
        
        % Simple rule-based classification (in practice, use trained ML model)
        classification = classifyLesionCandidate(candidateFeatures);
        classifications = [classifications; classification];
        
        % Perform segmentation if classified as lesion
        if classification.isLesion
            segmentation = segmentLesion(image, candidate);
            segmentations{i} = segmentation;
        else
            segmentations{i} = [];
        end
    end
    
    numLesions = sum([classifications.isLesion]);
    fprintf('Classification completed: %d lesions identified\n', numLesions);
end

function classification = classifyLesionCandidate(features)
    % Classify lesion candidate based on extracted features
    
    classification = struct();
    
    % Simple rule-based classifier (replace with trained ML model)
    score = 0;
    
    % Intensity criteria
    if features.meanIntensity > 120
        score = score + 0.3;
    end
    
    % Size criteria
    if features.area > 50 && features.area < 500
        score = score + 0.3;
    end
    
    % Shape criteria
    if features.compactness > 0.5
        score = score + 0.2;
    end
    
    % Texture criteria
    if features.entropy > 2.0
        score = score + 0.2;
    end
    
    % Classification decision
    classification.score = score;
    classification.isLesion = score > 0.6;
    
    % Assign lesion type based on features
    if classification.isLesion
        if features.meanIntensity > 150
            classification.type = 'solid';
        elseif features.entropy > 3.0
            classification.type = 'complex';
        else
            classification.type = 'ground_glass';
        end
    else
        classification.type = 'normal';
    end
    
    classification.confidence = min(1, score / 1.2);
end

function segmentation = segmentLesion(image, candidate)
    % Perform precise segmentation of detected lesion
    
    % Define region around candidate
    roiSize = round(candidate.radius * 3);
    x = round(candidate.x);
    y = round(candidate.y);
    
    x1 = max(1, x - roiSize);
    x2 = min(size(image, 2), x + roiSize);
    y1 = max(1, y - roiSize);
    y2 = min(size(image, 1), y + roiSize);
    
    roi = image(y1:y2, x1:x2);
    
    % Active contour segmentation
    segmentation = performActiveContourSegmentation(roi, candidate);
    
    % Convert back to full image coordinates
    segmentation.x_offset = x1 - 1;
    segmentation.y_offset = y1 - 1;
end

function segmentation = performActiveContourSegmentation(roi, candidate)
    % Perform active contour segmentation on ROI
    
    % Initial contour (circle around candidate center)
    [height, width] = size(roi);
    centerX = width / 2;
    centerY = height / 2;
    
    % Create initial mask
    [X, Y] = meshgrid(1:width, 1:height);
    initialRadius = candidate.radius * 0.8;
    initialMask = (X - centerX).^2 + (Y - centerY).^2 <= initialRadius^2;
    
    % Perform active contour evolution (simplified)
    numIterations = 50;
    currentMask = initialMask;
    
    for iter = 1:numIterations
        % Compute forces
        [forceX, forceY] = computeActiveContourForces(roi, currentMask);
        
        % Update contour
        currentMask = evolveContour(currentMask, forceX, forceY);
        
        % Check convergence (simplified)
        if iter > 10 && mod(iter, 10) == 0
            % Could add convergence criteria here
        end
    end
    
    segmentation = struct();
    segmentation.mask = currentMask;
    segmentation.area = sum(currentMask(:));
    segmentation.perimeter = sum(bwperim(currentMask));
    
    % Extract contour points
    boundary = bwboundaries(currentMask);
    if ~isempty(boundary)
        segmentation.contour = boundary{1};
    else
        segmentation.contour = [];
    end
end

function [forceX, forceY] = computeActiveContourForces(image, mask)
    % Compute forces for active contour evolution
    
    % Image gradient forces
    [Gx, Gy] = gradient(double(image));
    gradientMagnitude = sqrt(Gx.^2 + Gy.^2);
    
    % Normalise gradient
    maxGrad = max(gradientMagnitude(:));
    if maxGrad > 0
        Gx = Gx / maxGrad;
        Gy = Gy / maxGrad;
    end
    
    % Region-based forces
    insideMean = mean(image(mask));
    outsideMean = mean(image(~mask));
    
    regionForce = (image - insideMean).^2 - (image - outsideMean).^2;
    [regionFx, regionFy] = gradient(regionForce);
    
    % Combine forces
    alpha = 0.5; % Weight for gradient forces
    beta = 0.5;  % Weight for region forces
    
    forceX = alpha * Gx + beta * regionFx;
    forceY = alpha * Gy + beta * regionFy;
end

function newMask = evolveContour(mask, forceX, forceY)
    % Evolve contour based on computed forces
    
    % Simple level set evolution (simplified)
    dt = 0.1;
    
    % Compute distance transform
    phi = bwdist(~mask) - bwdist(mask);
    
    % Compute gradient of distance function
    [phiX, phiY] = gradient(phi);
    
    % Normalise gradient
    gradMagnitude = sqrt(phiX.^2 + phiY.^2);
    phiX = phiX ./ (gradMagnitude + eps);
    phiY = phiY ./ (gradMagnitude + eps);
    
    % Update level set function
    phiNew = phi + dt * (forceX .* phiX + forceY .* phiY);
    
    % Extract new mask
    newMask = phiNew > 0;
end

function analysisResults = performLesionAnalysis(image, groundTruthMask)
    % Perform comprehensive lesion detection and analysis
    
    fprintf('Performing comprehensive lesion analysis...\n');
    
    analysisResults = struct();
    
    % Preprocessing
    preprocessedImage = preprocessMedicalImage(image);
    
    % Candidate detection
    candidates = detectLesionCandidates(preprocessedImage, 'blob');
    
    % Feature extraction
    features = extractLesionFeatures(preprocessedImage, candidates);
    
    % Classification and segmentation
    [classifications, segmentations] = classifyAndSegmentLesions(preprocessedImage, candidates, features);
    
    % Evaluation against ground truth
    evaluation = evaluateDetectionResults(classifications, segmentations, groundTruthMask, candidates);
    
    % Store results
    analysisResults.candidates = candidates;
    analysisResults.features = features;
    analysisResults.classifications = classifications;
    analysisResults.segmentations = segmentations;
    analysisResults.evaluation = evaluation;
    
    fprintf('Lesion analysis completed\n');
end

function evaluation = evaluateDetectionResults(classifications, segmentations, groundTruthMask, candidates)
    % Evaluate detection results against ground truth
    
    evaluation = struct();
    
    % Count detected lesions
    detectedLesions = sum([classifications.isLesion]);
    
    % Count true lesions in ground truth
    trueLesions = length(unique(groundTruthMask)) - 1; % Exclude background
    
    % Compute basic metrics
    evaluation.detectedCount = detectedLesions;
    evaluation.groundTruthCount = trueLesions;
    
    % Spatial matching evaluation
    truePositives = 0;
    falsePositives = 0;
    
    for i = 1:length(classifications)
        if classifications(i).isLesion
            candidate = candidates(i);
            
            % Check if candidate overlaps with ground truth
            x = round(candidate.x);
            y = round(candidate.y);
            
            if x >= 1 && x <= size(groundTruthMask, 2) && ...
               y >= 1 && y <= size(groundTruthMask, 1)
                
                if groundTruthMask(y, x) > 0
                    truePositives = truePositives + 1;
                else
                    falsePositives = falsePositives + 1;
                end
            else
                falsePositives = falsePositives + 1;
            end
        end
    end
    
    falseNegatives = max(0, trueLesions - truePositives);
    
    % Compute performance metrics
    evaluation.truePositives = truePositives;
    evaluation.falsePositives = falsePositives;
    evaluation.falseNegatives = falseNegatives;
    
    % Standard metrics
    if truePositives + falsePositives > 0
        evaluation.precision = truePositives / (truePositives + falsePositives);
    else
        evaluation.precision = 0;
    end
    
    if truePositives + falseNegatives > 0
        evaluation.recall = truePositives / (truePositives + falseNegatives);
    else
        evaluation.recall = 0;
    end
    
    if evaluation.precision + evaluation.recall > 0
        evaluation.f1Score = 2 * (evaluation.precision * evaluation.recall) / ...
                            (evaluation.precision + evaluation.recall);
    else
        evaluation.f1Score = 0;
    end
    
    fprintf('Detection evaluation: Precision=%.3f, Recall=%.3f, F1=%.3f\n', ...
        evaluation.precision, evaluation.recall, evaluation.f1Score);
end
