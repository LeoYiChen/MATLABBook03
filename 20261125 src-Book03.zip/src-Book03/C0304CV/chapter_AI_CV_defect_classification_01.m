%% chapter_AI_CV_defect_classification_01.m
% Advanced Defect Detection and Classification System for Industrial Quality Control
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_defect_classification_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Advanced Defect Detection and Classification System
fprintf('Advanced Defect Detection and Classification System\n');
fprintf('==================================================\n');

% Create comprehensive defect dataset for training and testing
[defectDataset, defectLabels, defectInfo] = createDefectClassificationDataset();











% 1. Feature Extraction for Defect Classification





% 2. Machine Learning Classification

% 3. Deep Learning Approach

% 4. Multi-classifier Ensemble


% 5. Classification Performance Analysis

% Test the defect classification system
fprintf('\nTesting defect classification system...\n');

% Extract features from all samples
fprintf('Extracting features from defect samples...\n');
allFeatures = [];

for i = 1:size(defectDataset, 3)
    sampleImage = defectDataset(:, :, i);
    features = extractDefectClassificationFeatures(sampleImage);
    allFeatures = [allFeatures; features];
end

fprintf('Feature extraction completed: %d features per sample\n', size(allFeatures, 2));

% Train different classifiers
[svmClassifier, svmAccuracy] = trainDefectClassifier(allFeatures, defectLabels, 'svm');
[treeClassifier, treeAccuracy] = trainDefectClassifier(allFeatures, defectLabels, 'tree');

% Create ensemble classifier
ensembleClassifier = createEnsembleClassifier(allFeatures, defectLabels);

% Test ensemble predictions
testIndices = randperm(size(allFeatures, 1), 20);
testFeatures = allFeatures(testIndices, :);
testLabels = defectLabels(testIndices);

ensemblePredictions = predictEnsemble(ensembleClassifier, testFeatures);

% Analyze performance
performanceReport = analyzeClassificationPerformance(ensemblePredictions, testLabels, defectInfo.defectTypes);

% Visualise classification results
figure;

% Show sample images from each defect class
numClasses = length(defectInfo.defectTypes);
for i = 1:numClasses
    subplot(2, 4, i);
    
    % Find first sample of this class
    classIndices = find(defectLabels == i);
    if ~isempty(classIndices)
        sampleImage = defectDataset(:, :, classIndices(1));
        imshow(sampleImage, []);
        title(sprintf('%s', defectInfo.defectTypes{i}));
    end
end

% Display confusion matrix
subplot(2, 4, 8);
imagesc(performanceReport.confusionMatrix);
colorbar;
title('Confusion Matrix');
xlabel('Predicted Class');
ylabel('True Class');

sgtitle('Defect Classification Results');

% Display performance metrics
figure;

% Per-class performance
classNames = defectInfo.defectTypes;
precisions = arrayfun(@(x) performanceReport.classMetrics.*(classNames{x}).precision, 1:length(classNames));
recalls = arrayfun(@(x) performanceReport.classMetrics.*(classNames{x}).recall, 1:length(classNames));
f1Scores = arrayfun(@(x) performanceReport.classMetrics.*(classNames{x}).f1Score, 1:length(classNames));

subplot(1, 3, 1);
bar([precisions; recalls; f1Scores]');
legend({'Precision', 'Recall', 'F1-Score'});
set(gca, 'XTickLabel', classNames);
xtickangle(45);
title('Per-Class Performance');
ylabel('Score');

% Classifier comparison
subplot(1, 3, 2);
classifierAccuracies = [svmAccuracy, treeAccuracy, performanceReport.overallAccuracy];
classifierNames = {'SVM', 'Decision Tree', 'Ensemble'};
bar(classifierAccuracies);
set(gca, 'XTickLabel', classifierNames);
title('Classifier Comparison');
ylabel('Accuracy');

% Feature importance (simplified visualization)
subplot(1, 3, 3);
featureImportance = std(allFeatures, 0, 1); % Use feature variance as importance measure
bar(featureImportance);
title('Feature Importance');
xlabel('Feature Index');
ylabel('Importance (Std Dev)');

sgtitle('Defect Classification Performance Analysis');

fprintf('\nDefect Classification System Summary:\n');
fprintf('====================================\n');
fprintf('Dataset: %d samples across %d defect types\n', size(defectDataset, 3), length(defectInfo.defectTypes));
fprintf('Features: %d features extracted per sample\n', size(allFeatures, 2));
fprintf('Best classifier: Ensemble (%.1f%% accuracy)\n', performanceReport.overallAccuracy * 100);

fprintf('\nImplementation Benefits:\n');
fprintf('=======================\n');
fprintf(' Automated defect categorisation\n');
fprintf(' Consistent quality assessment\n');
fprintf(' Reduced dependency on human expertise\n');
fprintf(' Comprehensive defect documentation\n');
fprintf(' Process improvement insights\n');
fprintf(' Real-time quality feedback\n');
fprintf(' Statistical quality control\n');
fprintf(' Continuous learning capabilities\n');

fprintf('\nIndustrial Applications:\n');
fprintf('=======================\n');
fprintf(' Surface quality inspection in manufacturing\n');
fprintf(' Semiconductor wafer defect analysis\n');
fprintf(' Textile fabric defect detection\n');
fprintf(' Automotive paint quality assessment\n');
fprintf(' Pharmaceutical tablet inspection\n');
fprintf(' Food product quality control\n');
fprintf(' Metal parts surface analysis\n');
fprintf(' Electronic component inspection\n');

% Local functions (moved to end so this listing is a valid MATLAB script)
function [dataset, labels, info] = createDefectClassificationDataset()
    % Create comprehensive dataset for defect classification
    
    fprintf('Creating defect classification dataset...\n');
    
    numSamplesPerClass = 20;
    defectTypes = {'scratch', 'crack', 'pi*t', 'stain', 'dent', 'burn', 'good'};
    
    totalSamples = length(defectTypes) * numSamplesPerClass;
    imageSize = [128, 128];
    
    dataset = zeros([imageSize, totalSamples], 'single');
    labels = [];
    
    info = struct();
    info.defectTypes = defectTypes;
    info.numSamplesPerClass = numSamplesPerClass;
    info.imageSize = imageSize;
    
    sampleIdx = 1;
    
    for typeIdx = 1:length(defectTypes)
        defectType = defectTypes{typeIdx};
        
        for sample = 1:numSamplesPerClass
            % Create sample image with specific defect type
            sampleImage = createDefectSample(imageSize, defectType, sample);
            
            dataset(:, :, sampleIdx) = sampleImage;
            labels = [labels; typeIdx];
            sampleIdx = sampleIdx + 1;
        end
    end
    
    fprintf('Created dataset: %d samples across %d defect types\n', ...
        totalSamples, length(defectTypes));
end

function image = createDefectSample(imageSize, defectType, sampleNumber)
    % Create synthetic sample with specific defect characteristics
    
    % Create base surface texture
    image = createBaseSurface(imageSize, sampleNumber);
    
    switch defectType
        case 'scratch'
            image = addScratchDefect(image, sampleNumber);
            
        case 'crack'
            image = addCrackDefect(image, sampleNumber);
            
        case 'pi*t'
            image = addPitDefect(image, sampleNumber);
            
        case 'stain'
            image = addStainDefect(image, sampleNumber);
            
        case 'dent'
            image = addDentDefect(image, sampleNumber);
            
        case 'burn'
            image = addBurnDefect(image, sampleNumber);
            
        case 'good'
            % No additional defects - just base surface
            
        otherwise
            error('Unknown defect type: %s', defectType);
    end
    
    % Normalise to [0, 1] range
    image = single(image);
    image = (image - min(image(:))) / (max(image(:)) - min(image(:)) + eps);
end

function surface = createBaseSurface(imageSize, seed)
    % Create base surface texture with controlled variation
    
    rng(seed); % For reproducible results
    
    % Base intensity
    baseIntensity = 0.5 + 0.1 * (rand() - 0.5);
    
    % Create surface with slight texture
    [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
    
    % Multiple frequency components for realistic texture
    texture = 0.05 * sin(X / 10) .* cos(Y / 15) + ...
              0.03 * sin(X / 5) .* sin(Y / 8) + ...
              0.02 * randn(imageSize);
    
    surface = baseIntensity + texture;
    
    % Ensure valid range
    surface = max(0, min(1, surface));
    
    rng('shuffle'); % Reset random seed
end

function image = addScratchDefect(image, seed)
    % Add linear scratch defect
    
    rng(seed);
    
    % Scratch parameters
    startX = 20 + rand() * (size(image, 2) - 40);
    startY = 20 + rand() * (size(image, 1) - 40);
    
    length = 20 + rand() * 40;
    angle = rand() * 2 * pi;
    width = 1 + rand() * 2;
    
    endX = startX + length * cos(angle);
    endY = startY + length * sin(angle);
    
    % Ensure within image bounds
    endX = max(1, min(size(image, 2), endX));
    endY = max(1, min(size(image, 1), endY));
    
    % Create scratch path
    numPoints = round(length * 2);
    xPoints = linspace(startX, endX, numPoints);
    yPoints = linspace(startY, endY, numPoints);
    
    % Apply scratch effect
    intensity = 0.2 + rand() * 0.3; % Scratch darkness
    
    for i = 1:length(xPoints)
        x = round(xPoints(i));
        y = round(yPoints(i));
        
        % Create scratch with some width
        for dx = -round(width):round(width)
            for dy = -round(width):round(width)
                if sqrt(dx^2 + dy^2) <= width
                    px = x + dx;
                    py = y + dy;
                    
                    if px >= 1 && px <= size(image, 2) && py >= 1 && py <= size(image, 1)
                        image(py, px) = image(py, px) * intensity;
                    end
                end
            end
        end
    end
    
    rng('shuffle');
end

function image = addCrackDefect(image, seed)
    % Add branching crack defect
    
    rng(seed);
    
    % Starting point
    startX = size(image, 2) / 2 + (rand() - 0.5) * 20;
    startY = size(image, 1) / 2 + (rand() - 0.5) * 20;
    
    % Create main crack
    image = createCrackBranch(image, startX, startY, rand() * 2 * pi, 25 + rand() * 20);
    
    % Add secondary branches
    numBranches = randi([1, 3]);
    for i = 1:numBranches
        branchX = startX + (rand() - 0.5) * 40;
        branchY = startY + (rand() - 0.5) * 40;
        
        if branchX >= 1 && branchX <= size(image, 2) && ...
           branchY >= 1 && branchY <= size(image, 1)
            image = createCrackBranch(image, branchX, branchY, rand() * 2 * pi, 10 + rand() * 15);
        end
    end
    
    rng('shuffle');
end

function image = createCrackBranch(image, startX, startY, direction, length)
    % Create single crack branch with some randomness
    
    currentX = startX;
    currentY = startY;
    currentDirection = direction;
    
    intensity = 0.1 + rand() * 0.2;
    
    for step = 1:round(length)
        % Add some randomness to direction
        currentDirection = currentDirection + (rand() - 0.5) * 0.3;
        
        % Move in current direction
        currentX = currentX + cos(currentDirection);
        currentY = currentY + sin(currentDirection);
        
        x = round(currentX);
        y = round(currentY);
        
        if x >= 1 && x <= size(image, 2) && y >= 1 && y <= size(image, 1)
            image(y, x) = image(y, x) * intensity;
            
            % Add slight width to crack
            if x > 1
                image(y, x-1) = image(y, x-1) * (intensity + 0.3);
            end
            if x < size(image, 2)
                image(y, x+1) = image(y, x+1) * (intensity + 0.3);
            end
        else
            break; % Stop if outside image
        end
    end
end

function image = addPitDefect(image, seed)
    % Add circular pi*t defect
    
    rng(seed);
    
    % Pit parameters
    centerX = 30 + rand() * (size(image, 2) - 60);
    centerY = 30 + rand() * (size(image, 1) - 60);
    radius = 5 + rand() * 10;
    depth = 0.3 + rand() * 0.4;
    
    [X, Y] = meshgrid(1:size(image, 2), 1:size(image, 1));
    distance = sqrt((X - centerX).^2 + (Y - centerY).^2);
    
    % Create pi*t with gradient edges
    pitMask = distance <= radius;
    gradientMask = distance <= radius * 1.5;
    
    % Apply pi*t effect with smooth transition
    for y = 1:size(image, 1)
        for x = 1:size(image, 2)
            if pitMask(y, x)
                % Full pi*t depth at center
                image(y, x) = image(y, x) * (1 - depth);
            elseif gradientMask(y, x)
                % Gradual transition
                factor = 1 - (distance(y, x) - radius) / (radius * 0.5);
                image(y, x) = image(y, x) * (1 - depth * factor * 0.5);
            end
        end
    end
    
    rng('shuffle');
end

function image = addStainDefect(image, seed)
    % Add irregular stain defect
    
    rng(seed);
    
    % Stain parameters
    centerX = 40 + rand() * (size(image, 2) - 80);
    centerY = 40 + rand() * (size(image, 1) - 80);
    radius = 10 + rand() * 15;
    intensity = 0.3 + rand() * 0.4;
    
    [X, Y] = meshgrid(1:size(image, 2), 1:size(image, 1));
    
    % Create irregular stain shape
    angle = atan2(Y - centerY, X - centerX);
    distance = sqrt((X - centerX).^2 + (Y - centerY).^2);
    
    % Add irregularity to boundary
    irregularity = 0.3 * sin(6 * angle) + 0.2 * sin(4 * angle);
    adjustedRadius = radius * (1 + irregularity);
    
    stainMask = distance <= adjustedRadius;
    
    % Apply stain with some transparency
    stainEffect = exp(-distance.^2 / (2 * radius^2));
    
    image = image + intensity * stainEffect .* stainMask;
    image = min(1, image); % Clamp to valid range
    
    rng('shuffle');
end

function image = addDentDefect(image, seed)
    % Add dent defect with shading effects
    
    rng(seed);
    
    % Dent parameters
    centerX = 30 + rand() * (size(image, 2) - 60);
    centerY = 30 + rand() * (size(image, 1) - 60);
    radius = 8 + rand() * 12;
    
    [X, Y] = meshgrid(1:size(image, 2), 1:size(image, 1));
    distance = sqrt((X - centerX).^2 + (Y - centerY).^2);
    
    % Create dent with shading pattern
    dentMask = distance <= radius;
    
    % Simulate lighting effects on dented surface
    lightDirection = [1, 1]; % Light from top-right
    
    [gradX, gradY] = gradient(double(dentMask));
    
    % Calculate surface normal deviation
    normalX = gradX;
    normalY = gradY;
    
    % Dot product with light direction for shading
    shading = normalX * lightDirection(1) + normalY * lightDirection(2);
    shading = shading / (norm(lightDirection) + eps);
    
    % Apply shading effect
    shadingIntensity = 0.2;
    image = image + shadingIntensity * shading .* dentMask;
    
    % Ensure valid range
    image = max(0, min(1, image));
    
    rng('shuffle');
end

function image = addBurnDefect(image, seed)
    % Add burn defect with discoloration
    
    rng(seed);
    
    % Burn parameters
    centerX = 25 + rand() * (size(image, 2) - 50);
    centerY = 25 + rand() * (size(image, 1) - 50);
    radius = 8 + rand() * 15;
    
    [X, Y] = meshgrid(1:size(image, 2), 1:size(image, 1));
    distance = sqrt((X - centerX).^2 + (Y - centerY).^2);
    
    % Create burn with multiple intensity zones
    coreMask = distance <= radius * 0.4; % Severely burned core
    moderateMask = distance <= radius * 0.7 & ~coreMask; % Moderately burned
    lightMask = distance <= radius & ~coreMask & ~moderateMask; % Lightly burned
    
    % Apply burn effects
    image(coreMask) = image(coreMask) * 0.2; % Very dark core
    image(moderateMask) = image(moderateMask) * 0.5; % Moderately dark
    image(lightMask) = image(lightMask) * 0.8; % Slightly dark
    
    rng('shuffle');
end

function features = extractDefectClassificationFeatures(image)
    % Extract comprehensive features for defect classification
    
    features = [];
    
    % Intensity features
    intensityFeatures = extractIntensityFeatures(image);
    
    % Texture features
    textureFeatures = extractTextureFeatures(image);
    
    % Shape features
    shapeFeatures = extractShapeFeatures(image);
    
    % Edge features
    edgeFeatures = extractEdgeFeatures(image);
    
    % Combine all features
    features = [intensityFeatures, textureFeatures, shapeFeatures, edgeFeatures];
end

function features = extractIntensityFeatures(image)
    % Extract intensity-based features
    
    pixels = double(image(:));
    
    features = [
        mean(pixels),           % Mean intensity
        std(pixels),            % Standard deviation
        skewness(pixels),       % Skewness
        kurtosis(pixels),       % Kurtosis
        min(pixels),            % Minimum intensity
        max(pixels),            % Maximum intensity
        range(pixels),          % Intensity range
        prctile(pixels, 25),    % 25*th percentile
        prctile(pixels, 75)     % 75*th percentile
    ];
end

function features = extractTextureFeatures(image)
    % Extract texture-based features using GLCM
    
    % Convert to uint8 for GLCM calculation
    img_uint8 = uint8(image * 255);
    
    % Calculate GLCM (Gray-Level Co-occurrence Matrix)
    glcm = graycomatrix(img_uint8, 'Offset', [0 1; -1 1; -1 0; -1 -1], ...
                       'Symmetric', true, 'NumLevels', 32);
    
    % Calculate texture properties
    props = graycoprops(glcm, {'Contrast', 'Correlation', 'Energy', 'Homogeneity'});
    
    features = [
        mean(props.Contrast),      % Average contrast
        mean(props.Correlation),   % Average correlation
        mean(props.Energy),        % Average energy
        mean(props.Homogeneity),   % Average homogeneity
        entropy(img_uint8)         % Entropy
    ];
end

function features = extractShapeFeatures(image)
    % Extract shape-based features
    
    % Threshold image to get binary regions
    threshold = graythresh(image);
    binaryImage = imbinarize(image, threshold);
    
    % Remove small objects
    binaryImage = bwareaopen(binaryImage, 10);
    
    % Calculate region properties
    props = regionprops(binaryImage, 'Area', 'Perimeter', 'Eccentricity', ...
                       'Solidity', 'Extent', 'MajorAxisLength', 'MinorAxisLength');
    
    if ~isempty(props)
        % Use largest region if multiple regions exist
        [~, maxIdx] = max([props.Area]);
        region = props(maxIdx);
        
        features = [
            region.Area,
            region.Perimeter,
            region.Eccentricity,
            region.Solidity,
            region.Extent,
            region.MajorAxisLength / (region.MinorAxisLength + eps), % Aspect ratio
            4 * pi * region.Area / (region.Perimeter^2 + eps)        % Circularity
        ];
    else
        features = zeros(1, 7); % Default values if no regions found
    end
end

function features = extractEdgeFeatures(image)
    % Extract edge-based features
    
    % Detect edges using different methods
    cannyEdges = edge(image, 'canny');
    sobelEdges = edge(image, 'sobel');
    
    % Calculate edge density
    cannyDensity = sum(cannyEdges(:)) / numel(cannyEdges);
    sobelDensity = sum(sobelEdges(:)) / numel(sobelEdges);
    
    % Calculate gradient statistics
    [Gx, Gy] = gradient(double(image));
    gradientMagnitude = sqrt(Gx.^2 + Gy.^2);
    
    features = [
        cannyDensity,                    % Canny edge density
        sobelDensity,                    % Sobel edge density
        mean(gradientMagnitude(:)),      % Mean gradient magnitude
        std(gradientMagnitude(:)),       % Std gradient magnitude
        max(gradientMagnitude(:))        % Max gradient magnitude
    ];
end

function [classifier, accuracy] = trainDefectClassifier(features, labels, classifierType)
    % Train machine learning classifier for defect detection
    
    if nargin < 3
        classifierType = 'svm';
    end
    
    fprintf('Training %s classifier for defect classification...\n', classifierType);
    
    % Split data into training and testing sets
    numSamples = size(features, 1);
    trainRatio = 0.8;
    
    randIndices = randperm(numSamples);
    numTrain = round(numSamples * trainRatio);
    
    trainIndices = randIndices(1:numTrain);
    testIndices = randIndices((numTrain+1):end);
    
    trainFeatures = features(trainIndices, :);
    trainLabels = labels(trainIndices);
    testFeatures = features(testIndices, :);
    testLabels = labels(testIndices);
    
    % Train classifier
    switch classifierType
        case 'svm'
            % Support Vector Machine
            classifier = fitcecoc(trainFeatures, trainLabels);
            
        case 'tree'
            % Decision Tree
            classifier = fitctree(trainFeatures, trainLabels);
            
        case 'knn'
            % K-Nearest Neighbors
            classifier = fitcknn(trainFeatures, trainLabels, 'NumNeighbors', 5);
            
        case 'ensemble'
            % Random Forest
            classifier = TreeBagger(100, trainFeatures, trainLabels, 'OOBPrediction', 'On');
            
        otherwise
            error('Unknown classifier type: %s', classifierType);
    end
    
    % Evaluate classifier
    if strcmp(classifierType, 'ensemble')
        [predictions, ~] = predict(classifier, testFeatures);
        predictions = str2double(predictions); % Convert from cell array
    else
        predictions = predict(classifier, testFeatures);
    end
    
    accuracy = sum(predictions == testLabels) / length(testLabels);
    
    fprintf('Classifier training completed. Accuracy: %.2f%%\n', accuracy * 100);
end

function [deepClassifier, trainInfo] = trainDeepDefectClassifier(imageDataset, labels, options)
    % Train deep learning classifier for defect classification
    
    if nargin < 3
        options = struct();
        options.epochs = 20;
        options.batchSize = 16;
        options.learningRate = 0.001;
    end
    
    fprintf('Training deep learning classifier...\n');
    
    % Prepare data
    numClasses = length(unique(labels));
    imageSize = size(imageDataset(:, :, 1));
    
    % Create network architecture
    layers = [
        imageInputLayer([imageSize, 1], 'Name', 'input')
        
        convolution2dLayer(5, 16, 'Padding', 'same', 'Name', 'conv1')
        batchNormalizationLayer('Name', 'bn1')
        reluLayer('Name', 'relu1')
        maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool1')
        
        convolution2dLayer(3, 32, 'Padding', 'same', 'Name', 'conv2')
        batchNormalizationLayer('Name', 'bn2')
        reluLayer('Name', 'relu2')
        maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool2')
        
        convolution2dLayer(3, 64, 'Padding', 'same', 'Name', 'conv3')
        batchNormalizationLayer('Name', 'bn3')
        reluLayer('Name', 'relu3')
        maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool3')
        
        fullyConnectedLayer(128, 'Name', 'fc1')
        reluLayer('Name', 'relu_fc1')
        dropoutLayer(0.5, 'Name', 'dropout')
        
        fullyConnectedLayer(numClasses, 'Name', 'fc2')
        softmaxLayer('Name', 'softmax')
        classificationLayer('Name', 'output')
    ];
    
    % Training options
    trainingOpts = trainingOptions('adam', ...
        'InitialLearnRate', options.learningRate, ...
        'MaxEpochs', options.epochs, ...
        'MiniBatchSize', options.batchSize, ...
        'Verbose', false, ...
        'Plots', 'none');
    
    try
        % Prepare data for training
        X = reshape(imageDataset, [imageSize, 1, size(imageDataset, 3)]);
        Y = categorical(labels);
        
        % Train network
        [deepClassifier, trainInfo] = trainNetwork(X, Y, layers, trainingOpts);
        
        fprintf('Deep learning classifier training completed\n');
        
    catch ME
        fprintf('Deep learning training failed: %s\n', ME.message);
        fprintf('Using untrained network\n');
        
        deepClassifier = assembleNetwork(layers);
        trainInfo = struct();
    end
end

function ensembleClassifier = createEnsembleClassifier(features, labels)
    % Create ensemble of multiple classifiers
    
    fprintf('Creating ensemble classifier...\n');
    
    ensembleClassifier = struct();
    
    % Train multiple base classifiers
    [svmClassifier, svmAcc] = trainDefectClassifier(features, labels, 'svm');
    [treeClassifier, treeAcc] = trainDefectClassifier(features, labels, 'tree');
    [knnClassifier, knnAcc] = trainDefectClassifier(features, labels, 'knn');
    
    % Store classifiers and their accuracies
    ensembleClassifier.classifiers = {svmClassifier, treeClassifier, knnClassifier};
    ensembleClassifier.accuracies = [svmAcc, treeAcc, knnAcc];
    ensembleClassifier.weights = ensembleClassifier.accuracies / sum(ensembleClassifier.accuracies);
    
    fprintf('Ensemble classifier created with %d base classifiers\n', length(ensembleClassifier.classifiers));
end

function prediction = predictEnsemble(ensembleClassifier, features)
    % Make prediction using ensemble classifier
    
    numClassifiers = length(ensembleClassifier.classifiers);
    predictions = zeros(size(features, 1), numClassifiers);
    
    % Get predictions from each base classifier
    for i = 1:numClassifiers
        classifier = ensembleClassifier.classifiers{i};
        
        if isa(classifier, 'TreeBagger')
            pred = predict(classifier, features);
            predictions(:, i) = str2double(pred);
        else
            predictions(:, i) = predict(classifier, features);
        end
    end
    
    % Weighted voting
    weights = ensembleClassifier.weights;
    prediction = zeros(size(features, 1), 1);
    
    for i = 1:size(features, 1)
        classVotes = zeros(1, max(predictions(i, :)));
        
        for j = 1:numClassifiers
            classIdx = predictions(i, j);
            if classIdx > 0 && classIdx <= length(classVotes)
                classVotes(classIdx) = classVotes(classIdx) + weights(j);
            end
        end
        
        [~, prediction(i)] = max(classVotes);
    end
end

function performanceReport = analyzeClassificationPerformance(predictions, groundTruth, classNames)
    % Analyze classification performance with detailed metrics
    
    fprintf('Analyzing classification performance...\n');
    
    performanceReport = struct();
    
    % Basic accuracy
    accuracy = sum(predictions == groundTruth) / length(groundTruth);
    performanceReport.overallAccuracy = accuracy;
    
    % Confusion matrix
    confusionMat = confusionmat(groundTruth, predictions);
    performanceReport.confusionMatrix = confusionMat;
    
    % Per-class metrics
    numClasses = length(classNames);
    performanceReport.classMetrics = struct();
    
    for i = 1:numClasses
        className = classNames{i};
        
        % True positives, false positives, false negatives
        tp = confusionMat(i, i);
        fp = sum(confusionMat(:, i)) - tp;
        fn = sum(confusionMat(i, :)) - tp;
        
        % Precision, recall, F1-score
        precision = tp / (tp + fp + eps);
        recall = tp / (tp + fn + eps);
        f1Score = 2 * (precision * recall) / (precision + recall + eps);
        
        performanceReport.classMetrics.*(className) = struct();
        performanceReport.classMetrics.*(className).precision = precision;
        performanceReport.classMetrics.*(className).recall = recall;
        performanceReport.classMetrics.*(className).f1Score = f1Score;
    end
    
    % Average metrics
    precisions = arrayfun(@(x) performanceReport.classMetrics.*(classNames{x}).precision, 1:numClasses);
    recalls = arrayfun(@(x) performanceReport.classMetrics.*(classNames{x}).recall, 1:numClasses);
    f1Scores = arrayfun(@(x) performanceReport.classMetrics.*(classNames{x}).f1Score, 1:numClasses);
    
    performanceReport.averagePrecision = mean(precisions);
    performanceReport.averageRecall = mean(recalls);
    performanceReport.averageF1Score = mean(f1Scores);
    
    fprintf('Performance analysis completed\n');
    fprintf('Overall accuracy: %.2f%%\n', accuracy * 100);
    fprintf('Average precision: %.2f%%\n', performanceReport.averagePrecision * 100);
    fprintf('Average recall: %.2f%%\n', performanceReport.averageRecall * 100);
    fprintf('Average F1-score: %.2f%%\n', performanceReport.averageF1Score * 100);
end
