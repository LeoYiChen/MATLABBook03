%% chapter_AI_CV_automated_inspection_01.m
% Comprehensive Automated Visual Inspection System for Manufacturing Quality Control
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_automated_inspection_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Comprehensive Automated Visual Inspection System
fprintf('Automated Visual Inspection System for Manufacturing\n');
fprintf('===================================================\n');

% Create synthetic manufacturing images for demonstration
[productImages, defectGroundTruth, productInfo] = createManufacturingDataset();








% 1. Image Preprocessing for Industrial Inspection

% 2. Feature-based Defect Detection



% 3. Template-based Defect Detection

% 4. Machine Learning-based Defect Classification




% 5. Comprehensive Quality Assessment

% 6. Automated Inspection System Integration


% Test the automated visual inspection system
fprintf('\nTesting automated visual inspection system...\n');

% Select reference image (first product as template)
referenceImage = productImages{1};

% Preprocess reference image
referenceImage = preprocessIndustrialImage(referenceImage);

% Run automated inspection on all products
inspectionOptions = struct();
inspectionOptions.preprocessImages = true;
inspectionOptions.detectionMethod = 'feature';
inspectionOptions.enableClassification = true;
inspectionOptions.generateReport = true;

inspectionResults = runAutomatedInspection(productImages, referenceImage, inspectionOptions);

% Visualise inspection results
figure;

% Show first few products with inspection results
numProductsToShow = min(8, length(productImages));

for i = 1:numProductsToShow
    subplot(2, 4, i);
    
    product = inspectionResults.products(i);
    imshow(product.image);
    
    % Overlay defect locations
    hold on;
    for j = 1:length(product.defects)
        defect = product.defects(j);
        
        % Color based on severity
        switch defect.severity
            case 'low'
                color = 'yellow';
            case 'medium'
                color = 'orange';
            case 'high'
                color = 'red';
            otherwise
                color = 'blue';
        end
        
        plot(defect.location(1), defect.location(2), 'o', ...
             'Color', color, 'MarkerSize', 10, 'LineWidth', 2);
    end
    hold off;
    
    % Title with quality status
    report = product.qualityReport;
    title(sprintf('Product %d: %s (%.1f)', i, report.status, report.qualityScore));
end

sgtitle('Automated Visual Inspection Results');

% Display system performance metrics
figure;

% Pass/fail distribution
subplot(2, 3, 1);
passFailData = [inspectionResults.summary.passCount, inspectionResults.summary.failCount];
pie(passFailData, {'Pass', 'Fail'});
title('Pass/Fail Distribution');

% Defect count histogram
subplot(2, 3, 2);
defectCounts = arrayfun(@(x) length(x.defects), inspectionResults.products);
histogram(defectCounts, 'BinWidth', 1);
xlabel('Number of Defects');
ylabel('Number of Products');
title('Defect Count Distribution');

% Quality score distribution
subplot(2, 3, 3);
qualityScores = arrayfun(@(x) x.qualityReport.qualityScore, inspectionResults.products);
histogram(qualityScores, 10);
xlabel('Quality Score');
ylabel('Number of Products');
title('Quality Score Distribution');

% Defect severity breakdown
subplot(2, 3, 4);
allSeverities = {};
for i = 1:length(inspectionResults.products)
    for j = 1:length(inspectionResults.products(i).defects)
        allSeverities{end+1} = inspectionResults.products(i).defects(j).severity;
    end
end

if ~isempty(allSeverities)
    [uniqueSeverities, ~, severityIndices] = unique(allSeverities);
    severityCounts = accumarray(severityIndices, 1);
    
    bar(severityCounts);
    set(gca, 'XTickLabel', uniqueSeverities);
    xlabel('Severity Level');
    ylabel('Count');
    title('Defect Severity Breakdown');
end

% Processing time analysis (simulated)
subplot(2, 3, 5);
processingTimes = 0.5 + 0.3 * randn(length(productImages), 1); % Simulated times
processingTimes = max(0.1, processingTimes); % Ensure positive
histogram(processingTimes, 10);
xlabel('Processing Time (seconds)');
ylabel('Number of Products');
title('Processing Time Distribution');

% System efficiency metrics
subplot(2, 3, 6);
metrics = [inspectionResults.summary.passRate * 100, ...
           100 - inspectionResults.summary.averageDefectsPerProduct * 10, ...
           85]; % Simulated detection accuracy
metricLabels = {'Pass Rate (%)', 'Efficiency (%)', 'Accuracy (%)'};

bar(metrics);
set(gca, 'XTickLabel', metricLabels);
ylabel('Percentage');
title('System Performance Metrics');

sgtitle('Automated Inspection System Performance Analysis');

% Technical summary and recommendations
fprintf('\nAutomated Visual Inspection System Summary:\n');
fprintf('==========================================\n');
fprintf('Dataset: %d products across multiple types\n', length(productImages));
fprintf('Detection methods: Feature-based and template matching\n');
fprintf('Classification: Rule-based defect categorisation\n');
fprintf('Quality assessment: Multi-criteria evaluation\n');

fprintf('\nSystem Performance:\n');
fprintf('  Overall pass rate: %.1f%%\n', inspectionResults.summary.passRate * 100);
fprintf('  Average processing time: %.2f seconds per product\n', mean(processingTimes));
fprintf('  Total defects detected: %d\n', inspectionResults.summary.totalDefects);

fprintf('\nIndustrial Implementation Considerations:\n');
fprintf('========================================\n');
fprintf('1. Lighting standardisation for consistent imaging\n');
fprintf('2. Camera calibration and maintenance protocols\n');
fprintf('3. Integration with production line control systems\n');
fprintf('4. Quality standards configuration and updates\n');
fprintf('5. Statistical process control and trend analysis\n');
fprintf('6. Operator training and system validation procedures\n');
fprintf('7. Backup and redundancy systems for critical applications\n');
fprintf('8. Continuous improvement through machine learning updates\n');

fprintf('\nBenefits of Automated Visual Inspection:\n');
fprintf('=======================================\n');
fprintf(' Consistent, objective quality assessment\n');
fprintf(' 24/7 operation capability\n');
fprintf(' Reduced labour costs and human error\n');
fprintf(' Comprehensive defect documentation\n');
fprintf(' Real-time quality feedback\n');
fprintf(' Integration with digital manufacturing systems\n');
fprintf(' Scalability across multiple production lines\n');
fprintf(' Data-driven quality improvement insights\n');

% Local functions (moved to end so this listing is a valid MATLAB script)
function [images, defects, info] = createManufacturingDataset()
    % Create synthetic manufacturing dataset with various product types and defects
    
    fprintf('Creating synthetic manufacturing inspection dataset...\n');
    
    numProducts = 50;
    imageSize = [400, 400];
    
    images = cell(numProducts, 1);
    defects = cell(numProducts, 1);
    info = struct();
    
    % Product types
    productTypes = {'circuit_board', 'metal_part', 'textile', 'pharmaceutical'};
    
    % Defect types
    defectTypes = {'scratch', 'spot', 'crack', 'discoloration', 'missing_component', 'contamination'};
    
    info.productTypes = productTypes;
    info.defectTypes = defectTypes;
    info.products = [];
    
    for i = 1:numProducts
        % Random product type
        productType = productTypes{randi(length(productTypes))};
        
        % Create base product image
        [productImage, productDefects] = createProductImage(imageSize, productType, defectTypes);
        
        images{i} = productImage;
        defects{i} = productDefects;
        
        % Store product information
        product = struct();
        product.id = i;
        product.type = productType;
        product.hasDefects = ~isempty(productDefects);
        product.numDefects = length(productDefects);
        info.products = [info.products; product];
    end
    
    fprintf('Created dataset: %d products with various defect types\n', numProducts);
end

function [image, defects] = createProductImage(imageSize, productType, defectTypes)
    % Create synthetic product image with potential defects
    
    image = zeros(imageSize, 'uint8');
    defects = [];
    
    switch productType
        case 'circuit_board'
            image = createCircuitBoard(imageSize);
            
        case 'metal_part'
            image = createMetalPart(imageSize);
            
        case 'textile'
            image = createTextile(imageSize);
            
        case 'pharmaceutical'
            image = createPharmaceutical(imageSize);
    end
    
    % Add random defects
    numDefects = randi([0, 3]); % 0 to 3 defects per product
    
    for i = 1:numDefects
        defectType = defectTypes{randi(length(defectTypes))};
        defect = addDefectToImage(image, defectType, imageSize);
        
        if ~isempty(defect)
            defects = [defects; defect];
        end
    end
end

function image = createCircuitBoard(imageSize)
    % Create synthetic circuit board image
    
    image = uint8(ones(imageSize) * 40); % Dark PCB background
    
    % Add circuit traces
    for trace = 1:20
        startX = randi(imageSize(2));
        startY = randi(imageSize(1));
        
        % Create horizontal or vertical trace
        if rand() > 0.5
            % Horizontal trace
            length = 50 + randi(100);
            endX = min(imageSize(2), startX + length);
            
            if startY > 2 && startY < imageSize(1) - 2
                image((startY-1):(startY+1), startX:endX) = 200; % Copper trace
            end
        else
            % Vertical trace
            length = 50 + randi(100);
            endY = min(imageSize(1), startY + length);
            
            if startX > 2 && startX < imageSize(2) - 2
                image(startY:endY, (startX-1):(startX+1)) = 200;
            end
        end
    end
    
    % Add components
    for comp = 1:15
        x = 10 + randi(imageSize(2) - 30);
        y = 10 + randi(imageSize(1) - 30);
        
        width = 8 + randi(15);
        height = 8 + randi(15);
        
        x2 = min(imageSize(2), x + width);
        y2 = min(imageSize(1), y + height);
        
        image(y:y2, x:x2) = 120; % Component body
    end
end

function image = createMetalPart(imageSize)
    % Create synthetic metal part image
    
    % Create metal surface with slight variations
    image = uint8(ones(imageSize) * 150 + 10 * randn(imageSize));
    
    % Add machined features
    centerX = imageSize(2) / 2;
    centerY = imageSize(1) / 2;
    
    % Central hole
    [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
    holeMask = (X - centerX).^2 + (Y - centerY).^2 <= 30^2;
    image(holeMask) = 50; % Dark hole
    
    % Mounting holes
    for hole = 1:4
        angle = (hole - 1) * pi / 2;
        holeX = centerX + 80 * cos(angle);
        holeY = centerY + 80 * sin(angle);
        
        holeMask = (X - holeX).^2 + (Y - holeY).^2 <= 8^2;
        image(holeMask) = 50;
    end
    
    % Surface finish lines
    for line = 1:imageSize(1)
        if mod(line, 3) == 0
            image(line, :) = image(line, :) + uint8(5 * sin((1:imageSize(2)) / 10));
        end
    end
end

function image = createTextile(imageSize)
    % Create synthetic textile image
    
    % Base weave pattern
    image = uint8(ones(imageSize) * 100);
    
    % Create weave pattern
    warpSpacing = 4;
    weftSpacing = 4;
    
    for y = 1:weftSpacing:imageSize(1)
        if y + 1 <= imageSize(1)
            image(y:(y+1), :) = 120; % Weft threads
        end
    end
    
    for x = 1:warpSpacing:imageSize(2)
        if x + 1 <= imageSize(2)
            image(:, x:(x+1)) = 130; % Warp threads
        end
    end
    
    % Add texture variation
    texture = uint8(5 * randn(imageSize));
    image = image + texture;
    
    % Ensure valid intensity range
    image = max(0, min(255, image));
end

function image = createPharmaceutical(imageSize)
    % Create synthetic pharmaceutical tablet image
    
    image = uint8(ones(imageSize) * 50); % Dark background
    
    % Create tablet shape (ellipse)
    centerX = imageSize(2) / 2;
    centerY = imageSize(1) / 2;
    
    [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
    
    tabletA = 80; % Semi-major axis
    tabletB = 60; % Semi-minor axis
    
    tabletMask = ((X - centerX) / tabletA).^2 + ((Y - centerY) / tabletB).^2 <= 1;
    
    % Tablet surface
    image(tabletMask) = 200; % White tablet
    
    % Add embossed text/logo
    logoMask = ((X - centerX) / 20).^2 + ((Y - centerY) / 20).^2 <= 1;
    image(logoMask & tabletMask) = 160; % Embossed region
    
    % Add slight shading for 3*D effect
    shadingGradient = (Y - centerY) / tabletB;
    shadingMask = tabletMask;
    shading = uint8(20 * shadingGradient);
    
    image(shadingMask) = image(shadingMask) + shading(shadingMask);
    image = max(0, min(255, image));
end

function defect = addDefectToImage(image, defectType, imageSize)
    % Add specific defect type to product image
    
    defect = struct();
    defect.type = defectType;
    
    % Random defect location
    x = 50 + randi(imageSize(2) - 100);
    y = 50 + randi(imageSize(1) - 100);
    
    defect.location = [x, y];
    
    switch defectType
        case 'scratch'
            % Linear scratch
            length = 20 + randi(40);
            angle = rand() * 2 * pi;
            
            endX = x + length * cos(angle);
            endY = y + length * sin(angle);
            
            % Ensure within bounds
            endX = max(1, min(imageSize(2), endX));
            endY = max(1, min(imageSize(1), endY));
            
            % Draw line (simplified)
            numPoints = round(length);
            xPoints = round(linspace(x, endX, numPoints));
            yPoints = round(linspace(y, endY, numPoints));
            
            for i = 1:length(xPoints)
                if xPoints(i) >= 1 && xPoints(i) <= imageSize(2) && ...
                   yPoints(i) >= 1 && yPoints(i) <= imageSize(1)
                    image(yPoints(i), xPoints(i)) = max(0, double(image(yPoints(i), xPoints(i))) - 50);
                end
            end
            
            defect.severity = 'medium';
            
        case 'spot'
            % Circular spot defect
            radius = 3 + randi(8);
            [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
            
            spotMask = (X - x).^2 + (Y - y).^2 <= radius^2;
            
            % Dark spot
            image(spotMask) = max(0, double(image(spotMask)) - 80);
            
            defect.radius = radius;
            defect.severity = 'low';
            
        case 'crack'
            % Irregular crack
            crackLength = 15 + randi(25);
            
            % Create jagged crack path
            currentX = x;
            currentY = y;
            
            for step = 1:crackLength
                % Random direction with bias
                direction = (rand() - 0.5) * 0.5; % Small random angle
                
                nextX = round(currentX + cos(direction));
                nextY = round(currentY + sin(direction));
                
                % Ensure within bounds
                nextX = max(1, min(imageSize(2), nextX));
                nextY = max(1, min(imageSize(1), nextY));
                
                image(nextY, nextX) = max(0, double(image(nextY, nextX)) - 60);
                
                currentX = nextX;
                currentY = nextY;
            end
            
            defect.severity = 'high';
            
        case 'discoloration'
            % Area of discoloration
            radius = 10 + randi(15);
            [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
            
            discolorMask = (X - x).^2 + (Y - y).^2 <= radius^2;
            
            % Apply discoloration
            colorShift = 30 + randi(30);
            image(discolorMask) = min(255, double(image(discolorMask)) + colorShift);
            
            defect.radius = radius;
            defect.severity = 'medium';
            
        case 'missing_component'
            % Missing component (dark rectangular region)
            width = 8 + randi(12);
            height = 8 + randi(12);
            
            x1 = max(1, x - width/2);
            x2 = min(imageSize(2), x + width/2);
            y1 = max(1, y - height/2);
            y2 = min(imageSize(1), y + height/2);
            
            image(round(y1):round(y2), round(x1):round(x2)) = 30; % Dark missing area
            
            defect.dimensions = [width, height];
            defect.severity = 'high';
            
        case 'contamination'
            % Foreign particles
            numParticles = 3 + randi(5);
            
            for particle = 1:numParticles
                particleX = x + randi([-10, 10]);
                particleY = y + randi([-10, 10]);
                
                % Ensure within bounds
                particleX = max(1, min(imageSize(2), particleX));
                particleY = max(1, min(imageSize(1), particleY));
                
                particleSize = 1 + randi(3);
                [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
                
                particleMask = (X - particleX).^2 + (Y - particleY).^2 <= particleSize^2;
                
                % Bright contamination
                image(particleMask) = min(255, double(image(particleMask)) + 80);
            end
            
            defect.numParticles = numParticles;
            defect.severity = 'medium';
    end
end

function preprocessedImage = preprocessIndustrialImage(image, options)
    % Preprocess industrial images for optimal inspection performance
    
    if nargin < 2
        options = struct();
        options.enhanceContrast = true;
        options.reduceNoise = true;
        options.normalizeIllumination = true;
        options.sharpenEdges = false;
    end
    
    fprintf('Preprocessing industrial image for inspection...\n');
    
    preprocessedImage = double(image);
    
    % Noise reduction
    if options.reduceNoise
        % Median filter for impulse noise
        preprocessedImage = medfilt2(preprocessedImage, [3, 3]);
        
        % Gaussian filter for general noise reduction
        preprocessedImage = imgaussfilt(preprocessedImage, 0.5);
    end
    
    % Illumination normalisation
    if options.normalizeIllumination
        % Estimate background illumination
        background = imgaussfilt(preprocessedImage, 50);
        
        % Correct for uneven illumination
        preprocessedImage = preprocessedImage ./ (background + eps) * mean(background(:));
    end
    
    % Contrast enhancement
    if options.enhanceContrast
        % Adaptive histogram equalisation
        preprocessedImage = uint8(preprocessedImage);
        preprocessedImage = adapthisteq(preprocessedImage);
        preprocessedImage = double(preprocessedImage);
    end
    
    % Edge sharpening
    if options.sharpenEdges
        sharpenKernel = [0 -1 0; -1 5 -1; 0 -1 0];
        preprocessedImage = imfilter(preprocessedImage, sharpenKernel, 'same');
    end
    
    % Ensure valid intensity range
    preprocessedImage = max(0, min(255, preprocessedImage));
    preprocessedImage = uint8(preprocessedImage);
    
    fprintf('Image preprocessing completed\n');
end

function defects = detectDefectsFeatureBased(image, referenceImage, detectionParams)
    % Detect defects using feature-based comparison with reference
    
    if nargin < 3
        detectionParams = struct();
        detectionParams.featureType = 'SURF';
        detectionParams.matchThreshold = 0.6;
        detectionParams.geometricThreshold = 2.0;
    end
    
    fprintf('Detecting defects using feature-based analysis...\n');
    
    defects = [];
    
    try
        % Extract features from both images
        if strcmp(detectionParams.featureType, 'SURF')
            refPoints = detectSURFFeatures(referenceImage);
            testPoints = detectSURFFeatures(image);
            
            [refFeatures, refValidPoints] = extractFeatures(referenceImage, refPoints);
            [testFeatures, testValidPoints] = extractFeatures(image, testPoints);
            
        else
            % Alternative feature detection methods could be added here
            error('Unsupported feature type: %s', detectionParams.featureType);
        end
        
        % Match features between reference and test images
        if size(refFeatures, 1) > 0 && size(testFeatures, 1) > 0
            indexPairs = matchFeatures(refFeatures, testFeatures, ...
                'Unique', true, 'MaxRatio', detectionParams.matchThreshold);
            
            if size(indexPairs, 1) >= 4
                % Extract matched points
                matchedRefPoints = refValidPoints(indexPairs(:, 1), :);
                matchedTestPoints = testValidPoints(indexPairs(:, 2), :);
                
                % Estimate geometric transformation
                [tform, inlierIdx] = estimateGeometricTransform(matchedTestPoints, matchedRefPoints, ...
                    'projective', 'MaxDistance', detectionParams.geometricThreshold);
                
                % Identify unmatched regions as potential defects
                defects = identifyUnmatchedRegions(image, referenceImage, tform, testValidPoints, inlierIdx);
            end
        end
        
    catch ME
        fprintf('Feature-based detection failed: %s\n', ME.message);
        fprintf('Falling back to template matching approach\n');
        defects = detectDefectsTemplateBased(image, referenceImage);
    end
    
    fprintf('Feature-based defect detection completed\n');
end

function defects = identifyUnmatchedRegions(testImage, refImage, tform, testPoints, inlierIdx)
    % Identify regions with poor feature matching as potential defects
    
    defects = [];
    
    % Transform reference image to align with test image
    outputView = imref2d(size(testImage));
    alignedRef = imwarp(refImage, tform, 'OutputView', outputView);
    
    % Compute difference image
    diffImage = abs(double(testImage) - double(alignedRef));
    
    % Threshold to find significant differences
    threshold = mean(diffImage(:)) + 2 * std(diffImage(:));
    defectMask = diffImage > threshold;
    
    % Remove small regions
    defectMask = bwareaopen(defectMask, 50);
    
    % Find connected components
    cc = bwconncomp(defectMask);
    stats = regionprops(cc, 'Area', 'Centroid', 'BoundingBox');
    
    for i = 1:length(stats)
        defect = struct();
        defect.type = 'unmatched_region';
        defect.location = stats(i).Centroid;
        defect.area = stats(i).Area;
        defect.boundingBox = stats(i).BoundingBox;
        defect.severity = categorizeDefectSeverity(stats(i).Area);
        
        defects = [defects; defect];
    end
end

function severity = categorizeDefectSeverity(area)
    % Categorise defect severity based on area
    
    if area < 100
        severity = 'low';
    elseif area < 500
        severity = 'medium';
    else
        severity = 'high';
    end
end

function defects = detectDefectsTemplateBased(image, referenceTemplate)
    % Detect defects using template matching approach
    
    fprintf('Detecting defects using template matching...\n');
    
    defects = [];
    
    % Perform normalised cross-correlation
    correlation = normxcorr2(referenceTemplate, image);
    
    % Find regions with poor correlation (potential defects)
    correlationThreshold = 0.7;
    poorCorrelation = correlation < correlationThreshold;
    
    % Remove border artifacts from cross-correlation
    [templateHeight, templateWidth] = size(referenceTemplate);
    poorCorrelation(1:templateHeight, :) = false;
    poorCorrelation(:, 1:templateWidth) = false;
    poorCorrelation((end-templateHeight+1):end, :) = false;
    poorCorrelation(:, (end-templateWidth+1):end) = false;
    
    % Find connected components of poor correlation
    cc = bwconncomp(poorCorrelation);
    stats = regionprops(cc, 'Area', 'Centroid', 'BoundingBox');
    
    for i = 1:length(stats)
        if stats(i).Area > 50 % Minimum defect size
            defect = struct();
            defect.type = 'template_mismatch';
            defect.location = stats(i).Centroid;
            defect.area = stats(i).Area;
            defect.severity = categorizeDefectSeverity(stats(i).Area);
            
            defects = [defects; defect];
        end
    end
    
    fprintf('Template-based defect detection completed\n');
end

function [classifications, confidence] = classifyDefects(image, detectedDefects, classificationModel)
    % Classify detected defects using machine learning
    
    fprintf('Classifying %d detected defects...\n', length(detectedDefects));
    
    classifications = cell(length(detectedDefects), 1);
    confidence = zeros(length(detectedDefects), 1);
    
    for i = 1:length(detectedDefects)
        defect = detectedDefects(i);
        
        % Extract defect region
        defectRegion = extractDefectRegion(image, defect);
        
        % Extract features for classification
        features = extractDefectFeatures(defectRegion);
        
        % Classify defect (simplified rule-based classifier)
        [classification, conf] = classifyDefectType(features);
        
        classifications{i} = classification;
        confidence(i) = conf;
    end
    
    fprintf('Defect classification completed\n');
end

function region = extractDefectRegion(image, defect)
    % Extract region around defect for analysis
    
    centerX = round(defect.location(1));
    centerY = round(defect.location(2));
    
    % Define extraction window
    windowSize = 64;
    halfWindow = windowSize / 2;
    
    x1 = max(1, centerX - halfWindow);
    x2 = min(size(image, 2), centerX + halfWindow);
    y1 = max(1, centerY - halfWindow);
    y2 = min(size(image, 1), centerY + halfWindow);
    
    region = image(round(y1):round(y2), round(x1):round(x2));
end

function features = extractDefectFeatures(region)
    % Extract features from defect region for classification
    
    features = struct();
    
    % Intensity features
    features.meanIntensity = mean(region(:));
    features.stdIntensity = std(double(region(:)));
    features.minIntensity = double(min(region(:)));
    features.maxIntensity = double(max(region(:)));
    
    % Texture features
    if numel(region) > 1
        features.entropy = entropy(region);
    else
        features.entropy = 0;
    end
    
    % Shape features (simplified)
    features.area = numel(region);
    features.aspectRatio = size(region, 2) / size(region, 1);
    
    % Edge features
    edges = edge(region, 'canny');
    features.edgeDensity = sum(edges(:)) / numel(edges);
end

function [classification, confidence] = classifyDefectType(features)
    % Simple rule-based defect classification
    
    % Classification based on feature values
    if features.meanIntensity < 50
        classification = 'dark_defect';
        confidence = 0.8;
    elseif features.meanIntensity > 200
        classification = 'bright_defect';  
        confidence = 0.8;
    elseif features.edgeDensity > 0.1
        classification = 'edge_defect';
        confidence = 0.7;
    elseif features.entropy < 2
        classification = 'uniform_defect';
        confidence = 0.6;
    else
        classification = 'unknown_defect';
        confidence = 0.4;
    end
end

function qualityReport = performQualityAssessment(image, detectedDefects, classifications, qualityStandards)
    % Perform comprehensive quality assessment
    
    if nargin < 4
        qualityStandards = struct();
        qualityStandards.maxDefects = 2;
        qualityStandards.maxHighSeverity = 0;
        qualityStandards.maxTotalArea = 1000;
    end
    
    fprintf('Performing comprehensive quality assessment...\n');
    
    qualityReport = struct();
    qualityReport.totalDefects = length(detectedDefects);
    qualityReport.defectTypes = classifications;
    
    % Count defects by severity
    severityCounts = struct('low', 0, 'medium', 0, 'high', 0);
    totalDefectArea = 0;
    
    for i = 1:length(detectedDefects)
        severity = detectedDefects(i).severity;
        severityCounts.*(severity) = severityCounts.*(severity) + 1;
        
        if isfield(detectedDefects(i), 'area')
            totalDefectArea = totalDefectArea + detectedDefects(i).area;
        end
    end
    
    qualityReport.severityCounts = severityCounts;
    qualityReport.totalDefectArea = totalDefectArea;
    
    % Determine overall quality status
    qualityReport.passesInspection = true;
    qualityReport.failureReasons = {};
    
    if qualityReport.totalDefects > qualityStandards.maxDefects
        qualityReport.passesInspection = false;
        qualityReport.failureReasons{end+1} = 'Too many defects';
    end
    
    if severityCounts.high > qualityStandards.maxHighSeverity
        qualityReport.passesInspection = false;
        qualityReport.failureReasons{end+1} = 'High severity defects present';
    end
    
    if totalDefectArea > qualityStandards.maxTotalArea
        qualityReport.passesInspection = false;
        qualityReport.failureReasons{end+1} = 'Excessive defect area';
    end
    
    % Calculate quality score (0-100)
    baseScore = 100;
    
    % Penalties for defects
    defectPenalty = qualityReport.totalDefects * 10;
    severityPenalty = severityCounts.medium * 5 + severityCounts.high * 20;
    areaPenalty = min(50, totalDefectArea / 100);
    
    qualityReport.qualityScore = max(0, baseScore - defectPenalty - severityPenalty - areaPenalty);
    
    if qualityReport.passesInspection
        qualityReport.status = 'PASS';
    else
        qualityReport.status = 'FAIL';
    end
    
    fprintf('Quality assessment completed: %s (Score: %.1f)\n', ...
        qualityReport.status, qualityReport.qualityScore);
end

function inspectionResults = runAutomatedInspection(productImages, referenceImage, options)
    % Run complete automated inspection pipeline
    
    if nargin < 3
        options = struct();
        options.preprocessImages = true;
        options.detectionMethod = 'feature';
        options.enableClassification = true;
        options.generateReport = true;
    end
    
    fprintf('Running automated inspection on %d products...\n', length(productImages));
    
    inspectionResults = struct();
    inspectionResults.products = [];
    inspectionResults.summary = struct();
    
    passCount = 0;
    failCount = 0;
    totalDefects = 0;
    
    for i = 1:length(productImages)
        fprintf('\nInspecting product %d...\n', i);
        
        image = productImages{i};
        
        % Preprocessing
        if options.preprocessImages
            image = preprocessIndustrialImage(image);
        end
        
        % Defect detection
        switch options.detectionMethod
            case 'feature'
                defects = detectDefectsFeatureBased(image, referenceImage);
            case 'template'
                defects = detectDefectsTemplateBased(image, referenceImage);
            otherwise
                defects = detectDefectsFeatureBased(image, referenceImage);
        end
        
        % Defect classification
        if options.enableClassification && ~isempty(defects)
            [classifications, confidence] = classifyDefects(image, defects, []);
        else
            classifications = {};
            confidence = [];
        end
        
        % Quality assessment
        qualityReport = performQualityAssessment(image, defects, classifications);
        
        % Store results
        productResult = struct();
        productResult.productId = i;
        productResult.image = image;
        productResult.defects = defects;
        productResult.classifications = classifications;
        productResult.confidence = confidence;
        productResult.qualityReport = qualityReport;
        
        inspectionResults.products = [inspectionResults.products; productResult];
        
        % Update summary statistics
        totalDefects = totalDefects + length(defects);
        
        if qualityReport.passesInspection
            passCount = passCount + 1;
        else
            failCount = failCount + 1;
        end
    end
    
    % Generate summary report
    inspectionResults.summary.totalProducts = length(productImages);
    inspectionResults.summary.passCount = passCount;
    inspectionResults.summary.failCount = failCount;
    inspectionResults.summary.passRate = passCount / length(productImages);
    inspectionResults.summary.totalDefects = totalDefects;
    inspectionResults.summary.averageDefectsPerProduct = totalDefects / length(productImages);
    
    if options.generateReport
        generateInspectionReport(inspectionResults);
    end
    
    fprintf('\nAutomated inspection completed\n');
end

function generateInspectionReport(results)
    % Generate comprehensive inspection report
    
    fprintf('\n' + string(repmat('=', 1, 60)) + '\n');
    fprintf('AUTOMATED VISUAL INSPECTION REPORT\n');
    fprintf(string(repmat('=', 1, 60)) + '\n');
    
    summary = results.summary;
    
    fprintf('SUMMARY STATISTICS:\n');
    fprintf('  Total products inspected: %d\n', summary.totalProducts);
    fprintf('  Products passed: %d\n', summary.passCount);
    fprintf('  Products failed: %d\n', summary.failCount);
    fprintf('  Pass rate: %.1f%%\n', summary.passRate * 100);
    fprintf('  Total defects detected: %d\n', summary.totalDefects);
    fprintf('  Average defects per product: %.1f\n', summary.averageDefectsPerProduct);
    
    fprintf('\nDETAILED RESULTS:\n');
    
    for i = 1:length(results.products)
        product = results.products(i);
        report = product.qualityReport;
        
        fprintf('  Product %d: %s (Score: %.1f, Defects: %d)\n', ...
            product.productId, report.status, report.qualityScore, report.totalDefects);
        
        if ~isempty(product.defects)
            for j = 1:length(product.defects)
                defect = product.defects(j);
                fprintf('    - %s defect at (%.1f, %.1f), severity: %s\n', ...
                    defect.type, defect.location(1), defect.location(2), defect.severity);
            end
        end
    end
    
    fprintf('\n' + string(repmat('=', 1, 60)) + '\n');
end

% Local function copied from another listing in this chapter
function matches = matchFeatures(descriptors1, descriptors2, points1, points2, threshold)
% Find matches between feature descriptors using nearest neighbor ratio test

 
if isempty(descriptors1) || isempty(descriptors2)
    matches = [];
    return;
end

matches = [];

for i = 1:size(descriptors1, 1)
    desc1 = descriptors1(i, :);
    
    % Compute distances to all descriptors in second image
    distances = sqrt(sum((descriptors2 - desc1).^2, 2));
    
    % Find two nearest neighbors
    [sortedDist, sortedIdx] = sort(distances);
    
    if length(sortedDist) >= 2
        % Ratio test for distinctive matches
        ratio = sortedDist(1) / sortedDist(2);
        
        if ratio < threshold && sortedDist(1) < 0.5 % Additional distance threshold
            matches(end+1, :) = [i, sortedIdx(1), sortedDist(1), ratio];
        end
    end
end
end
