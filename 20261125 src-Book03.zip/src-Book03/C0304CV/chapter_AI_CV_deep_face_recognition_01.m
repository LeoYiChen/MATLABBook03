%% chapter_AI_CV_deep_face_recognition_01.m
% Deep Learning Face Recognition System Implementation
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_deep_face_recognition_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Deep Learning Face Recognition System
fprintf('Deep Learning Face Recognition System\n');
fprintf('====================================\n');

% Create face recognition dataset
[faceDataset, identityLabels] = createFaceRecognitionDataset();





% 1. Deep CNN Architecture for Face Recognition

% Create deep face recognition network
inputSize = [64, 64, 3];
numIdentities = 10;
faceRecognitionNet = createDeepFaceNetwork(inputSize, numIdentities);

% 2. Face Feature Extraction and Embedding

% 3. Triplet Loss Implementation for Metric Learning

% 4. Face Verification and Identification


% 5. Evaluation Metrics for Face Recognition

% 6. Comprehensive Face Recognition System

% Create face recognition system
faceSystem = createFaceRecognitionSystem(faceDataset, identityLabels);

% 7. Testing and Evaluation

% Create test set (using subset of original data)
testSize = 20;
testIndices = randperm(size(faceDataset, 4), testSize);
testImages = faceDataset(:, :, :, testIndices);
testLabels = identityLabels(testIndices);

% Test the system
systemTestResults = testFaceRecognitionSystem(faceSystem, testImages, testLabels);

% 8. Advanced Features and Analysis

% Perform advanced analysis
advancedResults = performAdvancedAnalysis(faceSystem, systemTestResults);

% 9. Visualization and Reporting

% Visualize results
visualizeFaceRecognitionResults(faceSystem, systemTestResults, advancedResults);

% 10. System Summary and Recommendations
fprintf('\nFace Recognition System Summary:\n');
fprintf('===============================\n');
fprintf('Dataset: %d identities, %d total images\n', faceSystem.numIdentities, length(faceSystem.galleryLabels));
fprintf('Network: %d-layer deep CNN\n', length(faceSystem.network.Layers));
fprintf('Feature dimension: %d\n', size(faceSystem.galleryFeatures, 1));
fprintf('Test accuracy: %.1f%%\n', systemTestResults.accuracy * 100);

fprintf('\nDeep Learning Face Recognition Advantages:\n');
fprintf('=========================================\n');
fprintf('1. End-to-end learning from raw pixel data\n');
fprintf('2. Automatic feature discovery and optimization\n');
fprintf('3. Superior performance on large-scale datasets\n');
fprintf('4. Robust to variations in pose, lighting, and expression\n');
fprintf('5. Scalable to millions of identities\n');

fprintf('\nChallenges and Considerations:\n');
fprintf('=============================\n');
fprintf('1. Requires large amounts of training data\n');
fprintf('2. Computational requirements for training and inference\n');
fprintf('3. Potential for demographic bias\n');
fprintf('4. Privacy and security concerns\n');
fprintf('5. Adversarial attack vulnerabilities\n');

fprintf('\nBest Practices for Deep Face Recognition:\n');
fprintf('=======================================\n');
fprintf('1. Use diverse and representative training datasets\n');
fprintf('2. Implement bias evaluation and mitigation strategies\n');
fprintf('3. Apply appropriate data augmentation techniques\n');
fprintf('4. Regular performance monitoring across demographics\n');
fprintf('5. Implement liveness detection for security\n');
fprintf('6. Consider privacy-preserving techniques\n');
fprintf('7. Continuous system updates and improvements\n');
fprintf('8. Compliance with relevant regulations and ethics guidelines\n');

% Future directions and research trends
fprintf('\nFuture Directions in Face Recognition:\n');
fprintf('====================================\n');
fprintf('1. Self-supervised learning to reduce annotation requirements\n');
fprintf('2. Federated learning for privacy-preserving training\n');
fprintf('3. Continual learning for adapting to new identities\n');
fprintf('4. Multimodal fusion with other biometric modalities\n');
fprintf('5. Edge computing optimization for mobile deployment\n');
fprintf('6. Explainable AI for interpretable recognition decisions\n');
fprintf('7. Synthetic data generation for data augmentation\n');
fprintf('8. Advanced adversarial robustness techniques\n');

% Local functions (moved to end so this listing is a valid MATLAB script)
function [dataset, labels] = createFaceRecognitionDataset()
    % Create synthetic face dataset for recognition training/testing
    
    fprintf('Creating face recognition dataset...\n');
    
    numIdentities = 10;
    samplesPerIdentity = 5;
    imageSize = [64, 64, 3]; % Reduced size for computational efficiency
    
    totalSamples = numIdentities * samplesPerIdentity;
    dataset = zeros([imageSize, totalSamples], 'single');
    labels = zeros(totalSamples, 1);
    
    sampleIdx = 1;
    
    for identity = 1:numIdentities
        % Generate face variations for this identity
        baseFace = generateBaseFace(imageSize, identity);
        
        for sample = 1:samplesPerIdentity
            % Create variations (pose, lighting, expression)
            variation = struct();
            variation.pose = (rand() - 0.5) * 0.3; % ㊣0.15 rad rotation
            variation.lighting = 0.7 + rand() * 0.6; % 0.7 to 1.3 lighting
            variation.expression = rand() > 0.5; % Random expression change
            variation.noise = 0.05; % Noise level
            
            faceImage = applyFaceVariations(baseFace, variation);
            
            dataset(:, :, :, sampleIdx) = faceImage;
            labels(sampleIdx) = identity;
            sampleIdx = sampleIdx + 1;
        end
    end
    
    fprintf('Created dataset: %d identities, %d samples per identity\n', ...
        numIdentities, samplesPerIdentity);
end

function baseFace = generateBaseFace(imageSize, identityID)
    % Generate base face image for specific identity
    
    baseFace = zeros(imageSize, 'single');
    
    % Use identity ID to create consistent but different faces
    rng(identityID * 42); % Consistent random seed for each identity
    
    % Face shape parameters based on identity
    faceWidth = 25 + mod(identityID, 10) * 2;
    faceHeight = 35 + mod(identityID, 8) * 2;
    centerX = imageSize(2) / 2;
    centerY = imageSize(1) / 2;
    
    [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
    
    % Face region
    faceRegion = ((X - centerX) / faceWidth).^2 + ((Y - centerY) / faceHeight).^2 <= 1;
    
    % Skin color based on identity
    skinTone = [0.8, 0.6, 0.4] + 0.2 * [sin(identityID), cos(identityID), sin(identityID*2)];
    skinTone = max(0.3, min(0.9, skinTone));
    
    for c = 1:3
        channel = baseFace(:, :, c);
        channel(faceRegion) = skinTone(c);
        baseFace(:, :, c) = channel;
    end
    
    % Add facial features with identity-specific characteristics
    baseFace = addIdentityFeatures(baseFace, identityID, centerX, centerY, faceWidth, faceHeight);
    
    % Reset random seed
    rng('shuffle');
end

function faceImage = addIdentityFeatures(faceImage, identityID, centerX, centerY, faceWidth, faceHeight)
    % Add identity-specific facial features
    
    [imageHeight, imageWidth, ~] = size(faceImage);
    
    % Eyes - position and size vary by identity
    eyeY = centerY - faceHeight * 0.2;
    eyeSpacing = faceWidth * (0.4 + 0.2 * sin(identityID));
    leftEyeX = centerX - eyeSpacing / 2;
    rightEyeX = centerX + eyeSpacing / 2;
    
    eyeSize = 3 + mod(identityID, 4); % Eye size varies by identity
    
    [X, Y] = meshgrid(1:imageWidth, 1:imageHeight);
    
    % Left eye
    leftEyeMask = (X - leftEyeX).^2 + (Y - eyeY).^2 <= eyeSize^2;
    faceImage(leftEyeMask) = 0.1; % Dark eyes
    
    % Right eye
    rightEyeMask = (X - rightEyeX).^2 + (Y - eyeY).^2 <= eyeSize^2;
    faceImage(rightEyeMask) = 0.1;
    
    % Nose - shape varies by identity
    noseWidth = 2 + mod(identityID, 3);
    noseHeight = 4 + mod(identityID, 3);
    noseY = centerY - faceHeight * 0.05;
    
    noseMask = ((X - centerX) / noseWidth).^2 + ((Y - noseY) / noseHeight).^2 <= 1;
    for c = 1:3
        channel = faceImage(:, :, c);
        channel(noseMask) = max(0, channel(noseMask) - 0.1); % Slightly darker nose
        faceImage(:, :, c) = channel;
    end
    
   % Mouth - size varies by identity
    mouthY = centerY + faceHeight * 0.25;
    mouthWidth = 8 + mod(identityID, 5);
    mouthHeight = 2 + mod(identityID, 2);
    
    mouthMask = ((X - centerX) / mouthWidth).^2 + ((Y - mouthY) / mouthHeight).^2 <= 1;
    faceImage(mouthMask) = 0.2; % Dark mouth
end

function variedFace = applyFaceVariations(baseFace, variation)
    % Apply variations to create different samples of same identity
    
    variedFace = baseFace;
    
    % Apply lighting variation
    variedFace = variedFace * variation.lighting;
    
    % Apply pose variation (simplified rotation)
    if abs(variation.pose) > 0.01
        tform = affine2d([cos(variation.pose), -sin(variation.pose), 0; ...
                         sin(variation.pose), cos(variation.pose), 0; ...
                         0, 0, 1]);
        
        for c = 1:size(variedFace, 3)
            variedFace(:, :, c) = imwarp(variedFace(:, :, c), tform, ...
                'OutputView', imref2d(size(variedFace(:, :, 1))));
        end
    end
    
    % Apply expression variation (slight geometric changes)
    if variation.expression
        % Slightly modify mouth region
        [height, width, ~] = size(variedFace);
        centerY = height / 2;
        mouthRegion = (centerY + height * 0.2):(centerY + height * 0.3);
        
        if max(mouthRegion) <= height
            mouthRegion = round(mouthRegion);
            mouthRegion = mouthRegion(mouthRegion >= 1 & mouthRegion <= height);
            variedFace(mouthRegion, :, :) = variedFace(mouthRegion, :, :) * 0.9;
        end
    end
    
    % Add noise
    noise = variation.noise * randn(size(variedFace));
    variedFace = variedFace + noise;
    
    % Ensure valid range
    variedFace = max(0, min(1, variedFace));
end

function deepFaceNet = createDeepFaceNetwork(inputSize, numIdentities)
    % Create deep CNN architecture for face recognition
    
    fprintf('Creating deep face recognition network...\n');
    
    layers = [
        imageInputLayer(inputSize, 'Name', 'input')
        
        % First convolutional block
        convolution2dLayer(3, 32, 'Padding', 'same', 'Name', 'conv1_1')
        batchNormalizationLayer('Name', 'bn1_1')
        reluLayer('Name', 'relu1_1')
        convolution2dLayer(3, 32, 'Padding', 'same', 'Name', 'conv1_2')
        batchNormalizationLayer('Name', 'bn1_2')
        reluLayer('Name', 'relu1_2')
        maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool1')
        
        % Second convolutional block
        convolution2dLayer(3, 64, 'Padding', 'same', 'Name', 'conv2_1')
        batchNormalizationLayer('Name', 'bn2_1')
        reluLayer('Name', 'relu2_1')
        convolution2dLayer(3, 64, 'Padding', 'same', 'Name', 'conv2_2')
        batchNormalizationLayer('Name', 'bn2_2')
        reluLayer('Name', 'relu2_2')
        maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool2')
        
        % Third convolutional block
        convolution2dLayer(3, 128, 'Padding', 'same', 'Name', 'conv3_1')
        batchNormalizationLayer('Name', 'bn3_1')
        reluLayer('Name', 'relu3_1')
        convolution2dLayer(3, 128, 'Padding', 'same', 'Name', 'conv3_2')
        batchNormalizationLayer('Name', 'bn3_2')
        reluLayer('Name', 'relu3_2')
        maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool3')
        
        % Fourth convolutional block
        convolution2dLayer(3, 256, 'Padding', 'same', 'Name', 'conv4_1')
        batchNormalizationLayer('Name', 'bn4_1')
        reluLayer('Name', 'relu4_1')
        convolution2dLayer(3, 256, 'Padding', 'same', 'Name', 'conv4_2')
        batchNormalizationLayer('Name', 'bn4_2')
        reluLayer('Name', 'relu4_2')
        maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool4')
        
        % Feature embedding layers
        fullyConnectedLayer(512, 'Name', 'fc1')
        batchNormalizationLayer('Name', 'bn_fc1')
        reluLayer('Name', 'relu_fc1')
        dropoutLayer(0.5, 'Name', 'dropout1')
        
        fullyConnectedLayer(128, 'Name', 'embedding') % Feature embedding
        batchNormalizationLayer('Name', 'bn_embedding')
        
        % Classification layer
        fullyConnectedLayer(numIdentities, 'Name', 'fc_classifier')
        softmaxLayer('Name', 'softmax')
        classificationLayer('Name', 'output')
    ];
    
    deepFaceNet = layerGraph(layers);
    
    fprintf('Deep face network created with %d layers\n', length(layers));
end

function features = extractFaceFeatures(network, images, layerName)
    % Extract deep features from face images
    
    if nargin < 3
        layerName = 'embedding'; % Default to embedding layer
    end
    
    fprintf('Extracting face features from %s layer...\n', layerName);
    
    try
        % Extract features using activations
        features = activations(network, images, layerName, 'OutputAs', 'columns');
        
        % Normalize features (L2 normalization)
        features = features ./ (vecnorm(features, 2, 1) + eps);
        
        fprintf('Extracted %d-dimensional features for %d images\n', ...
            size(features, 1), size(features, 2));
        
    catch ME
        fprintf('Feature extraction failed: %s\n', ME.message);
        fprintf('Using random features for demonstration\n');
        
        % Generate random features as fallback
        featureDim = 128;
        numImages = size(images, 4);
        features = randn(featureDim, numImages, 'single');
        features = features ./ vecnorm(features, 2, 1);
    end
end

function tripletLoss = computeTripletLoss(anchorFeatures, positiveFeatures, negativeFeatures, margin)
    % Compute triplet loss for metric learning
    
    if nargin < 4
        margin = 0.2;
    end
    
    % Compute distances
    posDistance = vecnorm(anchorFeatures - positiveFeatures, 2, 1);
    negDistance = vecnorm(anchorFeatures - negativeFeatures, 2, 1);
    
    % Triplet loss: max(0, d(a,p) - d(a,n) + margin)
    tripletLoss = max(0, posDistance - negDistance + margin);
    tripletLoss = mean(tripletLoss);
    
    fprintf('Triplet loss: %.4f (margin: %.2f)\n', tripletLoss, margin);
end

function verificationResult = verifyFaces(features1, features2, threshold)
    % Verify if two face feature vectors belong to same identity
    
    if nargin < 3
        threshold = 0.6; % Cosine similarity threshold
    end
    
    % Compute cosine similarity
    similarity = dot(features1, features2) / (norm(features1) * norm(features2));
    
    % Verification decision
    isMatch = similarity >= threshold;
    confidence = abs(similarity - threshold) / threshold;
    
    verificationResult = struct();
    verificationResult.similarity = similarity;
    verificationResult.isMatch = isMatch;
    verificationResult.confidence = confidence;
    verificationResult.threshold = threshold;
    
    fprintf('Face verification: similarity=%.3f, match=%s, confidence=%.3f\n', ...
        similarity, mat2str(isMatch), confidence);
end

function identificationResult = identifyFace(queryFeatures, galleryFeatures, galleryLabels, topK)
    % Identify face against gallery of known identities
    
    if nargin < 4
        topK = 5;
    end
    
    fprintf('Performing face identification against %d gallery images...\n', size(galleryFeatures, 2));
    
    % Compute similarities with all gallery images
    similarities = queryFeatures' * galleryFeatures;
    
    % Sort by similarity
    [sortedSimilarities, sortedIndices] = sort(similarities, 'descend');
    
    % Get top-K results
    topKIndices = sortedIndices(1:min(topK, length(sortedIndices)));
    topKSimilarities = sortedSimilarities(1:min(topK, length(sortedSimilarities)));
    topKLabels = galleryLabels(topKIndices);
    
    identificationResult = struct();
    identificationResult.topKIndices = topKIndices;
    identificationResult.topKSimilarities = topKSimilarities;
    identificationResult.topKLabels = topKLabels;
    identificationResult.queryFeatures = queryFeatures;
    
    fprintf('Top identification results:\n');
    for i = 1:min(3, length(topKLabels))
        fprintf('  Rank %d: Identity %d (similarity: %.3f)\n', ...
            i, topKLabels(i), topKSimilarities(i));
    end
end

function metrics = evaluateFaceRecognition(predictions, groundTruth, similarities, thresholds)
    % Comprehensive evaluation of face recognition performance
    
    fprintf('Evaluating face recognition performance...\n');
    
    metrics = struct();
    
    % Accuracy metrics
    if nargin >= 2 && ~isempty(predictions) && ~isempty(groundTruth)
        accuracy = sum(predictions == groundTruth) / length(groundTruth);
        metrics.accuracy = accuracy;
        
        % Confusion matrix for multi-class
        uniqueLabels = unique([predictions; groundTruth]);
        confusionMat = confusionmat(groundTruth, predictions, 'Order', uniqueLabels);
        metrics.confusionMatrix = confusionMat;
        
        fprintf('Classification accuracy: %.3f\n', accuracy);
    end
    
    % Verification metrics (ROC analysis)
    if nargin >= 4 && ~isempty(similarities) && ~isempty(thresholds)
        numThresholds = length(thresholds);
        TPR = zeros(numThresholds, 1); % True Positive Rate
        FPR = zeros(numThresholds, 1); % False Positive Rate
        
        % Assume binary labels: 1 for genuine pairs, 0 for impostor pairs
        genuineMask = groundTruth == 1;
        impostorMask = groundTruth == 0;
        
        for i = 1:numThresholds
            threshold = thresholds(i);
            predictions_binary = similarities >= threshold;
            
            % True positives and false positives
            TP = sum(predictions_binary & genuineMask);
            FP = sum(predictions_binary & impostorMask);
            TN = sum(~predictions_binary & impostorMask);
            FN = sum(~predictions_binary & genuineMask);
            
            TPR(i) = TP / (TP + FN + eps);
            FPR(i) = FP / (FP + TN + eps);
        end
        
        % Compute AUC
        AUC = trapz(FPR, TPR);
        
        % Find EER (Equal Error Rate)
        FRR = 1 - TPR;
        [~, eerIdx] = min(abs(FPR - FRR));
        EER = (FPR(eerIdx) + FRR(eerIdx)) / 2;
        
        metrics.TPR = TPR;
        metrics.FPR = FPR;
        metrics.AUC = AUC;
        metrics.EER = EER;
        metrics.thresholds = thresholds;
        
        fprintf('Verification metrics: AUC=%.3f, EER=%.3f\n', AUC, EER);
    end
end

function recognitionSystem = createFaceRecognitionSystem(trainImages, trainLabels, options)
    % Create complete face recognition system
    
    if nargin < 3
        options = struct();
        options.networkType = 'deep_cnn';
        options.embeddingDim = 128;
        options.trainingEpochs = 10;
        options.batchSize = 32;
    end
    
    fprintf('Creating comprehensive face recognition system...\n');
    
    recognitionSystem = struct();
    recognitionSystem.options = options;
    
    % Create and train network
    inputSize = size(trainImages(:, :, :, 1));
    numIdentities = length(unique(trainLabels));
    
    network = createDeepFaceNetwork(inputSize, numIdentities);
    
    % Training options (simplified for demonstration)
    trainingOpts = trainingOptions('adam', ...
        'InitialLearnRate', 0.001, ...
        'MaxEpochs', options.trainingEpochs, ...
        'MiniBatchSize', options.batchSize, ...
        'Verbose', false, ...
        'Plots', 'none');
    
    try
        fprintf('Training face recognition network...\n');
        trainedNetwork = trainNetwork(trainImages, categorical(trainLabels), network, trainingOpts);
        recognitionSystem.network = trainedNetwork;
        
    catch ME
        fprintf('Training failed: %s\n', ME.message);
        fprintf('Using untrained network for demonstration\n');
        recognitionSystem.network = assembleNetwork(network);
    end
    
    % Extract features for gallery
    galleryFeatures = extractFaceFeatures(recognitionSystem.network, trainImages);
    recognitionSystem.galleryFeatures = galleryFeatures;
    recognitionSystem.galleryLabels = trainLabels;
    
    % System metadata
    recognitionSystem.inputSize = inputSize;
    recognitionSystem.numIdentities = numIdentities;
    recognitionSystem.creationTime = datetime('now');
    
    fprintf('Face recognition system created successfully\n');
end

function testResults = testFaceRecognitionSystem(system, testImages, testLabels)
    % Test face recognition system performance
    
    fprintf('Testing face recognition system...\n');
    
    % Extract features for test images
    testFeatures = extractFaceFeatures(system.network, testImages);
    
    % Perform identification for each test image
    numTestImages = size(testFeatures, 2);
    predictions = zeros(numTestImages, 1);
    similarities = zeros(numTestImages, 1);
    
    for i = 1:numTestImages
        queryFeatures = testFeatures(:, i);
        
        % Identify against gallery
        identResult = identifyFace(queryFeatures, system.galleryFeatures, ...
                                 system.galleryLabels, 1);
        
        predictions(i) = identResult.topKLabels(1);
        similarities(i) = identResult.topKSimilarities(1);
    end
    
    % Evaluate performance
    accuracy = sum(predictions == testLabels) / length(testLabels);
    
    testResults = struct();
    testResults.predictions = predictions;
    testResults.groundTruth = testLabels;
    testResults.similarities = similarities;
    testResults.accuracy = accuracy;
    
    fprintf('Test results: Accuracy = %.3f (%d/%d correct)\n', ...
        accuracy, sum(predictions == testLabels), length(testLabels));
    
    % Detailed analysis
    uniqueLabels = unique(testLabels);
    fprintf('\nPer-identity accuracy:\n');
    for label = uniqueLabels'
        labelMask = testLabels == label;
        labelAccuracy = sum(predictions(labelMask) == label) / sum(labelMask);
        fprintf('  Identity %d: %.3f\n', label, labelAccuracy);
    end
end

function advancedAnalysis = performAdvancedAnalysis(system, testResults)
    % Perform advanced analysis of face recognition system
    
    fprintf('Performing advanced face recognition analysis...\n');
    
    advancedAnalysis = struct();
    
    % Feature space analysis
    allFeatures = [system.galleryFeatures, extractFaceFeatures(system.network, testImages)];
    allLabels = [system.galleryLabels; testLabels];
    
    % Compute inter-class and intra-class distances
    uniqueLabels = unique(allLabels);
    interClassDistances = [];
    intraClassDistances = [];
    
    for i = 1:length(uniqueLabels)
        label = uniqueLabels(i);
        classFeatures = allFeatures(:, allLabels == label);
        
        % Intra-class distances
        if size(classFeatures, 2) > 1
            classDistances = pdist(classFeatures', 'cosine');
            intraClassDistances = [intraClassDistances, classDistances];
        end
        
        % Inter-class distances
        otherFeatures = allFeatures(:, allLabels ~= label);
        if ~isempty(otherFeatures)
            for j = 1:size(classFeatures, 2)
                distances = 1 - classFeatures(:, j)' * otherFeatures;
                interClassDistances = [interClassDistances, distances];
            end
        end
    end
    
    advancedAnalysis.meanIntraClassDistance = mean(intraClassDistances);
    advancedAnalysis.meanInterClassDistance = mean(interClassDistances);
    advancedAnalysis.separabilityRatio = advancedAnalysis.meanInterClassDistance / ...
                                        (advancedAnalysis.meanIntraClassDistance + eps);
    
    % Feature dimensionality analysis
    [coeff, score, latent] = pca(allFeatures');
    advancedAnalysis.pcaVarianceExplained = cumsum(latent) / sum(latent);
    advancedAnalysis.effectiveDimensionality = find(advancedAnalysis.pcaVarianceExplained >= 0.95, 1);
    
    % Quality metrics
    advancedAnalysis.featureNormConsistency = std(vecnorm(allFeatures, 2, 1));
    
    fprintf('Advanced analysis results:\n');
    fprintf('  Mean intra-class distance: %.3f\n', advancedAnalysis.meanIntraClassDistance);
    fprintf('  Mean inter-class distance: %.3f\n', advancedAnalysis.meanInterClassDistance);
    fprintf('  Separability ratio: %.3f\n', advancedAnalysis.separabilityRatio);
    fprintf('  Effective dimensionality: %d (95%% variance)\n', advancedAnalysis.effectiveDimensionality);
    fprintf('  Feature norm consistency: %.3f\n', advancedAnalysis.featureNormConsistency);
end

function visualizeFaceRecognitionResults(system, testResults, advancedAnalysis)
    % Visualize face recognition results and analysis
    
    figure;
    
    % Plot 1: Confusion matrix
    subplot(2, 3, 1);
    if isfield(testResults, 'groundTruth') && isfield(testResults, 'predictions')
        confusionMatrix = confusionmat(testResults.groundTruth, testResults.predictions);
        imagesc(confusionMatrix);
        colorbar;
        title('Confusion Matrix');
        xlabel('Predicted Identity');
        ylabel('True Identity');
    end
    
    % Plot 2: Similarity distribution
    subplot(2, 3, 2);
    if isfield(testResults, 'similarities')
        histogram(testResults.similarities, 20);
        title('Similarity Score Distribution');
        xlabel('Similarity Score');
        ylabel('Frequency');
    end
    
    % Plot 3: PCA visualization
    subplot(2, 3, 3);
    if isfield(advancedAnalysis, 'pcaVarianceExplained')
        plot(advancedAnalysis.pcaVarianceExplained, 'b-', 'LineWidth', 2);
        xlabel('Principal Component');
        ylabel('Cumulative Variance Explained');
        title('PCA Analysis');
        grid on;
    end
    
    % Plot 4: Distance analysis
    subplot(2, 3, 4);
    if isfield(advancedAnalysis, 'meanIntraClassDistance') && ...
       isfield(advancedAnalysis, 'meanInterClassDistance')
        
        distances = [advancedAnalysis.meanIntraClassDistance, ...
                    advancedAnalysis.meanInterClassDistance];
        bar(distances);
        set(gca, 'XTickLabel', {'Intra-class', 'Inter-class'});
        title('Distance Analysis');
        ylabel('Mean Distance');
    end
    
    % Plot 5: Performance metrics
    subplot(2, 3, 5);
    if isfield(testResults, 'accuracy')
        performanceData = [testResults.accuracy, 1 - testResults.accuracy];
        pie(performanceData, {'Correct', 'Incorrect'});
        title(sprintf('Overall Accuracy: %.1f%%', testResults.accuracy * 100));
    end
    
    % Plot 6: Feature space visualization (2*D projection)
    subplot(2, 3, 6);
    try
        % Simple 2*D projection of features for visualization
        allFeatures = system.galleryFeatures;
        if size(allFeatures, 1) > 2
            [~, score] = pca(allFeatures');
            scatter(score(:, 1), score(:, 2), 50, system.galleryLabels, 'filled');
            colorbar;
            title('Feature Space (PCA Projection)');
            xlabel('PC 1');
            ylabel('PC 2');
        end
    catch
        text(0.5, 0.5, 'Feature visualization unavailable', ...
             'HorizontalAlignment', 'center', 'Units', 'normalized');
        title('Feature Space');
    end
    
    sgtitle('Face Recognition System Analysis');
end
