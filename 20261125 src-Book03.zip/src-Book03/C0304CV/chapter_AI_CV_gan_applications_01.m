%% chapter_AI_CV_gan_applications_01.m
% GAN Applications: Image Translation and Enhancement
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_gan_applications_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Comprehensive GAN Applications in Computer Vision
fprintf('GAN Applications in Computer Vision\n');
fprintf('===================================\n');

% Application 1: Image-to-Image Translation (Simplified Pix2Pix)

% Application 2: Super-Resolution GAN (SRGAN)

% Application 3: Data Augmentation with GANs

% Application 4: Style Transfer with GANs


% Application 5: Inpainting with GANs


% Create example networks for different applications
fprintf('Creating example GAN architectures for different applications...\n');

% Pix2Pix example
input_size = [256, 256, 3];
output_size = [256, 256, 3];
[pix2pix_gen, pix2pix_disc] = createPix2PixNetworks(input_size, output_size);

fprintf('Pix2Pix Networks:\n');
fprintf('  Generator layers: %d\n', length(pix2pix_gen));
fprintf('  Discriminator layers: %d\n', length(pix2pix_disc));

% SRGAN example
low_res_size = [64, 64, 3];
high_res_size = [256, 256, 3];
[srgan_gen, srgan_disc] = createSRGANNetworks(low_res_size, high_res_size);

fprintf('SRGAN Networks:\n');
fprintf('  Generator layers: %d\n', length(srgan_gen));
fprintf('  Discriminator layers: %d\n', length(srgan_disc));

% Performance evaluation metrics for GAN applications





% Application showcase with synthetic data
fprintf('\nGAN Applications Showcase:\n');
fprintf('==========================\n');

% Create synthetic test data
test_images = rand(64, 64, 3, 10, 'single');
reference_images = rand(64, 64, 3, 10, 'single');

% Evaluate different applications
fprintf('\nEvaluating GAN Applications:\n');
sr_metrics = evaluateGANApplication(test_images, reference_images, 'super_resolution');
translation_metrics = evaluateGANApplication(test_images, reference_images, 'image_translation');
inpainting_metrics = evaluateGANApplication(test_images, reference_images, 'inpainting');

% Summary of GAN applications
fprintf('\nGAN Applications Summary:\n');
fprintf('=========================\n');
fprintf('1. Image-to-Image Translation:\n');
fprintf('   - Pix2Pix: Paired domain translation\n');
fprintf('   - CycleGAN: Unpaired domain translation\n');
fprintf('   - Applications: Style transfer, colorization, sketch-to-photo\n');

fprintf('\n2. Super-Resolution:\n');
fprintf('   - SRGAN: Perceptually realistic upsampling\n');
fprintf('   - ESRGAN: Enhanced quality and detail\n');
fprintf('   - Applications: Medical imaging, satellite imagery, photography\n');

fprintf('\n3. Data Augmentation:\n');
fprintf('   - Generate synthetic training samples\n');
fprintf('   - Improve model generalization\n');
fprintf('   - Applications: Limited dataset scenarios, class imbalance\n');

fprintf('\n4. Image Inpainting:\n');
fprintf('   - Context encoders: Fill missing regions\n');
fprintf('   - Partial convolutions: Handle irregular holes\n');
fprintf('   - Applications: Photo restoration, object removal\n');

fprintf('\n5. Domain Adaptation:\n');
fprintf('   - Adapt models across different domains\n');
fprintf('   - Reduce domain gap through translation\n');
fprintf('   - Applications: Simulation-to-real transfer\n');

% Local functions (moved to end so this listing is a valid MATLAB script)
function [generator, discriminator] = createPix2PixNetworks(inputSize, outputSize)
    % Pix2Pix Generator (U-Net architecture)
    function layers = createUNetGenerator(inputSize, outputSize)
        % Encoder
        encoder = [
            imageInputLayer(inputSize, 'Name', 'input')
            
            % Encoder blocks
            convolution2dLayer(4, 64, 'Stride', 2, 'Padding', 'same', 'Name', 'enc1')
            leakyReluLayer(0.2, 'Name', 'enc1_relu')
            
            convolution2dLayer(4, 128, 'Stride', 2, 'Padding', 'same', 'Name', 'enc2')
            batchNormalizationLayer('Name', 'enc2_bn')
            leakyReluLayer(0.2, 'Name', 'enc2_relu')
            
            convolution2dLayer(4, 256, 'Stride', 2, 'Padding', 'same', 'Name', 'enc3')
            batchNormalizationLayer('Name', 'enc3_bn')
            leakyReluLayer(0.2, 'Name', 'enc3_relu')
            
            convolution2dLayer(4, 512, 'Stride', 2, 'Padding', 'same', 'Name', 'enc4')
            batchNormalizationLayer('Name', 'enc4_bn')
            leakyReluLayer(0.2, 'Name', 'enc4_relu')
            
            % Bottleneck
            convolution2dLayer(4, 512, 'Stride', 2, 'Padding', 'same', 'Name', 'bottleneck')
            batchNormalizationLayer('Name', 'bottleneck_bn')
            reluLayer('Name', 'bottleneck_relu')
            
            % Decoder
            transposedConv2dLayer(4, 512, 'Stride', 2, 'Cropping', 'same', 'Name', 'dec1')
            batchNormalizationLayer('Name', 'dec1_bn')
            dropoutLayer(0.5, 'Name', 'dec1_dropout')
            reluLayer('Name', 'dec1_relu')
            
            transposedConv2dLayer(4, 256, 'Stride', 2, 'Cropping', 'same', 'Name', 'dec2')
            batchNormalizationLayer('Name', 'dec2_bn')
            dropoutLayer(0.5, 'Name', 'dec2_dropout')
            reluLayer('Name', 'dec2_relu')
            
            transposedConv2dLayer(4, 128, 'Stride', 2, 'Cropping', 'same', 'Name', 'dec3')
            batchNormalizationLayer('Name', 'dec3_bn')
            reluLayer('Name', 'dec3_relu')
            
            transposedConv2dLayer(4, 64, 'Stride', 2, 'Cropping', 'same', 'Name', 'dec4')
            batchNormalizationLayer('Name', 'dec4_bn')
            reluLayer('Name', 'dec4_relu')
            
            % Final output
            transposedConv2dLayer(4, outputSize(3), 'Stride', 2, 'Cropping', 'same', 'Name', 'output')
            tanhLayer('Name', 'tanh')
        ];
        
        layers = encoder;
    end
    
    % Pix2Pix Discriminator (PatchGAN)
    function layers = createPatchGANDiscriminator(inputSize, targetSize)
        % Concatenate input and target
        combined_size = [inputSize(1), inputSize(2), inputSize(3) + targetSize(3)];
        
        layers = [
            imageInputLayer(combined_size, 'Name', 'input', 'Normalization', 'none')
            
            % Convolutional layers
            convolution2dLayer(4, 64, 'Stride', 2, 'Padding', 'same', 'Name', 'conv1')
            leakyReluLayer(0.2, 'Name', 'lrelu1')
            
            convolution2dLayer(4, 128, 'Stride', 2, 'Padding', 'same', 'Name', 'conv2')
            batchNormalizationLayer('Name', 'bn1')
            leakyReluLayer(0.2, 'Name', 'lrelu2')
            
            convolution2dLayer(4, 256, 'Stride', 2, 'Padding', 'same', 'Name', 'conv3')
            batchNormalizationLayer('Name', 'bn2')
            leakyReluLayer(0.2, 'Name', 'lrelu3')
            
            convolution2dLayer(4, 512, 'Stride', 1, 'Padding', 'same', 'Name', 'conv4')
            batchNormalizationLayer('Name', 'bn3')
            leakyReluLayer(0.2, 'Name', 'lrelu4')
            
            % Final classification
            convolution2dLayer(4, 1, 'Stride', 1, 'Padding', 'same', 'Name', 'conv5')
            sigmoidLayer('Name', 'sigmoid')
        ];
    end
    
    generator = createUNetGenerator(inputSize, outputSize);
    discriminator = createPatchGANDiscriminator(inputSize, outputSize);
end

function [generator, discriminator] = createSRGANNetworks(lowResSize, highResSize)
    % SRGAN Generator
    function layers = createSRGenerator(inputSize, outputSize)
        scale_factor = outputSize(1) / inputSize(1);
        num_upsampling_blocks = log2(scale_factor);
        
        layers = [
            imageInputLayer(inputSize, 'Name', 'input')
            
            % Initial convolution
            convolution2dLayer(9, 64, 'Padding', 'same', 'Name', 'initial_conv')
            reluLayer('Name', 'initial_relu')
            
            % Residual blocks
            convolution2dLayer(3, 64, 'Padding', 'same', 'Name', 'res1_conv1')
            batchNormalizationLayer('Name', 'res1_bn1')
            reluLayer('Name', 'res1_relu1')
            convolution2dLayer(3, 64, 'Padding', 'same', 'Name', 'res1_conv2')
            batchNormalizationLayer('Name', 'res1_bn2')
            additionLayer(2, 'Name', 'res1_add')
            
            % Additional residual blocks would be added here...
            
            % Upsampling blocks
            convolution2dLayer(3, 256, 'Padding', 'same', 'Name', 'upsample1_conv')
            reluLayer('Name', 'upsample1_relu')
            
            % Pixel shuffle simulation (simplified)
            transposedConv2dLayer(3, 64, 'Stride', 2, 'Cropping', 'same', 'Name', 'upsample1_up')
            
            % Final output
            convolution2dLayer(9, outputSize(3), 'Padding', 'same', 'Name', 'output_conv')
            tanhLayer('Name', 'output_tanh')
        ];
    end
    
    % SRGAN Discriminator
    function layers = createSRDiscriminator(inputSize)
        layers = [
            imageInputLayer(inputSize, 'Name', 'input')
            
            % Feature extraction
            convolution2dLayer(3, 64, 'Stride', 1, 'Padding', 'same', 'Name', 'conv1')
            leakyReluLayer(0.2, 'Name', 'lrelu1')
            
            convolution2dLayer(3, 64, 'Stride', 2, 'Padding', 'same', 'Name', 'conv2')
            batchNormalizationLayer('Name', 'bn1')
            leakyReluLayer(0.2, 'Name', 'lrelu2')
            
            convolution2dLayer(3, 128, 'Stride', 1, 'Padding', 'same', 'Name', 'conv3')
            batchNormalizationLayer('Name', 'bn2')
            leakyReluLayer(0.2, 'Name', 'lrelu3')
            
            convolution2dLayer(3, 128, 'Stride', 2, 'Padding', 'same', 'Name', 'conv4')
            batchNormalizationLayer('Name', 'bn3')
            leakyReluLayer(0.2, 'Name', 'lrelu4')
            
            convolution2dLayer(3, 256, 'Stride', 1, 'Padding', 'same', 'Name', 'conv5')
            batchNormalizationLayer('Name', 'bn4')
            leakyReluLayer(0.2, 'Name', 'lrelu5')
            
            convolution2dLayer(3, 256, 'Stride', 2, 'Padding', 'same', 'Name', 'conv6')
            batchNormalizationLayer('Name', 'bn5')
            leakyReluLayer(0.2, 'Name', 'lrelu6')
            
            % Dense layers
            fullyConnectedLayer(1024, 'Name', 'fc1')
            leakyReluLayer(0.2, 'Name', 'fc1_lrelu')
            fullyConnectedLayer(1, 'Name', 'fc2')
            sigmoidLayer('Name', 'sigmoid')
        ];
    end
    
    generator = createSRGenerator(lowResSize, highResSize);
    discriminator = createSRDiscriminator(highResSize);
end

function augmented_data = ganDataAugmentation(original_data, gan_generator, num_augmented)
    % Generate synthetic data for augmentation
    latent_dim = 100; % Assuming standard latent dimension
    noise = randn(latent_dim, num_augmented, 'single');
    
    try
        % Generate synthetic samples
        synthetic_data = predict(gan_generator, noise);
        
        % Combine with original data
        augmented_data = cat(4, original_data, synthetic_data);
        
        fprintf('Data Augmentation Results:\n');
        fprintf('Original samples: %d\n', size(original_data, 4));
        fprintf('Synthetic samples: %d\n', size(synthetic_data, 4));
        fprintf('Total augmented: %d\n', size(augmented_data, 4));
        
    catch ME
        fprintf('Error in data augmentation: %s\n', ME.message);
        augmented_data = original_data;
    end
end

function style_transfer_results = ganStyleTransfer(content_images, style_reference)
    % Simplified style transfer implementation
    fprintf('GAN-based Style Transfer:\n');
    fprintf('========================\n');
    
    num_images = size(content_images, 4);
    style_transfer_results = zeros(size(content_images), 'like', content_images);
    
    for i = 1:num_images
        content_img = content_images(:, :, :, i);
        
        % Simplified style transfer (placeholder)
        % In practice, this would use a trained style transfer GAN
        transferred_img = applyStyleTransformation(content_img, style_reference);
        style_transfer_results(:, :, :, i) = transferred_img;
    end
    
    fprintf('Style transfer completed for %d images\n', num_images);
end

function transferred_img = applyStyleTransformation(content_img, style_reference)
    % Simplified style transfer transformation
    % This is a placeholder - real implementation would use trained networks
    
    % Extract style statistics (simplified)
    style_mean = mean(style_reference(:));
    style_std = std(style_reference(:));
    
    % Apply style transformation
    content_mean = mean(content_img(:));
    content_std = std(content_img(:));
    
    % Normalize content and apply style statistics
    normalized_content = (content_img - content_mean) / (content_std + eps);
    transferred_img = normalized_content * style_std + style_mean;
    
    % Ensure valid range
    transferred_img = max(0, min(1, transferred_img));
end

function inpainted_images = ganInpainting(damaged_images, masks)
    % GAN-based image inpainting
    fprintf('GAN-based Image Inpainting:\n');
    fprintf('===========================\n');
    
    num_images = size(damaged_images, 4);
    inpainted_images = damaged_images; % Initialize with damaged images
    
    for i = 1:num_images
        damaged_img = damaged_images(:, :, :, i);
        mask = masks(:, :, :, i);
        
        % Simplified inpainting process
        inpainted_img = performInpainting(damaged_img, mask);
        inpainted_images(:, :, :, i) = inpainted_img;
    end
    
    fprintf('Inpainting completed for %d images\n', num_images);
end

function inpainted_img = performInpainting(damaged_img, mask)
    % Simplified inpainting algorithm
    % Real implementation would use context encoders or partial convolution GANs
    
    inpainted_img = damaged_img;
    
    % Find damaged regions
    damaged_regions = mask > 0.5;
    
    % Simple inpainting using surrounding pixels (placeholder)
    for c = 1:size(damaged_img, 3)
        channel = damaged_img(:, :, c);
        damaged_channel = damaged_regions(:, :, min(c, size(damaged_regions, 3)));
        
        % Fill damaged regions with interpolated values
        [damaged_y, damaged_x] = find(damaged_channel);
        
        for i = 1:length(damaged_y)
            y = damaged_y(i);
            x = damaged_x(i);
            
            % Get surrounding valid pixels
            window_size = 5;
            y_range = max(1, y-window_size):min(size(channel, 1), y+window_size);
            x_range = max(1, x-window_size):min(size(channel, 2), x+window_size);
            
            window = channel(y_range, x_range);
            mask_window = damaged_channel(y_range, x_range);
            valid_pixels = window(~mask_window);
            
            if ~isempty(valid_pixels)
                channel(y, x) = mean(valid_pixels);
            end
        end
        
        inpainted_img(:, :, c) = channel;
    end
end

function metrics = evaluateGANApplication(generated_images, reference_images, application_type)
    metrics = struct();
    
    switch application_type
        case 'super_resolution'
            % PSNR and SSIM for super-resolution
            metrics = evaluateSuperResolution(generated_images, reference_images);
            
        case 'image_translation'
            % Perceptual similarity for image translation
            metrics = evaluateImageTranslation(generated_images, reference_images);
            
        case 'inpainting'
            % Reconstruction quality for inpainting
            metrics = evaluateInpainting(generated_images, reference_images);
            
        case 'data_augmentation'
            % Diversity and realism for data augmentation
            metrics = evaluateDataAugmentation(generated_images, reference_images);
            
        otherwise
            fprintf('Unknown application type: %s\n', application_type);
    end
end

function metrics = evaluateSuperResolution(sr_images, hr_images)
    % Peak Signal-to-Noise Ratio
    mse = mean((sr_images(:) - hr_images(:)).^2);
    max_val = max(hr_images(:));
    psnr = 10 * log10(max_val^2 / mse);
    
    % Simplified SSIM calculation
    mu1 = mean(sr_images(:));
    mu2 = mean(hr_images(:));
    sigma1 = var(sr_images(:));
    sigma2 = var(hr_images(:));
    sigma12 = cov(sr_images(:), hr_images(:));
    
    c1 = 0.01^2;
    c2 = 0.03^2;
    
    ssim = ((2*mu1*mu2 + c1) * (2*sigma12(1,2) + c2)) / ...
           ((mu1^2 + mu2^2 + c1) * (sigma1 + sigma2 + c2));
    
    metrics.psnr = psnr;
    metrics.ssim = ssim;
    
    fprintf('Super-Resolution Metrics:\n');
    fprintf('  PSNR: %.2f dB\n', psnr);
    fprintf('  SSIM: %.4f\n', ssim);
end

function metrics = evaluateImageTranslation(translated_images, target_images)
    % L1 distance for image translation
    l1_distance = mean(abs(translated_images(:) - target_images(:)));
    
    % Perceptual similarity (simplified)
    perceptual_sim = 1 - l1_distance;
    
    metrics.l1_distance = l1_distance;
    metrics.perceptual_similarity = perceptual_sim;
    
    fprintf('Image Translation Metrics:\n');
    fprintf('  L1 Distance: %.4f\n', l1_distance);
    fprintf('  Perceptual Similarity: %.4f\n', perceptual_sim);
end

function metrics = evaluateInpainting(inpainted_images, original_images)
    % Reconstruction error in inpainted regions
    reconstruction_error = mean((inpainted_images(:) - original_images(:)).^2);
    
    metrics.reconstruction_error = reconstruction_error;
    
    fprintf('Inpainting Metrics:\n');
    fprintf('  Reconstruction Error: %.6f\n', reconstruction_error);
end

function metrics = evaluateDataAugmentation(synthetic_images, real_images)
    % Simplified diversity measurement
    real_mean = mean(real_images(:));
    real_std = std(real_images(:));
    synthetic_mean = mean(synthetic_images(:));
    synthetic_std = std(synthetic_images(:));
    
    distribution_distance = abs(real_mean - synthetic_mean) + abs(real_std - synthetic_std);
    
    metrics.distribution_distance = distribution_distance;
    
    fprintf('Data Augmentation Metrics:\n');
    fprintf('  Distribution Distance: %.4f\n', distribution_distance);
end
