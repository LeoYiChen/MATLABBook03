%% chapter_AI_CV_basic_filtering_01.m
% Gaussian and Median Filtering Comparison
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_basic_filtering_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Load test image and add different noise types
original_image = imread('coins.png');
original_image = im2double(original_image);

% Add Gaussian noise
gaussian_noise_image = imnoise(original_image, 'gaussian', 0, 0.01);

% Add salt and pepper noise
saltpepper_noise_image = imnoise(original_image, 'salt & pepper', 0.05);

% Apply different filtering techniques
% Gaussian filtering - effective for Gaussian noise
sigma_small = 0.5;
sigma_medium = 1.0;
sigma_large = 2.0;

gauss_filtered_small = imgaussfilt(gaussian_noise_image, sigma_small);
gauss_filtered_medium = imgaussfilt(gaussian_noise_image, sigma_medium);
gauss_filtered_large = imgaussfilt(gaussian_noise_image, sigma_large);

% Median filtering - effective for impulse noise
median_filtered_3x3 = medfilt2(saltpepper_noise_image, [3 3]);
median_filtered_5x5 = medfilt2(saltpepper_noise_image, [5 5]);
median_filtered_7x7 = medfilt2(saltpepper_noise_image, [7 7]);

% Calculate PSNR for quantitative assessment
psnr_gauss_small = psnr(gauss_filtered_small, original_image);
psnr_gauss_medium = psnr(gauss_filtered_medium, original_image);
psnr_gauss_large = psnr(gauss_filtered_large, original_image);

psnr_median_3x3 = psnr(median_filtered_3x3, original_image);
psnr_median_5x5 = psnr(median_filtered_5x5, original_image);
psnr_median_7x7 = psnr(median_filtered_7x7, original_image);

% Display results
figure;
subplot(3,4,1); imshow(original_image); title('Original');
subplot(3,4,2); imshow(gaussian_noise_image); title('Gaussian Noise');
subplot(3,4,3); imshow(gauss_filtered_small); 
title(sprintf('Gaussian 考=%.1f, PSNR=%.1f', sigma_small, psnr_gauss_small));
subplot(3,4,4); imshow(gauss_filtered_medium);
title(sprintf('Gaussian 考=%.1f, PSNR=%.1f', sigma_medium, psnr_gauss_medium));

subplot(3,4,5); imshow(saltpepper_noise_image); title('Salt & Pepper Noise');
subplot(3,4,6); imshow(median_filtered_3x3);
title(sprintf('Median 3℅3, PSNR=%.1f', psnr_median_3x3));
subplot(3,4,7); imshow(median_filtered_5x5);
title(sprintf('Median 5℅5, PSNR=%.1f', psnr_median_5x5));
subplot(3,4,8); imshow(median_filtered_7x7);
title(sprintf('Median 7℅7, PSNR=%.1f', psnr_median_7x7));

% Cross-application: wrong filter for wrong noise type
gauss_on_saltpepper = imgaussfilt(saltpepper_noise_image, sigma_medium);
median_on_gaussian = medfilt2(gaussian_noise_image, [5 5]);

subplot(3,4,9); imshow(gauss_on_saltpepper); 
title('Gaussian on S&P (Poor)');
subplot(3,4,10); imshow(median_on_gaussian);
title('Median on Gaussian (Poor)');

% Display filtering kernels for educational purposes
[X, Y] = meshgrid(-10:10, -10:10);
gaussian_kernel = exp(-(X.^2 + Y.^2)/(2*sigma_medium^2));
gaussian_kernel = gaussian_kernel / sum(gaussian_kernel(:));

subplot(3,4,11); surf(X, Y, gaussian_kernel); 
title('Gaussian Kernel'); axis tight;
subplot(3,4,12); imagesc(gaussian_kernel); 
title('Gaussian Kernel (2*D)'); axis equal tight; colorbar;
