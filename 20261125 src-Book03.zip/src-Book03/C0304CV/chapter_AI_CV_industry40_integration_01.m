%% chapter_AI_CV_industry40_integration_01.m
% Industry 4.0 Computer Vision Integration and Digital Twin Implementation
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_industry40_integration_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Industry 4.0 Computer Vision Integration and Digital Twin System
fprintf('Industry 4.0 Computer Vision Integration and Digital Twin System\n');
fprintf('================================================================\n');

% Create simulated Industry 4.0 manufacturing environment
[factoryData, productionLine, qualityMetrics] = createIndustry40Environment();







% 1. Digital Twin Implementation






% 2. Real-time Data Integration











% 3. Industry 4.0 Analytics and Reporting










% Test the Industry 4.0 integration system
fprintf('\nTesting Industry 4.0 computer vision integration...\n');

% Create digital twin for production line
digitalTwin = createDigitalTwin(productionLine);

% Simulate real-time data updates
for update = 1:5
    fprintf('\nSimulation update %d:\n', update);
    
    % Generate new sensor data
    currentSensorData = createSensorArray();
    
    % Generate vision system data
    visionData = struct();
    visionData.defectsDetected = randi([0, 3]);
    visionData.inspectionsPassed = 45 + randi(10);
    visionData.averageConfidence = 0.92 + rand() * 0.06;
    visionData.processingTime = 0.05 + rand() * 0.02; % 50-70*ms
    
    % Update digital twin
    digitalTwin = updateDigitalTwinRealTime(digitalTwin, currentSensorData, visionData);
    
    % Display current state
    fprintf('  Throughput: %.1f units/hour\n', digitalTwin.currentState.throughput);
    fprintf('  Quality: %.1f%%\n', digitalTwin.currentState.quality * 100);
    fprintf('  Efficiency: %.1f%%\n', digitalTwin.currentState.efficiency * 100);
end

% Generate comprehensive analytics report
analyticsReport = generateIndustry40Analytics(digitalTwin, [], hours(24));

% Visualise Industry 4.0 dashboard
figure;

% System performance overview
subplot(3, 4, 1);
performanceData = [analyticsReport.performance.throughputEfficiency, 1 - analyticsReport.performance.throughputEfficiency];
pie(performanceData, {'Achieved', 'Gap'});
title('Throughput Performance');

% Quality metrics
subplot(3, 4, 2);
qualityMetrics = [
    analyticsReport.quality.firstPassYield,
    analyticsReport.quality.defectRate,
    analyticsReport.quality.reworkRate
];
bar(qualityMetrics);
set(gca, 'XTickLabel', {'First Pass', 'Defects', 'Rework'});
title('Quality Metrics');
ylabel('Rate');

% OEE breakdown
subplot(3, 4, 3);
oeeComponents = [
    analyticsReport.efficiency.availability,
    analyticsReport.efficiency.performance,
    analyticsReport.efficiency.quality
];
bar(oeeComponents);
set(gca, 'XTickLabel', {'Availability', 'Performance', 'Quality'});
title('OEE Components');
ylabel('Score');

% Vision system performance
subplot(3, 4, 4);
visionMetrics = [
    analyticsReport.quality.visionSystemAccuracy,
    analyticsReport.quality.inspectionCoverage,
    1 - analyticsReport.quality.falsePositiveRate,
    1 - analyticsReport.quality.falseNegativeRate
];
bar(visionMetrics);
set(gca, 'XTickLabel', {'Accuracy', 'Coverage', 'Precision', 'Recall'});
title('Vision System Performance');
ylabel('Score');

% Real-time trends (simulated)
subplot(3, 4, [5, 6]);
timePoints = 1:24; % 24 hours
throughputTrend = 95 + 5 * sin(timePoints * pi / 12) + randn(1, 24);
qualityTrend = 96 + 2 * cos(timePoints * pi / 8) + randn(1, 24) * 0.5;

plot(timePoints, throughputTrend, 'b-', 'LineWidth', 2);
hold on;
plot(timePoints, qualityTrend, 'r-', 'LineWidth', 2);
hold off;
xlabel('Time (hours)');
ylabel('Performance (%)');
title('Real-time Performance Trends');
legend({'Throughput', 'Quality'}, 'Location', 'best');
grid on;

% Predictive maintenance
subplot(3, 4, [7, 8]);
maintenanceData = [
    1 - analyticsReport.predictive.failureProbability,
    analyticsReport.predictive.failureProbability
];
pie(maintenanceData, {'Healthy', 'Maintenance Risk'});
title('Predictive Maintenance Status');

% Optimisation opportunities
subplot(3, 4, 9);
if ~isempty(digitalTwin.optimisations.opportunities)
    optimisationTypes = {digitalTwin.optimisations.opportunities.type};
    optimisationPotentials = [digitalTwin.optimisations.opportunities.potential];
    
    bar(optimisationPotentials * 100);
    set(gca, 'XTickLabel', optimisationTypes);
    xtickangle(45);
    title('Optimisation Opportunities');
    ylabel('Improvement Potential (%)');
end

% Energy consumption
subplot(3, 4, 10);
energyData = [
    digitalTwin.realTimeData.sensors.powerConsumption,
    3.5 - digitalTwin.realTimeData.sensors.powerConsumption % Remaining capacity
];
bar(energyData);
set(gca, 'XTickLabel', {'Current', 'Available'});
title('Energy Consumption');
ylabel('Power (kW)');

% Digital Twin sync status
subplot(3, 4, 11);
syncHealth = 0.95; % 95% sync health
healthBar = barh(1, syncHealth);
healthBar.FaceColor = 'green';
xlim([0, 1]);
title('Digital Twin Sync Health');
xlabel('Health Score');

% ROI analysis
subplot(3, 4, 12);
if ~isempty(analyticsReport.recommendations)
    roiValues = arrayfun(@(x) x.estimatedROI, analyticsReport.recommendations);
    bar(roiValues * 100);
    title('Optimisation ROI');
    ylabel('ROI (%)');
end

sgtitle('Industry 4.0 Manufacturing Dashboard');

% Display comprehensive report
fprintf('\n' + string(repmat('=', 1, 70)) + '\n');
fprintf('INDUSTRY 4.0 ANALYTICS REPORT\n');
fprintf(string(repmat('=', 1, 70)) + '\n');

fprintf('\nSYSTEM PERFORMANCE:\n');
fprintf('  Current Throughput: %.1f units/hour (%.1f%% of target)\n', ...
    analyticsReport.performance.currentThroughput, ...
    analyticsReport.performance.throughputEfficiency * 100);
fprintf('  Current Quality: %.1f%% (Target: %.1f%%)\n', ...
    analyticsReport.quality.currentQualityRate * 100, ...
    analyticsReport.quality.targetQualityRate * 100);
fprintf('  Overall Equipment Effectiveness: %.1f%%\n', ...
    analyticsReport.efficiency.oee * 100);

fprintf('\nVISION SYSTEM STATUS:\n');
fprintf('  Inspection Accuracy: %.1f%%\n', analyticsReport.quality.visionSystemAccuracy * 100);
fprintf('  Coverage: %.1f%%\n', analyticsReport.quality.inspectionCoverage * 100);
fprintf('  False Positive Rate: %.1f%%\n', analyticsReport.quality.falsePositiveRate * 100);
fprintf('  False Negative Rate: %.1f%%\n', analyticsReport.quality.falseNegativeRate * 100);

fprintf('\nPREDICTIVE INSIGHTS:\n');
fprintf('  Maintenance Probability (24*h): %.1f%%\n', ...
    analyticsReport.predictive.failureProbability * 100);
fprintf('  Optimisation Potential: %.1f%%\n', ...
    analyticsReport.predictive.optimisationPotential * 100);

fprintf('\nRECOMMENDATIONS:\n');
if ~isempty(analyticsReport.recommendations)
    for i = 1:length(analyticsReport.recommendations)
        rec = analyticsReport.recommendations(i);
        fprintf('  %d. %s (Priority: %s, ROI: %.0f%%)\n', ...
            i, rec.description, rec.priority, rec.estimatedROI * 100);
    end
else
    fprintf('  No specific recommendations at this time.\n');
end

fprintf('\nDIGITAL TWIN STATUS:\n');
fprintf('  Synchronisation: %s\n', digitalTwin.syncStatus);
fprintf('  Last Update: %s\n', char(digitalTwin.lastUpdate));
fprintf('  Model Accuracy: %.1f%%\n', digitalTwin.model.accuracy * 100);
fprintf('  Prediction Confidence: %.1f%%\n', digitalTwin.model.confidence * 100);

fprintf('\n' + string(repmat('=', 1, 70)) + '\n');

% Advanced Analytics Summary
fprintf('\nIndustry 4.0 Integration Summary:\n');
fprintf('================================\n');
fprintf('Manufacturing System: %s\n', productionLine.name);
fprintf('Vision Systems: Integrated across %d workstations\n', length(productionLine.workstations));
fprintf('Digital Twin: Active and synchronised\n');
fprintf('Real-time Analytics: Enabled\n');
fprintf('Predictive Capabilities: Operational\n');

fprintf('\nKey Performance Indicators:\n');
fprintf('==========================\n');
fprintf(' Overall Equipment Effectiveness: %.1f%%\n', analyticsReport.efficiency.oee * 100);
fprintf(' First Pass Yield: %.1f%%\n', analyticsReport.quality.firstPassYield * 100);
fprintf(' Vision System Uptime: 99.2%%\n'); % Simulated high uptime
fprintf(' Energy Efficiency Rating: %s\n', analyticsReport.efficiency.energyEfficiencyRating);
fprintf(' Predictive Maintenance Accuracy: 94.3%%\n'); % Simulated accuracy

fprintf('\nBusiness Impact:\n');
fprintf('===============\n');
fprintf(' Estimated Annual Savings: $%.0f\n', analyticsReport.predictive.estimatedBenefits.estimatedAnnualSavings);
fprintf(' Quality Improvement Potential: %.1f%%\n', analyticsReport.predictive.optimisationPotential * 100);
fprintf(' Unplanned Downtime Reduction: 35%%\n'); % Industry typical improvement
fprintf(' Material Waste Reduction: 12%%\n'); % Industry typical improvement

fprintf('\nTechnology Integration Benefits:\n');
fprintf('===============================\n');
fprintf(' Real-time quality monitoring and feedback\n');
fprintf(' Predictive maintenance reducing unplanned downtime\n');
fprintf(' Automated defect detection with 98%% accuracy\n');
fprintf(' Digital twin enabling virtual process optimisation\n');
fprintf(' Edge computing for millisecond response times\n');
fprintf(' Cloud integration for enterprise-wide visibility\n');
fprintf(' Machine learning continuously improving performance\n');
fprintf(' Seamless integration with existing manufacturing systems\n');

% Advanced Industry 4.0 capabilities
fprintf('\nAdvanced Industry 4.0 Capabilities:\n');
fprintf('===================================\n');
fprintf('1. Cyber-Physical Systems Integration:\n');
fprintf('    Physical-digital synchronisation\n');
fprintf('    Real-time system state monitoring\n');
fprintf('    Autonomous decision-making capabilities\n');

fprintf('\n2. Intelligent Manufacturing Networks:\n');
fprintf('    Machine-to-machine communication\n');
fprintf('    Distributed intelligence across production line\n');
fprintf('    Collaborative robotics integration\n');

fprintf('\n3. Advanced Analytics and AI:\n');
fprintf('    Deep learning for pattern recognition\n');
fprintf('    Reinforcement learning for process optimisation\n');
fprintf('    Natural language processing for operator interfaces\n');

fprintf('\n4. Edge-Cloud Computing Architecture:\n');
fprintf('    Local processing for real-time decisions\n');
fprintf('    Cloud analytics for global optimisation\n');
fprintf('    Hybrid computing for optimal performance\n');

fprintf('\n5. Digital Twin Technologies:\n');
fprintf('    Physics-based modelling\n');
fprintf('    Machine learning-enhanced predictions\n');
fprintf('    Virtual commissioning and testing\n');

% Future developments and trends
fprintf('\nFuture Developments in Industry 4.0 Vision:\n');
fprintf('==========================================\n');
fprintf('1. Autonomous Manufacturing:\n');
fprintf('    Self-optimising production systems\n');
fprintf('    Adaptive quality control\n');
fprintf('    Predictive supply chain management\n');

fprintf('\n2. Human-Machine Collaboration:\n');
fprintf('    Augmented reality for operator assistance\n');
fprintf('    Cognitive manufacturing interfaces\n');
fprintf('    Adaptive automation levels\n');

fprintf('\n3. Sustainability Integration:\n');
fprintf('    Carbon footprint optimisation\n');
fprintf('    Circular economy principles\n');
fprintf('    Energy-aware manufacturing\n');

fprintf('\n4. Blockchain for Manufacturing:\n');
fprintf('    Secure supply chain tracking\n');
fprintf('    Quality certification\n');
fprintf('    Intellectual property protection\n');

fprintf('\n5. 5*G and Beyond:\n');
fprintf('    Ultra-low latency communications\n');
fprintf('    Massive IoT connectivity\n');
fprintf('    Enhanced mobile broadband for manufacturing\n');

% Implementation best practices
fprintf('\nImplementation Best Practices:\n');
fprintf('=============================\n');
fprintf('1. Phased Implementation Approach:\n');
fprintf('    Start with pilot projects\n');
fprintf('    Gradually scale across facility\n');
fprintf('    Learn and adapt during rollout\n');

fprintf('\n2. Data Strategy:\n');
fprintf('    Establish data governance\n');
fprintf('    Ensure data quality and consistency\n');
fprintf('    Implement robust cybersecurity\n');

fprintf('\n3. Change Management:\n');
fprintf('    Train workforce on new technologies\n');
fprintf('    Foster culture of continuous improvement\n');
fprintf('    Ensure leadership commitment\n');

fprintf('\n4. Technology Integration:\n');
fprintf('    Prioritise interoperability\n');
fprintf('    Use open standards where possible\n');
fprintf('    Plan for future scalability\n');

fprintf('\n5. Performance Monitoring:\n');
fprintf('    Define clear KPIs\n');
fprintf('    Implement continuous monitoring\n');
fprintf('    Regular performance reviews\n');

% Return on Investment analysis
fprintf('\nReturn on Investment Analysis:\n');
fprintf('=============================\n');
fprintf('Implementation Costs:\n');
fprintf(' Vision system hardware: $250,000\n');
fprintf(' Software and integration: $150,000\n');
fprintf(' Training and change management: $75,000\n');
fprintf(' Infrastructure upgrades: $125,000\n');
fprintf('Total Investment: $600,000\n');

fprintf('\nAnnual Benefits:\n');
fprintf(' Quality improvement savings: $180,000\n');
fprintf(' Efficiency gains: $220,000\n');
fprintf(' Reduced downtime: $160,000\n');
fprintf(' Energy savings: $45,000\n');
fprintf('Total Annual Benefits: $605,000\n');

fprintf('\nPayback Period: 11.9 months\n');
fprintf('5-Year NPV: $2,425,000\n');
fprintf('5-Year ROI: 304%%\n');

% Risk assessment and mitigation
fprintf('\nRisk Assessment and Mitigation:\n');
fprintf('==============================\n');
fprintf('Technical Risks:\n');
fprintf(' Integration complexity: Mitigated by phased approach\n');
fprintf(' Technology obsolescence: Addressed through modular design\n');
fprintf(' Cybersecurity threats: Managed via comprehensive security framework\n');

fprintf('\nOperational Risks:\n');
fprintf(' Workforce resistance: Addressed through training and involvement\n');
fprintf(' Process disruption: Minimised via parallel implementation\n');
fprintf(' Vendor dependency: Reduced through multi-supplier strategy\n');

fprintf('\nFinancial Risks:\n');
fprintf(' Cost overruns: Controlled through detailed project management\n');
fprintf(' Benefit realisation: Ensured via continuous monitoring\n');
fprintf(' Market changes: Addressed through flexible system design\n');

% Compliance and standards
fprintf('\nCompliance and Standards:\n');
fprintf('========================\n');
fprintf('Industry Standards:\n');
fprintf(' ISO 9001:2015 (Quality Management)\n');
fprintf(' ISO 14001:2015 (Environmental Management)\n');
fprintf(' ISO 45001:2018 (Occupational Health and Safety)\n');
fprintf(' IEC 62443 (Industrial Cybersecurity)\n');

fprintf('\nRegulatory Compliance:\n');
fprintf(' GDPR (Data Protection)\n');
fprintf(' OSHA (Workplace Safety)\n');
fprintf(' FDA 21 CFR Part 11 (Pharmaceutical)\n');
fprintf(' ISO 13485 (Medical Devices)\n');

fprintf('\nTechnical Standards:\n');
fprintf(' OPC UA (Industrial Communication)\n');
fprintf(' MTConnect (Manufacturing Data)\n');
fprintf(' MQTT (IoT Messaging)\n');
fprintf(' JSON-LD (Data Interchange)\n');

% Conclusion and next steps
fprintf('\nConclusion and Next Steps:\n');
fprintf('=========================\n');
fprintf('The integration of computer vision with Industry 4.0 and digital twin\n');
fprintf('technologies represents a transformative opportunity for manufacturing\n');
fprintf('excellence. The demonstrated capabilities provide:\n');

fprintf('\n Enhanced quality control through intelligent vision systems\n');
fprintf(' Predictive maintenance reducing unplanned downtime\n');
fprintf(' Real-time optimisation of manufacturing processes\n');
fprintf(' Comprehensive digital transformation of operations\n');
fprintf(' Significant return on investment and competitive advantage\n');

fprintf('\nRecommended Next Steps:\n');
fprintf('1. Develop detailed implementation roadmap\n');
fprintf('2. Establish cross-functional project team\n');
fprintf('3. Conduct pilot implementation on critical production line\n');
fprintf('4. Develop workforce training programmes\n');
fprintf('5. Implement cybersecurity framework\n');
fprintf('6. Establish performance monitoring systems\n');
fprintf('7. Plan for organisation-wide rollout\n');
fprintf('8. Develop continuous improvement processes\n');

fprintf('\nSuccess Factors:\n');
fprintf(' Strong leadership commitment and vision\n');
fprintf(' Clear business case and objectives\n');
fprintf(' Comprehensive change management\n');
fprintf(' Robust technology architecture\n');
fprintf(' Continuous learning and adaptation\n');
fprintf(' Focus on value creation and ROI\n');
fprintf(' Collaboration across entire organisation\n');
fprintf(' Long-term strategic perspective\n');

fprintf('\n' + string(repmat('=', 1, 70)) + '\n');
fprintf('END OF INDUSTRY 4.0 ANALYTICS REPORT\n');
fprintf(string(repmat('=', 1, 70)) + '\n');

% Local functions (moved to end so this listing is a valid MATLAB script)
function [factory, prodLine, metrics] = createIndustry40Environment()
    % Create simulated Industry 4.0 factory environment
    
    fprintf('Creating Industry 4.0 manufacturing environment...\n');
    
    % Factory configuration
    factory = struct();
    factory.name = 'Smart Manufacturing Facility';
    factory.productionLines = 3;
    factory.workstations = [5, 4, 6]; % Per production line
    factory.sensors = {'vision', 'temperature', 'vibration', 'pressure'};
    
    % Production line configuration
    prodLine = struct();
    prodLine.id = 1;
    prodLine.name = 'Assembly Line Alpha';
    prodLine.workstations = createWorkstations(factory.workstations(1));
    prodLine.targetThroughput = 100; % Units per hour
    prodLine.qualityTarget = 0.98; % 98% pass rate
    
    % Quality metrics
    metrics = struct();
    metrics.overallEffectiveness = 0.85;
    metrics.qualityRate = 0.96;
    metrics.availability = 0.92;
    metrics.performance = 0.88;
    
    fprintf('Industry 4.0 environment created\n');
end

function workstations = createWorkstations(numStations)
    % Create workstations with integrated vision systems
    
    workstations = [];
    
    for i = 1:numStations
        station = struct();
        station.id = i;
        station.name = sprintf('Station_%d', i);
        station.type = getStationType(i);
        station.visionSystem = createVisionSystem(station.type);
        station.sensors = createSensorArray();
        station.status = 'operational';
        station.efficiency = 0.85 + rand() * 0.1; % 85-95% efficiency
        
        workstations = [workstations; station];
    end
end

function stationType = getStationType(stationId)
    % Assign station types based on production sequence
    
    stationTypes = {'component_placement', 'assembly', 'inspection', 'packaging', 'quality_control'};
    stationType = stationTypes{min(stationId, length(stationTypes))};
end

function visionSystem = createVisionSystem(stationType)
    % Create vision system configuration for specific station type
    
    visionSystem = struct();
    visionSystem.cameras = [];
    visionSystem.lighting = [];
    visionSystem.algorithms = [];
    
    switch stationType
        case 'component_placement'
            visionSystem.cameras = createCameraConfig('placement');
            visionSystem.lighting = {'structured_light', 'led_ring'};
            visionSystem.algorithms = {'template_matching', 'edge_detection'};
            visionSystem.accuracy = 0.99;
            visionSystem.speed = 50; % Inspections per minute
            
        case 'assembly'
            visionSystem.cameras = createCameraConfig('assembly');
            visionSystem.lighting = {'diffuse', 'directional'};
            visionSystem.algorithms = {'feature_matching', 'dimensional_measurement'};
            visionSystem.accuracy = 0.97;
            visionSystem.speed = 30;
            
        case 'inspection'
            visionSystem.cameras = createCameraConfig('inspection');
            visionSystem.lighting = {'brightfield', 'darkfield', 'uv'};
            visionSystem.algorithms = {'defect_detection', 'surface_analysis', 'ai_classification'};
            visionSystem.accuracy = 0.98;
            visionSystem.speed = 40;
            
        case 'packaging'
            visionSystem.cameras = createCameraConfig('packaging');
            visionSystem.lighting = {'overhead', 'side_lighting'};
            visionSystem.algorithms = {'barcode_reading', 'label_verification', 'presence_detection'};
            visionSystem.accuracy = 0.995;
            visionSystem.speed = 80;
            
        case 'quality_control'
            visionSystem.cameras = createCameraConfig('quality');
            visionSystem.lighting = {'multi_angle', 'polarised'};
            visionSystem.algorithms = {'comprehensive_inspection', 'statistical_analysis', 'trend_monitoring'};
            visionSystem.accuracy = 0.99;
            visionSystem.speed = 25;
    end
    
    visionSystem.digitalTwinEnabled = true;
    visionSystem.dataLogging = true;
    visionSystem.remoteMonitoring = true;
end

function cameraConfig = createCameraConfig(applicationType)
    % Create camera configuration for specific application
    
    cameraConfig = struct();
    
    switch applicationType
        case 'placement'
            cameraConfig.type = 'area_scan';
            cameraConfig.resolution = [2048, 2048];
            cameraConfig.frameRate = 60;
            cameraConfig.lensType = 'telecentric';
            
        case 'assembly'
            cameraConfig.type = 'line_scan';
            cameraConfig.resolution = [4096, 1];
            cameraConfig.frameRate = 200;
            cameraConfig.lensType = 'standard';
            
        case 'inspection'
            cameraConfig.type = 'multi_spectral';
            cameraConfig.resolution = [1920, 1080];
            cameraConfig.frameRate = 30;
            cameraConfig.lensType = 'macro';
            
        case 'packaging'
            cameraConfig.type = 'area_scan';
            cameraConfig.resolution = [1280, 1024];
            cameraConfig.frameRate = 100;
            cameraConfig.lensType = 'wide_angle';
            
        case 'quality'
            cameraConfig.type = 'high_resolution';
            cameraConfig.resolution = [4096, 4096];
            cameraConfig.frameRate = 15;
            cameraConfig.lensType = 'precision';
    end
    
    cameraConfig.interface = 'gigabit_ethernet';
    cameraConfig.triggerMode = 'external';
    cameraConfig.calibrated = true;
end

function sensors = createSensorArray()
    % Create comprehensive sensor array for workstation monitoring
    
    sensors = struct();
    
    % Environmental sensors
    sensors.temperature = 22 + randn() * 2; % Celsius
    sensors.humidity = 45 + randn() * 5; % Percentage
    sensors.vibration = 0.1 + rand() * 0.05; % m/s
    sensors.pressure = 101.3 + randn() * 0.5; % kPa
    
    % Production sensors
    sensors.partCount = randi([0, 50]); % Parts processed
    sensors.cycleTime = 30 + randn() * 5; % Seconds
    sensors.powerConsumption = 2.5 + rand() * 0.5; % kW
    
    % Quality sensors
    sensors.defectRate = 0.02 + rand() * 0.03; % 2-5% defect rate
    sensors.reworkRate = 0.01 + rand() * 0.02; % 1-3% rework rate
    
    sensors.timestamp = datetime('now');
end

function digitalTwin = createDigitalTwin(physicalSystem, historicalData)
    % Create digital twin of manufacturing system
    
    fprintf('Creating digital twin for manufacturing system...\n');
    
    digitalTwin = struct();
    digitalTwin.physicalSystemId = physicalSystem.id;
    digitalTwin.model = createSystemModel(physicalSystem);
    digitalTwin.realTimeData = [];
    digitalTwin.predictions = [];
    digitalTwin.optimisations = [];
    
    % Initialize with historical data
    if nargin > 1 && ~isempty(historicalData)
        digitalTwin = updateDigitalTwinModel(digitalTwin, historicalData);
    end
    
    digitalTwin.lastUpdate = datetime('now');
    digitalTwin.syncStatus = 'synchronized';
    
    fprintf('Digital twin created for system %s\n', physicalSystem.name);
end

function model = createSystemModel(physicalSystem)
    % Create mathematical model of physical system
    
    model = struct();
    
    % Process model parameters
    model.throughputModel = createThroughputModel(physicalSystem);
    model.qualityModel = createQualityModel(physicalSystem);
    model.efficiencyModel = createEfficiencyModel(physicalSystem);
    model.maintenanceModel = createMaintenanceModel(physicalSystem);
    
    % Model validation metrics
    model.accuracy = 0.92;
    model.confidence = 0.88;
    model.lastValidation = datetime('now');
end

function throughputModel = createThroughputModel(system)
    % Create throughput prediction model
    
    throughputModel = struct();
    throughputModel.baselineRate = system.targetThroughput;
    throughputModel.efficiencyFactors = {
        'temperature', 0.95;
        'humidity', 0.98;
        'vibration', 0.92;
        'maintenance_status', 0.90
    };
    
    % Simple linear model coefficients
    throughputModel.coefficients = [1.0, -0.02, -0.01, -0.05, 0.15];
    throughputModel.intercept = system.targetThroughput * 0.8;
end

function qualityModel = createQualityModel(system)
    % Create quality prediction model
    
    qualityModel = struct();
    qualityModel.baselineQuality = system.qualityTarget;
    qualityModel.defectProbability = 0.02;
    
    % Vision system contribution to quality model
    qualityModel.visionAccuracy = system.visionSystem.accuracy;
    qualityModel.inspectionCoverage = 0.95;
    
    % Environmental factors affecting quality
    qualityModel.environmentalFactors = {
        'temperature_stability', 0.98;
        'vibration_level', 0.95;
        'lighting_consistency', 0.99
    };
end

function efficiencyModel = createEfficiencyModel(system)
    % Create overall equipment effectiveness (OEE) model
    
    efficiencyModel = struct();
    efficiencyModel.availability = 0.92;
    efficiencyModel.performance = 0.88;
    efficiencyModel.quality = system.qualityTarget;
    efficiencyModel.oee = efficiencyModel.availability * efficiencyModel.performance * efficiencyModel.quality;
    
    % Factors affecting efficiency
    efficiencyModel.bottleneckFactors = {'material_supply', 'operator_skill', 'equipment_condition'};
end

function maintenanceModel = createMaintenanceModel(system)
    % Create predictive maintenance model
    
    maintenanceModel = struct();
    maintenanceModel.mtbf = 720; % Mean time between failures (hours)
    maintenanceModel.mttr = 2; % Mean time to repair (hours)
    maintenanceModel.lastMaintenance = datetime('now') - hours(randi([24, 168])); % 1-7 days ago
    
    % Condition indicators
    maintenanceModel.healthScore = 0.85 + rand() * 0.1; % 85-95%
    maintenanceModel.degradationRate = 0.001; % Per hour
    maintenanceModel.maintenanceThreshold = 0.7;
end

function digitalTwin = updateDigitalTwinRealTime(digitalTwin, sensorData, visionData)
    % Update digital twin with real-time data
    
    fprintf('Updating digital twin with real-time data...\n');
    
    % Integrate sensor data
    digitalTwin.realTimeData.sensors = sensorData;
    digitalTwin.realTimeData.timestamp = datetime('now');
    
    % Integrate vision system data
    digitalTwin.realTimeData.vision = visionData;
    
    % Update system state estimation
    digitalTwin = updateSystemState(digitalTwin);
    
    % Generate predictions
    digitalTwin = generatePredictions(digitalTwin);
    
    % Identify optimisation opportunities
    digitalTwin = identifyOptimisations(digitalTwin);
    
    digitalTwin.lastUpdate = datetime('now');
    digitalTwin.syncStatus = 'synchronized';
    
    fprintf('Digital twin updated successfully\n');
end

function digitalTwin = updateSystemState(digitalTwin)
    % Update current system state based on real-time data
    
    sensorData = digitalTwin.realTimeData.sensors;
    
    % Calculate current throughput
    currentThroughput = estimateCurrentThroughput(digitalTwin, sensorData);
    
    % Calculate current quality metrics
    currentQuality = estimateCurrentQuality(digitalTwin, sensorData);
    
    % Calculate current efficiency
    currentEfficiency = estimateCurrentEfficiency(digitalTwin, sensorData);
    
    % Update system state
    digitalTwin.currentState = struct();
    digitalTwin.currentState.throughput = currentThroughput;
    digitalTwin.currentState.quality = currentQuality;
    digitalTwin.currentState.efficiency = currentEfficiency;
    digitalTwin.currentState.timestamp = datetime('now');
end

function throughput = estimateCurrentThroughput(digitalTwin, sensorData)
    % Estimate current throughput based on sensor data
    
    model = digitalTwin.model.throughputModel;
    
    % Environmental factors
    tempFactor = 1 - 0.01 * abs(sensorData.temperature - 22); % Optimal at 22～C
    humidityFactor = 1 - 0.005 * abs(sensorData.humidity - 45); % Optimal at 45%
    vibrationFactor = 1 - 0.1 * sensorData.vibration; % Lower vibration is better
    
    % Calculate adjusted throughput
    throughput = model.baselineRate * tempFactor * humidityFactor * vibrationFactor;
    throughput = max(0, throughput); % Ensure non-negative
end

function quality = estimateCurrentQuality(digitalTwin, sensorData)
    % Estimate current quality based on sensor and vision data
    
    model = digitalTwin.model.qualityModel;
    
    % Base quality from model
    baseQuality = model.baselineQuality;
    
    % Environmental impact on quality
    environmentalImpact = 1 - 0.002 * abs(sensorData.temperature - 22) - ...
                         0.001 * abs(sensorData.humidity - 45) - ...
                         0.05 * sensorData.vibration;
    
    % Vision system contribution
    visionContribution = model.visionAccuracy * model.inspectionCoverage;
    
    quality = baseQuality * environmentalImpact * visionContribution;
    quality = max(0, min(1, quality)); % Clamp to [0, 1]
end

function efficiency = estimateCurrentEfficiency(digitalTwin, sensorData)
    % Estimate current overall equipment effectiveness
    
    model = digitalTwin.model.efficiencyModel;
    
    % Current availability (based on operational status)
    availability = 0.95; % Assume high availability for this simulation
    
    % Current performance (based on cycle time)
    expectedCycleTime = 30; % seconds
    actualCycleTime = sensorData.cycleTime;
    performance = expectedCycleTime / actualCycleTime;
    performance = min(1, performance); % Cap at 100%
    
    % Current quality
    quality = digitalTwin.currentState.quality;
    
    efficiency = availability * performance * quality;
end

function digitalTwin = generatePredictions(digitalTwin)
    % Generate predictions for future system behaviour
    
    fprintf('Generating system predictions...\n');
    
    digitalTwin.predictions = struct();
    
    % Short-term predictions (next hour)
    digitalTwin.predictions.shortTerm = generateShortTermPredictions(digitalTwin);
    
    % Medium-term predictions (next day)
    digitalTwin.predictions.mediumTerm = generateMediumTermPredictions(digitalTwin);
    
    % Long-term predictions (next week)
    digitalTwin.predictions.longTerm = generateLongTermPredictions(digitalTwin);
    
    digitalTwin.predictions.timestamp = datetime('now');
end

function predictions = generateShortTermPredictions(digitalTwin)
    % Generate short-term predictions (next hour)
    
    currentState = digitalTwin.currentState;
    
    predictions = struct();
    
    % Predict throughput for next hour
    predictions.throughput = currentState.throughput * (0.98 + rand() * 0.04); % ㊣2% variation
    
    % Predict quality for next hour
    predictions.quality = currentState.quality * (0.99 + rand() * 0.02); % ㊣1% variation
    
    % Predict efficiency for next hour
    predictions.efficiency = currentState.efficiency * (0.97 + rand() * 0.06); % ㊣3% variation
    
    % Predict potential issues
    predictions.riskFactors = identifyShortTermRisks(digitalTwin);
    
    predictions.confidence = 0.92;
    predictions.timeHorizon = hours(1);
end

function predictions = generateMediumTermPredictions(digitalTwin)
    % Generate medium-term predictions (next day)
    
    predictions = struct();
    
    % Predict daily production
    currentThroughput = digitalTwin.currentState.throughput;
    predictions.dailyProduction = currentThroughput * 8 * (0.95 + rand() * 0.1); % 8-hour shift
    
    % Predict maintenance needs
    maintenanceModel = digitalTwin.model.maintenanceModel;
    timeSinceMaintenance = hours(datetime('now') - maintenanceModel.lastMaintenance);
    
    predictions.maintenanceProbability = timeSinceMaintenance / (maintenanceModel.mtbf * 24);
    predictions.maintenanceProbability = min(1, predictions.maintenanceProbability);
    
    predictions.confidence = 0.78;
    predictions.timeHorizon = hours(24);
end

function predictions = generateLongTermPredictions(digitalTwin)
    % Generate long-term predictions (next week)
    
    predictions = struct();
    
    % Predict weekly performance trends
    predictions.performanceTrend = 'stable'; % Could be 'improving', 'declining', or 'stable'
    predictions.qualityTrend = 'stable';
    predictions.efficiencyTrend = 'stable';
    
    % Predict optimisation potential
    predictions.optimisationPotential = 0.05 + rand() * 0.10; % 5-15% improvement potential
    
    predictions.confidence = 0.65;
    predictions.timeHorizon = hours(168); % 1 week
end

function risks = identifyShortTermRisks(digitalTwin)
    % Identify potential short-term risks
    
    risks = {};
    
    sensorData = digitalTwin.realTimeData.sensors;
    
    % Temperature risk
    if abs(sensorData.temperature - 22) > 3
        risks{end+1} = 'temperature_deviation';
    end
    
    % Vibration risk
    if sensorData.vibration > 0.15
        risks{end+1} = 'excessive_vibration';
    end
    
    % Quality risk
    if sensorData.defectRate > 0.05
        risks{end+1} = 'quality_degradation';
    end
    
    % Efficiency risk
    if sensorData.cycleTime > 35
        risks{end+1} = 'cycle_time_increase';
    end
end

function digitalTwin = identifyOptimisations(digitalTwin)
    % Identify optimisation opportunities
    
    fprintf('Identifying optimisation opportunities...\n');
    
    digitalTwin.optimisations = struct();
    digitalTwin.optimisations.opportunities = [];
    
    currentState = digitalTwin.currentState;
    sensorData = digitalTwin.realTimeData.sensors;
    
    % Throughput optimisation
    if currentState.throughput < digitalTwin.model.throughputModel.baselineRate * 0.9
        optimisation = struct();
        optimisation.type = 'throughput';
        optimisation.description = 'Increase throughput by optimising cycle time';
        optimisation.potential = 0.15; % 15% improvement
        optimisation.priority = 'high';
        digitalTwin.optimisations.opportunities = [digitalTwin.optimisations.opportunities; optimisation];
    end
    
    % Quality optimisation
    if currentState.quality < 0.95
        optimisation = struct();
        optimisation.type = 'quality';
        optimisation.description = 'Improve quality through vision system calibration';
        optimisation.potential = 0.08; % 8% improvement
        optimisation.priority = 'medium';
        digitalTwin.optimisations.opportunities = [digitalTwin.optimisations.opportunities; optimisation];
    end
    
    % Energy optimisation
    if sensorData.powerConsumption > 2.8
        optimisation = struct();
        optimisation.type = 'energy';
        optimisation.description = 'Reduce energy consumption through process optimisation';
        optimisation.potential = 0.12; % 12% reduction
        optimisation.priority = 'low';
        digitalTwin.optimisations.opportunities = [digitalTwin.optimisations.opportunities; optimisation];
    end
    
    digitalTwin.optimisations.timestamp = datetime('now');
end

function analyticsReport = generateIndustry40Analytics(digitalTwin, historicalData, timeFrame)
    % Generate comprehensive Industry 4.0 analytics report
    
    if nargin < 3
        timeFrame = hours(24); % Default to 24 hours
    end
    
    fprintf('Generating Industry 4.0 analytics report...\n');
    
    analyticsReport = struct();
    analyticsReport.reportPeriod = timeFrame;
    analyticsReport.generationTime = datetime('now');
    
    % Performance analytics
    analyticsReport.performance = analyzePerformance(digitalTwin, historicalData, timeFrame);
    
    % Quality analytics
    analyticsReport.quality = analyzeQuality(digitalTwin, historicalData, timeFrame);
    
    % Efficiency analytics
    analyticsReport.efficiency = analyzeEfficiency(digitalTwin, historicalData, timeFrame);
    
    % Predictive analytics
    analyticsReport.predictive = analyzePredictive(digitalTwin);
    
    % Optimisation recommendations
    analyticsReport.recommendations = generateRecommendations(digitalTwin);
    
    fprintf('Analytics report generated successfully\n');
end

function performance = analyzePerformance(digitalTwin, historicalData, timeFrame)
    % Analyze system performance metrics
    
    performance = struct();
    
    % Current performance
    performance.currentThroughput = digitalTwin.currentState.throughput;
    performance.targetThroughput = digitalTwin.model.throughputModel.baselineRate;
    performance.throughputEfficiency = performance.currentThroughput / performance.targetThroughput;
    
    % Historical trends (simulated)
    performance.averageThroughput = performance.targetThroughput * (0.9 + rand() * 0.1);
    performance.trendDirection = 'stable'; % Could be 'increasing', 'decreasing', 'stable'
    performance.variability = 0.05 + rand() * 0.05; % 5-10% coefficient of variation
    
    % Performance indicators
    performance.kpis = struct();
    performance.kpis.oee = digitalTwin.currentState.efficiency;
    performance.kpis.availability = 0.92;
    performance.kpis.performance_rate = 0.88;
    performance.kpis.quality_rate = digitalTwin.currentState.quality;
end

function quality = analyzeQuality(digitalTwin, historicalData, timeFrame)
    % Analyze quality metrics and trends
    
    quality = struct();
    
    % Current quality
    quality.currentQualityRate = digitalTwin.currentState.quality;
    quality.targetQualityRate = digitalTwin.model.qualityModel.baselineQuality;
    quality.qualityPerformance = quality.currentQualityRate / quality.targetQualityRate;
    
    % Defect analysis
    quality.defectRate = digitalTwin.realTimeData.sensors.defectRate;
    quality.reworkRate = digitalTwin.realTimeData.sensors.reworkRate;
    quality.firstPassYield = 1 - quality.defectRate - quality.reworkRate;
    
    % Vision system contribution
    quality.visionSystemAccuracy = digitalTwin.model.qualityModel.visionAccuracy;
    quality.inspectionCoverage = digitalTwin.model.qualityModel.inspectionCoverage;
    quality.falsePositiveRate = 0.02; % 2% false positive rate
    quality.falseNegativeRate = 0.01; % 1% false negative rate
end

function efficiency = analyzeEfficiency(digitalTwin, historicalData, timeFrame)
    % Analyze efficiency metrics
    
    efficiency = struct();
    
    % Overall Equipment Effectiveness (OEE)
    efficiency.oee = digitalTwin.currentState.efficiency;
    efficiency.worldClassOEE = 0.85; % World-class benchmark
    efficiency.oeeGap = efficiency.worldClassOEE - efficiency.oee;
    
    % Efficiency components
    efficiency.availability = 0.92;
    efficiency.performance = 0.88;
    efficiency.quality = digitalTwin.currentState.quality;
    
    % Energy efficiency
    efficiency.energyPerUnit = digitalTwin.realTimeData.sensors.powerConsumption / ...
                              digitalTwin.currentState.throughput;
    efficiency.energyEfficiencyRating = 'good'; % Could be 'excellent', 'good', 'fair', 'poor'
    
    % Resource utilisation
    efficiency.materialUtilisation = 0.94; % 94% material utilisation
    efficiency.labourProductivity = 0.87; % 87% labour productivity
end

function predictive = analyzePredictive(digitalTwin)
    % Analyze predictive insights
    
    predictive = struct();
    
    % Failure predictions
    predictive.failureProbability = digitalTwin.predictions.mediumTerm.maintenanceProbability;
    predictive.timeToFailure = estimateTimeToFailure(digitalTwin);
    
    % Performance predictions
    predictive.performanceForecast = digitalTwin.predictions.longTerm.performanceTrend;
    predictive.qualityForecast = digitalTwin.predictions.longTerm.qualityTrend;
    
    % Optimisation potential
    predictive.optimisationPotential = digitalTwin.predictions.longTerm.optimisationPotential;
    predictive.estimatedBenefits = calculateOptimisationBenefits(digitalTwin);
end

function timeToFailure = estimateTimeToFailure(digitalTwin)
    % Estimate time to next failure
    
    maintenanceModel = digitalTwin.model.maintenanceModel;
    
    currentHealth = maintenanceModel.healthScore;
    degradationRate = maintenanceModel.degradationRate;
    failureThreshold = 0.5; % Health score threshold for failure
    
    timeToFailure = (currentHealth - failureThreshold) / degradationRate;
    timeToFailure = max(0, timeToFailure); % Ensure non-negative
end

function benefits = calculateOptimisationBenefits(digitalTwin)
    % Calculate estimated benefits from optimisations
    
    benefits = struct();
    
    optimisations = digitalTwin.optimisations.opportunities;
    
    benefits.totalPotentialImprovement = 0;
    benefits.estimatedAnnualSavings = 0;
    
    for i = 1:length(optimisations)
        optimisation = optimisations(i);
        
        benefits.totalPotentialImprovement = benefits.totalPotentialImprovement + optimisation.potential;
        
        % Estimate annual savings (simplified calculation)
        switch optimisation.type
            case 'throughput'
                benefits.estimatedAnnualSavings = benefits.estimatedAnnualSavings + 50000; % $50*k
            case 'quality'
                benefits.estimatedAnnualSavings = benefits.estimatedAnnualSavings + 30000; % $30*k
            case 'energy'
                benefits.estimatedAnnualSavings = benefits.estimatedAnnualSavings + 15000; % $15*k
        end
    end
end

function recommendations = generateRecommendations(digitalTwin)
    % Generate actionable recommendations
    
    recommendations = [];
    
    optimisations = digitalTwin.optimisations.opportunities;
    
    for i = 1:length(optimisations)
        optimisation = optimisations(i);
        
        recommendation = struct();
        recommendation.category = optimisation.type;
        recommendation.description = optimisation.description;
        recommendation.priority = optimisation.priority;
        recommendation.implementation = generateImplementationPlan(optimisation);
        recommendation.estimatedROI = calculateROI(optimisation);
        
        recommendations = [recommendations; recommendation];
    end
end

function implementation = generateImplementationPlan(optimisation)
    % Generate implementation plan for optimisation
    
    implementation = struct();
    
    switch optimisation.type
        case 'throughput'
            implementation.steps = {
                'Analyze current bottlenecks',
                'Optimize material flow',
                'Adjust machine parameters',
                'Implement process improvements',
                'Monitor and validate results'
            };
            implementation.duration = 'days(14)'; % 2 weeks
            implementation.resources = {'process_engineer', 'maintenance_technician'};
            
        case 'quality'
            implementation.steps = {
                'Calibrate vision systems',
                'Update inspection algorithms',
                'Train operators',
                'Implement quality controls',
                'Validate improvements'
            };
            implementation.duration = 'days(7)'; % 1 week
            implementation.resources = {'quality_engineer', 'vision_specialist'};
            
        case 'energy'
            implementation.steps = {
                'Conduct energy audit',
                'Optimize equipment settings',
                'Implement power management',
                'Monitor consumption',
                'Report savings'
            };
            implementation.duration = 'days(10)'; % 10 days
            implementation.resources = {'energy_engineer', 'maintenance_staff'};
    end
end

function roi = calculateROI(optimisation)
    % Calculate return on investment for optimisation
    
    % Implementation cost (simplified)
    implementationCost = 10000; % $10*k base cost
    
    switch optimisation.type
        case 'throughput'
            annualBenefit = 50000; % $50*k annual benefit
        case 'quality'
            annualBenefit = 30000; % $30*k annual benefit
        case 'energy'
            annualBenefit = 15000; % $15*k annual benefit
        otherwise
            annualBenefit = 20000; % Default benefit
    end
    
    roi = (annualBenefit - implementationCost) / implementationCost;
end
