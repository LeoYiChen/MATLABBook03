%% chapter_AI_CV_stereo_calibration_01.m
% Comprehensive Stereo Vision Calibration and Rectification System
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_stereo_calibration_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Comprehensive Stereo Vision System Implementation
% Including calibration, rectification, and depth estimation

fprintf('Stereo Vision System: From Calibration to 3*D Reconstruction\n');
fprintf('=========================================================\n');

% Create synthetic stereo calibration data (in practice, use real calibration images)
boardSize = [9, 6]; % Checkerboard pattern size
squareSize = 25; % Square size in mm
numCalibrationImages = 20;

% Generate synthetic calibration data
fprintf('Generating synthetic calibration data...\n');
[imagePoints1, imagePoints2, worldPoints] = generateSyntheticCalibrationData(boardSize, squareSize, numCalibrationImages);


% Perform stereo calibration
fprintf('Performing stereo camera calibration...\n');

% Estimate camera parameters
imageSize = [480, 640];
try
% Use MATLAB's stereo calibration function
% Note: In practice, you would use real calibration images

 
% For demonstration, create stereo parameters manually
% This represents the output of estimateCameraParameters for stereo systems

% Create CameraParameters objects for each camera
intrinsicsMatrix1 = [800, 0, 320; 0, 800, 240; 0, 0, 1];
intrinsicsMatrix2 = [800, 0, 320; 0, 800, 240; 0, 0, 1];

distortionCoeffs1 = [0.1, -0.2, 0, 0, 0]; % k1, k2, p1, p2, k3
distortionCoeffs2 = [0.1, -0.2, 0, 0, 0];

% Create camera parameters (simplified)
cameraParams1 = struct();
cameraParams1.IntrinsicMatrix = intrinsicsMatrix1;
cameraParams1.RadialDistortion = distortionCoeffs1(1:2);
cameraParams1.TangentialDistortion = distortionCoeffs1(3:4);
cameraParams1.ImageSize = imageSize;

cameraParams2 = struct();
cameraParams2.IntrinsicMatrix = intrinsicsMatrix2;
cameraParams2.RadialDistortion = distortionCoeffs2(1:2);
cameraParams2.TangentialDistortion = distortionCoeffs2(3:4);
cameraParams2.ImageSize = imageSize;

% Stereo parameters
R = eye(3); % Rotation between cameras
T = [100; 0; 0]; % Translation between cameras (baseline)

% Essential and Fundamental matrices
E = computeEssentialMatrix(R, T);
F = computeFundamentalMatrix(intrinsicsMatrix1, intrinsicsMatrix2, E);

fprintf('Stereo calibration completed successfully\n');
fprintf('Baseline: %.2f mm\n', norm(T));
fprintf('Rotation between cameras: %.2f degrees\n', acosd(trace(R-eye(3))/2));
catch ME
fprintf('Stereo calibration error: %s\n', ME.message);
fprintf('Using synthetic parameters for demonstration\n');
end

% Helper functions for matrix computations


% Image rectification implementation


% Create synthetic stereo image pair for demonstration
fprintf('Creating synthetic stereo image pair...\n');
imageSize = [480, 640, 3];
[img1, img2, groundTruthDepth] = createSyntheticStereoImages(imageSize);


% Perform stereo rectification
cameraParams1.IntrinsicMatrix = [800, 0, 320; 0, 800, 240; 0, 0, 1];
cameraParams2.IntrinsicMatrix = [800, 0, 320; 0, 800, 240; 0, 0, 1];
cameraParams1.ImageSize = [480, 640];
cameraParams2.ImageSize = [480, 640];

R = eye(3);
T = [100; 0; 0];

[img1_rect, img2_rect, Q] = rectifyStereoImages(img1, img2, cameraParams1, cameraParams2, R, T);

% Visualize calibration results
figure;
subplot(2, 3, 1);
imshow(img1);
title('Left Camera Image');

subplot(2, 3, 2);
imshow(img2);
title('Right Camera Image');

subplot(2, 3, 3);
imshow(groundTruthDepth, []);
colormap('jet');
colorbar;
title('Ground Truth Depth');

subplot(2, 3, 4);
imshow(img1_rect);
title('Rectified Left Image');

subplot(2, 3, 5);
imshow(img2_rect);
title('Rectified Right Image');

subplot(2, 3, 6);
% Show epipolar lines for verification
showEpipolarLines(img1, img2, F);
title('Epipolar Line Verification');


% Stereo calibration accuracy assessment

% Assess calibration quality
calibration_metrics = assessCalibrationAccuracy(imagePoints1, imagePoints2, worldPoints, cameraParams1, cameraParams2, R, T);

% Advanced calibration techniques discussion
fprintf('\nAdvanced Calibration Techniques:\n');
fprintf('================================\n');
fprintf('1. Subpixel corner detection for improved accuracy\n');
fprintf('2. Multiple calibration pattern sizes and orientations\n');
fprintf('3. Temporal stability analysis across multiple sessions\n');
fprintf('4. Automatic outlier detection and rejection\n');
fprintf('5. Bundle adjustment for global optimization\n');
fprintf('6. Self-calibration techniques for dynamic scenarios\n');

% Best practices summary
fprintf('\nStereo Calibration Best Practices:\n');
fprintf('==================================\n');
fprintf('1. Use high-quality calibration patterns with known geometry\n');
fprintf('2. Capture calibration images across the full working volume\n');
fprintf('3. Ensure calibration pattern fills significant portion of image\n');
fprintf('4. Include variety of pattern orientations and positions\n');
fprintf('5. Minimize motion blur and ensure good lighting conditions\n');
fprintf('6. Validate calibration accuracy through 3*D measurement tests\n');
fprintf('7. Consider temporal stability for long-term deployments\n');
fprintf('8. Document calibration procedures and maintain calibration records\n');

% Local functions (moved to end so this listing is a valid MATLAB script)
function [imagePoints1, imagePoints2, worldPoints] = generateSyntheticCalibrationData(boardSize, squareSize, numImages)
% Generate world coordinates for checkerboard pattern
[X, Y] = meshgrid(0:(boardSize(1)-1), 0:(boardSize(2)-1));
worldPoints = [X(:) * squareSize, Y(:) * squareSize, zeros(numel(X), 1)];

 
% Define synthetic camera parameters
imageSize = [480, 640]; % Standard VGA resolution
focalLength = [800, 800]; % Focal length in pixels
principalPoint = imageSize / 2;

% Define stereo baseline (distance between cameras)
baseline = 100; % mm

% Synthetic camera intrinsics
K1 = [focalLength(1), 0, principalPoint(1);
      0, focalLength(2), principalPoint(2);
      0, 0, 1];
K2 = K1; % Assuming identical cameras

% Initialize storage for image points
imagePoints1 = zeros(size(worldPoints, 1), 2, numImages);
imagePoints2 = zeros(size(worldPoints, 1), 2, numImages);

for i = 1:numImages
    % Generate random camera poses for calibration
    rotationAngle = (rand(1, 3) - 0.5) * 0.3; % Small random rotations
    translation = [(rand - 0.5) * 100, (rand - 0.5) * 100, 200 + rand * 100]; % Random translation
    
    % Create rotation matrix
    R1 = rotx(rotationAngle(1)) * roty(rotationAngle(2)) * rotz(rotationAngle(3));
    t1 = translation';
    
    % Second camera position (baseline offset)
    R2 = R1;
    t2 = t1 + [baseline; 0; 0]; % Parallel stereo configuration
    
    % Project world points to image coordinates
    worldPointsHom = [worldPoints, ones(size(worldPoints, 1), 1)]';
    
    % Camera 1 projection
    P1 = K1 * [R1, t1];
    projectedPoints1 = P1 * worldPointsHom;
    projectedPoints1 = projectedPoints1 ./ projectedPoints1(3, :);
    imagePoints1(:, :, i) = projectedPoints1(1:2, :)';
    
    % Camera 2 projection
    P2 = K2 * [R2, t2];
    projectedPoints2 = P2 * worldPointsHom;
    projectedPoints2 = projectedPoints2 ./ projectedPoints2(3, :);
    imagePoints2(:, :, i) = projectedPoints2(1:2, :)';
    
    % Add small amount of noise to simulate real conditions
    noise_std = 0.1;
    imagePoints1(:, :, i) = imagePoints1(:, :, i) + randn(size(imagePoints1(:, :, i))) * noise_std;
    imagePoints2(:, :, i) = imagePoints2(:, :, i) + randn(size(imagePoints2(:, :, i))) * noise_std;
end
end

function E = computeEssentialMatrix(R, T)
% Essential matrix: E = [t]_x * R
% where [t]_x is the skew-symmetric matrix of translation vector
T_skew = [0, -T(3), T(2);
T(3), 0, -T(1);
-T(2), T(1), 0];
E = T_skew * R;
end

function F = computeFundamentalMatrix(K1, K2, E)
% Fundamental matrix: F = K2^(-T) * E * K1^(-1)
F = inv(K2') * E * inv(K1);
end

function [img1_rect, img2_rect, Q] = rectifyStereoImages(img1, img2, cameraParams1, cameraParams2, R, T)
fprintf('Performing stereo rectification...\n');

 
% Extract camera matrices
K1 = cameraParams1.IntrinsicMatrix;
K2 = cameraParams2.IntrinsicMatrix;

% Compute rectification transforms
imageSize = cameraParams1.ImageSize;

% Simplified rectification (Bouguet's method)
% 1. Compute rotation matrices to align epipolar lines
e1 = T / norm(T); % Epipolar direction
e2 = [-T(2); T(1); 0] / norm([-T(2); T(1); 0]); % Perpendicular direction
e3 = cross(e1, e2); % Third orthogonal direction

R_rect1 = [e1'; e2'; e3'];
R_rect2 = R * R_rect1;

% Compute new projection matrices
P1_rect = K1 * [R_rect1, zeros(3,1)];
P2_rect = K2 * [R_rect2, -R_rect2 * T];

% Compute disparity-to-depth mapping matrix Q
Q = computeDisparityToDepthMatrix(K1, K2, R_rect1, R_rect2, T);

% Apply rectification transforms (simplified)
img1_rect = img1; % In practice, apply geometric transformation
img2_rect = img2;

fprintf('Rectification completed\n');
fprintf('Rectified image size: %dx%d\n', imageSize(2), imageSize(1));
end

function Q = computeDisparityToDepthMatrix(K1, K2, R1, R2, T)
% Compute Q matrix for disparity-to-depth conversion
% Q transforms [x, y, disparity, 1] to [X, Y, Z, W] where X/W, Y/W, Z/W are 3*D coordinates

 
fx = K1(1,1);
fy = K1(2,2);
cx = K1(1,3);
cy = K2(2,3);
baseline = norm(T);

Q = [1, 0, 0, -cx;
     0, 1, 0, -cy;
     0, 0, 0, fx;
     0, 0, -1/baseline, 0];
end

function [img1, img2, depthMap] = createSyntheticStereoImages(imageSize)
% Create synthetic stereo pair with known geometry

 
% Create a scene with multiple depth layers
img1 = zeros(imageSize, 'uint8');
img2 = zeros(imageSize, 'uint8');
depthMap = zeros(imageSize(1), imageSize(2));

% Background plane
img1(:, :, 1) = 50; % Red channel
img1(:, :, 2) = 100; % Green channel
img1(:, :, 3) = 150; % Blue channel
depthMap(:, :) = 1000; % 1000*mm depth

% Add geometric objects at different depths
% Foreground rectangle
rect1_coords = [100, 150, 200, 100]; % [x, y, width, height]
x_range = rect1_coords(1):(rect1_coords(1) + rect1_coords(3));
y_range = rect1_coords(2):(rect1_coords(2) + rect1_coords(4));

if max(x_range) <= imageSize(2) && max(y_range) <= imageSize(1)
    img1(y_range, x_range, :) = 200; % Bright object
    depthMap(y_range, x_range) = 500; % 500*mm depth
end

% Middle ground circle
center = [400, 200];
radius = 50;
[X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
circle_mask = (X - center(1)).^2 + (Y - center(2)).^2 <= radius^2;

for c = 1:3
    channel = img1(:, :, c);
    channel(circle_mask) = 150;
    img1(:, :, c) = channel;
end
depthMap(circle_mask) = 750; % 750*mm depth

% Create right image with disparity
baseline = 100; % mm
focal_length = 800; % pixels

img2 = img1; % Start with left image

% Apply disparity based on depth
for y = 1:imageSize(1)
    for x = 1:imageSize(2)
        depth = depthMap(y, x);
        disparity = (baseline * focal_length) / depth; % Disparity in pixels
        
        % Shift pixel in right image
        x_shifted = round(x - disparity);
        
        if x_shifted >= 1 && x_shifted <= imageSize(2)
            img2(y, x_shifted, :) = img1(y, x, :);
        end
    end
end

% Fill occlusions in right image
for y = 1:imageSize(1)
    for x = 1:imageSize(2)
        if all(img2(y, x, :) == 0)
            % Fill with background values
            img2(y, x, :) = [50, 100, 150];
        end
    end
end
end

function showEpipolarLines(img1, img2, F)
% Demonstrate epipolar geometry
% Select points in left image and show corresponding epipolar lines in right image

 
% Convert to grayscale for display
if size(img1, 3) == 3
    img1_gray = rgb2gray(img1);
    img2_gray = rgb2gray(img2);
else
    img1_gray = img1;
    img2_gray = img2;
end

% Display side-by-side images
combined_img = [img1_gray, img2_gray];
imshow(combined_img);

% Select sample points in left image
sample_points = [200, 150; 400, 250; 300, 350]; % [x, y] coordinates

hold on;
% Plot points in left image
plot(sample_points(:, 1), sample_points(:, 2), 'ro', 'MarkerSize', 8, 'LineWidth', 2);

% Compute and plot epipolar lines in right image
imageWidth = size(img1_gray, 2);

for i = 1:size(sample_points, 1)
    % Homogeneous coordinates
    p = [sample_points(i, :), 1]';
    
    % Epipolar line in right image: l = F * p
    l = F * p;
    
    % Line equation: ax + by + c = 0
    % Solve for y at x = 0 and x = image_width
    x_coords = [1, imageWidth];
    y_coords = -(l(1) * x_coords + l(3)) / l(2);
    
    % Offset x coordinates for right image display
    x_coords_right = x_coords + imageWidth;
    
    % Plot epipolar line
    if all(y_coords > 0) && all(y_coords <= size(img1_gray, 1))
        plot(x_coords_right, y_coords, 'r-', 'LineWidth', 2);
    end
end

hold off;

% Add text labels
text(size(img1_gray, 2)/2, 20, 'Left Image', 'HorizontalAlignment', 'center', 'Color', 'white', 'FontSize', 12);
text(size(img1_gray, 2) * 1.5, 20, 'Right Image', 'HorizontalAlignment', 'center', 'Color', 'white', 'FontSize', 12);
end

function calibration_metrics = assessCalibrationAccuracy(imagePoints1, imagePoints2, worldPoints, cameraParams1, cameraParams2, R, T)
fprintf('\nCalibration Accuracy Assessment:\n');
fprintf('================================\n');

 
calibration_metrics = struct();

% Reprojection error analysis
total_error1 = 0;
total_error2 = 0;
num_points = 0;

for i = 1:size(imagePoints1, 3)
    % Get image points for current image
    pts1 = squeeze(imagePoints1(:, :, i));
    pts2 = squeeze(imagePoints2(:, :, i));
    world_pts = worldPoints;
    
    % Project world points to image coordinates using calibrated parameters
    % (Simplified projection for demonstration)
    K1 = cameraParams1.IntrinsicMatrix;
    K2 = cameraParams2.IntrinsicMatrix;
    
    % Assume identity rotation and zero translation for camera 1 (reference)
    R1 = eye(3);
    t1 = [0; 0; 0];
    
    % Camera 2 has rotation R and translation T relative to camera 1
    R2 = R;
    t2 = T;
    
    % Simplified projection (assuming world points are at various depths)
    world_pts_3d = [world_pts, 500 * ones(size(world_pts, 1), 1)]; % Assume 500*mm depth
    
    % Project to camera 1
    world_pts_hom = [world_pts_3d, ones(size(world_pts_3d, 1), 1)]';
    P1 = K1 * [R1, t1];
    projected1 = P1 * world_pts_hom;
    projected1 = projected1 ./ projected1(3, :);
    projected1 = projected1(1:2, :)';
    
    % Project to camera 2
    P2 = K2 * [R2, t2];
    projected2 = P2 * world_pts_hom;
    projected2 = projected2 ./ projected2(3, :);
    projected2 = projected2(1:2, :)';
    
    % Compute reprojection errors
    error1 = sqrt(sum((pts1 - projected1).^2, 2));
    error2 = sqrt(sum((pts2 - projected2).^2, 2));
    
    total_error1 = total_error1 + sum(error1);
    total_error2 = total_error2 + sum(error2);
    num_points = num_points + length(error1);
end

mean_error1 = total_error1 / num_points;
mean_error2 = total_error2 / num_points;
mean_error_overall = (total_error1 + total_error2) / (2 * num_points);

calibration_metrics.mean_reprojection_error_camera1 = mean_error1;
calibration_metrics.mean_reprojection_error_camera2 = mean_error2;
calibration_metrics.mean_reprojection_error_overall = mean_error_overall;

% Stereo geometry metrics
baseline_length = norm(T);
calibration_metrics.baseline_length = baseline_length;
calibration_metrics.rotation_angle = acosd(trace(R-eye(3))/2);

fprintf('Mean reprojection error (Camera 1): %.3f pixels\n', mean_error1);
fprintf('Mean reprojection error (Camera 2): %.3f pixels\n', mean_error2);
fprintf('Overall mean reprojection error: %.3f pixels\n', mean_error_overall);
fprintf('Stereo baseline: %.2f mm\n', baseline_length);
fprintf('Rotation between cameras: %.2f degrees\n', calibration_metrics.rotation_angle);

% Quality assessment
if mean_error_overall < 0.5
    fprintf('Calibration quality: Excellent\n');
elseif mean_error_overall < 1.0
    fprintf('Calibration quality: Good\n');
elseif mean_error_overall < 2.0
    fprintf('Calibration quality: Acceptable\n');
else
    fprintf('Calibration quality: Poor - consider recalibration\n');
end
end
