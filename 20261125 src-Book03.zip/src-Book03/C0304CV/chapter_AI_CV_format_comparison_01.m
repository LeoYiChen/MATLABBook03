%% chapter_AI_CV_format_comparison_01.m
% Image Format Comparison and Quality Assessment
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_format_comparison_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Load high-quality reference image
reference_image = imread('cameraman.tif');

% Save in different formats with varying quality settings
imwrite(reference_image, 'output_png.png');
imwrite(reference_image, 'output_jpeg_high.jpg', 'Quality', 95);
imwrite(reference_image, 'output_jpeg_medium.jpg', 'Quality', 75);
imwrite(reference_image, 'output_jpeg_low.jpg', 'Quality', 50);

% Load compressed versions for comparison
png_image = imread('output_png.png');
jpeg_high = imread('output_jpeg_high.jpg');
jpeg_medium = imread('output_jpeg_medium.jpg');
jpeg_low = imread('output_jpeg_low.jpg');

% Calculate file sizes
ref_info = dir('cameraman.tif');
png_info = dir('output_png.png');
jpeg_high_info = dir('output_jpeg_high.jpg');
jpeg_medium_info = dir('output_jpeg_medium.jpg');
jpeg_low_info = dir('output_jpeg_low.jpg');

% Calculate PSNR for quality assessment
psnr_png = psnr(png_image, reference_image);
psnr_jpeg_high = psnr(jpeg_high, reference_image);
psnr_jpeg_medium = psnr(jpeg_medium, reference_image);
psnr_jpeg_low = psnr(jpeg_low, reference_image);

% Display compression statistics
fprintf('Format Comparison Results:\n');
fprintf('Reference TIFF: %d bytes\n', ref_info.bytes);
fprintf('PNG: %d bytes (%.1fx compression), PSNR: %.2f dB\n', ...
    png_info.bytes, ref_info.bytes/png_info.bytes, psnr_png);
fprintf('JPEG High: %d bytes (%.1fx compression), PSNR: %.2f dB\n', ...
    jpeg_high_info.bytes, ref_info.bytes/jpeg_high_info.bytes, psnr_jpeg_high);
fprintf('JPEG Medium: %d bytes (%.1fx compression), PSNR: %.2f dB\n', ...
    jpeg_medium_info.bytes, ref_info.bytes/jpeg_medium_info.bytes, psnr_jpeg_medium);
fprintf('JPEG Low: %d bytes (%.1fx compression), PSNR: %.2f dB\n', ...
    jpeg_low_info.bytes, ref_info.bytes/jpeg_low_info.bytes, psnr_jpeg_low);

% Visualise compression artefacts
figure;
subplot(2,3,1); imshow(reference_image); title('Reference TIFF');
subplot(2,3,2); imshow(png_image); title('PNG (Lossless)');
subplot(2,3,3); imshow(jpeg_high); title('JPEG Quality 95');
subplot(2,3,4); imshow(jpeg_medium); title('JPEG Quality 75');
subplot(2,3,5); imshow(jpeg_low); title('JPEG Quality 50');

% Show difference images to highlight artefacts
diff_jpeg_high = abs(double(reference_image) - double(jpeg_high));
subplot(2,3,6); imshow(diff_jpeg_high, []); title('High Quality Difference');
