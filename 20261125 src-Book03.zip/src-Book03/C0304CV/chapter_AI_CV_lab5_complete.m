%% chapter_AI_CV_lab5_complete.m
% Comprehensive Explainable AI Framework Implementation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_lab5_complete
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% Comprehensive Explainable AI Framework for Computer Vision
% Author: Dr Yi Chen
% Created: January 2025
% MATLAB Version: R2024a or later
% Description: Complete explainable AI framework with multiple explanation
%              methods, evaluation metrics, and visualization tools


% Execute main function
explainableResults = explainableAIFramework();

% Local functions (moved to end so this listing is a valid MATLAB script)
function explainableResults = explainableAIFramework()
    %% Main function for explainable AI framework
    
    fprintf('Explainable AI Framework for Computer Vision\n');
    fprintf('===========================================\n');
    
    % Initialize explainable AI framework
    explainableFramework = initializeExplainableFramework();
    
    % Create test dataset and models
    [testData, models] = createExplainableTestData();
    
    % Perform comprehensive explainable AI analysis
    explainableResults = performExplainableAnalysis(testData, models, explainableFramework);
    
    % Generate explainability report
    generateExplainabilityReport(explainableResults);
    
    % Visualise explainable AI results
    visualiseExplainableResults(explainableResults);
end

function framework = initializeExplainableFramework()
    %% Initialize comprehensive explainable AI framework
    
    fprintf('Initializing explainable AI framework...\n');
    
    framework = struct();
    
    % Explanation methods
    framework.methods = {
        'integrated_gradients',
        'gradcam',
        'lime',
        'shap',
        'occlusion',
        'counterfactual'
    };
    
    % Evaluation metrics
    framework.metrics = {
        'faithfulness',
        'stability',
        'comprehensiveness',
        'sufficiency',
        'sensitivity'
    };
    
    % Visualization modes
    framework.visualizations = {
        'heatmap',
        'overlay',
        'segmentation',
        'interactive'
    };
    
    % Target audiences
    framework.audiences = {
        'developer',
        'domain_expert',
        'end_user',
        'regulator'
    };
    
    fprintf('Explainable AI framework initialized\n');
end

function [testData, models] = createExplainableTestData()
    %% Create test data and models for explainable AI analysis
    
    fprintf('Creating explainable AI test data...\n');
    
    % Test images
    testData = struct();
    testData.images = createTestImages();
    testData.labels = createTestLabels(size(testData.images, 4));
    testData.metadata = createImageMetadata(size(testData.images, 4));
    
    % Test models
    models = struct();
    models.simpleClassifier = createSimpleClassifier(testData);
    models.deepClassifier = createDeepClassifier(testData);
    models.ensembleClassifier = createEnsembleClassifier(testData);
    
    fprintf('Test data and models created\n');
end

function images = createTestImages()
    %% Create test images with known patterns
    
    numImages = 100;
    imageSize = [64, 64, 3];
    images = zeros([imageSize, numImages], 'single');
    
    for i = 1:numImages
        % Create different pattern types
        patternType = mod(i - 1, 5) + 1;
        
        switch patternType
            case 1 % Geometric shapes
                image = createGeometricPattern(imageSize(1:2));
                
            case 2 % Texture patterns
                image = createTexturePattern(imageSize(1:2));
                
            case 3 % Edge patterns
                image = createEdgePattern(imageSize(1:2));
                
            case 4 % Blob patterns
                image = createBlobPattern(imageSize(1:2));
                
            case 5 % Mixed patterns
                image = createMixedPattern(imageSize(1:2));
        end
        
        % Convert to RGB
        if size(image, 3) == 1
            rgbImage = repmat(image, [1, 1, 3]);
        else
            rgbImage = image;
        end
        
        % Add noise
        noise = randn(imageSize) * 0.05;
        noisyImage = rgbImage + noise;
        
        % Normalize
        noisyImage = max(0, min(1, noisyImage));
        
        images(:, :, :, i) = single(noisyImage);
    end
end

function pattern = createGeometricPattern(imageSize)
    %% Create geometric pattern
    
    pattern = zeros(imageSize);
    
    % Create circle
    [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
    centerX = imageSize(2) / 2 + randn() * 5;
    centerY = imageSize(1) / 2 + randn() * 5;
    radius = 15 + randn() * 3;
    
    circle = (X - centerX).^2 + (Y - centerY).^2 <= radius^2;
    pattern(circle) = 0.8;
    
    % Add rectangle
    rectX = round(imageSize(2) * 0.2);
    rectY = round(imageSize(1) * 0.7);
    rectW = round(imageSize(2) * 0.3);
    rectH = round(imageSize(1) * 0.2);
    
    pattern(rectY:min(rectY+rectH, imageSize(1)), rectX:min(rectX+rectW, imageSize(2))) = 0.6;
end

function pattern = createTexturePattern(imageSize)
    %% Create texture pattern
    
    % Generate Perlin-like noise texture
    [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
    
    texture = sin(X * 0.1) .* cos(Y * 0.15) + ...
              0.5 * sin(X * 0.3) .* cos(Y * 0.25) + ...
              0.25 * sin(X * 0.6) .* cos(Y * 0.5);
    
    pattern = (texture + 1.5) / 3; % Normalize to [0, 1]
end

function pattern = createEdgePattern(imageSize)
    %% Create edge pattern
    
    pattern = zeros(imageSize);
    
    % Vertical edges
    pattern(:, 20:22) = 1;
    pattern(:, 40:42) = 1;
    
    % Horizontal edges
    pattern(15:17, :) = 1;
    pattern(45:47, :) = 1;
    
    % Diagonal edge
    for i = 1:min(imageSize)
        if i <= imageSize(1) && i <= imageSize(2)
            pattern(i, i) = 1;
        end
    end
end

function pattern = createBlobPattern(imageSize)
    %% Create blob pattern
    
    pattern = zeros(imageSize);
    numBlobs = 3 + randi(3);
    
    for blob = 1:numBlobs
        centerX = randi(imageSize(2));
        centerY = randi(imageSize(1));
        radius = 5 + randi(8);
        intensity = 0.3 + rand() * 0.7;
        
        [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
        distance = sqrt((X - centerX).^2 + (Y - centerY).^2);
        blobMask = distance <= radius;
        
        pattern(blobMask) = max(pattern(blobMask), intensity);
    end
end

function pattern = createMixedPattern(imageSize)
    %% Create mixed pattern combining multiple elements
    
    geometric = createGeometricPattern(imageSize);
    texture = createTexturePattern(imageSize);
    
    pattern = 0.6 * geometric + 0.4 * texture;
    pattern = pattern / max(pattern(:)); % Normalize
end

function labels = createTestLabels(numImages)
    %% Create test labels
    
    % 5 classes corresponding to pattern types
    labels = mod((1:numImages) - 1, 5) + 1;
    labels = labels';
end

function metadata = createImageMetadata(numImages)
    %% Create image metadata for explainability analysis
    
    metadata = struct();
    metadata.importance_regions = cell(numImages, 1);
    metadata.pattern_types = cell(numImages, 1);
    metadata.difficulty_level = zeros(numImages, 1);
    
    for i = 1:numImages
        patternType = mod(i - 1, 5) + 1;
        
        % Define ground truth importance regions
        switch patternType
            case 1 % Geometric
                importance = zeros(64, 64);
                importance(20:40, 25:45) = 1; % Circle region
                importance(45:55, 10:35) = 1; % Rectangle region
                
            case 2 % Texture
                importance = ones(64, 64) * 0.5; % Distributed importance
                
            case 3 % Edge
                importance = zeros(64, 64);
                importance(:, 20:22) = 1; % Vertical edges
                importance(15:17, :) = 1; % Horizontal edges
                
            case 4 % Blob
                importance = zeros(64, 64);
                % Add blob regions (simplified)
                importance(20:35, 20:35) = 1;
                importance(40:55, 40:55) = 1;
                
            case 5 % Mixed
                importance = ones(64, 64) * 0.3; % Moderate distributed importance
        end
        
        metadata.importance_regions{i} = importance;
        metadata.pattern_types{i} = patternType;
        metadata.difficulty_level(i) = rand() * 0.5 + 0.5; % 0.5 to 1.0
    end
end

function classifier = createSimpleClassifier(testData)
    %% Create simple classifier for explainability testing
    
    classifier = struct();
    classifier.type = 'simple_linear';
    
    % Flatten images for simple classifier
    images = testData.images;
    [height, width, channels, numImages] = size(images);
    flatImages = reshape(images, height * width * channels, numImages)';
    
    % Simple linear classifier
    numFeatures = size(flatImages, 2);
    numClasses = length(unique(testData.labels));
    
    classifier.weights = randn(numClasses, numFeatures) * 0.01;
    classifier.bias = zeros(numClasses, 1);
    
    % Train simple classifier (simplified)
    learningRate = 0.01;
    numEpochs = 10;
    
    for epoch = 1:numEpochs
        for i = 1:numImages
            features = flatImages(i, :)';
            target = testData.labels(i);
            
            % Forward pass
            scores = classifier.weights * features + classifier.bias;
            probabilities = softmax(scores);
            
            % Compute loss and gradients (simplified)
            targetVector = zeros(numClasses, 1);
            targetVector(target) = 1;
            
            error = probabilities - targetVector;
            
            % Update weights
            classifier.weights = classifier.weights - learningRate * (error * features');
            classifier.bias = classifier.bias - learningRate * error;
        end
    end
    
    classifier.trainedImages = flatImages;
end

function probs = softmax(scores)
    %% Softmax function
    expScores = exp(scores - max(scores));
    probs = expScores / sum(expScores);
end

function classifier = createDeepClassifier(testData)
    %% Create deep classifier (simplified CNN-like)
    
    classifier = struct();
    classifier.type = 'deep_cnn';
    
    % Simplified deep network structure
    classifier.layers = {
        struct('type', 'conv', 'filters', 16, 'kernel_size', 5),
        struct('type', 'pool', 'size', 2),
        struct('type', 'conv', 'filters', 32, 'kernel_size', 3),
        struct('type', 'pool', 'size', 2),
        struct('type', 'fc', 'units', 64),
        struct('type', 'output', 'units', 5)
    };
    
    % Initialize weights (simplified)
    classifier.conv1_weights = randn(5, 5, 3, 16) * 0.1;
    classifier.conv2_weights = randn(3, 3, 16, 32) * 0.1;
    classifier.fc_weights = randn(64, 32*14*14) * 0.1; % Assuming size after pooling
    classifier.output_weights = randn(5, 64) * 0.1;
    
    % Training would go here (simplified for demo)
    classifier.trained = true;
end

function classifier = createEnsembleClassifier(testData)
    %% Create ensemble classifier
    
    classifier = struct();
    classifier.type = 'ensemble';
    
    % Create multiple base classifiers
    classifier.base_classifiers = cell(3, 1);
    
    for i = 1:3
        % Each base classifier with slight variations
        baseClassifier = createSimpleClassifier(testData);
        
        % Add noise to weights for diversity
        noise = randn(size(baseClassifier.weights)) * 0.01;
        baseClassifier.weights = baseClassifier.weights + noise;
        
        classifier.base_classifiers{i} = baseClassifier;
    end
    
    classifier.ensemble_weights = ones(3, 1) / 3; % Equal weighting
end

function results = performExplainableAnalysis(testData, models, framework)
    %% Perform comprehensive explainable AI analysis
    
    fprintf('Performing explainable AI analysis...\n');
    
    results = struct();
    
    % Test each explanation method
    results.integratedGradients = performIntegratedGradients(testData, models, framework);
    results.gradCAM = performGradCAM(testData, models, framework);
    results.LIME = performLIME(testData, models, framework);
    results.SHAP = performSHAP(testData, models, framework);
    results.occlusion = performOcclusionAnalysis(testData, models, framework);
    results.counterfactual = performCounterfactualAnalysis(testData, models, framework);
    
    % Evaluate explanation quality
    results.evaluation = evaluateExplanationQuality(results, testData, framework);
    
    % Audience-specific explanations
    results.audienceSpecific = generateAudienceSpecificExplanations(results, framework);
    
    fprintf('Explainable AI analysis completed\n');
end

function igResults = performIntegratedGradients(testData, models, framework)
    %% Perform Integrated Gradients analysis
    
    fprintf('  Computing Integrated Gradients...\n');
    
    igResults = struct();
    igResults.method = 'Integrated Gradients';
    
    numSamples = min(20, size(testData.images, 4)); % Limit for computation
    igResults.explanations = cell(numSamples, 1);
    igResults.attributions = zeros([size(testData.images, 1), size(testData.images, 2), numSamples]);
    
    for sample = 1:numSamples
        image = testData.images(:, :, :, sample);
        label = testData.labels(sample);
        
        % Compute integrated gradients
        attribution = computeIntegratedGradients(image, label, models.simpleClassifier);
        
        igResults.explanations{sample} = attribution;
        igResults.attributions(:, :, sample) = sum(attribution, 3); % Sum across channels
    end
    
    igResults.meanAttribution = mean(igResults.attributions, 3);
    igResults.maxAttribution = max(igResults.attributions, [], 3);
    
    fprintf('    Integrated Gradients completed for %d samples\n', numSamples);
end

function attribution = computeIntegratedGradients(image, targetClass, model)
    %% Compute Integrated Gradients attribution
    
    numSteps = 50;
    baseline = zeros(size(image));
    
    % Generate path from baseline to input
    alphas = linspace(0, 1, numSteps);
    gradients = zeros([size(image), numSteps]);
    
    for step = 1:numSteps
        alpha = alphas(step);
        interpolatedImage = baseline + alpha * (image - baseline);
        
        % Compute gradient
        grad = computeImageGradient(interpolatedImage, targetClass, model);
        gradients(:, :, :, step) = grad;
    end
    
    % Integrate gradients
    avgGradients = mean(gradients, 4);
    attribution = (image - baseline) .* avgGradients;
end

function gradient = computeImageGradient(image, targetClass, model)
    %% Compute gradient of model output with respect to input image
    
    epsilon = 1e-3;
    [height, width, channels] = size(image);
    gradient = zeros(size(image));
    
    % Flatten image for model
    flatImage = image(:)';
    
    % Compute baseline prediction
    baselinePred = predictWithModel(flatImage, model);
    baselineScore = baselinePred(targetClass);
    
    % Compute numerical gradients
    for c = 1:channels
        for i = 1:height
            for j = 1:width
                % Perturb pixel
                perturbedImage = image;
                perturbedImage(i, j, c) = perturbedImage(i, j, c) + epsilon;
                
                flatPerturbed = perturbedImage(:)';
                perturbedPred = predictWithModel(flatPerturbed, model);
                perturbedScore = perturbedPred(targetClass);
                
                % Compute gradient
                gradient(i, j, c) = (perturbedScore - baselineScore) / epsilon;
            end
        end
    end
end

function prediction = predictWithModel(flatImage, model)
    %% Make prediction with model
    
    switch model.type
        case 'simple_linear'
            scores = model.weights * flatImage' + model.bias;
            prediction = softmax(scores);
            
        case 'deep_cnn'
            % Simplified forward pass
            prediction = forwardPassCNN(reshape(flatImage, 64, 64, 3), model);
            
        case 'ensemble'
            % Ensemble prediction
            ensemblePreds = zeros(5, length(model.base_classifiers));
            for i = 1:length(model.base_classifiers)
                ensemblePreds(:, i) = predictWithModel(flatImage, model.base_classifiers{i});
            end
            prediction = ensemblePreds * model.ensemble_weights;
            
        otherwise
            % Default random prediction
            prediction = rand(5, 1);
            prediction = prediction / sum(prediction);
    end
end

function prediction = forwardPassCNN(image, model)
    %% Simplified CNN forward pass
    
    % Conv1
    conv1Output = applyConvolution(image, model.conv1_weights);
    pool1Output = applyPooling(conv1Output, 2);
    
    % Conv2
    conv2Output = applyConvolution(pool1Output, model.conv2_weights);
    pool2Output = applyPooling(conv2Output, 2);
    
    % Flatten and FC
    flattenedOutput = pool2Output(:);
    fcOutput = model.fc_weights * flattenedOutput;
    
    % Output layer
    scores = model.output_weights * fcOutput;
    prediction = softmax(scores);
end

function output = applyConvolution(input, weights)
    %% Apply convolution operation (simplified)
    
    [inputH, inputW, inputC] = size(input);
    [kernelH, kernelW, ~, numFilters] = size(weights);
    
    outputH = inputH - kernelH + 1;
    outputW = inputW - kernelW + 1;
    output = zeros(outputH, outputW, numFilters);
    
    for f = 1:numFilters
        kernel = weights(:, :, :, f);
        
        for i = 1:outputH
            for j = 1:outputW
                patch = input(i:i+kernelH-1, j:j+kernelW-1, :);
                output(i, j, f) = sum(patch(:) .* kernel(:));
            end
        end
    end
    
    % Apply ReLU activation
    output = max(0, output);
end

function output = applyPooling(input, poolSize)
    %% Apply max pooling (simplified)
    
    [inputH, inputW, inputC] = size(input);
    outputH = floor(inputH / poolSize);
    outputW = floor(inputW / poolSize);
    output = zeros(outputH, outputW, inputC);
    
    for c = 1:inputC
        for i = 1:outputH
            for j = 1:outputW
                startI = (i-1) * poolSize + 1;
                endI = min(i * poolSize, inputH);
                startJ = (j-1) * poolSize + 1;
                endJ = min(j * poolSize, inputW);
                
                patch = input(startI:endI, startJ:endJ, c);
                output(i, j, c) = max(patch(:));
            end
        end
    end
end

function gradCAMResults = performGradCAM(testData, models, framework)
    %% Perform Grad-CAM analysis
    
    fprintf('  Computing Grad-CAM...\n');
    
    gradCAMResults = struct();
    gradCAMResults.method = 'Grad-CAM';
    
    numSamples = min(20, size(testData.images, 4));
    gradCAMResults.heatmaps = zeros([size(testData.images, 1), size(testData.images, 2), numSamples]);
    
    for sample = 1:numSamples
        image = testData.images(:, :, :, sample);
        label = testData.labels(sample);
        
        % Compute Grad-CAM
        heatmap = computeGradCAM(image, label, models.deepClassifier);
        gradCAMResults.heatmaps(:, :, sample) = heatmap;
    end
    
    gradCAMResults.meanHeatmap = mean(gradCAMResults.heatmaps, 3);
    
    fprintf('    Grad-CAM completed for %d samples\n', numSamples);
end

function heatmap = computeGradCAM(image, targetClass, model)
    %% Compute Grad-CAM heatmap
    
    % Extract feature maps from last convolutional layer (simplified)
    featureMaps = extractFeatureMaps(image);
    
    % Compute gradients with respect to feature maps
    gradients = computeFeatureGradients(image, targetClass, model, featureMaps);
    
    % Global average pooling of gradients
    weights = squeeze(mean(mean(gradients, 1), 2));
    
    % Weighted combination of feature maps
    [height, width, numMaps] = size(featureMaps);
    heatmap = zeros(height, width);
    
    for i = 1:numMaps
        heatmap = heatmap + weights(i) * featureMaps(:, :, i);
    end
    
    % Apply ReLU and normalize
    heatmap = max(heatmap, 0);
    heatmap = heatmap / (max(heatmap(:)) + eps);
    
    % Resize to input image size
    heatmap = imresize(heatmap, [size(image, 1), size(image, 2)]);
end

function featureMaps = extractFeatureMaps(image)
    %% Extract feature maps from convolutional layer (simplified)
    
    % Apply simple filters to simulate conv layer
    filters = {
        [-1, 0, 1; -2, 0, 2; -1, 0, 1], % Vertical edges
        [-1, -2, -1; 0, 0, 0; 1, 2, 1], % Horizontal edges
        [0, -1, 0; -1, 5, -1; 0, -1, 0], % Sharpening
        ones(3, 3) / 9 % Smoothing
    };
    
    grayImage = rgb2gray(image);
    numFilters = length(filters);
    [height, width] = size(grayImage);
    featureMaps = zeros(height, width, numFilters);
    
    for i = 1:numFilters
        filtered = imfilter(double(grayImage), filters{i}, 'same');
        featureMaps(:, :, i) = filtered;
    end
end

function gradients = computeFeatureGradients(image, targetClass, model, featureMaps)
    %% Compute gradients with respect to feature maps
    
    [height, width, numMaps] = size(featureMaps);
    gradients = zeros(size(featureMaps));
    
    epsilon = 1e-3;
    flatImage = image(:)';
    baselinePred = predictWithModel(flatImage, model);
    baselineScore = baselinePred(targetClass);
    
    for i = 1:numMaps
        for y = 1:min(10, height) % Limit computation
            for x = 1:min(10, width)
                % Perturb feature map (simplified)
                perturbedImage = image;
                perturbedImage(y, x, 1) = perturbedImage(y, x, 1) + epsilon;
                
                flatPerturbed = perturbedImage(:)';
                perturbedPred = predictWithModel(flatPerturbed, model);
                perturbedScore = perturbedPred(targetClass);
                
                gradients(y, x, i) = (perturbedScore - baselineScore) / epsilon;
            end
        end
    end
end

function limeResults = performLIME(testData, models, framework)
    %% Perform LIME analysis
    
    fprintf('  Computing LIME explanations...\n');
    
    limeResults = struct();
    limeResults.method = 'LIME';
    
    numSamples = min(10, size(testData.images, 4)); % Fewer samples due to computational cost
    limeResults.explanations = cell(numSamples, 1);
    
    for sample = 1:numSamples
        image = testData.images(:, :, :, sample);
        label = testData.labels(sample);
        
        % Compute LIME explanation
        explanation = computeLIMEExplanation(image, label, models.simpleClassifier);
        limeResults.explanations{sample} = explanation;
    end
    
    fprintf('    LIME completed for %d samples\n', numSamples);
end

function explanation = computeLIMEExplanation(image, targetClass, model)
    %% Compute LIME explanation
    
    numSamples = 1000;
    segmentSize = 8; % Size of superpixels
    
    % Create superpixel segmentation
    segments = createSuperpixelSegmentation(image, segmentSize);
    numSegments = max(segments(:));
    
    % Generate perturbed samples
    [perturbedSamples, features] = generateLIMESamples(image, segments, numSamples);
    
    % Get model predictions for perturbed samples
    predictions = zeros(numSamples, 1);
    for i = 1:numSamples
        flatSample = perturbedSamples(:, :, :, i);
        flatSample = flatSample(:)';
        pred = predictWithModel(flatSample, model);
        predictions(i) = pred(targetClass);
    end
    
    % Fit linear model
    weights = fitLinearModel(features, predictions);
    
    % Create explanation map
    explanation = zeros(size(image, 1), size(image, 2));
    for seg = 1:numSegments
        segmentMask = segments == seg;
        if seg <= length(weights)
            explanation(segmentMask) = weights(seg);
        end
    end
end

function segments = createSuperpixelSegmentation(image, segmentSize)
    %% Create superpixel segmentation (simplified)
    
    [height, width, ~] = size(image);
    segments = zeros(height, width);
    
    segmentId = 1;
    for y = 1:segmentSize:height
        for x = 1:segmentSize:width
            yEnd = min(y + segmentSize - 1, height);
            xEnd = min(x + segmentSize - 1, width);
            
            segments(y:yEnd, x:xEnd) = segmentId;
            segmentId = segmentId + 1;
        end
    end
end

function [perturbedSamples, features] = generateLIMESamples(image, segments, numSamples)
    %% Generate perturbed samples for LIME
    
    numSegments = max(segments(:));
    [height, width, channels] = size(image);
    
    perturbedSamples = zeros(height, width, channels, numSamples);
    features = zeros(numSamples, numSegments);
    
    for sample = 1:numSamples
        % Random binary mask for segments
        segmentMask = rand(numSegments, 1) > 0.5;
        features(sample, :) = segmentMask;
        
        % Create perturbed image
        perturbedImage = image;
        for seg = 1:numSegments
            if ~segmentMask(seg)
                % Replace segment with mean color
                segmentPixels = segments == seg;
                for c = 1:channels
                    channelData = perturbedImage(:, :, c);
                    meanValue = mean(image(:, :, c), 'all');
                    channelData(segmentPixels) = meanValue;
                    perturbedImage(:, :, c) = channelData;
                end
            end
        end
        
        perturbedSamples(:, :, :, sample) = perturbedImage;
    end
end

function weights = fitLinearModel(features, predictions)
    %% Fit linear model for LIME
    
    % Ridge regression with regularization
    lambda = 0.01;
    X = [ones(size(features, 1), 1), features]; % Add bias term
    
    % Solve ridge regression
    weightsWithBias = (X' * X + lambda * eye(size(X, 2))) \ (X' * predictions);
    
    % Remove bias term
    weights = weightsWithBias(2:end);
end

function shapResults = performSHAP(testData, models, framework)
    %% Perform SHAP analysis
    
    fprintf('  Computing SHAP values...\n');
    
    shapResults = struct();
    shapResults.method = 'SHAP';
    
    numSamples = min(5, size(testData.images, 4)); % Very limited due to computational cost
    shapResults.shapValues = cell(numSamples, 1);
    
    for sample = 1:numSamples
        image = testData.images(:, :, :, sample);
        label = testData.labels(sample);
        
        % Compute SHAP values
        shapValues = computeSHAPValues(image, label, models.simpleClassifier);
        shapResults.shapValues{sample} = shapValues;
    end
    
    fprintf('    SHAP completed for %d samples\n', numSamples);
end

function shapValues = computeSHAPValues(image, targetClass, model)
    %% Compute SHAP values (simplified implementation)
    
    % Create feature representation (superpixels)
    segments = createSuperpixelSegmentation(image, 8);
    numFeatures = max(segments(:));
    
    shapValues = zeros(size(image, 1), size(image, 2));
    
    % Compute Shapley values for each feature (simplified)
    for feature = 1:min(numFeatures, 20) % Limit computation
        shapValue = computeShapleyValue(image, segments, feature, targetClass, model);
        
        featureMask = segments == feature;
        shapValues(featureMask) = shapValue;
    end
end

function shapValue = computeShapleyValue(image, segments, targetFeature, targetClass, model)
    %% Compute Shapley value for specific feature (simplified)
    
    numFeatures = max(segments(:));
    otherFeatures = setdiff(1:numFeatures, targetFeature);
    
    numSamples = 50; % Limited for computational efficiency
    marginalContributions = zeros(numSamples, 1);
    
    for sample = 1:numSamples
        % Random subset of other features
        subsetSize = randi([0, length(otherFeatures)]);
        if subsetSize > 0
            subset = otherFeatures(randperm(length(otherFeatures), subsetSize));
        else
            subset = [];
        end
        
        % Compute marginal contribution
        valueWith = evaluateFeatureSubset(image, segments, [subset, targetFeature], targetClass, model);
        valueWithout = evaluateFeatureSubset(image, segments, subset, targetClass, model);
        
        marginalContributions(sample) = valueWith - valueWithout;
    end
    
    shapValue = mean(marginalContributions);
end

function value = evaluateFeatureSubset(image, segments, activeFeatures, targetClass, model)
    %% Evaluate model with only specified features active
    
    % Create masked image
    maskedImage = zeros(size(image));
    
    for feature = activeFeatures
        featureMask = segments == feature;
        
        for c = 1:size(image, 3)
            channelData = maskedImage(:, :, c);
            channelData(featureMask) = image(featureMask + (c-1)*numel(segments));
            maskedImage(:, :, c) = channelData;
        end
    end
    
    % Evaluate model
    flatImage = maskedImage(:)';
    prediction = predictWithModel(flatImage, model);
    value = prediction(targetClass);
end

function occlusionResults = performOcclusionAnalysis(testData, models, framework)
    %% Perform occlusion analysis
    
    fprintf('  Computing occlusion analysis...\n');
    
    occlusionResults = struct();
    occlusionResults.method = 'Occlusion Analysis';
    
    numSamples = min(10, size(testData.images, 4));
    occlusionResults.heatmaps = zeros([size(testData.images, 1), size(testData.images, 2), numSamples]);
    
    for sample = 1:numSamples
        image = testData.images(:, :, :, sample);
        label = testData.labels(sample);
        
% Compute occlusion heatmap
        heatmap = computeOcclusionHeatmap(image, label, models.simpleClassifier);
        occlusionResults.heatmaps(:, :, sample) = heatmap;
    end
    
    occlusionResults.meanHeatmap = mean(occlusionResults.heatmaps, 3);
    
    fprintf('    Occlusion analysis completed for %d samples\n', numSamples);
end

function heatmap = computeOcclusionHeatmap(image, targetClass, model)
    %% Compute occlusion-based sensitivity heatmap
    
    windowSize = 8;
    stride = 4;
    
    [height, width, channels] = size(image);
    
    % Get baseline prediction
    flatImage = image(:)';
    baselinePrediction = predictWithModel(flatImage, model);
    baselineScore = baselinePrediction(targetClass);
    
    % Create heatmap
    heatmap = zeros(height, width);
    
    % Slide occlusion window
    for y = 1:stride:(height - windowSize + 1)
        for x = 1:stride:(width - windowSize + 1)
            % Create occluded image
            occludedImage = image;
            occludedImage(y:(y+windowSize-1), x:(x+windowSize-1), :) = 0;
            
            % Get prediction for occluded image
            flatOccluded = occludedImage(:)';
            occludedPrediction = predictWithModel(flatOccluded, model);
            occludedScore = occludedPrediction(targetClass);
            
            % Compute sensitivity
            sensitivity = baselineScore - occludedScore;
            
            % Assign sensitivity to window region
            heatmap(y:(y+windowSize-1), x:(x+windowSize-1)) = sensitivity;
        end
    end
end

function counterfactualResults = performCounterfactualAnalysis(testData, models, framework)
    %% Perform counterfactual analysis
    
    fprintf('  Computing counterfactual explanations...\n');
    
    counterfactualResults = struct();
    counterfactualResults.method = 'Counterfactual Analysis';
    
    numSamples = min(5, size(testData.images, 4)); % Limited due to optimization cost
    counterfactualResults.counterfactuals = cell(numSamples, 1);
    
    for sample = 1:numSamples
        image = testData.images(:, :, :, sample);
        originalLabel = testData.labels(sample);
        
        % Find different target class
        targetClass = mod(originalLabel, 5) + 1;
        
        % Generate counterfactual
        counterfactual = generateCounterfactualExplanation(image, originalLabel, targetClass, models.simpleClassifier);
        counterfactualResults.counterfactuals{sample} = counterfactual;
    end
    
    fprintf('    Counterfactual analysis completed for %d samples\n', numSamples);
end

function counterfactual = generateCounterfactualExplanation(image, originalClass, targetClass, model)
    %% Generate counterfactual explanation
    
    % Initialize counterfactual as copy of original
    counterfactual = struct();
    counterfactual.original = image;
    counterfactual.originalClass = originalClass;
    counterfactual.targetClass = targetClass;
    
    optimizedImage = image;
    
    % Optimization parameters
    numIterations = 50;
    learningRate = 0.01;
    
    for iteration = 1:numIterations
        % Get current predictions
        flatImage = optimizedImage(:)';
        currentPred = predictWithModel(flatImage, model);
        
        originalScore = currentPred(originalClass);
        targetScore = currentPred(targetClass);
        
        % Compute loss (minimize original class, maximize target class)
        loss = originalScore - targetScore;
        
        % Compute gradient with respect to image
        gradient = computeCounterfactualGradient(optimizedImage, originalClass, targetClass, model);
        
        % Update image
        optimizedImage = optimizedImage - learningRate * gradient;
        
        % Clamp to valid range
        optimizedImage = max(0, min(1, optimizedImage));
        
        % Check convergence
        if abs(loss) < 0.1 || targetScore > originalScore
            break;
        end
    end
    
    counterfactual.counterfactualImage = optimizedImage;
    counterfactual.difference = abs(image - optimizedImage);
    counterfactual.iterations = iteration;
    
    % Final predictions
    flatOptimized = optimizedImage(:)';
    finalPred = predictWithModel(flatOptimized, model);
    counterfactual.finalPrediction = finalPred;
end

function gradient = computeCounterfactualGradient(image, originalClass, targetClass, model)
    %% Compute gradient for counterfactual optimization
    
    epsilon = 1e-3;
    [height, width, channels] = size(image);
    gradient = zeros(size(image));
    
    % Compute numerical gradient
    for c = 1:channels
        for i = 1:height
            for j = 1:width
                % Forward perturbation
                imagePlus = image;
                imagePlus(i, j, c) = imagePlus(i, j, c) + epsilon;
                
                % Backward perturbation
                imageMinus = image;
                imageMinus(i, j, c) = imageMinus(i, j, c) - epsilon;
                
                % Compute predictions
                flatPlus = imagePlus(:)';
                flatMinus = imageMinus(:)';
                
                predPlus = predictWithModel(flatPlus, model);
                predMinus = predictWithModel(flatMinus, model);
                
                % Compute loss gradient
                lossPlus = predPlus(originalClass) - predPlus(targetClass);
                lossMinus = predMinus(originalClass) - predMinus(targetClass);
                
                gradient(i, j, c) = (lossPlus - lossMinus) / (2 * epsilon);
            end
        end
    end
end

function evaluation = evaluateExplanationQuality(results, testData, framework)
    %% Evaluate explanation quality using multiple metrics
    
    fprintf('  Evaluating explanation quality...\n');
    
    evaluation = struct();
    
    % Evaluate each explanation method
    methods = fieldnames(results);
    methods = methods(~strcmp(methods, 'evaluation') & ~strcmp(methods, 'audienceSpecific'));
    
    for i = 1:length(methods)
        method = methods{i};
        if isfield(results, method)
            methodEval = evaluateMethodQuality(results.*(method), testData, method);
            evaluation.*(method) = methodEval;
        end
    end
    
    % Overall comparison
    evaluation.comparison = compareExplanationMethods(evaluation);
    
    fprintf('    Explanation quality evaluation completed\n');
end

function methodEval = evaluateMethodQuality(methodResults, testData, methodName)
    %% Evaluate quality of specific explanation method
    
    methodEval = struct();
    methodEval.method = methodName;
    
    % Faithfulness: How well explanations reflect model behaviour
    methodEval.faithfulness = evaluateFaithfulness(methodResults, testData);
    
    % Stability: Consistency across similar inputs
    methodEval.stability = evaluateStability(methodResults, testData);
    
    % Comprehensiveness: Coverage of important features
    methodEval.comprehensiveness = evaluateComprehensiveness(methodResults, testData);
    
    % Sufficiency: Minimal set of features for decision
    methodEval.sufficiency = evaluateSufficiency(methodResults, testData);
    
    % Overall quality score
    methodEval.overallScore = (methodEval.faithfulness + methodEval.stability + ...
                              methodEval.comprehensiveness + methodEval.sufficiency) / 4;
end

function faithfulness = evaluateFaithfulness(methodResults, testData)
    %% Evaluate faithfulness of explanations
    
    % Simplified faithfulness measure
    % In practice, would involve perturbation tests and correlation analysis
    
    faithfulness = 0.7 + rand() * 0.2; % Simulated score between 0.7-0.9
    
    % Add method-specific adjustments
    if strcmp(methodResults.method, 'Integrated Gradients')
        faithfulness = faithfulness + 0.05; % Generally more faithful
    elseif strcmp(methodResults.method, 'LIME')
        faithfulness = faithfulness - 0.05; % Local approximation limitations
    end
    
    faithfulness = max(0, min(1, faithfulness));
end

function stability = evaluateStability(methodResults, testData)
    %% Evaluate stability of explanations
    
    % Simplified stability measure
    stability = 0.6 + rand() * 0.3; % Simulated score between 0.6-0.9
    
    % Method-specific adjustments
    if strcmp(methodResults.method, 'Grad-CAM')
        stability = stability + 0.1; % Generally more stable
    elseif strcmp(methodResults.method, 'SHAP')
        stability = stability + 0.05; % Theoretically guaranteed properties
    end
    
    stability = max(0, min(1, stability));
end

function comprehensiveness = evaluateComprehensiveness(methodResults, testData)
    %% Evaluate comprehensiveness of explanations
    
    % Compare with ground truth importance regions if available
    if isfield(testData, 'metadata') && isfield(testData.metadata, 'importance_regions')
        
        % Simplified comprehensiveness calculation
        comprehensiveness = 0;
        numSamples = 0;
        
        if strcmp(methodResults.method, 'Integrated Gradients') && isfield(methodResults, 'attributions')
            attributions = methodResults.attributions;
            
            for sample = 1:min(size(attributions, 3), length(testData.metadata.importance_regions))
                if ~isempty(testData.metadata.importance_regions{sample})
                    groundTruth = testData.metadata.importance_regions{sample};
                    explanation = attributions(:, :, sample);
                    
                    % Normalize both to [0, 1]
                    explanation = (explanation - min(explanation(:))) / (max(explanation(:)) - min(explanation(:)) + eps);
                    groundTruth = (groundTruth - min(groundTruth(:))) / (max(groundTruth(:)) - min(groundTruth(:)) + eps);
                    
                    % Compute overlap
                    overlap = corr(explanation(:), groundTruth(:));
                    comprehensiveness = comprehensiveness + max(0, overlap);
                    numSamples = numSamples + 1;
                end
            end
            
            if numSamples > 0
                comprehensiveness = comprehensiveness / numSamples;
            else
                comprehensiveness = 0.5; % Default
            end
        else
            comprehensiveness = 0.6 + rand() * 0.2; % Simulated for other methods
        end
    else
        comprehensiveness = 0.6 + rand() * 0.2; % Simulated score
    end
end

function sufficiency = evaluateSufficiency(methodResults, testData)
    %% Evaluate sufficiency of explanations
    
    % Simplified sufficiency measure
    sufficiency = 0.5 + rand() * 0.3; % Simulated score between 0.5-0.8
    
    % Method-specific adjustments
    if strcmp(methodResults.method, 'LIME')
        sufficiency = sufficiency + 0.1; % Designed for local sufficiency
    elseif strcmp(methodResults.method, 'Occlusion Analysis')
        sufficiency = sufficiency + 0.05; % Direct feature importance
    end
    
    sufficiency = max(0, min(1, sufficiency));
end

function comparison = compareExplanationMethods(evaluation)
    %% Compare explanation methods across metrics
    
    comparison = struct();
    
    methods = fieldnames(evaluation);
    methods = methods(~strcmp(methods, 'comparison'));
    
    if isempty(methods)
        return;
    end
    
    % Extract scores for comparison
    metrics = {'faithfulness', 'stability', 'comprehensiveness', 'sufficiency', 'overallScore'};
    scoreMatrix = zeros(length(methods), length(metrics));
    
    for i = 1:length(methods)
        method = methods{i};
        if isfield(evaluation, method)
            methodEval = evaluation.*(method);
            for j = 1:length(metrics)
                metric = metrics{j};
                if isfield(methodEval, metric)
                    scoreMatrix(i, j) = methodEval.*(metric);
                end
            end
        end
    end
    
    comparison.methods = methods;
    comparison.metrics = metrics;
    comparison.scoreMatrix = scoreMatrix;
    
    % Find best method for each metric
    [~, bestIndices] = max(scoreMatrix, [], 1);
    comparison.bestMethods = cell(length(metrics), 1);
    
    for i = 1:length(metrics)
        comparison.bestMethods{i} = methods{bestIndices(i)};
    end
    
    % Overall ranking
    [~, overallRanking] = sort(scoreMatrix(:, end), 'descend');
    comparison.overallRanking = methods(overallRanking);
end

function audienceResults = generateAudienceSpecificExplanations(results, framework)
    %% Generate audience-specific explanations
    
    fprintf('  Generating audience-specific explanations...\n');
    
    audienceResults = struct();
    
    for i = 1:length(framework.audiences)
        audience = framework.audiences{i};
        audienceExplanation = adaptExplanationForAudience(results, audience);
        audienceResults.*(audience) = audienceExplanation;
    end
    
    fprintf('    Audience-specific explanations generated\n');
end

function adapted = adaptExplanationForAudience(results, audience)
    %% Adapt explanations for specific audience
    
    adapted = struct();
    adapted.audience = audience;
    
    switch audience
        case 'developer'
            % Technical details, multiple methods, quantitative metrics
            adapted.recommendedMethods = {'integratedGradients', 'gradCAM', 'SHAP'};
            adapted.detail_level = 'high';
            adapted.include_metrics = true;
            adapted.include_code = true;
            adapted.visualization_type = 'technical';
            
        case 'domain_expert'
            % Focus on interpretability and domain relevance
            adapted.recommendedMethods = {'gradCAM', 'LIME', 'counterfactual'};
            adapted.detail_level = 'medium';
            adapted.include_metrics = true;
            adapted.include_code = false;
            adapted.visualization_type = 'interpretable';
            
        case 'end_user'
            % Simple, intuitive explanations
            adapted.recommendedMethods = {'gradCAM', 'occlusion'};
            adapted.detail_level = 'low';
            adapted.include_metrics = false;
            adapted.include_code = false;
            adapted.visualization_type = 'intuitive';
            
        case 'regulator'
            % Comprehensive documentation and validation
            adapted.recommendedMethods = {'integratedGradients', 'SHAP', 'counterfactual'};
            adapted.detail_level = 'comprehensive';
            adapted.include_metrics = true;
            adapted.include_code = true;
            adapted.visualization_type = 'documentation';
    end
    
    % Generate audience-specific summary
    adapted.summary = generateAudienceSummary(results, adapted);
end

function summary = generateAudienceSummary(results, audienceConfig)
    %% Generate audience-specific summary
    
    summary = struct();
    summary.audience = audienceConfig.audience;
    
    % Select appropriate explanations based on audience
    selectedMethods = audienceConfig.recommendedMethods;
    summary.explanations = struct();
    
    for i = 1:length(selectedMethods)
        method = selectedMethods{i};
        if isfield(results, method)
            summary.explanations.*(method) = results.*(method);
        end
    end
    
    % Add audience-specific insights
    switch audienceConfig.audience
        case 'developer'
            summary.insights = {
                'Integrated Gradients provides mathematically grounded attributions',
                'Grad-CAM offers efficient visualization for convolutional networks',
                'SHAP values satisfy desirable theoretical properties'
            };
            
        case 'domain_expert'
            summary.insights = {
                'Visual attention patterns align with domain knowledge',
                'Counterfactual examples show decision boundaries',
                'Local explanations reveal model behavior patterns'
            };
            
        case 'end_user'
            summary.insights = {
                'Highlighted regions show what the model focuses on',
                'Brighter areas indicate higher importance',
                'Model decisions are based on specific visual features'
            };
            
        case 'regulator'
            summary.insights = {
                'Multiple explanation methods provide comprehensive analysis',
                'Quantitative metrics validate explanation quality',
                'Systematic evaluation ensures reliability'
            };
    end
    
    summary.recommendations = generateAudienceRecommendations(audienceConfig.audience);
end

function recommendations = generateAudienceRecommendations(audience)
    %% Generate audience-specific recommendations
    
    switch audience
        case 'developer'
            recommendations = {
                'Implement multiple explanation methods for robust analysis',
                'Use quantitative metrics to validate explanation quality',
                'Consider computational efficiency for deployment',
                'Integrate explanations into development workflow'
            };
            
        case 'domain_expert'
            recommendations = {
                'Validate explanations against domain knowledge',
                'Use explanations to identify model limitations',
                'Focus on interpretable visualization methods',
                'Combine explanations with expert judgment'
            };
            
        case 'end_user'
            recommendations = {
                'Provide simple, visual explanations',
                'Avoid technical jargon and complex metrics',
                'Focus on actionable insights',
                'Ensure explanations build trust'
            };
            
        case 'regulator'
            recommendations = {
                'Document explanation methodology thoroughly',
                'Provide comprehensive evaluation metrics',
                'Ensure reproducibility and auditability',
                'Validate across diverse test cases'
            };
    end
end

function generateExplainabilityReport(explainableResults)
    %% Generate comprehensive explainability report
    
    fprintf('\n' + string(repmat('=', 1, 70)) + '\n');
    fprintf('EXPLAINABLE AI FRAMEWORK ANALYSIS REPORT\n');
    fprintf(string(repmat('=', 1, 70)) + '\n');
    
    % Method performance summary
    if isfield(explainableResults, 'evaluation')
        eval = explainableResults.evaluation;
        
        fprintf('\nEXPLANATION METHOD PERFORMANCE:\n');
        if isfield(eval, 'comparison')
            comp = eval.comparison;
            
            fprintf('  Overall ranking:\n');
            for i = 1:length(comp.overallRanking)
                method = comp.overallRanking{i};
                if isfield(eval, method)
                    score = eval.*(method).overallScore;
                    fprintf('    %d. %s: %.3f\n', i, method, score);
                end
            end
            
            fprintf('\n  Best methods by metric:\n');
            for i = 1:length(comp.metrics)
                metric = comp.metrics{i};
                bestMethod = comp.bestMethods{i};
                fprintf('    %s: %s\n', metric, bestMethod);
            end
        end
    end
    
    % Individual method results
    methods = {'integratedGradients', 'gradCAM', 'LIME', 'SHAP', 'occlusion', 'counterfactual'};
    
    for i = 1:length(methods)
        method = methods{i};
        if isfield(explainableResults, method)
            methodResult = explainableResults.*(method);
            fprintf('\n%s RESULTS:\n', upper(strrep(method, '_', ' ')));
            
            if isfield(explainableResults.evaluation, method)
                eval = explainableResults.evaluation.*(method);
                fprintf('  Faithfulness: %.3f\n', eval.faithfulness);
                fprintf('  Stability: %.3f\n', eval.stability);
                fprintf('  Comprehensiveness: %.3f\n', eval.comprehensiveness);
                fprintf('  Sufficiency: %.3f\n', eval.sufficiency);
                fprintf('  Overall Score: %.3f\n', eval.overallScore);
            end
            
            % Method-specific information
            if strcmp(method, 'integratedGradients') && isfield(methodResult, 'attributions')
                fprintf('  Attribution maps generated: %d\n', size(methodResult.attributions, 3));
            elseif strcmp(method, 'gradCAM') && isfield(methodResult, 'heatmaps')
                fprintf('  Heatmaps generated: %d\n', size(methodResult.heatmaps, 3));
            elseif strcmp(method, 'LIME') && isfield(methodResult, 'explanations')
                fprintf('  LIME explanations: %d\n', length(methodResult.explanations));
            end
        end
    end
    
    % Audience-specific recommendations
    if isfield(explainableResults, 'audienceSpecific')
        as = explainableResults.audienceSpecific;
        
        fprintf('\nAUDIENCE-SPECIFIC RECOMMENDATIONS:\n');
        audiences = fieldnames(as);
        
        for i = 1:length(audiences)
            audience = audiences{i};
            audienceData = as.*(audience);
            
            fprintf('  %s:\n', upper(strrep(audience, '_', ' ')));
            fprintf('    Recommended methods: %s\n', strjoin(audienceData.recommendedMethods, ', '));
            fprintf('    Detail level: %s\n', audienceData.detail_level);
            fprintf('    Visualization type: %s\n', audienceData.visualization_type);
        end
    end
    
    fprintf('\nEXPLAINABLE AI BENEFITS:\n');
    fprintf('========================\n');
    fprintf(' Enhanced trust and transparency in AI systems\n');
    fprintf(' Improved debugging and model development\n');
    fprintf(' Regulatory compliance and audit trails\n');
    fprintf(' Better understanding of model limitations\n');
    fprintf(' Facilitated human-AI collaboration\n');
    fprintf(' Detection of model biases and unfairness\n');
    fprintf(' Educational value for domain experts\n');
    
    fprintf('\nEXPLANATION METHOD CHARACTERISTICS:\n');
    fprintf('==================================\n');
    fprintf(' Integrated Gradients: Mathematically principled, satisfies axioms\n');
    fprintf(' Grad-CAM: Efficient, class-discriminative localisation\n');
    fprintf(' LIME: Model-agnostic, locally faithful approximations\n');
    fprintf(' SHAP: Game-theoretic foundation, additive feature attribution\n');
    fprintf(' Occlusion: Intuitive, direct feature importance measurement\n');
    fprintf(' Counterfactual: What-if analysis, decision boundary exploration\n');
    
    fprintf('\nIMPLEMENTATION CONSIDERATIONS:\n');
    fprintf('=============================\n');
    fprintf(' Computational cost varies significantly between methods\n');
    fprintf(' Different methods suitable for different model types\n');
    fprintf(' Explanation quality depends on model architecture\n');
    fprintf(' User study validation often required\n');
    fprintf(' Integration with deployment pipeline necessary\n');
    fprintf(' Continuous evaluation and monitoring recommended\n');
    
    fprintf('\nFUTURE DIRECTIONS:\n');
    fprintf('==================\n');
    fprintf(' Interactive explanation interfaces\n');
    fprintf(' Multi-modal explanation generation\n');
    fprintf(' Causal reasoning integration\n');
    fprintf(' Personalized explanation strategies\n');
    fprintf(' Automated explanation quality assessment\n');
    fprintf(' Real-time explanation generation\n');
    
    fprintf('\n' + string(repmat('=', 1, 70)) + '\n');
end

function visualiseExplainableResults(explainableResults)
    %% Visualise explainable AI results
    
    figure('Position', [100, 100, 1600, 1200]);
    
    % Method comparison overview
    subplot(3, 5, 1);
    if isfield(explainableResults, 'evaluation') && isfield(explainableResults.evaluation, 'comparison')
        comp = explainableResults.evaluation.comparison;
        
        if isfield(comp, 'scoreMatrix')
            imagesc(comp.scoreMatrix);
            colorbar;
            colormap(hot);
            
            set(gca, 'XTick', 1:length(comp.metrics));
            set(gca, 'XTickLabel', comp.metrics);
            set(gca, 'YTick', 1:length(comp.methods));
            set(gca, 'YTickLabel', comp.methods);
            xtickangle(45);
            
            title('Method Performance Matrix');
        end
    end
    
    % Individual method visualizations
    plotIndex = 2;
    methods = {'integratedGradients', 'gradCAM', 'LIME', 'occlusion'};
    
    for i = 1:length(methods)
        method = methods{i};
        if isfield(explainableResults, method)
            methodResult = explainableResults.*(method);
            
            subplot(3, 5, plotIndex);
            
            if strcmp(method, 'integratedGradients') && isfield(methodResult, 'meanAttribution')
                imshow(methodResult.meanAttribution, []);
                title('Integrated Gradients');
                colorbar;
                
            elseif strcmp(method, 'gradCAM') && isfield(methodResult, 'meanHeatmap')
                imshow(methodResult.meanHeatmap, []);
                title('Grad-CAM');
                colorbar;
                colormap(gca, hot);
                
            elseif strcmp(method, 'LIME') && isfield(methodResult, 'explanations') && ~isempty(methodResult.explanations)
                if ~isempty(methodResult.explanations{1})
                    imshow(methodResult.explanations{1}, []);
                    title('LIME');
                    colorbar;
                end
                
            elseif strcmp(method, 'occlusion') && isfield(methodResult, 'meanHeatmap')
                imshow(methodResult.meanHeatmap, []);
                title('Occlusion Analysis');
                colorbar;
                colormap(gca, hot);
            end
            
            plotIndex = plotIndex + 1;
        end
    end
    
    % Evaluation metrics comparison
    subplot(3, 5, 6);
    if isfield(explainableResults, 'evaluation')
        eval = explainableResults.evaluation;
        methods = fieldnames(eval);
        methods = methods(~strcmp(methods, 'comparison'));
        
        if ~isempty(methods)
            metrics = {'faithfulness', 'stability', 'comprehensiveness', 'sufficiency'};
            metricMatrix = zeros(length(methods), length(metrics));
            
            for i = 1:length(methods)
                method = methods{i};
                if isfield(eval, method)
                    methodEval = eval.*(method);
                    for j = 1:length(metrics)
                        metric = metrics{j};
                        if isfield(methodEval, metric)
                            metricMatrix(i, j) = methodEval.*(metric);
                        end
                    end
                end
            end
            
            bar(metricMatrix);
            set(gca, 'XTickLabel', methods);
            legend(metrics, 'Location', 'best');
            title('Quality Metrics by Method');
            xtickangle(45);
            ylabel('Score');
        end
    end
    
    % Overall scores
    subplot(3, 5, 7);
    if isfield(explainableResults, 'evaluation')
        eval = explainableResults.evaluation;
        methods = fieldnames(eval);
        methods = methods(~strcmp(methods, 'comparison'));
        
        if ~isempty(methods)
            overallScores = zeros(length(methods), 1);
            
            for i = 1:length(methods)
                method = methods{i};
                if isfield(eval, method) && isfield(eval.*(method), 'overallScore')
                    overallScores(i) = eval.*(method).overallScore;
                end
            end
            
            bar(overallScores);
            set(gca, 'XTickLabel', methods);
            title('Overall Quality Scores');
            xtickangle(45);
            ylabel('Overall Score');
        end
    end
    
    % Audience preferences
    subplot(3, 5, 8);
    if isfield(explainableResults, 'audienceSpecific')
        as = explainableResults.audienceSpecific;
        audiences = fieldnames(as);
        
        % Count method preferences
        methodCounts = containers.Map();
        
        for i = 1:length(audiences)
            audience = audiences{i};
            if isfield(as.*(audience), 'recommendedMethods')
                methods = as.*(audience).recommendedMethods;
                for j = 1:length(methods)
                    method = methods{j};
                    if isKey(methodCounts, method)
                        methodCounts(method) = methodCounts(method) + 1;
                    else
                        methodCounts(method) = 1;
                    end
                end
            end
        end
        
        if methodCounts.Count > 0
            methodNames = keys(methodCounts);
            counts = cell2mat(values(methodCounts));
            
            bar(counts);
            set(gca, 'XTickLabel', methodNames);
            title('Method Popularity by Audience');
            xtickangle(45);
            ylabel('Number of Audiences');
        end
    end
    
    % Counterfactual analysis
    if isfield(explainableResults, 'counterfactual')
        cf = explainableResults.counterfactual;
        
        if isfield(cf, 'counterfactuals') && ~isempty(cf.counterfactuals)
            counterfactual = cf.counterfactuals{1};
            
            if isfield(counterfactual, 'original')
                subplot(3, 5, 9);
                imshow(counterfactual.original);
                title('Original Image');
                
                subplot(3, 5, 10);
                if isfield(counterfactual, 'counterfactualImage')
                    imshow(counterfactual.counterfactualImage);
                    title('Counterfactual Image');
                end
                
                subplot(3, 5, 11);
                if isfield(counterfactual, 'difference')
                    imshow(counterfactual.difference, []);
                    title('Difference Map');
                    colorbar;
                    colormap(gca, hot);
                end
            end
        end
    end
    
    % Method reliability analysis
    subplot(3, 5, 12);
    if isfield(explainableResults, 'evaluation') && isfield(explainableResults.evaluation, 'comparison')
        comp = explainableResults.evaluation.comparison;
        
        if isfield(comp, 'scoreMatrix')
            % Compute coefficient of variation for each method
            cvScores = std(comp.scoreMatrix, 0, 2) ./ mean(comp.scoreMatrix, 2);
            
            bar(cvScores);
            set(gca, 'XTickLabel', comp.methods);
            title('Method Reliability (Lower CV = More Reliable)');
            xtickangle(45);
            ylabel('Coefficient of Variation');
        end
    end
    
    % Computational efficiency comparison
    subplot(3, 5, 13);
    % Simulated computational costs (in practice, would measure actual times)
    methods = {'integratedGradients', 'gradCAM', 'LIME', 'SHAP', 'occlusion', 'counterfactual'};
    simulated_costs = [0.8, 0.2, 2.5, 3.0, 1.0, 1.5]; % Relative computational costs
    
    bar(simulated_costs);
    set(gca, 'XTickLabel', methods);
    title('Computational Cost (Relative)');
    xtickangle(45);
    ylabel('Relative Cost');
    
    % Explanation coverage analysis
    subplot(3, 5, 14);
    % Simulated coverage metrics
    coverage_scores = [0.85, 0.92, 0.78, 0.88, 0.75, 0.65];
    
    bar(coverage_scores);
    set(gca, 'XTickLabel', methods);
    title('Explanation Coverage');
    xtickangle(45);
    ylabel('Coverage Score');
    
    % User preference simulation
    subplot(3, 5, 15);
    user_preferences = [0.7, 0.85, 0.8, 0.6, 0.9, 0.75];
    
    bar(user_preferences);
    set(gca, 'XTickLabel', methods);
    title('User Preference (Simulated)');
    xtickangle(45);
    ylabel('Preference Score');
    
    sgtitle('Comprehensive Explainable AI Analysis Results', 'FontSize', 16);
end
