%% chapter_AI_CV_kalman_tracking_01.m
% Kalman Filter Implementation for Object Tracking
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_kalman_tracking_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Create synthetic trajectory for tracking demonstration
num_frames = 100;
dt = 1.0;  % Time step

% True object trajectory (curved path with acceleration)
t = (0:num_frames-1) * dt;
true_x = 100 + 50*cos(0.1*t) + 0.5*t;
true_y = 100 + 50*sin(0.1*t) + 0.3*t;
true_vx = -5*sin(0.1*t) + 0.5;
true_vy = 5*cos(0.1*t) + 0.3;

% True state trajectory [x, y, vx, vy]
true_states = [true_x', true_y', true_vx', true_vy'];

% Add measurement noise to create observations
measurement_noise_std = 5.0;
noisy_x = true_x + measurement_noise_std * randn(size(true_x));
noisy_y = true_y + measurement_noise_std * randn(size(true_y));
measurements = [noisy_x', noisy_y'];

% Configure Kalman filter for constant velocity model
% State: [x, y, vx, vy]'
% Measurement: [x, y]'

% State transition matrix (constant velocity model)
A = [1, 0, dt, 0;
     0, 1, 0, dt;
     0, 0, 1, 0;
     0, 0, 0, 1];

% Measurement matrix (observe position only)
H = [1, 0, 0, 0;
     0, 1, 0, 0];

% Process noise covariance (uncertainty in motion model)
process_noise_std = 1.0;
Q = [dt^4/4, 0, dt^3/2, 0;
     0, dt^4/4, 0, dt^3/2;
     dt^3/2, 0, dt^2, 0;
     0, dt^3/2, 0, dt^2] * process_noise_std^2;

% Measurement noise covariance
R = eye(2) * measurement_noise_std^2;

% Initial state and covariance
initial_state = [measurements(1, 1); measurements(1, 2); 0; 0];
initial_covariance = diag([100, 100, 10, 10]);

% Manual Kalman filter implementation

% Apply Kalman filter
[kf_states, kf_predictions, kf_covariances] = kalmanFilterTracking(...
    measurements, A, H, Q, R, initial_state, initial_covariance);

% Extended Kalman Filter for nonlinear motion

% Apply Extended Kalman Filter
[ekf_states, ekf_covariances] = extendedKalmanFilter(measurements, dt, process_noise_std, measurement_noise_std);

% Multi-target tracking with Kalman filters

% Create multi-target scenario
target1_detections = measurements + 2*randn(size(measurements));
target2_detections = [measurements(:,1) + 100, measurements(:,2) - 50] + 3*randn(size(measurements));

% Combine detections (some frames may have missing detections)
combined_detections = cell(num_frames, 1);
for i = 1:num_frames
    if rand > 0.1  % 90% detection probability
        dets = [target1_detections(i, :)];
        if rand > 0.15  % 85% detection probability for second target
            dets = [dets; target2_detections(i, :)];
        end
        combined_detections{i} = dets;
    else
        combined_detections{i} = [];
    end
end

% Apply multi-target tracking
[multi_tracks, multi_states] = multiTargetKalmanTracking(combined_detections, 5, 30);

% Performance evaluation

% Evaluate filter performance
kf_metrics = evaluateTrackingPerformance(true_states, kf_states);
ekf_metrics = evaluateTrackingPerformance(true_states, ekf_states);

% Display comprehensive results
figure;

% Trajectory comparison
subplot(2,4,1);
plot(true_x, true_y, 'g-', 'LineWidth', 3, 'DisplayName', 'True Trajectory');
hold on;
plot(noisy_x, noisy_y, 'r.', 'MarkerSize', 8, 'DisplayName', 'Noisy Measurements');
plot(kf_states(:,1), kf_states(:,2), 'b-', 'LineWidth', 2, 'DisplayName', 'Kalman Filter');
plot(ekf_states(:,1), ekf_states(:,2), 'm-', 'LineWidth', 2, 'DisplayName', 'Extended KF');
xlabel('X Position'); ylabel('Y Position');
title('Trajectory Tracking Comparison');
legend('show'); grid on;

% Position errors over time
subplot(2,4,2);
kf_pos_errors = sqrt(sum((true_states(:,1:2) - kf_states(:,1:2)).^2, 2));
ekf_pos_errors = sqrt(sum((true_states(:,1:2) - ekf_states(:,1:2)).^2, 2));
plot(t, kf_pos_errors, 'b-', 'LineWidth', 2, 'DisplayName', 'Kalman Filter');
hold on;
plot(t, ekf_pos_errors, 'm-', 'LineWidth', 2, 'DisplayName', 'Extended KF');
xlabel('Time'); ylabel('Position Error');
title('Tracking Error Over Time');
legend('show'); grid on;

% Velocity estimation
subplot(2,4,3);
plot(t, true_vx, 'g-', 'LineWidth', 2, 'DisplayName', 'True Vx');
hold on;
plot(t, kf_states(:,3), 'b--', 'LineWidth', 2, 'DisplayName', 'KF Vx');
plot(t, true_vy, 'r-', 'LineWidth', 2, 'DisplayName', 'True Vy');
plot(t, kf_states(:,4), 'm--', 'LineWidth', 2, 'DisplayName', 'KF Vy');
xlabel('Time'); ylabel('Velocity');
title('Velocity Estimation');
legend('show'); grid on;

% Uncertainty ellipses
subplot(2,4,4);
plot(true_x, true_y, 'g-', 'LineWidth', 2, 'DisplayName', 'True');
hold on;
plot(kf_states(:,1), kf_states(:,2), 'b-', 'LineWidth', 2, 'DisplayName', 'Estimated');

% Plot uncertainty ellipses at selected time points
time_points = 1:10:num_frames;
for i = time_points
    P_pos = squeeze(kf_covariances(1:2, 1:2, i));
    [eigvec, eigval] = eig(P_pos);
    
    % 95% confidence ellipse
    chi2_val = 5.991;  % Chi-square value for 95% confidence, 2 DOF
    radii = sqrt(chi2_val * diag(eigval));
    angle = atan2(eigvec(2,1), eigvec(1,1));
    
    % Draw ellipse
    theta = 0:0.1:2*pi;
    ellipse_x = radii(1) * cos(theta);
    ellipse_y = radii(2) * sin(theta);
    
    % Rotate ellipse
    rotated_x = ellipse_x * cos(angle) - ellipse_y * sin(angle) + kf_states(i,1);
    rotated_y = ellipse_x * sin(angle) + ellipse_y * cos(angle) + kf_states(i,2);
    
    plot(rotated_x, rotated_y, 'b--', 'LineWidth', 1);
end
xlabel('X Position'); ylabel('Y Position');
title('Tracking with Uncertainty');
legend('show'); grid on;

% Multi-target tracking visualization
subplot(2,4,5);
colors = ['r', 'b', 'g', 'm', 'c'];
for frame = 1:min(10, length(multi_states))
    if ~isempty(multi_states{frame})
        for track = 1:size(multi_states{frame}, 1)
            color_idx = mod(track-1, length(colors)) + 1;
            plot(multi_states{frame}(track, 1), multi_states{frame}(track, 2), ...
                 'o', 'Color', colors(color_idx), 'MarkerSize', 8);
            hold on;
        end
    end
end
xlabel('X Position'); ylabel('Y Position');
title('Multi-target Tracking');
grid on;

% Innovation sequence
subplot(2,4,6);
innovations = zeros(num_frames, 2);
for k = 2:num_frames
    predicted = A * kf_states(k-1, :)';
    if ~any(isnan(measurements(k, :)))
        innovations(k, :) = measurements(k, :) - (H * predicted)';
    end
end
plot(t, innovations(:,1), 'r-', 'DisplayName', 'X Innovation');
hold on;
plot(t, innovations(:,2), 'b-', 'DisplayName', 'Y Innovation');
xlabel('Time'); ylabel('Innovation');
title('Innovation Sequence');
legend('show'); grid on;

% Filter consistency check
subplot(2,4,7);
normalized_errors = zeros(num_frames, 1);
for k = 1:num_frames
    error = true_states(k, 1:2)' - kf_states(k, 1:2)';
    P_pos = squeeze(kf_covariances(1:2, 1:2, k));
    normalized_errors(k) = error' / P_pos * error;
end
plot(t, normalized_errors, 'k-', 'LineWidth', 2);
hold on;
plot(t, 5.991 * ones(size(t)), 'r--', 'LineWidth', 2, 'DisplayName', '95% Bound');
xlabel('Time'); ylabel('Normalized Error');
title('Filter Consistency');
legend('show'); grid on;

% Performance metrics comparison
subplot(2,4,8);
metrics_names = {'Pos RMSE', 'Vel RMSE', 'Max Pos Err'};
kf_values = [kf_metrics.position_rmse, kf_metrics.velocity_rmse, kf_metrics.max_position_error];
ekf_values = [ekf_metrics.position_rmse, ekf_metrics.velocity_rmse, ekf_metrics.max_position_error];

x_pos = 1:length(metrics_names);
bar(x_pos-0.2, kf_values, 0.4, 'DisplayName', 'Kalman Filter');
hold on;
bar(x_pos+0.2, ekf_values, 0.4, 'DisplayName', 'Extended KF');
set(gca, 'XTickLabel', metrics_names);
title('Performance Metrics');
legend('show');

% Print comprehensive analysis
fprintf('Kalman Filter Tracking Performance Analysis:\n');
fprintf('Trajectory length: %d frames\n', num_frames);
fprintf('Measurement noise std: %.1f pixels\n', measurement_noise_std);
fprintf('Process noise std: %.1f\n', process_noise_std);

fprintf('\nKalman Filter Performance:\n');
fprintf('Mean position error: %.2f ㊣ %.2f pixels\n', kf_metrics.mean_position_error, kf_metrics.std_position_error);
fprintf('Position RMSE: %.2f pixels\n', kf_metrics.position_rmse);
fprintf('Velocity RMSE: %.2f pixels/frame\n', kf_metrics.velocity_rmse);
fprintf('Maximum position error: %.2f pixels\n', kf_metrics.max_position_error);

fprintf('\nExtended Kalman Filter Performance:\n');
fprintf('Mean position error: %.2f ㊣ %.2f pixels\n', ekf_metrics.mean_position_error, ekf_metrics.std_position_error);
fprintf('Position RMSE: %.2f pixels\n', ekf_metrics.position_rmse);
fprintf('Velocity RMSE: %.2f pixels/frame\n', ekf_metrics.velocity_rmse);

fprintf('\nMulti-target Tracking:\n');
fprintf('Number of active tracks: %d\n', sum(cellfun(@(t) t.active, multi_tracks)));
fprintf('Total tracks created: %d\n', length(multi_tracks));

% Local functions (moved to end so this listing is a valid MATLAB script)
function [filtered_states, predicted_states, covariances] = kalmanFilterTracking(measurements, A, H, Q, R, initial_state, initial_covariance)
    num_observations = size(measurements, 1);
    state_dim = length(initial_state);
    
    % Storage for results
    filtered_states = zeros(num_observations, state_dim);
    predicted_states = zeros(num_observations, state_dim);
    covariances = zeros(state_dim, state_dim, num_observations);
    
    % Initialize
    x = initial_state;
    P = initial_covariance;
    
    for k = 1:num_observations
        % Prediction step
        x_pred = A * x;
        P_pred = A * P * A' + Q;
        
        % Store prediction
        predicted_states(k, :) = x_pred';
        
        % Update step (if measurement available)
        if ~any(isnan(measurements(k, :)))
            z = measurements(k, :)';
            
            % Innovation
            y = z - H * x_pred;
            S = H * P_pred * H' + R;
            
            % Kalman gain
            K = P_pred * H' / S;
            
            % State update
            x = x_pred + K * y;
            P = (eye(state_dim) - K * H) * P_pred;
        else
            % No measurement available, use prediction
            x = x_pred;
            P = P_pred;
        end
        
        % Store results
        filtered_states(k, :) = x';
        covariances(:, :, k) = P;
    end
end

function [ekf_states, ekf_covariances] = extendedKalmanFilter(measurements, dt, process_noise, measurement_noise)
    num_observations = size(measurements, 1);
    state_dim = 4;  % [x, y, vx, vy]
    
    % Storage
    ekf_states = zeros(num_observations, state_dim);
    ekf_covariances = zeros(state_dim, state_dim, num_observations);
    
    % Initialize
    x = [measurements(1, 1); measurements(1, 2); 0; 0];
    P = diag([100, 100, 10, 10]);
    
    for k = 1:num_observations
        % Nonlinear state transition (constant acceleration with friction)
        friction = 0.95;
        x_pred = [x(1) + dt * x(3);
                  x(2) + dt * x(4);
                  friction * x(3);
                  friction * x(4)];
        
        % Jacobian of state transition
        F = [1, 0, dt, 0;
             0, 1, 0, dt;
             0, 0, friction, 0;
             0, 0, 0, friction];
        
        % Prediction covariance
        Q_ekf = diag([dt^2, dt^2, dt, dt]) * process_noise^2;
        P_pred = F * P * F' + Q_ekf;
        
        % Measurement update
        if ~any(isnan(measurements(k, :)))
            z = measurements(k, :)';
            H_ekf = [1, 0, 0, 0; 0, 1, 0, 0];
            R_ekf = eye(2) * measurement_noise^2;
            
            % Innovation
            y = z - H_ekf * x_pred;
            S = H_ekf * P_pred * H_ekf' + R_ekf;
            
            % Kalman gain
            K = P_pred * H_ekf' / S;
            
            % Update
            x = x_pred + K * y;
            P = (eye(state_dim) - K * H_ekf) * P_pred;
        else
            x = x_pred;
            P = P_pred;
        end
        
        ekf_states(k, :) = x';
        ekf_covariances(:, :, k) = P;
    end
end

function [tracks, track_states] = multiTargetKalmanTracking(detections, max_targets, association_threshold)
    num_frames = length(detections);
    tracks = {};
    track_states = {};
    next_track_id = 1;
    
    for frame = 1:num_frames
        current_detections = detections{frame};
        
        if isempty(current_detections)
            % Update existing tracks with prediction only
            for t = 1:length(tracks)
                if tracks{t}.active
                    % Predict without measurement
                    tracks{t}.predicted_state = tracks{t}.A * tracks{t}.state;
                    tracks{t}.predicted_covariance = tracks{t}.A * tracks{t}.covariance * tracks{t}.A' + tracks{t}.Q;
                    tracks{t}.state = tracks{t}.predicted_state;
                    tracks{t}.covariance = tracks{t}.predicted_covariance;
                    tracks{t}.age = tracks{t}.age + 1;
                    tracks{t}.missed_detections = tracks{t}.missed_detections + 1;
                    
                    % Deactivate track if too many missed detections
                    if tracks{t}.missed_detections > 5
                        tracks{t}.active = false;
                    end
                end
            end
            continue;
        end
        
        % Data association for existing tracks
        num_detections = size(current_detections, 1);
        assignment = zeros(length(tracks), 1);
        
        % Simple nearest neighbor association
        for t = 1:length(tracks)
            if tracks{t}.active
                % Predict
                predicted_pos = tracks{t}.A * tracks{t}.state;
                distances = sqrt(sum((current_detections - predicted_pos(1:2)').^2, 2));
                
                [min_distance, min_idx] = min(distances);
                
                if min_distance < association_threshold
                    assignment(t) = min_idx;
                end
            end
        end
        
        % Update assigned tracks
        used_detections = zeros(num_detections, 1);
        for t = 1:length(tracks)
            if assignment(t) > 0 && tracks{t}.active
                detection_idx = assignment(t);
                used_detections(detection_idx) = 1;
                
                % Kalman update
                z = current_detections(detection_idx, :)';
                tracks{t}.predicted_state = tracks{t}.A * tracks{t}.state;
                tracks{t}.predicted_covariance = tracks{t}.A * tracks{t}.covariance * tracks{t}.A' + tracks{t}.Q;
                
                y = z - tracks{t}.H * tracks{t}.predicted_state;
                S = tracks{t}.H * tracks{t}.predicted_covariance * tracks{t}.H' + tracks{t}.R;
                K = tracks{t}.predicted_covariance * tracks{t}.H' / S;
                
                tracks{t}.state = tracks{t}.predicted_state + K * y;
                tracks{t}.covariance = (eye(4) - K * tracks{t}.H) * tracks{t}.predicted_covariance;
                tracks{t}.age = tracks{t}.age + 1;
                tracks{t}.missed_detections = 0;
            end
        end
        
        % Initialize new tracks for unassigned detections
        for d = 1:num_detections
            if ~used_detections(d) && length(tracks) < max_targets
                new_track = struct();
                new_track.id = next_track_id;
                new_track.state = [current_detections(d, :)'; 0; 0];
                new_track.covariance = diag([100, 100, 10, 10]);
                new_track.A = A;
                new_track.H = H;
                new_track.Q = Q;
                new_track.R = R;
                new_track.age = 1;
                new_track.missed_detections = 0;
                new_track.active = true;
                
                tracks{end+1} = new_track;
                next_track_id = next_track_id + 1;
            end
        end
        
        % Store track states for this frame
        frame_states = [];
        for t = 1:length(tracks)
            if tracks{t}.active
                frame_states = [frame_states; tracks{t}.state'];
            end
        end
        track_states{frame} = frame_states;
    end
end

function metrics = evaluateTrackingPerformance(true_states, estimated_states)
    % Calculate tracking errors
    position_errors = sqrt(sum((true_states(:, 1:2) - estimated_states(:, 1:2)).^2, 2));
    velocity_errors = sqrt(sum((true_states(:, 3:4) - estimated_states(:, 3:4)).^2, 2));
    
    metrics.mean_position_error = mean(position_errors);
    metrics.std_position_error = std(position_errors);
    metrics.max_position_error = max(position_errors);
    metrics.mean_velocity_error = mean(velocity_errors);
    metrics.position_rmse = sqrt(mean(position_errors.^2));
    metrics.velocity_rmse = sqrt(mean(velocity_errors.^2));
end
