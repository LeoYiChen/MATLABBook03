%% chapter_AI_CV_deformable_templates_01.m
% Deformable Template Matching Implementation
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_deformable_templates_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Load test image with deformable objects
test_image = imread('circbw.tif');
if size(test_image, 3) == 3
    test_image = rgb2gray(test_image);
end
test_image = im2double(test_image);

% Create a simple deformable template (ellipse)
template_size = 50;
[X, Y] = meshgrid(-template_size/2:template_size/2, -template_size/2:template_size/2);

% Initial ellipse parameters [a, b, theta, center_x, center_y]
ellipse_params = [20, 15, 0, template_size/2, template_size/2];

% Generate ellipse template

% Active contour implementation for deformable matching

% Parametric deformable template matching

% Thin plate spline deformation

% Apply different deformable matching approaches
base_template = generateEllipseTemplate(ellipse_params, template_size);

% Test parametric deformation
param_ranges.a = -5:2:5;
param_ranges.b = -3:1:3;
param_ranges.theta = -pi/6:pi/12:pi/6;
param_ranges.dx = -10:5:10;
param_ranges.dy = -10:5:10;

[optimal_params, match_score] = parametricDeformableMatch(test_image, ellipse_params, param_ranges);
optimal_template = generateEllipseTemplate(optimal_params, template_size);

% Active contour for boundary detection
% Create initial contour around detected objects
initial_contour = [30, 30; 70, 30; 70, 70; 30, 70; 30, 30];  % Square contour
final_contour = activeContourMatch(test_image, initial_contour, 50, 0.1, 0.1, 0.2);

% Multi-resolution deformable matching

% Apply multi-resolution matching
multiresolution_result = multiResolutionDeformableMatch(test_image, base_template, 3);

% Performance evaluation for deformable templates

% Evaluate performance
rigid_performance = evaluateDeformableMatching(test_image, base_template);
deformable_performance = evaluateDeformableMatching(test_image, optimal_template);

% Display comprehensive results
figure;

% Original image and templates
subplot(2,4,1);
imshow(test_image);
title('Original Image');

subplot(2,4,2);
imshow(base_template);
title('Rigid Template');

subplot(2,4,3);
imshow(optimal_template);
title('Deformed Template');

% Correlation maps
subplot(2,4,4);
rigid_corr = normxcorr2(base_template, test_image);
imshow(rigid_corr, []);
title('Rigid Correlation');
colorbar;

subplot(2,4,5);
deformable_corr = normxcorr2(optimal_template, test_image);
imshow(deformable_corr, []);
title('Deformable Correlation');
colorbar;

% Active contour result
subplot(2,4,6);
imshow(test_image); hold on;
plot(initial_contour(:,1), initial_contour(:,2), 'r-', 'LineWidth', 2);
plot(final_contour(:,1), final_contour(:,2), 'g-', 'LineWidth', 2);
legend('Initial', 'Final');
title('Active Contour Evolution');

% Parameter comparison
subplot(2,4,7);
param_names = {'a', 'b', '牟', 'cx', 'cy'};
original_vals = ellipse_params;
optimised_vals = optimal_params;

x_pos = 1:length(param_names);
bar(x_pos-0.2, original_vals, 0.4, 'b');
hold on;
bar(x_pos+0.2, optimised_vals, 0.4, 'r');
set(gca, 'XTickLabel', param_names);
legend('Original', 'Optimised');
title('Parameter Comparison');

% Performance metrics
subplot(2,4,8);
methods = {'Rigid', 'Deformable'};
correlations = [rigid_performance.max_correlation, deformable_performance.max_correlation];
bar(correlations);
set(gca, 'XTickLabel', methods);
title('Matching Performance');
ylabel('Max Correlation');

% Print analysis
fprintf('Deformable Template Matching Analysis:\n');
fprintf('Original parameters: [%.1f, %.1f, %.2f, %.1f, %.1f]\n', ellipse_params);
fprintf('Optimised parameters: [%.1f, %.1f, %.2f, %.1f, %.1f]\n', optimal_params);
fprintf('Rigid template correlation: %.3f\n', rigid_performance.max_correlation);
fprintf('Deformable template correlation: %.3f\n', deformable_performance.max_correlation);
fprintf('Improvement: %.3f\n', deformable_performance.max_correlation - rigid_performance.max_correlation);

% Local functions (moved to end so this listing is a valid MATLAB script)
function template = generateEllipseTemplate(params, template_size)
    a = params(1);  % Semi-major axis
    b = params(2);  % Semi-minor axis
    theta = params(3);  % Rotation angle
    cx = params(4);  % Center x
    cy = params(5);  % Center y
    
    [X, Y] = meshgrid(1:template_size, 1:template_size);
    
    % Translate to center
    X_centered = X - cx;
    Y_centered = Y - cy;
    
    % Apply rotation
    X_rot = X_centered * cos(theta) + Y_centered * sin(theta);
    Y_rot = -X_centered * sin(theta) + Y_centered * cos(theta);
    
    % Ellipse equation
    ellipse_mask = (X_rot.^2 / a^2) + (Y_rot.^2 / b^2) <= 1;
    template = double(ellipse_mask);
end

function final_contour = activeContourMatch(image, initial_contour, iterations, alpha, beta, gamma)
    % alpha: elasticity (internal energy)
    % beta: rigidity (internal energy)  
    % gamma: external force weight
    
    contour = initial_contour;
    
    for iter = 1:iterations
        % Compute external forces (image gradients)
        [grad_x, grad_y] = gradient(image);
        grad_magnitude = sqrt(grad_x.^2 + grad_y.^2);
        
        % Interpolate forces at contour points
        external_force_x = interp2(grad_x, contour(:,1), contour(:,2), 'linear', 0);
        external_force_y = interp2(grad_y, contour(:,1), contour(:,2), 'linear', 0);
        
        % Compute internal forces
        n_points = size(contour, 1);
        internal_force_x = zeros(n_points, 1);
        internal_force_y = zeros(n_points, 1);
        
        for i = 1:n_points
            % Indices for neighbouring points (circular)
            prev_idx = mod(i-2, n_points) + 1;
            next_idx = mod(i, n_points) + 1;
            next2_idx = mod(i+1, n_points) + 1;
            
            % First derivative (elasticity)
            dx1 = contour(next_idx, 1) - contour(i, 1);
            dy1 = contour(next_idx, 2) - contour(i, 2);
            
            % Second derivative (rigidity)
            dx2 = contour(prev_idx, 1) - 2*contour(i, 1) + contour(next_idx, 1);
            dy2 = contour(prev_idx, 2) - 2*contour(i, 2) + contour(next_idx, 2);
            
            % Internal forces
            internal_force_x(i) = alpha * dx1 + beta * dx2;
            internal_force_y(i) = alpha * dy1 + beta * dy2;
        end
        
        % Update contour
        contour(:, 1) = contour(:, 1) + gamma * external_force_x - internal_force_x;
        contour(:, 2) = contour(:, 2) + gamma * external_force_y - internal_force_y;
        
        % Ensure contour stays within image bounds
        contour(:, 1) = max(1, min(size(image, 2), contour(:, 1)));
        contour(:, 2) = max(1, min(size(image, 1), contour(:, 2)));
    end
    
    final_contour = contour;
end

function [best_params, best_score] = parametricDeformableMatch(image, initial_params, param_ranges)
    best_score = -inf;
    best_params = initial_params;
    
    % Simple grid search over parameter space
    a_range = initial_params(1) + param_ranges.a;
    b_range = initial_params(2) + param_ranges.b;
    theta_range = initial_params(3) + param_ranges.theta;
    
    for a = a_range
        for b = b_range
            for theta = theta_range
                % Test different positions
                for dx = param_ranges.dx
                    for dy = param_ranges.dy
                        test_params = [a, b, theta, ...
                                     initial_params(4) + dx, ...
                                     initial_params(5) + dy];
                        
                        % Generate template with current parameters
                        template = generateEllipseTemplate(test_params, template_size);
                        
                        % Extract corresponding image region
                        cx = round(test_params(4));
                        cy = round(test_params(5));
                        
                        if cx-template_size/2 > 0 && cx+template_size/2 <= size(image, 2) && ...
                           cy-template_size/2 > 0 && cy+template_size/2 <= size(image, 1)
                            
                            image_region = image(cy-template_size/2:cy+template_size/2, ...
                                               cx-template_size/2:cx+template_size/2);
                            
                            % Compute matching score (normalised correlation)
                            score = corr2(template, image_region);
                            
                            if score > best_score
                                best_score = score;
                                best_params = test_params;
                            end
                        end
                    end
                end
            end
        end
    end
end

function warped_template = thinPlateSplineWarp(template, control_points, target_points)
    % Simple implementation of thin plate spline warping
    [rows, cols] = size(template);
    [X, Y] = meshgrid(1:cols, 1:rows);
    
    % For this simplified version, we'll use basic interpolation
    warped_template = template;  % Placeholder
    
    % In a full implementation, this would solve the TPS system
    % and apply the resulting transformation
    if size(control_points, 1) >= 3 && size(target_points, 1) >= 3
        try
            % Use built-in function for point-based geometric transformation
            tform = fitgeotrans(control_points, target_points, 'pwl');
            [warped_X, warped_Y] = transformPointsForward(tform, X(:), Y(:));
            
            % Interpolate warped template
            warped_template = griddata(warped_X, warped_Y, template(:), X, Y, 'linear');
            warped_template(isnan(warped_template)) = 0;
        catch
            % Fallback to original template
            warped_template = template;
        end
    end
end

function multiresolution_result = multiResolutionDeformableMatch(image, template, num_levels)
    multiresolution_result = struct();
    
    current_image = image;
    current_template = template;
    
    for level = 1:num_levels
        % Match at current resolution
        correlation_map = normxcorr2(current_template, current_image);
        [max_corr, max_idx] = max(correlation_map(:));
        [max_y, max_x] = ind2sub(size(correlation_map), max_idx);
        
        % Store result
        multiresolution_result.correlations(level) = max_corr;
        multiresolution_result.positions(level, :) = [max_x, max_y];
        multiresolution_result.scales(level) = 2^(level-1);
        
        % Downsample for next level
        if level < num_levels
            current_image = imresize(current_image, 0.5);
            current_template = imresize(current_template, 0.5);
        end
    end
end

function performance = evaluateDeformableMatching(image, template, ground_truth_params)
    % Generate correlation map
    correlation_map = normxcorr2(template, image);
    
    % Find best match
    [max_corr, max_idx] = max(correlation_map(:));
    [best_y, best_x] = ind2sub(size(correlation_map), max_idx);
    
    % Convert to image coordinates
    detected_x = best_x - size(template, 2) + 1;
    detected_y = best_y - size(template, 1) + 1;
    
    % Compare with ground truth
    if nargin > 2
        true_x = ground_truth_params(4);
        true_y = ground_truth_params(5);
        
        detection_error = sqrt((detected_x - true_x)^2 + (detected_y - true_y)^2);
        performance.detection_error = detection_error;
    end
    
    performance.max_correlation = max_corr;
    performance.detected_position = [detected_x, detected_y];
end
