%% chapter_AI_CV_feature_tracking_01.m
% Advanced Feature Tracking and Correspondence Analysis for Structure from Motion
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_feature_tracking_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Comprehensive Feature Tracking and Correspondence System for SfM
fprintf('Structure from Motion: Feature Tracking and Correspondence Analysis\n');
fprintf('==================================================================\n');

% Create synthetic image sequence simulating camera motion around a 3*D scene
numImages = 8;
imageSize = [480, 640, 3];
[imageSequence, cameraParams, worldPoints3D] = createSyntheticImageSequence(numImages, imageSize);



% Feature detection using corner detection (simplified SIFT-like approach)


% Feature matching between consecutive images

% Extract features from all images
fprintf('Extracting features from image sequence...\n');
allFeatures = cell(numImages, 1);
allDescriptors = cell(numImages, 1);

for i = 1:numImages
[features, descriptors] = detectAndDescribeFeatures(imageSequence{i});
allFeatures{i} = features;
allDescriptors{i} = descriptors;

 
fprintf('Image %d: %d features detected\n', i, size(features, 1));
end

% Establish correspondences between consecutive image pairs
fprintf('\nEstablishing feature correspondences...\n');
pairwiseMatches = cell(numImages-1, 1);
matchingThreshold = 0.8; % Ratio test threshold

for i = 1:(numImages-1)
matches = matchFeatures(allDescriptors{i}, allDescriptors{i+1}, ...
allFeatures{i}, allFeatures{i+1}, matchingThreshold);

 
if ~isempty(matches)
    % Extract matched point coordinates
    points1 = allFeatures{i}(matches(:, 1), :);
    points2 = allFeatures{i+1}(matches(:, 2), :);
    
    % Geometric verification using fundamental matrix
    [F, inlierIdx] = estimateFundamentalMatrix(points1, points2, ...
        'Method', 'RANSAC', 'NumTrials', 1000, 'DistanceThreshold', 2.0);
    
    % Store geometrically verified matches
    verifiedMatches = matches(inlierIdx, :);
    pairwiseMatches{i} = struct();
    pairwiseMatches{i}.matches = verifiedMatches;
    pairwiseMatches{i}.points1 = points1(inlierIdx, :);
    pairwiseMatches{i}.points2 = points2(inlierIdx, :);
    pairwiseMatches{i}.F = F;
    
    fprintf('Pair %d-%d: %d initial matches, %d verified matches\n', ...
        i, i+1, size(matches, 1), size(verifiedMatches, 1));
else
    fprintf('Pair %d-%d: No matches found\n', i, i+1);
    pairwiseMatches{i} = struct();
    pairwiseMatches{i}.matches = [];
    pairwiseMatches{i}.points1 = [];
    pairwiseMatches{i}.points2 = [];
    pairwiseMatches{i}.F = [];
end
end

% Track features across multiple images to create feature tracks

% Create feature tracks
featureTracks = createFeatureTracks(pairwiseMatches, numImages);

fprintf('\nFeature Track Analysis:\n');
fprintf('=======================\n');
fprintf('Total feature tracks created: %d\n', length(featureTracks));

% Analyze track lengths
trackLengths = arrayfun(@(x) length(x.imageIds), featureTracks);
fprintf('Track length statistics:\n');
fprintf(' Minimum length: %d images\n', min(trackLengths));
fprintf(' Maximum length: %d images\n', max(trackLengths));
fprintf(' Mean length: %.1f images\n', mean(trackLengths));
fprintf(' Tracks visible in ≡3 images: %d\n', sum(trackLengths >= 3));
fprintf(' Tracks visible in ≡5 images: %d\n', sum(trackLengths >= 5));

% Correspondence quality assessment

correspondenceQuality = assessCorrespondenceQuality(pairwiseMatches, featureTracks);

% Visualize feature correspondences
figure;

% Show pairwise matches for first few image pairs
numPairsToShow = min(4, length(pairwiseMatches));
for pairIdx = 1:numPairsToShow
subplot(2, numPairsToShow, pairIdx);

 
if ~isempty(pairwiseMatches{pairIdx}.points1)
    % Create side-by-side image
    img1 = imageSequence{pairIdx};
    img2 = imageSequence{pairIdx + 1};
    
    if size(img1, 3) == 3
        img1_gray = rgb2gray(img1);
        img2_gray = rgb2gray(img2);
    else
        img1_gray = img1;
        img2_gray = img2;
    end
    
    combined_img = [img1_gray, img2_gray];
    imshow(combined_img);
    
    % Plot matches
    points1 = pairwiseMatches{pairIdx}.points1;
    points2 = pairwiseMatches{pairIdx}.points2;
    
    % Offset points2 for right image
    points2_offset = points2;
    points2_offset(:, 1) = points2_offset(:, 1) + size(img1_gray, 2);
    
    hold on;
    plot(points1(:, 1), points1(:, 2), 'ro', 'MarkerSize', 4);
    plot(points2_offset(:, 1), points2_offset(:, 2), 'bo', 'MarkerSize', 4);
    
    % Draw lines connecting matches (sample of matches to avoid clutter)
    numLinesToShow = min(20, size(points1, 1));
    indices = randperm(size(points1, 1), numLinesToShow);
    
    for i = indices
        plot([points1(i, 1), points2_offset(i, 1)], ...
             [points1(i, 2), points2_offset(i, 2)], 'g-', 'LineWidth', 1);
    end
    
    hold off;
    title(sprintf('Matches: Images %d-%d (%d)', pairIdx, pairIdx+1, size(points1, 1)));
else
    text(0.5, 0.5, 'No matches', 'Units', 'normalized', 'HorizontalAlignment', 'center');
    title(sprintf('Images %d-%d (0 matches)', pairIdx, pairIdx+1));
end
end

% Show feature tracks visualization
subplot(2, numPairsToShow, (numPairsToShow+1):(2*numPairsToShow));

% Create a timeline showing track persistence
if ~isempty(featureTracks)
trackMatrix = zeros(length(featureTracks), numImages);

 
for i = 1:length(featureTracks)
    for imageId = featureTracks(i).imageIds
        trackMatrix(i, imageId) = 1;
    end
end

imagesc(trackMatrix);
colormap([1 1 1; 0 0 1]); % White for absent, blue for present
xlabel('Image Number');
ylabel('Feature Track ID');
title('Feature Track Persistence');

% Add colorbar
colorbar('Ticks', [0, 1], 'TickLabels', {'Absent', 'Present'});
else
text(0.5, 0.5, 'No feature tracks', 'Units', 'normalized', 'HorizontalAlignment', 'center');
title('Feature Track Analysis');
end

% Advanced correspondence analysis
fprintf('\nAdvanced Correspondence Analysis:\n');
fprintf('================================\n');

% Reprojection error analysis (would require camera poses)
fprintf('Reprojection Error Analysis:\n');
fprintf('- Requires estimated camera poses for implementation\n');
fprintf('- Measures geometric consistency of 3*D triangulation\n');
fprintf('- Typical threshold: 1-2 pixels for good correspondences\n');

% Correspondence robustness
fprintf('\nCorrespondence Robustness Factors:\n');
fprintf('1. Feature detector repeatability across viewpoints\n');
fprintf('2. Descriptor distinctiveness and invariance\n');
fprintf('3. Geometric verification through fundamental matrix\n');
fprintf('4. Multi-view consistency checks\n');
fprintf('5. Temporal coherence in video sequences\n');

% Best practices for feature tracking
fprintf('\nBest Practices for Feature Tracking:\n');
fprintf('===================================\n');
fprintf('1. Use scale and rotation invariant features (SIFT, SURF)\n');
fprintf('2. Apply ratio test for distinctive matching\n');
fprintf('3. Perform geometric verification with RANSAC\n');
fprintf('4. Track features across multiple views for stability\n');
fprintf('5. Filter tracks based on length and reprojection error\n');
fprintf('6. Consider temporal smoothness in video sequences\n');
fprintf('7. Adapt matching thresholds based on scene characteristics\n');
fprintf('8. Use bundle adjustment for global optimization\n');

% Local functions (moved to end so this listing is a valid MATLAB script)
function [images, camParams, world3D] = createSyntheticImageSequence(numImages, imageSize)
% Create a synthetic 3*D scene and simulate camera motion

 
% Define 3*D world points (synthetic scene)
numPoints = 100;

% Create points in 3*D space (a cube-like structure)
world3D = [
    % Front face
    rand(25, 1) * 200 - 100, rand(25, 1) * 200 - 100, zeros(25, 1) + 500;
    % Back face  
    rand(25, 1) * 200 - 100, rand(25, 1) * 200 - 100, zeros(25, 1) + 700;
    % Side points
    rand(50, 1) * 200 - 100, rand(50, 1) * 200 - 100, rand(50, 1) * 200 + 500
];

% Camera intrinsic parameters
focal_length = 800; % pixels
principal_point = [imageSize(2)/2, imageSize(1)/2];
K = [focal_length, 0, principal_point(1);
     0, focal_length, principal_point(2);
     0, 0, 1];

% Generate camera poses (circular motion around scene)
radius = 800; % mm
height = 600; % mm
center = [0, 0, 600]; % Scene center

images = cell(numImages, 1);
camParams = cell(numImages, 1);

for i = 1:numImages
    % Camera position on circle
    angle = (i - 1) * 2 * pi / numImages;
    camera_pos = center + [radius * cos(angle), radius * sin(angle), height];
    
    % Camera looks towards scene center
    look_direction = center - camera_pos;
    look_direction = look_direction / norm(look_direction);
    
    % Construct rotation matrix (simplified - camera looks at center)
    up = [0, 0, 1];
    right = cross(look_direction, up);
    right = right / norm(right);
    up_corrected = cross(right, look_direction);
    
    R = [right; up_corrected; -look_direction];
    t = -R * camera_pos';
    
    % Store camera parameters
    camParams{i} = struct();
    camParams{i}.K = K;
    camParams{i}.R = R;
    camParams{i}.t = t;
    camParams{i}.P = K * [R, t]; % Projection matrix
    
    % Project 3*D points to image
    world_hom = [world3D, ones(size(world3D, 1), 1)]';
    projected = camParams{i}.P * world_hom;
    projected = projected ./ projected(3, :);
    image_points = projected(1:2, :)';
    
    % Create synthetic image with projected points
    img = createSyntheticImage(imageSize, image_points, world3D);
    images{i} = img;
end
end

function img = createSyntheticImage(imageSize, imagePoints, worldPoints)
% Create synthetic image with feature points
img = uint8(rand(imageSize) * 50 + 50); % Random texture background

 
% Add feature points as distinctive patterns
for i = 1:size(imagePoints, 1)
    x = round(imagePoints(i, 1));
    y = round(imagePoints(i, 2));
    
    % Check if point is within image bounds
    if x >= 5 && x <= imageSize(2) - 5 && y >= 5 && y <= imageSize(1) - 5
        % Create distinctive feature pattern
        depth = worldPoints(i, 3);
        intensity = uint8(min(255, max(100, 255 - depth/10))); % Depth-based intensity
        
        % Add cross pattern
        img(y-2:y+2, x, :) = intensity;
        img(y, x-2:x+2, :) = intensity;
        
        % Add small square around feature
        img(y-1:y+1, x-1:x+1, :) = intensity;
    end
end
end

function [features, descriptors] = detectAndDescribeFeatures(image)
% Convert to grayscale for feature detection
if size(image, 3) == 3
grayImage = rgb2gray(image);
else
grayImage = image;
end

 
% Detect corner features using Harris corner detector
corners = detectHarrisFeatures(grayImage, 'MinQuality', 0.01, 'FilterSize', 5);

% Extract feature points
if corners.Count > 0
    features = corners.Location;
    
    % Compute simple descriptors (patch-based)
    descriptors = extractFeatureDescriptors(grayImage, features);
else
    features = [];
    descriptors = [];
end
end

function descriptors = extractFeatureDescriptors(image, points)
% Extract simple patch-based descriptors around feature points
patchSize = 11;
halfPatch = floor(patchSize / 2);
numFeatures = size(points, 1);
descriptors = zeros(numFeatures, patchSize^2);

 
[height, width] = size(image);
image = double(image);

for i = 1:numFeatures
    x = round(points(i, 1));
    y = round(points(i, 2));
    
    % Extract patch around feature point
    if x > halfPatch && x <= width - halfPatch && ...
       y > halfPatch && y <= height - halfPatch
        
        patch = image((y-halfPatch):(y+halfPatch), (x-halfPatch):(x+halfPatch));
        
        % Normalize patch
        patch = patch - mean(patch(:));
        if std(patch(:)) > 0
            patch = patch / std(patch(:));
        end
        
        descriptors(i, :) = patch(:)';
    end
end
end

function matches = matchFeatures(descriptors1, descriptors2, points1, points2, threshold)
% Find matches between feature descriptors using nearest neighbor ratio test

 
if isempty(descriptors1) || isempty(descriptors2)
    matches = [];
    return;
end

matches = [];

for i = 1:size(descriptors1, 1)
    desc1 = descriptors1(i, :);
    
    % Compute distances to all descriptors in second image
    distances = sqrt(sum((descriptors2 - desc1).^2, 2));
    
    % Find two nearest neighbors
    [sortedDist, sortedIdx] = sort(distances);
    
    if length(sortedDist) >= 2
        % Ratio test for distinctive matches
        ratio = sortedDist(1) / sortedDist(2);
        
        if ratio < threshold && sortedDist(1) < 0.5 % Additional distance threshold
            matches(end+1, :) = [i, sortedIdx(1), sortedDist(1), ratio];
        end
    end
end
end

function tracks = createFeatureTracks(pairwiseMatches, numImages)
% Build feature tracks by connecting pairwise matches
tracks = [];
trackId = 1;

 
% Start with matches from first pair
if ~isempty(pairwiseMatches{1}.matches)
    for i = 1:size(pairwiseMatches{1}.matches, 1)
        track = struct();
        track.id = trackId;
        track.imageIds = [1, 2];
        track.featureIds = pairwiseMatches{1}.matches(i, 1:2);
        track.points = [pairwiseMatches{1}.points1(i, :); pairwiseMatches{1}.points2(i, :)];
        tracks = [tracks; track];
        trackId = trackId + 1;
    end
end

% Extend tracks with subsequent matches
for pairIdx = 2:(numImages-1)
    if isempty(pairwiseMatches{pairIdx}.matches)
        continue;
    end
    
    currentMatches = pairwiseMatches{pairIdx}.matches;
    
    for matchIdx = 1:size(currentMatches, 1)
        featureId1 = currentMatches(matchIdx, 1);
        featureId2 = currentMatches(matchIdx, 2);
        
        % Find existing track that ends with this feature
        trackFound = false;
        for trackIdx = 1:length(tracks)
            if length(tracks(trackIdx).imageIds) == pairIdx && ...
               tracks(trackIdx).imageIds(end) == pairIdx && ...
               tracks(trackIdx).featureIds(end) == featureId1
                
                % Extend this track
                tracks(trackIdx).imageIds(end+1) = pairIdx + 1;
                tracks(trackIdx).featureIds(end+1) = featureId2;
                tracks(trackIdx).points(end+1, :) = pairwiseMatches{pairIdx}.points2(matchIdx, :);
                trackFound = true;
                break;
            end
        end
        
        % Create new track if no existing track found
        if ~trackFound
            track = struct();
            track.id = trackId;
            track.imageIds = [pairIdx, pairIdx + 1];
            track.featureIds = [featureId1, featureId2];
            track.points = [pairwiseMatches{pairIdx}.points1(matchIdx, :); 
                           pairwiseMatches{pairIdx}.points2(matchIdx, :)];
            tracks = [tracks; track];
            trackId = trackId + 1;
        end
    end
end
end

function quality_metrics = assessCorrespondenceQuality(pairwiseMatches, featureTracks)
quality_metrics = struct();

 
% Pairwise matching statistics
totalInitialMatches = 0;
totalVerifiedMatches = 0;

for i = 1:length(pairwiseMatches)
    if ~isempty(pairwiseMatches{i}.matches)
        % Count matches before and after geometric verification
        % (This would require storing initial matches before verification)
        totalVerifiedMatches = totalVerifiedMatches + size(pairwiseMatches{i}.matches, 1);
    end
end

quality_metrics.total_verified_matches = totalVerifiedMatches;
quality_metrics.mean_matches_per_pair = totalVerifiedMatches / length(pairwiseMatches);

% Track-based statistics
trackLengths = arrayfun(@(x) length(x.imageIds), featureTracks);
quality_metrics.num_tracks = length(featureTracks);
quality_metrics.mean_track_length = mean(trackLengths);
quality_metrics.long_tracks_ratio = sum(trackLengths >= 3) / length(trackLengths);

% Coverage analysis (percentage of images with sufficient features)
imagesWithSufficientTracks = zeros(1, length(pairwiseMatches) + 1);
for track = featureTracks
    for imageId = track.imageIds
        imagesWithSufficientTracks(imageId) = imagesWithSufficientTracks(imageId) + 1;
    end
end
quality_metrics.min_tracks_per_image = min(imagesWithSufficientTracks);
quality_metrics.mean_tracks_per_image = mean(imagesWithSufficientTracks);

fprintf('\nCorrespondence Quality Assessment:\n');
fprintf('=================================\n');
fprintf('Total verified matches: %d\n', quality_metrics.total_verified_matches);
fprintf('Mean matches per image pair: %.1f\n', quality_metrics.mean_matches_per_pair);
fprintf('Number of feature tracks: %d\n', quality_metrics.num_tracks);
fprintf('Mean track length: %.1f images\n', quality_metrics.mean_track_length);
fprintf('Long tracks ratio (≡3 images): %.1f%%\n', quality_metrics.long_tracks_ratio * 100);
fprintf('Minimum tracks per image: %d\n', quality_metrics.min_tracks_per_image);
fprintf('Mean tracks per image: %.1f\n', quality_metrics.mean_tracks_per_image);
end
