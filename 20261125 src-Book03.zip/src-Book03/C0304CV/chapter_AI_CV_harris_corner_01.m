%% chapter_AI_CV_harris_corner_01.m
% Comprehensive Harris Corner Detection Implementation
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_harris_corner_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Load test image with prominent corner features
test_image = imread('checkerboard.png');
if size(test_image, 3) == 3
    test_image = rgb2gray(test_image);
end
test_image = im2double(test_image);

% MATLAB built-in corner detection
corners_harris = corner(test_image, 'Harris');
corners_minimum = corner(test_image, 'MinimumEigenvalue');

% Manual Harris corner detector implementation

% Apply manual Harris detector with different parameters
[corners_manual, response_map, structure_tensor] = harrisCornerDetector(test_image, 1.0, 0.04, 0.01);
[corners_high_k, response_map_high_k, ~] = harrisCornerDetector(test_image, 1.0, 0.08, 0.01);
[corners_low_k, response_map_low_k, ~] = harrisCornerDetector(test_image, 1.0, 0.02, 0.01);

% Eigenvalue-based corner detection for comparison

% Apply eigenvalue-based detection
[corners_eigenvalue, eigenvalue_map] = eigenvalueCornerDetector(test_image, 1.0, 0.005);

% Corner quality assessment

quality_harris = assessCornerQuality(corners_manual, response_map);
quality_eigenvalue = assessCornerQuality(corners_eigenvalue, eigenvalue_map);

% Multi-scale corner detection


% Apply multi-scale detection
scales = [0.5, 1.0, 1.5, 2.0];
multiscale_corners = detectMultiScaleCorners(test_image, scales, 0.04, 0.005);

% Display comprehensive results
figure;

% Original image with detected corners
subplot(2,4,1); 
imshow(test_image); hold on;
plot(corners_harris(:,1), corners_harris(:,2), 'r+', 'MarkerSize', 10, 'LineWidth', 2);
title('MATLAB Harris Corners');

subplot(2,4,2);
imshow(test_image); hold on;
plot(corners_manual(:,1), corners_manual(:,2), 'g+', 'MarkerSize', 10, 'LineWidth', 2);
title('Manual Harris Implementation');

subplot(2,4,3);
imshow(test_image); hold on;
plot(corners_eigenvalue(:,1), corners_eigenvalue(:,2), 'b+', 'MarkerSize', 10, 'LineWidth', 2);
title('Minimum Eigenvalue Method');

subplot(2,4,4);
imshow(test_image); hold on;
if ~isempty(multiscale_corners)
    plot(multiscale_corners(:,1), multiscale_corners(:,2), 'm+', 'MarkerSize', 10, 'LineWidth', 2);
end
title('Multi-scale Corners');

% Response maps
subplot(2,4,5); imshow(response_map, []); title('Harris Response Map');
subplot(2,4,6); imshow(eigenvalue_map, []); title('Min Eigenvalue Map');
subplot(2,4,7); imshow(structure_tensor.Ix2, []); title('Ix Component');
subplot(2,4,8); imshow(structure_tensor.Iy2, []); title('Iy Component');

% Quantitative analysis
fprintf('Corner Detection Performance Analysis:\n');
fprintf('MATLAB Harris: %d corners detected\n', size(corners_harris, 1));
fprintf('Manual Harris: %d corners detected\n', size(corners_manual, 1));
fprintf('Eigenvalue method: %d corners detected\n', size(corners_eigenvalue, 1));
fprintf('Multi-scale method: %d corners detected\n', size(multiscale_corners, 1));

if ~isempty(quality_harris)
    fprintf('Harris response range: %.6f to %.6f\n', min(quality_harris), max(quality_harris));
end
if ~isempty(quality_eigenvalue)
    fprintf('Eigenvalue range: %.6f to %.6f\n', min(quality_eigenvalue), max(quality_eigenvalue));
end

% Local functions (moved to end so this listing is a valid MATLAB script)
function [corners, response_map, structure_tensor] = harrisCornerDetector(image, sigma, k, threshold)
    % Compute image gradients using Sobel operators
    sobel_x = [-1 0 1; -2 0 2; -1 0 1];
    sobel_y = [-1 -2 -1; 0 0 0; 1 2 1];
    
    Ix = imfilter(image, sobel_x, 'symmetric');
    Iy = imfilter(image, sobel_y, 'symmetric');
    
    % Compute products of gradients
    Ix2 = Ix .* Ix;
    Iy2 = Iy .* Iy;
    Ixy = Ix .* Iy;
    
    % Apply Gaussian smoothing to gradient products
    gaussian_kernel = fspecial('gaussian', 2*ceil(3*sigma)+1, sigma);
    Ix2_smooth = imfilter(Ix2, gaussian_kernel, 'symmetric');
    Iy2_smooth = imfilter(Iy2, gaussian_kernel, 'symmetric');
    Ixy_smooth = imfilter(Ixy, gaussian_kernel, 'symmetric');
    
    % Compute Harris corner response
    % R = det(M) - k * trace(M)^2
    % where M = [Ix2_smooth, Ixy_smooth; Ixy_smooth, Iy2_smooth]
    det_M = Ix2_smooth .* Iy2_smooth - Ixy_smooth.^2;
    trace_M = Ix2_smooth + Iy2_smooth;
    response_map = det_M - k * trace_M.^2;
    
    % Store structure tensor components
    structure_tensor.Ix2 = Ix2_smooth;
    structure_tensor.Iy2 = Iy2_smooth;
    structure_tensor.Ixy = Ixy_smooth;
    
    % Find local maxima above threshold
    % Apply non-maximum suppression
    suppressed = imregionalmax(response_map) & (response_map > threshold);
    
    % Extract corner coordinates
    [corner_y, corner_x] = find(suppressed);
    corners = [corner_x, corner_y];
end

function [corners, eigenvalue_map] = eigenvalueCornerDetector(image, sigma, threshold)
    % Compute gradients
    [Ix, Iy] = gradient(double(image));
    
    % Compute products and smooth
    Ix2 = Ix .* Ix;
    Iy2 = Iy .* Iy;
    Ixy = Ix .* Iy;
    
    gaussian_kernel = fspecial('gaussian', 2*ceil(3*sigma)+1, sigma);
    Ix2_smooth = imfilter(Ix2, gaussian_kernel, 'symmetric');
    Iy2_smooth = imfilter(Iy2, gaussian_kernel, 'symmetric');
    Ixy_smooth = imfilter(Ixy, gaussian_kernel, 'symmetric');
    
    % Compute minimum eigenvalue at each pixel
    [rows, cols] = size(image);
    eigenvalue_map = zeros(rows, cols);
    
    for i = 1:rows
        for j = 1:cols
            M = [Ix2_smooth(i,j), Ixy_smooth(i,j); 
                 Ixy_smooth(i,j), Iy2_smooth(i,j)];
            eigenvals = eig(M);
            eigenvalue_map(i,j) = min(eigenvals);
        end
    end
    
    % Find corners as local maxima of minimum eigenvalue
    suppressed = imregionalmax(eigenvalue_map) & (eigenvalue_map > threshold);
    [corner_y, corner_x] = find(suppressed);
    corners = [corner_x, corner_y];
end

function quality_scores = assessCornerQuality(corners, response_map)
    quality_scores = zeros(size(corners, 1), 1);
    for i = 1:size(corners, 1)
        x = corners(i, 1);
        y = corners(i, 2);
        if x > 0 && x <= size(response_map, 2) && y > 0 && y <= size(response_map, 1)
            quality_scores(i) = response_map(y, x);
        end
    end
end

function multiscale_corners = detectMultiScaleCorners(image, sigmas, k, threshold)
    all_corners = [];
    all_responses = [];
    
    for i = 1:length(sigmas)
        [corners, response_map, ~] = harrisCornerDetector(image, sigmas(i), k, threshold);
        if ~isempty(corners)
            % Add scale information
            scale_info = repmat(sigmas(i), size(corners, 1), 1);
            corners_with_scale = [corners, scale_info];
            responses = assessCornerQuality(corners, response_map);
            
            all_corners = [all_corners; corners_with_scale];
            all_responses = [all_responses; responses];
        end
    end
    
    % Remove duplicates and select best corners
    if ~isempty(all_corners)
        % Simple duplicate removal based on spatial proximity
        multiscale_corners = removeDuplicateCorners(all_corners, all_responses, 5);
    else
        multiscale_corners = [];
    end
end

function unique_corners = removeDuplicateCorners(corners, responses, min_distance)
    if isempty(corners)
        unique_corners = [];
        return;
    end
    
    % Sort by response strength
    [~, sort_idx] = sort(responses, 'descend');
    sorted_corners = corners(sort_idx, :);
    
    unique_corners = [];
    for i = 1:size(sorted_corners, 1)
        current_corner = sorted_corners(i, 1:2);
        
        % Check distance to already selected corners
        if isempty(unique_corners)
            unique_corners = sorted_corners(i, :);
        else
            distances = sqrt(sum((unique_corners(:, 1:2) - current_corner).^2, 2));
            if min(distances) > min_distance
                unique_corners = [unique_corners; sorted_corners(i, :)];
            end
        end
    end
end
