%% chapter_AI_CV_neuromorphic_simulation_01.m
% Neuromorphic Vision System Simulation and Event-Driven Processing Framework
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_neuromorphic_simulation_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Neuromorphic Vision System Simulation Framework
fprintf('Neuromorphic Vision System Simulation\n');
fprintf('====================================\n');

% Create neuromorphic computing framework
neuromorphicFramework = createNeuromorphicFramework();


% 1. Event-Based Vision Sensor Simulation


% 2. Spiking Neural Network Implementation






% 3. Neuromorphic Visual Processing








% 4. Neuromorphic Feature Extraction







% 5. Adaptive Learning in Neuromorphic Systems




% Test the neuromorphic vision system
fprintf('\nTesting neuromorphic vision system...\n');

% Create test video sequence for event-based processing
testVideo = createTestVideoSequence();

% Simulate event-based sensor
events = simulateEventBasedSensor(testVideo, 0.15);

% Create spiking neural network
networkStructure = {
    struct('type', 'input', 'numNeurons', 64, 'inputMask', ones(8, 8)),
    struct('type', 'hidden', 'numNeurons', 32),
    struct('type', 'output', 'numNeurons', 16)
};

spikingNet = createSpikingNeuralNetwork(networkStructure, neuromorphicFramework);

% Process events through neuromorphic network
if ~isempty(events)
    processedEvents = neuromorphicVisualProcessing(events, spikingNet);
    
    % Extract features from processed events
    temporalFeatures = neuromorphicFeatureExtraction(processedEvents, 'temporal_contrast');
    motionFeatures = neuromorphicFeatureExtraction(events, 'motion_detection');
    edgeFeatures = neuromorphicFeatureExtraction(events, 'edge_detection');
    
    % Create target outputs for learning (simplified)
    targetOutputs = events(1:min(10, length(events))); % Use first 10 events as targets
    
    % Perform adaptive learning
    if length(processedEvents) >= length(targetOutputs)
        adaptedNet = neuromorphicAdaptiveLearning(spikingNet, events, targetOutputs);
    end
end


% Visualize neuromorphic results
figure;

% Event visualization
if ~isempty(events)
    subplot(2, 4, 1);
    eventTimes = [events.timestamp];
    eventX = [events.x];
    eventY = [events.y];
    scatter3(eventX, eventY, eventTimes, 20, eventTimes, 'filled');
    xlabel('X Position');
    ylabel('Y Position');
    zlabel('Time');
    title('Event Stream Visualization');
    colorbar;
    
    % Event polarity
    subplot(2, 4, 2);
    polarities = [events.polarity];
    scatter(eventX, eventY, 30, polarities, 'filled');
    xlabel('X Position');
    ylabel('Y Position');
    title('Event Polarities');
    colorbar;
    
    % Temporal event distribution
    subplot(2, 4, 3);
    histogram(eventTimes, 20);
    xlabel('Time');
    ylabel('Number of Events');
    title('Temporal Event Distribution');
    
    % Spatial event distribution
    subplot(2, 4, 4);
    histogram2(eventX, eventY, 10, 'DisplayStyle', 'tile');
    xlabel('X Position');
    ylabel('Y Position');
    title('Spatial Event Distribution');
    colorbar;
end

% Feature visualization
if exist('temporalFeatures', 'var') && ~isempty(temporalFeatures)
    subplot(2, 4, 5);
    plot(temporalFeatures(1:min(100, length(temporalFeatures))));
    xlabel('Feature Index');
    ylabel('Feature Value');
    title('Temporal Contrast Features');
end

if exist('motionFeatures', 'var') && ~isempty(motionFeatures)
    subplot(2, 4, 6);
    bar(motionFeatures);
    xlabel('Feature Index');
    ylabel('Feature Value');
    title('Motion Features');
end

if exist('edgeFeatures', 'var') && ~isempty(edgeFeatures)
    subplot(2, 4, 7);
    bar(edgeFeatures);
    xlabel('Feature Index');
    ylabel('Feature Value');
    title('Edge Features');
end

% Network structure visualization
subplot(2, 4, 8);
layerSizes = [networkStructure{1}.numNeurons, networkStructure{2}.numNeurons, networkStructure{3}.numNeurons];
bar(layerSizes);
set(gca, 'XTickLabel', {'Input', 'Hidden', 'Output'});
ylabel('Number of Neurons');
title('Network Structure');

sgtitle('Neuromorphic Vision System Results');

% Display comprehensive neuromorphic computing summary
fprintf('\n' + string(repmat('=', 1, 70)) + '\n');
fprintf('NEUROMORPHIC VISION SYSTEM SUMMARY\n');
fprintf(string(repmat('=', 1, 70)) + '\n');

fprintf('\nFRAMEWORK CONFIGURATION:\n');
fprintf('  Neuron model: %s\n', neuromorphicFramework.neuronModel);
fprintf('  Time step: %.1f ms\n', neuromorphicFramework.timeStep);
fprintf('  Simulation time: %.1f ms\n', neuromorphicFramework.simulationTime);
fprintf('  Threshold: %.1f mV\n', neuromorphicFramework.neuronParams.threshold);
fprintf('  Time constant: %.1f ms\n', neuromorphicFramework.neuronParams.membrane_time_constant);

if ~isempty(events)
    fprintf('\nEVENT-BASED PROCESSING:\n');
    fprintf('  Total events generated: %d\n', length(events));
    fprintf('  Event rate: %.1f events/frame\n', length(events) / size(testVideo, 3));
    fprintf('  Temporal span: %.1f frames\n', max([events.timestamp]) - min([events.timestamp]));
    
    positiveEvents = sum([events.polarity]);
    negativeEvents = sum(~[events.polarity]);
    fprintf('  Positive events: %d (%.1f%%)\n', positiveEvents, positiveEvents/length(events)*100);
    fprintf('  Negative events: %d (%.1f%%)\n', negativeEvents, negativeEvents/length(events)*100);
end

fprintf('\nSPIKING NEURAL NETWORK:\n');
fprintf('  Network layers: %d\n', length(spikingNet.layers));
for i = 1:length(spikingNet.layers)
    fprintf('    Layer %d: %d neurons (%s)\n', i, spikingNet.layers{i}.numNeurons, spikingNet.layers{i}.type);
end
fprintf('  Connections: %d\n', length(spikingNet.connections));

if exist('processedEvents', 'var')
    fprintf('\nPROCESSED EVENTS:\n');
    fprintf('  Output events: %d\n', length(processedEvents));
    if ~isempty(processedEvents)
        outputRate = length(processedEvents) / neuromorphicFramework.simulationTime;
        fprintf('  Output rate: %.1f events/ms\n', outputRate);
    end
end

if exist('temporalFeatures', 'var')
    fprintf('\nFEATURE EXTRACTION:\n');
    fprintf('  Temporal features: %d\n', length(temporalFeatures));
    fprintf('  Motion features: %d\n', length(motionFeatures));
    fprintf('  Edge features: %d\n', length(edgeFeatures));
end

fprintf('\nNEUROMORPHIC ADVANTAGES:\n');
fprintf('========================\n');
fprintf(' Ultra-low power consumption (米W to mW range)\n');
fprintf(' Event-driven processing eliminates redundant computation\n');
fprintf(' Natural temporal processing capabilities\n');
fprintf(' Asynchronous operation matches sensor dynamics\n');
fprintf(' Inherent robustness to variations and noise\n');
fprintf(' Massively parallel distributed processing\n');
fprintf(' Real-time processing with minimal latency\n');

fprintf('\nBIOLOGICAL INSPIRATION:\n');
fprintf('======================\n');
fprintf(' Retinal processing: ON/OFF ganglion cells\n');
fprintf(' Spiking communication: Action potentials\n');
fprintf(' Synaptic plasticity: STDP learning rules\n');
fprintf(' Hierarchical processing: Visual cortex organization\n');
fprintf(' Attention mechanisms: Dynamic routing\n');

fprintf('\nCURRENT LIMITATIONS:\n');
fprintf('===================\n');
fprintf(' Limited availability of neuromorphic hardware\n');
fprintf(' Programming complexity compared to conventional systems\n');
fprintf(' Limited software tools and development environments\n');
fprintf(' Integration challenges with existing systems\n');
fprintf(' Training algorithms still under development\n');

fprintf('\nFUTURE PROSPECTS:\n');
fprintf('================\n');
fprintf(' Large-scale neuromorphic processors (millions of neurons)\n');
fprintf(' Integration with event-based sensors\n');
fprintf(' Autonomous systems with ultra-low power requirements\n');
fprintf(' Brain-computer interfaces\n');
fprintf(' Edge AI with real-time processing\n');
fprintf(' Neuromorphic computing for IoT applications\n');

fprintf('\nAPPLICATION DOMAINS:\n');
fprintf('===================\n');
fprintf(' Autonomous vehicles: Real-time visual processing\n');
fprintf(' Robotics: Sensorimotor control and navigation\n');
fprintf(' Surveillance: Always-on visual monitoring\n');
fprintf(' Prosthetics: Neural interfaces for vision restoration\n');
fprintf(' Space applications: Radiation-tolerant processing\n');
fprintf(' Industrial automation: High-speed quality control\n');

fprintf('\n' + string(repmat('=', 1, 70)) + '\n');

% Local functions (moved to end so this listing is a valid MATLAB script)
function framework = createNeuromorphicFramework()
    % Create framework for neuromorphic vision system simulation
    
    fprintf('Creating neuromorphic computing framework...\n');
    
    framework = struct();
    framework.name = 'MATLAB Neuromorphic Vision Simulator';
    framework.timeStep = 0.1; % milliseconds
    framework.simulationTime = 100; % milliseconds
    framework.neuronModel = 'leaky_integrate_fire';
    framework.synapseModel = 'exponential';
    
    % Neuron parameters
    framework.neuronParams = struct();
    framework.neuronParams.restingPotential = -70; % mV
    framework.neuronParams.threshold = -55; % mV
    framework.neuronParams.reset = -80; % mV
    framework.neuronParams.membrane_time_constant = 20; % ms
    framework.neuronParams.refractory_period = 2; % ms
    
    % Synapse parameters
    framework.synapseParams = struct();
    framework.synapseParams.time_constant = 5; % ms
    framework.synapseParams.delay = 1; % ms
    framework.synapseParams.weight_scale = 1.0;
    
    fprintf('Neuromorphic framework initialized\n');
end

function events = simulateEventBasedSensor(videoSequence, threshold)
    % Simulate event-based vision sensor (like DVS camera)
    
    if nargin < 2
        threshold = 0.1; % Intensity change threshold
    end
    
    fprintf('Simulating event-based vision sensor...\n');
    
    [height, width, numFrames] = size(videoSequence);
    events = [];
    
    % Initialize previous frame
    prevFrame = double(videoSequence(:, :, 1)) / 255;
    
    for frame = 2:numFrames
        currentFrame = double(videoSequence(:, :, frame)) / 255;
        
        % Compute intensity change
        intensityChange = currentFrame - prevFrame;
        
        % Generate events for significant changes
        frameEvents = generateEvents(intensityChange, threshold, frame);
        events = [events; frameEvents];
        
        % Update previous frame
        prevFrame = currentFrame;
    end
    
    fprintf('Generated %d events from %d frames\n', size(events, 1), numFrames);
end

function frameEvents = generateEvents(intensityChange, threshold, timestamp)
    % Generate events from intensity changes
    
    frameEvents = [];
    
    % Find pixels with significant intensity changes
    [rows, cols] = find(abs(intensityChange) > threshold);
    
    for i = 1:length(rows)
        event = struct();
        event.x = cols(i);
        event.y = rows(i);
        event.timestamp = timestamp;
        event.polarity = intensityChange(rows(i), cols(i)) > 0; % 1 for increase, 0 for decrease
        event.magnitude = abs(intensityChange(rows(i), cols(i)));
        
        frameEvents = [frameEvents; event];
    end
end

function spikingNetwork = createSpikingNeuralNetwork(networkStructure, framework)
    % Create spiking neural network for neuromorphic processing
    
    fprintf('Creating spiking neural network...\n');
    
    spikingNetwork = struct();
    spikingNetwork.framework = framework;
    spikingNetwork.structure = networkStructure;
    spikingNetwork.layers = {};
    
    % Create network layers
    for layer = 1:length(networkStructure)
        layerConfig = networkStructure{layer};
        networkLayer = createSpikingLayer(layerConfig, framework);
        spikingNetwork.layers{layer} = networkLayer;
    end
    
    % Create connections between layers
    spikingNetwork.connections = createLayerConnections(spikingNetwork);
    
    fprintf('Spiking neural network created with %d layers\n', length(spikingNetwork.layers));
end

function layer = createSpikingLayer(config, framework)
    % Create a layer of spiking neurons
    
    layer = struct();
    layer.type = config.type;
    layer.numNeurons = config.numNeurons;
    layer.neurons = cell(config.numNeurons, 1);
    
    % Create individual neurons
    for neuron = 1:config.numNeurons
        layer.neurons{neuron} = createSpikingNeuron(framework);
    end
    
    % Layer-specific parameters
    if strcmp(config.type, 'input')
        layer.inputMask = config.inputMask;
    elseif strcmp(config.type, 'convolutional')
        layer.kernelSize = config.kernelSize;
        layer.stride = config.stride;
        layer.padding = config.padding;
    end
end

function neuron = createSpikingNeuron(framework)
    % Create individual spiking neuron
    
    neuron = struct();
    neuron.model = framework.neuronModel;
    neuron.params = framework.neuronParams;
    
    % State variables
    neuron.membranePotential = neuron.params.restingPotential;
    neuron.lastSpikeTime = -inf;
    neuron.synapticCurrent = 0;
    neuron.inputSpikes = [];
    neuron.outputSpikes = [];
    
    % Synaptic inputs
    neuron.synapses = [];
end

function connections = createLayerConnections(network)
    % Create connections between network layers
    
    connections = {};
    
    for layer = 1:(length(network.layers) - 1)
        currentLayer = network.layers{layer};
        nextLayer = network.layers{layer + 1};
        
        connection = struct();
        connection.preLayer = layer;
        connection.postLayer = layer + 1;
        connection.weights = createConnectionWeights(currentLayer, nextLayer);
        connection.delays = createConnectionDelays(currentLayer, nextLayer);
        
        connections{layer} = connection;
    end
end

function weights = createConnectionWeights(preLayer, postLayer)
    % Create synaptic weights between layers
    
    % Random initialization with biological constraints
    weights = randn(postLayer.numNeurons, preLayer.numNeurons) * 0.1;
    
    % Ensure non-negative weights (excitatory connections)
    weights = max(weights, 0);
    
    % Normalize to maintain stability
    weights = weights / sum(weights(:)) * preLayer.numNeurons;
end

function delays = createConnectionDelays(preLayer, postLayer)
    % Create synaptic delays between layers
    
    % Random delays with biological constraints (1-10 ms)
    delays = 1 + rand(postLayer.numNeurons, preLayer.numNeurons) * 9;
end

function processedEvents = neuromorphicVisualProcessing(inputEvents, spikingNetwork)
    % Process visual events through neuromorphic network
    
    fprintf('Processing visual events through neuromorphic network...\n');
    
    framework = spikingNetwork.framework;
    numTimeSteps = round(framework.simulationTime / framework.timeStep);
    
    processedEvents = [];
    
    % Initialize network state
    networkState = initializeNetworkState(spikingNetwork);
    
    for timeStep = 1:numTimeSteps
        currentTime = timeStep * framework.timeStep;
        
        % Get input events for current time
        timeEvents = getEventsAtTime(inputEvents, currentTime);
        
        % Inject input events into network
        networkState = injectInputEvents(networkState, timeEvents, spikingNetwork);
        
        % Simulate network dynamics
        networkState = simulateNetworkStep(networkState, spikingNetwork, currentTime);
        
        % Extract output events
        outputEvents = extractOutputEvents(networkState, currentTime);
        processedEvents = [processedEvents; outputEvents];
    end
    
    fprintf('Neuromorphic processing completed\n');
end

function state = initializeNetworkState(network)
    % Initialize network state for simulation
    
    state = struct();
    state.layers = cell(length(network.layers), 1);
    
    for layer = 1:length(network.layers)
        layerState = struct();
        layerState.membranePotentials = ones(network.layers{layer}.numNeurons, 1) * ...
                                       network.framework.neuronParams.restingPotential;
        layerState.lastSpikeTimes = -inf(network.layers{layer}.numNeurons, 1);
        layerState.synapticCurrents = zeros(network.layers{layer}.numNeurons, 1);
        layerState.spikeBuffer = cell(network.layers{layer}.numNeurons, 1);
        
        state.layers{layer} = layerState;
    end
end

function timeEvents = getEventsAtTime(events, currentTime)
    % Extract events occurring at current time
    
    if isempty(events)
        timeEvents = [];
        return;
    end
    
    % Find events within current time window
    timeWindow = 0.5; % ms
    eventTimes = [events.timestamp];
    
    validIndices = abs(eventTimes - currentTime) <= timeWindow;
    timeEvents = events(validIndices);
end

function state = injectInputEvents(state, events, network)
    % Inject input events into first layer neurons
    
    if isempty(events) || isempty(network.layers)
        return;
    end
    
    inputLayer = network.layers{1};
    
    if ~strcmp(inputLayer.type, 'input')
        return;
    end
    
    % Map events to input neurons
    for i = 1:length(events)
        event = events(i);
        
        % Map pixel coordinates to neuron indices (simplified)
        neuronIndex = mod(event.x + event.y * 64, inputLayer.numNeurons) + 1;
        
        % Inject spike
        state.layers{1}.spikeBuffer{neuronIndex} = [state.layers{1}.spikeBuffer{neuronIndex}; event];
    end
end

function state = simulateNetworkStep(state, network, currentTime)
    % Simulate one time step of network dynamics
    
    dt = network.framework.timeStep;
    
    % Update each layer
    for layer = 1:length(network.layers)
        state.layers{layer} = updateLayerState(state.layers{layer}, network.layers{layer}, ...
                                              network.framework, currentTime, dt);
    end
    
    % Propagate spikes between layers
    state = propagateSpikes(state, network, currentTime);
end

function layerState = updateLayerState(layerState, layerConfig, framework, currentTime, dt)
    % Update state of neurons in layer
    
    for neuron = 1:layerConfig.numNeurons
        % Check refractory period
        if currentTime - layerState.lastSpikeTimes(neuron) > framework.neuronParams.refractory_period
            
            % Update synaptic current (exponential decay)
            tau = framework.synapseParams.time_constant;
            layerState.synapticCurrents(neuron) = layerState.synapticCurrents(neuron) * exp(-dt / tau);
            
            % Add input current from spike buffer
            if ~isempty(layerState.spikeBuffer{neuron})
                inputCurrent = length(layerState.spikeBuffer{neuron}) * framework.synapseParams.weight_scale;
                layerState.synapticCurrents(neuron) = layerState.synapticCurrents(neuron) + inputCurrent;
                layerState.spikeBuffer{neuron} = []; % Clear buffer
            end
            
            % Update membrane potential (leaky integrate-and-fire)
            tau_m = framework.neuronParams.membrane_time_constant;
            V_rest = framework.neuronParams.restingPotential;
            I_syn = layerState.synapticCurrents(neuron);
            
            dV = (-(layerState.membranePotentials(neuron) - V_rest) + I_syn) / tau_m;
            layerState.membranePotentials(neuron) = layerState.membranePotentials(neuron) + dV * dt;
            
            % Check for spike
            if layerState.membranePotentials(neuron) >= framework.neuronParams.threshold
                % Generate spike
                layerState.lastSpikeTimes(neuron) = currentTime;
                layerState.membranePotentials(neuron) = framework.neuronParams.reset;
            end
        end
    end
end

function state = propagateSpikes(state, network, currentTime)
    % Propagate spikes between connected layers
    
    for connIdx = 1:length(network.connections)
        connection = network.connections{connIdx};
        preLayer = connection.preLayer;
        postLayer = connection.postLayer;
        
        % Find neurons that spiked in pre-synaptic layer
        spikingNeurons = find(state.layers{preLayer}.lastSpikeTimes == currentTime);
        
        for neuron = spikingNeurons'
            % Propagate spike to post-synaptic layer with delays
            for postNeuron = 1:size(connection.weights, 1)
                weight = connection.weights(postNeuron, neuron);
                delay = connection.delays(postNeuron, neuron);
                
                if weight > 0
                    % Add delayed spike to buffer (simplified - immediate for this simulation)
                    spikeEvent = struct('weight', weight, 'time', currentTime + delay);
                    state.layers{postLayer}.spikeBuffer{postNeuron} = ...
                        [state.layers{postLayer}.spikeBuffer{postNeuron}; spikeEvent];
                end
            end
        end
    end
end

function outputEvents = extractOutputEvents(state, currentTime)
    % Extract output events from final layer
    
    outputEvents = [];
    
    if isempty(state.layers)
        return;
    end
    
    % Get spikes from final layer
    finalLayer = state.layers{end};
    spikingNeurons = find(finalLayer.lastSpikeTimes == currentTime);
    
    for neuron = spikingNeurons'
        event = struct();
        event.neuronId = neuron;
        event.timestamp = currentTime;
        event.layerId = length(state.layers);
        
        outputEvents = [outputEvents; event];
    end
end

function features = neuromorphicFeatureExtraction(events, extractionMethod)
    % Extract features from neuromorphic event streams
    
    if nargin < 2
        extractionMethod = 'temporal_contrast';
    end
    
    fprintf('Extracting neuromorphic features using %s method...\n', extractionMethod);
    
    switch extractionMethod
        case 'temporal_contrast'
            features = extractTemporalContrastFeatures(events);
            
        case 'motion_detection'
            features = extractMotionFeatures(events);
            
        case 'edge_detection'
            features = extractEdgeFeatures(events);
            
        case 'event_histogram'
            features = extractEventHistogramFeatures(events);
            
        otherwise
            error('Unknown feature extraction method: %s', extractionMethod);
    end
    
    fprintf('Feature extraction completed\n');
end

function features = extractTemporalContrastFeatures(events)
    % Extract temporal contrast features from event stream
    
    if isempty(events)
        features = [];
        return;
    end
    
    % Create spatial grid
    maxX = max([events.x]);
    maxY = max([events.y]);
    gridSize = [maxY, maxX];
    
    % Create temporal windows
    timeWindows = 10; % Number of time windows
    maxTime = max([events.timestamp]);
    minTime = min([events.timestamp]);
    windowSize = (maxTime - minTime) / timeWindows;
    
    features = zeros(gridSize(1), gridSize(2), timeWindows);
    
    for window = 1:timeWindows
        windowStart = minTime + (window - 1) * windowSize;
        windowEnd = windowStart + windowSize;
        
        % Find events in current window
        eventIndices = find([events.timestamp] >= windowStart & [events.timestamp] < windowEnd);
        windowEvents = events(eventIndices);
        
        % Accumulate events in spatial grid
        for i = 1:length(windowEvents)
            event = windowEvents(i);
            features(event.y, event.x, window) = features(event.y, event.x, window) + event.magnitude;
        end
    end
    
    % Flatten features
    features = features(:);
end

function features = extractMotionFeatures(events)
    % Extract motion-based features from event stream
    
    if length(events) < 2
        features = [];
        return;
    end
    
    motionVectors = [];
    
    % Compute motion vectors between consecutive events
    for i = 2:length(events)
        prevEvent = events(i-1);
        currEvent = events(i);
        
        % Compute spatial displacement
        dx = currEvent.x - prevEvent.x;
        dy = currEvent.y - prevEvent.y;
        dt = currEvent.timestamp - prevEvent.timestamp;
        
        if dt > 0
            % Compute velocity
            vx = dx / dt;
            vy = dy / dt;
            
            motionVector = struct();
            motionVector.vx = vx;
            motionVector.vy = vy;
            motionVector.magnitude = sqrt(vx^2 + vy^2);
            motionVector.direction = atan2(vy, vx);
            
            motionVectors = [motionVectors; motionVector];
        end
    end
    
    % Extract statistical features from motion vectors
    if ~isempty(motionVectors)
        features = [
            mean([motionVectors.vx]);
            mean([motionVectors.vy]);
            std([motionVectors.vx]);
            std([motionVectors.vy]);
            mean([motionVectors.magnitude]);
            std([motionVectors.magnitude]);
            circ_mean([motionVectors.direction]');
            circ_std([motionVectors.direction]')
        ];
    else
        features = zeros(8, 1);
    end
end

function meanAngle = circ_mean(angles)
    % Circular mean for angular data
    meanAngle = atan2(mean(sin(angles)), mean(cos(angles)));
end

function stdAngle = circ_std(angles)
    % Circular standard deviation for angular data
    R = sqrt(mean(sin(angles))^2 + mean(cos(angles))^2);
    stdAngle = sqrt(-2 * log(R));
end

function features = extractEdgeFeatures(events)
    % Extract edge-based features from event stream
    
    if isempty(events)
        features = [];
        return;
    end
    
    % Create spatial grid
    maxX = max([events.x]);
    maxY = max([events.y]);
    eventMap = zeros(maxY, maxX);
    
    % Accumulate events
    for i = 1:length(events)
        event = events(i);
        eventMap(event.y, event.x) = eventMap(event.y, event.x) + event.magnitude;
    end
    
    % Apply edge detection
    [gradX, gradY] = gradient(eventMap);
    edgeMagnitude = sqrt(gradX.^2 + gradY.^2);
    edgeDirection = atan2(gradY, gradX);
    
    % Extract edge features
    features = [
        sum(edgeMagnitude(:));           % Total edge strength
        mean(edgeMagnitude(:));          % Average edge strength
        std(edgeMagnitude(:));           % Edge strength variability
        circ_mean(edgeDirection(:));     % Mean edge direction
        circ_std(edgeDirection(:));      % Edge direction variability
        nnz(edgeMagnitude > 0.1);        % Number of significant edges
    ];
end

function features = extractEventHistogramFeatures(events)
    % Extract histogram-based features from event stream
    
    if isempty(events)
        features = [];
        return;
    end
    
    % Temporal histogram
    numTimeBins = 20;
    maxTime = max([events.timestamp]);
    minTime = min([events.timestamp]);
    timeEdges = linspace(minTime, maxTime, numTimeBins + 1);
    temporalHist = histcounts([events.timestamp], timeEdges);
    
    % Spatial histogram
    numSpatialBins = 10;
    maxX = max([events.x]);
    maxY = max([events.y]);
    spatialHistX = histcounts([events.x], numSpatialBins);
    spatialHistY = histcounts([events.y], numSpatialBins);
    
    % Polarity histogram
    polarities = [events.polarity];
    polarityHist = [sum(polarities), sum(~polarities)];
    
    % Magnitude histogram
    magnitudes = [events.magnitude];
    magnitudeHist = histcounts(magnitudes, 10);
    
    % Combine all histograms
    features = [temporalHist, spatialHistX, spatialHistY, polarityHist, magnitudeHist]';
end

function adaptedNetwork = neuromorphicAdaptiveLearning(network, inputEvents, targetOutputs)
    % Implement adaptive learning for neuromorphic systems
    
    fprintf('Performing adaptive learning in neuromorphic system...\n');
    
    adaptedNetwork = network;
    learningRate = 0.01;
    numEpochs = 10;
    
    for epoch = 1:numEpochs
        fprintf('Learning epoch %d/%d\n', epoch, numEpochs);
        
        % Process input events
        networkOutputs = neuromorphicVisualProcessing(inputEvents, adaptedNetwork);
        
        % Compute error signals
        errorSignals = computeErrorSignals(networkOutputs, targetOutputs);
        
        % Update synaptic weights using spike-timing dependent plasticity (STDP)
        adaptedNetwork = applySTDPLearning(adaptedNetwork, errorSignals, learningRate);
        
        % Evaluate performance
        performance = evaluateNetworkPerformance(networkOutputs, targetOutputs);
        fprintf('  Performance: %.3f\n', performance);
    end
    
    fprintf('Adaptive learning completed\n');
end

function errorSignals = computeErrorSignals(networkOutputs, targetOutputs)
    % Compute error signals for learning
    
    % Simplified error computation
    numOutputs = length(networkOutputs);
    numTargets = length(targetOutputs);
    
    errorSignals = [];
    
    % Compare actual vs desired spike patterns
    for i = 1:min(numOutputs, numTargets)
        actualSpike = networkOutputs(i);
        targetSpike = targetOutputs(i);
        
        % Temporal error
        timeError = abs(actualSpike.timestamp - targetSpike.timestamp);
        
        % Spatial error
        spatialError = abs(actualSpike.neuronId - targetSpike.neuronId);
        
        error = struct();
        error.temporal = timeError;
        error.spatial = spatialError;
        error.combined = timeError + spatialError;
        
        errorSignals = [errorSignals; error];
    end
end

function network = applySTDPLearning(network, errorSignals, learningRate)
    % Apply spike-timing dependent plasticity learning
    
    % Update connection weights based on spike timing
    for connIdx = 1:length(network.connections)
        connection = network.connections{connIdx};
        
        % Simplified STDP rule
        for i = 1:length(errorSignals)
            error = errorSignals(i);
            
            % Potentiation for small errors, depression for large errors
            if error.combined < 1.0
                delta*Weight = learningRate * (1 - error.combined);
            else
                delta*Weight = -learningRate * error.combined * 0.1;
            end
            
            % Apply weight updates with constraints
            connection.weights = connection.weights + delta*Weight;
            connection.weights = max(0, connection.weights); % Non-negative weights
            connection.weights = min(1, connection.weights); % Maximum weight constraint
        end
        
        network.connections{connIdx} = connection;
    end
end

function performance = evaluateNetworkPerformance(outputs, targets)
    % Evaluate network performance
    
    if isempty(outputs) || isempty(targets)
        performance = 0;
        return;
    end
    
    % Simple performance metric based on temporal accuracy
    temporalErrors = [];
    
    for i = 1:min(length(outputs), length(targets))
        timeError = abs(outputs(i).timestamp - targets(i).timestamp);
        temporalErrors = [temporalErrors; timeError];
    end
    
    % Performance as inverse of mean temporal error
    if ~isempty(temporalErrors)
        meanError = mean(temporalErrors);
        performance = 1 / (1 + meanError);
    else
        performance = 0;
    end
end

function videoSeq = createTestVideoSequence()
    % Create test video sequence for neuromorphic processing
    
    numFrames = 20;
    frameSize = [64, 64];
    videoSeq = zeros([frameSize, numFrames], 'uint8');
    
    % Create moving object
    for frame = 1:numFrames
        % Moving circle
        centerX = 10 + frame * 2;
        centerY = 32;
        radius = 8;
        
        [X, Y] = meshgrid(1:frameSize(2), 1:frameSize(1));
        circle = (X - centerX).^2 + (Y - centerY).^2 <= radius^2;
        
        videoSeq(:, :, frame) = uint8(circle * 255);
    end
end
