%% chapter_AI_CV_lab4_snn_syntax.m
% Spiking neural network syntax.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_lab4_snn_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Create spiking neuron
neuron = struct();
neuron.membrane_potential = -70; % mV
neuron.threshold = -55; % mV
neuron.reset = -80; % mV

% Update neuron state
if neuron.membrane_potential >= neuron.threshold
    neuron.spike_time = current_time;
    neuron.membrane_potential = neuron.reset;
end
