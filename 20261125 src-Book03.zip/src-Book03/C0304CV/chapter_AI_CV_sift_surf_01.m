%% chapter_AI_CV_sift_surf_01.m
% SIFT and SURF Feature Descriptor Implementation and Comparison
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_sift_surf_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Load pair of images for feature matching demonstration
image1 = imread('cameraman.tif');
image2 = imrotate(image1, 30);  % Rotate for transformation testing
image2 = imresize(image2, 0.8); % Scale change
image2 = imnoise(image2, 'gaussian', 0, 0.01); % Add noise

% Convert to double precision
image1 = im2double(image1);
image2 = im2double(image2);

% SIFT feature detection and description
sift_points1 = detectSIFTFeatures(image1);
sift_points2 = detectSIFTFeatures(image2);

[sift_features1, sift_valid_points1] = extractFeatures(image1, sift_points1);
[sift_features2, sift_valid_points2] = extractFeatures(image2, sift_points2);

% SURF feature detection and description
surf_points1 = detectSURFFeatures(image1);
surf_points2 = detectSURFFeatures(image2);

[surf_features1, surf_valid_points1] = extractFeatures(image1, surf_points1);
[surf_features2, surf_valid_points2] = extractFeatures(image2, surf_points2);

% Feature matching
sift_index_pairs = matchFeatures(sift_features1, sift_features2);
surf_index_pairs = matchFeatures(surf_features1, surf_features2);

% Extract matched point locations
sift_matched_points1 = sift_valid_points1(sift_index_pairs(:,1));
sift_matched_points2 = sift_valid_points2(sift_index_pairs(:,2));

surf_matched_points1 = surf_valid_points1(surf_index_pairs(:,1));
surf_matched_points2 = surf_valid_points2(surf_index_pairs(:,2));

% Manual SIFT-like descriptor implementation for educational purposes

% Compute simplified SIFT descriptors for top features
if ~isempty(sift_valid_points1.Location)
    sample_keypoint1 = sift_valid_points1(1);
    sample_keypoint2 = sift_valid_points2(1);
    
    % Estimate dominant orientation (simplified)
    orientation1 = sample_keypoint1.Orientation * pi / 180;
    orientation2 = sample_keypoint2.Orientation * pi / 180;
    
    manual_descriptor1 = computeSimplifiedSIFTDescriptor(image1, sample_keypoint1, orientation1);
    manual_descriptor2 = computeSimplifiedSIFTDescriptor(image2, sample_keypoint2, orientation2);
end

% Feature matching quality assessment

% Robust matching using RANSAC

% Apply RANSAC to filter matches
if size(sift_matched_points1, 1) >= 4
    [sift_inliers1, sift_inliers2, sift_transform] = robustMatching(...
        sift_matched_points1, sift_matched_points2, 'similarity');
    sift_quality = assessMatchQuality(sift_inliers1, sift_inliers2);
end

if size(surf_matched_points1, 1) >= 4
    [surf_inliers1, surf_inliers2, surf_transform] = robustMatching(...
        surf_matched_points1, surf_matched_points2, 'similarity');
    surf_quality = assessMatchQuality(surf_inliers1, surf_inliers2);
end

% Descriptor analysis
sift_descriptor_stats.dimensions = size(sift_features1, 2);
sift_descriptor_stats.sparsity = mean(sift_features1(:) == 0);
sift_descriptor_stats.mean_norm = mean(sqrt(sum(sift_features1.^2, 2)));

surf_descriptor_stats.dimensions = size(surf_features1, 2);
surf_descriptor_stats.sparsity = mean(surf_features1(:) == 0);
surf_descriptor_stats.mean_norm = mean(sqrt(sum(surf_features1.^2, 2)));

% Display comprehensive results
figure;

% Original images with detected features
subplot(2,4,1);
imshow(image1); hold on;
plot(sift_valid_points1.Location(:,1), sift_valid_points1.Location(:,2), 'r+', 'MarkerSize', 6);
title(sprintf('SIFT Features Image 1 (%d)', length(sift_valid_points1)));

subplot(2,4,2);
imshow(image2); hold on;
plot(sift_valid_points2.Location(:,1), sift_valid_points2.Location(:,2), 'r+', 'MarkerSize', 6);
title(sprintf('SIFT Features Image 2 (%d)', length(sift_valid_points2)));

subplot(2,4,3);
imshow(image1); hold on;
plot(surf_valid_points1.Location(:,1), surf_valid_points1.Location(:,2), 'g+', 'MarkerSize', 6);
title(sprintf('SURF Features Image 1 (%d)', length(surf_valid_points1)));

subplot(2,4,4);
imshow(image2); hold on;
plot(surf_valid_points2.Location(:,1), surf_valid_points2.Location(:,2), 'g+', 'MarkerSize', 6);
title(sprintf('SURF Features Image 2 (%d)', length(surf_valid_points2)));

% Feature matching visualization
if exist('sift_inliers1', 'var') && ~isempty(sift_inliers1)
    subplot(2,4,5);
    showMatchedFeatures(image1, image2, sift_inliers1, sift_inliers2);
    title(sprintf('SIFT Matches (%d inliers)', length(sift_inliers1)));
end

if exist('surf_inliers1', 'var') && ~isempty(surf_inliers1)
    subplot(2,4,6);
    showMatchedFeatures(image1, image2, surf_inliers1, surf_inliers2);
    title(sprintf('SURF Matches (%d inliers)', length(surf_inliers1)));
end

% Descriptor statistics
subplot(2,4,7);
if ~isempty(sift_features1)
    histogram(sift_features1(:), 50);
    title('SIFT Descriptor Distribution');
    xlabel('Descriptor Value');
    ylabel('Frequency');
end

subplot(2,4,8);
if ~isempty(surf_features1)
    histogram(surf_features1(:), 50);
    title('SURF Descriptor Distribution');
    xlabel('Descriptor Value');
    ylabel('Frequency');
end

% Print quantitative analysis
fprintf('Feature Descriptor Performance Analysis:\n');
fprintf('SIFT Features: %d (Image 1), %d (Image 2)\n', ...
    length(sift_valid_points1), length(sift_valid_points2));
fprintf('SURF Features: %d (Image 1), %d (Image 2)\n', ...
    length(surf_valid_points1), length(surf_valid_points2));

fprintf('SIFT Matches: %d total, ', size(sift_matched_points1, 1));
if exist('sift_inliers1', 'var')
    fprintf('%d inliers (%.1f%%)\n', length(sift_inliers1), ...
        100 * length(sift_inliers1) / size(sift_matched_points1, 1));
else
    fprintf('0 inliers\n');
end

fprintf('SURF Matches: %d total, ', size(surf_matched_points1, 1));
if exist('surf_inliers1', 'var')
    fprintf('%d inliers (%.1f%%)\n', length(surf_inliers1), ...
        100 * length(surf_inliers1) / size(surf_matched_points1, 1));
else
    fprintf('0 inliers\n');
end

fprintf('SIFT Descriptor: %d dimensions, %.1f%% sparse\n', ...
    sift_descriptor_stats.dimensions, sift_descriptor_stats.sparsity * 100);
fprintf('SURF Descriptor: %d dimensions, %.1f%% sparse\n', ...
    surf_descriptor_stats.dimensions, surf_descriptor_stats.sparsity * 100);

% Local functions (moved to end so this listing is a valid MATLAB script)
function descriptor = computeSimplifiedSIFTDescriptor(image, keypoint, orientation)
    x = round(keypoint.Location(1));
    y = round(keypoint.Location(2));
    scale = keypoint.Scale;
    
    % Define descriptor window size (16*x16 with 4*x4 subregions)
    patch_size = round(16 * scale);
    half_size = floor(patch_size / 2);
    
    % Extract oriented patch
    if y-half_size > 0 && y+half_size <= size(image,1) && ...
       x-half_size > 0 && x+half_size <= size(image,2)
        
        patch = image(y-half_size:y+half_size, x-half_size:x+half_size);
        
        % Compute gradients
        [Gx, Gy] = gradient(double(patch));
        magnitude = sqrt(Gx.^2 + Gy.^2);
        angles = atan2(Gy, Gx);
        
        % Adjust angles relative to keypoint orientation
        angles = angles - orientation;
        angles(angles < 0) = angles(angles < 0) + 2*pi;
        
        % Create 4*x4 grid of subregions
        descriptor = zeros(4, 4, 8);  % 4*x4 spatial bins, 8 orientation bins
        subregion_size = size(patch, 1) / 4;
        
        for i = 1:4
            for j = 1:4
                % Extract subregion
                row_start = round((i-1) * subregion_size) + 1;
                row_end = round(i * subregion_size);
                col_start = round((j-1) * subregion_size) + 1;
                col_end = round(j * subregion_size);
                
                if row_end <= size(magnitude, 1) && col_end <= size(magnitude, 2)
                    sub_magnitude = magnitude(row_start:row_end, col_start:col_end);
                    sub_angles = angles(row_start:row_end, col_start:col_end);
                    
                    % Compute orientation histogram (8 bins)
                    for bin = 1:8
                        bin_center = (bin - 1) * pi / 4;
                        angle_diff = abs(sub_angles - bin_center);
                        angle_diff = min(angle_diff, 2*pi - angle_diff);
                        
                        weights = sub_magnitude .* exp(-angle_diff.^2 / (2 * (pi/8)^2));
                        descriptor(i, j, bin) = sum(weights(:));
                    end
                end
            end
        end
        
        % Flatten to 128-dimensional vector
        descriptor = descriptor(:);
        
        % Normalise and clip
        descriptor = descriptor / (norm(descriptor) + eps);
        descriptor(descriptor > 0.2) = 0.2;  % Illumination invariance
        descriptor = descriptor / (norm(descriptor) + eps);
    else
        descriptor = zeros(128, 1);
    end
end

function match_quality = assessMatchQuality(points1, points2, true_transformation)
    if nargin < 3
        % Simple distance-based quality measure
        distances = sqrt(sum((points1.Location - points2.Location).^2, 2));
        match_quality.mean_distance = mean(distances);
        match_quality.std_distance = std(distances);
    else
        % Transform points1 using known transformation and compare
        transformed_points = transformPointsForward(true_transformation, points1.Location);
        errors = sqrt(sum((transformed_points - points2.Location).^2, 2));
        match_quality.mean_error = mean(errors);
        match_quality.std_error = std(errors);
        match_quality.inlier_ratio = sum(errors < 5) / length(errors);
    end
end

function [inlier_points1, inlier_points2, transformation] = robustMatching(points1, points2, method)
    if strcmp(method, 'similarity')
        [transformation, inlier_indices] = estimateGeometricTransform2D(...
            points1, points2, 'similarity', 'MaxDistance', 4);
    else
        [transformation, inlier_indices] = estimateGeometricTransform2D(...
            points1, points2, 'affine', 'MaxDistance', 4);
    end
    
    inlier_points1 = points1(inlier_indices);
    inlier_points2 = points2(inlier_indices);
end

% Local function copied from another listing in this chapter
function matches = matchFeatures(descriptors1, descriptors2, points1, points2, threshold)
% Find matches between feature descriptors using nearest neighbor ratio test

 
if isempty(descriptors1) || isempty(descriptors2)
    matches = [];
    return;
end

matches = [];

for i = 1:size(descriptors1, 1)
    desc1 = descriptors1(i, :);
    
    % Compute distances to all descriptors in second image
    distances = sqrt(sum((descriptors2 - desc1).^2, 2));
    
    % Find two nearest neighbors
    [sortedDist, sortedIdx] = sort(distances);
    
    if length(sortedDist) >= 2
        % Ratio test for distinctive matches
        ratio = sortedDist(1) / sortedDist(2);
        
        if ratio < threshold && sortedDist(1) < 0.5 % Additional distance threshold
            matches(end+1, :) = [i, sortedIdx(1), sortedDist(1), ratio];
        end
    end
end
end
