%% chapter_AI_CV_lab1_cv_syntax.m
% Cross-validation framework implementation syntax.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_lab1_cv_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Cross-validation partition creation
cv = cvpartition(labels, 'KFold', numFolds, 'Stratify', true);

% Bootstrap sampling
bootIndices = randsample(numSamples, numSamples, true);

% Statistical testing
[h, p] = ttest2(results1, results2);
