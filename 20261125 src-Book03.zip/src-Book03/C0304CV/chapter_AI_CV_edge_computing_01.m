%% chapter_AI_CV_edge_computing_01.m
% Comprehensive Edge Computing Framework for Computer Vision
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_edge_computing_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Comprehensive Edge Computing Framework for Computer Vision
fprintf('Edge Computing Framework for Computer Vision\n');
fprintf('==========================================\n');

% Simulate edge computing environment
edgeEnvironment = createEdgeEnvironment();


% 1. Model Compression and Optimisation







% 2. Edge Device Optimisation





% 3. Distributed Edge Computing







% 4. Power and Thermal Management


% Test the complete edge computing framework
fprintf('\nTesting comprehensive edge computing framework...\n');

% Run all demonstrations
compressionResults = demonstrateModelCompression();
deviceResults = optimiseForEdgeDevices();
distributedResults = demonstrateDistributedEdgeComputing();
powerResults = demonstratePowerManagement();

% Visualise edge computing results
figure;

% Model compression comparison
subplot(3, 4, 1);
techniques = {'Original', 'Quantised', 'Pruned', 'Distilled'};
compressionRatios = [1, compressionResults.quantisationRatio, compressionResults.pruningRatio, compressionResults.distillationRatio];
bar(compressionRatios);
set(gca, 'XTickLabel', techniques);
xtickangle(45);
title('Model Compression Ratios');
ylabel('Size Reduction Factor');

% Accuracy retention
subplot(3, 4, 2);
accuracyRetention = [1, compressionResults.quantised.accuracy / compressionResults.original.accuracy, ...
                    compressionResults.pruned.accuracy / compressionResults.original.accuracy, ...
                    compressionResults.distilled.accuracy / compressionResults.original.accuracy];
bar(accuracyRetention);
set(gca, 'XTickLabel', techniques);
xtickangle(45);
title('Accuracy Retention');
ylabel('Relative Accuracy');

% Device performance comparison
subplot(3, 4, 3);
deviceNames = {};
fpsValues = [];

for i = 1:length(edgeEnvironment.devices)
    device = edgeEnvironment.devices{i};
    deviceName = device.name;
    deviceNames{end+1} = deviceName;
    
    fieldName = matlab.lang.makeValidName(deviceName);
    if isfield(deviceResults, fieldName) && isfield(deviceResults.*(fieldName), 'Medium') && ...
       isfield(deviceResults.*(fieldName).Medium, 'fps')
        fpsValues(end+1) = deviceResults.*(fieldName).Medium.fps;
    else
        fpsValues(end+1) = 0;
    end
end

bar(fpsValues);
set(gca, 'XTickLabel', deviceNames);
xtickangle(45);
title('Device Performance (FPS)');
ylabel('Frames Per Second');

% Power consumption by device
subplot(3, 4, 4);
powerValues = [];

for i = 1:length(edgeEnvironment.devices)
    device = edgeEnvironment.devices{i};
    deviceName = device.name;
    
    fieldName = matlab.lang.makeValidName(deviceName);
    if isfield(deviceResults, fieldName) && isfield(deviceResults.*(fieldName), 'Medium') && ...
       isfield(deviceResults.*(fieldName).Medium, 'powerConsumption')
        powerValues(end+1) = deviceResults.*(fieldName).Medium.powerConsumption;
    else
        powerValues(end+1) = device.power_watts;
    end
end

bar(powerValues);
set(gca, 'XTickLabel', deviceNames);
xtickangle(45);
title('Power Consumption');
ylabel('Watts');

% Distributed computing scenarios
subplot(3, 4, [5, 6]);
scenarios = fieldnames(distributedResults);
latencies = [];
privacyScores = [];

for i = 1:length(scenarios)
    scenario = scenarios{i};
    latencies(end+1) = distributedResults.*(scenario).totalLatency;
    privacyScores(end+1) = distributedResults.*(scenario).privacy;
end

yyaxis left;
bar(latencies);
ylabel('Latency (seconds)');
yyaxis right;
plot(1:length(scenarios), privacyScores, 'ro-', 'LineWidth', 2);
ylabel('Privacy Score');
set(gca, 'XTickLabel', scenarios);
xtickangle(45);
title('Distributed Computing Trade-offs');

% Power management strategies
subplot(3, 4, [7, 8]);
strategies = fieldnames(powerResults);
performancePerWatt = [];
batteryLife = [];

for i = 1:length(strategies)
    strategy = strategies{i};
    performancePerWatt(end+1) = powerResults.*(strategy).performancePerWatt;
    batteryLife(end+1) = powerResults.*(strategy).batteryLifeHours;
end

yyaxis left;
bar(performancePerWatt);
ylabel('Performance/Watt');
yyaxis right;
plot(1:length(strategies), batteryLife, 'go-', 'LineWidth', 2);
ylabel('Battery Life (hours)');
set(gca, 'XTickLabel', strategies);
xtickangle(45);
title('Power Management Strategies');

% Compression trade-offs
subplot(3, 4, 9);
sizes = [compressionResults.original.modelSize, compressionResults.quantised.modelSize, ...
         compressionResults.pruned.modelSize, compressionResults.distilled.modelSize] / 1e6;
accuracies = [compressionResults.original.accuracy, compressionResults.quantised.accuracy, ...
             compressionResults.pruned.accuracy, compressionResults.distilled.accuracy];

scatter(sizes, accuracies, 100, [1, 2, 3, 4], 'filled');
xlabel('Model Size (MB)');
ylabel('Accuracy');
title('Model Size vs Accuracy Trade-off');
colorbar;

% Edge vs cloud comparison
subplot(3, 4, 10);
deploymentOptions = {'Local Only', 'Edge-Cloud', 'Multi-Device', 'Hierarchical'};
edgeLatencies = [distributedResults.local_only.totalLatency, ...
                distributedResults.edge_cloud.totalLatency, ...
                distributedResults.multi_device.totalLatency, ...
                distributedResults.hierarchical.totalLatency];

bar(edgeLatencies);
set(gca, 'XTickLabel', deploymentOptions);
xtickangle(45);
title('Deployment Strategy Latencies');
ylabel('Latency (seconds)');

% Thermal management
subplot(3, 4, 11);
thermalOutputs = [];
operatingTemps = [];

for i = 1:length(strategies)
    strategy = strategies{i};
    thermalOutputs(end+1) = powerResults.*(strategy).thermalOutput;
    operatingTemps(end+1) = powerResults.*(strategy).operatingTemp;
end

yyaxis left;
bar(thermalOutputs);
ylabel('Thermal Output');
yyaxis right;
plot(1:length(strategies), operatingTemps, 'ro-', 'LineWidth', 2);
ylabel('Operating Temperature (～C)');
yline(80, 'r--', 'Throttle Threshold');
set(gca, 'XTickLabel', strategies);
xtickangle(45);
title('Thermal Management');

% Overall efficiency
subplot(3, 4, 12);
efficiency = performancePerWatt ./ max(performancePerWatt); % Normalised efficiency
powerConsumption = [];

for i = 1:length(strategies)
    strategy = strategies{i};
    powerConsumption(end+1) = powerResults.*(strategy).powerConsumption;
end

scatter(powerConsumption, efficiency, 100, 'filled');
xlabel('Power Consumption (W)');
ylabel('Normalised Efficiency');
title('Efficiency vs Power Trade-off');

% Add strategy labels
for i = 1:length(strategies)
    text(powerConsumption(i), efficiency(i), strategies{i}, 'VerticalAlignment', 'bottom');
end

sgtitle('Edge Computing for Computer Vision Results');

% Display comprehensive edge computing summary
fprintf('\n' + string(repmat('=', 1, 70)) + '\n');
fprintf('EDGE COMPUTING FOR COMPUTER VISION SUMMARY\n');
fprintf(string(repmat('=', 1, 70)) + '\n');

fprintf('\nMODEL COMPRESSION RESULTS:\n');
fprintf('  Quantisation: %.1fx size reduction, %.1f%% accuracy retention\n', ...
    compressionResults.quantisationRatio, ...
    (compressionResults.quantised.accuracy / compressionResults.original.accuracy) * 100);
fprintf('  Pruning: %.1fx size reduction, %.1f%% accuracy retention\n', ...
    compressionResults.pruningRatio, ...
    (compressionResults.pruned.accuracy / compressionResults.original.accuracy) * 100);
fprintf('  Distillation: %.1fx size reduction, %.1f%% accuracy retention\n', ...
    compressionResults.distillationRatio, ...
    (compressionResults.distilled.accuracy / compressionResults.original.accuracy) * 100);

fprintf('\nDEVICE OPTIMISATION:\n');
for i = 1:length(edgeEnvironment.devices)
    device = edgeEnvironment.devices{i};
    fprintf('  %s: %d cores, %dGB RAM, %.1fW power\n', ...
        device.name, device.cpu_cores, device.memory_gb, device.power_watts);
end

fprintf('\nDISTRIBUTED COMPUTING STRATEGIES:\n');
scenarios = fieldnames(distributedResults);
for i = 1:length(scenarios)
    scenario = scenarios{i};
    result = distributedResults.*(scenario);
    fprintf('  %s: %.3fs latency, %.1f%% privacy, %s requirements\n', ...
        scenario, result.totalLatency, result.privacy * 100, ...
        string(result.canMeetRequirements));
end

fprintf('\nPOWER MANAGEMENT:\n');
strategies = fieldnames(powerResults);
for i = 1:length(strategies)
    strategy = strategies{i};
    result = powerResults.*(strategy);
    fprintf('  %s: %.1fW power, %.1f FPS/W efficiency, %.1fh battery\n', ...
        strategy, result.powerConsumption, result.performancePerWatt, result.batteryLifeHours);
end

fprintf('\nEDGE COMPUTING BENEFITS:\n');
fprintf('=======================\n');
fprintf(' Reduced latency through local processing\n');
fprintf(' Enhanced privacy by keeping data local\n');
fprintf(' Reduced bandwidth requirements\n');
fprintf(' Improved reliability and resilience\n');
fprintf(' Scalable distributed processing\n');
fprintf(' Real-time responsiveness\n');
fprintf(' Reduced cloud computing costs\n');

fprintf('\nDEPLOYMENT CONSIDERATIONS:\n');
fprintf('=========================\n');
fprintf(' Hardware constraints and capabilities\n');
fprintf(' Power and thermal management\n');
fprintf(' Model optimisation and compression\n');
fprintf(' Network connectivity and reliability\n');
fprintf(' Security and privacy requirements\n');
fprintf(' Maintenance and updates\n');
fprintf(' Cost-effectiveness analysis\n');
fprintf(' Scalability and load balancing\n');

fprintf('\nBEST PRACTICES:\n');
fprintf('===============\n');
fprintf(' Profile applications on target hardware\n');
fprintf(' Use appropriate model compression techniques\n');
fprintf(' Implement adaptive power management\n');
fprintf(' Design for network intermittency\n');
fprintf(' Consider hybrid edge-cloud architectures\n');
fprintf(' Monitor thermal conditions and performance\n');
fprintf(' Implement graceful degradation strategies\n');
fprintf(' Plan for device lifecycle management\n');

fprintf('\nFUTURE TRENDS:\n');
fprintf('=============\n');
fprintf(' Dedicated AI accelerators in edge devices\n');
fprintf(' Federated learning for distributed training\n');
fprintf(' 5*G enabling ultra-low latency applications\n');
fprintf(' Neuromorphic computing for energy efficiency\n');
fprintf(' Edge-cloud continuum architectures\n');
fprintf(' Automated model optimisation and deployment\n');
fprintf(' Enhanced security and privacy frameworks\n');

fprintf('\n' + string(repmat('=', 1, 70)) + '\n');

% Local functions (moved to end so this listing is a valid MATLAB script)
function env = createEdgeEnvironment()
    % Create simulated edge computing environment
    
    fprintf('Creating edge computing environment...\n');
    
    env = struct();
    
    % Edge device specifications
    env.devices = {
        struct('name', 'Raspberry Pi 4', 'cpu_cores', 4, 'memory_gb', 4, 'gpu', false, 'power_watts', 5),
        struct('name', 'NVIDIA Jetson Nano', 'cpu_cores', 4, 'memory_gb', 4, 'gpu', true, 'power_watts', 10),
        struct('name', 'Intel NUC', 'cpu_cores', 8, 'memory_gb', 16, 'gpu', true, 'power_watts', 25),
        struct('name', 'Mobile Phone', 'cpu_cores', 8, 'memory_gb', 6, 'gpu', true, 'power_watts', 3),
        struct('name', 'Edge Server', 'cpu_cores', 16, 'memory_gb', 32, 'gpu', true, 'power_watts', 100)
    };
    
    % Network constraints
    env.network = struct();
    env.network.bandwidth_mbps = [1, 5, 10, 50, 100]; % Various bandwidth scenarios
    env.network.latency_ms = [50, 20, 10, 5, 2];
    env.network.reliability = [0.95, 0.97, 0.98, 0.99, 0.995];
    
    % Application requirements
    env.applications = {
        struct('name', 'Traffic Monitoring', 'fps_required', 30, 'accuracy_threshold', 0.9, 'latency_max_ms', 100),
        struct('name', 'Security Surveillance', 'fps_required', 15, 'accuracy_threshold', 0.95, 'latency_max_ms', 200),
        struct('name', 'Industrial Inspection', 'fps_required', 60, 'accuracy_threshold', 0.98, 'latency_max_ms', 50),
        struct('name', 'Agricultural Monitoring', 'fps_required', 1, 'accuracy_threshold', 0.85, 'latency_max_ms', 5000),
        struct('name', 'Autonomous Vehicle', 'fps_required', 30, 'accuracy_threshold', 0.99, 'latency_max_ms', 50)
    };
    
    fprintf('Created edge environment with %d device types and %d applications\n', ...
        length(env.devices), length(env.applications));
end

function compressionResults = demonstrateModelCompression()
    % Demonstrate model compression techniques for edge deployment
    
    fprintf('Demonstrating model compression techniques...\n');
    
    compressionResults = struct();
    
    % Create synthetic neural network model
    originalModel = createSyntheticModel();
    
    % Quantisation
    quantisedModel = quantiseModel(originalModel);
    
    % Pruning
    prunedModel = pruneModel(originalModel, 0.5); % 50% sparsity
    
    % Knowledge distillation (simplified)
    distilledModel = distillModel(originalModel);
    
    % Evaluate compressed models
    testData = createTestData();
    
    % Performance evaluation
    compressionResults.original = evaluateModel(originalModel, testData);
    compressionResults.quantised = evaluateModel(quantisedModel, testData);
    compressionResults.pruned = evaluateModel(prunedModel, testData);
    compressionResults.distilled = evaluateModel(distilledModel, testData);
    
    % Compression ratios
    compressionResults.quantisationRatio = compressionResults.original.modelSize / compressionResults.quantised.modelSize;
    compressionResults.pruningRatio = compressionResults.original.modelSize / compressionResults.pruned.modelSize;
    compressionResults.distillationRatio = compressionResults.original.modelSize / compressionResults.distilled.modelSize;
    
    fprintf('Model compression completed\n');
    fprintf('  Quantisation: %.1fx size reduction, %.3f accuracy retention\n', ...
        compressionResults.quantisationRatio, compressionResults.quantised.accuracy / compressionResults.original.accuracy);
    fprintf('  Pruning: %.1fx size reduction, %.3f accuracy retention\n', ...
        compressionResults.pruningRatio, compressionResults.pruned.accuracy / compressionResults.original.accuracy);
    fprintf('  Distillation: %.1fx size reduction, %.3f accuracy retention\n', ...
        compressionResults.distillationRatio, compressionResults.distilled.accuracy / compressionResults.original.accuracy);
end

function model = createSyntheticModel()
    % Create synthetic neural network model
    
    model = struct();
    model.layers = {};
    
    % Convolutional layers
    model.layers{end+1} = struct('type', 'conv', 'filters', 32, 'kernel_size', 3, 'weights', rand(3, 3, 3, 32, 'single'));
    model.layers{end+1} = struct('type', 'conv', 'filters', 64, 'kernel_size', 3, 'weights', rand(3, 3, 32, 64, 'single'));
    model.layers{end+1} = struct('type', 'conv', 'filters', 128, 'kernel_size', 3, 'weights', rand(3, 3, 64, 128, 'single'));
    
    % Fully connected layers
    model.layers{end+1} = struct('type', 'fc', 'units', 256, 'weights', rand(128*8*8, 256, 'single'));
    model.layers{end+1} = struct('type', 'fc', 'units', 10, 'weights', rand(256, 10, 'single'));
    
    % Calculate model size
    totalParams = 0;
    for i = 1:length(model.layers)
        totalParams = totalParams + numel(model.layers{i}.weights);
    end
    model.parameters = totalParams;
    model.sizeBytes = totalParams * 4; % 32-bit floats
end

function quantisedModel = quantiseModel(model)
    % Quantise model to 8-bit integers
    
    quantisedModel = model;
    
    for i = 1:length(model.layers)
        weights = model.layers{i}.weights;
        
        % Find min/max for quantisation
        minVal = min(weights(:));
        maxVal = max(weights(:));
        
        % Quantise to 8-bit
        scale = (maxVal - minVal) / 255;
        quantised = round((weights - minVal) / scale);
        quantised = uint8(quantised);
        
        % Store quantised weights and scale factors
        quantisedModel.layers{i}.weights = quantised;
        quantisedModel.layers{i}.scale = scale;
        quantisedModel.layers{i}.offset = minVal;
    end
    
    % Update model size
    quantisedModel.sizeBytes = model.parameters; % 8-bit instead of 32-bit
end

function prunedModel = pruneModel(model, sparsity)
    % Prune model by removing small weights
    
    prunedModel = model;
    
    for i = 1:length(model.layers)
        weights = model.layers{i}.weights;
        
        % Find threshold for pruning
        absWeights = abs(weights(:));
        threshold = prctile(absWeights, sparsity * 100);
        
        % Create pruning mask
        mask = abs(weights) > threshold;
        
        % Apply pruning
        prunedWeights = weights .* mask;
        
        prunedModel.layers{i}.weights = prunedWeights;
        prunedModel.layers{i}.mask = mask;
    end
    
    % Update model size (accounting for sparsity)
    prunedModel.sizeBytes = model.sizeBytes * (1 - sparsity);
end

function distilledModel = distillModel(originalModel)
    % Create smaller distilled model
    
    distilledModel = struct();
    distilledModel.layers = {};
    
    % Smaller architecture
    distilledModel.layers{end+1} = struct('type', 'conv', 'filters', 16, 'kernel_size', 3, 'weights', rand(3, 3, 3, 16, 'single'));
    distilledModel.layers{end+1} = struct('type', 'conv', 'filters', 32, 'kernel_size', 3, 'weights', rand(3, 3, 16, 32, 'single'));
    distilledModel.layers{end+1} = struct('type', 'fc', 'units', 64, 'weights', rand(32*16*16, 64, 'single'));
    distilledModel.layers{end+1} = struct('type', 'fc', 'units', 10, 'weights', rand(64, 10, 'single'));
    
    % Calculate model size
    totalParams = 0;
    for i = 1:length(distilledModel.layers)
        totalParams = totalParams + numel(distilledModel.layers{i}.weights);
    end
    distilledModel.parameters = totalParams;
    distilledModel.sizeBytes = totalParams * 4;
end

function testData = createTestData()
    % Create test data for model evaluation
    
    testData = struct();
    testData.images = rand(32, 32, 3, 100, 'single'); % 100 test images
    testData.labels = randi(10, 100, 1); % 10 classes
end

function results = evaluateModel(model, testData)
    % Evaluate model performance
    
    results = struct();
    results.modelSize = model.sizeBytes;
    results.parameters = model.parameters;
    
    % Simulate inference time (based on model complexity)
    complexityFactor = log(model.parameters) / 10;
    results.inferenceTime = 0.01 + complexityFactor * 0.001; % Simulated time
    
    % Simulate accuracy (larger models typically more accurate)
    baseAccuracy = 0.85;
    sizeBonus = min(0.1, log(model.parameters / 10000) * 0.02);
    results.accuracy = baseAccuracy + sizeBonus + randn() * 0.01;
    results.accuracy = max(0, min(1, results.accuracy));
    
    % Simulate memory usage
    results.memoryUsage = model.sizeBytes * 1.5; % Account for activations
    
    % Simulate power consumption
    results.powerConsumption = model.parameters / 100000; % Simplified model
end

function deviceResults = optimiseForEdgeDevices()
    % Optimise computer vision for different edge devices
    
    fprintf('Optimising for edge devices...\n');
    
    deviceResults = struct();
    
    % Create test models of different complexities
    models = {
        createLightweightModel(),
        createMediumModel(),
        createHeavyModel()
    };
    
    modelNames = {'Lightweight', 'Medium', 'Heavy'};
    
    % Test on different devices
    for deviceIdx = 1:length(edgeEnvironment.devices)
        device = edgeEnvironment.devices{deviceIdx};
        deviceName = device.name;
        
        deviceResults.*(matlab.lang.makeValidName(deviceName)) = struct();
        
        for modelIdx = 1:length(models)
            model = models{modelIdx};
            modelName = modelNames{modelIdx};
            
            % Check if model fits on device
            canRun = model.sizeBytes <= device.memory_gb * 1e9 * 0.5; % Use 50% of available memory
            
            if canRun
                % Simulate performance on device
                performance = simulateDevicePerformance(model, device);
                deviceResults.*(matlab.lang.makeValidName(deviceName)).*(modelName) = performance;
            else
                deviceResults.*(matlab.lang.makeValidName(deviceName)).*(modelName) = struct('canRun', false);
            end
        end
    end
    
    fprintf('Edge device optimisation completed\n');
end

function model = createLightweightModel()
    % Create lightweight model for resource-constrained devices
    
    model = struct();
    model.name = 'Lightweight';
    model.layers = 3;
    model.parameters = 50000;
    model.sizeBytes = model.parameters * 4;
    model.flops = 1e6; % Floating point operations
end

function model = createMediumModel()
    % Create medium-complexity model
    
    model = struct();
    model.name = 'Medium';
    model.layers = 8;
    model.parameters = 500000;
    model.sizeBytes = model.parameters * 4;
    model.flops = 10e6;
end

function model = createHeavyModel()
    % Create heavy model for high-performance applications
    
    model = struct();
    model.name = 'Heavy';
    model.layers = 20;
    model.parameters = 5000000;
    model.sizeBytes = model.parameters * 4;
    model.flops = 100e6;
end

function performance = simulateDevicePerformance(model, device)
    % Simulate model performance on specific device
    
    performance = struct();
    performance.canRun = true;
    
    % Estimate inference time based on device capabilities
    cpuPerformance = device.cpu_cores * 1e9; % Simplified FLOPS estimate
    
    if device.gpu
        gpuPerformance = cpuPerformance * 5; % GPU 5*x faster assumption
        totalPerformance = gpuPerformance;
    else
        totalPerformance = cpuPerformance;
    end
    
    performance.inferenceTime = model.flops / totalPerformance;
    performance.fps = 1 / performance.inferenceTime;
    
    % Estimate power consumption
    basePower = device.power_watts * 0.3; % Base power consumption
    computePower = (model.flops / 1e9) * 0.1; % Additional power for computation
    performance.powerConsumption = basePower + computePower;
    
    % Estimate memory usage
    performance.memoryUsage = model.sizeBytes + model.parameters * 0.1; % Account for activations
    
    % Estimate thermal impact
    performance.thermalImpact = performance.powerConsumption / device.power_watts;
    
    % Battery life estimate (for mobile devices)
    if strcmp(device.name, 'Mobile Phone')
        batteryCapacity = 15; % Wh
        performance.batteryLifeHours = batteryCapacity / performance.powerConsumption;
    end
end

function distributedResults = demonstrateDistributedEdgeComputing()
    % Demonstrate distributed edge computing strategies
    
    fprintf('Demonstrating distributed edge computing...\n');
    
    distributedResults = struct();
    
    % Define distributed computing scenarios
    scenarios = {
        'local_only',      % Process everything locally
        'edge_cloud',      % Hybrid edge-cloud processing
        'multi_device',    % Distributed across multiple edge devices
        'hierarchical'     % Hierarchical edge-cloud architecture
    };
    
    % Simulate workload
    workload = createComputerVisionWorkload();
    
    for i = 1:length(scenarios)
        scenario = scenarios{i};
        result = simulateDistributedScenario(workload, scenario);
        distributedResults.*(scenario) = result;
    end
    
    fprintf('Distributed edge computing simulation completed\n');
end

function workload = createComputerVisionWorkload()
    % Create computer vision workload for distributed processing
    
    workload = struct();
    workload.videoStreams = 4;
    workload.resolution = [1920, 1080];
    workload.fps = 30;
    workload.processingStages = {
        struct('name', 'preprocessing', 'complexity', 1, 'latency_sensitive', true),
        struct('name', 'detection', 'complexity', 10, 'latency_sensitive', true),
        struct('name', 'tracking', 'complexity', 5, 'latency_sensitive', true),
        struct('name', 'analytics', 'complexity', 3, 'latency_sensitive', false),
        struct('name', 'storage', 'complexity', 2, 'latency_sensitive', false)
    };
end

function result = simulateDistributedScenario(workload, scenario)
    % Simulate distributed computing scenario
    
    result = struct();
    result.scenario = scenario;
    
    switch scenario
        case 'local_only'
            result = simulateLocalProcessing(workload);
            
        case 'edge_cloud'
            result = simulateEdgeCloudProcessing(workload);
            
        case 'multi_device'
            result = simulateMultiDeviceProcessing(workload);
            
        case 'hierarchical'
            result = simulateHierarchicalProcessing(workload);
    end
end

function result = simulateLocalProcessing(workload)
    % Simulate local-only processing
    
    result = struct();
    result.totalLatency = 0;
    result.totalPower = 0;
    result.bandwidthUsage = 0;
    result.privacy = 1.0; % Full privacy
    
    device = edgeEnvironment.devices{2}; % Use Jetson Nano
    
    for i = 1:length(workload.processingStages)
        stage = workload.processingStages{i};
        
        % Simulate processing time
        stageLatency = stage.complexity * 0.01; % 10*ms per complexity unit
        result.totalLatency = result.totalLatency + stageLatency;
        
        % Simulate power consumption
        stagePower = stage.complexity * 0.5; % 0.5*W per complexity unit
        result.totalPower = result.totalPower + stagePower;
    end
    
    result.canMeetRequirements = result.totalLatency <= 0.1; % 100*ms requirement
end

function result = simulateEdgeCloudProcessing(workload)
    % Simulate edge-cloud hybrid processing
    
    result = struct();
    result.edgeLatency = 0;
    result.cloudLatency = 0;
    result.networkLatency = 0.05; % 50*ms network latency
    result.totalPower = 0;
    result.bandwidthUsage = 0;
    result.privacy = 0.7; % Reduced privacy due to cloud processing
    
    % Process latency-sensitive stages on edge
    edgeStages = {'preprocessing', 'detection'};
    cloudStages = {'analytics', 'storage'};
    
    device = edgeEnvironment.devices{2}; % Edge device
    
    for i = 1:length(workload.processingStages)
        stage = workload.processingStages{i};
        
        if ismember(stage.name, edgeStages)
            % Process on edge
            stageLatency = stage.complexity * 0.01;
            result.edgeLatency = result.edgeLatency + stageLatency;
            
            stagePower = stage.complexity * 0.5;
            result.totalPower = result.totalPower + stagePower;
        else
            % Process in cloud
            stageLatency = stage.complexity * 0.005; % Cloud is 2*x faster
            result.cloudLatency = result.cloudLatency + stageLatency;
            
            % Bandwidth usage
            dataSize = stage.complexity * 1; % MB per complexity unit
            result.bandwidthUsage = result.bandwidthUsage + dataSize;
        end
    end
    
    result.totalLatency = result.edgeLatency + result.cloudLatency + result.networkLatency;
    result.canMeetRequirements = result.totalLatency <= 0.1;
end

function result = simulateMultiDeviceProcessing(workload)
    % Simulate processing distributed across multiple edge devices
    
    result = struct();
    result.totalLatency = 0;
    result.totalPower = 0;
    result.bandwidthUsage = 0;
    result.privacy = 0.9; % High privacy, local network only
    
    % Distribute stages across devices
    numDevices = 3;
    stagesPerDevice = ceil(length(workload.processingStages) / numDevices);
    
    maxLatency = 0;
    
    for deviceIdx = 1:numDevices
        device = edgeEnvironment.devices{min(deviceIdx + 1, length(edgeEnvironment.devices))};
        
        deviceLatency = 0;
        devicePower = 0;
        
        startStage = (deviceIdx - 1) * stagesPerDevice + 1;
        endStage = min(deviceIdx * stagesPerDevice, length(workload.processingStages));
        
        for stageIdx = startStage:endStage
            stage = workload.processingStages{stageIdx};
            
            stageLatency = stage.complexity * 0.008; % Slightly better than single device
            deviceLatency = deviceLatency + stageLatency;
            
            stagePower = stage.complexity * 0.4;
            devicePower = devicePower + stagePower;
        end
        
        maxLatency = max(maxLatency, deviceLatency);
        result.totalPower = result.totalPower + devicePower;
        
        % Inter-device communication
        if deviceIdx > 1
            result.bandwidthUsage = result.bandwidthUsage + 5; % MB
        end
    end
    
    result.totalLatency = maxLatency + 0.01; % Add communication overhead
    result.canMeetRequirements = result.totalLatency <= 0.1;
end

function result = simulateHierarchicalProcessing(workload)
    % Simulate hierarchical edge-cloud processing
    
    result = struct();
    result.level1Latency = 0; % Edge devices
    result.level2Latency = 0; % Edge server
    result.level3Latency = 0; % Cloud
    result.totalPower = 0;
    result.bandwidthUsage = 0;
    result.privacy = 0.8; % Good privacy with selective cloud usage
    
    % Level 1: Edge devices (preprocessing, basic detection)
    level1Stages = {'preprocessing', 'detection'};
    for i = 1:length(workload.processingStages)
        stage = workload.processingStages{i};
        if ismember(stage.name, level1Stages)
            stageLatency = stage.complexity * 0.012;
            result.level1Latency = result.level1Latency + stageLatency;
            
            stagePower = stage.complexity * 0.3;
            result.totalPower = result.totalPower + stagePower;
        end
    end
    
    % Level 2: Edge server (tracking, basic analytics)
    level2Stages = {'tracking'};
    for i = 1:length(workload.processingStages)
        stage = workload.processingStages{i};
        if ismember(stage.name, level2Stages)
            stageLatency = stage.complexity * 0.005;
            result.level2Latency = result.level2Latency + stageLatency;
            
            result.bandwidthUsage = result.bandwidthUsage + stage.complexity * 0.5;
        end
    end
    
    % Level 3: Cloud (complex analytics, storage)
    level3Stages = {'analytics', 'storage'};
    for i = 1:length(workload.processingStages)
        stage = workload.processingStages{i};
        if ismember(stage.name, level3Stages)
            stageLatency = stage.complexity * 0.003;
            result.level3Latency = result.level3Latency + stageLatency;
            
            result.bandwidthUsage = result.bandwidthUsage + stage.complexity * 0.2;
        end
    end
    
    % Network latencies
    edgeToServer = 0.01; % 10*ms
    serverToCloud = 0.03; % 30*ms
    
    result.totalLatency = result.level1Latency + edgeToServer + result.level2Latency + 
                         serverToCloud + result.level3Latency;
    result.canMeetRequirements = result.totalLatency <= 0.15; % Relaxed requirement
end

function powerResults = demonstratePowerManagement()
    % Demonstrate power and thermal management for edge devices
    
    fprintf('Demonstrating power and thermal management...\n');
    
    powerResults = struct();
    
    % Test different power management strategies
    strategies = {'performance', 'balanced', 'power_saver', 'adaptive'};
    
    for i = 1:length(strategies)
        strategy = strategies{i};
        result = simulatePowerStrategy(strategy);
        powerResults.*(strategy) = result;
    end
    
    fprintf('Power management simulation completed\n');
end

function result = simulatePowerStrategy(strategy)
    % Simulate power management strategy
    
    result = struct();
    result.strategy = strategy;
    
    baseModel = createMediumModel();
    
    switch strategy
        case 'performance'
            % Maximum performance, high power
            result.cpuFrequency = 1.0; % Relative to maximum
            result.gpuFrequency = 1.0;
            result.inferenceTime = 0.05;
            result.powerConsumption = 15; % Watts
            result.thermalOutput = 12; % Relative units
            
        case 'balanced'
            % Balanced performance and power
            result.cpuFrequency = 0.8;
            result.gpuFrequency = 0.8;
            result.inferenceTime = 0.07;
            result.powerConsumption = 10;
            result.thermalOutput = 8;
            
        case 'power_saver'
            % Minimum power consumption
            result.cpuFrequency = 0.5;
            result.gpuFrequency = 0.4;
            result.inferenceTime = 0.12;
            result.powerConsumption = 5;
            result.thermalOutput = 4;
            
        case 'adaptive'
            % Adaptive based on workload and thermal conditions
            result.cpuFrequency = 0.7;
            result.gpuFrequency = 0.9; % Favour GPU
            result.inferenceTime = 0.06;
            result.powerConsumption = 8;
            result.thermalOutput = 6;
    end
    
    % Calculate efficiency metrics
    result.performancePerWatt = (1 / result.inferenceTime) / result.powerConsumption;
    result.energyPerInference = result.powerConsumption * result.inferenceTime;
    
    % Thermal management
    ambientTemp = 25; % Celsius
    result.operatingTemp = ambientTemp + result.thermalOutput;
    result.thermalThrottling = result.operatingTemp > 80; % Throttle above 80*C
    
    % Battery life estimate
    batteryCapacity = 50; % Wh (typical for edge device)
    result.batteryLifeHours = batteryCapacity / result.powerConsumption;
end
