%% chapter_AI_CV_fine_tuning_01.m
% Comprehensive Transfer Learning and Fine-tuning Implementation
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_fine_tuning_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Comprehensive Transfer Learning Implementation with Multiple Strategies
% Load pre-trained network
net = imagePretrainedNetwork('resnet18');

% Analyse pre-trained network structure
fprintf('Pre-trained Network Analysis:\n');
fprintf('=============================\n');
fprintf('Network: ResNet-18\n');
fprintf('Total layers: %d\n', length(net.Layers));

% Find key layers
inputLayer = net.Layers(1);
lastConvLayer = [];
classificationLayer = [];

for i = 1:length(net.Layers)
    if isa(net.Layers(i), 'nnet.cnn.layer.Convolution2DLayer')
        lastConvLayer = net.Layers(i);
    elseif isa(net.Layers(i), 'nnet.cnn.layer.ClassificationOutputLayer')
        classificationLayer = net.Layers(i);
    end
end

fprintf('Input size: %dx%dx%d\n', inputLayer.InputSize);
fprintf('Original number of classes: 1000 (ImageNet)\n');

% Create custom dataset (synthetic for demonstration)
imageSize = inputLayer.InputSize;
numClasses = 5;  % Custom classification task
numImagesPerClass = 50;
totalImages = numClasses * numImagesPerClass;

% Generate synthetic images with distinct patterns for each class
XTrain = zeros([imageSize, totalImages], 'single');
YTrain = categorical(zeros(totalImages, 1));

for class = 1:numClasses
    startIdx = (class-1) * numImagesPerClass + 1;
    endIdx = class * numImagesPerClass;
    
    % Create class-specific patterns
    for i = startIdx:endIdx
        % Base random image
        img = rand(imageSize, 'single');
        
        % Add class-specific patterns
        switch class
            case 1
                % Horizontal stripes
                img(:, 1:2:end, :) = img(:, 1:2:end, :) * 0.3;
            case 2
                % Vertical stripes
                img(1:2:end, :, :) = img(1:2:end, :, :) * 0.3;
            case 3
                % Diagonal pattern
                for row = 1:imageSize(1)
                    for col = 1:imageSize(2)
                        if mod(row + col, 4) == 0
                            img(row, col, :) = 0.8;
                        end
                    end
                end
            case 4
                % Central bright region
                center = imageSize(1:2) / 2;
                radius = imageSize(1) / 4;
                [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
                mask = (X - center(2)).^2 + (Y - center(1)).^2 < radius^2;
                img(repmat(mask, [1, 1, imageSize(3)])) = 0.9;
            case 5
                % Random noise with bias
                img = img * 0.5 + 0.4;
        end
        
        XTrain(:, :, :, i) = img;
        YTrain(i) = categorical(class);
    end
end

% Split into train and validation
valRatio = 0.2;
numVal = round(totalImages * valRatio);
indices = randperm(totalImages);
valIndices = indices(1:numVal);
trainIndices = indices(numVal+1:end);

XVal = XTrain(:, :, :, valIndices);
YVal = YTrain(valIndices);
XTrain = XTrain(:, :, :, trainIndices);
YTrain = YTrain(trainIndices);

fprintf('\nDataset Information:\n');
fprintf('Training images: %d\n', length(YTrain));
fprintf('Validation images: %d\n', length(YVal));
fprintf('Number of classes: %d\n', numClasses);

% Strategy 1: Feature Extraction (Freeze all layers except classifier)

% Strategy 2: Fine-tuning with different learning rates for different layers

% Strategy 3: Progressive unfreezing

% Create different network configurations
net_feature_extractor = createFeatureExtractor(net, numClasses);
net_fine_tuning = createFineTuningNetwork(net, numClasses);
net_progressive = createProgressiveNetwork(net, numClasses);

% Training options for different strategies
options_feature_extraction = trainingOptions('adam', ...
    'InitialLearnRate', 0.001, ...
    'MaxEpochs', 10, ...
    'MiniBatchSize', 16, ...
    'ValidationData', {XVal, YVal}, ...
    'ValidationFrequency', 10, ...
    'Verbose', false, ...
    'Plots', 'none');

options_fine_tuning = trainingOptions('adam', ...
    'InitialLearnRate', 0.0001, ... % Lower learning rate for fine-tuning
    'MaxEpochs', 15, ...
    'MiniBatchSize', 16, ...
    'ValidationData', {XVal, YVal}, ...
    'ValidationFrequency', 10, ...
    'Verbose', false, ...
    'Plots', 'none', ...
    'LearnRateSchedule', 'piecewise', ...
    'LearnRateDropPeriod', 5, ...
    'LearnRateDropFactor', 0.5);

% Train and evaluate different strategies
strategies = {'Feature Extraction', 'Fine-tuning', 'Progressive'};
networks = {net_feature_extractor, net_fine_tuning, net_progressive};
training_options = {options_feature_extraction, options_fine_tuning, options_fine_tuning};

results = struct();

for i = 1:length(strategies)
    fprintf('\nTraining %s strategy...\n', strategies{i});
    
    try
        tic;
        trained_net = trainNetwork({XTrain, YTrain}, networks{i}, training_options{i});
        training_time = toc;
        
        % Evaluate performance
        YPred = classify(trained_net, XVal);
        accuracy = sum(YPred == YVal) / numel(YVal);
        
        % Store results
        results.*(matlab.lang.makeValidName(strategies{i})) = struct();
        results.*(matlab.lang.makeValidName(strategies{i})).accuracy = accuracy;
        results.*(matlab.lang.makeValidName(strategies{i})).training_time = training_time;
        results.*(matlab.lang.makeValidName(strategies{i})).network = trained_net;
        
        fprintf('  Accuracy: %.2f%%\n', accuracy * 100);
        fprintf('  Training time: %.2f seconds\n', training_time);
        
    catch ME
        fprintf('  Error: %s\n', ME.message);
        results.*(matlab.lang.makeValidName(strategies{i})) = struct();
        results.*(matlab.lang.makeValidName(strategies{i})).accuracy = 0;
        results.*(matlab.lang.makeValidName(strategies{i})).training_time = inf;
    end
end

% Analyse layer activations and feature evolution

% Analyse feature evolution if networks were successfully trained
if isfield(results, 'FineTuning') && ~isempty(results.FineTuning.network)
    test_image = XVal(:, :, :, 1);
    analyseTransferLearning(net, results.FineTuning.network, test_image, 'conv2d_1');
end

% Performance comparison visualisation
field_names = fieldnames(results);
accuracies = [];
training_times = [];
valid_results = {};

for i = 1:length(field_names)
    if isfield(results.*(field_names{i}), 'accuracy') && results.*(field_names{i}).accuracy > 0
        accuracies(end+1) = results.*(field_names{i}).accuracy;
        training_times(end+1) = results.*(field_names{i}).training_time;
        valid_results{end+1} = field_names{i};
    end
end

if ~isempty(valid_results)
    figure;
    
    subplot(1, 2, 1);
    bar(accuracies * 100);
    title('Transfer Learning Strategy Comparison');
    ylabel('Accuracy (%)');
    set(gca, 'XTickLabel', valid_results);
    
    subplot(1, 2, 2);
    bar(training_times);
    title('Training Time Comparison');
    ylabel('Time (seconds)');
    set(gca, 'XTickLabel', valid_results);
end

% Learning curve analysis

plotLearningCurves([]);

% Best practices summary
fprintf('\n\nTransfer Learning Best Practices:\n');
fprintf('=================================\n');
fprintf('1. Use feature extraction when target dataset is small and similar to source\n');
fprintf('2. Use fine-tuning when target dataset is large or different from source\n');
fprintf('3. Start with lower learning rates for pre-trained layers\n');
fprintf('4. Use higher learning rates for new classifier layers\n');
fprintf('5. Consider progressive unfreezing for very different domains\n');
fprintf('6. Monitor for overfitting, especially with small datasets\n');
fprintf('7. Use data augmentation to increase effective dataset size\n');
fprintf('8. Experiment with different pre-trained architectures\n');

% Domain adaptation considerations
fprintf('\nDomain Adaptation Guidelines:\n');
fprintf('============================\n');
fprintf('Similar domains (e.g., ImageNet ↙ CIFAR): Fine-tune all layers\n');
fprintf('Different domains (e.g., Natural images ↙ Medical): Feature extraction + new classifier\n');
fprintf('Very different domains (e.g., RGB ↙ Thermal): Progressive unfreezing or full training\n');

% Local functions (moved to end so this listing is a valid MATLAB script)
function net_frozen = createFeatureExtractor(net, numClasses)
    % Convert to layer graph
    lgraph = layerGraph(net);
    
    % Find and replace final layers
    % Remove the last 3 layers (FC, Softmax, Classification)
    layersToRemove = {lgraph.Layers(end-2).Name, lgraph.Layers(end-1).Name, lgraph.Layers(end).Name};
    lgraph = removeLayers(lgraph, layersToRemove);
    
    % Add new classification layers
    newLayers = [
        fullyConnectedLayer(numClasses, 'Name', 'new_fc', ...
            'WeightLearnRateFactor', 10, 'BiasLearnRateFactor', 10)
        softmaxLayer('Name', 'new_softmax')
        classificationLayer('Name', 'new_output')
    ];
    
    lgraph = addLayers(lgraph, newLayers);
    
    % Connect new layers
    lastLayerName = lgraph.Layers(end-2).Name; % Layer before the removed ones
    lgraph = connectLayers(lgraph, lastLayerName, 'new_fc');
    
    % Freeze all layers except new ones
    layers = lgraph.Layers;
    for i = 1:length(layers)
        if ~contains(layers(i).Name, 'new_')
            if isprop(layers(i), 'WeightLearnRateFactor')
                layers(i).WeightLearnRateFactor = 0;
            end
            if isprop(layers(i), 'BiasLearnRateFactor')
                layers(i).BiasLearnRateFactor = 0;
            end
        end
    end
    
    lgraph.Layers = layers;
    net_frozen = lgraph;
end

function net_finetune = createFineTuningNetwork(net, numClasses)
    % Convert to layer graph
    lgraph = layerGraph(net);
    
    % Replace final layers
    layersToRemove = {lgraph.Layers(end-2).Name, lgraph.Layers(end-1).Name, lgraph.Layers(end).Name};
    lgraph = removeLayers(lgraph, layersToRemove);
    
    % Add new classification layers with higher learning rates
    newLayers = [
        fullyConnectedLayer(numClasses, 'Name', 'new_fc', ...
            'WeightLearnRateFactor', 20, 'BiasLearnRateFactor', 20)
        softmaxLayer('Name', 'new_softmax')
        classificationLayer('Name', 'new_output')
    ];
    
    lgraph = addLayers(lgraph, newLayers);
    
    % Connect new layers
    lastLayerName = lgraph.Layers(end-2).Name;
    lgraph = connectLayers(lgraph, lastLayerName, 'new_fc');
    
    % Set different learning rates for different layer groups
    layers = lgraph.Layers;
    for i = 1:length(layers)
        if contains(layers(i).Name, 'new_')
            % New layers: full learning rate
            continue;
        elseif i <= length(layers) * 0.3
            % Early layers: very low learning rate
            if isprop(layers(i), 'WeightLearnRateFactor')
                layers(i).WeightLearnRateFactor = 0.1;
            end
            if isprop(layers(i), 'BiasLearnRateFactor')
                layers(i).BiasLearnRateFactor = 0.1;
            end
        elseif i <= length(layers) * 0.7
            % Middle layers: moderate learning rate
            if isprop(layers(i), 'WeightLearnRateFactor')
                layers(i).WeightLearnRateFactor = 0.5;
            end
            if isprop(layers(i), 'BiasLearnRateFactor')
                layers(i).BiasLearnRateFactor = 0.5;
            end
        else
            % Later layers: higher learning rate
            if isprop(layers(i), 'WeightLearnRateFactor')
                layers(i).WeightLearnRateFactor = 2;
            end
            if isprop(layers(i), 'BiasLearnRateFactor')
                layers(i).BiasLearnRateFactor = 2;
            end
        end
    end
    
    lgraph.Layers = layers;
    net_finetune = lgraph;
end

function net_progressive = createProgressiveNetwork(net, numClasses)
    % Similar to fine-tuning but we'll implement progressive unfreezing
    % during training (simplified version shown here)
    lgraph = layerGraph(net);
    
    % Replace final layers
    layersToRemove = {lgraph.Layers(end-2).Name, lgraph.Layers(end-1).Name, lgraph.Layers(end).Name};
    lgraph = removeLayers(lgraph, layersToRemove);
    
    newLayers = [
        fullyConnectedLayer(numClasses, 'Name', 'new_fc', ...
            'WeightLearnRateFactor', 10, 'BiasLearnRateFactor', 10)
        softmaxLayer('Name', 'new_softmax')
        classificationLayer('Name', 'new_output')
    ];
    
    lgraph = addLayers(lgraph, newLayers);
    lastLayerName = lgraph.Layers(end-2).Name;
    lgraph = connectLayers(lgraph, lastLayerName, 'new_fc');
    
    net_progressive = lgraph;
end

function analyseTransferLearning(original_net, adapted_net, test_image, layer_name)
    % Extract features from both networks
    try
        original_features = activations(original_net, test_image, layer_name);
        adapted_features = activations(adapted_net, test_image, layer_name);
        
        % Compute feature similarity
        original_flat = original_features(:);
        adapted_flat = adapted_features(:);
        
        % Normalise features
        original_norm = original_flat / norm(original_flat);
        adapted_norm = adapted_flat / norm(adapted_flat);
        
        % Compute cosine similarity
        similarity = dot(original_norm, adapted_norm);
        
        fprintf('Layer %s feature similarity: %.3f\n', layer_name, similarity);
        
        % Visualise feature maps
        figure;
        
        subplot(1, 3, 1);
        imshow(test_image);
        title('Input Image');
        
        subplot(1, 3, 2);
        imagesc(mean(original_features, 3));
        title('Original Features');
        colorbar;
        
        subplot(1, 3, 3);
        imagesc(mean(adapted_features, 3));
        title('Adapted Features');
        colorbar;
        
        sgtitle(sprintf('Feature Evolution in %s', layer_name));
        
    catch ME
        fprintf('Error analysing layer %s: %s\n', layer_name, ME.message);
    end
end

function plotLearningCurves(training_info)
    % This would require storing training information during training
    % For demonstration, we'll create synthetic learning curves
    
    epochs = 1:10;
    
    % Simulated learning curves for different strategies
    feature_extraction_acc = 0.3 + 0.5 * (1 - exp(-epochs/2));
    fine_tuning_acc = 0.4 + 0.4 * (1 - exp(-epochs/3));
    progressive_acc = 0.2 + 0.6 * (1 - exp(-epochs/4));
    
    figure;
    plot(epochs, feature_extraction_acc, 'b-', 'LineWidth', 2, 'DisplayName', 'Feature Extraction');
    hold on;
    plot(epochs, fine_tuning_acc, 'r-', 'LineWidth', 2, 'DisplayName', 'Fine-tuning');
    plot(epochs, progressive_acc, 'g-', 'LineWidth', 2, 'DisplayName', 'Progressive');
    
    xlabel('Epoch');
    ylabel('Validation Accuracy');
    title('Learning Curves for Different Transfer Learning Strategies');
    legend('show');
    grid on;
end
