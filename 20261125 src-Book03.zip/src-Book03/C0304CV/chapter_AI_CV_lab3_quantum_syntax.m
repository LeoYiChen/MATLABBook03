%% chapter_AI_CV_lab3_quantum_syntax.m
% Quantum state representation syntax.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_lab3_quantum_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Create quantum state vector
quantumState = zeros(2^numQubits, 1);
quantumState(1) = 1; % Initialize to |0...0

% Apply quantum gate
quantumState = gateMatrix * quantumState;

% Measure quantum state
probabilities = abs(quantumState).^2;
