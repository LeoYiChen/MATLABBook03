%% chapter_AI_CV_lab2_complete.m
% Real-time Image Processing Optimisation Framework.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_lab2_complete
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% Real-time Image Processing Optimisation Framework
% Author: Dr Yi Chen
% Created: January 2025
% MATLAB Version: R2024a or later
% Description: Comprehensive framework for real-time image processing
%              with CPU and GPU optimisation techniques










    processingTime = toc;
    
    result = struct();
    result.method = 'Parallel CPU';
    result.processingTime = processingTime;
    result.fps = numFrames / processingTime;
    result.pixelsPerSecond = numel(video) / processingTime;
    result.processedVideo = processedVideo;
end






% Execute main function
optimisationResults = realtimeImageProcessingOptimisation();

% Local functions (moved to end so this listing is a valid MATLAB script)
function optimisationResults = realtimeImageProcessingOptimisation()
    %% Main function for real-time image processing optimisation
    
    fprintf('Real-time Image Processing Optimisation Framework\n');
    fprintf('=================================================\n');
    
    % Check system capabilities
    systemInfo = checkSystemCapabilities();
    
    % Create test video sequences
    testVideos = createTestVideoSequences();
    
    % Perform comprehensive optimisation benchmark
    optimisationResults = performOptimisationBenchmark(testVideos, systemInfo);
    
    % Generate optimisation report
    generateOptimisationReport(optimisationResults);
    
    % Visualise optimisation results
    visualiseOptimisationResults(optimisationResults);
end

function sysInfo = checkSystemCapabilities()
    %% Check system capabilities for optimisation
    
    fprintf('Checking system capabilities...\n');
    
    sysInfo = struct();
    
    % CPU information
    sysInfo.cpu = struct();
    sysInfo.cpu.cores = feature('numcores');
    sysInfo.cpu.threads = maxNumCompThreads();
    
    % Memory information
    [~, memInfo] = memory();
    sysInfo.memory = struct();
    sysInfo.memory.totalGB = memInfo.MemAvailableAllArrays / 1e9;
    
    % GPU information
    try
        gpu = gpuDevice();
        sysInfo.gpu = struct();
        sysInfo.gpu.available = true;
        sysInfo.gpu.name = gpu.Name;
        sysInfo.gpu.memory = gpu.TotalMemory / 1e9;
        sysInfo.gpu.computeCapability = gpu.ComputeCapability;
        fprintf('GPU detected: %s (%.1f GB)\n', gpu.Name, sysInfo.gpu.memory);
    catch
        sysInfo.gpu = struct();
        sysInfo.gpu.available = false;
        fprintf('No GPU available\n');
    end
    
    % Parallel pool information
    if isempty(gcp('nocreate'))
        parpool('local');
    end
    pool = gcp();
    sysInfo.parallel = struct();
    sysInfo.parallel.workers = pool.NumWorkers;
    
    fprintf('System capabilities checked\n');
end

function testVideos = createTestVideoSequences()
    %% Create test video sequences for benchmarking
    
    fprintf('Creating test video sequences...\n');
    
    testVideos = struct();
    
    % Different resolution sequences
    resolutions = {[480, 640], [720, 1280], [1080, 1920], [2160, 3840]};
    resolutionNames = {'480*p', '720*p', '1080*p', '4*K'};
    
    for i = 1:length(resolutions)
        resolution = resolutions{i};
        name = resolutionNames{i};
        
        % Create synthetic video sequence
        numFrames = 30;
        video = createSyntheticVideo(resolution, numFrames);
        
        testVideos.*(name) = struct();
        testVideos.*(name).frames = video;
        testVideos.*(name).resolution = resolution;
        testVideos.*(name).numFrames = numFrames;
        testVideos.*(name).totalPixels = prod(resolution) * numFrames;
    end
    
    fprintf('Test video sequences created\n');
end

function video = createSyntheticVideo(resolution, numFrames)
    %% Create synthetic video with motion and texture
    
    height = resolution(1);
    width = resolution(2);
    video = zeros(height, width, numFrames, 'uint8');
    
    % Create moving objects with texture
    for frame = 1:numFrames
        % Background
        background = uint8(rand(height, width) * 50 + 100);
        
        % Moving circle
        centerX = width/4 + (width/2) * (frame-1) / (numFrames-1);
        centerY = height/2 + 50 * sin(2*pi*(frame-1)/(numFrames-1));
        radius = 30;
        
        [X, Y] = meshgrid(1:width, 1:height);
        circle = (X - centerX).^2 + (Y - centerY).^2 <= radius^2;
        
        % Add circle to background
        frame_image = background;
        frame_image(circle) = 255;
        
        % Add noise for realism
        noise = uint8(randn(height, width) * 10);
        frame_image = frame_image + noise;
        
        video(:, :, frame) = frame_image;
    end
end

function results = performOptimisationBenchmark(testVideos, systemInfo)
    %% Perform comprehensive optimisation benchmark
    
    fprintf('Performing optimisation benchmark...\n');
    
    results = struct();
    videoNames = fieldnames(testVideos);
    
    for i = 1:length(videoNames)
        videoName = videoNames{i};
        video = testVideos.*(videoName).frames;
        
        fprintf('Benchmarking %s video (%dx%d)...\n', videoName, ...
            size(video, 2), size(video, 1));
        
        % Test different processing methods
        videoResults = struct();
        
        % 1. Sequential processing
        videoResults.sequential = benchmarkSequentialProcessing(video);
        
        % 2. Vectorised processing
        videoResults.vectorised = benchmarkVectorisedProcessing(video);
        
        % 3. Parallel CPU processing
        videoResults.parallelCPU = benchmarkParallelCPUProcessing(video);
        
        % 4. GPU processing (if available)
        if systemInfo.gpu.available
            videoResults.GPU = benchmarkGPUProcessing(video);
        end
        
        % 5. Memory-optimised processing
        videoResults.memoryOptimised = benchmarkMemoryOptimisedProcessing(video);
        
        results.*(videoName) = videoResults;
    end
    
    fprintf('Optimisation benchmark completed\n');
end

function result = benchmarkSequentialProcessing(video)
    %% Benchmark sequential processing approach
    
    fprintf('  Testing sequential processing...\n');
    
    [height, width, numFrames] = size(video);
    processedVideo = zeros(size(video), 'uint8');
    
    tic;
    for frame = 1:numFrames
        currentFrame = video(:, :, frame);
        
        % Apply image processing pipeline
        processedFrame = sequentialImageProcessingPipeline(currentFrame);
        processedVideo(:, :, frame) = processedFrame;
    end
    processingTime = toc;
    
    result = struct();
    result.method = 'Sequential';
    result.processingTime = processingTime;
    result.fps = numFrames / processingTime;
    result.pixelsPerSecond = numel(video) / processingTime;
    result.processedVideo = processedVideo;
end

function processedFrame = sequentialImageProcessingPipeline(frame)
    %% Sequential image processing pipeline
    
    % Convert to double for processing
    img = double(frame);
    
    % 1. Gaussian smoothing
    sigma = 1.0;
    kernelSize = 2 * ceil(3 * sigma) + 1;
    kernel = fspecial('gaussian', kernelSize, sigma);
    smoothed = imfilter(img, kernel, 'same', 'replicate');
    
    % 2. Edge detection
    [Gx, Gy] = gradient(smoothed);
    edgeMagnitude = sqrt(Gx.^2 + Gy.^2);
    
    % 3. Thresholding
    threshold = graythresh(uint8(edgeMagnitude)) * max(edgeMagnitude(:));
    edges = edgeMagnitude > threshold;
    
    % 4. Morphological operations
    se = strel('disk', 2);
    cleaned = imclose(edges, se);
    
    % Convert back to uint8
    processedFrame = uint8(cleaned * 255);
end

function result = benchmarkVectorisedProcessing(video)
    %% Benchmark vectorised processing approach
    
    fprintf('  Testing vectorised processing...\n');
    
    [height, width, numFrames] = size(video);
    
    tic;
    % Process all frames simultaneously using vectorisation
    processedVideo = vectorisedImageProcessingPipeline(video);
    processingTime = toc;
    
    result = struct();
    result.method = 'Vectorised';
    result.processingTime = processingTime;
    result.fps = numFrames / processingTime;
    result.pixelsPerSecond = numel(video) / processingTime;
    result.processedVideo = processedVideo;
end

function processedVideo = vectorisedImageProcessingPipeline(video)
    %% Vectorised image processing pipeline
    
    % Convert to double
    videoDouble = double(video);
    
    % 1. Gaussian smoothing (3*D convolution)
    sigma = 1.0;
    kernelSize = 2 * ceil(3 * sigma) + 1;
    kernel = fspecial('gaussian', kernelSize, sigma);
    
    % Apply 2*D filter to each frame
    smoothed = zeros(size(videoDouble));
    for frame = 1:size(video, 3)
        smoothed(:, :, frame) = imfilter(videoDouble(:, :, frame), kernel, 'same', 'replicate');
    end
    
    % 2. Vectorised gradient computation
    [Gx, Gy] = gradient(smoothed);
    edgeMagnitude = sqrt(Gx.^2 + Gy.^2);
    
    % 3. Vectorised thresholding
    globalThreshold = prctile(edgeMagnitude(:), 85); % 85*th percentile
    edges = edgeMagnitude > globalThreshold;
    
    % 4. Vectorised morphological operations
    se = strel('disk', 2);
    processedVideo = zeros(size(video), 'uint8');
    
    for frame = 1:size(video, 3)
        cleaned = imclose(edges(:, :, frame), se);
        processedVideo(:, :, frame) = uint8(cleaned * 255);
    end
end

function result = benchmarkParallelCPUProcessing(video)
    %% Benchmark parallel CPU processing approach
    
    fprintf('  Testing parallel CPU processing...\n');
    
    [height, width, numFrames] = size(video);
    processedVideo = zeros(size(video), 'uint8');
    
    tic;
    % Use parfor for frame-level parallelisation
    parfor frame = 1:numFrames
        currentFrame = video(:, :, frame);
        processedFrame = sequentialImageProcessingPipeline(currentFrame);
        processedVideo(:, :, frame) = processedFrame;
    end

function result = benchmarkGPUProcessing(video)
    %% Benchmark GPU processing approach
    
    fprintf('  Testing GPU processing...\n');
    
    [height, width, numFrames] = size(video);
    
    tic;
    % Transfer to GPU
    gpuVideo = gpuArray(video);
    
    % Process on GPU
    processedGPUVideo = gpuImageProcessingPipeline(gpuVideo);
    
    % Transfer back to CPU
    processedVideo = gather(processedGPUVideo);
    
    % Wait for GPU to complete
    wait(gpuDevice);
    processingTime = toc;
    
    result = struct();
    result.method = 'GPU';
    result.processingTime = processingTime;
    result.fps = numFrames / processingTime;
    result.pixelsPerSecond = numel(video) / processingTime;
    result.processedVideo = processedVideo;
end

function processedVideo = gpuImageProcessingPipeline(gpuVideo)
    %% GPU-accelerated image processing pipeline
    
    % Convert to double on GPU
    videoDouble = double(gpuVideo);
    
    % 1. GPU Gaussian smoothing
    sigma = 1.0;
    kernelSize = 2 * ceil(3 * sigma) + 1;
    kernel = gpuArray(fspecial('gaussian', kernelSize, sigma));
    
    smoothed = zeros(size(videoDouble), 'like', videoDouble);
    for frame = 1:size(gpuVideo, 3)
        smoothed(:, :, frame) = imfilter(videoDouble(:, :, frame), kernel, 'same', 'replicate');
    end
    
    % 2. GPU gradient computation
    [Gx, Gy] = gradient(smoothed);
    edgeMagnitude = sqrt(Gx.^2 + Gy.^2);
    
    % 3. GPU thresholding
    globalThreshold = prctile(edgeMagnitude(:), 85);
    edges = edgeMagnitude > globalThreshold;
    
    % 4. GPU morphological operations (simplified)
    se = gpuArray(strel('disk', 2).Neighborhood);
    processedVideo = zeros(size(gpuVideo), 'like', gpuVideo);
    
    for frame = 1:size(gpuVideo, 3)
        % Simplified closing operation on GPU
        dilated = imdilate(edges(:, :, frame), se);
        closed = imerode(dilated, se);
        processedVideo(:, :, frame) = uint8(closed * 255);
    end
end

function result = benchmarkMemoryOptimisedProcessing(video)
    %% Benchmark memory-optimised processing approach
    
    fprintf('  Testing memory-optimised processing...\n');
    
    [height, width, numFrames] = size(video);
    
    % Process in chunks to optimise memory usage
    chunkSize = 5; % Process 5 frames at a time
    processedVideo = zeros(size(video), 'uint8');
    
    tic;
    for startFrame = 1:chunkSize:numFrames
        endFrame = min(startFrame + chunkSize - 1, numFrames);
        chunk = video(:, :, startFrame:endFrame);
        
        % Process chunk
        processedChunk = vectorisedImageProcessingPipeline(chunk);
        processedVideo(:, :, startFrame:endFrame) = processedChunk;
        
        % Clear intermediate variables to free memory
        clear chunk processedChunk;
    end
    processingTime = toc;
    
    result = struct();
    result.method = 'Memory Optimised';
    result.processingTime = processingTime;
    result.fps = numFrames / processingTime;
    result.pixelsPerSecond = numel(video) / processingTime;
    result.processedVideo = processedVideo;
end

function generateOptimisationReport(optimisationResults)
    %% Generate comprehensive optimisation report
    
    fprintf('\n' + string(repmat('=', 1, 70)) + '\n');
    fprintf('REAL-TIME IMAGE PROCESSING OPTIMISATION REPORT\n');
    fprintf(string(repmat('=', 1, 70)) + '\n');
    
    videoNames = fieldnames(optimisationResults);
    
    for i = 1:length(videoNames)
        videoName = videoNames{i};
        videoResults = optimisationResults.*(videoName);
        
        fprintf('\n%s VIDEO RESULTS:\n', upper(videoName));
        fprintf(string(repmat('-', 1, 40)) + '\n');
        
        methods = fieldnames(videoResults);
        
        % Find baseline (sequential) performance
        baselineTime = inf;
        if isfield(videoResults, 'sequential')
            baselineTime = videoResults.sequential.processingTime;
        end
        
        for j = 1:length(methods)
            method = methods{j};
            result = videoResults.*(method);
            
            speedup = baselineTime / result.processingTime;
            
            fprintf('  %s:\n', result.method);
            fprintf('    Processing time: %.3f seconds\n', result.processingTime);
            fprintf('    Frame rate: %.1f FPS\n', result.fps);
            fprintf('    Throughput: %.1f MPix/s\n', result.pixelsPerSecond / 1e6);
            fprintf('    Speedup: %.1fx\n', speedup);
            fprintf('\n');
        end
    end
    
    % Summary analysis
    fprintf('\nOPTIMISATION ANALYSIS:\n');
    fprintf(string(repmat('=', 1, 40)) + '\n');
    
    % Find best performing method for each resolution
    for i = 1:length(videoNames)
        videoName = videoNames{i};
        videoResults = optimisationResults.*(videoName);
        methods = fieldnames(videoResults);
        
        bestFPS = 0;
        bestMethod = '';
        
        for j = 1:length(methods)
            method = methods{j};
            fps = videoResults.*(method).fps;
            if fps > bestFPS
                bestFPS = fps;
                bestMethod = videoResults.*(method).method;
            end
        end
        
        fprintf('  %s: Best method is %s (%.1f FPS)\n', videoName, bestMethod, bestFPS);
    end
    
    fprintf('\n' + string(repmat('=', 1, 70)) + '\n');
end

function visualiseOptimisationResults(optimisationResults)
    %% Visualise optimisation results
    
    figure('Position', [100, 100, 1400, 900]);
    
    videoNames = fieldnames(optimisationResults);
    numVideos = length(videoNames);
    
    % Extract data for visualisation
    allMethods = {};
    fpsMatrix = [];
    speedupMatrix = [];
    
    for i = 1:numVideos
        videoName = videoNames{i};
        videoResults = optimisationResults.*(videoName);
        methods = fieldnames(videoResults);
        
        if i == 1
            allMethods = methods;
            fpsMatrix = zeros(numVideos, length(methods));
            speedupMatrix = zeros(numVideos, length(methods));
        end
        
        % Find baseline time
        baselineTime = inf;
        if isfield(videoResults, 'sequential')
            baselineTime = videoResults.sequential.processingTime;
        end
        
        for j = 1:length(methods)
            method = methods{j};
            result = videoResults.*(method);
            
            fpsMatrix(i, j) = result.fps;
            speedupMatrix(i, j) = baselineTime / result.processingTime;
        end
    end
    
    % Method labels for plotting
    methodLabels = cell(size(allMethods));
    for i = 1:length(allMethods)
        if isfield(optimisationResults.*(videoNames{1}), allMethods{i})
            methodLabels{i} = optimisationResults.*(videoNames{1}).*(allMethods{i}).method;
        else
            methodLabels{i} = allMethods{i};
        end
    end
    
    % FPS comparison across resolutions
    subplot(2, 3, 1);
    bar(fpsMatrix);
    set(gca, 'XTickLabel', videoNames);
    ylabel('Frame Rate (FPS)');
    title('Frame Rate by Resolution');
    legend(methodLabels, 'Location', 'best');
    grid on;
    
    % Speedup comparison
    subplot(2, 3, 2);
    bar(speedupMatrix);
    set(gca, 'XTickLabel', videoNames);
    ylabel('Speedup Factor');
    title('Speedup vs Sequential');
    legend(methodLabels, 'Location', 'best');
    grid on;
    
    % Logarithmic FPS plot
    subplot(2, 3, 3);
    semilogy(fpsMatrix');
    xlabel('Method');
    ylabel('Frame Rate (FPS)');
    title('Frame Rate (Log Scale)');
    set(gca, 'XTickLabel', methodLabels);
    xtickangle(45);
    legend(videoNames, 'Location', 'best');
    grid on;
    
    % Efficiency analysis
    subplot(2, 3, 4);
    if size(fpsMatrix, 2) >= 4
        % GPU vs CPU comparison
        cpuFPS = fpsMatrix(:, 3); % Parallel CPU
        gpuFPS = fpsMatrix(:, 4); % GPU
        
        scatter(cpuFPS, gpuFPS, 100, 'filled');
        xlabel('CPU FPS');
        ylabel('GPU FPS');
        title('GPU vs CPU Performance');
        
        % Add diagonal line
        maxFPS = max([cpuFPS; gpuFPS]);
        line([0, maxFPS], [0, maxFPS], 'Color', 'r', 'LineStyle', '--');
        
        % Add labels
        for i = 1:length(videoNames)
            text(cpuFPS(i), gpuFPS(i), videoNames{i}, 'VerticalAlignment', 'bottom');
        end
        grid on;
    end
    
    % Processing throughput
    subplot(2, 3, 5);
    throughputMatrix = zeros(size(fpsMatrix));
    
    for i = 1:numVideos
        videoName = videoNames{i};
        videoResults = optimisationResults.*(videoName);
        methods = fieldnames(videoResults);
        
        for j = 1:length(methods)
            method = methods{j};
            result = videoResults.*(method);
            throughputMatrix(i, j) = result.pixelsPerSecond / 1e6; % MPix/s
        end
    end
    
    bar(throughputMatrix);
    set(gca, 'XTickLabel', videoNames);
    ylabel('Throughput (MPix/s)');
    title('Processing Throughput');
    legend(methodLabels, 'Location', 'best');
    grid on;
    
    % Relative performance heatmap
    subplot(2, 3, 6);
    % Normalise by best performance for each resolution
    normalisedPerformance = speedupMatrix ./ max(speedupMatrix, [], 2);
    
    imagesc(normalisedPerformance);
    colorbar;
    colormap(hot);
    
    set(gca, 'XTick', 1:length(methodLabels));
    set(gca, 'XTickLabel', methodLabels);
    set(gca, 'YTick', 1:length(videoNames));
    set(gca, 'YTickLabel', videoNames);
    xtickangle(45);
    
    title('Relative Performance Heatmap');
    xlabel('Optimisation Method');
    ylabel('Video Resolution');
    
    % Add text annotations
    for i = 1:numVideos
        for j = 1:length(methodLabels)
            text(j, i, sprintf('%.2f', normalisedPerformance(i, j)), ...
                'HorizontalAlignment', 'center', 'Color', 'white');
        end
    end
    
    sgtitle('Real-time Image Processing Optimisation Results', 'FontSize', 14);
end
