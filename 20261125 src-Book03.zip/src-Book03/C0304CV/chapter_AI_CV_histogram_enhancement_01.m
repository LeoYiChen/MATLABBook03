%% chapter_AI_CV_histogram_enhancement_01.m
% Comprehensive Histogram-Based Enhancement Techniques
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_histogram_enhancement_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Load test images with different contrast characteristics
low_contrast_image = imread('pout.tif');
normal_image = imread('cameraman.tif');

% Convert to double precision for processing
low_contrast_image = im2double(low_contrast_image);
normal_image = im2double(normal_image);

% Apply different histogram-based enhancement techniques
% Standard histogram equalisation
hist_eq_low = histeq(low_contrast_image);
hist_eq_normal = histeq(normal_image);

% Adaptive histogram equalisation (CLAHE)
clahe_low = adapthisteq(low_contrast_image, 'ClipLimit', 0.02, 'NumTiles', [8 8]);
clahe_normal = adapthisteq(normal_image, 'ClipLimit', 0.02, 'NumTiles', [8 8]);

% Custom histogram specification
target_histogram = ones(256, 1) / 256;  % Uniform distribution
custom_enhanced_low = histeq(low_contrast_image, target_histogram);

% Gamma correction for comparison
gamma_low_bright = imadjust(low_contrast_image, [], [], 0.5);
gamma_low_dark = imadjust(low_contrast_image, [], [], 2.0);

% Calculate histogram statistics

% Analyse enhancement effectiveness
original_stats = calculateHistStats(low_contrast_image);
histeq_stats = calculateHistStats(hist_eq_low);
clahe_stats = calculateHistStats(clahe_low);

% Display results with comprehensive analysis
figure;

% Original and enhanced images
subplot(3,4,1); imshow(low_contrast_image); title('Original Low Contrast');
subplot(3,4,2); imshow(hist_eq_low); title('Histogram Equalisation');
subplot(3,4,3); imshow(clahe_low); title('CLAHE');
subplot(3,4,4); imshow(gamma_low_bright); title('Gamma Correction (污=0.5)');

% Corresponding histograms
subplot(3,4,5); imhist(low_contrast_image); title('Original Histogram');
subplot(3,4,6); imhist(hist_eq_low); title('Equalised Histogram');
subplot(3,4,7); imhist(clahe_low); title('CLAHE Histogram');
subplot(3,4,8); imhist(gamma_low_bright); title('Gamma Corrected Histogram');

% Cumulative distribution functions
subplot(3,4,9);
original_cdf = cumsum(imhist(low_contrast_image)) / numel(low_contrast_image);
plot(0:255, original_cdf, 'b-', 'LineWidth', 2);
title('Original CDF'); xlabel('Intensity'); ylabel('Cumulative Probability');

subplot(3,4,10);
histeq_cdf = cumsum(imhist(hist_eq_low)) / numel(hist_eq_low);
plot(0:255, histeq_cdf, 'r-', 'LineWidth', 2);
title('Equalised CDF'); xlabel('Intensity'); ylabel('Cumulative Probability');

subplot(3,4,11);
clahe_cdf = cumsum(imhist(clahe_low)) / numel(clahe_low);
plot(0:255, clahe_cdf, 'g-', 'LineWidth', 2);
title('CLAHE CDF'); xlabel('Intensity'); ylabel('Cumulative Probability');

% Quantitative comparison
subplot(3,4,12);
methods = {'Original', 'Hist Eq', 'CLAHE'};
entropy_values = [original_stats.entropy, histeq_stats.entropy, clahe_stats.entropy];
dynamic_range_values = [original_stats.dynamic_range, histeq_stats.dynamic_range, clahe_stats.dynamic_range];

yyaxis left;
bar(1:3, entropy_values, 'FaceColor', 'blue', 'FaceAlpha', 0.7);
ylabel('Entropy (bits)');
yyaxis right;
bar(1:3, dynamic_range_values, 'FaceColor', 'red', 'FaceAlpha', 0.7);
ylabel('Dynamic Range');
set(gca, 'XTickLabel', methods);
title('Enhancement Metrics');

% Print detailed statistics
fprintf('Enhancement Analysis Results:\n');
fprintf('Method\t\tEntropy\t\tDynamic Range\tEffective Range\n');
fprintf('Original\t%.3f\t\t%.3f\t\t%.3f\n', original_stats.entropy, ...
    original_stats.dynamic_range, original_stats.effective_range);
fprintf('Hist Eq\t\t%.3f\t\t%.3f\t\t%.3f\n', histeq_stats.entropy, ...
    histeq_stats.dynamic_range, histeq_stats.effective_range);
fprintf('CLAHE\t\t%.3f\t\t%.3f\t\t%.3f\n', clahe_stats.entropy, ...
    clahe_stats.dynamic_range, clahe_stats.effective_range);

% Local functions (moved to end so this listing is a valid MATLAB script)
function stats = calculateHistStats(img)
    histogram_data = imhist(img);
    stats.mean = mean(img(:));
    stats.std = std(img(:));
    stats.entropy = entropy(img);
    stats.dynamic_range = max(img(:)) - min(img(:));
    
    % Calculate histogram spread metrics
    cumsum_hist = cumsum(histogram_data) / sum(histogram_data);
    stats.percentile_5 = find(cumsum_hist >= 0.05, 1) / 256;
    stats.percentile_95 = find(cumsum_hist >= 0.95, 1) / 256;
    stats.effective_range = stats.percentile_95 - stats.percentile_5;
end
