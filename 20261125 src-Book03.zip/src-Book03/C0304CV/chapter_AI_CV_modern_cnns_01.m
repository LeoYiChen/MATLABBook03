%% chapter_AI_CV_modern_cnns_01.m
% Modern CNN Architectures Implementation and Comparison
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_modern_cnns_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Comprehensive comparison of modern CNN architectures
% Load CIFAR-10 dataset for architecture comparison
cifar10Data = tempdir;
url = 'https://www.cs.toronto.edu/~kriz/cifar-10-matlab.tar.gz';
% Note: In practice, load local CIFAR-10 data or use built-in datasets

% Create synthetic dataset for demonstration
numClasses = 10;
imageSize = [32, 32, 3];
numTrainImages = 1000;
numValidImages = 200;

% Generate synthetic training data
XTrain = rand([imageSize, numTrainImages], 'single');
YTrain = categorical(randi([1, numClasses], numTrainImages, 1));

% Generate synthetic validation data
XValidation = rand([imageSize, numValidImages], 'single');
YValidation = categorical(randi([1, numClasses], numValidImages, 1));

fprintf('Modern CNN Architectures Comparison\n');
fprintf('===================================\n');

% 1. VGG-style Architecture

% 2. ResNet-style Architecture with Residual Blocks

% 3. DenseNet-style Architecture (simplified)

% 4. MobileNet-style Architecture (depthwise separable convolutions)

% Create all architectures
vgg_net = createVGGStyle(imageSize, numClasses);
resnet_lgraph = createResNetStyle(imageSize, numClasses);
dense_net = createDenseNetStyle(imageSize, numClasses);
mobile_net = createMobileNetStyle(imageSize, numClasses);

% Architecture analysis function

% Analyse all architectures
vgg_stats = analyseArchitecture(vgg_net, 'VGG-Style');
resnet_stats = analyseArchitecture(resnet_lgraph, 'ResNet-Style');
dense_stats = analyseArchitecture(dense_net, 'DenseNet-Style');
mobile_stats = analyseArchitecture(mobile_net, 'MobileNet-Style');

% Training comparison (simplified due to computational constraints)

% Compare architectures (note: ResNet requires special handling due to layer graph)
standard_architectures = {vgg_net, dense_net, mobile_net};
standard_names = {'VGG-Style', 'DenseNet-Style', 'MobileNet-Style'};

compareTrainingEfficiency(standard_architectures, standard_names);

% Architecture evolution timeline
fprintf('\nCNN Architecture Evolution Timeline:\n');
fprintf('====================================\n');
fprintf('1998: LeNet - First successful CNN for digit recognition\n');
fprintf('2012: AlexNet - ImageNet breakthrough, introduced ReLU and dropout\n');
fprintf('2014: VGG - Demonstrated power of depth with small filters\n');
fprintf('2014: GoogLeNet - Introduced inception modules and 1*x1 convolutions\n');
fprintf('2015: ResNet - Solved vanishing gradient with residual connections\n');
fprintf('2016: DenseNet - Dense connections for feature reuse\n');
fprintf('2017: MobileNet - Efficient architectures for mobile deployment\n');
fprintf('2018: EfficientNet - Compound scaling for optimal efficiency\n');
fprintf('2020: Vision Transformer - Attention-based architectures\n');

% Performance characteristics summary
fprintf('\nArchitecture Performance Characteristics:\n');
fprintf('=========================================\n');
fprintf('VGG: Simple, deep, high parameter count\n');
fprintf('ResNet: Very deep, residual connections, moderate parameters\n');
fprintf('DenseNet: Dense connections, feature reuse, parameter efficient\n');
fprintf('MobileNet: Lightweight, mobile-optimised, very efficient\n');

% Local functions (moved to end so this listing is a valid MATLAB script)
function vgg_layers = createVGGStyle(inputSize, numClasses)
    vgg_layers = [
        imageInputLayer(inputSize, 'Name', 'input')
        
        % Block 1
        convolution2dLayer(3, 64, 'Padding', 'same', 'Name', 'conv1_1')
        reluLayer('Name', 'relu1_1')
        convolution2dLayer(3, 64, 'Padding', 'same', 'Name', 'conv1_2')
        reluLayer('Name', 'relu1_2')
        maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool1')
        
        % Block 2
        convolution2dLayer(3, 128, 'Padding', 'same', 'Name', 'conv2_1')
        reluLayer('Name', 'relu2_1')
        convolution2dLayer(3, 128, 'Padding', 'same', 'Name', 'conv2_2')
        reluLayer('Name', 'relu2_2')
        maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool2')
        
        % Block 3
        convolution2dLayer(3, 256, 'Padding', 'same', 'Name', 'conv3_1')
        reluLayer('Name', 'relu3_1')
        convolution2dLayer(3, 256, 'Padding', 'same', 'Name', 'conv3_2')
        reluLayer('Name', 'relu3_2')
        maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool3')
        
        % Classifier
        fullyConnectedLayer(512, 'Name', 'fc1')
        reluLayer('Name', 'relu_fc1')
        dropoutLayer(0.5, 'Name', 'dropout1')
        fullyConnectedLayer(numClasses, 'Name', 'fc2')
        softmaxLayer('Name', 'softmax')
        classificationLayer('Name', 'output')
    ];
end

function resnet_lgraph = createResNetStyle(inputSize, numClasses)
    % Helper function to create residual block
    function block_layers = residualBlock(numFilters, blockName, downsample)
        if nargin < 3
            downsample = false;
        end
        
        if downsample
            stride = 2;
        else
            stride = 1;
        end
        
        block_layers = [
            convolution2dLayer(3, numFilters, 'Padding', 'same', 'Stride', stride, ...
                'Name', [blockName, '_conv1'])
            batchNormalizationLayer('Name', [blockName, '_bn1'])
            reluLayer('Name', [blockName, '_relu1'])
            
            convolution2dLayer(3, numFilters, 'Padding', 'same', ...
                'Name', [blockName, '_conv2'])
            batchNormalizationLayer('Name', [blockName, '_bn2'])
        ];
    end
    
    % Main network
    main_branch = [
        imageInputLayer(inputSize, 'Name', 'input')
        
        % Initial conv
        convolution2dLayer(7, 64, 'Padding', 'same', 'Stride', 2, 'Name', 'conv1')
        batchNormalizationLayer('Name', 'bn1')
        reluLayer('Name', 'relu1')
        maxPooling2dLayer(3, 'Stride', 2, 'Padding', 'same', 'Name', 'pool1')
        
        % Residual blocks (simplified)
        convolution2dLayer(3, 64, 'Padding', 'same', 'Name', 'res2a_conv1')
        batchNormalizationLayer('Name', 'res2a_bn1')
        reluLayer('Name', 'res2a_relu1')
        convolution2dLayer(3, 64, 'Padding', 'same', 'Name', 'res2a_conv2')
        batchNormalizationLayer('Name', 'res2a_bn2')
        
        additionLayer(2, 'Name', 'res2a_add')
        reluLayer('Name', 'res2a_relu2')
        
        % More blocks...
        convolution2dLayer(3, 128, 'Padding', 'same', 'Stride', 2, 'Name', 'res3a_conv1')
        batchNormalizationLayer('Name', 'res3a_bn1')
        reluLayer('Name', 'res3a_relu1')
        convolution2dLayer(3, 128, 'Padding', 'same', 'Name', 'res3a_conv2')
        batchNormalizationLayer('Name', 'res3a_bn2')
        
        % Global average pooling
        globalAveragePooling2dLayer('Name', 'gap')
        fullyConnectedLayer(numClasses, 'Name', 'fc')
        softmaxLayer('Name', 'softmax')
        classificationLayer('Name', 'output')
    ];
    
    % Create layer graph and add skip connections
    resnet_lgraph = layerGraph(main_branch);
    
    % Add skip connection for res2a
    resnet_lgraph = addLayers(resnet_lgraph, [
        convolution2dLayer(1, 64, 'Name', 'res2a_skip')
        batchNormalizationLayer('Name', 'res2a_skip_bn')
    ]);
    
    % Connect skip path
    resnet_lgraph = connectLayers(resnet_lgraph, 'pool1', 'res2a_skip');
    resnet_lgraph = connectLayers(resnet_lgraph, 'res2a_skip_bn', 'res2a_add/in2');
    
    % Add skip connection for res3a (with downsampling)
    resnet_lgraph = addLayers(resnet_lgraph, [
        convolution2dLayer(1, 128, 'Stride', 2, 'Name', 'res3a_skip')
        batchNormalizationLayer('Name', 'res3a_skip_bn')
    ]);
    
    % Connect downsampling skip path
    resnet_lgraph = connectLayers(resnet_lgraph, 'res2a_relu2', 'res3a_skip');
    resnet_lgraph = connectLayers(resnet_lgraph, 'res3a_skip_bn', 'res3a_add/in2');
    
    % Add second addition layer for res3a
    resnet_lgraph = addLayers(resnet_lgraph, [
        additionLayer(2, 'Name', 'res3a_add')
        reluLayer('Name', 'res3a_relu2')
    ]);
    
    % Connect to addition layer
    resnet_lgraph = connectLayers(resnet_lgraph, 'res3a_bn2', 'res3a_add/in1');
    resnet_lgraph = connectLayers(resnet_lgraph, 'res3a_add', 'gap');
end

function dense_layers = createDenseNetStyle(inputSize, numClasses)
    dense_layers = [
        imageInputLayer(inputSize, 'Name', 'input')
        
        % Initial convolution
        convolution2dLayer(7, 64, 'Padding', 'same', 'Stride', 2, 'Name', 'conv1')
        batchNormalizationLayer('Name', 'bn1')
        reluLayer('Name', 'relu1')
        maxPooling2dLayer(3, 'Stride', 2, 'Padding', 'same', 'Name', 'pool1')
        
        % Dense block 1 (simplified)
        batchNormalizationLayer('Name', 'dense1_bn1')
        reluLayer('Name', 'dense1_relu1')
        convolution2dLayer(1, 128, 'Name', 'dense1_conv1') % 1*x1 conv
        batchNormalizationLayer('Name', 'dense1_bn2')
        reluLayer('Name', 'dense1_relu2')
        convolution2dLayer(3, 32, 'Padding', 'same', 'Name', 'dense1_conv2') % 3*x3 conv
        
        % Transition layer
        batchNormalizationLayer('Name', 'trans1_bn')
        reluLayer('Name', 'trans1_relu')
        convolution2dLayer(1, 64, 'Name', 'trans1_conv') % Compression
        averagePooling2dLayer(2, 'Stride', 2, 'Name', 'trans1_pool')
        
        % Final layers
        globalAveragePooling2dLayer('Name', 'gap')
        fullyConnectedLayer(numClasses, 'Name', 'fc')
        softmaxLayer('Name', 'softmax')
        classificationLayer('Name', 'output')
    ];
end

function mobile_layers = createMobileNetStyle(inputSize, numClasses)
    % Helper function for depthwise separable convolution block
    function ds_block = depthwiseSeparableBlock(numFilters, blockName)
        ds_block = [
            % Depthwise convolution (simulated with grouped convolution)
            convolution2dLayer(3, numFilters, 'Padding', 'same', ...
                'Name', [blockName, '_dw'])
            batchNormalizationLayer('Name', [blockName, '_dw_bn'])
            reluLayer('Name', [blockName, '_dw_relu'])
            
            % Pointwise convolution
            convolution2dLayer(1, numFilters, 'Name', [blockName, '_pw'])
            batchNormalizationLayer('Name', [blockName, '_pw_bn'])
            reluLayer('Name', [blockName, '_pw_relu'])
        ];
    end
    
    mobile_layers = [
        imageInputLayer(inputSize, 'Name', 'input')
        
        % Standard convolution
        convolution2dLayer(3, 32, 'Padding', 'same', 'Stride', 2, 'Name', 'conv1')
        batchNormalizationLayer('Name', 'bn1')
        reluLayer('Name', 'relu1')
        
        % Depthwise separable blocks (simplified representation)
        convolution2dLayer(3, 32, 'Padding', 'same', 'Name', 'ds1_dw')
        batchNormalizationLayer('Name', 'ds1_dw_bn')
        reluLayer('Name', 'ds1_dw_relu')
        convolution2dLayer(1, 64, 'Name', 'ds1_pw')
        batchNormalizationLayer('Name', 'ds1_pw_bn')
        reluLayer('Name', 'ds1_pw_relu')
        
        convolution2dLayer(3, 64, 'Padding', 'same', 'Stride', 2, 'Name', 'ds2_dw')
        batchNormalizationLayer('Name', 'ds2_dw_bn')
        reluLayer('Name', 'ds2_dw_relu')
        convolution2dLayer(1, 128, 'Name', 'ds2_pw')
        batchNormalizationLayer('Name', 'ds2_pw_bn')
        reluLayer('Name', 'ds2_pw_relu')
        
        % Global average pooling
        globalAveragePooling2dLayer('Name', 'gap')
        fullyConnectedLayer(numClasses, 'Name', 'fc')
        softmaxLayer('Name', 'softmax')
        classificationLayer('Name', 'output')
    ];
end

function stats = analyseArchitecture(layers_or_lgraph, archName)
    if isa(layers_or_lgraph, 'nnet.cnn.LayerGraph')
        layers = layers_or_lgraph.Layers;
    else
        layers = layers_or_lgraph;
    end
    
    % Count different layer types
    conv_count = sum(arrayfun(@(x) isa(x, 'nnet.cnn.layer.Convolution2DLayer'), layers));
    fc_count = sum(arrayfun(@(x) isa(x, 'nnet.cnn.layer.FullyConnectedLayer'), layers));
    bn_count = sum(arrayfun(@(x) isa(x, 'nnet.cnn.layer.BatchNormalizationLayer'), layers));
    pool_count = sum(arrayfun(@(x) isa(x, 'nnet.cnn.layer.MaxPooling2DLayer') || ...
        isa(x, 'nnet.cnn.layer.AveragePooling2DLayer') || ...
        isa(x, 'nnet.cnn.layer.GlobalAveragePooling2DLayer'), layers));
    
    stats = struct();
    stats.name = archName;
    stats.total_layers = length(layers);
    stats.conv_layers = conv_count;
    stats.fc_layers = fc_count;
    stats.bn_layers = bn_count;
    stats.pool_layers = pool_count;
    
    % Estimate parameters (simplified)
    total_params = 0;
    for i = 1:length(layers)
        layer = layers(i);
        if isa(layer, 'nnet.cnn.layer.Convolution2DLayer')
            % Rough parameter estimation
            if i == 1
                in_channels = imageSize(3);
            else
                in_channels = 64; % Simplified assumption
            end
            filter_params = layer.FilterSize(1) * layer.FilterSize(2) * in_channels * layer.NumFilters;
            bias_params = layer.NumFilters;
            total_params = total_params + filter_params + bias_params;
            
        elseif isa(layer, 'nnet.cnn.layer.FullyConnectedLayer')
            % Simplified FC parameter count
            total_params = total_params + 1000 * layer.OutputSize + layer.OutputSize;
        end
    end
    
    stats.estimated_parameters = total_params;
    
    fprintf('\n%s Architecture:\n', archName);
    fprintf('  Total layers: %d\n', stats.total_layers);
    fprintf('  Convolutional layers: %d\n', stats.conv_layers);
    fprintf('  Fully connected layers: %d\n', stats.fc_layers);
    fprintf('  Batch norm layers: %d\n', stats.bn_layers);
    fprintf('  Pooling layers: %d\n', stats.pool_layers);
    fprintf('  Estimated parameters: %.2e\n', stats.estimated_parameters);
end

function compareTrainingEfficiency(architectures, arch_names)
    fprintf('\nTraining Efficiency Comparison:\n');
    fprintf('===============================\n');
    
    training_times = [];
    memory_usage = [];
    
    options = trainingOptions('adam', ...
        'InitialLearnRate', 0.001, ...
        'MaxEpochs', 5, ... % Reduced for comparison
        'MiniBatchSize', 32, ...
        'Verbose', false, ...
        'ExecutionEnvironment', 'auto');
    
    for i = 1:length(architectures)
        fprintf('Testing %s...\n', arch_names{i});
        
        try
            tic;
            if isa(architectures{i}, 'nnet.cnn.LayerGraph')
                net = trainNetwork(XTrain, YTrain, architectures{i}, options);
            else
                net = trainNetwork(XTrain, YTrain, architectures{i}, options);
            end
            training_time = toc;
            training_times(i) = training_time;
            
            % Estimate memory usage (simplified)
            info = whos('net');
            memory_usage(i) = info.bytes;
            
            fprintf('  Training time: %.2f seconds\n', training_time);
            fprintf('  Model size: %.2f MB\n', memory_usage(i) / 1024^2);
            
        catch ME
            fprintf('  Error training %s: %s\n', arch_names{i}, ME.message);
            training_times(i) = NaN;
            memory_usage(i) = NaN;
        end
    end
    
    % Plot comparison
    figure;
    subplot(1, 2, 1);
    valid_times = ~isnan(training_times);
    bar(find(valid_times), training_times(valid_times));
    title('Training Time Comparison');
    ylabel('Time (seconds)');
    set(gca, 'XTickLabel', arch_names(valid_times));
    
    subplot(1, 2, 2);
    valid_memory = ~isnan(memory_usage);
    bar(find(valid_memory), memory_usage(valid_memory) / 1024^2);
    title('Model Size Comparison');
    ylabel('Size (MB)');
    set(gca, 'XTickLabel', arch_names(valid_memory));
end
