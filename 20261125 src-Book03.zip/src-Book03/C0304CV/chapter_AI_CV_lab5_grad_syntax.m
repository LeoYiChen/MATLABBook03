%% chapter_AI_CV_lab5_grad_syntax.m
% Gradient-based explanation syntax.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_lab5_grad_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Compute gradient for explanation
[loss, gradient] = computeModelGradient(model, input, target);

% Generate integrated gradients
baseline = zeros(size(input));
explanation = integratedGradients(model, input, baseline, target);
