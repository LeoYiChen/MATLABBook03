%% chapter_AI_CV_adaptive_filtering_01.m
% Adaptive Filtering Techniques Demonstration
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_adaptive_filtering_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Load test image with mixed content (smooth and textured regions)
test_image = imread('fabric.png');
test_image = im2double(test_image);

% Add varying levels of noise to different regions
noisy_image = imnoise(test_image, 'gaussian', 0, 0.01);

% Apply Wiener filtering with automatic noise estimation
wiener_filtered = wiener2(noisy_image, [5 5]);

% Implement edge-preserving adaptive filter

% Apply custom edge-preserving filter
edge_preserving_filtered = edgePreservingFilter(noisy_image, 5, 0.1);

% Bilateral filtering implementation (edge-preserving)

% Apply bilateral filtering
bilateral_filtered = simpleBilateralFilter(noisy_image, 2.0, 0.1);

% Calculate quality metrics
psnr_wiener = psnr(wiener_filtered, test_image);
psnr_edge_preserving = psnr(edge_preserving_filtered, test_image);
psnr_bilateral = psnr(bilateral_filtered, test_image);

% Calculate edge preservation metrics
edge_original = edge(test_image, 'canny');
edge_wiener = edge(wiener_filtered, 'canny');
edge_preserving_edges = edge(edge_preserving_filtered, 'canny');
edge_bilateral = edge(bilateral_filtered, 'canny');

% Display comprehensive results
figure;
subplot(2,4,1); imshow(test_image); title('Original Image');
subplot(2,4,2); imshow(noisy_image); title('Noisy Image');
subplot(2,4,3); imshow(wiener_filtered); 
title(sprintf('Wiener Filter\nPSNR: %.2f dB', psnr_wiener));
subplot(2,4,4); imshow(edge_preserving_filtered);
title(sprintf('Edge-Preserving\nPSNR: %.2f dB', psnr_edge_preserving));

subplot(2,4,5); imshow(bilateral_filtered);
title(sprintf('Bilateral Filter\nPSNR: %.2f dB', psnr_bilateral));
subplot(2,4,6); imshow(edge_original); title('Original Edges');
subplot(2,4,7); imshow(edge_wiener); title('Wiener Edges');
subplot(2,4,8); imshow(edge_bilateral); title('Bilateral Edges');

% Quantitative edge preservation analysis
fprintf('Edge Preservation Analysis:\n');
edge_preservation_wiener = sum(edge_wiener(:) & edge_original(:)) / sum(edge_original(:));
edge_preservation_bilateral = sum(edge_bilateral(:) & edge_original(:)) / sum(edge_original(:));

fprintf('Wiener edge preservation: %.3f\n', edge_preservation_wiener);
fprintf('Bilateral edge preservation: %.3f\n', edge_preservation_bilateral);

% Local functions (moved to end so this listing is a valid MATLAB script)
function filtered_img = edgePreservingFilter(img, window_size, threshold)
    filtered_img = img;
    [rows, cols] = size(img);
    half_window = floor(window_size / 2);
    
    for i = half_window+1:rows-half_window
        for j = half_window+1:cols-half_window
            % Extract local window
            window = img(i-half_window:i+half_window, ...
                        j-half_window:j+half_window);
            
            % Calculate local gradient magnitude
            [Gx, Gy] = gradient(window);
            gradient_mag = sqrt(Gx.^2 + Gy.^2);
            max_gradient = max(gradient_mag(:));
            
            % Adaptive filtering based on local edge strength
            if max_gradient < threshold
                % Smooth region: apply strong filtering
                filtered_img(i,j) = mean(window(:));
            else
                % Edge region: apply minimal filtering
                center_idx = ceil(window_size/2);
                filtered_img(i,j) = 0.7 * window(center_idx, center_idx) + ...
                                   0.3 * mean(window(:));
            end
        end
    end
end

function bilateral_img = simpleBilateralFilter(img, sigma_spatial, sigma_intensity)
    bilateral_img = zeros(size(img));
    [rows, cols] = size(img);
    window_size = 2 * ceil(3 * sigma_spatial) + 1;
    half_window = floor(window_size / 2);
    
    % Pre-compute spatial weights
    [X, Y] = meshgrid(-half_window:half_window, -half_window:half_window);
    spatial_weights = exp(-(X.^2 + Y.^2) / (2 * sigma_spatial^2));
    
    for i = half_window+1:rows-half_window
        for j = half_window+1:cols-half_window
            % Extract local window
            window = img(i-half_window:i+half_window, ...
                        j-half_window:j+half_window);
            center_pixel = img(i, j);
            
            % Calculate intensity weights
            intensity_diff = window - center_pixel;
            intensity_weights = exp(-(intensity_diff.^2) / (2 * sigma_intensity^2));
            
            % Combine spatial and intensity weights
            combined_weights = spatial_weights .* intensity_weights;
            combined_weights = combined_weights / sum(combined_weights(:));
            
            % Apply weighted average
            bilateral_img(i, j) = sum(sum(window .* combined_weights));
        end
    end
end
