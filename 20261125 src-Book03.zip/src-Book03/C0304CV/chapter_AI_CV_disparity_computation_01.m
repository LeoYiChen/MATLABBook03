%% chapter_AI_CV_disparity_computation_01.m
% Advanced Disparity Map Computation and Analysis
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0304CV/
% Listing label         : chapter_AI_CV_disparity_computation_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Comprehensive Disparity Map Computation and Analysis
fprintf('Disparity Map Computation: From Stereo Pairs to 3*D Understanding\n');
fprintf('================================================================\n');

% Load stereo image pair (using synthetic data for demonstration)
imageSize = [480, 640, 3];
[leftImage, rightImage, groundTruthDisparity] = createAdvancedStereoScene(imageSize);


% Convert to grayscale for disparity computation
leftGray = rgb2gray(leftImage);
rightGray = rgb2gray(rightImage);

% 1. Block Matching Algorithm

% 2. Semi-Global Matching (SGM) - Simplified implementation



% 3. Compute disparity maps using different methods
blockSize = 11;
maxDisparity = 64;

% Block Matching
disparityBM = blockMatchingDisparity(leftGray, rightGray, blockSize, maxDisparity);

% Semi-Global Matching (simplified)
P1 = 8; % Penalty for small disparity changes
P2 = 32; % Penalty for large disparity changes
disparitySGM = semiGlobalMatching(leftGray, rightGray, maxDisparity, P1, P2);

% Post-processing: Left-Right Consistency Check

% Apply consistency check (would require computing right-to-left disparity)
% For demonstration, apply simple filtering
disparityBM_filtered = medfilt2(disparityBM, [3, 3]); % Median filtering
disparitySGM_filtered = medfilt2(disparitySGM, [3, 3]);

% Convert disparity to depth
focal_length = 800; % pixels
baseline = 100; % mm


depthBM = disparityToDepth(disparityBM_filtered, focal_length, baseline);
depthSGM = disparityToDepth(disparitySGM_filtered, focal_length, baseline);
groundTruthDepth = disparityToDepth(groundTruthDisparity, focal_length, baseline);

% Evaluation metrics

metricsBM = evaluateDisparityMaps(disparityBM_filtered, groundTruthDisparity, maxDisparity);
metricsSGM = evaluateDisparityMaps(disparitySGM_filtered, groundTruthDisparity, maxDisparity);

fprintf('\nDisparity Map Evaluation:\n');
fprintf('=========================\n');
fprintf('Block Matching:\n');
fprintf(' MAE: %.2f pixels\n', metricsBM.mae);
fprintf(' RMSE: %.2f pixels\n', metricsBM.rmse);
fprintf(' Bad pixels (>1*px error): %.1f%%\n', metricsBM.bad_pixels * 100);

fprintf('Semi-Global Matching:\n');
fprintf(' MAE: %.2f pixels\n', metricsSGM.mae);
fprintf(' RMSE: %.2f pixels\n', metricsSGM.rmse);
fprintf(' Bad pixels (>1*px error): %.1f%%\n', metricsSGM.bad_pixels * 100);

% Visualize results
figure;

subplot(3, 4, 1);
imshow(leftImage);
title('Left Image');

subplot(3, 4, 2);
imshow(rightImage);
title('Right Image');

subplot(3, 4, 3);
imshow(groundTruthDisparity, []);
colormap(gca, 'jet');
colorbar;
title('Ground Truth Disparity');

subplot(3, 4, 4);
imshow(groundTruthDepth, []);
colormap(gca, 'jet');
colorbar;
title('Ground Truth Depth (mm)');

subplot(3, 4, 5);
imshow(disparityBM, []);
colormap(gca, 'jet');
colorbar;
title('Block Matching Disparity');

subplot(3, 4, 6);
imshow(disparityBM_filtered, []);
colormap(gca, 'jet');
colorbar;
title('BM Disparity (Filtered)');

subplot(3, 4, 7);
imshow(disparitySGM, []);
colormap(gca, 'jet');
colorbar;
title('SGM Disparity');

subplot(3, 4, 8);
imshow(disparitySGM_filtered, []);
colormap(gca, 'jet');
colorbar;
title('SGM Disparity (Filtered)');

subplot(3, 4, 9);
imshow(depthBM, []);
colormap(gca, 'jet');
colorbar;
title('BM Depth Map (mm)');

subplot(3, 4, 10);
imshow(depthSGM, []);
colormap(gca, 'jet');
colorbar;
title('SGM Depth Map (mm)');

% Error maps
errorBM = abs(disparityBM_filtered - groundTruthDisparity);
errorSGM = abs(disparitySGM_filtered - groundTruthDisparity);

subplot(3, 4, 11);
imshow(errorBM, []);
colormap(gca, 'hot');
colorbar;
title('BM Error Map');

subplot(3, 4, 12);
imshow(errorSGM, []);
colormap(gca, 'hot');
colorbar;
title('SGM Error Map');

% 3*D point cloud reconstruction

% Reconstruct 3*D point cloud
Q = [1, 0, 0, -320; % Q matrix for disparity-to-depth conversion
0, 1, 0, -240;
0, 0, 0, 800;
0, 0, -1/100, 0];

pointCloudBM = reconstructPointCloud(disparityBM_filtered, Q, leftImage);
pointCloudSGM = reconstructPointCloud(disparitySGM_filtered, Q, leftImage);

fprintf('\n3D Point Cloud Statistics:\n');
fprintf('==========================\n');
fprintf('Block Matching Point Cloud:\n');
fprintf(' Number of points: %d\n', size(pointCloudBM.points, 1));
fprintf(' Depth range: %.1f - %.1f mm\n', min(pointCloudBM.points(:, 3)), max(pointCloudBM.points(:, 3)));

fprintf('Semi-Global Matching Point Cloud:\n');
fprintf(' Number of points: %d\n', size(pointCloudSGM.points, 1));
fprintf(' Depth range: %.1f - %.1f mm\n', min(pointCloudSGM.points(:, 3)), max(pointCloudSGM.points(:, 3)));

% Algorithm comparison and recommendations
fprintf('\nDisparity Algorithm Comparison:\n');
fprintf('===============================\n');
fprintf('Block Matching:\n');
fprintf(' + Simple and fast\n');
fprintf(' + Good for textured regions\n');
fprintf(' - Poor in textureless areas\n');
fprintf(' - Sensitive to noise\n');
fprintf(' - Limited global consistency\n');

fprintf('\nSemi-Global Matching:\n');
fprintf(' + Better global consistency\n');
fprintf(' + Handles textureless regions better\n');
fprintf(' + More robust to noise\n');
fprintf(' - More computationally intensive\n');
fprintf(' - Requires parameter tuning\n');

fprintf('\nAdvanced Techniques:\n');
fprintf(' - Graph cuts for global optimization\n');
fprintf(' - Belief propagation for probabilistic inference\n');
fprintf(' - CNN-based matching for learned features\n');
fprintf(' - Multi-scale processing for efficiency\n');
fprintf(' - Temporal consistency for video sequences\n');

% Performance optimization tips
fprintf('\nPerformance Optimization:\n');
fprintf('=========================\n');
fprintf('1. Use image pyramids for multi-scale matching\n');
fprintf('2. Implement early termination in matching loops\n');
fprintf('3. Utilize parallel processing for independent computations\n');
fprintf('4. Apply region-of-interest processing when possible\n');
fprintf('5. Consider hardware acceleration (GPU, FPGA)\n');
fprintf('6. Optimize memory access patterns for cache efficiency\n');
fprintf('7. Use look-up tables for expensive operations\n');
fprintf('8. Implement adaptive algorithms based on scene content\n');

% Local functions (moved to end so this listing is a valid MATLAB script)
function [leftImg, rightImg, gtDisparity] = createAdvancedStereoScene(imageSize)
% Create more complex synthetic stereo scene with various depth cues

 
leftImg = zeros(imageSize, 'uint8');
rightImg = zeros(imageSize, 'uint8');
gtDisparity = zeros(imageSize(1), imageSize(2));

% Camera parameters
focal_length = 800; % pixels
baseline = 100; % mm

% Create layered scene with different textures and depths
% Background with texture
background_texture = uint8(rand(imageSize(1), imageSize(2)) * 50 + 50);
for c = 1:3
    leftImg(:, :, c) = background_texture;
end
gtDisparity(:, :) = (focal_length * baseline) / 2000; % 2000*mm depth

% Add geometric objects at different depths
objects = [
    struct('type', 'rectangle', 'pos', [100, 100, 150, 100], 'depth', 800, 'color', [200, 100, 50]);
    struct('type', 'circle', 'pos', [400, 200, 60], 'depth', 600, 'color', [50, 200, 100]);
    struct('type', 'ellipse', 'pos', [300, 350, 80, 40], 'depth', 1200, 'color', [100, 50, 200]);
    struct('type', 'triangle', 'pos', [500, 100, 70], 'depth', 400, 'color', [200, 200, 50]);
];

for obj = objects
    disparity_val = (focal_length * baseline) / obj.depth;
    
    switch obj.type
        case 'rectangle'
            [x_start, y_start, width, height] = deal(obj.pos(1), obj.pos(2), obj.pos(3), obj.pos(4));
            x_range = x_start:(x_start + width - 1);
            y_range = y_start:(y_start + height - 1);
            
            % Ensure coordinates are within image bounds
            x_range = x_range(x_range >= 1 & x_range <= imageSize(2));
            y_range = y_range(y_range >= 1 & y_range <= imageSize(1));
            
            if ~isempty(x_range) && ~isempty(y_range)
                % Add texture to rectangle
                texture = uint8(rand(length(y_range), length(x_range)) * 50);
                for c = 1:3
                    channel = leftImg(:, :, c);
                    channel(y_range, x_range) = uint8(obj.color(c)) + texture;
                    leftImg(:, :, c) = channel;
                end
                gtDisparity(y_range, x_range) = disparity_val;
            end
            
        case 'circle'
            [center_x, center_y, radius] = deal(obj.pos(1), obj.pos(2), obj.pos(3));
            [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
            mask = (X - center_x).^2 + (Y - center_y).^2 <= radius^2;
            
            % Add radial texture pattern
            distances = sqrt((X - center_x).^2 + (Y - center_y).^2);
            texture = uint8(50 * sin(distances / 10));
            
            for c = 1:3
                channel = leftImg(:, :, c);
                channel(mask) = uint8(obj.color(c)) + texture(mask);
                leftImg(:, :, c) = channel;
            end
            gtDisparity(mask) = disparity_val;
            
        case 'ellipse'
            [center_x, center_y, a, b] = deal(obj.pos(1), obj.pos(2), obj.pos(3), obj.pos(4));
            [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
            mask = ((X - center_x) / a).^2 + ((Y - center_y) / b).^2 <= 1;
            
            for c = 1:3
                channel = leftImg(:, :, c);
                channel(mask) = obj.color(c);
                leftImg(:, :, c) = channel;
            end
            gtDisparity(mask) = disparity_val;
            
        case 'triangle'
            % Simplified triangle (using circular approximation for this demo)
            [center_x, center_y, size_val] = deal(obj.pos(1), obj.pos(2), obj.pos(3));
            [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
            
            % Create triangular region (simplified)
            mask = (X - center_x).^2 + (Y - center_y).^2 <= size_val^2 & ...
                   Y >= center_y - size_val/2;
            
            for c = 1:3
                channel = leftImg(:, :, c);
                channel(mask) = obj.color(c);
                leftImg(:, :, c) = channel;
            end
            gtDisparity(mask) = disparity_val;
    end
end

% Generate right image by shifting left image according to disparity
rightImg = leftImg; % Initialize

for y = 1:imageSize(1)
    for x = 1:imageSize(2)
        disparity = gtDisparity(y, x);
        x_shifted = round(x - disparity);
        
        if x_shifted >= 1 && x_shifted <= imageSize(2)
            rightImg(y, x_shifted, :) = leftImg(y, x, :);
        end
    end
end

% Fill occlusions in right image
for y = 1:imageSize(1)
    for x = 1:imageSize(2)
        if all(rightImg(y, x, :) == 0)
            % Simple occlusion filling
            if x > 1
                rightImg(y, x, :) = rightImg(y, x-1, :);
            else
                rightImg(y, x, :) = leftImg(y, x, :);
            end
        end
    end
end
end

function disparityMap = blockMatchingDisparity(leftImg, rightImg, blockSize, maxDisparity)
fprintf('Computing disparity using Block Matching...\n');

 
[height, width] = size(leftImg);
disparityMap = zeros(height, width);
halfBlock = floor(blockSize / 2);

% Convert to double for computation
leftImg = double(leftImg);
rightImg = double(rightImg);

for y = (halfBlock + 1):(height - halfBlock)
    for x = (halfBlock + 1):(width - halfBlock)
        % Extract template from left image
        template = leftImg((y-halfBlock):(y+halfBlock), (x-halfBlock):(x+halfBlock));
        
        best_disparity = 0;
        best_score = inf;
        
        % Search along epipolar line in right image
        search_start = max(halfBlock + 1, x - maxDisparity);
        search_end = min(width - halfBlock, x);
        
        for x_right = search_start:search_end
            % Extract candidate block from right image
            candidate = rightImg((y-halfBlock):(y+halfBlock), (x_right-halfBlock):(x_right+halfBlock));
            
            % Compute Sum of Absolute Differences (SAD)
            sad = sum(abs(template(:) - candidate(:)));
            
            if sad < best_score
                best_score = sad;
                best_disparity = x - x_right;
            end
        end
        
        disparityMap(y, x) = best_disparity;
    end
end

fprintf('Block matching completed\n');
end

function disparityMap = semiGlobalMatching(leftImg, rightImg, maxDisparity, P1, P2)
fprintf('Computing disparity using Semi-Global Matching...\n');

 
[height, width] = size(leftImg);

% Convert to double
leftImg = double(leftImg);
rightImg = double(rightImg);

% Compute cost volume
costVolume = computeCostVolume(leftImg, rightImg, maxDisparity);

% Aggregate costs along multiple paths
directions = [0, 1; 1, 0; 0, -1; -1, 0; 1, 1; 1, -1; -1, 1; -1, -1]; % 8 directions
aggregatedCosts = zeros(size(costVolume));

for dir = 1:size(directions, 1)
    pathCosts = computePathCosts(costVolume, directions(dir, :), P1, P2);
    aggregatedCosts = aggregatedCosts + pathCosts;
end

% Winner-takes-all disparity selection
[~, disparityIndices] = min(aggregatedCosts, [], 3);
disparityMap = disparityIndices - 1; % Convert to 0-based disparity

fprintf('Semi-global matching completed\n');
end

function costVolume = computeCostVolume(leftImg, rightImg, maxDisparity)
[height, width] = size(leftImg);
costVolume = zeros(height, width, maxDisparity + 1);

 
for d = 0:maxDisparity
    for y = 1:height
        for x = 1:width
            x_right = x - d;
            if x_right >= 1 && x_right <= width
                % Compute matching cost (absolute difference)
                cost = abs(leftImg(y, x) - rightImg(y, x_right));
            else
                cost = 255; % High cost for invalid correspondences
            end
            costVolume(y, x, d + 1) = cost;
        end
    end
end
end

function pathCosts = computePathCosts(costVolume, direction, P1, P2)
[height, width, numDisparities] = size(costVolume);
pathCosts = zeros(size(costVolume));

 
% Initialize first row/column
if direction(1) == 0 && direction(2) == 1 % Horizontal right
    pathCosts(:, 1, :) = costVolume(:, 1, :);
    
    for x = 2:width
        for y = 1:height
            for d = 1:numDisparities
                % Current pixel cost
                pixelCost = costVolume(y, x, d);
                
                % Previous costs
                prevCosts = squeeze(pathCosts(y, x-1, :));
                
                % Compute aggregation costs
                minPrevCost = min(prevCosts);
                
                % Same disparity
                cost1 = prevCosts(d);
                
                % Adjacent disparities
                cost2 = inf;
                cost3 = inf;
                if d > 1
                    cost2 = prevCosts(d-1) + P1;
                end
                if d < numDisparities
                    cost3 = prevCosts(d+1) + P1;
                end
                
                % All other disparities
                cost4 = minPrevCost + P2;
                
                aggregatedCost = pixelCost + min([cost1, cost2, cost3, cost4]) - minPrevCost;
                pathCosts(y, x, d) = aggregatedCost;
            end
        end
    end
else
    % For other directions, use similar logic (simplified here)
    pathCosts = costVolume;
end
end

function disparityFiltered = leftRightConsistencyCheck(disparityLeft, disparityRight, threshold)
disparityFiltered = disparityLeft;
[height, width] = size(disparityLeft);

 
for y = 1:height
    for x = 1:width
        disparity = disparityLeft(y, x);
        x_right = round(x - disparity);
        
        if x_right >= 1 && x_right <= width
            disparityRight_val = disparityRight(y, x_right);
            
            % Check consistency
            if abs(disparity - disparityRight_val) > threshold
                disparityFiltered(y, x) = 0; % Mark as invalid
            end
        else
            disparityFiltered(y, x) = 0;
        end
    end
end
end

function depthMap = disparityToDepth(disparityMap, focalLength, baseline)
depthMap = zeros(size(disparityMap));
validMask = disparityMap > 0;
depthMap(validMask) = (focalLength * baseline) ./ disparityMap(validMask);
depthMap(~validMask) = 0; % Invalid depth
end

function metrics = evaluateDisparityMaps(computed, groundTruth, maxDisparity)
% Remove invalid regions
validMask = groundTruth > 0 & groundTruth <= maxDisparity;

 
if sum(validMask(:)) == 0
    metrics = struct('mae', inf, 'rmse', inf, 'bad_pixels', 1.0);
    return;
end

computedValid = computed(validMask);
groundTruthValid = groundTruth(validMask);

% Mean Absolute Error
mae = mean(abs(computedValid - groundTruthValid));

% Root Mean Square Error
rmse = sqrt(mean((computedValid - groundTruthValid).^2));

% Bad pixels (error > threshold)
threshold = 1.0; % pixels
badPixels = sum(abs(computedValid - groundTruthValid) > threshold) / length(computedValid);

metrics = struct('mae', mae, 'rmse', rmse, 'bad_pixels', badPixels);
end

function pointCloud = reconstructPointCloud(disparityMap, Q, leftImage)
[height, width] = size(disparityMap);
validMask = disparityMap > 0;

 
% Create coordinate matrices
[u, v] = meshgrid(1:width, 1:height);

% Homogeneous image coordinates
imagePoints = [u(validMask), v(validMask), disparityMap(validMask), ones(sum(validMask(:)), 1)]';

% Transform to 3*D coordinates using Q matrix
worldPoints = Q * imagePoints;
worldPoints = worldPoints ./ worldPoints(4, :); % Normalize by W

% Get corresponding colors
colors = reshape(leftImage, [], 3);
validIndices = find(validMask);
pointColors = colors(validIndices, :);

pointCloud = struct();
pointCloud.points = worldPoints(1:3, :)';
pointCloud.colors = double(pointColors) / 255;
end
