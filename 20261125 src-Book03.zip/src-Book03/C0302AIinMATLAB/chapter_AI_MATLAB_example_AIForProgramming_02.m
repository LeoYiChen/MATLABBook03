%% chapter_AI_MATLAB_example_AIForProgramming_02.m
% Unit test suite for validating AI-assisted geometric properties function.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_example_AIForProgramming_02
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
classdef TestGeometricProperties < matlab.unittest.TestCase
    % TESTGEOMETRICPROPERTIES Unit tests for calculateGeometricProperties
    
    methods (Test)
        
        
        
        
    end
end

% Local functions (moved to end so this listing is a valid MATLAB script)
        function testCircleProperties(testCase)
            % Verify circle calculations with known radius
            props = calculateGeometricProperties('circle', 5);
            testCase.verifyEqual(props.area, pi * 25, 'RelTol', 1e-10);
            testCase.verifyEqual(props.perimeter, 10 * pi, 'RelTol', 1e-10);
        end

        function testRectangleProperties(testCase)
            % Verify rectangle calculations
            props = calculateGeometricProperties('rectangle', [4, 3]);
            testCase.verifyEqual(props.area, 12);
            testCase.verifyEqual(props.perimeter, 14);
        end

        function testInvalidShapeError(testCase)
            % Verify error thrown for invalid shape
            testCase.verifyError(@() calculateGeometricProperties('hexagon', 5), ...
                'calculateGeometricProperties:InvalidShape');
        end

        function testInvalidParameterCount(testCase)
            % Verify error for incorrect parameter count
            testCase.verifyError(@() calculateGeometricProperties('rectangle', 5), ...
                'calculateGeometricProperties:InvalidParameterCount');
        end

        function testNegativeParameterError(testCase)
            % Verify error for negative parameters
            testCase.verifyError(@() calculateGeometricProperties('circle', -5), ...
                'MATLAB:validateattributes:expectedPositive');
        end
