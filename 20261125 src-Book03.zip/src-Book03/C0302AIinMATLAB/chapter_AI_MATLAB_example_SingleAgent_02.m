%% chapter_AI_MATLAB_example_SingleAgent_02.m
% Instantiation and usage of the IntelligentAgent class. The example demonstrates agent creation, message processing, action selection, and status reporting.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_example_SingleAgent_02
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Define agent configuration
config.stateDimension  = 10;  % 10-dimensional observation space
config.actionDimension = 4;   % 4 possible actions

% Create the agent
agent = IntelligentAgent("Agent_Alpha", config);

% Register an event listener for incoming messages
addlistener(agent, 'MessageReceived', @(src, evt) ...
    fprintf('  [Listener] Agent %s received a message.\n', src.AgentID));

% Send an inform-type message to update the knowledge base
informMsg = struct('sender', 'Supervisor', ...
                   'type', 'inform', ...
                   'content', struct('key', 'targetTemperature', ...
                                     'value', 72.5));
resp1 = agent.processMessage(informMsg);
fprintf('Inform response: %s\n', resp1.status);

% Send a query message to retrieve the stored value
queryMsg = struct('sender', 'Monitor', ...
                  'type', 'query', ...
                  'content', struct('key', 'targetTemperature'));
resp2 = agent.processMessage(queryMsg);
fprintf('Query response: %s, value = %.1f\n', ...
        resp2.status, resp2.data);

% Simulate action selection from a random observation
observation = randn(1, config.stateDimension);
[action, probs] = agent.selectAction(observation);
fprintf('Selected action: %d (probabilities: %s)\n', ...
        action, mat2str(probs, 3));

% Generate and display a status report
report = agent.generateStatusReport();
fprintf('Status report (JSON):\n%s\n', report.jsonRepresentation);
