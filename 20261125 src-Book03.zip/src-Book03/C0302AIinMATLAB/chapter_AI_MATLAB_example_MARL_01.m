%% chapter_AI_MATLAB_example_MARL_01.m
% Schematic configuration of a multi-agent reinforcement learning scenario using the MATLAB Reinforcement Learning Toolbox. Two PPO agents are created with separate observation and action specifications, and multi-agent training options are configured for simultaneous policy optimisation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_example_MARL_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Define observation and action specifications for two agents
obsInfo1 = rlNumericSpec([8 1], 'LowerLimit', -inf, 'UpperLimit', inf);
obsInfo2 = rlNumericSpec([6 1], 'LowerLimit', -inf, 'UpperLimit', inf);
actInfo1 = rlFiniteSetSpec([1 2 3 4]);   % Discrete actions
actInfo2 = rlNumericSpec([2 1], 'LowerLimit', -1, 'UpperLimit', 1);

% Create PPO agents with default network architectures
agent1 = rlPPOAgent(obsInfo1, actInfo1);
agent2 = rlPPOAgent(obsInfo2, actInfo2);

% Configure multi-agent training options
trainOpts = rlMultiAgentTrainingOptions( ...
    'MaxEpisodes', 1000, ...
    'MaxStepsPerEpisode', 500, ...
    'ScoreAveragingWindowLength', 50, ...
    'StopTrainingCriteria', 'AverageReward', ...
    'StopTrainingValue', 200);

% Note: A multi-agent environment must be defined that returns
% observations, rewards, and termination signals for each agent.
% The environment can be a custom MATLAB function or Simulink model.
%
% Example (schematic):
% env = rlFunctionEnv(multiObsInfo, multiActInfo, stepFcn, resetFcn);
% trainingResult = train([agent1, agent2], env, trainOpts);
