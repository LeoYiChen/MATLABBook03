%% chapter_AI_MATLAB_Lab01_step06.m
% Analysis Agent function for evaluating design compliance against constraints.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_Lab01_step06
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function analysisResults = evaluateDesignCompliance( ...
        simResults, design, constraints)
    % evaluateDesignCompliance - Assess whether a beam design meets
    % the engineering constraints.
    %
    % Inputs:
    %   simResults  - simulation results struct
    %   design      - beam design struct
    %   constraints - engineering constraints struct
    %
    % Output:
    %   analysisResults - struct containing compliance assessment
    %
    % Author: Dr Yi Chen
    % Date:   2025
    % MATLAB: R2024b
    
    % Deflection compliance
    analysisResults.deflectionRatio = ...
        simResults.maxDeflection / constraints.maxDeflection;
    analysisResults.deflectionPass = ...
        analysisResults.deflectionRatio <= 1.0;
    
    % Stress compliance
    analysisResults.stressRatio = ...
        simResults.maxStress / constraints.allowableStress;
    analysisResults.stressPass = analysisResults.stressRatio <= 1.0;
    
    % Overall compliance
    analysisResults.allConstraintsMet = ...
        analysisResults.deflectionPass && analysisResults.stressPass;
    
    % Overall utilisation (governing constraint)
    analysisResults.overallUtilisation = ...
        max(analysisResults.deflectionRatio, ...
            analysisResults.stressRatio);
    
    % Determine governing constraint
    if analysisResults.deflectionRatio >= analysisResults.stressRatio
        analysisResults.governingConstraint = "deflection";
    else
        analysisResults.governingConstraint = "stress";
    end
    
    % Current mass for tracking
    analysisResults.currentMass = design.mass;
    
    % Optimality check
    utilisationTarget = constraints.utilisationTarget;
    analysisResults.isOptimal = analysisResults.allConstraintsMet && ...
        (analysisResults.overallUtilisation >= utilisationTarget);
    
    % Determine design verdict
    if ~analysisResults.allConstraintsMet
        analysisResults.designVerdict = "FAIL";
    elseif analysisResults.isOptimal
        analysisResults.designVerdict = "OPTIMAL";
    else
        analysisResults.designVerdict = "PASS (under-utilised)";
    end
    
    analysisResults.timestamp = datetime('now');
end
