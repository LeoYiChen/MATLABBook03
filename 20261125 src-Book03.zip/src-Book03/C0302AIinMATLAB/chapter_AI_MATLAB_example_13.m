%% chapter_AI_MATLAB_example_13.m
% Integrating MATLAB with OpenAI's GPT Models
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_example_13
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Set up OpenAI API connection
oai = openai;

% Define a MATLAB-related prompt
prompt = "Generate MATLAB code to create a scatter plot of random data with a trend line";

% Generate a response
response = generate(oai, prompt);

% Display the response
disp(response)

% Extract and execute code from the response
codeBlock = extractBetween(response, "```matlab", "```");
if ~isempty(codeBlock)
    % Remove the language marker if present
    code = strrep(codeBlock{1}, "matlab", "");
    % Execute the generated code
    eval(code);
end
