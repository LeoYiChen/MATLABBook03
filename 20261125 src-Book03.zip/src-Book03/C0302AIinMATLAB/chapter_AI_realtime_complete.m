%% chapter_AI_realtime_complete.m
% Real-time predictive analytics system.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_realtime_complete
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
classdef RealTimePredictiveSystem < handle
    % Real-Time Predictive Analytics System
    % Author: Dr Yi Chen
    % Version: 1.0
    
    properties
        dataBuffer
        predictionModel
        performanceMonitor
        adaptationEngine
        streamProcessor
        ensembleModels
        isRunning
        configuration
    end
    
    methods
        
        
        
        
        
        
        
        
        
        
        
        
    end
end

classdef CircularBuffer < handle
    properties
        data
        capacity
        size
        headIndex
        tailIndex
    end
    
    methods
        
        
        
    end
end

classdef EnsemblePredictionModel < handle
    properties
        baseModels
        modelWeights
        ensembleMethod
        isTrained
        trainingHistory
        performanceMetrics
    end
    
    methods
        
        
        
        
        
        
        
    end
end

classdef RealTimePerformanceMonitor < handle
    properties
        predictionHistory
        latencyHistory
        accuracyHistory
        startTime
    end
    
    methods
        
        
        
        
        
        
        
    end
end

classdef ModelAdaptationEngine < handle
    properties
        adaptationConfig
        adaptationHistory
        performanceThreshold
        recentErrors
        adaptationCount
    end
    
    methods
        
        
        
        
    end
end

classdef StreamProcessor < handle
    properties
        preprocessingConfig
        scaler
        filterState
    end
    
    methods
        
        
        
        
    end
end

% Local functions (moved to end so this listing is a valid MATLAB script)
        function obj = RealTimePredictiveSystem(config)
            if nargin < 1
                config = obj.getDefaultConfiguration();
            end
            
            obj.configuration = config;
            obj.dataBuffer = CircularBuffer(config.bufferSize);
            obj.predictionModel = EnsemblePredictionModel(config.modelConfig);
            obj.performanceMonitor = RealTimePerformanceMonitor();
            obj.adaptationEngine = ModelAdaptationEngine(config.adaptationConfig);
            obj.streamProcessor = StreamProcessor(config.streamConfig);
            obj.isRunning = false;
            
            fprintf('Real-time predictive system initialised.\n');
        end

        function config = getDefaultConfiguration(obj)
            config = struct();
            config.bufferSize = 1000;
            config.predictionHorizon = 1;
            config.adaptationThreshold = 0.1;
            config.retrainingInterval = 100;
            config.confidenceLevel = 0.95;
            
            config.modelConfig = struct();
            config.modelConfig.baseModels = {'linear', 'tree', 'svm'};
            config.modelConfig.ensembleMethod = 'weighted_average';
            
            config.adaptationConfig = struct();
            config.adaptationConfig.learningRate = 0.01;
            config.adaptationConfig.forgettingFactor = 0.99;
            
            config.streamConfig = struct();
            config.streamConfig.samplingRate = 10; % Hz
            config.streamConfig.preprocessing = 'normalisation';
        end

        function startRealTimeProcessing(obj, dataSource, duration)
            % Start real-time processing for specified duration
            obj.isRunning = true;
            startTime = tic;
            processingStats = struct('totalPredictions', 0, 'averageLatency', 0, 'errors', 0);
            
            fprintf('Starting real-time processing for %.1f seconds...\n', duration);
            
            % Initial model training if needed
            if ~obj.predictionModel.isTrained
                obj.initialModelTraining(dataSource);
            end
            
            while toc(startTime) < duration && obj.isRunning
                try
                    % Get new data point
                    newDataPoint = obj.getNextDataPoint(dataSource);
                    
                    if ~isempty(newDataPoint)
                        % Process the data point
                        predictionStart = tic;
                        result = obj.processDataPoint(newDataPoint);
                        processingTime = toc(predictionStart);
                        
                        % Update statistics
                        processingStats.totalPredictions = processingStats.totalPredictions + 1;
                        processingStats.averageLatency = (processingStats.averageLatency * (processingStats.totalPredictions - 1) + processingTime) / processingStats.totalPredictions;
                        
                        % Display prediction result
                        if mod(processingStats.totalPredictions, 10) == 0
                            fprintf('Prediction %d: %.3f (Confidence: %.2f%%, Latency: %.1fms)\n', ...
                                processingStats.totalPredictions, result.prediction, result.confidence*100, processingTime*1000);
                        end
                        
                        % Check for adaptation needs
                        if obj.adaptationEngine.shouldAdapt(result)
                            obj.adaptModel(newDataPoint, result);
                        end
                    end
                    
                    % Brief pause to simulate real-time constraints
                    pause(1/obj.configuration.streamConfig.samplingRate);
                    
                catch ME
                    processingStats.errors = processingStats.errors + 1;
                    fprintf('Processing error: %s\n', ME.message);
                end
            end
            
            obj.isRunning = false;
            fprintf('Real-time processing completed.\n');
            fprintf('Total predictions: %d, Average latency: %.2fms, Errors: %d\n', ...
                processingStats.totalPredictions, processingStats.averageLatency*1000, processingStats.errors);
        end

        function initialModelTraining(obj, dataSource)
            fprintf('Training initial model...\n');
            
            % Generate initial training data
            trainingData = obj.generateInitialTrainingData(dataSource, 500);
            
            % Train the ensemble model
            obj.predictionModel.train(trainingData.features, trainingData.targets);
            
            fprintf('Initial model training completed.\n');
        end

        function trainingData = generateInitialTrainingData(obj, dataSource, numSamples)
            trainingData = struct();
            
            switch dataSource.type
                case 'time_series'
                    % Generate time series data
                    t = linspace(0, 10, numSamples);
                    signal = sin(2*pi*0.1*t) + 0.5*sin(2*pi*0.05*t) + 0.1*randn(size(t));
                    
                    % Create features (windowed approach)
                    windowSize = 10;
                    features = [];
                    targets = [];
                    
                    for i = windowSize+1:length(signal)
                        features(end+1, :) = signal(i-windowSize:i-1);
                        targets(end+1) = signal(i);
                    end
                    
                case 'sensor_data'
                    % Generate multi-sensor data
                    features = randn(numSamples, 5); % 5 sensor readings
                    
                    % Create synthetic relationship for targets
                    targets = 2*features(:,1) + 0.5*features(:,2) - features(:,3) + 0.1*randn(numSamples, 1);
                    
                case 'financial'
                    % Generate financial time series
                    returns = 0.001 + 0.02*randn(numSamples, 1);
                    prices = cumprod(1 + returns);
                    
                    % Technical indicators as features
                    features = obj.calculateTechnicalIndicators(prices);
                    targets = returns(size(features,1)+1:end); % Future returns
                    
                otherwise
                    % Default synthetic data
                    features = randn(numSamples, 3);
                    targets = sum(features, 2) + 0.1*randn(numSamples, 1);
            end
            
            trainingData.features = features;
            trainingData.targets = targets;
        end

        function indicators = calculateTechnicalIndicators(obj, prices)
            % Calculate technical indicators for financial data
            windowSize = 20;
            indicators = [];
            
            for i = windowSize:length(prices)-1
                priceWindow = prices(i-windowSize+1:i);
                
                % Moving averages
                ma5 = mean(prices(max(1,i-4):i));
                ma20 = mean(priceWindow);
                
                % Relative strength index (simplified)
                gains = diff(priceWindow);
                avgGain = mean(gains(gains > 0));
                avgLoss = abs(mean(gains(gains < 0)));
                rsi = 100 - (100 / (1 + avgGain/(avgLoss + eps)));
                
                % Volatility
                volatility = std(diff(priceWindow));
                
                indicators(end+1, :) = [ma5, ma20, rsi, volatility];
            end
        end

        function newDataPoint = getNextDataPoint(obj, dataSource)
            % Simulate getting next data point from stream
            persistent dataIndex timeSeriesData
            
            if isempty(dataIndex)
                dataIndex = 1;
                % Generate longer time series for streaming
                t = linspace(0, 100, 10000);
                timeSeriesData = sin(2*pi*0.1*t) + 0.5*sin(2*pi*0.05*t) + 0.1*randn(size(t));
            end
            
            if dataIndex <= length(timeSeriesData)
                switch dataSource.type
                    case 'time_series'
                        newDataPoint = struct();
                        newDataPoint.timestamp = datetime('now');
                        newDataPoint.value = timeSeriesData(dataIndex);
                        newDataPoint.features = obj.extractFeaturesFromStream(timeSeriesData, dataIndex);
                        
                    case 'sensor_data'
                        newDataPoint = struct();
                        newDataPoint.timestamp = datetime('now');
                        newDataPoint.sensorReadings = randn(1, 5);
                        newDataPoint.features = newDataPoint.sensorReadings;
                        
                    case 'financial'
                        newDataPoint = struct();
                        newDataPoint.timestamp = datetime('now');
                        newDataPoint.price = 100 + cumsum(0.1*randn(1));
                        newDataPoint.volume = randi([1000, 10000]);
                        newDataPoint.features = [newDataPoint.price, newDataPoint.volume, randn(1,2)];
                        
                    otherwise
                        newDataPoint = struct();
                        newDataPoint.timestamp = datetime('now');
                        newDataPoint.features = randn(1, 3);
                end
                
                dataIndex = dataIndex + 1;
            else
                newDataPoint = []; % End of data
            end
        end

        function features = extractFeaturesFromStream(obj, timeSeriesData, currentIndex)
            windowSize = 10;
            
            if currentIndex >= windowSize
                features = timeSeriesData(currentIndex-windowSize+1:currentIndex);
            else
                % Pad with zeros if not enough history
                features = [zeros(1, windowSize-currentIndex), timeSeriesData(1:currentIndex)];
            end
        end

        function result = processDataPoint(obj, dataPoint)
            result = struct();
            result.timestamp = dataPoint.timestamp;
            
            % Add to buffer
            obj.dataBuffer.add(dataPoint);
            
            % Preprocess features
            preprocessedFeatures = obj.streamProcessor.preprocess(dataPoint.features);
            
            % Make prediction
            predictionResult = obj.predictionModel.predict(preprocessedFeatures);
            
            result.prediction = predictionResult.prediction;
            result.confidence = predictionResult.confidence;
            result.uncertainty = predictionResult.uncertainty;
            result.modelWeights = predictionResult.modelWeights;
            
            % Update performance monitoring
            obj.performanceMonitor.recordPrediction(result);
            
            % Store actual value if available (for online learning)
            if isfield(dataPoint, 'actualValue')
                result.actualValue = dataPoint.actualValue;
                obj.performanceMonitor.recordActual(dataPoint.actualValue);
            end
            
            result.processingLatency = obj.performanceMonitor.getLatestLatency();
        end

        function adaptModel(obj, dataPoint, predictionResult)
            % Perform online model adaptation
            if isfield(dataPoint, 'actualValue')
                % Calculate prediction error
                error = abs(predictionResult.prediction - dataPoint.actualValue);
                
                % Update model based on error
                obj.adaptationEngine.updateModel(obj.predictionModel, dataPoint.features, dataPoint.actualValue, error);
                
                fprintf('Model adapted based on prediction error: %.3f\n', error);
            end
        end

        function stopProcessing(obj)
            obj.isRunning = false;
            fprintf('Real-time processing stopped.\n');
        end

        function metrics = getPerformanceMetrics(obj)
            metrics = obj.performanceMonitor.getMetrics();
            metrics.bufferUtilisation = obj.dataBuffer.getUtilisation();
            metrics.modelPerformance = obj.predictionModel.getPerformanceMetrics();
            metrics.adaptationStats = obj.adaptationEngine.getAdaptationStats();
        end

        function visualiseRealTimePerformance(obj)
            % Create real-time performance dashboard
            figure('Name', 'Real-Time Predictive Analytics Dashboard', 'Position', [100, 100, 1200, 800]);
            
            % Performance metrics over time
            subplot(2, 3, 1);
            obj.performanceMonitor.plotLatencyTrend();
            
            subplot(2, 3, 2);
            obj.performanceMonitor.plotAccuracyTrend();
            
            subplot(2, 3, 3);
            obj.performanceMonitor.plotPredictionDistribution();
            
            subplot(2, 3, 4);
            obj.predictionModel.plotModelWeights();
            
            subplot(2, 3, 5);
            obj.adaptationEngine.plotAdaptationHistory();
            
            subplot(2, 3, 6);
            obj.dataBuffer.plotBufferStatus();
        end

        function obj = CircularBuffer(capacity)
            obj.capacity = capacity;
            obj.data = cell(capacity, 1);
            obj.size = 0;
            obj.headIndex = 1;
            obj.tailIndex = 1;
        end

        function add(obj, item)
            obj.data{obj.tailIndex} = item;
            obj.tailIndex = mod(obj.tailIndex, obj.capacity) + 1;
            
            if obj.size < obj.capacity
                obj.size = obj.size + 1;
            else
                obj.headIndex = mod(obj.headIndex, obj.capacity) + 1;
            end
        end

        function utilisation = getUtilisation(obj)
            utilisation = obj.size / obj.capacity;
        end

        function plotBufferStatus(obj)
            % Plot buffer utilisation over time
            utilisationHistory = linspace(0.2, obj.getUtilisation(), 100);
            plot(utilisationHistory);
            title('Buffer Utilisation');
            xlabel('Time');
            ylabel('Utilisation Ratio');
            ylim([0, 1]);
            grid on;
        end

        function obj = EnsemblePredictionModel(config)
            obj.baseModels = containers.Map();
            obj.modelWeights = [];
            obj.ensembleMethod = config.ensembleMethod;
            obj.isTrained = false;
            obj.trainingHistory = {};
            obj.performanceMetrics = struct();
            
            % Initialise base models
            for i = 1:length(config.baseModels)
                modelType = config.baseModels{i};
                obj.baseModels(modelType) = obj.createBaseModel(modelType);
            end
        end

        function model = createBaseModel(obj, modelType)
            model = struct();
            model.type = modelType;
            model.parameters = [];
            model.trained = false;
            
            switch modelType
                case 'linear'
                    model.weights = [];
                    model.bias = 0;
                case 'tree'
                    model.tree = [];
                case 'svm'
                    model.supportVectors = [];
                    model.alpha = [];
                    model.kernel = 'rbf';
            end
        end

        function train(obj, features, targets)
            fprintf('Training ensemble model...\n');
            
            modelNames = keys(obj.baseModels);
            obj.modelWeights = ones(length(modelNames), 1) / length(modelNames);
            
            % Train each base model
            for i = 1:length(modelNames)
                modelName = modelNames{i};
                model = obj.baseModels(modelName);
                
                try
                    trainedModel = obj.trainBaseModel(model, features, targets);
                    obj.baseModels(modelName) = trainedModel;
                    fprintf('Trained %s model\n', modelName);
                catch ME
                    fprintf('Failed to train %s model: %s\n', modelName, ME.message);
                end
            end
            
            obj.isTrained = true;
            obj.trainingHistory{end+1} = struct('timestamp', datetime('now'), 'dataSize', size(features));
        end

        function trainedModel = trainBaseModel(obj, model, features, targets)
            trainedModel = model;
            
            switch model.type
                case 'linear'
                    % Linear regression
                    if size(features, 2) > 1
                        X = [ones(size(features, 1), 1), features]; % Add bias term
                        weights = (X' * X) \ (X' * targets);
                        trainedModel.weights = weights(2:end);
                        trainedModel.bias = weights(1);
                    else
                        trainedModel.weights = features \ targets;
                        trainedModel.bias = 0;
                    end
                    trainedModel.trained = true;
                    
                case 'tree'
                    % Simple decision tree (placeholder)
                    trainedModel.tree = struct('threshold', mean(features(:)), 'leftValue', mean(targets(targets < median(targets))), 'rightValue', mean(targets(targets >= median(targets))));
                    trainedModel.trained = true;
                    
                case 'svm'
                    % Simplified SVM (using normal equations)
                    trainedModel.weights = pinv(features) * targets;
                    trainedModel.trained = true;
            end
        end

        function result = predict(obj, features)
            result = struct();
            
            if ~obj.isTrained
                error('Model must be trained before making predictions');
            end
            
            modelNames = keys(obj.baseModels);
            predictions = zeros(length(modelNames), 1);
            confidences = zeros(length(modelNames), 1);
            
            % Get predictions from each base model
            for i = 1:length(modelNames)
                modelName = modelNames{i};
                model = obj.baseModels(modelName);
                
                if model.trained
                    [pred, conf] = obj.predictWithBaseModel(model, features);
                    predictions(i) = pred;
                    confidences(i) = conf;
                end
            end
            
            % Combine predictions using ensemble method
            switch obj.ensembleMethod
                case 'simple_average'
                    result.prediction = mean(predictions);
                    result.confidence = mean(confidences);
                    
                case 'weighted_average'
                    result.prediction = sum(obj.modelWeights .* predictions);
                    result.confidence = sum(obj.modelWeights .* confidences);
                    
                case 'median'
                    result.prediction = median(predictions);
                    result.confidence = median(confidences);
            end
            
            % Calculate uncertainty
            result.uncertainty = std(predictions);
            result.modelWeights = obj.modelWeights;
            result.individualPredictions = predictions;
        end

        function [prediction, confidence] = predictWithBaseModel(obj, model, features)
            switch model.type
                case 'linear'
                    prediction = features * model.weights + model.bias;
                    confidence = 0.8; % Simplified confidence
                    
                case 'tree'
                    if mean(features) > model.tree.threshold
                        prediction = model.tree.rightValue;
                    else
                        prediction = model.tree.leftValue;
                    end
                    confidence = 0.7;
                    
                case 'svm'
                    prediction = features * model.weights;
                    confidence = 0.75;
                    
                otherwise
                    prediction = 0;
                    confidence = 0.5;
            end
        end

        function metrics = getPerformanceMetrics(obj)
            metrics = obj.performanceMetrics;
            metrics.isTrained = obj.isTrained;
            metrics.numBaseModels = obj.baseModels.Count;
            metrics.ensembleMethod = obj.ensembleMethod;
        end

        function plotModelWeights(obj)
            if ~isempty(obj.modelWeights)
                modelNames = keys(obj.baseModels);
                bar(obj.modelWeights);
                set(gca, 'XTickLabel', modelNames);
                title('Ensemble Model Weights');
                ylabel('Weight');
                grid on;
            else
                text(0.5, 0.5, 'No model weights available', 'HorizontalAlignment', 'center');
                title('Ensemble Model Weights');
            end
        end

        function obj = RealTimePerformanceMonitor()
            obj.predictionHistory = {};
            obj.latencyHistory = [];
            obj.accuracyHistory = [];
            obj.startTime = datetime('now');
        end

        function recordPrediction(obj, predictionResult)
            obj.predictionHistory{end+1} = predictionResult;
            
            if isfield(predictionResult, 'processingLatency')
                obj.latencyHistory(end+1) = predictionResult.processingLatency;
            end
        end

        function recordActual(obj, actualValue)
            if ~isempty(obj.predictionHistory)
                lastPrediction = obj.predictionHistory{end};
                if isfield(lastPrediction, 'prediction')
                    accuracy = 1 - abs(lastPrediction.prediction - actualValue) / (abs(actualValue) + eps);
                    obj.accuracyHistory(end+1) = max(0, accuracy);
                end
            end
        end

        function latency = getLatestLatency(obj)
            if ~isempty(obj.latencyHistory)
                latency = obj.latencyHistory(end);
            else
                latency = 0;
            end
        end

        function metrics = getMetrics(obj)
            metrics = struct();
            metrics.totalPredictions = length(obj.predictionHistory);
            
            if ~isempty(obj.latencyHistory)
                metrics.averageLatency = mean(obj.latencyHistory);
                metrics.maxLatency = max(obj.latencyHistory);
                metrics.minLatency = min(obj.latencyHistory);
            end
            
            if ~isempty(obj.accuracyHistory)
                metrics.averageAccuracy = mean(obj.accuracyHistory);
                metrics.currentAccuracy = obj.accuracyHistory(end);
            end
            
            metrics.uptime = seconds(datetime('now') - obj.startTime);
        end

        function plotLatencyTrend(obj)
            if ~isempty(obj.latencyHistory)
                plot(obj.latencyHistory * 1000); % Convert to ms
                title('Prediction Latency Trend');
                xlabel('Prediction Number');
                ylabel('Latency (ms)');
                grid on;
            else
                text(0.5, 0.5, 'No latency data', 'HorizontalAlignment', 'center');
                title('Prediction Latency Trend');
            end
        end

        function plotAccuracyTrend(obj)
            if ~isempty(obj.accuracyHistory)
                plot(obj.accuracyHistory);
                title('Prediction Accuracy Trend');
                xlabel('Prediction Number');
                ylabel('Accuracy');
                ylim([0, 1]);
                grid on;
            else
                text(0.5, 0.5, 'No accuracy data', 'HorizontalAlignment', 'center');
                title('Prediction Accuracy Trend');
            end
        end

        function plotPredictionDistribution(obj)
            if ~isempty(obj.predictionHistory)
                predictions = cellfun(@(x) x.prediction, obj.predictionHistory);
                histogram(predictions, 20);
                title('Prediction Distribution');
                xlabel('Prediction Value');
                ylabel('Frequency');
                grid on;
            else
                text(0.5, 0.5, 'No prediction data', 'HorizontalAlignment', 'center');
                title('Prediction Distribution');
            end
        end

        function obj = ModelAdaptationEngine(config)
            obj.adaptationConfig = config;
            obj.adaptationHistory = {};
            obj.performanceThreshold = 0.1;
            obj.recentErrors = [];
            obj.adaptationCount = 0;
        end

        function shouldAdapt = shouldAdapt(obj, predictionResult)
            shouldAdapt = false;
            
            % Check if we have enough error history
            if length(obj.recentErrors) >= 10
                recentErrorRate = mean(obj.recentErrors(end-9:end));
                if recentErrorRate > obj.performanceThreshold
                    shouldAdapt = true;
                end
            end
            
            % Check prediction confidence
            if isfield(predictionResult, 'confidence') && predictionResult.confidence < 0.6
                shouldAdapt = true;
            end
        end

        function updateModel(obj, model, features, actualValue, error)
            % Perform online learning update
            obj.recentErrors(end+1) = error;
            
            % Keep only recent errors
            if length(obj.recentErrors) > 50
                obj.recentErrors = obj.recentErrors(end-49:end);
            end
            
            % Update model weights (simplified online learning)
            modelNames = keys(model.baseModels);
            
            for i = 1:length(modelNames)
                modelName = modelNames{i};
                baseModel = model.baseModels(modelName);
                
                if baseModel.trained
                    % Simple gradient descent update for linear models
                    if strcmp(baseModel.type, 'linear')
                        learningRate = obj.adaptationConfig.learningRate;
                        prediction = features * baseModel.weights + baseModel.bias;
                        gradientWeights = 2 * (prediction - actualValue) * features';
                        gradientBias = 2 * (prediction - actualValue);
                        
                        baseModel.weights = baseModel.weights - learningRate * gradientWeights;
                        baseModel.bias = baseModel.bias - learningRate * gradientBias;
                        
                        model.baseModels(modelName) = baseModel;
                    end
                end
            end
            
            obj.adaptationCount = obj.adaptationCount + 1;
            obj.adaptationHistory{end+1} = struct('timestamp', datetime('now'), 'error', error, 'features', features);
        end

        function stats = getAdaptationStats(obj)
            stats = struct();
            stats.adaptationCount = obj.adaptationCount;
            stats.averageRecentError = mean(obj.recentErrors);
            
            if ~isempty(obj.adaptationHistory)
                errors = cellfun(@(x) x.error, obj.adaptationHistory);
                stats.adaptationErrorTrend = errors;
            end
        end

        function plotAdaptationHistory(obj)
            if ~isempty(obj.adaptationHistory)
                errors = cellfun(@(x) x.error, obj.adaptationHistory);
                plot(errors);
                title('Model Adaptation History');
                xlabel('Adaptation Number');
                ylabel('Prediction Error');
                grid on;
            else
                text(0.5, 0.5, 'No adaptation data', 'HorizontalAlignment', 'center');
                title('Model Adaptation History');
            end
        end

        function obj = StreamProcessor(config)
            obj.preprocessingConfig = config;
            obj.scaler = struct('mean', 0, 'std', 1);
            obj.filterState = struct();
        end

        function processedFeatures = preprocess(obj, features)
            processedFeatures = features;
            
            switch obj.preprocessingConfig.preprocessing
                case 'normalisation'
                    processedFeatures = obj.normalizeFeatures(features);
                case 'standardisation'
                    processedFeatures = obj.standardizeFeatures(features);
                case 'filtering'
                    processedFeatures = obj.filterFeatures(features);
            end
        end

        function normalizedFeatures = normalizeFeatures(obj, features)
            % Min-max normalisation (simplified)
            normalizedFeatures = (features - min(features)) / (max(features) - min(features) + eps);
        end

        function standardizedFeatures = standardizeFeatures(obj, features)
            % Z-score standardisation (using running statistics)
            obj.scaler.mean = 0.99 * obj.scaler.mean + 0.01 * mean(features);
            obj.scaler.std = 0.99 * obj.scaler.std + 0.01 * std(features);
            
            standardizedFeatures = (features - obj.scaler.mean) / (obj.scaler.std + eps);
        end

        function filteredFeatures = filterFeatures(obj, features)
            % Simple low-pass filter
            alpha = 0.1; % Filter coefficient
            
            if ~isfield(obj.filterState, 'previousValue')
                obj.filterState.previousValue = features;
            end
            
            filteredFeatures = alpha * features + (1 - alpha) * obj.filterState.previousValue;
            obj.filterState.previousValue = filteredFeatures;
        end
