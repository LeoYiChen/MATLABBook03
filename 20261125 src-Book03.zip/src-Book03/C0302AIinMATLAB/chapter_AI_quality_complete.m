%% chapter_AI_quality_complete.m
% Comprehensive data quality assessment pipeline.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_quality_complete
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
classdef DataQualityAssessor < handle
    properties
        options
        qualityDimensions
        anomalyDetectors
        statisticalTests
    end
    
    methods
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    end
end

% Local functions (moved to end so this listing is a valid MATLAB script)
function qualityReport = comprehensiveDataQualityAssessment(dataset, options)
    % Comprehensive Data Quality Assessment Pipeline
    % Author: Dr Yi Chen
    % Version: 1.0
    % Description: Evaluates data quality across multiple dimensions
    
    if nargin < 2
        options = struct();
    end
    
    try
        % Initialise quality assessor
        assessor = DataQualityAssessor(options);
        
        % Perform comprehensive assessment
        qualityReport = assessor.assessDataQuality(dataset);
        
        % Generate recommendations
        qualityReport.recommendations = assessor.generateRecommendations(qualityReport);
        
        % Create visualisations
        if ~isfield(options, 'generatePlots') || options.generatePlots
            qualityReport.visualisations = assessor.createQualityVisualisations(qualityReport);
        end
        
        fprintf('Data quality assessment completed.\n');
        fprintf('Overall quality score: %.2f/10\n', qualityReport.overallScore);
        
    catch ME
        qualityReport = struct();
        qualityReport.success = false;
        qualityReport.error = ME.message;
    end
end

        function obj = DataQualityAssessor(options)
            obj.options = obj.setDefaultOptions(options);
            obj.qualityDimensions = {'completeness', 'consistency', 'accuracy', 'validity', 'uniqueness', 'timeliness'};
            obj.anomalyDetectors = obj.initialiseAnomalyDetectors();
            obj.statisticalTests = obj.initialiseStatisticalTests();
        end

        function options = setDefaultOptions(obj, inputOptions)
            options = struct();
            options.completenessWeight = 0.2;
            options.consistencyWeight = 0.2;
            options.accuracyWeight = 0.2;
            options.validityWeight = 0.15;
            options.uniquenessWeight = 0.15;
            options.timelinessWeight = 0.1;
            options.anomalyThreshold = 0.05;
            options.confidenceLevel = 0.95;
            
            % Override with user options
            fields = fieldnames(inputOptions);
            for i = 1:length(fields)
                options.*(fields{i}) = inputOptions.*(fields{i});
            end
        end

        function detectors = initialiseAnomalyDetectors(obj)
            detectors = containers.Map();
            detectors('statistical') = @obj.statisticalAnomalyDetection;
            detectors('isolation_forest') = @obj.isolationForestDetection;
            detectors('clustering') = @obj.clusteringBasedDetection;
            detectors('rules_based') = @obj.rulesBasedDetection;
        end

        function tests = initialiseStatisticalTests(obj)
            tests = containers.Map();
            tests('normality') = @obj.normalityTest;
            tests('outliers') = @obj.outlierTest;
            tests('correlation') = @obj.correlationTest;
            tests('distribution') = @obj.distributionTest;
        end

        function qualityReport = assessDataQuality(obj, dataset)
            qualityReport = struct();
            qualityReport.timestamp = datetime('now');
            qualityReport.datasetInfo = obj.getDatasetInfo(dataset);
            
            % Assess each quality dimension
            qualityReport.completeness = obj.assessCompleteness(dataset);
            qualityReport.consistency = obj.assessConsistency(dataset);
            qualityReport.accuracy = obj.assessAccuracy(dataset);
            qualityReport.validity = obj.assessValidity(dataset);
            qualityReport.uniqueness = obj.assessUniqueness(dataset);
            qualityReport.timeliness = obj.assessTimeliness(dataset);
            
            % Detect anomalies
            qualityReport.anomalies = obj.detectAnomalies(dataset);
            
            % Perform statistical tests
            qualityReport.statisticalTests = obj.performStatisticalTests(dataset);
            
            % Calculate overall score
            qualityReport.overallScore = obj.calculateOverallScore(qualityReport);
            
            % Data profiling
            qualityReport.profile = obj.generateDataProfile(dataset);
        end

        function info = getDatasetInfo(obj, dataset)
            info = struct();
            info.dimensions = size(dataset);
            info.totalElements = numel(dataset);
            info.dataType = class(dataset);
            info.memoryUsage = whos('dataset').bytes;
            
            if istable(dataset)
                info.variableNames = dataset.Properties.VariableNames;
                info.variableTypes = cellfun(@class, table2cell(dataset(1,:)), 'UniformOutput', false);
            end
        end

        function completeness = assessCompleteness(obj, dataset)
            completeness = struct();
            
            if istable(dataset)
                % Table-based completeness assessment
                totalCells = height(dataset) * width(dataset);
                missingCells = sum(ismissing(dataset), 'all');
                
                completeness.totalCells = totalCells;
                completeness.missingCells = missingCells;
                completeness.completenessRatio = (totalCells - missingCells) / totalCells;
                
                % Per-column completeness
                completeness.columnCompleteness = 1 - sum(ismissing(dataset)) / height(dataset);
                
                % Per-row completeness
                completeness.rowCompleteness = 1 - sum(ismissing(dataset), 2) / width(dataset);
                
            else
                % Numeric array completeness
                totalElements = numel(dataset);
                missingElements = sum(isnan(dataset(:)));
                
                completeness.totalElements = totalElements;
                completeness.missingElements = missingElements;
                completeness.completenessRatio = (totalElements - missingElements) / totalElements;
            end
            
            % Score completeness (0-10 scale)
            completeness.score = completeness.completenessRatio * 10;
        end

        function consistency = assessConsistency(obj, dataset)
            consistency = struct();
            
            if istable(dataset)
                consistency = obj.assessTableConsistency(dataset);
            else
                consistency = obj.assessArrayConsistency(dataset);
            end
            
            % Calculate overall consistency score
            consistency.score = mean([consistency.typeConsistency, consistency.formatConsistency, consistency.rangeConsistency]);
        end

        function consistency = assessTableConsistency(obj, dataset)
            consistency = struct();
            
            % Type consistency within columns
            typeConsistency = zeros(width(dataset), 1);
            for i = 1:width(dataset)
                column = dataset{:, i};
                if isnumeric(column)
                    typeConsistency(i) = 10; % Perfect for numeric
                else
                    % Check string consistency
                    typeConsistency(i) = obj.assessStringConsistency(column);
                end
            end
            consistency.typeConsistency = mean(typeConsistency);
            
            % Format consistency
            consistency.formatConsistency = obj.assessFormatConsistency(dataset);
            
            % Range consistency
            consistency.rangeConsistency = obj.assessRangeConsistency(dataset);
        end

        function consistency = assessArrayConsistency(obj, dataset)
            consistency = struct();
            
            % Type consistency
            consistency.typeConsistency = 10; % Arrays are type-consistent by definition
            
            % Range consistency
            if isnumeric(dataset)
                dataRange = range(dataset(:));
                dataStd = std(dataset(:));
                
                % Assess if range is reasonable relative to standard deviation
                if dataRange < 5 * dataStd
                    consistency.rangeConsistency = 10;
                elseif dataRange < 10 * dataStd
                    consistency.rangeConsistency = 7;
                else
                    consistency.rangeConsistency = 4;
                end
            else
                consistency.rangeConsistency = 8; % Default for non-numeric
            end
            
            % Format consistency
            consistency.formatConsistency = 9; % Arrays have consistent format
        end

        function formatConsistency = assessFormatConsistency(obj, dataset)
            % Assess format consistency across columns
            formatScores = [];
            
            if istable(dataset)
                for i = 1:width(dataset)
                    column = dataset{:, i};
                    if iscellstr(column) || isstring(column)
                        formatScores(end+1) = obj.assessStringFormatConsistency(column);
                    else
                        formatScores(end+1) = 10; % Numeric columns are format-consistent
                    end
                end
            end
            
            formatConsistency = mean(formatScores);
        end

        function formatScore = assessStringFormatConsistency(obj, stringColumn)
            % Assess format consistency in string columns
            if isempty(stringColumn)
                formatScore = 10;
                return;
            end
            
            % Check for consistent patterns
            patterns = {};
            patternCounts = [];
            
            for i = 1:length(stringColumn)
                str = char(stringColumn(i));
                pattern = regexprep(str, '\d', 'N'); % Replace digits with N
                pattern = regexprep(pattern, '[A-Za-z]', 'L'); % Replace letters with L
                
                idx = find(strcmp(patterns, pattern));
                if isempty(idx)
                    patterns{end+1} = pattern;
                    patternCounts(end+1) = 1;
                else
                    patternCounts(idx) = patternCounts(idx) + 1;
                end
            end
            
            % Score based on pattern diversity
            dominantPatternRatio = max(patternCounts) / length(stringColumn);
            formatScore = dominantPatternRatio * 10;
        end

        function rangeConsistency = assessRangeConsistency(obj, dataset)
            % Assess if data values are within expected ranges
            rangeScores = [];
            
            if istable(dataset)
                for i = 1:width(dataset)
                    column = dataset{:, i};
                    if isnumeric(column)
                        rangeScores(end+1) = obj.assessNumericRangeConsistency(column);
                    else
                        rangeScores(end+1) = 8; % Default for non-numeric
                    end
                end
            else
                rangeScores = obj.assessNumericRangeConsistency(dataset);
            end
            
            rangeConsistency = mean(rangeScores);
        end

        function rangeScore = assessNumericRangeConsistency(obj, numericData)
            % Assess numeric range consistency using IQR method
            Q1 = prctile(numericData, 25);
            Q3 = prctile(numericData, 75);
            IQR = Q3 - Q1;
            
            lowerBound = Q1 - 1.5 * IQR;
            upperBound = Q3 + 1.5 * IQR;
            
            outlierRatio = sum(numericData < lowerBound | numericData > upperBound) / length(numericData);
            rangeScore = (1 - outlierRatio) * 10;
        end

        function accuracy = assessAccuracy(obj, dataset)
            accuracy = struct();
            
            % Since we don't have ground truth, estimate accuracy using various heuristics
            accuracy.syntacticAccuracy = obj.assessSyntacticAccuracy(dataset);
            accuracy.semanticAccuracy = obj.assessSemanticAccuracy(dataset);
            accuracy.structuralAccuracy = obj.assessStructuralAccuracy(dataset);
            
            % Overall accuracy score
            accuracy.score = mean([accuracy.syntacticAccuracy, accuracy.semanticAccuracy, accuracy.structuralAccuracy]);
        end

        function syntacticScore = assessSyntacticAccuracy(obj, dataset)
            % Assess syntactic accuracy (format correctness)
            if istable(dataset)
                syntacticScores = [];
                for i = 1:width(dataset)
                    column = dataset{:, i};
                    if isnumeric(column)
                        syntacticScores(end+1) = 10; % Numeric data is syntactically correct
                    else
                        syntacticScores(end+1) = obj.assessStringSyntax(column);
                    end
                end
                syntacticScore = mean(syntacticScores);
            else
                syntacticScore = 10; % Numeric arrays are syntactically correct
            end
        end

        function syntaxScore = assessStringSyntax(obj, stringColumn)
            % Assess string syntax correctness
            syntaxScore = 10; % Start with perfect score
            
            for i = 1:length(stringColumn)
                str = char(stringColumn(i));
                
                % Check for common syntax issues
                if contains(str, '  ') % Multiple spaces
                    syntaxScore = syntaxScore - 0.1;
                end
                
                if ~isempty(regexp(str, '^\s|\s$', 'once')) % Leading/trailing whitespace
                    syntaxScore = syntaxScore - 0.1;
                end
                
                if contains(str, char(9)) % Tab characters
                    syntaxScore = syntaxScore - 0.1;
                end
            end
            
            syntaxScore = max(syntaxScore, 0);
        end

        function semanticScore = assessSemanticAccuracy(obj, dataset)
            % Assess semantic accuracy using domain knowledge
            semanticScore = 8; % Default score for unknown semantic correctness
            
            % This would typically involve domain-specific validation
            % For demonstration, we'll use simple heuristics
            
            if istable(dataset)
                for i = 1:width(dataset)
                    varName = dataset.Properties.VariableNames{i};
                    column = dataset{:, i};
                    
                    % Example semantic checks based on variable names
                    if contains(lower(varName), 'age') && isnumeric(column)
                        if any(column < 0 | column > 150)
                            semanticScore = semanticScore - 1;
                        end
                    elseif contains(lower(varName), 'percentage') && isnumeric(column)
                        if any(column < 0 | column > 100)
                            semanticScore = semanticScore - 1;
                        end
                    end
                end
            end
            
            semanticScore = max(semanticScore, 0);
        end

        function structuralScore = assessStructuralAccuracy(obj, dataset)
            % Assess structural accuracy
            structuralScore = 10;
            
            if istable(dataset)
                % Check for consistent structure
                expectedColumns = width(dataset);
                if any(sum(~ismissing(dataset), 2) < expectedColumns * 0.5)
                    structuralScore = structuralScore - 2; % Penalty for sparse rows
                end
            else
                % Check for NaN patterns that might indicate structural issues
                nanRatio = sum(isnan(dataset(:))) / numel(dataset);
                if nanRatio > 0.1
                    structuralScore = structuralScore - (nanRatio * 10);
                end
            end
            
            structuralScore = max(structuralScore, 0);
        end

        function validity = assessValidity(obj, dataset)
            validity = struct();
            
            % Domain validity
            validity.domainValidity = obj.assessDomainValidity(dataset);
            
            % Constraint validity
            validity.constraintValidity = obj.assessConstraintValidity(dataset);
            
            % Business rule validity
            validity.businessRuleValidity = obj.assessBusinessRuleValidity(dataset);
            
            % Overall validity score
            validity.score = mean([validity.domainValidity, validity.constraintValidity, validity.businessRuleValidity]);
        end

        function domainScore = assessDomainValidity(obj, dataset)
            % Assess if values are within valid domains
            domainScore = 10;
            
            if istable(dataset)
                for i = 1:width(dataset)
                    column = dataset{:, i};
                    if isnumeric(column)
                        % Check for infinite or extremely large values
                        if any(isinf(column) | abs(column) > 1e10)
                            domainScore = domainScore - 1;
                        end
                    end
                end
            else
                if any(isinf(dataset(:)) | abs(dataset(:)) > 1e10)
                    domainScore = domainScore - 2;
                end
            end
            
            domainScore = max(domainScore, 0);
        end

        function constraintScore = assessConstraintValidity(obj, dataset)
            % Assess constraint violations
            constraintScore = 9; % Default high score
            
            % This would typically check business-specific constraints
            % For demonstration, we'll check basic mathematical constraints
            
            if isnumeric(dataset)
                % Check for reasonable value distributions
                dataStd = std(dataset(:), 'omitnan');
                dataMean = mean(dataset(:), 'omitnan');
                
                % Flag extremely skewed distributions
                if dataStd > 10 * abs(dataMean)
                    constraintScore = constraintScore - 2;
                end
            end
            
            constraintScore = max(constraintScore, 0);
        end

        function businessScore = assessBusinessRuleValidity(obj, dataset)
            % Assess business rule compliance
            businessScore = 8; % Default score
            
            % This would implement specific business rules
            % For demonstration, we'll use generic rules
            
            if istable(dataset)
                % Example: Check for logical relationships between columns
                numericColumns = varfun(@isnumeric, dataset, 'OutputFormat', 'uniform');
                if sum(numericColumns) >= 2
                    % Simple correlation check as business rule proxy
                    numData = dataset{:, numericColumns};
                    corrMatrix = corr(numData, 'rows', 'pairwise');
                    
                    % Flag if all correlations are too high (potential data duplication)
                    offDiagCorr = corrMatrix(~eye(size(corrMatrix)));
                    if any(abs(offDiagCorr) > 0.95)
                        businessScore = businessScore - 1;
                    end
                end
            end
            
            businessScore = max(businessScore, 0);
        end

        function uniqueness = assessUniqueness(obj, dataset)
            uniqueness = struct();
            
            if istable(dataset)
                uniqueness = obj.assessTableUniqueness(dataset);
            else
                uniqueness = obj.assessArrayUniqueness(dataset);
            end
            
            % Overall uniqueness score
            uniqueness.score = uniqueness.overallUniquenessRatio * 10;
        end

        function uniqueness = assessTableUniqueness(obj, dataset)
            uniqueness = struct();
            
            % Row-level uniqueness
            [~, uniqueRowIndices] = unique(dataset, 'rows');
            uniqueness.uniqueRows = length(uniqueRowIndices);
            uniqueness.totalRows = height(dataset);
            uniqueness.rowUniquenessRatio = uniqueness.uniqueRows / uniqueness.totalRows;
            
            % Column-level uniqueness
            columnUniqueness = zeros(width(dataset), 1);
            for i = 1:width(dataset)
                column = dataset{:, i};
                uniqueValues = length(unique(column, 'rows'));
                totalValues = length(column);
                columnUniqueness(i) = uniqueValues / totalValues;
            end
            uniqueness.columnUniqueness = columnUniqueness;
            uniqueness.averageColumnUniqueness = mean(columnUniqueness);
            
            % Overall uniqueness
            uniqueness.overallUniquenessRatio = (uniqueness.rowUniquenessRatio + uniqueness.averageColumnUniqueness) / 2;
        end

        function uniqueness = assessArrayUniqueness(obj, dataset)
            uniqueness = struct();
            
            uniqueValues = length(unique(dataset(:)));
            totalValues = numel(dataset);
            
            uniqueness.uniqueValues = uniqueValues;
            uniqueness.totalValues = totalValues;
            uniqueness.overallUniquenessRatio = uniqueValues / totalValues;
        end

        function timeliness = assessTimeliness(obj, dataset)
            timeliness = struct();
            
            % Since we don't have timestamp information, we'll assess data freshness heuristically
            timeliness.dataFreshness = obj.assessDataFreshness(dataset);
            timeliness.temporalConsistency = obj.assessTemporalConsistency(dataset);
            
            % Overall timeliness score
            timeliness.score = (timeliness.dataFreshness + timeliness.temporalConsistency) / 2;
        end

        function freshness = assessDataFreshness(obj, dataset)
            % Assess data freshness (placeholder implementation)
            freshness = 8; % Default score assuming reasonably fresh data
            
            % This would typically check actual timestamps
            % For demonstration, we'll use file modification time if available
            try
                info = evalin('caller', 'whos(''dataset'')');
                % Assume data is fresh if recently loaded
                freshness = 9;
            catch
                freshness = 7;
            end
        end

        function temporalConsistency = assessTemporalConsistency(obj, dataset)
            % Assess temporal consistency
            temporalConsistency = 9; % Default high score
            
            % Look for date/time columns in tables
            if istable(dataset)
                for i = 1:width(dataset)
                    column = dataset{:, i};
                    if isa(column, 'datetime')
                        % Check for temporal anomalies
                        if any(diff(column) < 0) % Non-monotonic timestamps
                            temporalConsistency = temporalConsistency - 2;
                        end
                    end
                end
            end
            
            temporalConsistency = max(temporalConsistency, 0);
        end

        function anomalies = detectAnomalies(obj, dataset)
            anomalies = struct();
            
            % Apply multiple anomaly detection methods
            detectorNames = keys(obj.anomalyDetectors);
            
            for i = 1:length(detectorNames)
                detectorName = detectorNames{i};
                detector = obj.anomalyDetectors(detectorName);
                try
                    anomalies.*(detectorName) = detector(dataset);
                catch ME
                    anomalies.*(detectorName) = struct('error', ME.message);
                end
            end
            
            % Combine anomaly results
            anomalies.summary = obj.summariseAnomalies(anomalies);
        end

        function result = statisticalAnomalyDetection(obj, dataset)
            result = struct();
            
            if isnumeric(dataset)
                % Z-score based detection
                zScores = abs(zscore(dataset(:)));
                outliers = zScores > 3;
                
                result.method = 'z_score';
                result.threshold = 3;
                result.anomalyCount = sum(outliers);
                result.anomalyRatio = sum(outliers) / length(outliers);
                result.anomalyIndices = find(outliers);
            else
                result.method = 'not_applicable';
                result.message = 'Statistical detection not applicable to non-numeric data';
            end
        end

        function result = isolationForestDetection(obj, dataset)
            result = struct();
            result.method = 'isolation_forest';
            
            % Simplified isolation forest implementation
            if isnumeric(dataset) && numel(dataset) > 50
                data = dataset(:);
                contamination = obj.options.anomalyThreshold;
                
                % Simulate isolation forest scores
                scores = randn(size(data)) + 0.1 * (data - mean(data)) / std(data);
                threshold = prctile(scores, (1-contamination) * 100);
                
                anomalies = scores > threshold;
                
                result.anomalyCount = sum(anomalies);
                result.anomalyRatio = sum(anomalies) / length(anomalies);
                result.anomalyIndices = find(anomalies);
                result.contamination = contamination;
            else
                result.message = 'Insufficient data for isolation forest';
            end
        end

        function result = clusteringBasedDetection(obj, dataset)
            result = struct();
            result.method = 'clustering_based';
            
            if isnumeric(dataset) && numel(dataset) > 20
                data = dataset(:);
                
                % Simple k-means based anomaly detection
                k = min(3, floor(length(data) / 10));
                
                try
                    [clusterIdx, centroids] = kmeans(data, k);
                    
                    % Calculate distances to nearest centroid
                    distances = zeros(size(data));
                    for i = 1:length(data)
                        distances(i) = min(abs(data(i) - centroids));
                    end
                    
                    % Flag points far from any centroid
                    threshold = prctile(distances, 95);
                    anomalies = distances > threshold;
                    
                    result.anomalyCount = sum(anomalies);
                    result.anomalyRatio = sum(anomalies) / length(anomalies);
                    result.anomalyIndices = find(anomalies);
                    result.numClusters = k;
                    
                catch ME
                    result.error = ME.message;
                end
            else
                result.message = 'Insufficient data for clustering';
            end
        end

        function result = rulesBasedDetection(obj, dataset)
            result = struct();
            result.method = 'rules_based';
            
            anomalies = false(size(dataset));
            
            if isnumeric(dataset)
                % Rule 1: Extreme values
                dataStd = std(dataset(:), 'omitnan');
                dataMean = mean(dataset(:), 'omitnan');
                extremeValues = abs(dataset - dataMean) > 5 * dataStd;
                anomalies = anomalies | extremeValues;
                
                % Rule 2: Infinite or NaN values
                invalidValues = ~isfinite(dataset);
                anomalies = anomalies | invalidValues;
                
                % Rule 3: Repeated identical values (potential errors)
                flatData = dataset(:);
                [uniqueVals, ~, idx] = unique(flatData);
                counts = accumarray(idx, 1);
                suspiciousValues = counts > length(flatData) * 0.5; % More than 50% identical
                
                if any(suspiciousValues)
                    suspiciousVal = uniqueVals(suspiciousValues);
                    repeatedAnomalies = ismember(dataset, suspiciousVal);
                    anomalies = anomalies | repeatedAnomalies;
                end
            end
            
            result.anomalyCount = sum(anomalies(:));
            result.anomalyRatio = sum(anomalies(:)) / numel(anomalies);
            result.anomalyIndices = find(anomalies(:));
        end

        function summary = summariseAnomalies(obj, anomalies)
            summary = struct();
            
            % Collect all anomaly ratios
            ratios = [];
            methods = fieldnames(anomalies);
            methods = methods(~strcmp(methods, 'summary')); % Exclude summary field
            
            for i = 1:length(methods)
                method = methods{i};
                if isfield(anomalies.*(method), 'anomalyRatio')
                    ratios(end+1) = anomalies.*(method).anomalyRatio;
                end
            end
            
            if ~isempty(ratios)
                summary.averageAnomalyRatio = mean(ratios);
                summary.maxAnomalyRatio = max(ratios);
                summary.minAnomalyRatio = min(ratios);
                summary.anomalyConsistency = 1 - std(ratios); % High consistency = low std
            else
                summary.averageAnomalyRatio = 0;
                summary.anomalyConsistency = 1;
            end
            
            summary.methodsApplied = methods;
        end

        function testResults = performStatisticalTests(obj, dataset)
            testResults = struct();
            
            if isnumeric(dataset)
                % Normality test
                testResults.normality = obj.normalityTest(dataset);
                
                % Outlier test
                testResults.outliers = obj.outlierTest(dataset);
                
                % Distribution test
                testResults.distribution = obj.distributionTest(dataset);
                
                if size(dataset, 2) > 1
                    % Correlation test for multivariate data
                    testResults.correlation = obj.correlationTest(dataset);
                end
            else
                testResults.message = 'Statistical tests not applicable to non-numeric data';
            end
        end

        function result = normalityTest(obj, dataset)
            result = struct();
            result.testName = 'Kolmogorov-Smirnov Normality Test';
            
            data = dataset(:);
            data = data(~isnan(data)); % Remove NaN values
            
            if length(data) > 3
                % Simplified normality test
                [h, p] = kstest(normalize(data));
                
                result.isNormal = ~h;
                result.pValue = p;
                result.alpha = 0.05;
                result.testStatistic = max(abs(sort(normalize(data)) - norminv((1:length(data))' / (length(data) + 1))));
            else
                result.message = 'Insufficient data for normality test';
            end
        end

        function result = outlierTest(obj, dataset)
            result = struct();
            result.testName = 'Modified Z-Score Outlier Test';
            
            data = dataset(:);
            data = data(~isnan(data));
            
            if length(data) > 3
                % Modified Z-score using median absolute deviation
                medianVal = median(data);
                mad = median(abs(data - medianVal));
                modifiedZScores = 0.6745 * (data - medianVal) / mad;
                
                outliers = abs(modifiedZScores) > 3.5;
                
                result.outlierCount = sum(outliers);
                result.outlierRatio = sum(outliers) / length(data);
                result.outlierIndices = find(outliers);
                result.threshold = 3.5;
            else
                result.message = 'Insufficient data for outlier test';
            end
        end

        function result = correlationTest(obj, dataset)
            result = struct();
            result.testName = 'Correlation Matrix Analysis';
            
            if size(dataset, 2) > 1
                % Calculate correlation matrix
                corrMatrix = corr(dataset, 'rows', 'pairwise');
                
                result.correlationMatrix = corrMatrix;
                result.maxCorrelation = max(abs(corrMatrix(~eye(size(corrMatrix)))));
                result.minCorrelation = min(abs(corrMatrix(~eye(size(corrMatrix)))));
                result.averageCorrelation = mean(abs(corrMatrix(~eye(size(corrMatrix)))));
                
                % Identify highly correlated pairs
                [row, col] = find(abs(corrMatrix) > 0.8 & ~eye(size(corrMatrix)));
                result.highlyCorrelatedPairs = [row, col];
            else
                result.message = 'Correlation test requires multivariate data';
            end
        end

        function result = distributionTest(obj, dataset)
            result = struct();
            result.testName = 'Distribution Characteristics';
            
            data = dataset(:);
            data = data(~isnan(data));
            
            if length(data) > 1
                result.mean = mean(data);
                result.median = median(data);
                result.std = std(data);
                result.skewness = skewness(data);
                result.kurtosis = kurtosis(data);
                result.range = range(data);
                result.iqr = iqr(data);
                
                % Distribution shape assessment
                if abs(result.skewness) < 0.5
                    result.skewnessAssessment = 'approximately_symmetric';
                elseif abs(result.skewness) < 1
                    result.skewnessAssessment = 'moderately_skewed';
                else
                    result.skewnessAssessment = 'highly_skewed';
                end
                
                if result.kurtosis < 3
                    result.kurtosisAssessment = 'platykurtic';
                elseif result.kurtosis > 3
                    result.kurtosisAssessment = 'leptokurtic';
                else
                    result.kurtosisAssessment = 'mesokurtic';
                end
            else
                result.message = 'Insufficient data for distribution analysis';
            end
        end

        function overallScore = calculateOverallScore(obj, qualityReport)
            % Calculate weighted overall quality score
            weights = [
                obj.options.completenessWeight;
                obj.options.consistencyWeight;
                obj.options.accuracyWeight;
                obj.options.validityWeight;
                obj.options.uniquenessWeight;
                obj.options.timelinessWeight
            ];
            
            scores = [
                qualityReport.completeness.score;
                qualityReport.consistency.score;
                qualityReport.accuracy.score;
                qualityReport.validity.score;
                qualityReport.uniqueness.score;
                qualityReport.timeliness.score
            ];
            
            overallScore = sum(weights .* scores);
        end

        function profile = generateDataProfile(obj, dataset)
            profile = struct();
            profile.timestamp = datetime('now');
            
            if istable(dataset)
                profile = obj.generateTableProfile(dataset);
            else
                profile = obj.generateArrayProfile(dataset);
            end
        end

        function profile = generateTableProfile(obj, dataset)
            profile = struct();
            profile.type = 'table';
            profile.dimensions = size(dataset);
            profile.variableNames = dataset.Properties.VariableNames;
            
            % Profile each variable
            profile.variables = struct();
            for i = 1:width(dataset)
                varName = dataset.Properties.VariableNames{i};
                column = dataset{:, i};
                profile.variables.*(varName) = obj.profileVariable(column);
            end
        end

        function profile = generateArrayProfile(obj, dataset)
            profile = struct();
            profile.type = 'array';
            profile.dimensions = size(dataset);
            profile.dataType = class(dataset);
            
            if isnumeric(dataset)
                profile.statistics = obj.profileVariable(dataset);
            end
        end

        function varProfile = profileVariable(obj, variable)
            varProfile = struct();
            varProfile.dataType = class(variable);
            varProfile.totalCount = length(variable);
            
            if isnumeric(variable)
                variable = variable(~isnan(variable)); % Remove NaN for calculations
                
                if ~isempty(variable)
                    varProfile.validCount = length(variable);
                    varProfile.missingCount = varProfile.totalCount - varProfile.validCount;
                    varProfile.min = min(variable);
                    varProfile.max = max(variable);
                    varProfile.mean = mean(variable);
                    varProfile.median = median(variable);
                    varProfile.std = std(variable);
                    varProfile.quartiles = prctile(variable, [25, 50, 75]);
                    varProfile.uniqueCount = length(unique(variable));
                    varProfile.zeroCount = sum(variable == 0);
                    varProfile.negativeCount = sum(variable < 0);
                    varProfile.positiveCount = sum(variable > 0);
                end
            else
                % Categorical/string variable
                uniqueValues = unique(variable);
                varProfile.uniqueCount = length(uniqueValues);
                varProfile.uniqueValues = uniqueValues(1:min(10, length(uniqueValues))); % First 10
                
                if iscellstr(variable) || isstring(variable)
                    lengths = cellfun(@length, cellstr(variable));
                    varProfile.minLength = min(lengths);
                    varProfile.maxLength = max(lengths);
                    varProfile.meanLength = mean(lengths);
                end
            end
        end

        function recommendations = generateRecommendations(obj, qualityReport)
            recommendations = {};
            
            % Completeness recommendations
            if qualityReport.completeness.score < 8
                recommendations{end+1} = sprintf('LOW COMPLETENESS (%.1f/10): Consider data imputation or collection of missing values', qualityReport.completeness.score);
            end
            
            % Consistency recommendations
            if qualityReport.consistency.score < 7
                recommendations{end+1} = sprintf('LOW CONSISTENCY (%.1f/10): Review data formats and standardise value representations', qualityReport.consistency.score);
            end
            
            % Accuracy recommendations
            if qualityReport.accuracy.score < 7
                recommendations{end+1} = sprintf('LOW ACCURACY (%.1f/10): Implement data validation rules and cross-reference with authoritative sources', qualityReport.accuracy.score);
            end
            
            % Validity recommendations
            if qualityReport.validity.score < 7
                recommendations{end+1} = sprintf('LOW VALIDITY (%.1f/10): Define and enforce business rules and domain constraints', qualityReport.validity.score);
            end
            
            % Uniqueness recommendations
            if qualityReport.uniqueness.score < 6
                recommendations{end+1} = sprintf('LOW UNIQUENESS (%.1f/10): Investigate and remove duplicate records', qualityReport.uniqueness.score);
            end
            
            % Timeliness recommendations
            if qualityReport.timeliness.score < 7
                recommendations{end+1} = sprintf('LOW TIMELINESS (%.1f/10): Establish data refresh procedures and temporal validation', qualityReport.timeliness.score);
            end
            
            % Anomaly recommendations
            if isfield(qualityReport.anomalies, 'summary') && qualityReport.anomalies.summary.averageAnomalyRatio > 0.05
                recommendations{end+1} = sprintf('HIGH ANOMALY RATE (%.1f%%): Investigate %d anomalous data points', qualityReport.anomalies.summary.averageAnomalyRatio * 100, qualityReport.anomalies.summary.averageAnomalyRatio * numel(qualityReport.datasetInfo.totalElements));
            end
            
            % Overall recommendations
            if qualityReport.overallScore < 6
                recommendations{end+1} = 'CRITICAL: Overall data quality is poor. Consider comprehensive data cleansing before analysis.';
            elseif qualityReport.overallScore < 8
                recommendations{end+1} = 'MODERATE: Data quality needs improvement. Prioritise top issues before proceeding.';
            else
                recommendations{end+1} = 'GOOD: Data quality is acceptable for most analytical purposes.';
            end
        end

        function visualisations = createQualityVisualisations(obj, qualityReport)
            visualisations = struct();
            
            % Quality scores radar chart
            figure('Name', 'Data Quality Assessment', 'Position', [100, 100, 1200, 800]);
            
            subplot(2, 3, 1);
            obj.createQualityRadarChart(qualityReport);
            
            subplot(2, 3, 2);
            obj.createQualityBarChart(qualityReport);
            
            subplot(2, 3, 3);
            obj.createAnomalyChart(qualityReport);
            
            subplot(2, 3, 4);
            if isfield(qualityReport, 'profile') && isfield(qualityReport.profile, 'variables')
                obj.createCompletenessChart(qualityReport);
            end
            
            subplot(2, 3, 5);
            if isfield(qualityReport.statisticalTests, 'distribution')
                obj.createDistributionChart(qualityReport);
            end
            
            subplot(2, 3, 6);
            obj.createRecommendationsChart(qualityReport);
            
            visualisations.figureHandle = gcf;
        end

        function createQualityRadarChart(obj, qualityReport)
            scores = [
                qualityReport.completeness.score;
                qualityReport.consistency.score;
                qualityReport.accuracy.score;
                qualityReport.validity.score;
                qualityReport.uniqueness.score;
                qualityReport.timeliness.score
            ];
            
            labels = {'Completeness', 'Consistency', 'Accuracy', 'Validity', 'Uniqueness', 'Timeliness'};
            
            % Create polar plot
            angles = linspace(0, 2*pi, length(scores)+1);
            scores_plot = [scores; scores(1)]; % Close the polygon
            
            polarplot(angles, scores_plot, 'o-', 'LineWidth', 2, 'MarkerSize', 8);
            hold on;
            polarplot(angles, 10*ones(size(angles)), '-k', 'Alpha', 0.3); % Reference line at 10
            
            title('Data Quality Radar Chart');
            theta*ticks(rad2deg(angles(1:end-1)));
            theta*ticklabels(labels);
            rlim([0, 10]);
        end

        function createQualityBarChart(obj, qualityReport)
            scores = [
                qualityReport.completeness.score;
                qualityReport.consistency.score;
                qualityReport.accuracy.score;
                qualityReport.validity.score;
                qualityReport.uniqueness.score;
                qualityReport.timeliness.score
            ];
            
            labels = {'Completeness', 'Consistency', 'Accuracy', 'Validity', 'Uniqueness', 'Timeliness'};
            
            colors = scores / 10; % Normalise for coloring
            bar(scores, 'FaceColor', 'flat', 'CData', [colors, 1-colors, zeros(length(scores), 1)]);
            
            set(gca, 'XTickLabel', labels, 'XTickLabelRotation', 45);
            ylabel('Quality Score (0-10)');
            title('Data Quality Dimensions');
            ylim([0, 10]);
            grid on;
            
            % Add value labels on bars
            for i = 1:length(scores)
                text(i, scores(i) + 0.2, sprintf('%.1f', scores(i)), 'HorizontalAlignment', 'center');
            end
        end

        function createAnomalyChart(obj, qualityReport)
            if isfield(qualityReport.anomalies, 'summary')
                methods = qualityReport.anomalies.summary.methodsApplied;
                ratios = [];
                
                for i = 1:length(methods)
                    method = methods{i};
                    if isfield(qualityReport.anomalies.*(method), 'anomalyRatio')
                        ratios(end+1) = qualityReport.anomalies.*(method).anomalyRatio * 100;
                    end
                end
                
                if ~isempty(ratios)
                    bar(ratios);
                    set(gca, 'XTickLabel', methods, 'XTickLabelRotation', 45);
                    ylabel('Anomaly Percentage');
                    title('Anomaly Detection Results');
                    grid on;
                end
            else
                text(0.5, 0.5, 'No anomaly data available', 'HorizontalAlignment', 'center');
                title('Anomaly Detection Results');
            end
        end

        function createCompletenessChart(obj, qualityReport)
            if isfield(qualityReport.profile, 'variables')
                varNames = fieldnames(qualityReport.profile.variables);
                completeness = [];
                
                for i = 1:length(varNames)
                    varProfile = qualityReport.profile.variables.*(varNames{i});
                    if isfield(varProfile, 'validCount') && isfield(varProfile, 'totalCount')
                        completeness(end+1) = (varProfile.validCount / varProfile.totalCount) * 100;
                    else
                        completeness(end+1) = 100; % Assume complete for non-numeric
                    end
                end
                
                bar(completeness);
                set(gca, 'XTickLabel', varNames, 'XTickLabelRotation', 45);
                ylabel('Completeness Percentage');
                title('Variable Completeness');
                ylim([0, 100]);
                grid on;
            else
                text(0.5, 0.5, 'No completeness data available', 'HorizontalAlignment', 'center');
                title('Variable Completeness');
            end
        end

        function createDistributionChart(obj, qualityReport)
            if isfield(qualityReport.statisticalTests, 'distribution')
                dist = qualityReport.statisticalTests.distribution;
                
                % Create a simple distribution summary
                metrics = {'Mean', 'Median', 'Std', 'Skewness', 'Kurtosis'};
                values = [dist.mean, dist.median, dist.std, dist.skewness, dist.kurtosis];
                
                % Normalise values for display
                normValues = abs(values) / max(abs(values));
                
                bar(normValues);
                set(gca, 'XTickLabel', metrics, 'XTickLabelRotation', 45);
                ylabel('Normalised Value');
                title('Distribution Characteristics');
                grid on;
                
                % Add actual values as text
                for i = 1:length(values)
                    text(i, normValues(i) + 0.05, sprintf('%.2f', values(i)), 'HorizontalAlignment', 'center');
                end
            else
                text(0.5, 0.5, 'No distribution data available', 'HorizontalAlignment', 'center');
                title('Distribution Characteristics');
            end
        end

        function createRecommendationsChart(obj, qualityReport)
            % Create a summary of recommendation priorities
            criticalCount = sum(contains(qualityReport.recommendations, 'CRITICAL'));
            moderateCount = sum(contains(qualityReport.recommendations, 'MODERATE'));
            lowCount = sum(contains(qualityReport.recommendations, 'LOW'));
            goodCount = sum(contains(qualityReport.recommendations, 'GOOD'));
            
            counts = [criticalCount, moderateCount, lowCount, goodCount];
            labels = {'Critical', 'Moderate', 'Low Priority', 'Good'};
            colors = [0.8 0.2 0.2; 0.8 0.6 0.2; 0.8 0.8 0.2; 0.2 0.8 0.2];
            
            pie(counts, labels);
            colormap(colors);
            title('Recommendation Priorities');
        end
