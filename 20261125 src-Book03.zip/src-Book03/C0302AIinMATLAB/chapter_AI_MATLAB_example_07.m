%% chapter_AI_MATLAB_example_07.m
% Implementing Deep Q-Network (DQN) Agent for Cart-Pole System
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_example_07
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Create cart-pole environment
env = rlPredefinedEnv('CartPole-Discrete');

% Create DQN agent
obsInfo = getObservationInfo(env);
actInfo = getActionInfo(env);

% Create deep neural network for Q-function approximation
layers = [
    imageInputLayer(obsInfo.Dimension, 'Normalization', 'none', 'Name', 'state')
    fullyConnectedLayer(24, 'Name', 'fc1')
    reluLayer('Name', 'relu1')
    fullyConnectedLayer(24, 'Name', 'fc2')
    reluLayer('Name', 'relu2')
    fullyConnectedLayer(actInfo.Dimension, 'Name', 'fc3')];

% Create DQN agent
dqnOpts = rlDQNAgentOptions(...
    'UseDoubleDQN', true, ...
    'TargetUpdateFrequency', 4, ...
    'ExperienceBufferLength', 10000, ...
    'DiscountFactor', 0.99, ...
    'MiniBatchSize', 64);
agent = rlDQNAgent(layers, obsInfo, actInfo, dqnOpts);

% Train agent
trainOpts = rlTrainingOptions(...
    'MaxEpisodes', 500, ...
    'MaxStepsPerEpisode', 500, ...
    'Verbose', false, ...
    'Plots', 'training-progress', ...
    'StopTrainingCriteria', 'AverageReward', ...
    'StopTrainingValue', 480);
stats = train(agent, env, trainOpts);
