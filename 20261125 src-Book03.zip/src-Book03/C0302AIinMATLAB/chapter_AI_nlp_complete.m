%% chapter_AI_nlp_complete.m
% Complete natural language command parser implementation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_nlp_complete
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function result = naturalLanguageCommandParser(inputCommand)
% Natural Language Command Parser for MATLAB Operations
% Author: Dr Yi Chen
% Version: 1.0
% Description: Processes natural language commands and executes MATLAB operations

try
    % Step 1: Preprocess the input command
    processedCommand = preprocessCommand(inputCommand);
    
    % Step 2: Tokenise the command
    tokens = tokeniseCommand(processedCommand);
    
    % Step 3: Classify intent
    intent = classifyIntent(tokens);
    
    % Step 4: Extract entities
    entities = extractEntities(tokens, intent);
    
    % Step 5: Execute the command
    result = executeCommand(intent, entities);
    
    % Step 6: Format the response
    result.success = true;
    result.message = sprintf('Successfully executed: %s', inputCommand);
    
catch ME
    result.success = false;
    result.error = ME.message;
    result.message = sprintf('Failed to process command: %s', inputCommand);
end

end

function processedCommand = preprocessCommand(command)
% Remove punctuation and convert to lowercase
processedCommand = lower(regexprep(command, '[^\w\s]', ''));
end

function tokens = tokeniseCommand(command)
% Split command into individual words
tokens = strsplit(strtrim(command));
% Remove empty tokens
tokens = tokens(~cellfun('isempty', tokens));
end

function intent = classifyIntent(tokens)
% Define intent keywords
plotKeywords = {'plot', 'graph', 'visualise', 'draw', 'show'};
calculateKeywords = {'calculate', 'compute', 'find', 'determine'};
analyseKeywords = {'analyse', 'analyze', 'statistics', 'stats', 'summary'};

% Check for plot intent
if any(ismember(tokens, plotKeywords))
    intent = 'visualisation';
elseif any(ismember(tokens, calculateKeywords))
    intent = 'calculation';
elseif any(ismember(tokens, analyseKeywords))
    intent = 'analysis';
else
    intent = 'unknown';
end

end

function entities = extractEntities(tokens, intent)
entities = struct();

% Extract mathematical functions
mathFunctions = {'sin', 'cos', 'tan', 'exp', 'log', 'sqrt'};
entities.functions = intersect(tokens, mathFunctions);

% Extract numerical ranges
rangePattern = '\d+:\d+|\d+\.\d+:\d+\.\d+';
for i = 1:length(tokens)
    if ~isempty(regexp(tokens{i}, rangePattern, 'once'))
        entities.range = tokens{i};
        break;
    end
end

% Extract specific numerical values
numbers = [];
for i = 1:length(tokens)
    num = str2double(tokens{i});
    if ~isnan(num)
        numbers(end+1) = num;
    end
end
entities.numbers = numbers;

% Extract data types
dataTypes = {'matrix', 'vector', 'array', 'data'};
entities.dataTypes = intersect(tokens, dataTypes);

end

function result = executeCommand(intent, entities)
result = struct();

switch intent
    case 'visualisation'
        result = executeVisualisationCommand(entities);
    case 'calculation'
        result = executeCalculationCommand(entities);
    case 'analysis'
        result = executeAnalysisCommand(entities);
    otherwise
        error('Unknown intent: %s', intent);
end

end

function result = executeVisualisationCommand(entities)
result = struct();

if ~isempty(entities.functions)
    func = entities.functions{1};
    
    % Default range if none specified
    if isfield(entities, 'range') && ~isempty(entities.range)
        x = eval(entities.range);
    else
        x = 0:0.1:2*pi;
    end
    
    % Calculate function values
    switch func
        case 'sin'
            y = sin(x);
            result.title = 'Sine Function';
        case 'cos'
            y = cos(x);
            result.title = 'Cosine Function';
        case 'tan'
            y = tan(x);
            result.title = 'Tangent Function';
        case 'exp'
            y = exp(x);
            result.title = 'Exponential Function';
        case 'log'
            y = log(x);
            result.title = 'Natural Logarithm';
        case 'sqrt'
            y = sqrt(abs(x));
            result.title = 'Square Root Function';
    end
    
    % Create plot
    figure;
    plot(x, y, 'LineWidth', 2);
    title(result.title);
    xlabel('x');
    ylabel(sprintf('%s(x)', func));
    grid on;
    
    result.plotCreated = true;
    result.xData = x;
    result.yData = y;
    result.functionUsed = func;
else
    error('No valid function found for visualisation');
end

end

function result = executeCalculationCommand(entities)
result = struct();

if ~isempty(entities.numbers)
    numbers = entities.numbers;
    
    % Perform basic calculations
    result.sum = sum(numbers);
    result.mean = mean(numbers);
    result.product = prod(numbers);
    result.maximum = max(numbers);
    result.minimum = min(numbers);
    result.standardDeviation = std(numbers);
    result.numbers = numbers;
    
elseif ~isempty(entities.functions)
    % Generate sample data for function calculation
    x = 0:0.1:2*pi;
    func = entities.functions{1};
    
    switch func
        case 'sin'
            values = sin(x);
        case 'cos'
            values = cos(x);
        case 'tan'
            values = tan(x);
        otherwise
            values = eval(sprintf('%s(x)', func));
    end
    
    result.functionValues = values;
    result.functionUsed = func;
    result.inputRange = x;
    result.maxValue = max(values);
    result.minValue = min(values);
else
    error('No valid numbers or functions found for calculation');
end

end

function result = executeAnalysisCommand(entities)
result = struct();

% Generate sample dataset for analysis
if ~isempty(entities.numbers)
    data = entities.numbers;
else
    data = randn(100, 1); % Default random dataset
end

% Perform statistical analysis
result.dataSize = length(data);
result.mean = mean(data);
result.median = median(data);
result.standardDeviation = std(data);
result.variance = var(data);
result.skewness = skewness(data);
result.kurtosis = kurtosis(data);
result.minimum = min(data);
result.maximum = max(data);
result.range = range(data);
result.quartiles = prctile(data, [25, 50, 75]);

% Create histogram
figure;
histogram(data, 20);
title('Data Distribution Analysis');
xlabel('Value');
ylabel('Frequency');
grid on;

result.histogramCreated = true;
result.analysedData = data;

end
