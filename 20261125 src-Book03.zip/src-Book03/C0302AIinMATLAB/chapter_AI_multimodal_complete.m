%% chapter_AI_multimodal_complete.m
% Multi-modal input processing system.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_multimodal_complete
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function result = multiModalInputProcessingSystem(varargin)
% Multi-Modal Input Processing System
% Author: Dr Yi Chen
% Version: 1.0
% Description: Processes multiple input modalities with intelligent fusion

% Parse input arguments
inputParser = createInputParser();
parse(inputParser, varargin{:});
inputs = inputParser.Results;

try
    % Step 1: Detect available modalities
    availableModalities = detectModalities(inputs);
    
    % Step 2: Process each modality
    modalityResults = processModalities(inputs, availableModalities);
    
    % Step 3: Fuse multi-modal information
    fusedResult = fuseModalityInformation(modalityResults);
    
    % Step 4: Resolve conflicts if any
    resolvedResult = resolveModalityConflicts(fusedResult);
    
    % Step 5: Generate unified response
    result = generateUnifiedResponse(resolvedResult, availableModalities);
    
    result.success = true;
    result.processedModalities = availableModalities;
    
catch ME
    result.success = false;
    result.error = ME.message;
    result.message = 'Multi-modal processing failed';
end

end

function inputParser = createInputParser()
inputParser = inputParser();

% Define possible input parameters
addParameter(inputParser, 'textInput', '', @ischar);
addParameter(inputParser, 'voiceInput', [], @(x) isnumeric(x) || ischar(x));
addParameter(inputParser, 'fileInput', '', @ischar);
addParameter(inputParser, 'gestureInput', [], @isstruct);
addParameter(inputParser, 'imageInput', [], @(x) isnumeric(x) || ischar(x));
addParameter(inputParser, 'dataInput', [], @isnumeric);
addParameter(inputParser, 'contextInput', struct(), @isstruct);

end

function modalities = detectModalities(inputs)
modalities = {};

% Check for text input
if ~isempty(inputs.textInput) && ischar(inputs.textInput)
    modalities{end+1} = 'text';
end

% Check for voice input
if ~isempty(inputs.voiceInput)
    modalities{end+1} = 'voice';
end

% Check for file input
if ~isempty(inputs.fileInput) && exist(inputs.fileInput, 'file')
    modalities{end+1} = 'file';
end

% Check for gesture input
if ~isempty(inputs.gestureInput) && isstruct(inputs.gestureInput)
    modalities{end+1} = 'gesture';
end

% Check for image input
if ~isempty(inputs.imageInput)
    modalities{end+1} = 'image';
end

% Check for direct data input
if ~isempty(inputs.dataInput)
    modalities{end+1} = 'data';
end

fprintf('Detected modalities: %s\n', strjoin(modalities, ', '));

end

function modalityResults = processModalities(inputs, modalities)
modalityResults = struct();

for i = 1:length(modalities)
    modality = modalities{i};
    
    switch modality
        case 'text'
            modalityResults.text = processTextInput(inputs.textInput);
        case 'voice'
            modalityResults.voice = processVoiceInput(inputs.voiceInput);
        case 'file'
            modalityResults.file = processFileInput(inputs.fileInput);
        case 'gesture'
            modalityResults.gesture = processGestureInput(inputs.gestureInput);
        case 'image'
            modalityResults.image = processImageInput(inputs.imageInput);
        case 'data'
            modalityResults.data = processDataInput(inputs.dataInput);
    end
    
    fprintf('Processed %s input\n', modality);
end

end

function textResult = processTextInput(textInput)
textResult = struct();
textResult.modality = 'text';
textResult.rawInput = textInput;

% Tokenise and analyse text
tokens = strsplit(lower(textInput));

% Extract intent
textResult.intent = extractIntentFromText(tokens);

% Extract entities
textResult.entities = extractEntitiesFromText(tokens);

% Extract commands
textResult.commands = extractCommandsFromText(tokens);

% Confidence scoring
textResult.confidence = calculateTextConfidence(textResult);

textResult.processingTime = 0.05; % Simulated processing time

end

function intent = extractIntentFromText(tokens)
% Intent extraction logic
if any(ismember(tokens, {'plot', 'graph', 'visualise', 'show'}))
intent = 'visualisation';
elseif any(ismember(tokens, {'analyse', 'analyze', 'statistics', 'stats'}))
intent = 'analysis';
elseif any(ismember(tokens, {'calculate', 'compute', 'find'}))
intent = 'calculation';
elseif any(ismember(tokens, {'load', 'import', 'open'}))
intent = 'data_loading';
else
intent = 'general';
end
end

function entities = extractEntitiesFromText(tokens)
entities = struct();

% Extract numbers
numbers = [];
for i = 1:length(tokens)
    num = str2double(tokens{i});
    if ~isnan(num)
        numbers(end+1) = num;
    end
end
entities.numbers = numbers;

% Extract function names
functions = {'sin', 'cos', 'tan', 'exp', 'log', 'sqrt', 'mean', 'std'};
entities.functions = intersect(tokens, functions);

% Extract file references
fileExtensions = {'.mat', '.csv', '.txt', '.xlsx'};
entities.files = {};
for i = 1:length(tokens)
    for j = 1:length(fileExtensions)
        if contains(tokens{i}, fileExtensions{j})
            entities.files{end+1} = tokens{i};
        end
    end
end

end

function commands = extractCommandsFromText(tokens)
commands = {};

% Common command patterns
commandPatterns = {
    {'plot', 'graph'}, 'create_plot';
    {'analyse', 'analyze'}, 'perform_analysis';
    {'calculate', 'compute'}, 'do_calculation';
    {'load', 'import'}, 'load_data';
    {'save', 'export'}, 'save_data'
};

for i = 1:size(commandPatterns, 1)
    pattern = commandPatterns{i, 1};
    command = commandPatterns{i, 2};
    
    if any(ismember(tokens, pattern))
        commands{end+1} = command;
    end
end

end

function confidence = calculateTextConfidence(textResult)
confidence = 0.5; % Base confidence

% Increase confidence based on clear intent
if ~strcmp(textResult.intent, 'general')
    confidence = confidence + 0.2;
end

% Increase confidence based on extracted entities
if ~isempty(textResult.entities.numbers) || ~isempty(textResult.entities.functions)
    confidence = confidence + 0.2;
end

% Increase confidence based on clear commands
if ~isempty(textResult.commands)
    confidence = confidence + 0.1;
end

confidence = min(confidence, 1.0);


end

function voiceResult = processVoiceInput(voiceInput)
voiceResult = struct();
voiceResult.modality = 'voice';

if ischar(voiceInput)
    % Assume voice input is already transcribed text
    voiceResult.transcription = voiceInput;
    voiceResult.transcriptionConfidence = 0.9;
else
    % Simulate speech-to-text conversion
    voiceResult.transcription = simulateSpeechToText(voiceInput);
    voiceResult.transcriptionConfidence = 0.8;
end

% Process transcribed text
textResult = processTextInput(voiceResult.transcription);
voiceResult.intent = textResult.intent;
voiceResult.entities = textResult.entities;
voiceResult.commands = textResult.commands;

% Adjust confidence based on transcription quality
voiceResult.confidence = textResult.confidence * voiceResult.transcriptionConfidence;

% Extract prosodic features (simulated)
voiceResult.prosodics = struct('emphasis', randi([1,5]), 'urgency', randi([1,5]));

voiceResult.processingTime = 0.15; % Simulated processing time

end

function transcription = simulateSpeechToText(audioSignal)
% Simulate speech-to-text conversion
commonPhrases = {
'plot sine wave',
'analyse the data',
'calculate mean values',
'load dataset file',
'show histogram',
'compute statistics'
};

transcription = commonPhrases{randi(length(commonPhrases))};

end

function fileResult = processFileInput(filePath)
fileResult = struct();
fileResult.modality = 'file';
fileResult.filePath = filePath;

[~, ~, ext] = fileparts(filePath);
fileResult.fileType = ext;

% Process file based on type
switch lower(ext)
    case '.mat'
        fileResult = processMATFile(fileResult, filePath);
    case '.csv'
        fileResult = processCSVFile(fileResult, filePath);
    case '.txt'
        fileResult = processTextFile(fileResult, filePath);
    case {'.jpg', '.png', '.bmp'}
        fileResult = processImageFile(fileResult, filePath);
    otherwise
        fileResult.error = sprintf('Unsupported file type: %s', ext);
end

fileResult.confidence = 0.9; % High confidence for file inputs
fileResult.processingTime = 0.1;

end

function fileResult = processMATFile(fileResult, filePath)
try
loadedData = load(filePath);
variables = fieldnames(loadedData);

fileResult.variables = variables;
    fileResult.dataLoaded = true;
    fileResult.intent = 'data_loading';
    fileResult.entities = struct('dataVariables', variables);
    
    % Analyse loaded data
    for i = 1:length(variables)
        varName = variables{i};
        varData = loadedData.*(varName);
        fileResult.dataInfo.*(varName) = struct('size', size(varData), 'class', class(varData));
    end
    
catch ME
    fileResult.error = ME.message;
    fileResult.dataLoaded = false;
end

end

function fileResult = processCSVFile(fileResult, filePath)
try
data = readtable(filePath);

fileResult.dataLoaded = true;
    fileResult.intent = 'data_loading';
    fileResult.entities = struct('columns', data.Properties.VariableNames);
    fileResult.dataInfo = struct('numRows', height(data), 'numCols', width(data), 'columnNames', {data.Properties.VariableNames});
    fileResult.data = data;
    
catch ME
    fileResult.error = ME.message;
    fileResult.dataLoaded = false;
end

end

function fileResult = processTextFile(fileResult, filePath)
try
content = fileread(filePath);

fileResult.content = content;
    fileResult.intent = 'text_processing';
    
    % Basic text analysis
    words = strsplit(content);
    fileResult.entities = struct('wordCount', length(words), 'characterCount', length(content));
    
catch ME
    fileResult.error = ME.message;
end

end

function fileResult = processImageFile(fileResult, filePath)
try
image = imread(filePath);

fileResult.imageLoaded = true;
    fileResult.intent = 'image_processing';
    fileResult.entities = struct('imageSize', size(image), 'imageType', class(image));
    fileResult.imageData = image;
    
catch ME
    fileResult.error = ME.message;
    fileResult.imageLoaded = false;
end

end

function gestureResult = processGestureInput(gestureInput)
gestureResult = struct();
gestureResult.modality = 'gesture';
gestureResult.rawGesture = gestureInput;

% Recognise gesture patterns
gestureResult.recognisedGesture = recogniseGesture(gestureInput);

% Map gesture to intent
gestureResult.intent = mapGestureToIntent(gestureResult.recognisedGesture);

% Extract gesture parameters
gestureResult.entities = extractGestureEntities(gestureInput);

gestureResult.confidence = calculateGestureConfidence(gestureResult);
gestureResult.processingTime = 0.08;

end

function gesture = recogniseGesture(gestureInput)
% Simulate gesture recognition
if isfield(gestureInput, 'type')
gesture = gestureInput.type;
else
gestures = {'point', 'swipe_left', 'swipe_right', 'circle', 'pinch', 'zoom'};
gesture = gestures{randi(length(gestures))};
end
end

function intent = mapGestureToIntent(gesture)
gestureIntentMap = containers.Map({
'point', 'swipe_left', 'swipe_right', 'circle', 'pinch', 'zoom'
}, {
'selection', 'navigation', 'navigation', 'analysis', 'filter', 'visualisation'
});


if gestureIntentMap.isKey(gesture)
    intent = gestureIntentMap(gesture);
else
    intent = 'general';
end

end

function entities = extractGestureEntities(gestureInput)
entities = struct();

if isfield(gestureInput, 'coordinates')
    entities.coordinates = gestureInput.coordinates;
end

if isfield(gestureInput, 'velocity')
    entities.velocity = gestureInput.velocity;
end

if isfield(gestureInput, 'duration')
    entities.duration = gestureInput.duration;
end

end

function confidence = calculateGestureConfidence(gestureResult)
% Base confidence for gesture recognition
confidence = 0.7;

% Adjust based on gesture clarity
if isfield(gestureResult.entities, 'velocity') && gestureResult.entities.velocity > 0.5
    confidence = confidence + 0.1;
end

if isfield(gestureResult.entities, 'duration') && gestureResult.entities.duration > 0.2
    confidence = confidence + 0.1;
end

confidence = min(confidence, 1.0);

end

function imageResult = processImageInput(imageInput)
imageResult = struct();
imageResult.modality = 'image';

if ischar(imageInput)
    % Image file path
    image = imread(imageInput);
    imageResult.source = 'file';
    imageResult.filePath = imageInput;
else
    % Direct image data
    image = imageInput;
    imageResult.source = 'direct';
end

imageResult.imageData = image;
imageResult.imageSize = size(image);

% Perform basic image analysis
imageResult.analysis = analyseImage(image);

% Extract intent from image content
imageResult.intent = extractIntentFromImage(imageResult.analysis);

% Extract entities
imageResult.entities = extractEntitiesFromImage(imageResult.analysis);

imageResult.confidence = 0.8;
imageResult.processingTime = 0.12;

end

function analysis = analyseImage(image)
analysis = struct();

% Basic image properties
analysis.dimensions = size(image);
analysis.channels = size(image, 3);
analysis.dataType = class(image);

% Convert to grayscale for analysis
if size(image, 3) == 3
    grayImage = rgb2gray(image);
else
    grayImage = image;
end

% Statistical properties
analysis.meanIntensity = mean(grayImage(:));
analysis.stdIntensity = std(double(grayImage(:)));
analysis.minIntensity = min(grayImage(:));
analysis.maxIntensity = max(grayImage(:));

% Detect edges (simplified)
edges = edge(grayImage, 'canny');
analysis.edgeDensity = sum(edges(:)) / numel(edges);

% Detect basic patterns
analysis.hasText = detectTextPattern(grayImage);
analysis.hasGraphs = detectGraphPattern(edges);

end

function hasText = detectTextPattern(grayImage)
% Simplified text detection
hasText = analysis.edgeDensity > 0.1 && analysis.stdIntensity > 50;
end

function hasGraphs = detectGraphPattern(edges)
% Simplified graph/chart detection
hasGraphs = sum(edges(:)) > 1000; % Threshold for detecting structured content
end

function intent = extractIntentFromImage(analysis)
if analysis.hasGraphs
intent = 'visualisation';
elseif analysis.hasText
intent = 'text_processing';
else
intent = 'image_analysis';
end
end

function entities = extractEntitiesFromImage(analysis)
entities = struct();
entities.imageProperties = rmfield(analysis, {'hasText', 'hasGraphs'});

if analysis.hasText
    entities.contentType = 'text';
elseif analysis.hasGraphs
    entities.contentType = 'graph';
else
    entities.contentType = 'general';
end

end

function dataResult = processDataInput(dataInput)
dataResult = struct();
dataResult.modality = 'data';
dataResult.rawData = dataInput;

% Analyse data structure
dataResult.dataSize = size(dataInput);
dataResult.dataType = class(dataInput);

% Statistical analysis
dataResult.statistics = struct();
dataResult.statistics.mean = mean(dataInput(:));
dataResult.statistics.std = std(dataInput(:));
dataResult.statistics.min = min(dataInput(:));
dataResult.statistics.max = max(dataInput(:));

% Determine intent based on data characteristics
if size(dataInput, 2) > 1
    dataResult.intent = 'multivariate_analysis';
else
    dataResult.intent = 'univariate_analysis';
end

% Extract entities
dataResult.entities = struct('dataCharacteristics', dataResult.statistics);

dataResult.confidence = 0.95; % High confidence for direct data
dataResult.processingTime = 0.03;

end

function fusedResult = fuseModalityInformation(modalityResults)
fusedResult = struct();

% Collect all intents and their confidences
intents = {};
confidences = [];
modalities = fieldnames(modalityResults);

for i = 1:length(modalities)
    modality = modalities{i};
    result = modalityResults.*(modality);
    
    if isfield(result, 'intent') && isfield(result, 'confidence')
        intents{end+1} = result.intent;
        confidences(end+1) = result.confidence;
    end
end

% Determine dominant intent
if ~isempty(intents)
    [~, maxIdx] = max(confidences);
    fusedResult.dominantIntent = intents{maxIdx};
    fusedResult.intentConfidence = confidences(maxIdx);
else
    fusedResult.dominantIntent = 'general';
    fusedResult.intentConfidence = 0.5;
end

% Combine entities from all modalities
fusedResult.combinedEntities = struct();
for i = 1:length(modalities)
    modality = modalities{i};
    result = modalityResults.*(modality);
    
    if isfield(result, 'entities')
        fusedResult.combinedEntities.*(modality) = result.entities;
    end
end

% Calculate overall confidence
fusedResult.overallConfidence = mean(confidences);

% Store individual results
fusedResult.modalityResults = modalityResults;
fusedResult.processedModalities = modalities;

end

function resolvedResult = resolveModalityConflicts(fusedResult)
resolvedResult = fusedResult;

% Check for intent conflicts
modalities = fusedResult.processedModalities;
intents = {};

for i = 1:length(modalities)
    modality = modalities{i};
    if isfield(fusedResult.modalityResults.*(modality), 'intent')
        intents{end+1} = fusedResult.modalityResults.*(modality).intent;
    end
end

uniqueIntents = unique(intents);

if length(uniqueIntents) > 1
    % Conflict detected
    resolvedResult.conflictDetected = true;
    resolvedResult.conflictingIntents = uniqueIntents;
    
    % Resolve using confidence-weighted voting
    intentVotes = containers.Map();
    for i = 1:length(modalities)
        modality = modalities{i};
        modalityResult = fusedResult.modalityResults.*(modality);
        
        if isfield(modalityResult, 'intent') && isfield(modalityResult, 'confidence')
            intent = modalityResult.intent;
            confidence = modalityResult.confidence;
            
            if intentVotes.isKey(intent)
                intentVotes(intent) = intentVotes(intent) + confidence;
            else
                intentVotes(intent) = confidence;
            end
        end
    end
    
    % Select intent with highest weighted vote
    votes = cell2mat(values(intentVotes));
    intentNames = keys(intentVotes);
    [~, maxIdx] = max(votes);
    
    resolvedResult.resolvedIntent = intentNames{maxIdx};
    resolvedResult.resolutionConfidence = votes(maxIdx) / sum(votes);
    
else
    resolvedResult.conflictDetected = false;
    resolvedResult.resolvedIntent = fusedResult.dominantIntent;
    resolvedResult.resolutionConfidence = fusedResult.intentConfidence;
end

end

function result = generateUnifiedResponse(resolvedResult, availableModalities)
result = struct();
result.finalIntent = resolvedResult.resolvedIntent;
result.confidence = resolvedResult.resolutionConfidence;
result.modalitiesUsed = availableModalities;

% Generate action based on resolved intent
switch resolvedResult.resolvedIntent
    case 'visualisation'
        result.action = 'create_visualisation';
        result.message = sprintf('Creating visualisation based on input from %s', strjoin(availableModalities, ' and '));
        result.executionPlan = generateVisualisationPlan(resolvedResult);
        
    case 'analysis'
        result.action = 'perform_analysis';
        result.message = sprintf('Performing analysis using %s input(s)', strjoin(availableModalities, ', '));
        result.executionPlan = generateAnalysisPlan(resolvedResult);
        
    case 'calculation'
        result.action = 'do_calculation';
        result.message = sprintf('Executing calculations from %s', strjoin(availableModalities, ' and '));
        result.executionPlan = generateCalculationPlan(resolvedResult);
        
    case 'data_loading'
        result.action = 'load_data';
        result.message = sprintf('Loading data from %s source(s)', strjoin(availableModalities, ', '));
        result.executionPlan = generateDataLoadingPlan(resolvedResult);
        
    otherwise
        result.action = 'general_processing';
        result.message = sprintf('Processing multi-modal input from %s', strjoin(availableModalities, ', '));
        result.executionPlan = generateGeneralPlan(resolvedResult);
end

% Add conflict information if present
if resolvedResult.conflictDetected
    result.conflictResolution = struct();
    result.conflictResolution.detected = true;
    result.conflictResolution.conflictingIntents = resolvedResult.conflictingIntents;
    result.conflictResolution.resolutionMethod = 'confidence_weighted_voting';
end

% Summary statistics
result.processingStatistics = generateProcessingStatistics(resolvedResult);

end

function plan = generateVisualisationPlan(resolvedResult)
plan = struct();
plan.primaryAction = 'create_plot';
plan.dataSource = 'multi_modal_fusion';
plan.plotType = 'auto_detected';
plan.parameters = extractVisualisationParameters(resolvedResult);
end

function plan = generateAnalysisPlan(resolvedResult)
plan = struct();
plan.primaryAction = 'statistical_analysis';
plan.analysisType = 'comprehensive';
plan.parameters = extractAnalysisParameters(resolvedResult);
end

function plan = generateCalculationPlan(resolvedResult)
plan = struct();
plan.primaryAction = 'mathematical_computation';
plan.operationType = 'multi_modal_calculation';
plan.parameters = extractCalculationParameters(resolvedResult);
end

function plan = generateDataLoadingPlan(resolvedResult)
plan = struct();
plan.primaryAction = 'data_import';
plan.sourceType = 'multi_modal';
plan.parameters = extractDataLoadingParameters(resolvedResult);
end

function plan = generateGeneralPlan(resolvedResult)
plan = struct();
plan.primaryAction = 'general_processing';
plan.processingType = 'adaptive';
plan.parameters = struct();
end

function params = extractVisualisationParameters(resolvedResult)
params = struct();

% Extract parameters from different modalities
if isfield(resolvedResult, 'combinedEntities')
    entities = resolvedResult.combinedEntities;
    
    if isfield(entities, 'text') && isfield(entities.text, 'functions')
        params.functions = entities.text.functions;
    end
    
    if isfield(entities, 'data')
        params.dataSize = entities.data.dataCharacteristics;
    end
end

end

function params = extractAnalysisParameters(resolvedResult)
params = struct();
params.analysisType = 'comprehensive';
params.includeDescriptive = true;
params.includeInferential = true;
end

function params = extractCalculationParameters(resolvedResult)
params = struct();
 
 
 if isfield(resolvedResult, 'combinedEntities')
    entities = resolvedResult.combinedEntities;
    
    if isfield(entities, 'text') && isfield(entities.text, 'numbers')
        params.numbers = entities.text.numbers;
    end
    
    if isfield(entities, 'text') && isfield(entities.text, 'functions')
        params.functions = entities.text.functions;
    end
end

end

function params = extractDataLoadingParameters(resolvedResult)
params = struct();

if isfield(resolvedResult, 'modalityResults')
    if isfield(resolvedResult.modalityResults, 'file')
        params.filePath = resolvedResult.modalityResults.file.filePath;
        params.fileType = resolvedResult.modalityResults.file.fileType;
    end
end

end

function stats = generateProcessingStatistics(resolvedResult)
stats = struct();

if isfield(resolvedResult, 'modalityResults')
    modalities = fieldnames(resolvedResult.modalityResults);
    
    processingTimes = [];
    confidences = [];
    
    for i = 1:length(modalities)
        modalityResult = resolvedResult.modalityResults.*(modalities{i});
        
        if isfield(modalityResult, 'processingTime')
            processingTimes(end+1) = modalityResult.processingTime;
        end
        
        if isfield(modalityResult, 'confidence')
            confidences(end+1) = modalityResult.confidence;
        end
    end
    
    stats.totalProcessingTime = sum(processingTimes);
    stats.averageConfidence = mean(confidences);
    stats.modalityCount = length(modalities);
end

end
