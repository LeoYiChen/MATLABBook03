%% chapter_AI_MATLAB_Lab01_step01.m
% Function to define engineering specifications for the cantilever beam virtual prototyping exercise.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_Lab01_step01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function specifications = defineEngineeringSpecifications()
    % defineEngineeringSpecifications - Define all parameters for the
    % cantilever beam virtual prototyping exercise.
    %
    % Output:
    %   specifications - struct containing load, geometry, material,
    %                    constraint, and optimisation parameters.
    %
    % Author: Dr Yi Chen
    % Date:   2025
    % MATLAB: R2024b
    
    % Applied load configuration
    specifications.load.magnitude   = 1000;          % Applied force (N)
    specifications.load.type        = "point";        % Load type
    specifications.load.location    = "free_end";     % Load position
    
    % Beam geometry (fixed parameters)
    specifications.geometry.beamLength = 1.0;         % Beam length (m)
    
    % Material properties: Structural Steel (S275)
    specifications.material.name           = "Structural Steel S275";
    specifications.material.youngsModulus   = 200e9;   % Young's modulus (Pa)
    specifications.material.yieldStrength  = 275e6;    % Yield strength (Pa)
    specifications.material.density        = 7850;     % Density (kg/m^3)
    specifications.material.poissonsRatio  = 0.30;     % Poisson's ratio
    
    % Engineering constraints
    safetyFactor = 1.5;
    beamLength   = specifications.geometry.beamLength;
    
    specifications.constraints.maxDeflection    = beamLength / 250;
    specifications.constraints.safetyFactor     = safetyFactor;
    specifications.constraints.allowableStress  = ...
        specifications.material.yieldStrength / safetyFactor;
    specifications.constraints.utilisationTarget = 0.85;
    
    % Optimisation parameters
    specifications.optimisation.maxIterations        = 15;
    specifications.optimisation.reductionFactor      = 0.80;
    specifications.optimisation.convergenceTolerance = 0.01;
    
    % Initial design bounds (m)
    specifications.designBounds.minWidth  = 0.010;
    specifications.designBounds.minHeight = 0.020;
    specifications.designBounds.maxWidth  = 0.200;
    specifications.designBounds.maxHeight = 0.300;
    
    fprintf('Engineering specifications defined successfully.\n');
    fprintf('  Material         : %s\n', specifications.material.name);
    fprintf('  Applied load     : %.0f N at %s\n', ...
            specifications.load.magnitude, specifications.load.location);
    fprintf('  Max deflection   : %.4f m (L/250)\n', ...
            specifications.constraints.maxDeflection);
    fprintf('  Allowable stress : %.2f MPa (SF=%.1f)\n', ...
            specifications.constraints.allowableStress / 1e6, safetyFactor);
end
