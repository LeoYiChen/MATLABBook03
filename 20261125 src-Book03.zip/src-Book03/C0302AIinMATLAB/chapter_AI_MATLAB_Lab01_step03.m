%% chapter_AI_MATLAB_Lab01_step03.m
% Message routing function for inter-agent communication.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_Lab01_step03
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [message, communicationLog] = routeAgentMessage( ...
        senderID, recipientID, messageType, content, communicationLog)
    % routeAgentMessage - Construct, log, and route a standardised
    % message between agents in the virtual prototyping system.
    %
    % Inputs:
    %   senderID         - string identifier of the sending agent
    %   recipientID      - string identifier of the receiving agent
    %   messageType      - string describing the message category
    %   content          - struct with message payload
    %   communicationLog - existing communication log table
    %
    % Outputs:
    %   message          - constructed message struct
    %   communicationLog - updated communication log table
    %
    % Author: Dr Yi Chen
    % Date:   2025
    % MATLAB: R2024b
    
    % Construct standardised message
    message = struct();
    message.senderID    = senderID;
    message.recipientID = recipientID;
    message.type        = messageType;
    message.content     = content;
    message.timestamp   = datetime('now');
    message.messageID   = sprintf('MSG_%s_%06*d', ...
                          datestr(now, 'HHMMSSfff'), randi(999999));
    
    % Serialise content summary for the log
    contentSummary = truncateString(jsonencode(content), 80);
    
    % Append to communication log
    newRow = {message.timestamp, string(senderID), ...
              string(recipientID), string(messageType), ...
              string(contentSummary), "delivered"};
    communicationLog = [communicationLog; newRow];
    
    % Print communication trace
    fprintf('  [COMM] %s -> %s : %s\n', ...
            senderID, recipientID, messageType);
end

function truncated = truncateString(inputStr, maxLength)
    % truncateString - Truncate a string to a maximum length for display.
    if strlength(inputStr) > maxLength
        truncated = extractBefore(inputStr, maxLength + 1) + "...";
    else
        truncated = string(inputStr);
    end
end
