%% chapter_AI_MATLAB_Lab01_step09.m
% Visualisation functions for optimisation convergence and beam deflection profile.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_Lab01_step09
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function visualiseOptimisationConvergence(workflowResults)
    % visualiseOptimisationConvergence - Generate four-panel
    % convergence plot from the multi-agent workflow.
    %
    % Author: Dr Yi Chen
    % Date:   2025
    % MATLAB: R2024b
    
    history = workflowResults.iterationHistory;
    
    figure('Name', 'Optimisation Convergence', ...
           'Position', [100 100 900 700]);
    
    % Panel 1: Mass convergence
    subplot(2, 2, 1);
    plot(history.Iteration, history.Mass_kg, '-o', ...
         'LineWidth', 1.5, 'MarkerFaceColor', [0.2 0.4 0.8]);
    xlabel('Iteration'); ylabel('Mass (kg)');
    title('Beam Mass Convergence'); grid on;
    
    % Panel 2: Deflection convergence
    subplot(2, 2, 2);
    plot(history.Iteration, history.Deflection_mm, '-s', ...
         'LineWidth', 1.5, 'MarkerFaceColor', [0.8 0.2 0.2]);
    hold on;
    yline(4.0, '-r', 'Limit = 4.0 mm', 'LineWidth', 1.2);
    hold off;
    xlabel('Iteration'); ylabel('Max Deflection (mm)');
    title('Deflection Convergence'); grid on;
    
    % Panel 3: Stress convergence
    subplot(2, 2, 3);
    plot(history.Iteration, history.Stress_MPa, '-d', ...
         'LineWidth', 1.5, 'MarkerFaceColor', [0.2 0.7 0.3]);
    hold on;
    yline(183.33, '-r', 'Limit = 183.3 MPa', 'LineWidth', 1.2);
    hold off;
    xlabel('Iteration'); ylabel('Max Stress (MPa)');
    title('Stress Convergence'); grid on;
    
    % Panel 4: Utilisation convergence
    subplot(2, 2, 4);
    plot(history.Iteration, history.Utilisation, '-^', ...
         'LineWidth', 1.5, 'MarkerFaceColor', [0.7 0.5 0.1]);
    hold on;
    yline(0.85, '-g', 'Target = 0.85', 'LineWidth', 1.2);
    yline(1.00, '-r', 'Limit = 1.00', 'LineWidth', 1.2);
    hold off;
    xlabel('Iteration'); ylabel('Utilisation Ratio');
    title('Design Utilisation Convergence'); grid on;
    
    sgtitle('Multi-Agent Virtual Prototyping: Convergence');
end

function visualiseBeamDeflection(workflowResults)
    % visualiseBeamDeflection - Plot the deflection profile of the
    % final optimised cantilever beam.
    %
    % Author: Dr Yi Chen
    % Date:   2025
    % MATLAB: R2024b
    
    simResults = workflowResults.finalSimulation;
    design     = workflowResults.finalDesign;
    
    figure('Name', 'Beam Deflection Profile', ...
           'Position', [150 150 800 400]);
    
    positionMetres = simResults.positionAlongBeam;
    deflectionMM   = simResults.deflectionProfile * 1000;
    
    plot(positionMetres, deflectionMM, '-b', 'LineWidth', 2);
    hold on;
    plot(positionMetres(end), deflectionMM(end), 'ro', ...
         'MarkerSize', 10, 'MarkerFaceColor', 'r');
    text(positionMetres(end) * 0.70, deflectionMM(end) * 1.15, ...
         sprintf('Max = %.3f mm', deflectionMM(end)), ...
         'FontSize', 10, 'Color', 'r');
    hold off;
    
    xlabel('Position along beam (m)');
    ylabel('Deflection (mm)');
    title(sprintf('Deflection Profile: b=%.1f mm, h=%.1f mm', ...
          design.width * 1000, design.height * 1000));
    grid on;
    legend('Deflection curve', 'Max deflection', ...
           'Location', 'northwest');
end
