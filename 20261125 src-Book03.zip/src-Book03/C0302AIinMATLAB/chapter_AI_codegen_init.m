%% chapter_AI_codegen_init.m
% Code generation system initialisation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_codegen_init
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function codeGenerator = createCodeGenerator()
codeGenerator.semanticParser = SemanticParser();
codeGenerator.templateLibrary = CodeTemplateLibrary();
codeGenerator.syntaxValidator = SyntaxValidator();
end
