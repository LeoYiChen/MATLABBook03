%% chapter_AI_MATLAB_Lab01_step10.m
% Main script and report generation function for the virtual prototyping laboratory.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_Lab01_step10
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% AIi4Book01_ChapterAI_Lab01_Main.m
% Multi-Agent Virtual Prototyping Integration Automation
% Laboratory Exercise: Cantilever Beam Optimisation
%
% This script executes the complete multi-agent workflow for
% designing, simulating, analysing, and optimising a cantilever beam.
%
% Author: Dr Yi Chen
% Date:   2025
% MATLAB: R2024b

clc; close all; clear;

% Step 1: Define engineering specifications
specifications = defineEngineeringSpecifications();

% Steps 2-8: Execute the multi-agent workflow
workflowResults = executePrototypingWorkflow(specifications);

% Step 9: Visualise results
visualiseOptimisationConvergence(workflowResults);
visualiseBeamDeflection(workflowResults);

% Step 10: Generate engineering report
generateEngineeringReport(workflowResults, specifications);

% Display iteration history table
fprintf('\n- Iteration History Table -\n');
disp(workflowResults.iterationHistory);

% Display communication log (first 10 entries)
fprintf('\n- Communication Log (first 10 entries) -\n');
displayRows = min(10, height(workflowResults.communicationLog));
disp(workflowResults.communicationLog(1:displayRows, :));

function generateEngineeringReport(workflowResults, specifications)
    % generateEngineeringReport - Produce a text-based summary.
    %
    % Author: Dr Yi Chen
    % Date:   2025
    % MATLAB: R2024b
    
    fprintf('\n');
    fprintf('============================================\n');
    fprintf('     ENGINEERING REPORT: VIRTUAL PROTOTYPE  \n');
    fprintf('============================================\n');
    fprintf('Date: %s\n', datestr(datetime('now')));
    
    fprintf('\n- Specifications -\n');
    fprintf('Material          : %s\n', ...
            specifications.material.name);
    fprintf('Young''s modulus   : %.0f GPa\n', ...
            specifications.material.youngsModulus / 1e9);
    fprintf('Yield strength    : %.0f MPa\n', ...
            specifications.material.yieldStrength / 1e6);
    fprintf('Applied load      : %.0f N\n', ...
            specifications.load.magnitude);
    fprintf('Beam length       : %.2f m\n', ...
            specifications.geometry.beamLength);
    fprintf('Max deflection    : %.4f m (L/250)\n', ...
            specifications.constraints.maxDeflection);
    fprintf('Allowable stress  : %.2f MPa (SF=%.1f)\n', ...
            specifications.constraints.allowableStress / 1e6, ...
            specifications.constraints.safetyFactor);
    
    fprintf('\n- Optimisation Summary -\n');
    initialMass = ...
        workflowResults.iterationHistory.Mass_kg(1);
    finalMass = workflowResults.finalDesign.mass;
    fprintf('Initial mass      : %.2f kg\n', initialMass);
    fprintf('Final mass        : %.2f kg\n', finalMass);
    fprintf('Mass reduction    : %.1f%%\n', ...
            workflowResults.massReduction);
    fprintf('Total iterations  : %d\n', ...
            workflowResults.totalIterations);
    
    fprintf('\n- Final Design -\n');
    finalDesign = workflowResults.finalDesign;
    fprintf('Width  (b)        : %.4f m (%.1f mm)\n', ...
            finalDesign.width, finalDesign.width * 1000);
    fprintf('Height (h)        : %.4f m (%.1f mm)\n', ...
            finalDesign.height, finalDesign.height * 1000);
    fprintf('Moment of inertia : %.4e m^4\n', ...
            finalDesign.momentOfInertia);
    
    fprintf('\n- Final Structural Response -\n');
    finalSim = workflowResults.finalSimulation;
    fprintf('Max deflection    : %.3f mm\n', ...
            finalSim.maxDeflection * 1000);
    fprintf('Max stress        : %.2f MPa\n', ...
            finalSim.maxStress / 1e6);
    
    fprintf('\n- Communication Statistics -\n');
    fprintf('Total messages    : %d\n', ...
            workflowResults.totalMessages);
    fprintf('Unique senders    : %d\n', ...
            numel(unique( ...
            workflowResults.communicationLog.SenderID)));
    
    fprintf('\n- Verdict: %s -\n', ...
            workflowResults.finalAnalysis.designVerdict);
    fprintf('============================================\n');
end
