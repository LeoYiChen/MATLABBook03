%% chapter_AIinMATLAB_Integration_example_02.m
% Exporting a MATLAB-trained network to the ONNX format for use in external frameworks.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AIinMATLAB_Integration_example_02
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Assume 'trainedNet' is a network trained in MATLAB
% Export the network to an ONNX file
exportONNXNetwork(trainedNet, 'trained_model.onnx');

% Verify the export by re-importing the model
reimportedNet = importONNXNetwork('trained_model.onnx', ...
    'OutputLayerType', 'classification');
analyzeNetwork(reimportedNet);
