%% chapter_AI_doc_setup.m
% Document-based task specification setup.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_doc_setup
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function taskSystem = createDocumentTaskSystem()
taskSystem.parsers = containers.Map();
taskSystem.validators = containers.Map();
taskSystem.executors = containers.Map();
end
