%% chapter_AI_MATLAB_example_12.m
% Deploying a Deep Learning Model to Production
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_example_12
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Generate C++ code for trained network
cfg = coder.config('mex');
cfg.TargetLang = 'C++';
cfg.DeepLearningConfig = coder.DeepLearningConfig('TargetLibrary', 'mkldnn');
cfg.IntegrityChecks = false;
cfg.GenerateReport = true;
cfg.EnableOpenMP = true;

% Define entry-point function

% Generate standalone C++ code
codegen -config cfg detectObjects -args {zeros(720, 1280, 3, 'uint8')} -report

% Package as a deployable library
% (Additional MATLAB Compiler steps would be included here)

% Local functions (moved to end so this listing is a valid MATLAB script)
function detections = detectObjects(img)
    persistent detector;
    if isempty(detector)
        detector = yolov2ObjectDetector('tiny-yolov2-coco');
    end
    [bboxes, scores, labels] = detect(detector, img);
    detections = table(bboxes, scores, labels);
end
