%% chapter_AI_interactive_complete.m
% Interactive natural language query interface.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_interactive_complete
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function queryInterface = interactiveNaturalLanguageQuery()
% Interactive Natural Language Query Interface
% Author: Dr Yi Chen
% Version: 1.0
% Description: Conversational interface with context awareness and learning

% Initialise interface components
queryInterface = struct();
queryInterface.conversationHistory = {};
queryInterface.context = struct();
queryInterface.currentData = [];
queryInterface.userPreferences = struct();
queryInterface.suggestionEngine = initSuggestionEngine();

% Start interactive session
fprintf('=== Interactive Natural Language Query Interface ===\n');
fprintf('Type your questions about data analysis, visualisation, or calculations.\n');
fprintf('Type "exit" to quit, "help" for assistance, "context" to see current context.\n\n');

while true
    userInput = input('You: ', 's');
    
    if strcm*pi(userInput, 'exit')
        fprintf('Goodbye. Session ended.\n');
        break;
    elseif strcm*pi(userInput, 'help')
        displayHelp();
        continue;
    elseif strcm*pi(userInput, 'context')
        displayContext(queryInterface.context);
        continue;
    elseif isempty(strtrim(userInput))
        continue;
    end
    
    % Process the query
    response = processQuery(queryInterface, userInput);
    
    % Display response
    fprintf('Assistant: %s\n\n', response.message);
    
    % Show suggestions if available
    if ~isempty(response.suggestions)
        fprintf('Suggestions: %s\n\n', strjoin(response.suggestions, ', '));
    end
    
    % Update conversation history
    queryInterface.conversationHistory{end+1} = struct('user', userInput, 'assistant', response.message, 'timestamp', datetime('now'));
    
    % Update context
    queryInterface.context = updateContext(queryInterface.context, userInput, response);
end

end

function response = processQuery(interface, userQuery)
% Process user query with context awareness
response = struct();
response.success = true;
response.suggestions = {};

try
    % Analyse the query
    queryAnalysis = analyseQuery(userQuery, interface.context);
    
    % Execute the query
    executionResult = executeQueryWithContext(queryAnalysis, interface);
    
    % Generate response
    response.message = generateContextualResponse(queryAnalysis, executionResult);
    response.data = executionResult.data;
    response.queryType = queryAnalysis.intent;
    
    % Generate suggestions
    response.suggestions = generateSuggestions(queryAnalysis, interface.context);
    
catch ME
    response.success = false;
    response.message = sprintf('I encountered an error: %s. Could you rephrase your question?', ME.message);
    response.suggestions = {'Try a simpler question', 'Check your data format', 'Ask for help'};
end

end

function queryAnalysis = analyseQuery(query, context)
queryAnalysis = struct();

% Tokenise and preprocess
tokens = tokeniseQuery(query);

% Classify intent with confidence
[intent, confidence] = classifyIntentWithConfidence(tokens, context);
queryAnalysis.intent = intent;
queryAnalysis.confidence = confidence;

% Extract entities
entities = extractEntitiesAdvanced(tokens, context);
queryAnalysis.entities = entities;

% Detect references to previous context
contextReferences = detectContextReferences(tokens, context);
queryAnalysis.contextReferences = contextReferences;

% Determine query complexity
queryAnalysis.complexity = assessQueryComplexity(tokens, entities);

queryAnalysis.originalQuery = query;
queryAnalysis.tokens = tokens;

end

function tokens = tokeniseQuery(query)
% Advanced tokenisation with preprocessing
query = lower(strtrim(query));

% Handle contractions
query = regexprep(query, "can't", 'cannot');
query = regexprep(query, "won't", 'will not');
query = regexprep(query, "n't", ' not');

% Split into tokens
tokens = strsplit(query, {' ', ',', '.', '?', '.'});
tokens = tokens(~cellfun('isempty', tokens));

end

function [intent, confidence] = classifyIntentWithConfidence(tokens, context)
% Intent classification with confidence scoring
intentScores = containers.Map();

% Define intent keywords with weights
intentKeywords = struct();
intentKeywords.visualisation = struct('keywords', {{'plot', 'graph', 'chart', 'visualise', 'show', 'display'}}, 'weight', 1.0);
intentKeywords.analysis = struct('keywords', {{'analyse', 'analyze', 'statistics', 'stats', 'summary', 'describe'}}, 'weight', 1.0);
intentKeywords.calculation = struct('keywords', {{'calculate', 'compute', 'find', 'determine', 'solve'}}, 'weight', 1.0);
intentKeywords.data_operation = struct('keywords', {{'load', 'save', 'import', 'export', 'filter', 'sort'}}, 'weight', 1.0);
intentKeywords.comparison = struct('keywords', {{'compare', 'difference', 'versus', 'between', 'against'}}, 'weight', 1.0);
intentKeywords.prediction = struct('keywords', {{'predict', 'forecast', 'estimate', 'model', 'trend'}}, 'weight', 1.0);

intents = fieldnames(intentKeywords);

% Calculate scores for each intent
for i = 1:length(intents)
    intentName = intents{i};
    keywords = intentKeywords.*(intentName).keywords;
    weight = intentKeywords.*(intentName).weight;
    
    score = 0;
    for j = 1:length(keywords)
        if any(strcmp(tokens, keywords{j}))
            score = score + weight;
        end
    end
    
    % Context boost
    if isfield(context, 'lastIntent') && strcmp(context.lastIntent, intentName)
        score = score + 0.3; % Boost for intent continuity
    end
    
    intentScores(intentName) = score;
end

% Find the intent with highest score
scores = cell2mat(values(intentScores));
[maxScore, maxIdx] = max(scores);
intentNames = keys(intentScores);

if maxScore > 0
    intent = intentNames{maxIdx};
    confidence = min(maxScore / 3, 1.0); % Normalise confidence
else
    intent = 'general';
    confidence = 0.1;
end

end

function entities = extractEntitiesAdvanced(tokens, context)
entities = struct();

% Extract numbers
numbers = [];
for i = 1:length(tokens)
    num = str2double(tokens{i});
    if ~isnan(num)
        numbers(end+1) = num;
    end
end
entities.numbers = numbers;

% Extract mathematical functions
mathFunctions = {'sin', 'cos', 'tan', 'exp', 'log', 'sqrt', 'mean', 'std', 'sum', 'max', 'min'};
entities.functions = intersect(tokens, mathFunctions);

% Extract data references
dataReferences = {'data', 'dataset', 'values', 'points', 'observations', 'samples'};
entities.dataReferences = intersect(tokens, dataReferences);

% Extract comparison terms
comparisonTerms = {'higher', 'lower', 'greater', 'less', 'above', 'below', 'better', 'worse'};
entities.comparisons = intersect(tokens, comparisonTerms);

% Extract time references
timeReferences = {'yesterday', 'today', 'tomorrow', 'last', 'next', 'previous', 'recent'};
entities.timeReferences = intersect(tokens, timeReferences);

% Extract column/variable references from context
if isfield(context, 'availableColumns')
    entities.columnReferences = intersect(tokens, context.availableColumns);
end

end

function contextRefs = detectContextReferences(tokens, context)
contextRefs = struct();

% References to previous results
previousResultRefs = {'it', 'that', 'this', 'previous', 'last', 'result'};
contextRefs.previousResults = intersect(tokens, previousResultRefs);

% References to current data
currentDataRefs = {'current', 'existing', 'loaded', 'available'};
contextRefs.currentData = intersect(tokens, currentDataRefs);

% Determine if query is a follow-up
followUpIndicators = {'also', 'additionally', 'furthermore', 'moreover', 'then', 'next'};
contextRefs.isFollowUp = ~isempty(intersect(tokens, followUpIndicators));

end

function complexity = assessQueryComplexity(tokens, entities)
% Simple complexity assessment
complexity = 'simple';

complexityScore = 0;

% Add points for various complexity indicators
if length(tokens) > 10
    complexityScore = complexityScore + 1;
end

if length(entities.functions) > 1
    complexityScore = complexityScore + 1;
end

if ~isempty(entities.comparisons)
    complexityScore = complexityScore + 1;
end

if complexityScore >= 2
    complexity = 'complex';
elseif complexityScore >= 1
    complexity = 'moderate';
end

end

function result = executeQueryWithContext(queryAnalysis, interface)
result = struct();

switch queryAnalysis.intent
    case 'visualisation'
        result = executeVisualisationQuery(queryAnalysis, interface);
    case 'analysis'
        result = executeAnalysisQuery(queryAnalysis, interface);
    case 'calculation'
        result = executeCalculationQuery(queryAnalysis, interface);
    case 'data_operation'
        result = executeDataOperationQuery(queryAnalysis, interface);
    case 'comparison'
        result = executeComparisonQuery(queryAnalysis, interface);
    case 'prediction'
        result = executePredictionQuery(queryAnalysis, interface);
    otherwise
        result = executeGeneralQuery(queryAnalysis, interface);
end

result.intent = queryAnalysis.intent;
result.confidence = queryAnalysis.confidence;

end

function result = executeVisualisationQuery(queryAnalysis, interface)
result = struct();

% Get or generate data
if isempty(interface.currentData)
    data = randn(100, 2); % Generate sample data
    interface.currentData = data;
else
    data = interface.currentData;
end

% Determine plot type from entities
if any(strcmp(queryAnalysis.entities.functions, 'sin')) || any(strcmp(queryAnalysis.entities.functions, 'cos'))
    % Function plot
    x = linspace(0, 2*pi, 100);
    if any(strcmp(queryAnalysis.entities.functions, 'sin'))
        y = sin(x);
        plotTitle = 'Sine Function';
    else
        y = cos(x);
        plotTitle = 'Cosine Function';
    end
    
    figure;
    plot(x, y, 'LineWidth', 2);
    title(plotTitle);
    xlabel('x');
    ylabel('y');
    grid on;
    
    result.plotType = 'function';
    result.data = [x', y'];
    
else
    % Data plot
    figure;
    if size(data, 2) >= 2
        scatter(data(:,1), data(:,2), 'filled');
        title('Data Scatter Plot');
        xlabel('Variable 1');
        ylabel('Variable 2');
    else
        histogram(data(:,1), 20);
        title('Data Distribution');
        xlabel('Value');
        ylabel('Frequency');
    end
    grid on;
    
    result.plotType = 'data';
    result.data = data;
end

result.success = true;

end

function result = executeAnalysisQuery(queryAnalysis, interface)
result = struct();

% Get data for analysis
if isempty(interface.currentData)
    data = randn(200, 1);
    interface.currentData = data;
else
    data = interface.currentData(:,1); % Use first column
end

% Perform statistical analysis
analysis = struct();
analysis.count = length(data);
analysis.mean = mean(data);
analysis.median = median(data);
analysis.std = std(data);
analysis.variance = var(data);
analysis.min = min(data);
analysis.max = max(data);
analysis.range = range(data);
analysis.skewness = skewness(data);
analysis.kurtosis = kurtosis(data);
analysis.quartiles = prctile(data, [25, 50, 75]);

result.analysis = analysis;
result.data = data;
result.success = true;

end

function result = executeCalculationQuery(queryAnalysis, interface)
result = struct();

if ~isempty(queryAnalysis.entities.numbers)
    numbers = queryAnalysis.entities.numbers;
    
    calculations = struct();
    calculations.sum = sum(numbers);
    calculations.product = prod(numbers);
    calculations.mean = mean(numbers);
    calculations.std = std(numbers);
    calculations.max = max(numbers);
    calculations.min = min(numbers);
    
    if ~isempty(queryAnalysis.entities.functions)
        func = queryAnalysis.entities.functions{1};
        switch func
            case 'sqrt'
                calculations.sqrt_values = sqrt(abs(numbers));
            case 'exp'
                calculations.exp_values = exp(numbers);
            case 'log'
                calculations.log_values = log(abs(numbers) + eps);
        end
    end
    
    result.calculations = calculations;
    result.inputNumbers = numbers;
    
else
    % Generate sample calculation
    x = 1:10;
    result.calculations = struct('sum', sum(x), 'mean', mean(x));
    result.inputNumbers = x;
end

result.success = true;

end

function result = executeDataOperationQuery(queryAnalysis, interface)
result = struct();

% Generate or manipulate data based on query
if isempty(interface.currentData)
    % Generate new dataset
    numSamples = 100;
    numVariables = 3;
    data = randn(numSamples, numVariables);
    interface.currentData = data;
    
    result.operation = 'generate';
    result.dataSize = size(data);
    
else
    % Perform operation on existing data
    data = interface.currentData;
    
    if any(contains(queryAnalysis.tokens, 'sort'))
        data = sort(data);
        result.operation = 'sort';
    elseif any(contains(queryAnalysis.tokens, 'filter'))
        % Simple filter: remove outliers
        data = data(abs(data(:,1)) < 2*std(data(:,1)), :);
        result.operation = 'filter';
    else
        result.operation = 'access';
    end
    
    interface.currentData = data;
    result.dataSize = size(data);
end

result.data = data;
result.success = true;

end

function result = executeComparisonQuery(queryAnalysis, interface)
result = struct();

% Generate two datasets for comparison
data1 = randn(50, 1) + 1; % Slightly higher mean
data2 = randn(50, 1);

comparison = struct();
comparison.mean1 = mean(data1);
comparison.mean2 = mean(data2);
comparison.meanDifference = comparison.mean1 - comparison.mean2;
comparison.std1 = std(data1);
comparison.std2 = std(data2);

% Perform t-test
[h, p] = ttest2(data1, data2);
comparison.ttest_significant = h;
comparison.ttest_pvalue = p;

result.comparison = comparison;
result.data1 = data1;
result.data2 = data2;
result.success = true;

end

function result = executePredictionQuery(queryAnalysis, interface)
result = struct();

% Generate sample time series for prediction
t = 1:50;
trend = 0.1 * t;
seasonal = sin(2*pi*t/12);
noise = 0.2 * randn(size(t));
data = trend + seasonal + noise;

% Simple linear prediction
p = polyfit(t, data, 1);
futureT = 51:60;
prediction = polyval(p, futureT);

result.historicalData = data;
result.prediction = prediction;
result.futureTimePoints = futureT;
result.model = 'linear';
result.success = true;

end

function result = executeGeneralQuery(queryAnalysis, interface)
result = struct();
result.message = 'I can help with data analysis, visualisation, calculations, and more. What would you like to explore?';
result.success = true;
end

function message = generateContextualResponse(queryAnalysis, executionResult)
switch queryAnalysis.intent
case 'visualisation'
if executionResult.success
message = sprintf('I''ve created a %s plot for you. The visualisation shows the relationship in your data.', executionResult.plotType);
else
message = 'I had trouble creating the visualisation. Please check your data format.';
end

case 'analysis'
        if executionResult.success
            analysis = executionResult.analysis;
            message = sprintf('Here''s the analysis: Mean = %.3f, Std = %.3f, Range = [%.3f, %.3f]. The data has %d observations.', ...
                analysis.mean, analysis.std, analysis.min, analysis.max, analysis.count);
        else
            message = 'I couldn''t complete the analysis. Please ensure you have valid data.';
        end
        
    case 'calculation'
        if executionResult.success
            calc = executionResult.calculations;
            message = sprintf('Calculations complete: Sum = %.3f, Mean = %.3f, Max = %.3f, Min = %.3f', ...
                calc.sum, calc.mean, calc.max, calc.min);
        else
            message = 'I encountered an issue with the calculations. Please check your numbers.';
        end
        
    case 'data_operation'
        if executionResult.success
            message = sprintf('Data operation ''%s'' completed. Dataset now has %d rows and %d columns.', ...
                executionResult.operation, executionResult.dataSize(1), executionResult.dataSize(2));
        else
            message = 'The data operation couldn''t be completed.';
        end
        
    case 'comparison'
        if executionResult.success
            comp = executionResult.comparison;
            significance = '';
            if comp.ttest_significant
                significance = 'statistically significant';
            else
                significance = 'not statistically significant';
            end
            message = sprintf('Comparison results: Mean difference = %.3f. The difference is %s (p = %.3f).', ...
                comp.meanDifference, significance, comp.ttest_pvalue);
        else
            message = 'I couldn''t complete the comparison analysis.';
        end
        
    case 'prediction'
        if executionResult.success
            message = sprintf('I''ve generated predictions using a %s model. The forecast shows the expected trend.', ...
                executionResult.model);
        else
            message = 'Prediction generation failed. Please check your time series data.';
        end
        
    otherwise
        message = 'I''ve processed your request. How else can I help you explore your data?';
end

end

function suggestions = generateSuggestions(queryAnalysis, context)
suggestions = {};

switch queryAnalysis.intent
    case 'visualisation'
        suggestions = {'Try a different plot type', 'Analyse the data statistically', 'Compare with other datasets'};
        
    case 'analysis'
        suggestions = {'Create a visualisation', 'Perform hypothesis testing', 'Check for correlations'};
        
    case 'calculation'
        suggestions = {'Visualise the results', 'Compare with expected values', 'Perform sensitivity analysis'};
        
    case 'data_operation'
        suggestions = {'Analyse the processed data', 'Create summary statistics', 'Visualise data distribution'};
        
    case 'comparison'
        suggestions = {'Visualise the comparison', 'Try different statistical tests', 'Explore effect sizes'};
        
    case 'prediction'
        suggestions = {'Validate the model', 'Try different prediction methods', 'Analyse residuals'};
        
    otherwise
        suggestions = {'Load some data', 'Try data analysis', 'Create visualisations', 'Perform calculations'};
end

end

function context = updateContext(context, userQuery, response)
% Update conversation context
context.lastQuery = userQuery;
context.lastIntent = response.queryType;
context.lastSuccess = response.success;

% Update data context
if isfield(response, 'data') && ~isempty(response.data)
    context.hasData = true;
    context.dataSize = size(response.data);
end

% Track query patterns
if ~isfield(context, 'queryCount')
    context.queryCount = 0;
end
context.queryCount = context.queryCount + 1;

% Update timestamp
context.lastUpdate = datetime('now');

end

function displayHelp()
fprintf('\n=== Help Information ===\n');
fprintf('You can ask me to:\n');
fprintf('? Create plots and visualisations: "plot a sine wave", "show histogram of data"\n');
fprintf('? Perform analysis: "analyse the data", "calculate statistics"\n');
fprintf('? Do calculations: "find the mean of 1 2 3 4 5", "compute square root of 16"\n');
fprintf('? Handle data: "load dataset", "filter the data", "sort values"\n');
fprintf('? Make comparisons: "compare two groups", "test for differences"\n');
fprintf('? Generate predictions: "forecast future values", "predict trends"\n');
fprintf('\nSpecial commands:\n');
fprintf('? "context" - Show current conversation context\n');
fprintf('? "exit" - End the session\n\n');
end

function displayContext(context)
fprintf('\n=== Current Context ===\n');
if isfield(context, 'lastIntent')
fprintf('Last intent: %s\n', context.lastIntent);
end
if isfield(context, 'hasData') && context.hasData
fprintf('Data loaded: Yes (%dx%d)\n', context.dataSize(1), context.dataSize(2));
else
fprintf('Data loaded: No\n');
end
if isfield(context, 'queryCount')
fprintf('Queries processed: %d\n', context.queryCount);
end
fprintf('\n');
end

function suggestionEngine = initSuggestionEngine()
% Initialise suggestion engine with learning capabilities
suggestionEngine = struct();
suggestionEngine.userPatterns = containers.Map();
suggestionEngine.commonFollowUps = containers.Map();
suggestionEngine.successfulSequences = {};
end
