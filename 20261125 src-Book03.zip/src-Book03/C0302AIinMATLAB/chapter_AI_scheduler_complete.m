%% chapter_AI_scheduler_complete.m
% Complete autonomous task scheduler.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_scheduler_complete
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
classdef AutonomousTaskScheduler < handle
    % Autonomous Task Scheduler
    % Author: Dr Yi Chen
    % Version: 1.0
    
    properties
        taskQueue
        completedTasks
        failedTasks
        resourceMonitor
        performanceMetrics
        schedulingPolicy
        maxConcurrentTasks
    end
    
    methods
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    end
end

classdef ResourceMonitor < handle
    properties
        availableMemory
        availableCPU
        allocatedResources
    end
    
    methods
        
        
        
    end
end

classdef PerformanceMetrics < handle
    properties
        startTime
        taskThroughput
        resourceUtilisation
        errorRate
    end
    
    methods
        
        
    end
end

% Local functions (moved to end so this listing is a valid MATLAB script)
        function obj = AutonomousTaskScheduler()
            obj.taskQueue = {};
            obj.completedTasks = {};
            obj.failedTasks = {};
            obj.resourceMonitor = ResourceMonitor();
            obj.performanceMetrics = PerformanceMetrics();
            obj.schedulingPolicy = 'priority_first';
            obj.maxConcurrentTasks = 3;
        end

        function addTask(obj, task)
            % Add task to queue with validation
            validatedTask = obj.validateTask(task);
            obj.taskQueue{end+1} = validatedTask;
            obj.sortTaskQueue();
            fprintf('Task added: %s (Priority: %d)\n', task.name, task.priority);
        end

        function validatedTask = validateTask(obj, task)
            validatedTask = task;
            
            % Set default values if missing
            if ~isfield(task, 'priority')
                validatedTask.priority = 5; % Medium priority
            end
            
            if ~isfield(task, 'estimatedDuration')
                validatedTask.estimatedDuration = 60; % 60 seconds default
            end
            
            if ~isfield(task, 'resourceRequirements')
                validatedTask.resourceRequirements = struct('memory', 100, 'cpu', 50);
            end
            
            if ~isfield(task, 'dependencies')
                validatedTask.dependencies = {};
            end
            
            validatedTask.status = 'pending';
            validatedTask.addedTime = datetime('now');
        end

        function sortTaskQueue(obj)
            if isempty(obj.taskQueue)
                return;
            end
            
            priorities = cellfun(@(t) t.priority, obj.taskQueue);
            addedTimes = cellfun(@(t) t.addedTime, obj.taskQueue);
            
            switch obj.schedulingPolicy
                case 'priority_first'
                    [~, sortIdx] = sort(priorities, 'descend');
                case 'fifo'
                    [~, sortIdx] = sort(addedTimes);
                case 'shortest_first'
                    durations = cellfun(@(t) t.estimatedDuration, obj.taskQueue);
                    [~, sortIdx] = sort(durations);
                otherwise
                    sortIdx = 1:length(obj.taskQueue);
            end
            
            obj.taskQueue = obj.taskQueue(sortIdx);
        end

        function runScheduler(obj, duration)
            % Run autonomous scheduler for specified duration
            startTime = datetime('now');
            runningTasks = {};
            
            fprintf('Starting autonomous scheduler for %d seconds...\n', duration);
            
            while datetime('now') - startTime < seconds(duration)
                % Check completed running tasks
                runningTasks = obj.checkCompletedTasks(runningTasks);
                
                % Start new tasks if resources available
                if length(runningTasks) < obj.maxConcurrentTasks && ~isempty(obj.taskQueue)
                    newTask = obj.selectNextTask();
                    if ~isempty(newTask)
                        runningTask = obj.startTask(newTask);
                        if ~isempty(runningTask)
                            runningTasks{end+1} = runningTask;
                        end
                    end
                end
                
                % Update performance metrics
                obj.performanceMetrics.update(obj);
                
                % Brief pause
                pause(0.1);
            end
            
            fprintf('Scheduler stopped. Completed: %d, Failed: %d, Remaining: %d\n', ...
                length(obj.completedTasks), length(obj.failedTasks), length(obj.taskQueue));
        end

        function task = selectNextTask(obj)
            task = [];
            
            for i = 1:length(obj.taskQueue)
                candidate = obj.taskQueue{i};
                
                % Check dependencies
                if obj.areDependenciesMet(candidate)
                    % Check resource availability
                    if obj.resourceMonitor.areResourcesAvailable(candidate.resourceRequirements)
                        task = candidate;
                        obj.taskQueue(i) = [];
                        break;
                    end
                end
            end
        end

        function met = areDependenciesMet(obj, task)
            met = true;
            
            for i = 1:length(task.dependencies)
                depName = task.dependencies{i};
                completed = any(cellfun(@(t) strcmp(t.name, depName), obj.completedTasks));
                if ~completed
                    met = false;
                    break;
                end
            end
        end

        function runningTask = startTask(obj, task)
            runningTask = [];
            
            try
                % Allocate resources
                obj.resourceMonitor.allocateResources(task.resourceRequirements);
                
                % Start task execution
                task.status = 'running';
                task.startTime = datetime('now');
                task.worker = obj.createTaskWorker(task);
                
                runningTask = task;
                fprintf('Started task: %s\n', task.name);
                
            catch ME
                fprintf('Failed to start task %s: %s\n', task.name, ME.message);
                task.status = 'failed';
                task.error = ME.message;
                obj.failedTasks{end+1} = task;
            end
        end

        function worker = createTaskWorker(obj, task)
            % Create background worker for task execution
            worker = struct();
            worker.task = task;
            worker.startTime = datetime('now');
            worker.isComplete = false;
            worker.result = [];
            
            % Simulate task execution based on type
            switch task.type
                case 'data_processing'
                    worker.result = obj.executeDataProcessingTask(task);
                case 'analysis'
                    worker.result = obj.executeAnalysisTask(task);
                case 'calculation'
                    worker.result = obj.executeCalculationTask(task);
                case 'file_operation'
                    worker.result = obj.executeFileOperationTask(task);
                otherwise
                    worker.result = obj.executeGenericTask(task);
            end
            
            worker.isComplete = true;
            worker.completionTime = datetime('now');
        end

        function result = executeDataProcessingTask(obj, task)
            % Simulate data processing
            result = struct();
            result.taskType = 'data_processing';
            
            % Generate or load data
            if isfield(task, 'inputData')
                data = task.inputData;
            else
                data = randn(1000, 3);
            end
            
            % Process data
            processedData = normalize(data);
            
            result.originalSize = size(data);
            result.processedSize = size(processedData);
            result.processingTime = task.estimatedDuration;
            result.outputData = processedData;
            
            % Simulate processing time
            pause(task.estimatedDuration / 10); % Scaled down for demo
        end

        function result = executeAnalysisTask(obj, task)
            result = struct();
            result.taskType = 'analysis';
            
            % Generate sample data
            data = randn(500, 1);
            
            % Perform analysis
            result.statistics = struct();
            result.statistics.mean = mean(data);
            result.statistics.std = std(data);
            result.statistics.min = min(data);
            result.statistics.max = max(data);
            result.statistics.count = length(data);
            
            pause(task.estimatedDuration / 10);
        end

        function result = executeCalculationTask(obj, task)
            result = struct();
            result.taskType = 'calculation';
            
            % Perform mathematical calculations
            x = 1:100;
            result.calculations = struct();
            result.calculations.sum = sum(x);
            result.calculations.mean = mean(x);
            result.calculations.std = std(x);
            result.calculations.product = prod(x(1:10)); % Avoid overflow
            
            pause(task.estimatedDuration / 10);
        end

        function result = executeFileOperationTask(obj, task)
            result = struct();
            result.taskType = 'file_operation';
            
            % Simulate file operations
            result.operation = 'file_created';
            result.filename = sprintf('output_%s.mat', task.name);
            result.size = randi([1000, 10000]);
            
            pause(task.estimatedDuration / 10);
        end

        function result = executeGenericTask(obj, task)
            result = struct();
            result.taskType = 'generic';
            result.message = sprintf('Generic task %s completed', task.name);
            
            pause(task.estimatedDuration / 10);
        end

        function runningTasks = checkCompletedTasks(obj, runningTasks)
            completedIndices = [];
            
            for i = 1:length(runningTasks)
                task = runningTasks{i};
                
                if task.worker.isComplete
                    % Task completed successfully
                    task.status = 'completed';
                    task.completionTime = task.worker.completionTime;
                    task.result = task.worker.result;
                    task.actualDuration = seconds(task.completionTime - task.startTime);
                    
                    % Release resources
                    obj.resourceMonitor.releaseResources(task.resourceRequirements);
                    
                    % Move to completed tasks
                    obj.completedTasks{end+1} = task;
                    completedIndices(end+1) = i;
                    
                    fprintf('Completed task: %s (Duration: %.1fs)\n', task.name, task.actualDuration);
                end
            end
            
            % Remove completed tasks from running list
            runningTasks(completedIndices) = [];
        end

        function metrics = getPerformanceMetrics(obj)
            metrics = obj.performanceMetrics.getMetrics();
            metrics.completedTasks = length(obj.completedTasks);
            metrics.failedTasks = length(obj.failedTasks);
            metrics.pendingTasks = length(obj.taskQueue);
            
            if ~isempty(obj.completedTasks)
                durations = cellfun(@(t) t.actualDuration, obj.completedTasks);
                metrics.averageTaskDuration = mean(durations);
                metrics.totalCompletionTime = sum(durations);
            end
        end

        function obj = ResourceMonitor()
            obj.availableMemory = 1000; % MB
            obj.availableCPU = 100; % Percentage
            obj.allocatedResources = {};
        end

        function available = areResourcesAvailable(obj, requirements)
            memoryOK = obj.availableMemory >= requirements.memory;
            cpuOK = obj.availableCPU >= requirements.cpu;
            available = memoryOK && cpuOK;
        end

        function allocateResources(obj, requirements)
            if obj.areResourcesAvailable(requirements)
                obj.availableMemory = obj.availableMemory - requirements.memory;
                obj.availableCPU = obj.availableCPU - requirements.cpu;
                obj.allocatedResources{end+1} = requirements;
            else
                error('Insufficient resources available');
            end
        end

        function releaseResources(obj, requirements)
            obj.availableMemory = obj.availableMemory + requirements.memory;
            obj.availableCPU = obj.availableCPU + requirements.cpu;
            
            % Remove from allocated list
            for i = length(obj.allocatedResources):-1:1
                if isequal(obj.allocatedResources{i}, requirements)
                    obj.allocatedResources(i) = [];
                    break;
                end
            end
        end

        function obj = PerformanceMetrics()
            obj.startTime = datetime('now');
            obj.taskThroughput = [];
            obj.resourceUtilisation = [];
            obj.errorRate = [];
        end

        function update(obj, scheduler)
            currentTime = datetime('now');
            elapsed = seconds(currentTime - obj.startTime);
            
            % Calculate throughput
            completedCount = length(scheduler.completedTasks);
            throughput = completedCount / max(elapsed, 1);
            obj.taskThroughput(end+1) = throughput;
            
            % Calculate resource utilisation
            memUsage = (1000 - scheduler.resourceMonitor.availableMemory) / 1000;
            cpuUsage = (100 - scheduler.resourceMonitor.availableCPU) / 100;
            utilisation = (memUsage + cpuUsage) / 2;
            obj.resourceUtilisation(end+1) = utilisation;
            
            % Calculate error rate
            totalTasks = completedCount + length(scheduler.failedTasks);
            errorRate = length(scheduler.failedTasks) / max(totalTasks, 1);
            obj.errorRate(end+1) = errorRate;
        end

        function metrics = getMetrics(obj)
            metrics = struct();
            
            if ~isempty(obj.taskThroughput)
                metrics.averageThroughput = mean(obj.taskThroughput);
                metrics.currentThroughput = obj.taskThroughput(end);
            end
            
            if ~isempty(obj.resourceUtilisation)
                metrics.averageUtilisation = mean(obj.resourceUtilisation);
                metrics.currentUtilisation = obj.resourceUtilisation(end);
            end
            
            if ~isempty(obj.errorRate)
                metrics.currentErrorRate = obj.errorRate(end);
            end
        end
