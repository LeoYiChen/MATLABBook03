%% chapter_AI_MATLAB_example_03.m
% Transfer Learning Using a Pretrained Model for Image Classification
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_example_03
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Load a pretrained AlexNet model
net = alexnet;

% Load and preprocess an image
im = imread('image.jpg');
im = imresize(im, [227, 227]);

% Classify the image using the pretrained model
label = classify(net, im);

% Display the predicted label
disp(label);

% For fine-tuning, extract network layers and modify
layers = net.Layers;
layersTransfer = layers(1:end-3);
numClasses = 5;  % New number of classes

% Create new layers for fine-tuning
newLayers = [
    layersTransfer
    fullyConnectedLayer(numClasses, 'WeightLearnRateFactor', 10, 'BiasLearnRateFactor', 10)
    softmaxLayer
    classificationLayer];

% Set up training options and fine-tune
options = trainingOptions('sgdm', 'InitialLearnRate', 0.0001, 'MaxEpochs', 10);
netTransfer = trainNetwork(trainingImages, trainingLabels, newLayers, options);
