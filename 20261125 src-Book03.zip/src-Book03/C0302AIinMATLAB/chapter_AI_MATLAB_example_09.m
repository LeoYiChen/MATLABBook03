%% chapter_AI_MATLAB_example_09.m
% Hyperparameter Optimisation Using Bayesian Optimisation
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_example_09
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Define hyperparameter optimisation problem
optimVars = [
    optimizableVariable('NumLearners', [10, 100], 'Type', 'integer')
    optimizableVariable('MinLeafSize', [1, 20], 'Type', 'integer')
    optimizableVariable('LearningRate', [0.001, 0.1], 'Transform', 'log')];

% Define objective function
minfun = @(hypers)kfoldLoss(fitcensemble(X, Y, ...
    'Method', 'GentleBoost', ...
    'NumLearningCycles', hypers.NumLearners, ...
    'LearnRate', hypers.LearningRate, ...
    'Learners', templateTree('MinLeafSize', hypers.MinLeafSize), ...
    'KFold', 5));

% Run Bayesian optimisation
results = bayesopt(minfun, optimVars, ...
    'MaxObjectiveEvaluations', 30, ...
    'UseParallel', true, ...
    'AcquisitionFunctionName', 'expected-improvement-plus');

% Extract optimal hyperparameters
bestHyperparameters = results.XAtMinObjective;

% Train final model with optimal hyperparameters
finalModel = fitcensemble(X, Y, ...
    'Method', 'GentleBoost', ...
    'NumLearningCycles', bestHyperparameters.NumLearners, ...
    'LearnRate', bestHyperparameters.LearningRate, ...
    'Learners', templateTree('MinLeafSize', bestHyperparameters.MinLeafSize));
