%% chapter_AI_MATLAB_example_Consensus_01.m
% Implementation of the average consensus algorithm for a network of agents. The adjacency matrix defines the communication topology, and the Metropolis-Hastings weights ensure convergence to the global average of the agents' initial estimates.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_example_Consensus_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [estimateHistory, finalEstimate] = averageConsensus( ...
        initialEstimates, adjacencyMatrix, maxIterations, tolerance)
    % averageConsensus - Distributed average consensus algorithm
    %   initialEstimates - column vector of initial agent estimates
    %   adjacencyMatrix  - binary symmetric adjacency matrix (n x n)
    %   maxIterations    - maximum number of consensus iterations
    %   tolerance        - convergence threshold
    
    n = numel(initialEstimates);
    
    % Compute Metropolis-Hastings weights for convergence guarantee
    degree = sum(adjacencyMatrix, 2);
    W = zeros(n);
    for i = 1:n
        for j = 1:n
            if adjacencyMatrix(i, j) == 1 && i ~= j
                W(i, j) = 1 / (1 + max(degree(i), degree(j)));
            end
        end
        W(i, i) = 1 - sum(W(i, :));
    end
    
    % Iterative consensus
    x = initialEstimates(:);
    estimateHistory = zeros(n, maxIterations);
    estimateHistory(:, 1) = x;
    
    for t = 2:maxIterations
        x = W * x;
        estimateHistory(:, t) = x;
        
        % Check for convergence
        if max(abs(x - mean(x))) < tolerance
            estimateHistory = estimateHistory(:, 1:t);
            fprintf('Consensus reached at iteration %d.\n', t);
            break;
        end
    end
    
    finalEstimate = mean(x);
    fprintf('Final consensus value: %.4f (true average: %.4f).\n', ...
            finalEstimate, mean(initialEstimates));
end
