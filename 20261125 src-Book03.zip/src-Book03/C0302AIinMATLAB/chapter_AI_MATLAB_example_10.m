%% chapter_AI_MATLAB_example_10.m
% Using the Classification Learner App Programmatically
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_example_10
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Load data
load fisheriris

% Launch Classification Learner App programmatically
classificationLearner

% The following code would be generated from the app after training
% and exporting a model

% Train a classifier
% This code recreates a decision tree classifier trained in the app
template = templateTree(...
    'MaxNumSplits', 20);
classificationTree = fitcensemble(...
    predictors, ...
    response, ...
    'Method', 'Bag', ...
    'NumLearningCycles', 30, ...
    'Learners', template);

% Use the trained model for predictions
predictedLabels = predict(classificationTree, newData);
