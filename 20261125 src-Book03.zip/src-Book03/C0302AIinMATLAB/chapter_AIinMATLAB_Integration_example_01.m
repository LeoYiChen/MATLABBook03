%% chapter_AIinMATLAB_Integration_example_01.m
% Importing and analysing a pre-trained ONNX model in MATLAB. The importONNXNetwork function converts the ONNX file into a native MATLAB network object, and analyzeNetwork provides a detailed architectural summary.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AIinMATLAB_Integration_example_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Specify the path to the pre-trained ONNX model file
modelFile = 'resnet50.onnx';

% Import the ONNX model as a MATLAB network object
net = importONNXNetwork(modelFile, ...
    'OutputLayerType', 'classification');

% Display a detailed summary of the imported network architecture
analyzeNetwork(net);

% Perform inference on a sample image
img = imread('peppers.png');
inputSize = net.Layers(1).InputSize;
img = imresize(img, inputSize(1:2));

% Classify the image and display the predicted label
[label, scores] = classify(net, img);
fprintf('Predicted class: %s (confidence: %.2f%%)\n', ...
    string(label), max(scores) * 100);
