%% chapter_AIinMATLAB_Integration_example_03.m
% Direct import of Keras and TensorFlow models into MATLAB. The importKerasNetwork function handles HDF5 files, whilst importTensorFlowNetwork handles the SavedModel directory format.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AIinMATLAB_Integration_example_03
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Import a Keras model saved in HDF5 format
kerasNet = importKerasNetwork('vgg16_model.h5');
analyzeNetwork(kerasNet);

% Import a TensorFlow 2 SavedModel
tfModelFolder = 'saved_model_directory';
tfNet = importTensorFlowNetwork(tfModelFolder);
analyzeNetwork(tfNet);
