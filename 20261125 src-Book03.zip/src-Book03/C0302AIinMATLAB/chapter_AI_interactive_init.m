%% chapter_AI_interactive_init.m
% Interactive query interface initialisation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_interactive_init
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function queryInterface = createInteractiveInterface()
queryInterface.conversationManager = ConversationManager();
queryInterface.contextTracker = ContextTracker();
queryInterface.suggestionEngine = SuggestionEngine();
end
