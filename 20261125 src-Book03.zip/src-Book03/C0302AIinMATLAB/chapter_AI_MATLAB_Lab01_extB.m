%% chapter_AI_MATLAB_Lab01_extB.m
% Extension B: Parallel evaluation of multiple design candidates.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_Lab01_extB
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Generate a grid of candidate designs
widthRange  = linspace(0.020, 0.060, 10);
heightRange = linspace(0.040, 0.120, 10);
[widthGrid, heightGrid] = meshgrid(widthRange, heightRange);
numCandidates = numel(widthGrid);

% Start parallel pool
pool = gcp('nocreate');
if isempty(pool)
    pool = parpool('Processes', 4);
end

% Distribute simulation tasks
futures(numCandidates) = parallel.FevalFuture;
for idx = 1:numCandidates
    candidateDesign = generateBeamDesign( ...
        widthGrid(idx), heightGrid(idx), specifications);
    futures(idx) = parfeval(pool, ...
        @runCantileverBeamSimulation, 1, ...
        candidateDesign, specifications.load);
end

% Collect and evaluate results
massValues = zeros(numCandidates, 1);
feasible   = false(numCandidates, 1);
for idx = 1:numCandidates
    [completedIdx, result] = fetchNext(futures);
    candidateDesign = generateBeamDesign( ...
        widthGrid(completedIdx), ...
        heightGrid(completedIdx), specifications);
    analysis = evaluateDesignCompliance( ...
        result, candidateDesign, specifications.constraints);
    massValues(completedIdx) = candidateDesign.mass;
    feasible(completedIdx)   = analysis.allConstraintsMet;
end
