# C0302AIinMATLAB - Supplementary MATLAB Source Code

| Field | Value |
| --- | --- |
| Book | MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications |
| Chapter | Artificial Intelligence in MATLAB |
| Package version | 1.0.1 |
| Release stamp | 2026-11-10 |
| Source manuscript | `P03-20261111` |
| Source chapter file | `P0302main/C0302AIinMATLAB/` (included by `P03_20261005.tex`) |
| Code files | 57 (57 `.m`, 0 `.f`) |
| Code lines relocated | 8,665 |

## Why this folder exists

The editor reported that a large volume of programming code was present in the
manuscript and requested that it be moved to a professional repository with the
links supplied as supplementary material. The printed book is subject to a
length target below 1100 pages and to the Springer hard-copy limit of fewer
than 950 print pages. Accordingly, every `lstlisting` (and every MATLAB
`verbatim`) environment in the chapter has been removed from the main body and
deposited here. Only the filename, the listing caption and a reference to this
folder remain in the printed text.

## Naming convention

A file is named after the `label` of the listing it came from:

```latex
\begin{lstlisting}[..., caption={Basic matrix operations ...},
                     label={chapter_Introduction_example_01}]
```

is saved as `chapter_Introduction_example_01.m`.

- Listings without a `label` receive a generated name `C0302AIinMATLAB_code_NNN.m`.
- Code held in a `verbatim` environment receives `C0302AIinMATLAB_verbatim_NN.m`
  (or `.f` for the single illustrative Fortran 77 block).
- Where two listings shared the same label, the later file carries a numeric
  suffix (`_02`, `_03`, ...) so nothing is overwritten. This is recorded in
  the table below.

Each file begins with a header comment giving the caption, the original label,
this folder, the version stamp and the public repository URL.

## Finding a file from the book

The main text now shows a one-line note of the form:

> **Source code 3.4:** `chapter_ICT_example_01.m` - *caption*
> (supplementary material: `src-Book03/C0302AIinMATLAB/`)

The original listing numbers and all `\ref{...}` cross-references are
unchanged, so the in-text reference maps directly to a filename.

## Repository

```
https://github.com/LeoYiChen/MATLABBook03
```

Clone or download `src-Book03/` from this public repository, or use the
Springer supplementary archive. The same address is printed in the preface of
the book. Keep the `src-Book03/` folder name so that the in-text
`src-Book03/C0302AIinMATLAB/` paths resolve.

## Companion documents

- `VERSION.md` - version, release stamp and release notes
- `USER-GUIDE.md` - how to download, locate and run the code
- `MANIFEST.sha256` - SHA-256 ledger of every file in this folder

## Files

| Filename | Source listing label | Caption |
| --- | --- | --- |
| `chapter_AI_MATLAB_Lab01_extA.m` | `chapter_AI_MATLAB_Lab01_extA` | Extension A: Using fmincon for constrained beam optimisation. |
| `chapter_AI_MATLAB_Lab01_extB.m` | `chapter_AI_MATLAB_Lab01_extB` | Extension B: Parallel evaluation of multiple design candidates. |
| `chapter_AI_MATLAB_Lab01_extD.m` | `chapter_AI_MATLAB_Lab01_extD` | Extension D: Material database for multi-material agent-based optimisation. |
| `chapter_AI_MATLAB_Lab01_step01.m` | `chapter_AI_MATLAB_Lab01_step01` | Function to define engineering specifications for the cantilever beam virtual prototyping exercise. |
| `chapter_AI_MATLAB_Lab01_step02.m` | `chapter_AI_MATLAB_Lab01_step02` | Function to create the multi-agent team and initialise the communication infrastructure. |
| `chapter_AI_MATLAB_Lab01_step03.m` | `chapter_AI_MATLAB_Lab01_step03` | Message routing function for inter-agent communication. |
| `chapter_AI_MATLAB_Lab01_step04.m` | `chapter_AI_MATLAB_Lab01_step04` | Design Agent function for generating cantilever beam designs. |
| `chapter_AI_MATLAB_Lab01_step05.m` | `chapter_AI_MATLAB_Lab01_step05` | Simulation Agent function implementing Euler-Bernoulli cantilever beam analysis. |
| `chapter_AI_MATLAB_Lab01_step06.m` | `chapter_AI_MATLAB_Lab01_step06` | Analysis Agent function for evaluating design compliance against constraints. |
| `chapter_AI_MATLAB_Lab01_step07.m` | `chapter_AI_MATLAB_Lab01_step07` | Optimisation Agent function for proposing improved design parameters. |
| `chapter_AI_MATLAB_Lab01_step08.m` | `chapter_AI_MATLAB_Lab01_step08` | Main workflow orchestration function integrating all four AI agents. |
| `chapter_AI_MATLAB_Lab01_step09.m` | `chapter_AI_MATLAB_Lab01_step09` | Visualisation functions for optimisation convergence and beam deflection profile. |
| `chapter_AI_MATLAB_Lab01_step10.m` | `chapter_AI_MATLAB_Lab01_step10` | Main script and report generation function for the virtual prototyping laboratory. |
| `chapter_AI_MATLAB_VibeCoding_example_01.m` | `chapter_AI_MATLAB_VibeCoding_example_01` | Natural language intent recognition framework for MATLAB vibe coding applications. |
| `chapter_AI_MATLAB_VibeCoding_example_02.m` | `chapter_AI_MATLAB_VibeCoding_example_02` | Comprehensive validation framework for vibe coding generated MATLAB code. |
| `chapter_AI_MATLAB_example_01.m` | `chapter_AI_MATLAB_example_01` | Implementing a Random Forest Classifier in MATLAB |
| `chapter_AI_MATLAB_example_02.m` | `chapter_AI_MATLAB_example_02` | Transfer Learning with a Pre-trained CNN in MATLAB |
| `chapter_AI_MATLAB_example_03.m` | `chapter_AI_MATLAB_example_03` | Transfer Learning Using a Pretrained Model for Image Classification |
| `chapter_AI_MATLAB_example_04.m` | `chapter_AI_MATLAB_example_04` | Data Augmentation for Image Classification |
| `chapter_AI_MATLAB_example_05.m` | `chapter_AI_MATLAB_example_05` | Object Detection Using YOLO v2 in MATLAB |
| `chapter_AI_MATLAB_example_06.m` | `chapter_AI_MATLAB_example_06` | Sentiment Analysis Using Text Analytics Toolbox |
| `chapter_AI_MATLAB_example_07.m` | `chapter_AI_MATLAB_example_07` | Implementing Deep Q-Network (DQN) Agent for Cart-Pole System |
| `chapter_AI_MATLAB_example_08.m` | `chapter_AI_MATLAB_example_08` | Comprehensive Model Evaluation |
| `chapter_AI_MATLAB_example_09.m` | `chapter_AI_MATLAB_example_09` | Hyperparameter Optimisation Using Bayesian Optimisation |
| `chapter_AI_MATLAB_example_10.m` | `chapter_AI_MATLAB_example_10` | Using the Classification Learner App Programmatically |
| `chapter_AI_MATLAB_example_11.m` | `chapter_AI_MATLAB_example_11` | GPU Acceleration for Deep Learning |
| `chapter_AI_MATLAB_example_12.m` | `chapter_AI_MATLAB_example_12` | Deploying a Deep Learning Model to Production |
| `chapter_AI_MATLAB_example_13.m` | `chapter_AI_MATLAB_example_13` | Integrating MATLAB with OpenAI's GPT Models |
| `chapter_AI_MATLAB_example_AIForProgramming_01.m` | `chapter_AI_MATLAB_example_AIForProgramming_01` | AI-assisted MATLAB function with comprehensive input validation, error handling, and documentation following industry best practices. |
| `chapter_AI_MATLAB_example_AIForProgramming_02.m` | `chapter_AI_MATLAB_example_AIForProgramming_02` | Unit test suite for validating AI-assisted geometric properties function. |
| `chapter_AI_MATLAB_example_Consensus_01.m` | `chapter_AI_MATLAB_example_Consensus_01` | Implementation of the average consensus algorithm for a network of agents. The adjacency matrix defines the communication topology, and the Metropolis-Hastings weights ensure convergence to the global average of the agents' initial estimates. |
| `chapter_AI_MATLAB_example_DT_01.m` | `chapter_AI_MATLAB_example_DT_01` | Function to deploy a multi-agent monitoring system for a digital twin application. Specialised agents are created for each monitored subsystem, registered with the coordinator, and initialised with subsystem-specific knowledge. |
| `chapter_AI_MATLAB_example_MARL_01.m` | `chapter_AI_MATLAB_example_MARL_01` | Schematic configuration of a multi-agent reinforcement learning scenario using the MATLAB Reinforcement Learning Toolbox. Two PPO agents are created with separate observation and action specifications, and multi-agent training options are configured for simultaneous policy optimisation. |
| `chapter_AI_MATLAB_example_MAS_01.m` | `chapter_AI_MATLAB_example_MAS_01` | Multi-agent coordinator with agent registry, message routing, and parallel task execution. The coordinator manages a population of IntelligentAgent instances and provides methods for agent registration, inter-agent messaging, broadcast communication, and distributed task allocation using parfeval. |
| `chapter_AI_MATLAB_example_MAS_02.m` | `chapter_AI_MATLAB_example_MAS_02` | End-to-end demonstration of multi-agent system operation. Three agents are created and registered with the coordinator. Messages are routed between agents, and a distributed task is executed concurrently using the parallel computing infrastructure. |
| `chapter_AI_MATLAB_example_SingleAgent_01.m` | `chapter_AI_MATLAB_example_SingleAgent_01` | Implementation of a single AI agent with integrated communication protocol support. The class inherits from handle to support events and pass-by-reference semantics. The message-processing pipeline follows a structured receive-validate-route-respond pattern, and the decision-making module uses a dlnetwork policy. |
| `chapter_AI_MATLAB_example_SingleAgent_02.m` | `chapter_AI_MATLAB_example_SingleAgent_02` | Instantiation and usage of the IntelligentAgent class. The example demonstrates agent creation, message processing, action selection, and status reporting. |
| `chapter_AI_agent_framework.m` | `chapter_AI_agent_framework` | Autonomous agent framework. |
| `chapter_AI_codegen_complete.m` | `chapter_AI_codegen_complete` | Natural language to MATLAB code generation system. |
| `chapter_AI_codegen_init.m` | `chapter_AI_codegen_init` | Code generation system initialisation. |
| `chapter_AI_doc_complete.m` | `chapter_AI_doc_complete` | Document-based task specification system. |
| `chapter_AI_doc_setup.m` | `chapter_AI_doc_setup` | Document-based task specification setup. |
| `chapter_AI_interactive_complete.m` | `chapter_AI_interactive_complete` | Interactive natural language query interface. |
| `chapter_AI_interactive_init.m` | `chapter_AI_interactive_init` | Interactive query interface initialisation. |
| `chapter_AI_multimodal_complete.m` | `chapter_AI_multimodal_complete` | Multi-modal input processing system. |
| `chapter_AI_multimodal_init.m` | `chapter_AI_multimodal_init` | Multi-modal input processor initialisation. |
| `chapter_AI_nlp_complete.m` | `chapter_AI_nlp_complete` | Complete natural language command parser implementation. |
| `chapter_AI_nlp_init.m` | `chapter_AI_nlp_init` | Natural language command parser initialisation. |
| `chapter_AI_quality_complete.m` | `chapter_AI_quality_complete` | Comprehensive data quality assessment pipeline. |
| `chapter_AI_quality_framework.m` | `chapter_AI_quality_framework` | Data quality assessment framework. |
| `chapter_AI_realtime_complete.m` | `chapter_AI_realtime_complete` | Real-time predictive analytics system. |
| `chapter_AI_realtime_framework.m` | `chapter_AI_realtime_framework` | Real-time predictive analytics framework. |
| `chapter_AI_scheduler_complete.m` | `chapter_AI_scheduler_complete` | Complete autonomous task scheduler. |
| `chapter_AIinMATLAB_Integration_example_01.m` | `chapter_AIinMATLAB_Integration_example_01` | Importing and analysing a pre-trained ONNX model in MATLAB. The importONNXNetwork function converts the ONNX file into a native MATLAB network object, and analyzeNetwork provides a detailed architectural summary. |
| `chapter_AIinMATLAB_Integration_example_02.m` | `chapter_AIinMATLAB_Integration_example_02` | Exporting a MATLAB-trained network to the ONNX format for use in external frameworks. |
| `chapter_AIinMATLAB_Integration_example_03.m` | `chapter_AIinMATLAB_Integration_example_03` | Direct import of Keras and TensorFlow models into MATLAB. The importKerasNetwork function handles HDF5 files, whilst importTensorFlowNetwork handles the SavedModel directory format. |
| `chapter_AIinMATLAB_Integration_example_04.m` | `chapter_AIinMATLAB_Integration_example_04` | Configuring and utilising the MATLAB-Python interface. The pyenv function establishes the link to a specified Python installation, after which Python modules can be called using the py. prefix or via the pyrun function. |
