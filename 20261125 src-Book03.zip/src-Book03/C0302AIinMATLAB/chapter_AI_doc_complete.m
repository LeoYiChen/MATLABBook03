%% chapter_AI_doc_complete.m
% Document-based task specification system.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_doc_complete
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function result = documentTaskSpecificationSystem(documentPath)
% Document-Based Task Specification System
% Author: Dr Yi Chen
% Version: 1.0
% Description: Reads task specifications from documents and executes workflows

try
    % Step 1: Validate file existence
    if ~exist(documentPath, 'file')
        error('Document file not found: %s', documentPath);
    end
    
    % Step 2: Parse document based on file extension
    [~, ~, ext] = fileparts(documentPath);
    taskSpec = parseDocument(documentPath, ext);
    
    % Step 3: Validate task specification
    validationResult = validateTaskSpecification(taskSpec);
    if ~validationResult.isValid
        error('Task specification validation failed: %s', strjoin(validationResult.errors, '; '));
    end
    
    % Step 4: Resolve dependencies
    executionOrder = resolveDependencies(taskSpec);
    
    % Step 5: Execute tasks in order
    result = executeWorkflow(taskSpec, executionOrder);
    
    result.success = true;
    result.message = 'Workflow executed successfully';
    
catch ME
    result.success = false;
    result.error = ME.message;
    result.message = sprintf('Failed to process document: %s', documentPath);
end

end

function taskSpec = parseDocument(documentPath, extension)
switch lower(extension)
case '.json'
taskSpec = parseJSONDocument(documentPath);
case '.xml'
taskSpec = parseXMLDocument(documentPath);
case '.txt'
taskSpec = parseTextDocument(documentPath);
otherwise
error('Unsupported document format: %s', extension);
end
end

function taskSpec = parseJSONDocument(filePath)
% Parse JSON task specification
jsonText = fileread(filePath);
rawSpec = jsondecode(jsonText);

taskSpec = struct();
taskSpec.metadata = rawSpec.metadata;
taskSpec.tasks = rawSpec.tasks;
taskSpec.dependencies = rawSpec.dependencies;
taskSpec.parameters = rawSpec.parameters;

end

function taskSpec = parseXMLDocument(filePath)
% Parse XML task specification
domNode = xmlread(filePath);
taskSpec = struct();

% Extract metadata
metadataNodes = domNode.getElementsByTagName('metadata');
if metadataNodes.getLength() > 0
    taskSpec.metadata = extractXMLMetadata(metadataNodes.item(0));
end

% Extract tasks
taskNodes = domNode.getElementsByTagName('task');
taskSpec.tasks = cell(taskNodes.getLength(), 1);
for i = 0:taskNodes.getLength()-1
    taskSpec.tasks{i+1} = extractXMLTask(taskNodes.item(i));
end

% Extract dependencies
depNodes = domNode.getElementsByTagName('dependencies');
if depNodes.getLength() > 0
    taskSpec.dependencies = extractXMLDependencies(depNodes.item(0));
else
    taskSpec.dependencies = {};
end

end

function taskSpec = parseTextDocument(filePath)
% Parse plain text task specification
lines = readlines(filePath);
taskSpec = struct();
taskSpec.tasks = {};
taskSpec.dependencies = {};

currentTask = struct();
inTask = false;

for i = 1:length(lines)
    line = strtrim(lines{i});
    
    if startsWith(line, 'TASK:', 'IgnoreCase', true)
        if inTask
            taskSpec.tasks{end+1} = currentTask;
        end
        currentTask = struct();
        currentTask.name = extractAfter(line, ':');
        currentTask.name = strtrim(currentTask.name);
        inTask = true;
        
    elseif startsWith(line, 'TYPE:', 'IgnoreCase', true) && inTask
        currentTask.type = strtrim(extractAfter(line, ':'));
        
    elseif startsWith(line, 'PARAMETERS:', 'IgnoreCase', true) && inTask
        currentTask.parameters = parseTextParameters(extractAfter(line, ':'));
        
    elseif startsWith(line, 'DEPENDS_ON:', 'IgnoreCase', true) && inTask
        dependencies = strtrim(extractAfter(line, ':'));
        if ~isempty(dependencies)
            currentTask.dependencies = strsplit(dependencies, ',');
            currentTask.dependencies = cellfun(@strtrim, currentTask.dependencies, 'UniformOutput', false);
        end
    end
end

if inTask
    taskSpec.tasks{end+1} = currentTask;
end

end

function params = parseTextParameters(paramString)
params = struct();
if isempty(strtrim(paramString))
return;
end

pairs = strsplit(paramString, ',');
for i = 1:length(pairs)
    pair = strtrim(pairs{i});
    equalPos = strfind(pair, '=');
    if ~isempty(equalPos)
        key = strtrim(pair(1:equalPos(1)-1));
        value = strtrim(pair(equalPos(1)+1:end));
        
        % Try to convert to number
        numValue = str2double(value);
        if ~isnan(numValue)
            params.*(key) = numValue;
        else
            params.*(key) = value;
        end
    end
end

end

function validationResult = validateTaskSpecification(taskSpec)
validationResult = struct();
validationResult.isValid = true;
validationResult.errors = {};
validationResult.warnings = {};

% Check if tasks exist
if ~isfield(taskSpec, 'tasks') || isempty(taskSpec.tasks)
    validationResult.isValid = false;
    validationResult.errors{end+1} = 'No tasks specified';
    return;
end

% Validate each task
taskNames = {};
for i = 1:length(taskSpec.tasks)
    task = taskSpec.tasks{i};
    
    % Check required fields
    if ~isfield(task, 'name') || isempty(task.name)
        validationResult.isValid = false;
        validationResult.errors{end+1} = sprintf('Task %d missing name', i);
    else
        taskNames{end+1} = task.name;
    end
    
    if ~isfield(task, 'type') || isempty(task.type)
        validationResult.isValid = false;
        validationResult.errors{end+1} = sprintf('Task %s missing type', task.name);
    end
    
    % Validate task type
    validTypes = {'data_processing', 'analysis', 'visualisation', 'calculation', 'file_operation'};
    if isfield(task, 'type') && ~ismember(task.type, validTypes)
        validationResult.warnings{end+1} = sprintf('Unknown task type: %s', task.type);
    end
end

% Check dependencies
for i = 1:length(taskSpec.tasks)
    task = taskSpec.tasks{i};
    if isfield(task, 'dependencies') && ~isempty(task.dependencies)
        for j = 1:length(task.dependencies)
            dep = task.dependencies{j};
            if ~ismember(dep, taskNames)
                validationResult.isValid = false;
                validationResult.errors{end+1} = sprintf('Task %s depends on non-existent task: %s', task.name, dep);
            end
        end
    end
end

end

function executionOrder = resolveDependencies(taskSpec)
tasks = taskSpec.tasks;
numTasks = length(tasks);

% Create adjacency matrix for dependency graph
taskNames = cellfun(@(t) t.name, tasks, 'UniformOutput', false);
adjMatrix = false(numTasks, numTasks);

for i = 1:numTasks
    task = tasks{i};
    if isfield(task, 'dependencies') && ~isempty(task.dependencies)
        for j = 1:length(task.dependencies)
            depName = task.dependencies{j};
            depIndex = find(strcmp(taskNames, depName));
            if ~isempty(depIndex)
                adjMatrix(depIndex, i) = true; % depIndex must execute before i
            end
        end
    end
end

% Topological sort
executionOrder = topologicalSort(adjMatrix);

if isempty(executionOrder)
    error('Circular dependency detected in task specification');
end

end

function order = topologicalSort(adjMatrix)
n = size(adjMatrix, 1);
inDegree = sum(adjMatrix, 1);
order = [];
queue = find(inDegree == 0);

while ~isempty(queue)
    current = queue(1);
    queue(1) = [];
    order(end+1) = current;
    
    % Remove edges from current node
    for i = 1:n
        if adjMatrix(current, i)
            adjMatrix(current, i) = false;
            inDegree(i) = inDegree(i) - 1;
            if inDegree(i) == 0
                queue(end+1) = i;
            end
        end
    end
end

if length(order) ~= n
    order = []; % Circular dependency detected
end

end

function result = executeWorkflow(taskSpec, executionOrder)
result = struct();
result.executedTasks = {};
result.taskResults = containers.Map();
result.executionTimes = [];

tasks = taskSpec.tasks;

for i = 1:length(executionOrder)
    taskIndex = executionOrder(i);
    task = tasks{taskIndex};
    
    fprintf('Executing task: %s\n', task.name);
    
    % Execute task
    startTime = tic;
    taskResult = executeTask(task);
    executionTime = toc(startTime);
    
    % Store results
    result.executedTasks{end+1} = task.name;
    result.taskResults(task.name) = taskResult;
    result.executionTimes(end+1) = executionTime;
    
    fprintf('Task %s completed in %.3f seconds\n', task.name, executionTime);
end

result.totalExecutionTime = sum(result.executionTimes);
result.numTasksExecuted = length(result.executedTasks);

end

function taskResult = executeTask(task)
taskResult = struct();
taskResult.taskName = task.name;
taskResult.taskType = task.type;
taskResult.startTime = datetime('now');

try
    switch task.type
        case 'data_processing'
            taskResult = executeDataProcessingTask(task, taskResult);
        case 'analysis'
            taskResult = executeAnalysisTask(task, taskResult);
        case 'visualisation'
            taskResult = executeVisualisationTask(task, taskResult);
        case 'calculation'
            taskResult = executeCalculationTask(task, taskResult);
        case 'file_operation'
            taskResult = executeFileOperationTask(task, taskResult);
        otherwise
            error('Unknown task type: %s', task.type);
    end
    
    taskResult.success = true;
    taskResult.endTime = datetime('now');
    
catch ME
    taskResult.success = false;
    taskResult.error = ME.message;
    taskResult.endTime = datetime('now');
end

end

function taskResult = executeDataProcessingTask(task, taskResult)
% Generate or load sample data
if isfield(task, 'parameters') && isfield(task.parameters, 'data_size')
dataSize = task.parameters.data_size;
else
dataSize = 1000;
end

data = randn(dataSize, 3); % Generate random data

% Process data
processedData = normalize(data); % Normalise data

taskResult.originalDataSize = size(data);
taskResult.processedDataSize = size(processedData);
taskResult.dataStatistics = struct('mean', mean(processedData), 'std', std(processedData));
taskResult.outputData = processedData;

end

function taskResult = executeAnalysisTask(task, taskResult)
% Generate sample data for analysis
data = randn(500, 1);

% Perform statistical analysis
taskResult.analysis = struct();
taskResult.analysis.mean = mean(data);
taskResult.analysis.median = median(data);
taskResult.analysis.std = std(data);
taskResult.analysis.min = min(data);
taskResult.analysis.max = max(data);
taskResult.analysis.skewness = skewness(data);
taskResult.analysis.kurtosis = kurtosis(data);

taskResult.dataAnalysed = data;

end

function taskResult = executeVisualisationTask(task, taskResult)
% Create sample visualisation
x = linspace(0, 2*pi, 100);
y = sin(x) + 0.1*randn(size(x));

figure;
plot(x, y, 'b-', 'LineWidth', 2);
title(sprintf('Visualisation for Task: %s', task.name));
xlabel('X Values');
ylabel('Y Values');
grid on;

taskResult.plotCreated = true;
taskResult.dataPoints = length(x);
taskResult.xRange = [min(x), max(x)];
taskResult.yRange = [min(y), max(y)];

end

function taskResult = executeCalculationTask(task, taskResult)
% Perform mathematical calculations
if isfield(task, 'parameters')
params = task.parameters;
if isfield(params, 'numbers')
numbers = params.numbers;
else
numbers = 1:10; % Default numbers
end
else
numbers = 1:10;
end

taskResult.calculations = struct();
taskResult.calculations.sum = sum(numbers);
taskResult.calculations.product = prod(numbers);
taskResult.calculations.mean = mean(numbers);
taskResult.calculations.factorial_sum = sum(factorial(numbers(numbers <= 10)));
taskResult.calculations.geometric_mean = geomean(numbers);

taskResult.inputNumbers = numbers;

end

function taskResult = executeFileOperationTask(task, taskResult)
% Simulate file operations
if isfield(task, 'parameters') && isfield(task.parameters, 'operation')
operation = task.parameters.operation;
else
operation = 'create';
end

switch operation
    case 'create'
        % Create temporary file with sample data
        tempData = randn(100, 3);
        tempFile = tempname;
        save([tempFile '.mat'], 'tempData');
        taskResult.fileCreated = [tempFile '.mat'];
        taskResult.dataSize = size(tempData);
        
    case 'read'
        % Simulate reading file
        taskResult.filesRead = {'sample1.mat', 'sample2.mat'};
        taskResult.totalSizeRead = 2048; % bytes
        
    case 'process'
        % Simulate file processing
        taskResult.filesProcessed = 5;
        taskResult.processingTime = 1.23; % seconds
end

taskResult.operation = operation;

end
