%% chapter_AI_MATLAB_VibeCoding_example_01.m
% Natural language intent recognition framework for MATLAB vibe coding applications.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_VibeCoding_example_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [intent, confidence] = recogniseMATLABIntent(naturalLanguageQuery, contextData)
    % RECOGNISEMATLABINTENT Parse natural language for MATLAB operation intent
    %   [INTENT, CONFIDENCE] = RECOGNISEMATLABINTENT(QUERY, CONTEXT)
    %   analyses a natural language description of a mathematical operation
    %   and returns structured intent representation with confidence score.
    %
    %   This function implements domain-specific pattern matching to identify
    %   the mathematical domain, specific operation, parameters, and constraints
    %   from natural language specifications, enabling vibe coding workflows.
    %
    %   Inputs:
    %       naturalLanguageQuery - String containing natural language description
    %       contextData          - Structure with workspace context (optional)
    %
    %   Outputs:
    %       intent     - Structure containing parsed intent:
    %                    .domain: mathematical domain classification
    %                    .operation: specific operation identification
    %                    .parameters: extracted numerical parameters
    %                    .constraints: identified constraints
    %       confidence - Scalar in [0,1] indicating parsing confidence
    %
    %   Example:
    %       query = 'Compute eigenvalues of a symmetric positive definite matrix';
    %       [intent, conf] = recogniseMATLABIntent(query, struct());
    %
    %   See also EIG, SVD, FFT, FMINCON.
    
    fprintf('=== MATLAB Vibe Coding Intent Recognition ===\n');
    fprintf('Query: "%s"\n', naturalLanguageQuery);
    
    % Phase 1: Normalise and preprocess query
    queryNormalised = lower(strtrim(naturalLanguageQuery));
    queryTokens = strsplit(queryNormalised);
    
    % Phase 2: Domain classification through keyword matching
    domainClassification = classifyMathematicalDomain(queryNormalised);
    
    % Phase 3: Operation identification within domain
    operationIdentification = identifySpecificOperation(...
        queryNormalised, domainClassification.primaryDomain);
    
    % Phase 4: Parameter extraction
    parameterExtraction = extractComputationalParameters(...
        queryNormalised, queryTokens, contextData);
    
    % Phase 5: Constraint identification
    constraintIdentification = identifyMathematicalConstraints(...
        queryNormalised, domainClassification.primaryDomain);
    
    % Construct comprehensive intent structure
    intent = struct(...
        'domain', domainClassification.primaryDomain, ...
        'domainConfidence', domainClassification.confidence, ...
        'operation', operationIdentification.specificOperation, ...
        'operationConfidence', operationIdentification.confidence, ...
        'parameters', parameterExtraction.parameters, ...
        'constraints', {constraintIdentification.constraints}, ...
        'originalQuery', naturalLanguageQuery, ...
        'timestamp', datetime('now') ...
    );
    
    % Calculate overall confidence as weighted combination
    confidence = 0.4 * domainClassification.confidence + ...
                 0.4 * operationIdentification.confidence + ...
                 0.2 * parameterExtraction.confidence;
    
    fprintf('Domain: %s (confidence: %.2f)\n', intent.domain, ...
            intent.domainConfidence);
    fprintf('Operation: %s (confidence: %.2f)\n', intent.operation, ...
            intent.operationConfidence);
    fprintf('Overall Confidence: %.2f\n\n', confidence);
    
    % Validate minimum confidence threshold
    if confidence < 0.3
        warning('recogniseMATLABIntent:LowConfidence', ...
            'Intent recognition confidence (%.2f) below recommended threshold. Consider refining query.', ...
            confidence);
    end
end

function classification = classifyMathematicalDomain(query)
    % Classify query into mathematical domain categories
    
    % Define domain-specific keyword patterns
    domains = {
        'linear_algebra', {'matrix', 'eigenvalue', 'eigenvector', 'svd', ...
                          'singular', 'decomposition', 'inverse', 'determinant', ...
                          'rank', 'null space', 'orthogonal', 'hermitian'};
        'signal_processing', {'signal', 'frequency', 'spectrum', 'fft', 'dft', ...
                             'filter', 'convolution', 'fourier', 'wavelet', ...
                             'spectrogram', 'bandpass', 'lowpass', 'highpass'};
        'optimisation', {'minimise', 'minimize', 'maximise', 'maximize', ...
                        'optimise', 'optimize', 'objective', 'constraint', ...
                        'gradient', 'hessian', 'lagrange', 'penalty'};
        'statistics', {'mean', 'median', 'variance', 'standard deviation', ...
                      'correlation', 'regression', 'distribution', 'hypothesis', ...
                      'anova', 'chi-square', 'confidence interval'};
        'differential_equations', {'ode', 'pde', 'differential', 'derivative', ...
                                  'initial value', 'boundary value', 'laplace', ...
                                  'runge-kutta', 'finite difference', 'finite element'};
        'numerical_methods', {'integrate', 'differentiate', 'interpolate', ...
                             'root', 'zero', 'newton', 'bisection', 'quadrature', ...
                             'gauss', 'chebyshev', 'spline'};
        'control_systems', {'transfer function', 'state space', 'pid', ...
                           'controller', 'stability', 'bode', 'nyquist', ...
                           'pole', 'zero', 'feedback', 'compensator'};
        'image_processing', {'image', 'filter', 'edge', 'morphological', ...
                            'threshold', 'segment', 'transform', 'convolution', ...
                            'histogram', 'enhancement'}
    };
    
    % Calculate match scores for each domain
    numDomains = size(domains, 1);
    scores = zeros(numDomains, 1);
    
    for i = 1:numDomains
        keywords = domains{i, 2};
        matchCount = 0;
        for j = 1:length(keywords)
            if contains(query, keywords{j})
                matchCount = matchCount + 1;
            end
        end
        scores(i) = matchCount / length(keywords);
    end
    
    % Identify primary domain
    [maxScore, maxIdx] = max(scores);
    primaryDomain = domains{maxIdx, 1};
    
    % If no strong match, classify as general computation
    if maxScore < 0.1
        primaryDomain = 'general_computation';
        maxScore = 0.3; % Moderate default confidence
    end
    
    classification = struct(...
        'primaryDomain', primaryDomain, ...
        'confidence', maxScore, ...
        'allScores', scores, ...
        'domainList', {domains(:, 1)} ...
    );
end

function identification = identifySpecificOperation(query, domain)
    % Identify specific operation within recognised domain
    
    % Define operation patterns for each domain
    switch domain
        case 'linear_algebra'
            operations = {
                'eigenvalue_decomposition', {'eigenvalue', 'eigenvector', 'eig', 'spectral'};
                'singular_value_decomposition', {'svd', 'singular value'};
                'lu_decomposition', {'lu', 'factorisation', 'factorization', 'lower upper'};
                'qr_decomposition', {'qr', 'orthogonal', 'gram-schmidt'};
                'cholesky_decomposition', {'cholesky', 'positive definite'};
                'matrix_inverse', {'inverse', 'inv', 'invert'};
                'determinant', {'determinant', 'det'};
                'matrix_multiplication', {'multiply', 'product', 'times'};
                'matrix_rank', {'rank', 'column rank', 'row rank'}
            };
            
        case 'signal_processing'
            operations = {
                'fft_analysis', {'fft', 'fast fourier', 'frequency domain'};
                'filtering', {'filter', 'bandpass', 'lowpass', 'highpass', 'butterworth'};
                'spectral_analysis', {'spectrum', 'power spectral', 'periodogram', 'pwelch'};
                'convolution', {'convolve', 'conv'};
                'correlation', {'correlate', 'xcorr', 'cross-correlation'};
                'wavelet_transform', {'wavelet', 'cwt', 'dwt', 'wavelet transform'};
                'resampling', {'resample', 'downsample', 'upsample', 'interpolate'}
            };
            
        case 'optimisation'
            operations = {
                'unconstrained_minimisation', {'fminunc', 'unconstrained', 'gradient descent'};
                'constrained_minimisation', {'fmincon', 'constrained', 'constraint'};
                'linear_programming', {'linprog', 'linear program', 'simplex'};
                'nonlinear_least_squares', {'lsqnonlin', 'least squares', 'curve fit'};
                'quadratic_programming', {'quadprog', 'quadratic program'};
                'global_optimisation', {'global', 'particle swarm', 'genetic algorithm'}
            };
            
        case 'statistics'
            operations = {
                'descriptive_statistics', {'mean', 'median', 'mode', 'variance', 'std'};
                'hypothesis_testing', {'test', 'hypothesis', 'ttest', 'anova'};
                'regression_analysis', {'regression', 'fit', 'polyfit', 'regress'};
                'correlation_analysis', {'correlation', 'corrcoef', 'corr'};
                'distribution_fitting', {'distribution', 'fit', 'pdf', 'cdf'};
                'random_sampling', {'random', 'sample', 'rand', 'randn'}
            };
            
        case 'differential_equations'
            operations = {
                'ode_solving', {'ode45', 'ode23', 'ode15s', 'solve', 'differential'};
                'pde_solving', {'pde', 'partial differential', 'pdepe'};
                'initial_value_problem', {'initial', 'ivp', 'initial value'};
                'boundary_value_problem', {'boundary', 'bvp', 'bvp4c'}
            };
            
        case 'numerical_methods'
            operations = {
                'numerical_integration', {'integrate', 'integral', 'quad', 'trapz'};
                'numerical_differentiation', {'differentiate', 'diff', 'gradient'};
                'root_finding', {'root', 'zero', 'fzero', 'newton', 'bisection'};
                'interpolation', {'interpolate', 'interp1', 'interp2', 'spline'}
            };
            
        case 'control_systems'
            operations = {
                'transfer_function_analysis', {'transfer function', 'tf', 'zpk'};
                'state_space_analysis', {'state space', 'ss'};
                'controller_design', {'controller', 'pid', 'design'};
                'stability_analysis', {'stability', 'stable', 'pole', 'root locus'};
                'frequency_response', {'bode', 'nyquist', 'frequency response'}
            };
            
        case 'image_processing'
            operations = {
                'image_filtering', {'filter', 'smooth', 'sharpen', 'gaussian'};
                'edge_detection', {'edge', 'canny', 'sobel', 'prewitt'};
                'morphological_operations', {'morphology', 'dilate', 'erode', 'open', 'close'};
                'image_segmentation', {'segment', 'threshold', 'region'};
                'image_transformation', {'transform', 'rotate', 'resize', 'warp'}
            };
            
        otherwise
            operations = {
                'general_computation', {'compute', 'calculate', 'evaluate'}
            };
    end
    
    % Score each operation based on keyword matches
    numOperations = size(operations, 1);
    scores = zeros(numOperations, 1);
    
    for i = 1:numOperations
        keywords = operations{i, 2};
        matchCount = 0;
        for j = 1:length(keywords)
            if contains(query, keywords{j})
                matchCount = matchCount + 1;
            end
        end
        scores(i) = matchCount / length(keywords);
    end
    
    % Identify best matching operation
    [maxScore, maxIdx] = max(scores);
    specificOperation = operations{maxIdx, 1};
    
    % If no strong match, use generic operation
    if maxScore < 0.15
        specificOperation = 'general_computation';
        maxScore = 0.4;
    end
    
    identification = struct(...
        'specificOperation', specificOperation, ...
        'confidence', maxScore, ...
        'operationScores', scores, ...
        'operationList', {operations(:, 1)} ...
    );
end

function extraction = extractComputationalParameters(query, tokens, context)
    % Extract numerical parameters and data characteristics from query
    
    parameters = struct();
    confidence = 0.5; % Base confidence
    
    % Extract matrix dimensions (e.g., "100*x100 matrix", "5 by 3 array")
    dimPattern1 = '(\d+)\s*[xX×]\s*(\d+)';
    dimPattern2 = '(\d+)\s+by\s+(\d+)';
    
    dimMatch = regexp(query, dimPattern1, 'tokens');
    if isempty(dimMatch)
        dimMatch = regexp(query, dimPattern2, 'tokens');
    end
    
    if ~isempty(dimMatch)
        parameters.matrixRows = str2double(dimMatch{1}{1});
        parameters.matrixCols = str2double(dimMatch{1}{2});
        confidence = confidence + 0.2;
    end
    
    % Extract scalar numerical values
    numPattern = '\b\d+\.?\d*\b';
    numbers = regexp(query, numPattern, 'match');
    if ~isempty(numbers)
        parameters.scalarValues = cellfun(@str2double, numbers);
        confidence = confidence + 0.1;
    end
    
    % Extract data type specifications
    if contains(query, 'sparse')
        parameters.matrixType = 'sparse';
        confidence = confidence + 0.1;
    elseif contains(query, 'full') || contains(query, 'dense')
        parameters.matrixType = 'full';
        confidence = confidence + 0.1;
    end
    
    % Extract precision requirements
    if contains(query, 'single precision')
        parameters.precision = 'single';
    elseif contains(query, 'double precision') || contains(query, 'high precision')
        parameters.precision = 'double';
    end
    
    % Check workspace context if provided
    if nargin > 2 && ~isempty(context) && isfield(context, 'variables')
        parameters.workspaceContext = context.variables;
        confidence = confidence + 0.1;
    end
    
    % Cap confidence at 1.0
    confidence = min(confidence, 1.0);
    
    extraction = struct(...
        'parameters', parameters, ...
        'confidence', confidence ...
    );
end

function identification = identifyMathematicalConstraints(query, domain)
    % Identify mathematical and computational constraints from query
    
    constraints = {};
    
    % Matrix properties
    if contains(query, 'symmetric')
        constraints{end+1} = 'symmetric';
    end
    if contains(query, 'positive definite')
        constraints{end+1} = 'positive_definite';
    end
    if contains(query, 'hermitian')
        constraints{end+1} = 'hermitian';
    end
    if contains(query, 'orthogonal')
        constraints{end+1} = 'orthogonal';
    end
    if contains(query, 'diagonal')
        constraints{end+1} = 'diagonal';
    end
    
    % Value constraints
    if contains(query, 'real') && ~contains(query, 'real-time')
        constraints{end+1} = 'real_valued';
    end
    if contains(query, 'complex')
        constraints{end+1} = 'complex_valued';
    end
    if contains(query, 'positive')
        constraints{end+1} = 'positive_values';
    end
    if contains(query, 'bounded')
        constraints{end+1} = 'bounded';
    end
    
    % Computational constraints
    if contains(query, 'fast') || contains(query, 'efficient') || contains(query, 'quick')
        constraints{end+1} = 'performance_critical';
    end
    if contains(query, 'accurate') || contains(query, 'precise')
        constraints{end+1} = 'high_accuracy';
    end
    if contains(query, 'stable') || contains(query, 'robust')
        constraints{end+1} = 'numerical_stability';
    end
    
    % Domain-specific constraints
    switch domain
        case 'optimisation'
            if contains(query, 'global')
                constraints{end+1} = 'global_optimum';
            end
            if contains(query, 'local')
                constraints{end+1} = 'local_optimum';
            end
            if contains(query, 'convex')
                constraints{end+1} = 'convex_problem';
            end
            
        case 'signal_processing'
            if contains(query, 'real-time')
                constraints{end+1} = 'real_time_processing';
            end
            if contains(query, 'causal')
                constraints{end+1} = 'causal_filter';
            end
            
        case 'differential_equations'
            if contains(query, 'stiff')
                constraints{end+1} = 'stiff_system';
            end
    end
    
    identification = struct(...
        'constraints', {constraints}, ...
        'constraintCount', length(constraints) ...
    );
end
