%% chapter_AI_MATLAB_example_AIForProgramming_01.m
% AI-assisted MATLAB function with comprehensive input validation, error handling, and documentation following industry best practices.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_example_AIForProgramming_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [properties] = calculateGeometricProperties(shape, parameters)
    % CALCULATEGEOMETRICPROPERTIES Compute area, perimeter, and centroid
    %   PROPERTIES = CALCULATEGEOMETRICPROPERTIES(SHAPE, PARAMETERS)
    %   calculates geometric properties for specified shape types.
    %
    %   Inputs:
    %       shape      - Character vector specifying shape type:
    %                    'circle', 'rectangle', 'triangle', or 'ellipse'
    %       parameters - Numeric vector containing shape-specific parameters:
    %                    Circle: [radius]
    %                    Rectangle: [width, height]
    %                    Triangle: [base, height]
    %                    Ellipse: [semi_major_axis, semi_minor_axis]
    %
    %   Outputs:
    %       properties - Scalar structure with fields:
    %                    .area      - Surface area (positive scalar)
    %                    .perimeter - Perimeter length (positive scalar)
    %                    .centroid  - [x, y] coordinates (for non-centered shapes)
    %                    .shape     - Shape type (character vector)
    %
    %   Example:
    %       props = calculateGeometricProperties('circle', 5.0);
    %       fprintf('Area: %.2f, Perimeter: %.2f\n', ...
    %               props.area, props.perimeter);
    %
    %   See also POLYAREA, BOUNDARY, CONVHULL.
    
    % Input validation: shape type
    validateattributes(shape, {'char', 'string'}, {'nonempty'}, ...
        'calculateGeometricProperties', 'shape', 1);
    shape = lower(char(shape)); % Normalise to lowercase char
    validShapes = {'circle', 'rectangle', 'triangle', 'ellipse'};
    if ~ismember(shape, validShapes)
        error('calculateGeometricProperties:InvalidShape', ...
            'Shape must be one of: %s', strjoin(validShapes, ', '));
    end
    
    % Input validation: parameters
    validateattributes(parameters, {'numeric'}, ...
        {'positive', 'finite', 'real', 'vector', 'nonempty'}, ...
        'calculateGeometricProperties', 'parameters', 2);
    
    % Validate parameter count for specified shape
    expectedParamCount = containers.Map({'circle', 'rectangle', 'triangle', 'ellipse'}, {1, 2, 2, 2});
    if length(parameters) ~= expectedParamCount(shape)
        error('calculateGeometricProperties:InvalidParameterCount', ...
            'Shape "%s" requires %d parameter(s), but %d provided', ...
            shape, expectedParamCount(shape), length(parameters));
    end
    
    % Initialise output structure
    properties = struct('area', [], 'perimeter', [], ...
                       'centroid', [0, 0], 'shape', shape);
    
    % Calculate properties based on shape type
    switch shape
        case 'circle'
            radius = parameters(1);
            properties.area = pi * radius^2;
            properties.perimeter = 2 * pi * radius;
            
        case 'rectangle'
            width = parameters(1);
            height = parameters(2);
            properties.area = width * height;
            properties.perimeter = 2 * (width + height);
            
        case 'triangle'
            base = parameters(1);
            height = parameters(2);
            properties.area = 0.5 * base * height;
            % Perimeter requires additional information (assume isosceles)
            side_length = sqrt((base/2)^2 + height^2);
            properties.perimeter = base + 2 * side_length;
            properties.centroid = [base/2, height/3]; % Centroid for triangle
            
        case 'ellipse'
            a = parameters(1); % Semi-major axis
            b = parameters(2); % Semi-minor axis
            properties.area = pi * a * b;
            % Perimeter approximation using Ramanujan formula
            h = ((a - b)^2) / ((a + b)^2);
            properties.perimeter = pi * (a + b) * (1 + (3*h)/(10 + sqrt(4 - 3*h)));
    end
    
    % Validate computed results (sanity checks)
    assert(properties.area > 0, ...
        'calculateGeometricProperties:InvalidArea', ...
        'Computed area must be positive');
    assert(properties.perimeter > 0, ...
        'calculateGeometricProperties:InvalidPerimeter', ...
        'Computed perimeter must be positive');
    
    % Display results if no output arguments requested
    if nargout == 0
        fprintf('Geometric Properties for %s:\n', upper(shape));
        fprintf('  Area: %.4f square units\n', properties.area);
        fprintf('  Perimeter: %.4f units\n', properties.perimeter);
        if any(properties.centroid ~= 0)
            fprintf('  Centroid: (%.4f, %.4f)\n', properties.centroid);
        end
    end
end
