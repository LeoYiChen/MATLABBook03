%% chapter_AI_MATLAB_example_MAS_01.m
% Multi-agent coordinator with agent registry, message routing, and parallel task execution. The coordinator manages a population of IntelligentAgent instances and provides methods for agent registration, inter-agent messaging, broadcast communication, and distributed task allocation using parfeval.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_example_MAS_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
classdef MultiAgentCoordinator < handle
    % MultiAgentCoordinator - Manages a multi-agent system with A2A support
    % Provides agent registration, message routing, and collaborative
    % task execution across a population of IntelligentAgent instances.
    
    properties (Access = private)
        agentRegistry   containers.Map  % AgentID -> agent struct
        messageHistory  table           % Record of all routed messages
    end
    
    properties (Access = public)
        CoordinatorID   string          % Identifier for this coordinator
        ActiveAgents    double          % Count of registered agents
    end
    
    methods (Access = public)
        
        
        
        
        
    end
end

% Local functions (moved to end so this listing is a valid MATLAB script)
        function obj = MultiAgentCoordinator(coordinatorID)
            % Constructor: initialise the multi-agent coordinator
            obj.CoordinatorID = coordinatorID;
            obj.agentRegistry = containers.Map('KeyType', 'char', ...
                                               'ValueType', 'any');
            obj.ActiveAgents  = 0;
            obj.messageHistory = table('Size', [0, 5], ...
                'VariableTypes', {'datetime','string','string','string','string'}, ...
                'VariableNames', {'Timestamp','From','To','Type','Status'});
            
            fprintf('Coordinator %s initialised.\n', coordinatorID);
        end

        function registerAgent(obj, agent)
            % Register an IntelligentAgent with the coordinator
            %   agent - an IntelligentAgent instance
            
            agentID = char(agent.AgentID);
            
            % Create a registry entry with capability metadata
            entry.instance    = agent;
            entry.status      = "Active";
            entry.registered  = datetime('now');
            entry.taskCount   = 0;
            
            obj.agentRegistry(agentID) = entry;
            obj.ActiveAgents = obj.ActiveAgents + 1;
            
            fprintf('Agent %s registered (total active: %d).\n', ...
                    agentID, obj.ActiveAgents);
        end

        function response = routeMessage(obj, senderID, recipientID, message)
            % Route a message from one agent to another
            %   senderID    - AgentID of the sending agent
            %   recipientID - AgentID of the receiving agent
            %   message     - struct with fields: type, content
            
            if ~obj.agentRegistry.isKey(char(recipientID))
                response = struct('status', 'error', ...
                    'detail', 'Recipient agent not found');
                return;
            end
            
            % Retrieve the recipient agent instance
            recipientEntry = obj.agentRegistry(char(recipientID));
            recipientAgent = recipientEntry.instance;
            
            % Attach sender information to the message
            message.sender = senderID;
            
            % Deliver the message to the recipient
            response = recipientAgent.processMessage(message);
            
            % Log the routed message
            newRow = {datetime('now'), string(senderID), ...
                      string(recipientID), string(message.type), ...
                      string(response.status)};
            obj.messageHistory = [obj.messageHistory; newRow];
        end

        function responses = broadcastMessage(obj, senderID, message)
            % Broadcast a message to all registered agents
            %   Returns a containers.Map of AgentID -> response
            
            responses = containers.Map('KeyType','char','ValueType','any');
            agentIDs  = obj.agentRegistry.keys();
            
            for k = 1:numel(agentIDs)
                targetID = agentIDs{k};
                if ~strcmp(targetID, char(senderID))
                    resp = obj.routeMessage(senderID, targetID, message);
                    responses(targetID) = resp;
                end
            end
        end

        function results = executeDistributedTask(obj, taskData, agentIDs)
            % Execute a task distributed across specified agents
            % Uses parfeval for concurrent execution
            %   taskData - struct with task parameters
            %   agentIDs - cell array of AgentID strings
            
            fprintf('Distributing task across %d agents...\n', ...
                    numel(agentIDs));
            
            % Create a parallel pool if one does not already exist
            pool = gcp('nocreate');
            if isempty(pool)
                pool = parpool('Processes', ...
                    min(numel(agentIDs), feature('numcores')));
            end
            
            % Submit asynchronous tasks for each agent
            futures(numel(agentIDs)) = parallel.FevalFuture;
            for k = 1:numel(agentIDs)
                aID   = agentIDs{k};
                entry = obj.agentRegistry(char(aID));
                agent = entry.instance;
                
                % Each agent selects an action based on its observation
                observation = taskData.observations(k, :);
                futures(k) = parfeval(pool, @agent.selectAction, 2, ...
                                      observation);
            end
            
            % Collect results as they complete
            results = struct();
            results.actions     = zeros(numel(agentIDs), 1);
            results.agentIDs    = agentIDs;
            results.completedAt = NaT(numel(agentIDs), 1);
            
            for k = 1:numel(agentIDs)
                [completedIdx, action, ~] = fetchNext(futures);
                results.actions(completedIdx) = action;
                results.completedAt(completedIdx) = datetime('now');
                fprintf('  Agent %s completed (action: %d).\n', ...
                        agentIDs{completedIdx}, action);
            end
            
            fprintf('Distributed task completed.\n');
        end

        function summary = generateNetworkSummary(obj)
            % Generate a summary of the multi-agent network
            summary.coordinatorID  = obj.CoordinatorID;
            summary.totalAgents    = obj.ActiveAgents;
            summary.totalMessages  = height(obj.messageHistory);
            summary.agentIDs       = obj.agentRegistry.keys();
            summary.timestamp      = datetime('now');
            
            % Compute per-agent statistics
            agentIDs = summary.agentIDs;
            for k = 1:numel(agentIDs)
                entry = obj.agentRegistry(agentIDs{k});
                report = entry.instance.generateStatusReport();
                summary.agentReports{k} = report;
            end
        end
