%% chapter_AI_codegen_complete.m
% Natural language to MATLAB code generation system.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_codegen_complete
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function result = naturalLanguageCodeGenerator(naturalLanguageDescription)
% Natural Language to MATLAB Code Generation System
% Author: Dr Yi Chen
% Version: 1.0
% Description: Converts natural language descriptions to executable MATLAB code

try
    % Step 1: Parse natural language input
    semanticStructure = parseNaturalLanguage(naturalLanguageDescription);
    
    % Step 2: Generate code structure
    codeStructure = generateCodeStructure(semanticStructure);
    
    % Step 3: Generate actual MATLAB code
    generatedCode = generateMATLABCode(codeStructure);
    
    % Step 4: Validate and optimise code
    validatedCode = validateAndOptimiseCode(generatedCode);
    
    % Step 5: Test generated code
    testResults = testGeneratedCode(validatedCode);
    
    % Package results
    result = packageResults(naturalLanguageDescription, validatedCode, testResults);
    result.success = true;
    
catch ME
    result.success = false;
    result.error = ME.message;
    result.message = sprintf('Code generation failed for: %s', naturalLanguageDescription);
end

end

function semanticStructure = parseNaturalLanguage(description)
semanticStructure = struct();

% Preprocess the description
description = preprocessDescription(description);

% Tokenise
tokens = tokeniseDescription(description);

% Identify algorithmic patterns
algorithmicPatterns = identifyAlgorithmicPatterns(tokens);

% Extract mathematical expressions
mathematicalExpressions = extractMathematicalExpressions(tokens);

% Identify data operations
dataOperations = identifyDataOperations(tokens);

% Identify control structures
controlStructures = identifyControlStructures(tokens);

% Identify function calls
functionCalls = identifyFunctionCalls(tokens);

% Package semantic structure
semanticStructure.originalDescription = description;
semanticStructure.tokens = tokens;
semanticStructure.algorithmicPatterns = algorithmicPatterns;
semanticStructure.mathematicalExpressions = mathematicalExpressions;
semanticStructure.dataOperations = dataOperations;
semanticStructure.controlStructures = controlStructures;
semanticStructure.functionCalls = functionCalls;
semanticStructure.complexity = assessDescriptionComplexity(tokens);

end

function processedDesc = preprocessDescription(description)
% Convert to lowercase and clean up
processedDesc = lower(strtrim(description));

% Replace common phrases with standardised terms
replacements = {
    'for each', 'for every';
    'compute', 'calculate';
    'plot', 'visualise';
    'matrix', 'array';
    'if condition', 'if'
};

for i = 1:size(replacements, 1)
    processedDesc = strrep(processedDesc, replacements{i,1}, replacements{i,2});
end

end

function tokens = tokeniseDescription(description)
% Split into sentences first
sentences = split(description, '.');
sentences = sentences(~cellfun('isempty', sentences));

tokens = struct();
tokens.sentences = sentences;
tokens.words = {};

% Tokenise each sentence
for i = 1:length(sentences)
    sentence = strtrim(sentences{i});
    words = strsplit(sentence);
    tokens.words = [tokens.words, words];
end

% Remove empty tokens
tokens.words = tokens.words(~cellfun('isempty', tokens.words));

end

function patterns = identifyAlgorithmicPatterns(tokens)
patterns = {};
words = tokens.words;

% Loop patterns
if any(ismember(words, {'for', 'loop', 'iterate', 'repeat'}))
    patterns{end+1} = 'loop';
end

% Conditional patterns
if any(ismember(words, {'if', 'condition', 'when', 'check'}))
    patterns{end+1} = 'conditional';
end

% Sorting patterns
if any(ismember(words, {'sort', 'order', 'arrange'}))
    patterns{end+1} = 'sorting';
end

% Search patterns
if any(ismember(words, {'find', 'search', 'locate'}))
    patterns{end+1} = 'search';
end

% Optimisation patterns
if any(ismember(words, {'minimise', 'maximize', 'optimise', 'best'}))
    patterns{end+1} = 'optimisation';
end

% Interpolation patterns
if any(ismember(words, {'interpolate', 'approximate', 'estimate'}))
    patterns{end+1} = 'interpolation';
end

end

function expressions = extractMathematicalExpressions(tokens)
expressions = {};
words = tokens.words;

% Mathematical functions
mathFunctions = {'sin', 'cos', 'tan', 'exp', 'log', 'sqrt', 'abs', 'sum', 'mean', 'std'};
foundFunctions = intersect(words, mathFunctions);

for i = 1:length(foundFunctions)
    expressions{end+1} = struct('type', 'function', 'name', foundFunctions{i});
end

% Mathematical operations
if any(ismember(words, {'add', 'plus', 'addition'}))
    expressions{end+1} = struct('type', 'operation', 'name', 'addition');
end

if any(ismember(words, {'subtract', 'minus', 'subtraction'}))
    expressions{end+1} = struct('type', 'operation', 'name', 'subtraction');
end

if any(ismember(words, {'multiply', 'times', 'multiplication'}))
    expressions{end+1} = struct('type', 'operation', 'name', 'multiplication');
end

if any(ismember(words, {'divide', 'division'}))
    expressions{end+1} = struct('type', 'operation', 'name', 'division');
end

% Extract numerical values
numbers = [];
for i = 1:length(words)
    num = str2double(words{i});
    if ~isnan(num)
        numbers(end+1) = num;
    end
end

if ~isempty(numbers)
    expressions{end+1} = struct('type', 'numbers', 'values', numbers);
end

end

function operations = identifyDataOperations(tokens)
operations = {};
words = tokens.words;

% Data loading operations
if any(ismember(words, {'load', 'read', 'import'}))
    operations{end+1} = struct('type', 'data_loading', 'operation', 'load');
end

% Data creation operations
if any(ismember(words, {'create', 'generate', 'make'}))
    operations{end+1} = struct('type', 'data_creation', 'operation', 'create');
end

% Data transformation operations
if any(ismember(words, {'transform', 'convert', 'change'}))
    operations{end+1} = struct('type', 'data_transformation', 'operation', 'transform');
end

% Data analysis operations
if any(ismember(words, {'analyse', 'analyze', 'examine'}))
    operations{end+1} = struct('type', 'data_analysis', 'operation', 'analyse');
end

% Filtering operations
if any(ismember(words, {'filter', 'select', 'choose'}))
    operations{end+1} = struct('type', 'data_filtering', 'operation', 'filter');
end

end

function structures = identifyControlStructures(tokens)
structures = {};
words = tokens.words;

% For loops
if any(ismember(words, {'for', 'each', 'every'}))
    structures{end+1} = struct('type', 'for_loop');
end

% While loops
if any(ismember(words, {'while', 'until'}))
    structures{end+1} = struct('type', 'while_loop');
end

% If statements
if any(ismember(words, {'if', 'when', 'condition'}))
    structures{end+1} = struct('type', 'if_statement');
end

% Switch statements
if any(ismember(words, {'switch', 'case', 'depending'}))
    structures{end+1} = struct('type', 'switch_statement');
end

% Try-catch blocks
if any(ismember(words, {'try', 'catch', 'error', 'exception'}))
    structures{end+1} = struct('type', 'try_catch');
end

end

function calls = identifyFunctionCalls(tokens)
calls = {};
words = tokens.words;

% MATLAB built-in functions
builtinFunctions = {
    'plot', 'scatter', 'histogram', 'bar', 'pie';
    'mean', 'median', 'std', 'var', 'range';
    'sort', 'unique', 'find', 'max', 'min';
    'size', 'length', 'numel', 'isempty'
};

for i = 1:numel(builtinFunctions)
    func = builtinFunctions{i};
    if any(ismember(words, func))
        calls{end+1} = struct('type', 'builtin', 'name', func);
    end
end

% Toolbox functions
toolboxFunctions = {
    'fft', 'ifft', 'conv', 'filter';
    'polyfit', 'polyval', 'interp1', 'spline';
    'ode45', 'fsolve', 'fminsearch', 'lsqcurvefit'
};

for i = 1:numel(toolboxFunctions)
    func = toolboxFunctions{i};
    if any(ismember(words, func))
        calls{end+1} = struct('type', 'toolbox', 'name', func);
    end
end

end

function complexity = assessDescriptionComplexity(tokens)
words = tokens.words;

complexityScore = 0;

% Length-based complexity
if length(words) > 20
    complexityScore = complexityScore + 1;
end

% Control structure complexity
controlWords = {'for', 'while', 'if', 'switch', 'try'};
controlCount = sum(ismember(words, controlWords));
complexityScore = complexityScore + controlCount;

% Mathematical complexity
mathWords = {'sin', 'cos', 'exp', 'log', 'integral', 'derivative'};
mathCount = sum(ismember(words, mathWords));
complexityScore = complexityScore + mathCount * 0.5;

% Determine complexity level
if complexityScore < 2
    complexity = 'simple';
elseif complexityScore < 5
    complexity = 'moderate';
else
    complexity = 'complex';
end

end

function codeStructure = generateCodeStructure(semanticStructure)
codeStructure = struct();

% Determine main code type
codeStructure.codeType = determineCodeType(semanticStructure);

% Generate function signature
codeStructure.functionSignature = generateFunctionSignature(semanticStructure);

% Generate variable declarations
codeStructure.variableDeclarations = generateVariableDeclarations(semanticStructure);

% Generate main algorithm
codeStructure.mainAlgorithm = generateMainAlgorithm(semanticStructure);

% Generate output handling
codeStructure.outputHandling = generateOutputHandling(semanticStructure);

% Generate error handling
codeStructure.errorHandling = generateErrorHandling(semanticStructure);

end

function codeType = determineCodeType(semanticStructure)
patterns = semanticStructure.algorithmicPatterns;
dataOps = semanticStructure.dataOperations;
mathExprs = semanticStructure.mathematicalExpressions;

if any(strcmp(patterns, 'loop')) && ~isempty(mathExprs)
    codeType = 'iterative_calculation';
elseif any(contains({dataOps.type}, 'analysis'))
    codeType = 'data_analysis';
elseif any(contains({dataOps.type}, 'transformation'))
    codeType = 'data_processing';
elseif ~isempty(mathExprs)
    codeType = 'mathematical_computation';
elseif any(strcmp(patterns, 'optimisation'))
    codeType = 'optimisation';
else
    codeType = 'general_algorithm';
end

end

function signature = generateFunctionSignature(semanticStructure)
% Generate appropriate function name
functionName = generateFunctionName(semanticStructure);

% Determine input parameters
inputParams = determineInputParameters(semanticStructure);

% Determine output parameters
outputParams = determineOutputParameters(semanticStructure);

if isempty(outputParams)
    signature = sprintf('function %s(%s)', functionName, strjoin(inputParams, ', '));
else
    signature = sprintf('function %s = %s(%s)', strjoin(outputParams, ', '), functionName, strjoin(inputParams, ', '));
end

end

function functionName = generateFunctionName(semanticStructure)
codeType = determineCodeType(semanticStructure);

switch codeType
    case 'iterative_calculation'
        functionName = 'iterativeCalculation';
    case 'data_analysis'
        functionName = 'dataAnalysis';
    case 'data_processing'
        functionName = 'processData';
    case 'mathematical_computation'
        functionName = 'mathComputation';
    case 'optimisation'
        functionName = 'optimiseFunction';
    otherwise
        functionName = 'generatedFunction';
end

end

function inputParams = determineInputParameters(semanticStructure)
inputParams = {};

% Check for data operations that require input
dataOps = semanticStructure.dataOperations;
for i = 1:length(dataOps)
    if strcmp(dataOps{i}.type, 'data_loading')
        inputParams{end+1} = 'inputData';
        break;
    end
end

% Check for mathematical expressions with variables
mathExprs = semanticStructure.mathematicalExpressions;
hasNumbers = false;
for i = 1:length(mathExprs)
    if strcmp(mathExprs{i}.type, 'numbers')
        hasNumbers = true;
        break;
    end
end

if ~hasNumbers && ~isempty(mathExprs)
    inputParams{end+1} = 'x';
end

% Default input if none specified
if isempty(inputParams)
    inputParams{end+1} = 'inputData';
end

end

function outputParams = determineOutputParameters(semanticStructure)
outputParams = {};

patterns = semanticStructure.algorithmicPatterns;
codeType = determineCodeType(semanticStructure);

switch codeType
    case 'data_analysis'
        outputParams = {'analysisResults'};
    case 'mathematical_computation'
        outputParams = {'result'};
    case 'optimisation'
        outputParams = {'optimisedValue', 'optimalParameters'};
    case 'data_processing'
        outputParams = {'processedData'};
    otherwise
        outputParams = {'result'};
end

end

function declarations = generateVariableDeclarations(semanticStructure)
declarations = {};

codeType = determineCodeType(semanticStructure);

% Standard variable declarations based on code type
switch codeType
    case 'iterative_calculation'
        declarations{end+1} = '% Initialise variables for iterative calculation';
        declarations{end+1} = 'result = 0;';
        declarations{end+1} = 'iteration = 0;';
        
    case 'data_analysis'
        declarations{end+1} = '% Initialise analysis variables';
        declarations{end+1} = 'analysisResults = struct();';
        
    case 'mathematical_computation'
        declarations{end+1} = '% Initialise computation variables';
        declarations{end+1} = 'result = [];';
        
    case 'optimisation'
        declarations{end+1} = '% Initialise optimisation variables';
        declarations{end+1} = 'options = optimset();';
        declarations{end+1} = 'initialGuess = 0;';
end

% Add specific declarations based on identified patterns
if any(strcmp(semanticStructure.algorithmicPatterns, 'loop'))
    declarations{end+1} = 'loopCounter = 1;';
end

end

function algorithm = generateMainAlgorithm(semanticStructure)
algorithm = {};

patterns = semanticStructure.algorithmicPatterns;
mathExprs = semanticStructure.mathematicalExpressions;
dataOps = semanticStructure.dataOperations;
controlStructs = semanticStructure.controlStructures;

% Generate algorithm based on identified patterns
if any(strcmp(patterns, 'loop'))
    algorithm = [algorithm, generateLoopCode(semanticStructure)];
end

if any(strcmp(patterns, 'conditional'))
    algorithm = [algorithm, generateConditionalCode(semanticStructure)];
end

if any(strcmp(patterns, 'sorting'))
    algorithm = [algorithm, generateSortingCode(semanticStructure)];
end

if any(strcmp(patterns, 'search'))
    algorithm = [algorithm, generateSearchCode(semanticStructure)];
end

if ~isempty(mathExprs)
    algorithm = [algorithm, generateMathematicalCode(mathExprs)];
end

if ~isempty(dataOps)
    algorithm = [algorithm, generateDataOperationCode(dataOps)];
end

% Default algorithm if nothing specific identified
if isempty(algorithm)
    algorithm{end+1} = '% Default processing';
    algorithm{end+1} = 'result = inputData;';
end

end

function loopCode = generateLoopCode(semanticStructure)
loopCode = {};

% Determine loop type
if any(strcmp({semanticStructure.controlStructures.type}, 'for_loop'))
    loopCode{end+1} = '% For loop implementation';
    loopCode{end+1} = 'for i = 1:length(inputData)';
    loopCode{end+1} = '    % Process each element';
    loopCode{end+1} = '    result(i) = processElement(inputData(i));';
    loopCode{end+1} = 'end';
elseif any(strcmp({semanticStructure.controlStructures.type}, 'while_loop'))
    loopCode{end+1} = '% While loop implementation';
    loopCode{end+1} = 'while condition';
    loopCode{end+1} = '    % Process until condition is met';
    loopCode{end+1} = '    result = updateResult(result);';
    loopCode{end+1} = '    condition = checkCondition(result);';
    loopCode{end+1} = 'end';
else
    loopCode{end+1} = '% Generic loop implementation';
    loopCode{end+1} = 'for i = 1:10 % Default loop range';
    loopCode{end+1} = '    result(i) = i * 2; % Default operation';
    loopCode{end+1} = 'end';
end

end

function conditionalCode = generateConditionalCode(semanticStructure)
conditionalCode = {};

conditionalCode{end+1} = '% Conditional logic implementation';
conditionalCode{end+1} = 'if isempty(inputData)';
conditionalCode{end+1} = '    result = [];';
conditionalCode{end+1} = '    return;';
conditionalCode{end+1} = 'end';
conditionalCode{end+1} = '';
conditionalCode{end+1} = 'if size(inputData, 1) > size(inputData, 2)';
conditionalCode{end+1} = '    % Process as column vector';
conditionalCode{end+1} = '    result = processColumnVector(inputData);';
conditionalCode{end+1} = 'else';
conditionalCode{end+1} = '    % Process as row vector or matrix';
conditionalCode{end+1} = '    result = processMatrix(inputData);';
conditionalCode{end+1} = 'end';

end

function sortingCode = generateSortingCode(semanticStructure)
sortingCode = {};

sortingCode{end+1} = '% Sorting implementation';
sortingCode{end+1} = '[sortedData, sortIndices] = sort(inputData);';
sortingCode{end+1} = 'result = struct();';
sortingCode{end+1} = 'result.sortedData = sortedData;';
sortingCode{end+1} = 'result.originalIndices = sortIndices;';

end

function searchCode = generateSearchCode(semanticStructure)
searchCode = {};

searchCode{end+1} = '% Search implementation';
searchCode{end+1} = 'searchValue = max(inputData); % Default: search for maximum';
searchCode{end+1} = 'foundIndices = find(inputData == searchValue);';
searchCode{end+1} = 'result = struct();';
searchCode{end+1} = 'result.searchValue = searchValue;';
searchCode{end+1} = 'result.foundIndices = foundIndices;';
searchCode{end+1} = 'result.foundValues = inputData(foundIndices);';

end

function mathCode = generateMathematicalCode(mathExprs)
mathCode = {};

mathCode{end+1} = '% Mathematical computations';

for i = 1:length(mathExprs)
    expr = mathExprs{i};
    
    switch expr.type
        case 'function'
            switch expr.name
                case 'sin'
                    mathCode{end+1} = 'result = sin(inputData);';
                case 'cos'
                    mathCode{end+1} = 'result = cos(inputData);';
                case 'exp'
                    mathCode{end+1} = 'result = exp(inputData);';
                case 'log'
                    mathCode{end+1} = 'result = log(inputData);';
                case 'sqrt'
                    mathCode{end+1} = 'result = sqrt(abs(inputData));';
                case 'mean'
                    mathCode{end+1} = 'result = mean(inputData);';
                case 'std'
                    mathCode{end+1} = 'result = std(inputData);';
                case 'sum'
                    mathCode{end+1} = 'result = sum(inputData);';
                otherwise
                    mathCode{end+1} = sprintf('result = %s(inputData);', expr.name);
            end
            
        case 'operation'
            switch expr.name
                case 'addition'
                    mathCode{end+1} = 'result = inputData + 1; % Default addition';
                case 'subtraction'
                    mathCode{end+1} = 'result = inputData - 1; % Default subtraction';
                case 'multiplication'
                    mathCode{end+1} = 'result = inputData * 2; % Default multiplication';
                case 'division'
                    mathCode{end+1} = 'result = inputData / 2; % Default division';
            end
            
        case 'numbers'
            numbers = expr.values;
            mathCode{end+1} = sprintf('numbers = [%s];', num2str(numbers));
            mathCode{end+1} = 'result = numbers;';
    end
end

end

function dataCode = generateDataOperationCode(dataOps)
dataCode = {};

for i = 1:length(dataOps)
    op = dataOps{i};
    
    switch op.type
        case 'data_loading'
            dataCode{end+1} = '% Data loading operation';
            dataCode{end+1} = 'if ischar(inputData)';
            dataCode{end+1} = '    loadedData = load(inputData);';
            dataCode{end+1} = '    result = loadedData;';
            dataCode{end+1} = 'else';
            dataCode{end+1} = '    result = inputData;';
            dataCode{end+1} = 'end';
            
        case 'data_creation'
            dataCode{end+1} = '% Data creation operation';
            dataCode{end+1} = 'result = randn(100, 2); % Generate random data';
            
        case 'data_transformation'
            dataCode{end+1} = '% Data transformation operation';
            dataCode{end+1} = 'result = normalize(inputData); % Normalise data';
            
        case 'data_analysis'
            dataCode{end+1} = '% Data analysis operation';
            dataCode{end+1} = 'analysisResults = struct();';
            dataCode{end+1} = 'analysisResults.mean = mean(inputData);';
            dataCode{end+1} = 'analysisResults.std = std(inputData);';
            dataCode{end+1} = 'analysisResults.min = min(inputData);';
            dataCode{end+1} = 'analysisResults.max = max(inputData);';
            dataCode{end+1} = 'result = analysisResults;';
            
            case 'data_filtering'
                dataCode{end+1} = '% Data filtering operation';
                dataCode{end+1} = 'threshold = mean(inputData) + std(inputData);';
                dataCode{end+1} = 'filteredIndices = inputData <= threshold;';
                dataCode{end+1} = 'result = inputData(filteredIndices);';
        end
    end
end

function outputCode = generateOutputHandling(semanticStructure)
    outputCode = {};
    
    codeType = determineCodeType(semanticStructure);
    
    outputCode{end+1} = '';
    outputCode{end+1} = '% Output handling';
    
    switch codeType
        case 'data_analysis'
            outputCode{end+1} = 'if nargout == 0';
            outputCode{end+1} = '    disp(''Analysis Results:'');';
            outputCode{end+1} = '    disp(analysisResults);';
            outputCode{end+1} = 'end';
            
        case 'mathematical_computation'
            outputCode{end+1} = 'if nargout == 0';
            outputCode{end+1} = '    fprintf(''Computation result: %.4f\\n'', result);';
            outputCode{end+1} = 'end';
            
        case 'data_processing'
            outputCode{end+1} = 'if nargout == 0';
            outputCode{end+1} = '    fprintf(''Processed %d data points\\n'', numel(processedData));';
            outputCode{end+1} = 'end';
            
        otherwise
            outputCode{end+1} = 'if nargout == 0';
            outputCode{end+1} = '    disp(result);';
            outputCode{end+1} = 'end';
    end
end

function errorCode = generateErrorHandling(semanticStructure)
    errorCode = {};
    
    errorCode{end+1} = '';
    errorCode{end+1} = '% Error handling';
    errorCode{end+1} = 'if isempty(inputData)';
    errorCode{end+1} = '    error(''Input data cannot be empty'');';
    errorCode{end+1} = 'end';
    errorCode{end+1} = '';
    errorCode{end+1} = 'if ~isnumeric(inputData)';
    errorCode{end+1} = '    error(''Input data must be numeric'');';
    errorCode{end+1} = 'end';
end

function matlabCode = generateMATLABCode(codeStructure)
    matlabCode = {};
    
    % Add function signature
    matlabCode{end+1} = codeStructure.functionSignature;
    matlabCode{end+1} = sprintf('    %% Generated by Natural Language Code Generator', '');
    matlabCode{end+1} = sprintf('    %% Author: Dr Yi Chen', '');
    matlabCode{end+1} = '';
    
    % Add variable declarations
    matlabCode = [matlabCode, addIndentation(codeStructure.variableDeclarations)];
    matlabCode{end+1} = '';
    
    % Add error handling
    matlabCode = [matlabCode, addIndentation(codeStructure.errorHandling)];
    matlabCode{end+1} = '';
    
    % Add main algorithm
    matlabCode = [matlabCode, addIndentation(codeStructure.mainAlgorithm)];
    
    % Add output handling
    matlabCode = [matlabCode, addIndentation(codeStructure.outputHandling)];
    
    % Add function end
    matlabCode{end+1} = 'end';
end

function indentedCode = addIndentation(codeLines)
    indentedCode = {};
    for i = 1:length(codeLines)
        line = codeLines{i};
        if ~isempty(line) && ~startsWith(line, '%')
            indentedCode{end+1} = ['    ' line];
        else
            indentedCode{end+1} = line;
        end
    end
end

function validatedCode = validateAndOptimiseCode(generatedCode)
    validatedCode = generatedCode;
    
    % Basic syntax validation
    try
        % Check for balanced parentheses and brackets
        fullCode = strjoin(generatedCode, '\n');
        if ~isBalancedDelimiters(fullCode)
            error('Unbalanced delimiters detected');
        end
        
        % Check for valid MATLAB syntax patterns
        validatedCode = optimiseCode(validatedCode);
        
    catch ME
        warning('Code validation failed: %s', ME.message);
    end
end

function balanced = isBalancedDelimiters(code)
    parentheses = sum(code == '(') - sum(code == ')');
    brackets = sum(code == '[') - sum(code == ']');
    braces = sum(code == '{') - sum(code == '}');
    
    balanced = (parentheses == 0) && (brackets == 0) && (braces == 0);
end

function optimisedCode = optimiseCode(code)
    optimisedCode = code;
    
    % Remove redundant blank lines
    nonEmptyLines = ~cellfun(@(x) isempty(strtrim(x)), code);
    consecutiveEmpties = [false; ~nonEmptyLines(1:end-1) & ~nonEmptyLines(2:end)];
    optimisedCode = code(~consecutiveEmpties);
    
    % Optimise variable naming
    optimisedCode = optimiseVariableNames(optimisedCode);
end

function optimisedCode = optimiseVariableNames(code)
    optimisedCode = code;
    
    % Replace generic variable names with more descriptive ones
    replacements = {
        '\<data\>', 'processedData';
        '\<temp\>', 'temporaryVariable';
        '\<i\>', 'index';
        '\<j\>', 'innerIndex'
    };
    
    for i = 1:length(optimisedCode)
        for j = 1:size(replacements, 1)
            optimisedCode{i} = regexprep(optimisedCode{i}, replacements{j,1}, replacements{j,2});
        end
    end
end

function testResults = testGeneratedCode(code)
    testResults = struct();
    testResults.syntaxValid = true;
    testResults.executionSuccessful = false;
    testResults.testCases = {};
    testResults.errors = {};
    
    try
        % Write code to temporary file
        tempFile = [tempname '.m'];
        fid = fopen(tempFile, 'w');
        for i = 1:length(code)
            fprintf(fid, '%s\n', code{i});
        end
        fclose(fid);
        
        % Extract function name
        functionLine = code{1};
        functionName = extractFunctionName(functionLine);
        
        % Test with sample inputs
        testInputs = {
            [1, 2, 3, 4, 5];
            randn(10, 1);
            magic(3)
        };
        
        for i = 1:length(testInputs)
            try
                % Change to temp directory and execute
                oldPath = pwd;
                [tempDir, ~, ~] = fileparts(tempFile);
                cd(tempDir);
                
                result = feval(functionName, testInputs{i});
                testResults.testCases{i} = struct('input', testInputs{i}, 'output', result, 'success', true);
                testResults.executionSuccessful = true;
                
                cd(oldPath);
            catch ME
                testResults.testCases{i} = struct('input', testInputs{i}, 'error', ME.message, 'success', false);
                testResults.errors{end+1} = ME.message;
                cd(oldPath);
            end
        end
        
        % Clean up
        delete(tempFile);
        
    catch ME
        testResults.syntaxValid = false;
        testResults.errors{end+1} = ME.message;
    end
end

function functionName = extractFunctionName(functionLine)
    tokens = strsplit(functionLine);
    equalIndex = find(strcmp(tokens, '='));
    
    if ~isempty(equalIndex) && equalIndex < length(tokens)
        functionName = tokens{equalIndex + 1};
    else
        functionIndex = find(strcmp(tokens, 'function'));
        if ~isempty(functionIndex) && functionIndex < length(tokens)
            functionName = tokens{functionIndex + 1};
        else
            functionName = 'generatedFunction';
        end
    end
    
    % Remove parentheses if present
    functionName = regexprep(functionName, '\(.*\)', '');
end

function result = packageResults(originalDescription, code, testResults)
    result = struct();
    result.originalDescription = originalDescription;
    result.generatedCode = code;
    result.codeString = strjoin(code, '\n');
    result.testResults = testResults;
    result.codeValid = testResults.syntaxValid;
    result.executionSuccessful = testResults.executionSuccessful;
    result.numberOfTestsPassed = sum([testResults.testCases.success]);
    result.totalTests = length(testResults.testCases);
    result.successRate = result.numberOfTestsPassed / max(result.totalTests, 1);
end
