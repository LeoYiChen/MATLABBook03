%% chapter_AI_MATLAB_example_01.m
% Implementing a Random Forest Classifier in MATLAB
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_example_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Load sample data
load fisheriris

% Create a random forest model
rng(1); % For reproducibility
mdl = fitcensemble(meas, species, 'Method', 'Bag', ...
    'NumLearningCycles', 100, 'Learners', 'tree');

% Evaluate model using cross-validation
cv = crossval(mdl, 'KFold', 5);
loss = kfoldLoss(cv);

% Display results
fprintf('Classification error: %.2f%%\n', loss*100);

% Make predictions on new data
predictions = predict(mdl, meas(1:5,:));
