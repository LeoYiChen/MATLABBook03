%% chapter_AI_MATLAB_VibeCoding_example_02.m
% Comprehensive validation framework for vibe coding generated MATLAB code.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_VibeCoding_example_02
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [validated, report] = validateVibeCodedFunction(generatedFunction, ...
                                                         testSpecification, ...
                                                         qualityRequirements)
    % VALIDATEVIBECODEDFUNCTION Validate AI-generated MATLAB functions
    %   [VALIDATED, REPORT] = VALIDATEVIBECODEDFUNCTION(FUNC, SPEC, REQ)
    %   performs comprehensive validation of vibe coding generated functions
    %   including correctness verification, performance assessment, numerical
    %   stability analysis, and code quality evaluation.
    %
    %   This function implements a multi-stage validation pipeline essential
    %   for ensuring reliability of AI-generated code in scientific computing
    %   applications where correctness and numerical stability are critical.
    %
    %   Inputs:
    %       generatedFunction  - Function handle or code string to validate
    %       testSpecification  - Structure with test cases and requirements
    %       qualityRequirements - Structure with quality thresholds
    %
    %   Outputs:
    %       validated - Logical indicating overall validation success
    %       report    - Comprehensive structure with detailed results
    %
    %   Example:
    %       spec.testCases(1).input = magic(5);
    %       spec.testCases(1).expectedProperty = 'symmetric';
    %       req.maxExecutionTime = 0.1;
    %       [valid, rpt] = validateVibeCodedFunction(@(A) A', spec, req);
    %
    %   See also RECOGNISEMATLABINTENT, ASSERT, PROFILE.
    
    fprintf('=== Vibe Coding Validation Framework ===\n');
    fprintf('Validation commenced at: %s\n\n', datestr(datetime('now')));
    
    % Initialise comprehensive report structure
    report = struct();
    report.timestamp = datetime('now');
    report.functionInfo = extractFunctionInfo(generatedFunction);
    validated = true;
    
    % Stage 1: Syntax and Static Analysis
    fprintf('Stage 1: Syntax Validation\n');
    fprintf('-----\n');
    [syntaxValid, syntaxReport] = validateSyntax(generatedFunction);
    report.syntaxValidation = syntaxReport;
    
    if ~syntaxValid
        fprintf('FAILED: Syntax errors detected\n\n');
        validated = false;
        return;
    end
    fprintf('PASSED: No syntax errors detected\n\n');
    
    % Stage 2: Functional Correctness Testing
    fprintf('Stage 2: Correctness Testing\n');
    fprintf('-----\n');
    [correctnessValid, correctnessReport] = testCorrectness(...
        generatedFunction, testSpecification);
    report.correctnessValidation = correctnessReport;
    
    fprintf('Test Results: %d/%d passed\n', ...
        correctnessReport.passedTests, correctnessReport.totalTests);
    
    if ~correctnessValid
        fprintf('FAILED: Correctness validation failed\n\n');
        validated = false;
    else
        fprintf('PASSED: All correctness tests passed\n\n');
    end
    
    % Stage 3: Performance Assessment
    fprintf('Stage 3: Performance Assessment\n');
    fprintf('------\n');
    [performanceValid, performanceReport] = assessPerformance(...
        generatedFunction, testSpecification, qualityRequirements);
    report.performanceValidation = performanceReport;
    
    fprintf('Mean Execution Time: %.6f seconds\n', ...
        performanceReport.meanExecutionTime);
    
    if ~performanceValid
        fprintf('WARNING: Performance below requirements\n\n');
        % Performance issues are warnings, not hard failures
    else
        fprintf('PASSED: Performance meets requirements\n\n');
    end
    
    % Stage 4: Numerical Stability Analysis
    fprintf('Stage 4: Numerical Stability\n');
    fprintf('-----\n');
    [stabilityValid, stabilityReport] = analyseNumericalStability(...
        generatedFunction, testSpecification);
    report.stabilityValidation = stabilityReport;
    
    if ~stabilityValid
        fprintf('FAILED: Numerical stability issues detected\n\n');
        validated = false;
    else
        fprintf('PASSED: Numerically stable behaviour\n\n');
    end
    
    % Stage 5: Code Quality Assessment
    fprintf('Stage 5: Code Quality Assessment\n');
    fprintf('------\n');
    qualityReport = assessCodeQuality(generatedFunction);
    report.qualityAssessment = qualityReport;
    
    fprintf('Overall Quality Score: %.1f/10\n', qualityReport.overallScore);
    fprintf('Complexity: %d (cyclomatic)\n', qualityReport.cyclomaticComplexity);
    fprintf('Vectorisation: %s\n\n', ...
        logicalToYesNo(qualityReport.usesVectorisation));
    
    % Generate final summary
    report.overallValidation = validated;
    report.validationDuration = datetime('now') - report.timestamp;
    
    fprintf('=== Validation Complete ===\n');
    fprintf('Overall Result: %s\n', validationStatus(validated));
    fprintf('Duration: %.2f seconds\n', seconds(report.validationDuration));
    fprintf('=========================\n\n');
end

function info = extractFunctionInfo(func)
    % Extract metadata about the function being validated
    
    info = struct();
    
    if isa(func, 'function_handle')
        info.type = 'function_handle';
        info.name = func2str(func);
        
        % Attempt to get function metadata
        try
            funcInfo = functions(func);
            info.file = funcInfo.file;
            info.workspaceVariables = funcInfo.workspace;
        catch
            info.file = 'unknown';
        end
    elseif ischar(func) || isstring(func)
        info.type = 'code_string';
        info.name = 'anonymous';
        info.codeLength = length(char(func));
    else
        info.type = 'unknown';
        info.name = 'unidentified';
    end
end

function [valid, report] = validateSyntax(func)
    % Validate MATLAB syntax of generated function
    
    report = struct();
    valid = true;
    
    try
        if isa(func, 'function_handle')
            % Function handles are already parsed by MATLAB
            report.syntaxErrors = {};
            report.parseSuccessful = true;
            
        elseif ischar(func) || isstring(func)
            % For code strings, write to temporary file and check
            tempFile = [tempname, '.m'];
            fid = fopen(tempFile, 'w');
            fprintf(fid, '%s', char(func));
            fclose(fid);
            
            % Use checkcode if available (requires MATLAB Coder or similar)
            try
                messages = checkcode(tempFile, '-id');
                report.syntaxErrors = messages;
                report.parseSuccessful = isempty(messages);
                valid = report.parseSuccessful;
            catch
                % Fallback: assume valid if no immediate errors
                report.syntaxErrors = {};
                report.parseSuccessful = true;
            end
            
            % Clean up
            if exist(tempFile, 'file')
                delete(tempFile);
            end
        end
        
    catch ME
        report.syntaxErrors = {ME.message};
        report.parseSuccessful = false;
        valid = false;
    end
end

function [valid, report] = testCorrectness(func, specification)
    % Execute test cases to verify functional correctness
    
    report = struct();
    
    if ~isfield(specification, 'testCases')
        report.totalTests = 0;
        report.passedTests = 0;
        report.failedTests = 0;
        report.testResults = {};
        valid = true; % No tests means technical pass
        return;
    end
    
    testCases = specification.testCases;
    report.totalTests = length(testCases);
    report.passedTests = 0;
    report.failedTests = 0;
    report.testResults = cell(length(testCases), 1);
    
    for i = 1:length(testCases)
        testResult = struct();
        testResult.testNumber = i;
        testResult.input = testCases(i).input;
        
        try
            % Execute function with test input
            tic;
            if isa(func, 'function_handle')
                actual = func(testCases(i).input);
            else
                actual = evaluateCodeString(func, testCases(i).input);
            end
            testResult.executionTime = toc;
            testResult.output = actual;
            
            % Verify against expected output or property
            if isfield(testCases(i), 'expectedOutput')
                % Direct output comparison
                expected = testCases(i).expectedOutput;
                if isnumeric(expected) && isnumeric(actual)
                    tolerance = 1e-10;
                    passed = all(abs(actual(:) - expected(:)) < tolerance);
                else
                    passed = isequal(actual, expected);
                end
                testResult.comparisonType = 'output';
                testResult.expected = expected;
                
            elseif isfield(testCases(i), 'expectedProperty')
                % Property-based validation
                property = testCases(i).expectedProperty;
                passed = verifyProperty(actual, property);
                testResult.comparisonType = 'property';
                testResult.expectedProperty = property;
                
            else
                % No validation criteria specified
                passed = true;
                testResult.comparisonType = 'execution_only';
            end
            
            testResult.passed = passed;
            testResult.errorMessage = '';
            
            if passed
                report.passedTests = report.passedTests + 1;
            else
                report.failedTests = report.failedTests + 1;
            end
            
        catch ME
            testResult.passed = false;
            testResult.output = [];
            testResult.errorMessage = ME.message;
            testResult.executionTime = NaN;
            report.failedTests = report.failedTests + 1;
        end
        
        report.testResults{i} = testResult;
    end
    
    valid = (report.failedTests == 0);
end

function passed = verifyProperty(output, property)
    % Verify that output satisfies specified mathematical property
    
    switch lower(property)
        case 'symmetric'
            if ismatrix(output) && isnumeric(output)
                passed = all(all(abs(output - output') < 1e-10));
            else
                passed = false;
            end
            
        case 'positive_definite'
            if ismatrix(output) && isnumeric(output)
                try
                    chol(output);
                    passed = true;
                catch
                    passed = false;
                end
            else
                passed = false;
            end
            
        case 'orthogonal'
            if ismatrix(output) && isnumeric(output)
                identity = output * output';
                expected = eye(size(output, 1));
                passed = all(all(abs(identity - expected) < 1e-10));
            else
                passed = false;
            end
            
        case 'unit_norm'
            if isnumeric(output)
                passed = abs(norm(output(:)) - 1) < 1e-10;
            else
                passed = false;
            end
            
        case 'real_valued'
            passed = isreal(output);
            
        case 'positive'
            passed = all(output(:) > 0);
            
        otherwise
            warning('verifyProperty:UnknownProperty', ...
                'Unknown property: %s', property);
            passed = true; % Unknown properties pass by default
    end
end

function [valid, report] = assessPerformance(func, specification, requirements)
    % Assess computational performance characteristics
    
    report = struct();
    
    if ~isfield(specification, 'testCases') || isempty(specification.testCases)
        report.executionTimes = [];
        report.meanExecutionTime = NaN;
        report.maxExecutionTime = NaN;
        valid = true;
        return;
    end
    
    testCases = specification.testCases;
    numTests = length(testCases);
    executionTimes = zeros(numTests, 1);
    
    % Measure execution time for each test case
    for i = 1:numTests
        tic;
        try
            if isa(func, 'function_handle')
                func(testCases(i).input);
            else
                evaluateCodeString(func, testCases(i).input);
            end
            executionTimes(i) = toc;
        catch
            executionTimes(i) = Inf;
        end
    end
    
    report.executionTimes = executionTimes;
    report.meanExecutionTime = mean(executionTimes(isfinite(executionTimes)));
    report.maxExecutionTime = max(executionTimes(isfinite(executionTimes)));
    report.minExecutionTime = min(executionTimes(isfinite(executionTimes)));
    report.stdExecutionTime = std(executionTimes(isfinite(executionTimes)));
    
    % Validate against requirements
    valid = true;
    if isfield(requirements, 'maxExecutionTime')
        valid = valid && (report.maxExecutionTime <= requirements.maxExecutionTime);
    end
    if isfield(requirements, 'meanExecutionTime')
        valid = valid && (report.meanExecutionTime <= requirements.meanExecutionTime);
    end
    
    report.meetsRequirements = valid;
end

function [valid, report] = analyseNumericalStability(func, specification)
    % Analyse numerical stability through edge case testing
    
    report = struct();
    report.stabilityIssues = {};
    report.hasNaNOutputs = false;
    report.hasInfOutputs = false;
    valid = true;
    
    if ~isfield(specification, 'testCases') || isempty(specification.testCases)
        return;
    end
    
    % Generate edge cases based on test inputs
    edgeCases = generateEdgeCases(specification.testCases);
    
    for i = 1:length(edgeCases)
        try
            if isa(func, 'function_handle')
                result = func(edgeCases(i).input);
            else
                result = evaluateCodeString(func, edgeCases(i).input);
            end
            
            % Check for NaN values
            if any(isnan(result(:)))
                report.hasNaNOutputs = true;
                report.stabilityIssues{end+1} = sprintf(...
                    'NaN detected in edge case %d (%s)', i, edgeCases(i).description);
                valid = false;
            end
            
            % Check for Inf values
            if any(isinf(result(:)))
                report.hasInfOutputs = true;
                report.stabilityIssues{end+1} = sprintf(...
                    'Inf detected in edge case %d (%s)', i, edgeCases(i).description);
                valid = false;
            end
            
        catch ME
            report.stabilityIssues{end+1} = sprintf(...
                'Edge case %d failed: %s', i, ME.message);
            valid = false;
        end
    end
    
    report.edgeCaseCount = length(edgeCases);
    report.issueCount = length(report.stabilityIssues);
end

function edgeCases = generateEdgeCases(testCases)
    % Generate edge cases from base test cases
    
    edgeCases = [];
    edgeIdx = 0;
    
    for i = 1:length(testCases)
        input = testCases(i).input;
        
        if isnumeric(input) && ismatrix(input)
            % Matrix edge cases
            
            % Very small values
            edgeIdx = edgeIdx + 1;
            edgeCases(edgeIdx).input = input * 1e-10;
            edgeCases(edgeIdx).description = 'very_small_values';
            
            % Very large values
            edgeIdx = edgeIdx + 1;
            edgeCases(edgeIdx).input = input * 1e10;
            edgeCases(edgeIdx).description = 'very_large_values';
            
            % Near-zero matrix
            if all(size(input) > 1)
                edgeIdx = edgeIdx + 1;
                edgeCases(edgeIdx).input = zeros(size(input)) + 1e-15;
                edgeCases(edgeIdx).description = 'near_zero_matrix';
            end
            
            % Identity-like matrix
            if size(input, 1) == size(input, 2)
                edgeIdx = edgeIdx + 1;
                edgeCases(edgeIdx).input = eye(size(input, 1));
                edgeCases(edgeIdx).description = 'identity_matrix';
            end
        end
    end
end

function quality = assessCodeQuality(func)
    % Assess code quality metrics and best practices
    
    quality = struct();
    
    % Convert to string for analysis
    if isa(func, 'function_handle')
        codeStr = func2str(func);
    elseif ischar(func) || isstring(func)
        codeStr = char(func);
    else
        quality.overallScore = 0;
        quality.analysisError = 'Unsupported function type';
        return;
    end
    
    % Basic metrics
    lines = strsplit(codeStr, '\n');
    quality.totalLines = length(lines);
    
    commentLines = sum(cellfun(@(x) ~isempty(regexp(x, '^\s*%', 'once')), lines));
    quality.commentLines = commentLines;
    quality.commentRatio = commentLines / quality.totalLines;
    
    % Complexity metrics
    quality.forLoopCount = length(regexp(codeStr, '\bfor\b'));
    quality.whileLoopCount = length(regexp(codeStr, '\bwhile\b'));
    quality.ifStatementCount = length(regexp(codeStr, '\bif\b'));
    quality.cyclomaticComplexity = 1 + quality.forLoopCount + ...
                                    quality.whileLoopCount + ...
                                    quality.ifStatementCount;
    
    % MATLAB-specific quality indicators
    quality.usesVectorisation = contains(codeStr, '.*') || ...
                                contains(codeStr, './') || ...
                                contains(codeStr, '.^');
    
    quality.usesPreallocation = contains(codeStr, 'zeros(') || ...
                                contains(codeStr, 'ones(') || ...
                                contains(codeStr, 'nan(');
    
    quality.avoidsClearAll = ~contains(codeStr, 'clear all');
    
    % Calculate overall quality score (0-10)
    score = 5.0; % Base score
    
    if quality.commentRatio > 0.15
        score = score + 1.5;
    end
    if quality.cyclomaticComplexity < 10
        score = score + 2.0;
    end
    if quality.usesVectorisation
        score = score + 1.5;
    end
    if quality.usesPreallocation
        score = score + 0.5;
    end
    if quality.avoidsClearAll
        score = score + 0.5;
    end
    
    quality.overallScore = min(score, 10.0);
end

% Utility functions
function output = evaluateCodeString(codeStr, input)
    % Safely evaluate code string (simplified - production needs sandboxing)
    warning('evaluateCodeString:NotImplemented', ...
        'Code string evaluation requires proper sandboxing for security.');
    output = [];
end

function status = validationStatus(valid)
    if valid
        status = 'PASSED';
    else
        status = 'FAILED';
    end
end

function yesno = logicalToYesNo(value)
    if value
        yesno = 'Yes';
    else
        yesno = 'No';
    end
end
