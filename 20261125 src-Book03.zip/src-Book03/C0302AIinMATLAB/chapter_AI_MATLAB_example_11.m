%% chapter_AI_MATLAB_example_11.m
% GPU Acceleration for Deep Learning
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_example_11
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Check for available GPU
hasGPU = (gpuDeviceCount > 0);
if hasGPU
    device = gpuDevice();
    disp(['Using GPU: ', device.Name]);
    executionEnvironment = 'gpu';
else
    disp('No GPU available. Using CPU.');
    executionEnvironment = 'cpu';
end

% Configure training options with GPU acceleration if available
options = trainingOptions('sgdm', ...
    'ExecutionEnvironment', executionEnvironment, ...
    'MaxEpochs', 30, ...
    'MiniBatchSize', 128, ...
    'InitialLearnRate', 0.001, ...
    'LearnRateSchedule', 'piecewise', ...
    'LearnRateDropFactor', 0.1, ...
    'LearnRateDropPeriod', 10, ...
    'Shuffle', 'every-epoch', ...
    'ValidationData', valImds, ...
    'ValidationFrequency', 30, ...
    'Plots', 'training-progress', ...
    'Verbose', false);

% Train network
net = trainNetwork(trainImds, layers, options);
