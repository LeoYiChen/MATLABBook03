%% chapter_AI_MATLAB_example_04.m
% Data Augmentation for Image Classification
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_example_04
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Create an image datastore
imds = imageDatastore('imagefolder', 'IncludeSubfolders', true, ...
    'LabelSource', 'foldernames');

% Define augmentation parameters
augmenter = imageDataAugmenter( ...
    'RandRotation', [-20, 20], ...
    'RandXTranslation', [-10, 10], ...
    'RandYTranslation', [-10, 10], ...
    'RandXScale', [0.9, 1.1], ...
    'RandYScale', [0.9, 1.1], ...
    'RandXShear', [-10, 10], ...
    'RandYShear', [-10, 10]);

% Create augmented image datastore
augimds = augmentedImageDatastore([227 227], imds, ...
    'DataAugmentation', augmenter);

% Visualize some augmented images
augmentedData = preview(augimds);
figure;
for i = 1:4
    subplot(2, 2, i);
    imshow(augmentedData.input{i});
    title(string(augmentedData.response(i)));
end
