%% chapter_AI_MATLAB_example_SingleAgent_01.m
% Implementation of a single AI agent with integrated communication protocol support. The class inherits from handle to support events and pass-by-reference semantics. The message-processing pipeline follows a structured receive-validate-route-respond pattern, and the decision-making module uses a dlnetwork policy.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_example_SingleAgent_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
classdef IntelligentAgent < handle
    % IntelligentAgent - AI Agent with Communication Protocol Support
    % Implements a goal-directed agent with perception, decision-making,
    % knowledge management, and standardised message communication.
    
    properties (Access = private)
        stateVector         % Current state representation (numeric vector)
        knowledgeBase       % Accumulated beliefs (containers.Map)
        policyNetwork       % Decision-making network (dlnetwork)
        messageLog          % Communication history (table)
        lastReceivedMessage % Most recent incoming message (struct)
    end
    
    properties (Access = public)
        AgentID    string   % Unique agent identifier
        Status     string   % Operational status
        Epsilon    double   % Exploration rate for action selection
    end
    
    events
        MessageReceived     % Triggered upon incoming message
        ActionExecuted      % Triggered upon action completion
        StateUpdated        % Triggered upon state change
    end
    
    methods (Access = public)
        
        
        
        
    end
    
    methods (Access = private)
        
        
        
    end
end

% Local functions (moved to end so this listing is a valid MATLAB script)
        function obj = IntelligentAgent(agentID, config)
            % Constructor: initialise agent with specified configuration
            %   agentID - unique string identifier for this agent
            %   config  - struct with fields: stateDimension, actionDimension
            
            obj.AgentID = agentID;
            obj.Status  = "Initialised";
            obj.Epsilon = 0.1;
            obj.knowledgeBase = containers.Map('KeyType', 'char', ...
                                               'ValueType', 'any');
            
            % Initialise communication log as an empty table
            obj.messageLog = table('Size', [0, 4], ...
                'VariableTypes', {'datetime','string','string','string'}, ...
                'VariableNames', {'Timestamp','Sender','Type','Content'});
            
            % Initialise state vector
            stateDim = config.stateDimension;
            obj.stateVector = zeros(1, stateDim);
            
            % Build a simple policy network for decision-making
            actionDim = config.actionDimension;
            layers = [
                featureInputLayer(stateDim, 'Name', 'observation')
                fullyConnectedLayer(128, 'Name', 'fc1')
                reluLayer('Name', 'relu1')
                fullyConnectedLayer(64, 'Name', 'fc2')
                reluLayer('Name', 'relu2')
                fullyConnectedLayer(actionDim, 'Name', 'fc_out')
                softmaxLayer('Name', 'action_probs')
            ];
            obj.policyNetwork = dlnetwork(layerGraph(layers));
            
            fprintf('Agent %s initialised (state: %d, actions: %d).\n', ...
                    agentID, stateDim, actionDim);
        end

        function response = processMessage(obj, message)
            % Process an incoming structured message
            %   message - struct with fields: sender, type, content
            %   Returns a response struct
            
            % Validate the incoming message structure
            requiredFields = {'sender', 'type', 'content'};
            for k = 1:numel(requiredFields)
                if ~isfield(message, requiredFields{k})
                    response = struct('status', 'error', ...
                        'detail', sprintf('Missing field: %s', ...
                        requiredFields{k}));
                    return;
                end
            end
            
            % Log the communication event
            newRow = {datetime('now'), string(message.sender), ...
                      string(message.type), ...
                      string(jsonencode(message.content))};
            obj.messageLog = [obj.messageLog; newRow];
            
            % Store and notify listeners
            obj.lastReceivedMessage = message;
            notify(obj, 'MessageReceived');
            
            % Route to the appropriate handler based on message type
            switch lower(message.type)
                case "query"
                    response = obj.handleQuery(message);
                case "command"
                    response = obj.handleCommand(message);
                case "inform"
                    response = obj.handleInform(message);
                case "request"
                    response = obj.handleRequest(message);
                otherwise
                    response = struct('status', 'error', ...
                        'detail', 'Unrecognised message type');
            end
            
            % Attach metadata to the response
            response.respondingAgent = obj.AgentID;
            response.timestamp = datetime('now');
        end

        function [action, actionProbs] = selectAction(obj, observation)
            % Select an action given the current observation
            %   observation - numeric row vector of environment features
            %   Returns selected action index and probability distribution
            
            % Convert observation to dlarray for network inference
            dlObs = dlarray(single(observation'), 'CB');
            dlProbs = predict(obj.policyNetwork, dlObs);
            actionProbs = double(extractdata(dlProbs));
            
            % Epsilon-greedy action selection
            if rand() < obj.Epsilon
                action = randi(numel(actionProbs));
            else
                [~, action] = max(actionProbs);
            end
            
            % Update internal state and notify listeners
            obj.stateVector = observation;
            notify(obj, 'ActionExecuted');
        end

        function updateKnowledge(obj, key, value)
            % Update the agent knowledge base with a new belief
            obj.knowledgeBase(key) = value;
            notify(obj, 'StateUpdated');
        end

        function report = generateStatusReport(obj)
            % Produce a structured status report for external consumption
            report.agentID          = obj.AgentID;
            report.status           = obj.Status;
            report.knowledgeEntries = obj.knowledgeBase.Count;
            report.messagesHandled  = height(obj.messageLog);
            report.currentState     = obj.stateVector;
            report.timestamp        = datetime('now');
            
            % Encode as JSON for protocol-compliant transmission
            report.jsonRepresentation = jsonencode(report);
        end

        function response = handleQuery(obj, message)
            queryKey = message.content.key;
            if obj.knowledgeBase.isKey(queryKey)
                response = struct('status','success', ...
                    'data', obj.knowledgeBase(queryKey));
            else
                response = struct('status','not_found','data',[]);
            end
        end

        function response = handleCommand(obj, message)
            cmdType = message.content.commandType;
            forbidden = ["shutdown_all", "override_safety"];
            if ismember(cmdType, forbidden)
                response = struct('status','rejected', ...
                    'reason','Safety constraint violation');
                return;
            end
            try
                obj.Status = "Executing";
                % Execute the commanded action (application-specific)
                result = struct('commandType', cmdType, ...
                                'outcome', 'completed');
                obj.Status = "Active";
                response = struct('status','executed','result',result);
            catch ME
                obj.Status = "Error";
                response = struct('status','failed','error',ME.message);
            end
        end

        function response = handleInform(obj, message)
            if isfield(message.content,'key') && ...
               isfield(message.content,'value')
                obj.knowledgeBase(message.content.key) = ...
                    message.content.value;
                response = struct('status', 'acknowledged');
            else
                response = struct('status','error', ...
                    'detail','Missing key or value');
            end
        end

        function response = handleRequest(obj, message)
            % Handle a request for the agent to perform a task
            response = struct('status', 'accepted', ...
                'detail', 'Request queued for processing');
        end
