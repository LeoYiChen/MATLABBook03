%% chapter_AI_MATLAB_example_MAS_02.m
% End-to-end demonstration of multi-agent system operation. Three agents are created and registered with the coordinator. Messages are routed between agents, and a distributed task is executed concurrently using the parallel computing infrastructure.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_example_MAS_02
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Define agent configuration
config.stateDimension  = 8;
config.actionDimension = 3;

% Create the multi-agent coordinator
coordinator = MultiAgentCoordinator("MAS_Controller_01");

% Create and register three agents
agentNames = ["SensorAgent", "PlannerAgent", "ActuatorAgent"];
agents = cell(1, 3);
for k = 1:3
    agents{k} = IntelligentAgent(agentNames(k), config);
    coordinator.registerAgent(agents{k});
end

% Route an inform message from SensorAgent to PlannerAgent
sensorData = struct('type', 'inform', ...
    'content', struct('key', 'sensorReading', ...
                      'value', [23.5, 48.2, 101.3]));
resp = coordinator.routeMessage("SensorAgent", "PlannerAgent", sensorData);
fprintf('Routing result: %s\n', resp.status);

% Broadcast an alert to all agents
alertMsg = struct('type', 'inform', ...
    'content', struct('key', 'systemAlert', ...
                      'value', 'High temperature detected'));
allResponses = coordinator.broadcastMessage("Supervisor", alertMsg);
fprintf('Broadcast delivered to %d agents.\n', allResponses.Count);

% Execute a distributed task across all agents
taskData.observations = randn(3, config.stateDimension);
agentIDs = cellstr(agentNames);
results = coordinator.executeDistributedTask(taskData, agentIDs);
fprintf('Distributed actions: %s\n', mat2str(results.actions'));

% Generate network summary
summary = coordinator.generateNetworkSummary();
fprintf('Network summary: %d agents, %d messages routed.\n', ...
        summary.totalAgents, summary.totalMessages);
