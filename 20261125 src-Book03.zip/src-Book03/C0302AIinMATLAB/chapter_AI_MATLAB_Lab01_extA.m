%% chapter_AI_MATLAB_Lab01_extA.m
% Extension A: Using fmincon for constrained beam optimisation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_Lab01_extA
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Objective: minimise mass = rho * b * h * L
objectiveFcn = @(designVars) ...
    specifications.material.density * ...
    designVars(1) * designVars(2) * ...
    specifications.geometry.beamLength;

% Nonlinear constraints (c <= 0)
nonlinearConstraints = @(designVars) ...
    beamConstraints(designVars, specifications);

% Initial guess, lower bounds, upper bounds
initialGuess = [0.050, 0.100];
lowerBound   = [0.010, 0.020];
upperBound   = [0.200, 0.300];

% Solve using SQP algorithm
options = optimoptions('fmincon', 'Display', 'iter', ...
                       'Algorithm', 'sqp');
[optimalVars, optimalMass] = fmincon(objectiveFcn, ...
    initialGuess, [], [], [], [], ...
    lowerBound, upperBound, nonlinearConstraints, options);

function [cineq, ceq] = beamConstraints(designVars, specs)
    bVal    = designVars(1);
    hVal    = designVars(2);
    inertia = bVal * hVal^3 / 12;
    P = specs.load.magnitude;
    L = specs.geometry.beamLength;
    E = specs.material.youngsModulus;
    
    deflection = P * L^3 / (3 * E * inertia);
    stress     = P * L * (hVal / 2) / inertia;
    
    cineq = [deflection - specs.constraints.maxDeflection; ...
             stress     - specs.constraints.allowableStress];
    ceq   = [];
end
