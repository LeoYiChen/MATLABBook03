%% chapter_AI_MATLAB_example_05.m
% Object Detection Using YOLO v2 in MATLAB
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_example_05
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Load pre-trained YOLO v2 object detector
detector = yolov2ObjectDetector('tiny-yolov2-coco');

% Read test image
img = imread('street.jpg');

% Detect objects in the image
[bboxes, scores, labels] = detect(detector, img);

% Visualize detection results
if ~isempty(bboxes)
    img = insertObjectAnnotation(img, 'rectangle', bboxes, ...
        cellstr(labels) + ": " + string(scores), ...
        'FontSize', 18);
end
figure; imshow(img);
title('Object Detection Results');
