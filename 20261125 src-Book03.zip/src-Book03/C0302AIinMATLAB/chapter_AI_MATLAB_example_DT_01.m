%% chapter_AI_MATLAB_example_DT_01.m
% Function to deploy a multi-agent monitoring system for a digital twin application. Specialised agents are created for each monitored subsystem, registered with the coordinator, and initialised with subsystem-specific knowledge.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_example_DT_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function dtResults = deployDigitalTwinAgents(subsystemNames, sensorData)
    % deployDigitalTwinAgents - Create and coordinate monitoring agents
    %   subsystemNames - cell array of subsystem identifiers
    %   sensorData     - struct array with fields: name, readings (matrix)
    %   Returns: dtResults struct with monitoring outcomes
    
    numSubsystems = numel(subsystemNames);
    fprintf('Deploying %d monitoring agents for digital twin.\n', ...
            numSubsystems);
    
    % Create the multi-agent coordinator
    coordinator = MultiAgentCoordinator("DigitalTwin_Coordinator");
    
    % Configure agents with appropriate dimensions
    config.stateDimension  = size(sensorData(1).readings, 2);
    config.actionDimension = 3;  % e.g., normal, warn, alert
    
    % Deploy one agent per subsystem
    agentIDs = cell(1, numSubsystems);
    for k = 1:numSubsystems
        agentID = sprintf('Monitor_%s', subsystemNames{k});
        agent   = IntelligentAgent(string(agentID), config);
        coordinator.registerAgent(agent);
        agentIDs{k} = agentID;
        
        % Initialise agent knowledge with subsystem parameters
        agent.updateKnowledge('subsystem', subsystemNames{k});
        agent.updateKnowledge('thresholds', ...
            struct('warning', 80, 'critical', 95));
    end
    
    % Simulate a monitoring cycle over the available sensor data
    numTimeSteps = size(sensorData(1).readings, 1);
    dtResults.actions = zeros(numTimeSteps, numSubsystems);
    dtResults.agentIDs = agentIDs;
    
    for t = 1:numTimeSteps
        observations = zeros(numSubsystems, config.stateDimension);
        for k = 1:numSubsystems
            observations(k, :) = sensorData(k).readings(t, :);
        end
        
        % Each agent selects an action based on its observation
        taskData.observations = observations;
        stepResults = coordinator.executeDistributedTask( ...
            taskData, agentIDs);
        dtResults.actions(t, :) = stepResults.actions';
        
        % Broadcast any alerts detected by individual agents
        for k = 1:numSubsystems
            if stepResults.actions(k) == 3  % Alert action
                alertMsg = struct('type', 'inform', ...
                    'content', struct('key', 'alert', ...
                    'value', sprintf('Alert from %s at t=%d', ...
                    subsystemNames{k}, t)));
                coordinator.broadcastMessage(agentIDs{k}, alertMsg);
            end
        end
    end
    
    % Generate network summary
    dtResults.networkSummary = coordinator.generateNetworkSummary();
    fprintf('Digital twin monitoring completed: %d time steps.\n', ...
            numTimeSteps);
end
