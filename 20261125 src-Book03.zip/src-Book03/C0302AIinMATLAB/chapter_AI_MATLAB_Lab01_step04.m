%% chapter_AI_MATLAB_Lab01_step04.m
% Design Agent function for generating cantilever beam designs.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_Lab01_step04
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function design = generateBeamDesign(beamWidth, beamHeight, specifications)
    % generateBeamDesign - Create a complete beam design struct
    % from specified cross-sectional dimensions.
    %
    % Inputs:
    %   beamWidth      - cross-section width b (m)
    %   beamHeight     - cross-section height h (m)
    %   specifications - engineering specifications struct
    %
    % Output:
    %   design - struct containing all design parameters
    %
    % Author: Dr Yi Chen
    % Date:   2025
    % MATLAB: R2024b
    
    design.width         = beamWidth;
    design.height        = beamHeight;
    design.length        = specifications.geometry.beamLength;
    design.material      = specifications.material;
    
    % Derived geometric properties
    design.momentOfInertia   = beamWidth * beamHeight^3 / 12;
    design.crossSectionArea  = beamWidth * beamHeight;
    design.sectionModulus    = beamWidth * beamHeight^2 / 6;
    
    % Mass calculation
    design.mass = design.material.density * ...
                  design.crossSectionArea * design.length;
    
    % Design metadata
    design.timestamp     = datetime('now');
    design.designStatus  = "generated";
end
