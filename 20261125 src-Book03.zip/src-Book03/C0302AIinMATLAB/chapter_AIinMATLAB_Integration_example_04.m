%% chapter_AIinMATLAB_Integration_example_04.m
% Configuring and utilising the MATLAB-Python interface. The pyenv function establishes the link to a specified Python installation, after which Python modules can be called using the py. prefix or via the pyrun function.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AIinMATLAB_Integration_example_04
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Display the current Python environment configuration
pe = pyenv;
disp(pe);

% Alternatively, specify a particular Python version
% pe = pyenv('Version', '3.10');

% Call a Python library function directly using the py. prefix
npArray = py.numpy.array([1.0, 2.0, 3.0, 4.0, 5.0]);
meanValue = py.numpy.mean(npArray);
fprintf('Mean computed by NumPy: %.2f\n', double(meanValue));

% Execute a block of Python code using pyrun
% and retrieve the result as a MATLAB variable
result = pyrun( ...
    "import numpy as np; y = np.std(x)", ...
    "y", ...
    x = py.numpy.array([1.0, 2.0, 3.0, 4.0, 5.0]));
fprintf('Standard deviation: %.4f\n', double(result));

% Run an external Python script file
% pyrunfile('preprocess_data.py');
