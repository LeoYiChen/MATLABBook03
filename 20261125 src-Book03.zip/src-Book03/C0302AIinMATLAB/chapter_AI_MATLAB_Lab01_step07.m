%% chapter_AI_MATLAB_Lab01_step07.m
% Optimisation Agent function for proposing improved design parameters.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_Lab01_step07
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function improvedDesign = computeDesignImprovement( ...
        currentDesign, analysisResults, specifications)
    % computeDesignImprovement - Propose improved beam dimensions
    % based on the current analysis results.
    %
    % Inputs:
    %   currentDesign   - current beam design struct
    %   analysisResults - analysis results struct
    %   specifications  - engineering specifications struct
    %
    % Output:
    %   improvedDesign - updated design struct with new dimensions
    %
    % Author: Dr Yi Chen
    % Date:   2025
    % MATLAB: R2024b
    
    reductionFactor = specifications.optimisation.reductionFactor;
    bounds          = specifications.designBounds;
    
    if analysisResults.allConstraintsMet
        % Design passes: reduce dimensions to save mass
        dimensionScale = sqrt(reductionFactor);
    else
        % Design fails: increase dimensions for compliance
        dimensionScale = 1.0 / sqrt(reductionFactor);
    end
    
    % Apply scaling to width and height
    newWidth  = currentDesign.width  * dimensionScale;
    newHeight = currentDesign.height * dimensionScale;
    
    % Enforce design bounds
    newWidth  = max(min(newWidth,  bounds.maxWidth),  bounds.minWidth);
    newHeight = max(min(newHeight, bounds.maxHeight), bounds.minHeight);
    
    % Generate updated design struct
    improvedDesign = generateBeamDesign( ...
        newWidth, newHeight, specifications);
    improvedDesign.designStatus = "optimised";
    
    fprintf('  [OPT] Dimensions scaled by %.4f: b=%.4f m, h=%.4f m\n', ...
            dimensionScale, newWidth, newHeight);
end
