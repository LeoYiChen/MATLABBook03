%% chapter_AI_MATLAB_example_08.m
% Comprehensive Model Evaluation
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_example_08
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Load and split data
load ionosphere
cv = cvpartition(Y, 'HoldOut', 0.3);
XTrain = X(cv.training,:);
YTrain = Y(cv.training);
XTest = X(cv.test,:);
YTest = Y(cv.test);

% Train model
mdl = fitcsvm(XTrain, YTrain, 'KernelFunction', 'rbf', ...
    'BoxConstraint', 1, 'KernelScale', 'auto', ...
    'Standardize', true);

% Predict on test set
[YPred, scores] = predict(mdl, XTest);

% Evaluate performance using multiple metrics
confMat = confusionmat(YTest, YPred);
accuracy = sum(diag(confMat))/sum(confMat(:));
precision = confMat(1,1)/sum(confMat(:,1));
recall = confMat(1,1)/sum(confMat(1,:));
f1Score = 2*precision*recall/(precision+recall);

% Plot ROC curve
[X,Y,T,AUC] = perfcurve(YTest, scores(:,2), 'g');
figure;
plot(X,Y);
xlabel('False Positive Rate'); ylabel('True Positive Rate');
title(['ROC Curve (AUC = ' num2str(AUC) ')']);

% Local function copied from another listing in this chapter
        function result = predict(obj, features)
            result = struct();
            
            if ~obj.isTrained
                error('Model must be trained before making predictions');
            end
            
            modelNames = keys(obj.baseModels);
            predictions = zeros(length(modelNames), 1);
            confidences = zeros(length(modelNames), 1);
            
            % Get predictions from each base model
            for i = 1:length(modelNames)
                modelName = modelNames{i};
                model = obj.baseModels(modelName);
                
                if model.trained
                    [pred, conf] = obj.predictWithBaseModel(model, features);
                    predictions(i) = pred;
                    confidences(i) = conf;
                end
            end
            
            % Combine predictions using ensemble method
            switch obj.ensembleMethod
                case 'simple_average'
                    result.prediction = mean(predictions);
                    result.confidence = mean(confidences);
                    
                case 'weighted_average'
                    result.prediction = sum(obj.modelWeights .* predictions);
                    result.confidence = sum(obj.modelWeights .* confidences);
                    
                case 'median'
                    result.prediction = median(predictions);
                    result.confidence = median(confidences);
            end
            
            % Calculate uncertainty
            result.uncertainty = std(predictions);
            result.modelWeights = obj.modelWeights;
            result.individualPredictions = predictions;
        end
