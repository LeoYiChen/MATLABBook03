%% chapter_AI_MATLAB_Lab01_step05.m
% Simulation Agent function implementing Euler-Bernoulli cantilever beam analysis.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_Lab01_step05
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function simResults = runCantileverBeamSimulation(design, loadConfig)
    % runCantileverBeamSimulation - Compute structural response of a
    % cantilever beam using Euler-Bernoulli beam theory.
    %
    % Inputs:
    %   design     - beam design struct (from generateBeamDesign)
    %   loadConfig - struct with fields: magnitude, type, location
    %
    % Output:
    %   simResults - struct with deflection, stress, and profile
    %
    % Reference: Gere & Goodno, Mechanics of Materials, 9*th ed.
    %
    % Author: Dr Yi Chen
    % Date:   2025
    % MATLAB: R2024b
    
    % Extract parameters
    appliedForce  = loadConfig.magnitude;
    beamLength    = design.length;
    youngsModulus = design.material.youngsModulus;
    momentInertia = design.momentOfInertia;
    beamHeight    = design.height;
    
    % Maximum deflection at free end: delta = P*L^3 / (3*E*I)
    simResults.maxDeflection = appliedForce * beamLength^3 / ...
                               (3 * youngsModulus * momentInertia);
    
    % Maximum bending moment at fixed support: M = P*L
    simResults.maxBendingMoment = appliedForce * beamLength;
    
    % Maximum bending stress: sigma = M * c / I, c = h/2
    simResults.maxStress = simResults.maxBendingMoment * ...
                           (beamHeight / 2) / momentInertia;
    
    % Deflection profile: delta(x) = P/(6*EI)*(3*Lx^2 - x^3)
    numProfilePoints = 100;
    positionAlongBeam = linspace(0, beamLength, numProfilePoints);
    simResults.deflectionProfile = (appliedForce / ...
        (6 * youngsModulus * momentInertia)) * ...
        (3 * beamLength * positionAlongBeam.^2 - ...
         positionAlongBeam.^3);
    simResults.positionAlongBeam = positionAlongBeam;
    
    % Strain energy: U = P^2 * L^3 / (6*E*I)
    simResults.strainEnergy = appliedForce^2 * beamLength^3 / ...
                              (6 * youngsModulus * momentInertia);
    
    % Metadata
    simResults.timestamp = datetime('now');
    simResults.status    = "completed";
end
