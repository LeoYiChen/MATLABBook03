%% chapter_AI_MATLAB_example_06.m
% Sentiment Analysis Using Text Analytics Toolbox
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_example_06
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Load and prepare text data
documents = readtable('reviews.csv');
textData = documents.ReviewText;

% Create text preprocessing pipeline
documents = tokenizedDocument(textData);
documents = erasePunctuation(documents);
documents = removeStopWords(documents);
documents = lower(documents);

% Convert text to word embedding features
emb = fastTextWordEmbedding;
features = doc2sequence(emb, documents);

% Create LSTM network for sentiment classification
inputSize = 300; % Word embedding dimension
numHiddenUnits = 100;
numClasses = 2;

layers = [ ...
    sequenceInputLayer(inputSize)
    bilstmLayer(numHiddenUnits, 'OutputMode', 'last')
    fullyConnectedLayer(numClasses)
    softmaxLayer
    classificationLayer];

% Train network
options = trainingOptions('adam', ...
    'MaxEpochs', 10, ...
    'MiniBatchSize', 32, ...
    'Shuffle', 'every-epoch', ...
    'ValidationData', {valFeatures, valLabels}, ...
    'ValidationFrequency', 50, ...
    'Verbose', false, ...
    'Plots', 'training-progress');

net = trainNetwork(features, documents.Label, layers, options);
