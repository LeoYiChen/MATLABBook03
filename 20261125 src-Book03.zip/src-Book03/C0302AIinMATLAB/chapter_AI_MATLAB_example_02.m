%% chapter_AI_MATLAB_example_02.m
% Transfer Learning with a Pre-trained CNN in MATLAB
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0302AIinMATLAB/
% Listing label         : chapter_AI_MATLAB_example_02
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Load pre-trained network
net = resnet50();

% Analyze network architecture
analyzeNetwork(net);

% Modify network for transfer learning
lgraph = layerGraph(net);
newLearnableLayer = fullyConnectedLayer(numClasses, ...
    'Name', 'new_fc', ...
    'WeightLearnRateFactor', 10, ...
    'BiasLearnRateFactor', 10);
lgraph = replaceLayer(lgraph, 'fc1000', newLearnableLayer);
lgraph = replaceLayer(lgraph, 'ClassificationLayer_fc1000', ...
    classificationLayer('Name', 'new_classoutput'));

% Define training options
options = trainingOptions('sgdm', ...
    'MiniBatchSize', 32, ...
    'MaxEpochs', 10, ...
    'InitialLearnRate', 1e-4, ...
    'Shuffle', 'every-epoch', ...
    'ValidationData', augimdsValidation, ...
    'ValidationFrequency', 3, ...
    'Verbose', false, ...
    'Plots', 'training-progress');

% Train network
netTransfer = trainNetwork(augimdsTrain, lgraph, options);
