%% chapter_Introduction_lab02_solutions.m
% Solutions to visualisation tasks.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0301Introduction/
% Listing label         : chapter_Introduction_lab02_solutions
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Generate sample data for all visualisations
n = 1000;
data = randn(n, 5);  % 5 random variables
x = linspace(-3, 3, n)';
y = 2*x + 0.5*x.^2 + 2*randn(n, 1);  % Nonlinear relationship with noise

% Task 1: Multiple visualisation types of the same dataset
figure('Name', 'Multiple visualisation Types');
subplot(2, 2, 1)
plot(x, y, 'b-');
title('Line Plot');
xlabel('x'); ylabel('y');
grid on;

subplot(2, 2, 2)
scatter(x, y, 10, 'filled');
title('Scatter Plot');
xlabel('x'); ylabel('y');
grid on;

subplot(2, 2, 3)
histogram(y, 30);
title('Histogram');
xlabel('Value'); ylabel('Frequency');
grid on;

subplot(2, 2, 4)
boxplot(y);
title('Box Plot');
grid on;

% Task 2: 3*D Surface plot
figure('Name', '3*D Surface Plot');
[X, Y] = meshgrid(linspace(-10, 10, 100), linspace(-10, 10, 100));
R = sqrt(X.^2 + Y.^2) + eps;  % Adding eps to avoid division by zero
Z = sin(R)./R;
surf(X, Y, Z);
title('sin(r)/r Function');
xlabel('x'); ylabel('y'); zlabel('z');
colormap('jet');
colorbar;

% Task 3: Correlation matrix heatmap
figure('Name', 'Correlation Matrix');
corrMatrix = corr(data);
heatmap(corrMatrix);
title('Correlation Matrix Heatmap');
xlabel('Variable'); ylabel('Variable');
colormap('jet');

% Task 4: Tiledlayout with shared axes
figure('Name', 'Tiled Layout with Shared Axes');
tiledlayout(2, 2, 'TileSpacing', 'compact', 'Padding', 'compact');

% First tile
ax1 = nexttile;
plot(ax1, x, y, '.');
title(ax1, 'Raw Data');

% Second tile - Histogram of x
ax2 = nexttile;
histogram(ax2, x, 30);
title(ax2, 'Distribution of x');

% Third tile - Histogram of y
ax3 = nexttile;
histogram(ax3, y, 30);
title(ax3, 'Distribution of y');

% Fourth tile - Boxplots
ax4 = nexttile;
boxplot(ax4, [x, y], 'Labels', {'x', 'y'});
title(ax4, 'Boxplots');

% Link axes where appropriate
linkaxes([ax1, ax2], 'x');
linkaxes([ax1, ax3], 'y');

% Task 5: Animated visualisation of a simple pendulum
figure('Name', 'Pendulum Animation');
ax = gca;
ax.XLim = [-1.1 1.1];
ax.YLim = [-1.1 0.1];
grid on;
hold on;

% Pendulum parameters
L = 1;          % Length
g = 9.81;       % Gravity
theta0 = pi/4;  % Initial angle
omega0 = 0;     % Initial angular velocity

% Time parameters
tspan = [0, 10];
dt = 0.05;
t = tspan(1):dt:tspan(2);

% Solve the pendulum equation: d?¦È/dt? + (g/L)*sin(¦È) = 0
[t, y] = ode45(@(t,y) [y(2); -g/L*sin(y(1))], t, [theta0; omega0]);

% Convert to cartesian coordinates
x = L * sin(y(:,1));
y = -L * cos(y(:,1));

% Create pendulum visual elements
pendulumLine = plot([0, x(1)], [0, y(1)], 'k-', 'LineWidth', 2);
pendulumBob = plot(x(1), y(1), 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
title('Simple Pendulum Simulation');

% Animation
for i = 1:length(t)
    % Update pendulum position
    set(pendulumLine, 'XData', [0, x(i)], 'YData', [0, y(i)]);
    set(pendulumBob, 'XData', x(i), 'YData', y(i));
    
    % Update display
    drawnow;
    pause(0.01);
end
