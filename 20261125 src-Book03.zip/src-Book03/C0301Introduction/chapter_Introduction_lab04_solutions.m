%% chapter_Introduction_lab04_solutions.m
% Solutions to model-based design tasks.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0301Introduction/
% Listing label         : chapter_Introduction_lab04_solutions
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Task 1: Mass-Spring-Damper System
figure('Name', 'Mass-Spring-Damper System');

% System parameters
m = 1.0;    % Mass (kg)
k = 10.0;   % Spring constant (N/m)
c = 0.5;    % Damping coefficient (N¡¤s/m)

% State space representation
A = [0, 1; -k/m, -c/m];
B = [0; 1/m];
C = [1, 0];  % Position output
D = 0;

% Create state-space model
msdSystem = ss(A, B, C, D);

% Impulse response (hit the mass)
t = 0:0.01:10;
[y, t] = impulse(msdSystem, t);

% Plot position response
subplot(2, 1, 1);
plot(t, y, 'b-', 'LineWidth', 2);
title('Mass-Spring-Damper: Impulse Response');
xlabel('Time (s)');
ylabel('Position (m)');
grid on;

% Step response (constant force)
[y, t] = step(msdSystem, t);

% Plot position response
subplot(2, 1, 2);
plot(t, y, 'r-', 'LineWidth', 2);
title('Mass-Spring-Damper: Step Response');
xlabel('Time (s)');
ylabel('Position (m)');
grid on;

% Task 2: Predator-Prey Model (Lotka-Volterra)
figure('Name', 'Predator-Prey Model');

% Model parameters
alpha = 0.1;   % Prey growth rate
beta = 0.02;   % Prey death rate due to predation
gamma = 0.01;  % Predator growth rate from prey
delta = 0.1;   % Predator death rate

% Time span
tspan = [0, 200];

% Initial conditions: [prey, predator]
y0 = [50, 10];

% Solve the differential equations
[t, y] = ode45(@(t, y) predatorPreyModel(t, y, alpha, beta, gamma, delta), tspan, y0);

% Plot populations over time
subplot(2, 1, 1);
plot(t, y(:,1), 'b-', t, y(:,2), 'r-', 'LineWidth', 2);
title('Predator-Prey Dynamics');
xlabel('Time');
ylabel('Population');
legend('Prey', 'Predators', 'Location', 'best');
grid on;

% Phase portrait
subplot(2, 1, 2);
plot(y(:,1), y(:,2), 'g-', 'LineWidth', 2);
hold on;
plot(y0(1), y0(2), 'ko', 'MarkerSize', 10, 'LineWidth', 2);
title('Phase Portrait');
xlabel('Prey Population');
ylabel('Predator Population');
grid on;

% Predator-prey model function

% Task 3: SIR Epidemic Model
figure('Name', 'SIR Epidemic Model');

% Model parameters
beta = 0.3;    % Infection rate
gamma = 0.1;   % Recovery rate
N = 1000;      % Total population

% Time span (days)
tspan = [0, 100];

% Initial conditions: [S, I, R] as fractions of total population
initialInfected = 1;  % Start with 1 infected person
y0 = [(N - initialInfected)/N, initialInfected/N, 0];

% Solve the differential equations
[t, y] = ode45(@(t, y) sirModel(t, y, beta, gamma), tspan, y0);

% Plot the SIR curves
subplot(2, 1, 1);
plot(t, y(:,1)*N, 'b-', t, y(:,2)*N, 'r-', t, y(:,3)*N, 'g-', 'LineWidth', 2);
title('SIR Epidemic Model');
xlabel('Time (days)');
ylabel('Population');
legend('Susceptible', 'Infected', 'Recovered', 'Location', 'best');
grid on;

% Calculate and plot new infections per day
newInfections = diff(y(:,2)*N + y(:,3)*N);
subplot(2, 1, 2);
bar(t(2:end), newInfections);
title('New Infections per Day');
xlabel('Time (days)');
ylabel('New Cases');
grid on;

% Calculate peak infection and timing
[peakInfected, peakIdx] = max(y(:,2));
disp(['Peak infection: Day ' num2str(t(peakIdx)) ' with ' ...
      num2str(peakInfected*N) ' infected people (' ...
      num2str(peakInfected*100) '% of population)']);

% SIR model function

% Task 4: Financial Market Model
figure('Name', 'Financial Market Model');

% Model parameters
alpha = 0.05;    % Fundamental growth rate
beta = 0.2;      % Speculative feedback
sigma = 0.1;     % Volatility
T = 500;        % Number of time steps
dt = 1/252;     % Daily time step (252 trading days per year)

% Initialize arrays
time = (0:T-1)*dt;
fundamentalValue = zeros(T, 1);
marketPrice = zeros(T, 1);
returns = zeros(T, 1);
volatility = zeros(T, 1);

% Set initial values
fundamentalValue(1) = 100;
marketPrice(1) = 100;
volatility(1) = sigma;

% Simulate the market
for t = 2:T
    % Update fundamental value with growth and random shocks
    fundamentalValue(t) = fundamentalValue(t-1) * (1 + alpha*dt + sigma*sqrt(dt)*randn);
    
    % Update market price based on mean reversion to fundamental plus feedback
    % from past returns and time-varying volatility
    if t > 2
        returns(t-1) = (marketPrice(t-1) - marketPrice(t-2)) / marketPrice(t-2);
        % GARCH-like volatility update
        volatility(t) = sqrt(0.9*volatility(t-1)^2 + 0.1*returns(t-1)^2);
    end
    
    % Price evolution with feedback and volatility
    meanReversion = 0.1 * (fundamentalValue(t) - marketPrice(t-1));
    momentumEffect = beta * returns(max(1, t-2));
    randomShock = volatility(t) * sqrt(dt) * randn;
    
    marketPrice(t) = marketPrice(t-1) * (1 + meanReversion + momentumEffect + randomShock);
end

% Calculate returns
returns(1) = 0;
for t = 2:T
    returns(t) = (marketPrice(t) - marketPrice(t-1)) / marketPrice(t-1);
end

% Plot results
subplot(3, 1, 1);
plot(time, fundamentalValue, 'b-', time, marketPrice, 'r-', 'LineWidth', 2);
title('Financial Market Model: Price Dynamics');
xlabel('Time (years)');
ylabel('Price');
legend('Fundamental Value', 'Market Price', 'Location', 'best');
grid on;

subplot(3, 1, 2);
plot(time, returns, 'g-', 'LineWidth', 1);
title('Daily Returns');
xlabel('Time (years)');
ylabel('Return');
grid on;

subplot(3, 1, 3);
plot(time, volatility, 'm-', 'LineWidth', 1.5);
title('Volatility');
xlabel('Time (years)');
ylabel('Volatility');
grid on;

% Task 5: Digital Twin for a Simple Physical System
figure('Name', 'Digital Twin Simulation');

% System definition - a simple water tank with inflow and outflow
% State: water level (m)
% Input: inflow rate (m?/s)
% Disturbance: outflow rate (m?/s)
% Parameters
tankArea = 1.0;    % m?
outflowCoeff = 0.1; % m?/s

% Simulation parameters
T = 200;          % Number of time steps
dt = 0.1;         % Time step (s)
time = (0:T-1)*dt;

% Initialize arrays
actualLevel = zeros(T, 1);
estimatedLevel = zeros(T, 1);
inflowRate = zeros(T, 1);
outflowRate = zeros(T, 1);
measurements = zeros(T, 1);
predictions = zeros(T, 10);  % Store 10-step ahead predictions

% Initial conditions
actualLevel(1) = 0.5;   % Initial water level (m)
estimatedLevel(1) = 0.5; % Initial estimate matches actual

% Kalman filter parameters
processNoise = 0.001;  % State evolution noise
measurementNoise = 0.05; % Measurement noise
estimateCovariance = 0.1; % Initial estimate uncertainty

% Controlled inflow pattern
for t = 1:T
    if t <= T/3
        inflowRate(t) = 0.1;  % Constant inflow
    elseif t <= 2*T/3
        inflowRate(t) = 0.2;  % Increased inflow
    else
        inflowRate(t) = 0.05; % Reduced inflow
    end
    
    % Add random variations to inflow
    inflowRate(t) = max(0, inflowRate(t) + 0.02*randn);
end

% Simulate the system and digital twin
for t = 2:T
    % Actual system dynamics (water tank)
    outflowRate(t-1) = outflowCoeff * sqrt(max(0, actualLevel(t-1)));
    actualLevel(t) = actualLevel(t-1) + ...
                    (inflowRate(t-1) - outflowRate(t-1)) / tankArea * dt + ...
                    sqrt(processNoise) * randn * sqrt(dt);
    
    % Generate noisy measurement
    measurements(t) = actualLevel(t) + sqrt(measurementNoise) * randn;
    
    % Digital twin: Kalman filter for state estimation
    % Prediction step
    predictedLevel = estimatedLevel(t-1) + ...
                     (inflowRate(t-1) - outflowCoeff * sqrt(max(0, estimatedLevel(t-1)))) / tankArea * dt;
    predictedCovariance = estimateCovariance + processNoise * dt;
    
    % Update step
    kalmanGain = predictedCovariance / (predictedCovariance + measurementNoise);
    estimatedLevel(t) = predictedLevel + kalmanGain * (measurements(t) - predictedLevel);
    estimateCovariance = (1 - kalmanGain) * predictedCovariance;
    
    % Make predictions for future states
    if mod(t, 20) == 0 || t == T
        futureLevel = estimatedLevel(t);
        for i = 1:10
            futureInflow = inflowRate(t); % Assume current inflow continues
            futureOutflow = outflowCoeff * sqrt(max(0, futureLevel));
            futureLevel = futureLevel + (futureInflow - futureOutflow) / tankArea * dt;
            predictions(t, i) = futureLevel;
        end
    end
end

% Plot results
subplot(3, 1, 1);
plot(time, actualLevel, 'b-', time, estimatedLevel, 'r--', 'LineWidth', 2);
hold on;
scatter(time, measurements, 10, 'g', 'filled', 'MarkerFaceAlpha', 0.3);
title('Digital Twin: Water Tank Level');
xlabel('Time (s)');
ylabel('Water Level (m)');
legend('Actual Level', 'Estimated Level', 'Measurements', 'Location', 'best');
grid on;

subplot(3, 1, 2);
plot(time, inflowRate, 'b-', time, outflowRate, 'r-', 'LineWidth', 2);
title('Flow Rates');
xlabel('Time (s)');
ylabel('Flow Rate (m?/s)');
legend('Inflow', 'Outflow', 'Location', 'best');
grid on;

subplot(3, 1, 3);
plot(time, actualLevel, 'b-', 'LineWidth', 2);
hold on;

% Plot predictions at specific time points
predictionTimes = 20:20:T;
for i = 1:length(predictionTimes)
    t = predictionTimes(i);
    if t > 0 && any(predictions(t,:) ~= 0)
        predictionHorizon = time(t) + (1:10)*dt;
        plot(predictionHorizon, predictions(t,:), 'g--', 'LineWidth', 1);
    end
end

title('Digital Twin: Predictions');
xlabel('Time (s)');
ylabel('Water Level (m)');
legend('Actual Level', 'Predictions', 'Location', 'best');
grid on;

% Calculate performance metrics
rmseEstimation = sqrt(mean((actualLevel - estimatedLevel).^2));
disp(['RMSE of state estimation: ' num2str(rmseEstimation)]);

% Local functions (moved to end so this listing is a valid MATLAB script)
function dydt = predatorPreyModel(t, y, alpha, beta, gamma, delta)
    prey = y(1);
    predators = y(2);
    
    % Rate of change of prey
    dPreydt = alpha * prey - beta * prey * predators;
    
    % Rate of change of predators
    dPredatorsdt = gamma * prey * predators - delta * predators;
    
    dydt = [dPreydt; dPredatorsdt];
end

function dydt = sirModel(t, y, beta, gamma)
    S = y(1);
    I = y(2);
    R = y(3);
    
    % Rate of change equations
    dSdt = -beta * S * I;
    dIdt = beta * S * I - gamma * I;
    dRdt = gamma * I;
    
    dydt = [dSdt; dIdt; dRdt];
end
