%% chapter_Introduction_lab03_basic.m
% Data import and basic analysis.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0301Introduction/
% Listing label         : chapter_Introduction_lab03_basic
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Import data from CSV file
% If file doesn't exist, create sample data
try
    data = readtable('sample_data.csv');
catch
    % Create synthetic data
    time = (0:0.1:10)';
    signal = sin(time) + 0.2*randn(size(time));
    data = table(time, signal);
    writetable(data, 'sample_data.csv');
    disp('Created sample data file: sample_data.csv');
end

% Basic analysis
meanValue = mean(data.signal);
stdValue = std(data.signal);
maxValue = max(data.signal);
minValue = min(data.signal);

% Display statistics
disp('Basic Signal Statistics:');
disp(['Mean: ' num2str(meanValue)]);
disp(['Standard Deviation: ' num2str(stdValue)]);
disp(['Maximum: ' num2str(maxValue)]);
disp(['Minimum: ' num2str(minValue)]);
