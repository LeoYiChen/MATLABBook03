%% chapter_Introduction_example_01.m
% Basic matrix operations demonstrating the fundamental paradigm of MATLAB.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0301Introduction/
% Listing label         : chapter_Introduction_example_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Define matrices representing different domain concepts
A = [1 2 3; 4 5 6; 7 8 9]; % Could represent a digital image, state transition matrix, etc.
B = [0.1 0.2 0.3]'; % Could represent a time series, control input, etc.

% Fundamental operations work the same regardless of domain interpretation
C = A * B; % Matrix multiplication
D = eig(A); % Eigenvalue calculation
