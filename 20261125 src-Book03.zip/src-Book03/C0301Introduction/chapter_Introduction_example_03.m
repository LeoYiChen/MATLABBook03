%% chapter_Introduction_example_03.m
% Example of integrating domain-specific code with documentation in Live Editor.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0301Introduction/
% Listing label         : chapter_Introduction_example_03
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% MULTIDISCIPLINARY ANALYSIS: VIBRATION IMPACT ON CELLULAR STRUCTURES
% This notebook combines mechanical engineering and cellular biology approaches

% Define vibration parameters (Mechanical Engineering domain)
freq = 1:5:100; % Hz
amplitude = 0.01; % m

% Calculate mechanical stress response
stress = calculateMechanicalStress(freq, amplitude);

% Visualize mechanical response
plot(freq, stress)
title('Mechanical Stress Response')
xlabel('Frequency (Hz)')
ylabel('Stress (MPa)')

% Apply biological cell damage model (Cellular Biology domain)
cellViability = predictCellViability(stress);

% Display integrated results
displayMultidisciplinaryResults(freq, stress, cellViability);

