%% chapter_Introduction_lab01_basic.m
% Basic matrix operations in MATLAB.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0301Introduction/
% Listing label         : chapter_Introduction_lab01_basic
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Create matrices
A = [1 2 3; 4 5 6; 7 8 9];
B = [9 8 7; 6 5 4; 3 2 1];

% Basic matrix operations
sumMatrix = A + B;          % Matrix addition
diffMatrix = A - B;         % Matrix subtraction
productMatrix = A * B;      % Matrix multiplication
elementProduct = A .* B;    % Element-wise multiplication
transposeA = A';            % Matrix transpose

% Display results
disp('Matrix A:');
disp(A);
disp('Matrix B:');
disp(B);
disp('Sum A + B:');
disp(sumMatrix);
disp('Product A * B:');
disp(productMatrix);
disp('Element-wise product A .* B:');
disp(elementProduct);
