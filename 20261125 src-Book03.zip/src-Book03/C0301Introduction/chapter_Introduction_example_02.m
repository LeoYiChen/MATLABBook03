%% chapter_Introduction_example_02.m
% Example of a computational pipeline spanning multiple domains.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0301Introduction/
% Listing label         : chapter_Introduction_example_02
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% 1. Data acquisition and preprocessing (Signal Processing)
rawData = loadData('experiment.dat');
filteredData = bandpassFilter(rawData, [0.1, 50]);

% 2. Feature extraction (Pattern Recognition)
features = extractFeatures(filteredData);

% 3. Statistical analysis (Statistics)
[correlations, pValues] = correlationAnalysis(features);

% 4. Prediction model (Machine Learning)
model = fitModel(features, targetValues);

% 5. visualisation and interpretation (Data visualisation)
visualizeResults(model, features, 'Model Performance');
