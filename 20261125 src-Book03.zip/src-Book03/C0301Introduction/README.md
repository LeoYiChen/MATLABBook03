# C0301Introduction - Supplementary MATLAB Source Code

| Field | Value |
| --- | --- |
| Book | MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications |
| Chapter | Introduction |
| Package version | 1.0.1 |
| Release stamp | 2026-11-10 |
| Source manuscript | `P03-20261111` |
| Source chapter file | `P0302main/C0301Introduction/` (included by `P03_20261005.tex`) |
| Code files | 14 (14 `.m`, 0 `.f`) |
| Code lines relocated | 1,293 |

## Why this folder exists

The editor reported that a large volume of programming code was present in the
manuscript and requested that it be moved to a professional repository with the
links supplied as supplementary material. The printed book is subject to a
length target below 1100 pages and to the Springer hard-copy limit of fewer
than 950 print pages. Accordingly, every `lstlisting` (and every MATLAB
`verbatim`) environment in the chapter has been removed from the main body and
deposited here. Only the filename, the listing caption and a reference to this
folder remain in the printed text.

## Naming convention

A file is named after the `label` of the listing it came from:

```latex
\begin{lstlisting}[..., caption={Basic matrix operations ...},
                     label={chapter_Introduction_example_01}]
```

is saved as `chapter_Introduction_example_01.m`.

- Listings without a `label` receive a generated name `C0301Introduction_code_NNN.m`.
- Code held in a `verbatim` environment receives `C0301Introduction_verbatim_NN.m`
  (or `.f` for the single illustrative Fortran 77 block).
- Where two listings shared the same label, the later file carries a numeric
  suffix (`_02`, `_03`, ...) so nothing is overwritten. This is recorded in
  the table below.

Each file begins with a header comment giving the caption, the original label,
this folder, the version stamp and the public repository URL.

## Finding a file from the book

The main text now shows a one-line note of the form:

> **Source code 3.4:** `chapter_ICT_example_01.m` - *caption*
> (supplementary material: `src-Book03/C0301Introduction/`)

The original listing numbers and all `\ref{...}` cross-references are
unchanged, so the in-text reference maps directly to a filename.

## Repository

```
https://github.com/LeoYiChen/MATLABBook03
```

Clone or download `src-Book03/` from this public repository, or use the
Springer supplementary archive. The same address is printed in the preface of
the book. Keep the `src-Book03/` folder name so that the in-text
`src-Book03/C0301Introduction/` paths resolve.

## Companion documents

- `VERSION.md` - version, release stamp and release notes
- `USER-GUIDE.md` - how to download, locate and run the code
- `MANIFEST.sha256` - SHA-256 ledger of every file in this folder

## Files

| Filename | Source listing label | Caption |
| --- | --- | --- |
| `chapter_Introduction_example_01.m` | `chapter_Introduction_example_01` | Basic matrix operations demonstrating the fundamental paradigm of MATLAB. |
| `chapter_Introduction_example_02.m` | `chapter_Introduction_example_02` | Example of a computational pipeline spanning multiple domains. |
| `chapter_Introduction_example_03.m` | `chapter_Introduction_example_03` | Example of integrating domain-specific code with documentation in Live Editor. |
| `chapter_Introduction_lab01_basic.m` | `chapter_Introduction_lab01_basic` | Basic matrix operations in MATLAB. |
| `chapter_Introduction_lab01_solutions.m` | `chapter_Introduction_lab01_solutions` | Solutions to matrix operations tasks. |
| `chapter_Introduction_lab02_basic.m` | `chapter_Introduction_lab02_basic` | Basic plotting in MATLAB. |
| `chapter_Introduction_lab02_solutions.m` | `chapter_Introduction_lab02_solutions` | Solutions to visualisation tasks. |
| `chapter_Introduction_lab03_basic.m` | `chapter_Introduction_lab03_basic` | Data import and basic analysis. |
| `chapter_Introduction_lab03_solutions.m` | `chapter_Introduction_lab03_solutions` | Solutions to data analysis tasks. |
| `chapter_Introduction_lab04_basic.m` | `chapter_Introduction_lab04_basic` | Basic model definition and simulation. |
| `chapter_Introduction_lab04_solutions.m` | `chapter_Introduction_lab04_solutions` | Solutions to model-based design tasks. |
| `chapter_Introduction_lab05_basic.m` | `chapter_Introduction_lab05_basic` | Basic machine learning workflow. |
| `chapter_Introduction_lab05_solutions.m` | `chapter_Introduction_lab05_solutions` | Solutions to machine learning tasks. |
| `chapter_intro_example_01.m` | `chapter_intro_example_01` | Example MATLAB Code Structure |
