%% MATLABBook03_Chapter01_Lab01.m
% Exploring the MATLAB Environment and Matrix Operations
% This script introduces the fundamental components of MATLAB that serve as
% building blocks for multidisciplinary applications.
%
% MATLAB Roadmap to Applications - Volume III Multidisciplinary Applications
% Chapter 1: Introduction
% Laboratory 1: Matrix Operations
% 
% Version: 1.0
% Date: June 2023
% Author: Dr Leo Chen
% MATLAB Version: R2023a

%% Clear workspace and command window
clear;
clc;
disp('Laboratory 1: Exploring the MATLAB Environment and Matrix Operations');
disp('==================================================================');

%% 1. Basic Matrix Creation and Operations
disp('1. Basic Matrix Creation and Operations');
disp('---------------------------------------------------------');

% Create matrices
A = [1 2 3; 4 5 6; 7 8 9];
B = [9 8 7; 6 5 4; 3 2 1];

% Basic matrix operations
sumMatrix = A + B;          % Matrix addition
diffMatrix = A - B;         % Matrix subtraction
productMatrix = A * B;      % Matrix multiplication
elementProduct = A .* B;    % Element-wise multiplication
transposeA = A';            % Matrix transpose

% Display results
disp('Matrix A:');
disp(A);
disp('Matrix B:');
disp(B);
disp('Sum A + B:');
disp(sumMatrix);
disp('Difference A - B:');
disp(diffMatrix);
disp('Product A * B:');
disp(productMatrix);
disp('Element-wise product A .* B:');
disp(elementProduct);
disp('Transpose of A:');
disp(transposeA);

%% 2. Matrix Functions
disp('---------------------------------------------------------');
disp('2. Matrix Functions');
disp('---------------------------------------------------------');

% Calculate determinant
detA = det(A);
disp(['Determinant of A: ' num2str(detA)]);

% Calculate eigenvalues and eigenvectors
[V, D] = eig(A);
disp('Eigenvalues of A:');
disp(diag(D));
disp('Eigenvectors of A:');
disp(V);

% Matrix rank
rankA = rank(A);
disp(['Rank of A: ' num2str(rankA)]);

% Matrix inverse (if possible)
if det(A) ~= 0
    invA = inv(A);
    disp('Inverse of A:');
    disp(invA);
    
    % Verify inverse
    disp('A * inv(A) (should be identity matrix):');
    disp(A * invA);
else
    disp('A is singular, no inverse exists');
end

%% 3. Solving Systems of Linear Equations
disp('---------------------------------------------------------');
disp('3. Solving Systems of Linear Equations');
disp('---------------------------------------------------------');

% Create a system Ax = b
b = [1; 2; 3];

% Solve using matrix division (preferred method)
x1 = A \ b;
disp('Solution to Ax = b using A \ b:');
disp(x1);

% Verify solution
disp('Verification A*x:');
disp(A * x1);

% Solve using inverse (less numerically stable)
x2 = inv(A) * b;
disp('Solution to Ax = b using inv(A)*b:');
disp(x2);

% Compare methods
disp(['Difference between methods: ' num2str(norm(x1 - x2))]);

%% 4. Tasks
disp('---------------------------------------------------------');
disp('4. Tasks for Practice');
disp('---------------------------------------------------------');
disp('Task 1: Create a 4×4 matrix containing random integers between 1 and 10');
disp('Task 2: Calculate the determinant and eigenvalues of this matrix');
disp('Task 3: Solve the system of linear equations Ax = b where b is a column vector of ones');
disp('Task 4: Create a sparse matrix representation of a large matrix containing mostly zeros');
disp('Task 5: Experiment with matrix factorisation techniques like LU and QR decomposition');

%% 5. Solutions to Tasks
disp('---------------------------------------------------------');
disp('5. Solutions to Tasks');
disp('---------------------------------------------------------');

% Task 1: Create a 4x4 matrix with random integers
randomMatrix = randi(10, 4, 4);
disp('Random 4x4 matrix:');
disp(randomMatrix);

% Task 2: Calculate determinant and eigenvalues
detValue = det(randomMatrix);
eigenvalues = eig(randomMatrix);
disp('Determinant:');
disp(detValue);
disp('Eigenvalues:');
disp(eigenvalues);

% Task 3: Solve system of linear equations
b = ones(4, 1);
x = randomMatrix \ b;  % More efficient than inv(randomMatrix) * b
disp('Solution to Ax = b:');
disp(x);
disp('Verification (should be close to b):');
disp(randomMatrix * x);

% Task 4: Create a sparse matrix
sparseSize = 1000;
i = randi(sparseSize, 100, 1);  % Row indices
j = randi(sparseSize, 100, 1);  % Column indices
values = rand(100, 1);          % Values
sparseMatrix = sparse(i, j, values, sparseSize, sparseSize);
disp('Sparse matrix properties:');
disp(['Size: ' num2str(size(sparseMatrix, 1)) 'x' num2str(size(sparseMatrix, 2))]);
disp(['Number of non-zeros: ' num2str(nnz(sparseMatrix))]);
disp(['Sparsity: ' num2str(1 - nnz(sparseMatrix)/(sparseSize^2))]);

% Display a subset of the sparse matrix
disp('First 5x5 block of sparse matrix:');
fullSubset = full(sparseMatrix(1:5, 1:5));
disp(fullSubset);

% Task 5: Matrix factorisation
[L, U, P] = lu(randomMatrix);
[Q, R] = qr(randomMatrix);

disp('LU Decomposition:');
disp('L (Lower triangular):');
disp(L);
disp('U (Upper triangular):');
disp(U);
disp('P (Permutation matrix):');
disp(P);
disp('LU Decomposition verification (should be close to randomMatrix):');
disp(P' * L * U);

disp('QR Decomposition:');
disp('Q (Orthogonal matrix):');
disp(Q);
disp('R (Upper triangular matrix):');
disp(R);
disp('QR Decomposition verification (should be close to randomMatrix):');
disp(Q * R);

%% 6. Advanced Matrix Operations (Additional Material)
disp('---------------------------------------------------------');
disp('6. Advanced Matrix Operations');
disp('---------------------------------------------------------');

% Singular Value Decomposition (SVD)
disp('Singular Value Decomposition of A:');
[U, S, V] = svd(A);
disp('U (Left singular vectors):');
disp(U);
disp('S (Singular values):');
disp(S);
disp('V (Right singular vectors):');
disp(V);
disp('SVD verification (should be close to A):');
disp(U * S * V');

% Condition number
disp(['Condition number of A: ' num2str(cond(A))]);

% Matrix exponential
disp('Matrix exponential of A:');
disp(expm(A));

% Jordan canonical form
disp('Jordan form of A:');
[V, J] = jordan(A);
disp('J (Jordan form):');
disp(J);
disp('V (Transformation matrix):');
disp(V);
disp('Jordan form verification (should be close to A):');
disp(V * J * inv(V));

disp('Laboratory 1 completed successfully');