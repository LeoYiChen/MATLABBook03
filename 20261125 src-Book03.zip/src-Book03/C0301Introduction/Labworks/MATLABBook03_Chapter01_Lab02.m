%% MATLABBook03_Chapter01_Lab02.m
% Cross-Disciplinary Data Visualisation
% This script demonstrates various plotting techniques applicable to different
% types of data encountered in multidisciplinary applications.
%
% MATLAB Roadmap to Applications - Volume III Multidisciplinary Applications
% Chapter 1: Introduction
% Laboratory 2: Data Visualisation
% 
% Version: 1.0
% Date: June 2023
% Author: Dr Leo Chen
% MATLAB Version: R2023a

%% Clear workspace and command window
clear;
clc;
close all;

disp('Laboratory 2: Cross-Disciplinary Data Visualisation');
disp('==================================================================');

%% 1. Basic 2D Plotting
disp('1. Basic 2D Plotting');
disp('---------------------------------------------------------');

% Generate sample data
x = linspace(0, 2*pi, 100);
y1 = sin(x);
y2 = cos(x);
y3 = sin(x) .* cos(x);

% Create a simple 2D plot
figure('Name', 'Basic 2D Plotting');
plot(x, y1, 'b-', x, y2, 'r--', 'LineWidth', 2);
title('Sine and Cosine Functions');
xlabel('x (radians)');
ylabel('Amplitude');
legend('sin(x)', 'cos(x)', 'Location', 'best');
grid on;

% Adjust plot properties
set(gca, 'FontSize', 12);
set(gca, 'XTick', 0:pi/2:2*pi);
set(gca, 'XTickLabel', {'0', '\pi/2', '\pi', '3\pi/2', '2\pi'});
ylim([-1.2, 1.2]);

% Add annotations
text(pi/4, sin(pi/4) + 0.1, 'sin(\pi/4) \approx 0.7071', 'FontSize', 10);
text(pi/4, cos(pi/4) - 0.1, 'cos(\pi/4) \approx 0.7071', 'FontSize', 10);

% Display key values
disp(['sin(π/4) = ' num2str(sin(pi/4))]);
disp(['cos(π/4) = ' num2str(cos(pi/4))]);

%% 2. Multiple Plot Types
disp('---------------------------------------------------------');
disp('2. Multiple Plot Types');
disp('---------------------------------------------------------');

% Generate sample data for all visualisations
rng(1);  % Set random seed for reproducibility
n = 1000;
data = randn(n, 1);  % Normal distribution

% Create figure with multiple plot types
figure('Name', 'Multiple Visualization Types');

% Line plot
subplot(2, 2, 1);
x = linspace(-3, 3, n);
y = 1.5*x + 0.5*x.^2 + randn(size(x));
plot(x, y, 'b-');
title('Line Plot');
xlabel('x');
ylabel('y');
grid on;

% Scatter plot
subplot(2, 2, 2);
scatter(x, y, 10, 'filled');
title('Scatter Plot');
xlabel('x');
ylabel('y');
grid on;

% Histogram
subplot(2, 2, 3);
histogram(data, 30);
title('Histogram');
xlabel('Value');
ylabel('Frequency');
grid on;

% Box plot
subplot(2, 2, 4);
boxplot(data);
title('Box Plot');
ylabel('Value');
grid on;

%% 3. 3D Plotting
disp('---------------------------------------------------------');
disp('3. 3D Plotting');
disp('---------------------------------------------------------');

% Generate data for 3D plotting
[X, Y] = meshgrid(linspace(-10, 10, 100), linspace(-10, 10, 100));
R = sqrt(X.^2 + Y.^2) + eps;  % Adding eps to avoid division by zero
Z = sin(R)./R;

% Create figure with multiple 3D plot types
figure('Name', '3D Visualization Techniques');

% Surface plot
subplot(2, 2, 1);
surf(X, Y, Z);
title('Surface Plot');
xlabel('x');
ylabel('y');
zlabel('z');

% Mesh plot
subplot(2, 2, 2);
mesh(X, Y, Z);
title('Mesh Plot');
xlabel('x');
ylabel('y');
zlabel('z');

% Contour plot
subplot(2, 2, 3);
contour(X, Y, Z, 20);
title('Contour Plot');
xlabel('x');
ylabel('y');
colorbar;

% 3D contour plot
subplot(2, 2, 4);
contour3(X, Y, Z, 20);
title('3D Contour Plot');
xlabel('x');
ylabel('y');
zlabel('z');
grid on;

%% 4. Specialised Plots
disp('---------------------------------------------------------');
disp('4. Specialised Plots');
disp('---------------------------------------------------------');

figure('Name', 'Specialised Plots');

% Polar plot
subplot(2, 2, 1);
theta = linspace(0, 2*pi, 100);
rho = 1 + 0.5*sin(5*theta);
polarplot(theta, rho);
title('Polar Plot');

% Bar chart
subplot(2, 2, 2);
categories = {'Category A', 'Category B', 'Category C', 'Category D', 'Category E'};
values = [23, 45, 12, 78, 32];
bar(values);
title('Bar Chart');
xticklabels(categories);
xtickangle(45);
ylabel('Value');
grid on;

% Pie chart
subplot(2, 2, 3);
pie(values, {'A', 'B', 'C', 'D', 'E'});
title('Pie Chart');

% Area plot
subplot(2, 2, 4);
x = 1:10;
y = [cumsum(rand(1,10)); cumsum(rand(1,10)); cumsum(rand(1,10))];
area(x, y');
title('Area Plot');
xlabel('X');
ylabel('Y');
legend('Series 1', 'Series 2', 'Series 3', 'Location', 'northwest');
grid on;

%% 5. Tasks
disp('---------------------------------------------------------');
disp('5. Tasks for Practice');
disp('---------------------------------------------------------');
disp('Task 1: Create a subplot with four different visualisations of the same dataset');
disp('Task 2: Generate a 3D surface plot of the function z = sin(sqrt(x^2 + y^2))/sqrt(x^2 + y^2)');
disp('Task 3: Create a heatmap visualisation of a correlation matrix between five random variables');
disp('Task 4: Use tiledlayout to create a responsive grid of plots with shared axes');
disp('Task 5: Create an animated visualisation of a simple dynamical system');

%% 6. Solutions to Tasks
disp('---------------------------------------------------------');
disp('6. Solutions to Tasks');
disp('---------------------------------------------------------');

% Task 1: Multiple visualisation types of the same dataset
disp('Task 1: Multiple visualisations of the same dataset');

% Generate sample data for all visualisations
n = 1000;
data = randn(n, 5);  % 5 random variables
x = linspace(-3, 3, n)';
y = 2*x + 0.5*x.^2 + 2*randn(n, 1);  % Nonlinear relationship with noise

% Task 1: Multiple visualisation types of the same dataset
figure('Name', 'Task 1: Multiple Visualization Types');
subplot(2, 2, 1)
plot(x, y, 'b-');
title('Line Plot');
xlabel('x'); ylabel('y');
grid on;

subplot(2, 2, 2)
scatter(x, y, 10, 'filled');
title('Scatter Plot');
xlabel('x'); ylabel('y');
grid on;

subplot(2, 2, 3)
histogram(y, 30);
title('Histogram');
xlabel('Value'); ylabel('Frequency');
grid on;

subplot(2, 2, 4)
boxplot(y);
title('Box Plot');
grid on;

% Task 2: 3D Surface plot
disp('Task 2: 3D Surface plot');
figure('Name', 'Task 2: 3D Surface Plot');
[X, Y] = meshgrid(linspace(-10, 10, 100), linspace(-10, 10, 100));
R = sqrt(X.^2 + Y.^2) + eps;  % Adding eps to avoid division by zero
Z = sin(R)./R;
surf(X, Y, Z);
title('sin(r)/r Function');
xlabel('x'); ylabel('y'); zlabel('z');
colormap('jet');
colorbar;

% Task 3: Correlation matrix heatmap
disp('Task 3: Correlation matrix heatmap');
figure('Name', 'Task 3: Correlation Matrix');
corrMatrix = corr(data);
heatmap(corrMatrix);
title('Correlation Matrix Heatmap');
xlabel('Variable'); ylabel('Variable');
colormap('jet');

% Task 4: Tiledlayout with shared axes
disp('Task 4: Tiledlayout with shared axes');
figure('Name', 'Task 4: Tiled Layout with Shared Axes');
tiledlayout(2, 2, 'TileSpacing', 'compact', 'Padding', 'compact');

% First tile
ax1 = nexttile;
plot(ax1, x, y, '.');
title(ax1, 'Raw Data');

% Second tile - Histogram of x
ax2 = nexttile;
histogram(ax2, x, 30);
title(ax2, 'Distribution of x');

% Third tile - Histogram of y
ax3 = nexttile;
histogram(ax3, y, 30);
title(ax3, 'Distribution of y');

% Fourth tile - Boxplots
ax4 = nexttile;
boxplot(ax4, [x, y], 'Labels', {'x', 'y'});
title(ax4, 'Boxplots');

% Link axes where appropriate
linkaxes([ax1, ax2], 'x');
linkaxes([ax1, ax3], 'y');

% Task 5: Animated visualisation of a simple pendulum
disp('Task 5: Animated visualisation of a simple pendulum');
figure('Name', 'Task 5: Pendulum Animation');
ax = gca;
ax.XLim = [-1.1 1.1];
ax.YLim = [-1.1 0.1];
grid on;
hold on;

% Pendulum parameters
L = 1;          % Length
g = 9.81;       % Gravity
theta0 = pi/4;  % Initial angle
omega0 = 0;     % Initial angular velocity

% Time parameters
tspan = [0, 10];
dt = 0.05;
t = tspan(1):dt:tspan(2);

% Solve the pendulum equation: d²θ/dt² + (g/L)sin(θ) = 0
[t, y] = ode45(@(t,y) [y(2); -g/L*sin(y(1))], t, [theta0; omega0]);

% Convert to cartesian coordinates
x_pend = L * sin(y(:,1));
y_pend = -L * cos(y(:,1));

% Create pendulum visual elements
pendulumLine = plot([0, x_pend(1)], [0, y_pend(1)], 'k-', 'LineWidth', 2);
pendulumBob = plot(x_pend(1), y_pend(1), 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
title('Simple Pendulum Simulation');

% Trace of the pendulum motion
traceLine = animatedline('Color', 'b', 'LineStyle', ':', 'LineWidth', 1);

% Animation
for i = 1:length(t)
    % Update pendulum position
    set(pendulumLine, 'XData', [0, x_pend(i)], 'YData', [0, y_pend(i)]);
    set(pendulumBob, 'XData', x_pend(i), 'YData', y_pend(i));
    
    % Add point to trace
    addpoints(traceLine, x_pend(i), y_pend(i));
    
    % Display time
    if ishandle(timeText)
        delete(timeText);
    end
    timeText = text(-1, 0, sprintf('Time: %.2f s', t(i)), 'FontSize', 10);
    
    % Update display
    drawnow;
    pause(0.01);
end

%% 7. Advanced Visualisation Techniques (Additional Material)
disp('---------------------------------------------------------');
disp('7. Advanced Visualisation Techniques');
disp('---------------------------------------------------------');

% Create a 3D animation
figure('Name', 'Advanced 3D Animation');

% Generate a rotating torus
[theta, phi] = meshgrid(linspace(0, 2*pi, 40), linspace(0, 2*pi, 40));
r = 1;
a = 2;
x = (a + r*cos(theta)) .* cos(phi);
y = (a + r*cos(theta)) .* sin(phi);
z = r * sin(theta);

% Create surface with custom colormap
surface = surf(x, y, z, z);
colormap(hsv);
colorbar;
axis equal;
grid on;
title('Rotating Torus');
xlabel('X'); ylabel('Y'); zlabel('Z');

% Animation loop
for angle = 1:5:360
    % Rotate the view
    view(angle, 20);
    drawnow;
    pause(0.01);
end

% Create a custom colormap visualization
figure('Name', 'Custom Colormap Visualization');

% Generate data
[X, Y] = meshgrid(linspace(-3, 3, 100), linspace(-3, 3, 100));
Z = X.^2 - Y.^2;

% Create visualization with custom colormap
subplot(1, 2, 1);
surf(X, Y, Z, 'EdgeColor', 'none');
title('Default Colormap');
xlabel('X'); ylabel('Y'); zlabel('Z');
view(30, 30);

subplot(1, 2, 2);
surf(X, Y, Z, 'EdgeColor', 'none');
title('Custom Colormap');
xlabel('X'); ylabel('Y'); zlabel('Z');
view(30, 30);

% Create a custom colormap that transitions from blue to white to red
customMap = [linspace(0, 1, 64)', linspace(0, 1, 64)', ones(64, 1);
             ones(64, 1), linspace(1, 0, 64)', linspace(1, 0, 64)'];
colormap(subplot(1, 2, 2), customMap);

% Add colorbars
colorbar(subplot(1, 2, 1));
colorbar(subplot(1, 2, 2));

% Make sure colormaps have the same scale
caxis(subplot(1, 2, 1), [-9, 9]);
caxis(subplot(1, 2, 2), [-9, 9]);

disp('Laboratory 2 completed successfully');