%% MATLABBook03_Chapter01_Lab04.m
% Model-Based Design for Cross-Disciplinary Systems
% This laboratory explores the implementation of models for various types of
% systems within MATLAB.
%
% MATLAB Roadmap to Applications - Volume III Multidisciplinary Applications
% Chapter 1: Introduction
% Laboratory 4: Model-Based Design
% 
% Version: 1.0
% Date: June 2023
% Author: Dr Leo Chen
% MATLAB Version: R2023a

%% Clear workspace and command window
clear;
clc;
close all;

disp('Laboratory 4: Model-Based Design for Cross-Disciplinary Systems');
disp('==================================================================');

%% 1. Basic Linear System Modelling
disp('1. Basic Linear System Modelling');
disp('---------------------------------------------------------');

% Define a simple linear model
A = [0.9, 0.1; 0, 0.8];  % System matrix
B = [0; 1];              % Input matrix
C = [1, 0];              % Output matrix
D = 0;                   % Feedthrough matrix

% Create state-space model
sampleTime = 0.1;
sys = ss(A, B, C, D, sampleTime);

% Display system
disp('State-Space Model:');
disp(sys);

% Check system properties
disp(['Sample Time: ' num2str(sampleTime) ' seconds']);
disp(['System is stable: ' mat2str(isstable(sys))]);
disp(['System is controllable: ' mat2str(rank(ctrb(A, B)) == size(A, 1))]);
disp(['System is observable: ' mat2str(rank(obsv(A, C)) == size(A, 1))]);

% Simulate the system response to an input
t = 0:sampleTime:10;
u = ones(size(t));  % Step input
[y, t, x] = lsim(sys, u, t, [0; 0]);  % Simulate with zero initial state

% Plot the results
figure('Name', 'Linear System Response');
subplot(3, 1, 1);
plot(t, u, 'r-', 'LineWidth', 2);
title('Input Signal');
xlabel('Time (s)');
ylabel('Amplitude');
grid on;

subplot(3, 1, 2);
plot(t, x, 'LineWidth', 2);
title('State Variables');
xlabel('Time (s)');
ylabel('Value');
legend('State 1', 'State 2');
grid on;

subplot(3, 1, 3);
plot(t, y, 'b-', 'LineWidth', 2);
title('System Response');
xlabel('Time (s)');
ylabel('Amplitude');
grid on;

%% 2. Transfer Function Representation
disp('---------------------------------------------------------');
disp('2. Transfer Function Representation');
disp('---------------------------------------------------------');

% Convert state-space to transfer function
sysTf = tf(sys);
disp('Transfer Function:');
disp(sysTf);

% Step response using transfer function
figure('Name', 'Transfer Function Analysis');
subplot(2, 1, 1);
step(sysTf);
title('Step Response from Transfer Function');
grid on;

% Bode plot for frequency domain analysis
subplot(2, 1, 2);
bode(sysTf);
title('Bode Plot');
grid on;

%% 3. Control System Design
disp('---------------------------------------------------------');
disp('3. Control System Design');
disp('---------------------------------------------------------');

% Define plant transfer function (e.g., motor)
s = tf('s');
G = 1/(s^2 + 0.5*s + 1);
disp('Plant Transfer Function:');
disp(G);

% Design a PID controller
Kp = 2;   % Proportional gain
Ki = 1;   % Integral gain
Kd = 1;   % Derivative gain
C = pid(Kp, Ki, Kd);
disp('PID Controller:');
disp(C);

% Create closed-loop system
sysCl = feedback(C*G, 1);
disp('Closed-Loop System:');
disp(sysCl);

% Simulate closed-loop system
figure('Name', 'Control System Design');
subplot(2, 1, 1);
step(sysCl);
title('Closed-Loop Step Response');
grid on;

% Compare with open-loop system
subplot(2, 1, 2);
step(G, 'b', sysCl, 'r');
title('Open-Loop vs Closed-Loop Response');
legend('Open-Loop', 'Closed-Loop');
grid on;

%% 4. Nonlinear System Modelling
disp('---------------------------------------------------------');
disp('4. Nonlinear System Modelling');
disp('---------------------------------------------------------');

% Define a nonlinear system (pendulum)
pendulumSystem = @(t, y) [y(2); -9.81/1 * sin(y(1))];

% Simulate using ode45
tspan = [0 10];
y0 = [pi/4; 0];  % Initial conditions (angle = 45°, angular velocity = 0)
[t, y] = ode45(pendulumSystem, tspan, y0);

% Plot results
figure('Name', 'Nonlinear System - Pendulum');
subplot(2, 1, 1);
plot(t, y(:, 1), 'LineWidth', 2);
title('Pendulum Angle');
xlabel('Time (s)');
ylabel('Angle (rad)');
grid on;

subplot(2, 1, 2);
plot(t, y(:, 2), 'LineWidth', 2);
title('Angular Velocity');
xlabel('Time (s)');
ylabel('Velocity (rad/s)');
grid on;

% Plot phase portrait
figure('Name', 'Phase Portrait');
plot(y(:, 1), y(:, 2), 'LineWidth', 2);
title('Phase Portrait: Angular Position vs. Angular Velocity');
xlabel('Angle (rad)');
ylabel('Angular Velocity (rad/s)');
grid on;
hold on;
plot(y(1, 1), y(1, 2), 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r');  % Start point
text(y(1, 1), y(1, 2), ' Start', 'FontSize', 12);
plot(y(end, 1), y(end, 2), 'go', 'MarkerSize', 10, 'MarkerFaceColor', 'g');  % End point
text(y(end, 1), y(end, 2), ' End', 'FontSize', 12);

%% 5. Multidomain Modelling
disp('---------------------------------------------------------');
disp('5. Multidomain Modelling');
disp('---------------------------------------------------------');

% Example: RC circuit (electrical domain) as a dynamic system
R = 1e3;  % Resistance (ohms)
C = 1e-6;  % Capacitance (farads)
tau = R*C;  % Time constant (seconds)

% Create transfer function for RC circuit
RCsys = tf(1, [tau 1]);
disp('RC Circuit Transfer Function:');
disp(RCsys);

% Example: Mass-spring-damper (mechanical domain)
m = 1;    % Mass (kg)
k = 10;   % Spring constant (N/m)
c = 2;    % Damping coefficient (N·s/m)

% Create transfer function for mass-spring-damper
MSDsys = tf(1, [m c k]);
disp('Mass-Spring-Damper Transfer Function:');
disp(MSDsys);

% Compare responses of these systems
figure('Name', 'Multidomain Systems');
step(RCsys, 'b', MSDsys, 'r');
title('Comparison of RC Circuit and Mass-Spring-Damper Responses');
legend('RC Circuit', 'Mass-Spring-Damper');
grid on;

% Show that mathematically these systems are analogous
disp('System Comparison:');
disp(['RC Circuit Time Constant: ' num2str(tau) ' seconds']);
disp(['MSD Natural Frequency: ' num2str(sqrt(k/m)) ' rad/s']);
disp(['MSD Damping Ratio: ' num2str(c/(2*sqrt(k*m)))]);

%% 6. Tasks
disp('---------------------------------------------------------');
disp('6. Tasks for Practice');
disp('---------------------------------------------------------');
disp('Task 1: Create and simulate a model for a simple mechanical system (e.g., mass-spring-damper)');
disp('Task 2: Implement a predator-prey model to simulate ecological dynamics');
disp('Task 3: Develop a compartmental model for epidemic spread (e.g., SIR model)');
disp('Task 4: Create a simplified financial market model with feedback loops');
disp('Task 5: Implement a digital twin for a simple physical system that can estimate state and predict future behaviour');

%% 7. Solutions to Tasks
disp('---------------------------------------------------------');
disp('7. Solutions to Tasks');
disp('---------------------------------------------------------');

% Task 1: Mass-Spring-Damper System
disp('Task 1: Mass-Spring-Damper System');
figure('Name', 'Task 1: Mass-Spring-Damper System');

% System parameters
m = 1.0;    % Mass (kg)
k = 10.0;   % Spring constant (N/m)
c = 0.5;    % Damping coefficient (N·s/m)

% State space representation
A = [0, 1; -k/m, -c/m];
B = [0; 1/m];
C = [1, 0];  % Position output
D = 0;

% Create state-space model
msdSystem = ss(A, B, C, D);

% Impulse response (hit the mass)
t = 0:0.01:10;
[y, t] = impulse(msdSystem, t);

% Plot position response
subplot(2, 1, 1);
plot(t, y, 'b-', 'LineWidth', 2);
title('Mass-Spring-Damper: Impulse Response');
xlabel('Time (s)');
ylabel('Position (m)');
grid on;

% Step response (constant force)
[y, t] = step(msdSystem, t);

% Plot position response
subplot(2, 1, 2);
plot(t, y, 'r-', 'LineWidth', 2);
title('Mass-Spring-Damper: Step Response');
xlabel('Time (s)');
ylabel('Position (m)');
grid on;

% Task 2: Predator-Prey Model (Lotka-Volterra)
disp('Task 2: Predator-Prey Model');
figure('Name', 'Task 2: Predator-Prey Model');

% Model parameters
alpha = 0.1;   % Prey growth rate
beta = 0.02;   % Prey death rate due to predation
gamma = 0.01;  % Predator growth rate from prey
delta = 0.1;   % Predator death rate

% Time span
tspan = [0, 200];

% Initial conditions: [prey, predator]
y0 = [50, 10];

% Define the predator-prey model function
predatorPreyModel = @(t, y) [
    alpha * y(1) - beta * y(1) * y(2);  % Rate of change of prey
    gamma * y(1) * y(2) - delta * y(2)  % Rate of change of predators
];

% Solve the differential equations
[t, y] = ode45(predatorPreyModel, tspan, y0);

% Plot populations over time
subplot(2, 1, 1);
plot(t, y(:,1), 'b-', t, y(:,2), 'r-', 'LineWidth', 2);
title('Predator-Prey Dynamics');
xlabel('Time');
ylabel('Population');
legend('Prey', 'Predators', 'Location', 'best');
grid on;

% Phase portrait
subplot(2, 1, 2);
plot(y(:,1), y(:,2), 'g-', 'LineWidth', 2);
hold on;
plot(y0(1), y0(2), 'ko', 'MarkerSize', 10, 'LineWidth', 2);
title('Phase Portrait');
xlabel('Prey Population');
ylabel('Predator Population');
grid on;

% Calculate equilibrium points
equilibriumPrey = delta / gamma;
equilibriumPredator = alpha / beta;
plot(equilibriumPrey, equilibriumPredator, 'ro', 'MarkerSize', 10, 'LineWidth', 2);
text(equilibriumPrey + 2, equilibriumPredator, 'Equilibrium', 'FontSize', 12);

% Task 3: SIR Epidemic Model
disp('Task 3: SIR Epidemic Model');
figure('Name', 'Task 3: SIR Epidemic Model');

% Model parameters
beta = 0.3;    % Infection rate
gamma = 0.1;   % Recovery rate
N = 1000;      % Total population

% Time span (days)
tspan = [0, 100];

% Initial conditions: [S, I, R] as fractions of total population
initialInfected = 1;  % Start with 1 infected person
y0 = [(N - initialInfected)/N, initialInfected/N, 0];

% Define the SIR model function
sirModel = @(t, y) [
    -beta * y(1) * y(2);           % Rate of change of susceptible
    beta * y(1) * y(2) - gamma * y(2);  % Rate of change of infected
    gamma * y(2)                   % Rate of change of recovered
];

% Solve the differential equations
[t, y] = ode45(sirModel, tspan, y0);

% Plot the SIR curves
subplot(2, 1, 1);
plot(t, y(:,1)*N, 'b-', t, y(:,2)*N, 'r-', t, y(:,3)*N, 'g-', 'LineWidth', 2);
title('SIR Epidemic Model');
xlabel('Time (days)');
ylabel('Population');
legend('Susceptible', 'Infected', 'Recovered', 'Location', 'best');
grid on;

% Calculate and plot new infections per day
newInfections = diff(y(:,2)*N + y(:,3)*N);
subplot(2, 1, 2);
bar(t(2:end), newInfections);
title('New Infections per Day');
xlabel('Time (days)');
ylabel('New Cases');
grid on;

% Calculate peak infection and timing
[peakInfected, peakIdx] = max(y(:,2));
disp(['Peak infection: Day ' num2str(t(peakIdx)) ' with ' ...
      num2str(peakInfected*N) ' infected people (' ...
      num2str(peakInfected*100) '% of population)']);

% Task 4: Financial Market Model
disp('Task 4: Financial Market Model');
figure('Name', 'Task 4: Financial Market Model');

% Model parameters
alpha = 0.05;    % Fundamental growth rate
beta = 0.2;      % Speculative feedback
sigma = 0.1;     % Volatility
T = 500;        % Number of time steps
dt = 1/252;     % Daily time step (252 trading days per year)

% Initialize arrays
time = (0:T-1)*dt;
fundamentalValue = zeros(T, 1);
marketPrice = zeros(T, 1);
returns = zeros(T, 1);
volatility = zeros(T, 1);

% Set initial values
fundamentalValue(1) = 100;
marketPrice(1) = 100;
volatility(1) = sigma;

% Simulate the market
for t = 2:T
    % Update fundamental value with growth and random shocks
    fundamentalValue(t) = fundamentalValue(t-1) * (1 + alpha*dt + sigma*sqrt(dt)*randn);
    
    % Update market price based on mean reversion to fundamental plus feedback
    % from past returns and time-varying volatility
    if t > 2
        returns(t-1) = (marketPrice(t-1) - marketPrice(t-2)) / marketPrice(t-2);
        % GARCH-like volatility update
        volatility(t) = sqrt(0.9*volatility(t-1)^2 + 0.1*returns(t-1)^2);
    end
    
    % Price evolution with feedback and volatility
    meanReversion = 0.1 * (fundamentalValue(t) - marketPrice(t-1));
    momentumEffect = beta * returns(max(1, t-2));
    randomShock = volatility(t) * sqrt(dt) * randn;
    
    marketPrice(t) = marketPrice(t-1) * (1 + meanReversion + momentumEffect + randomShock);
end

% Calculate returns
returns(1) = 0;
for t = 2:T
    returns(t) = (marketPrice(t) - marketPrice(t-1)) / marketPrice(t-1);
end

% Plot results
subplot(3, 1, 1);
plot(time, fundamentalValue, 'b-', time, marketPrice, 'r-', 'LineWidth', 2);
title('Financial Market Model: Price Dynamics');
xlabel('Time (years)');
ylabel('Price');
legend('Fundamental Value', 'Market Price', 'Location', 'best');
grid on;

subplot(3, 1, 2);
plot(time, returns, 'g-', 'LineWidth', 1);
title('Daily Returns');
xlabel('Time (years)');
ylabel('Return');
grid on;

subplot(3, 1, 3);
plot(time, volatility, 'm-', 'LineWidth', 1.5);
title('Volatility');
xlabel('Time (years)');
ylabel('Volatility');
grid on;

% Calculate some key statistics
meanReturn = mean(returns);
stdReturn = std(returns);
sharpeRatio = meanReturn / stdReturn * sqrt(252);  % Annualized Sharpe ratio
maxDrawdown = max(cummax(marketPrice) - marketPrice) / max(marketPrice);

disp('Financial Market Statistics:');
disp(['Mean Daily Return: ' num2str(meanReturn*100) '%']);
disp(['Daily Volatility: ' num2str(stdReturn*100) '%']);
disp(['Sharpe Ratio: ' num2str(sharpeRatio)]);
disp(['Maximum Drawdown: ' num2str(maxDrawdown*100) '%']);

% Task 5: Digital Twin for a Simple Physical System
disp('Task 5: Digital Twin for a Simple Physical System');
figure('Name', 'Task 5: Digital Twin Simulation');

% System definition - a simple water tank with inflow and outflow
% State: water level (m)
% Input: inflow rate (m³/s)
% Disturbance: outflow rate (m³/s)
% Parameters
tankArea = 1.0;    % m²
outflowCoeff = 0.1; % m²/s

% Simulation parameters
T = 200;          % Number of time steps
dt = 0.1;         % Time step (s)
time = (0:T-1)*dt;

% Initialize arrays
actualLevel = zeros(T, 1);
estimatedLevel = zeros(T, 1);
inflowRate = zeros(T, 1);
outflowRate = zeros(T, 1);
measurements = zeros(T, 1);
predictions = zeros(T, 10);  % Store 10-step ahead predictions

% Initial conditions
actualLevel(1) = 0.5;   % Initial water level (m)
estimatedLevel(1) = 0.5; % Initial estimate matches actual

% Kalman filter parameters
processNoise = 0.001;  % State evolution noise
measurementNoise = 0.05; % Measurement noise
estimateCovariance = 0.1; % Initial estimate uncertainty

% Controlled inflow pattern
for t = 1:T
    if t <= T/3
        inflowRate(t) = 0.1;  % Constant inflow
    elseif t <= 2*T/3
        inflowRate(t) = 0.2;  % Increased inflow
    else
        inflowRate(t) = 0.05; % Reduced inflow
    end
    
    % Add random variations to inflow
    inflowRate(t) = max(0, inflowRate(t) + 0.02*randn);
end

% Simulate the system and digital twin
for t = 2:T
    % Actual system dynamics (water tank)
    outflowRate(t-1) = outflowCoeff * sqrt(max(0, actualLevel(t-1)));
    actualLevel(t) = actualLevel(t-1) + ...
                    (inflowRate(t-1) - outflowRate(t-1)) / tankArea * dt + ...
                    sqrt(processNoise) * randn * sqrt(dt);
    
    % Generate noisy measurement
    measurements(t) = actualLevel(t) + sqrt(measurementNoise) * randn;
    
    % Digital twin: Kalman filter for state estimation
    % Prediction step
    predictedLevel = estimatedLevel(t-1) + ...
                     (inflowRate(t-1) - outflowCoeff * sqrt(max(0, estimatedLevel(t-1)))) / tankArea * dt;
    predictedCovariance = estimateCovariance + processNoise * dt;
    
    % Update step
    kalmanGain = predictedCovariance / (predictedCovariance + measurementNoise);
    estimatedLevel(t) = predictedLevel + kalmanGain * (measurements(t) - predictedLevel);
    estimateCovariance = (1 - kalmanGain) * predictedCovariance;
    
    % Make predictions for future states
    if mod(t, 20) == 0 || t == T
        futureLevel = estimatedLevel(t);
        for i = 1:10
            futureInflow = inflowRate(t); % Assume current inflow continues
            futureOutflow = outflowCoeff * sqrt(max(0, futureLevel));
            futureLevel = futureLevel + (futureInflow - futureOutflow) / tankArea * dt;
            predictions(t, i) = futureLevel;
        end
    end
end

% Plot results
subplot(3, 1, 1);
plot(time, actualLevel, 'b-', time, estimatedLevel, 'r--', 'LineWidth', 2);
hold on;
scatter(time, measurements, 10, 'g', 'filled', 'MarkerFaceAlpha', 0.3);
title('Digital Twin: Water Tank Level');
xlabel('Time (s)');
ylabel('Water Level (m)');
legend('Actual Level', 'Estimated Level', 'Measurements', 'Location', 'best');
grid on;

subplot(3, 1, 2);
plot(time, inflowRate, 'b-', time, outflowRate, 'r-', 'LineWidth', 2);
title('Flow Rates');
xlabel('Time (s)');
ylabel('Flow Rate (m³/s)');
legend('Inflow', 'Outflow', 'Location', 'best');
grid on;

subplot(3, 1, 3);
plot(time, actualLevel, 'b-', 'LineWidth', 2);
hold on;

% Plot predictions at specific time points
predictionTimes = 20:20:T;
for i = 1:length(predictionTimes)
    t = predictionTimes(i);
    if t > 0 && any(predictions(t,:) ~= 0)
        predictionHorizon = time(t) + (1:10)*dt;
        plot(predictionHorizon, predictions(t,:), 'g--', 'LineWidth', 1);
    end
end

title('Digital Twin: Predictions');
xlabel('Time (s)');
ylabel('Water Level (m)');
legend('Actual Level', 'Predictions', 'Location', 'best');
grid on;

% Calculate performance metrics
rmseEstimation = sqrt(mean((actualLevel - estimatedLevel).^2));
disp(['RMSE of state estimation: ' num2str(rmseEstimation)]);

%% 8. Advanced Modelling Techniques (Additional Material)
disp('---------------------------------------------------------');
disp('8. Advanced Modelling Techniques');
disp('---------------------------------------------------------');

% Hybrid systems (combining continuous and discrete dynamics)
disp('Hybrid Systems: Bouncing Ball Example');

% Bouncing ball model
g = 9.81;       % Gravity (m/s²)
cor = 0.8;      % Coefficient of restitution
dt = 0.01;      % Time step (s)
tFinal = 5;     % Simulation time (s)
timeSteps = tFinal/dt;

% Initial conditions
position = 10;  % Initial height (m)
velocity = 0;   % Initial velocity (m/s)

% Arrays to store results
positions = zeros(timeSteps, 1);
velocities = zeros(timeSteps, 1);
times = (0:timeSteps-1)*dt;

% Simulate the system
for i = 1:timeSteps
    % Check for bounce
    if position < 0
        position = 0;
        velocity = -cor * velocity;  % Reverse velocity with energy loss
    end
    
    % Store current state
    positions(i) = position;
    velocities(i) = velocity;
    
    % Update state using explicit Euler integration
    velocity = velocity - g*dt;
    position = position + velocity*dt;
end

% Plot results
figure('Name', 'Hybrid System: Bouncing Ball');
subplot(2, 1, 1);
plot(times, positions, 'LineWidth', 2);
title('Bouncing Ball: Position vs Time');
xlabel('Time (s)');
ylabel('Height (m)');
grid on;

subplot(2, 1, 2);
plot(times, velocities, 'LineWidth', 2);
title('Bouncing Ball: Velocity vs Time');
xlabel('Time (s)');
ylabel('Velocity (m/s)');
grid on;

% Stochastic differential equations
disp('Stochastic Differential Equations: Geometric Brownian Motion');

% Parameters for geometric Brownian motion (e.g., stock price model)
mu = 0.05;        % Drift (expected return)
sigma = 0.2;      % Volatility
S0 = 100;         % Initial price
T = 1;            % Time horizon (years)
N = 1000;         % Number of time steps
dt = T/N;         % Time step size
times = (0:N)*dt; % Time points

% Generate multiple realizations
numPaths = 5;
S = zeros(N+1, numPaths);
S(1, :) = S0;

% Simulate paths
for path = 1:numPaths
    dW = sqrt(dt) * randn(N, 1);  % Wiener process increments
    for i = 1:N
        S(i+1, path) = S(i, path) * exp((mu - 0.5*sigma^2)*dt + sigma*dW(i));
    end
end

% Plot results
figure('Name', 'Stochastic Differential Equation: GBM');
plot(times, S, 'LineWidth', 2);
title('Geometric Brownian Motion: Multiple Paths');
xlabel('Time (years)');
ylabel('Stock Price');
grid on;

% Expected value
expectedS = S0 * exp(mu * times');
hold on;
plot(times, expectedS, 'k--', 'LineWidth', 2);
legend(['Path 1', 'Path 2', 'Path 3', 'Path 4', 'Path 5', 'Expected Value'], 'Location', 'best');

disp('Laboratory 4 completed successfully');