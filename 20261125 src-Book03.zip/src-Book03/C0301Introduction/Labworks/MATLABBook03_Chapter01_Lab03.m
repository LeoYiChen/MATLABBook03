%% MATLABBook03_Chapter01_Lab03.m
% Data Analysis Workflow for Multidisciplinary Applications
% This laboratory demonstrates a generic workflow applicable to various domains,
% from economics to signal processing.
%
% MATLAB Roadmap to Applications - Volume III Multidisciplinary Applications
% Chapter 1: Introduction
% Laboratory 3: Data Analysis Workflow
% 
% Version: 1.0
% Date: June 2023
% Author: Dr Leo Chen
% MATLAB Version: R2023a

%% Clear workspace and command window
clear;
clc;
close all;

disp('Laboratory 3: Data Analysis Workflow for Multidisciplinary Applications');
disp('==================================================================');

%% 1. Data Import and Basic Analysis
disp('1. Data Import and Basic Analysis');
disp('---------------------------------------------------------');

% Check if sample data file exists, if not create one
if exist('sample_data.csv', 'file') ~= 2
    % Create synthetic data
    time = (0:0.1:10)';
    signal = sin(time) + 0.2*randn(size(time));
    data = table(time, signal);
    writetable(data, 'sample_data.csv');
    disp('Created sample data file: sample_data.csv');
else
    disp('Using existing sample_data.csv file');
end

% Import data from CSV file
data = readtable('sample_data.csv');
disp('First few rows of imported data:');
disp(head(data));

% Basic analysis
meanValue = mean(data.signal);
stdValue = std(data.signal);
maxValue = max(data.signal);
minValue = min(data.signal);

% Display statistics
disp('Basic Signal Statistics:');
disp(['Mean: ' num2str(meanValue)]);
disp(['Standard Deviation: ' num2str(stdValue)]);
disp(['Maximum: ' num2str(maxValue)]);
disp(['Minimum: ' num2str(minValue)]);

% Visualize the data
figure('Name', 'Imported Data');
plot(data.time, data.signal, 'b-o');
title('Imported Signal Data');
xlabel('Time');
ylabel('Signal');
grid on;

%% 2. Data Preprocessing
disp('---------------------------------------------------------');
disp('2. Data Preprocessing');
disp('---------------------------------------------------------');

% Copy data to preserve original
processedData = data;

% Check for missing values
nMissing = sum(ismissing(processedData.signal));
disp(['Number of missing values: ' num2str(nMissing)]);

% Add some missing values for demonstration
if nMissing == 0
    randomIndices = randperm(height(processedData), 5);
    processedData.signal(randomIndices) = NaN;
    disp('Added 5 missing values for demonstration purposes');
end

% Fill missing values using linear interpolation
processedData.signal = fillmissing(processedData.signal, 'linear');
disp('Filled missing values using linear interpolation');

% Outlier detection using median absolute deviation
medianVal = median(processedData.signal, 'omitnan');
mad = median(abs(processedData.signal - medianVal), 'omitnan');
threshold = 3; % Number of MAD to consider as outlier
outlierIndices = abs(processedData.signal - medianVal) > threshold * mad;
disp(['Detected ' num2str(sum(outlierIndices)) ' outliers']);

% Replace outliers with median
processedData.signal(outlierIndices) = medianVal;
disp('Replaced outliers with median value');

% Smoothing using moving average
windowSize = 5;
processedData.smoothedSignal = movmean(processedData.signal, windowSize);
disp(['Applied smoothing with window size ' num2str(windowSize)]);

% Visualize preprocessing
figure('Name', 'Data Preprocessing');
subplot(2, 1, 1);
plot(data.time, data.signal, 'b-o', 'DisplayName', 'Original');
hold on;
plot(processedData.time, processedData.signal, 'r-*', 'DisplayName', 'Preprocessed');
title('Original vs Preprocessed Data');
xlabel('Time');
ylabel('Signal');
legend('show');
grid on;

subplot(2, 1, 2);
plot(processedData.time, processedData.signal, 'b-', 'DisplayName', 'Preprocessed');
hold on;
plot(processedData.time, processedData.smoothedSignal, 'r-', 'DisplayName', 'Smoothed');
title('Preprocessed vs Smoothed Data');
xlabel('Time');
ylabel('Signal');
legend('show');
grid on;

%% 3. Feature Extraction
disp('---------------------------------------------------------');
disp('3. Feature Extraction');
disp('---------------------------------------------------------');

% Extract time domain features
features = table();
features.mean = mean(processedData.smoothedSignal);
features.std = std(processedData.smoothedSignal);
features.min = min(processedData.smoothedSignal);
features.max = max(processedData.smoothedSignal);
features.range = range(processedData.smoothedSignal);
features.median = median(processedData.smoothedSignal);
features.skewness = skewness(processedData.smoothedSignal);
features.kurtosis = kurtosis(processedData.smoothedSignal);

% Extract zero crossings
signChanges = diff(sign(processedData.smoothedSignal));
features.zeroCrossings = sum(abs(signChanges) > 0) / length(signChanges);

% Extract frequency domain features using FFT
Y = fft(processedData.smoothedSignal);
L = length(processedData.smoothedSignal);
P2 = abs(Y/L);
P1 = P2(1:floor(L/2)+1);
P1(2:end-1) = 2*P1(2:end-1);
f = (0:(L/2))/L;

% Find dominant frequency
[maxP1, maxIdx] = max(P1);
features.dominantFreq = f(maxIdx);
features.dominantAmp = maxP1;

% Calculate spectral centroid
features.spectralCentroid = sum(f .* P1) / sum(P1);

% Display extracted features
disp('Extracted Features:');
disp(features);

% Visualize features in frequency domain
figure('Name', 'Feature Extraction');
subplot(2, 1, 1);
plot(f, P1);
hold on;
scatter(features.dominantFreq, features.dominantAmp, 100, 'r', 'filled');
title('Frequency Domain Features');
xlabel('Frequency');
ylabel('Amplitude');
grid on;
text(features.dominantFreq + 0.02, features.dominantAmp, ...
     ['Dominant Frequency: ' num2str(features.dominantFreq)], 'FontSize', 10);

% Visualize time-domain statistical features
subplot(2, 1, 2);
bar(table2array(features(:,1:8)));
title('Time Domain Statistical Features');
xticklabels(features.Properties.VariableNames(1:8));
xtickangle(45);
grid on;

%% 4. Model Building and Evaluation
disp('---------------------------------------------------------');
disp('4. Model Building and Evaluation');
disp('---------------------------------------------------------');

% Create a simple model to predict the signal based on time
% Let's use a Fourier series model
order = 3;  % Order of Fourier series
X = ones(height(processedData), 1);
for n = 1:order
    X = [X, sin(n*2*pi*processedData.time), cos(n*2*pi*processedData.time)];
end

% Fit model
y = processedData.smoothedSignal;
beta = X \ y;

% Make predictions
yHat = X * beta;

% Evaluate model
errors = y - yHat;
rmse = sqrt(mean(errors.^2));
mae = mean(abs(errors));
r2 = 1 - sum(errors.^2)/sum((y - mean(y)).^2);

% Display model metrics
disp('Model Performance Metrics:');
disp(['RMSE: ' num2str(rmse)]);
disp(['MAE: ' num2str(mae)]);
disp(['R²: ' num2str(r2)]);

% Visualize model fit
figure('Name', 'Model Fitting');
subplot(2, 1, 1);
plot(processedData.time, y, 'b-', 'DisplayName', 'Actual');
hold on;
plot(processedData.time, yHat, 'r-', 'DisplayName', 'Predicted');
title(['Model Fit (R² = ' num2str(r2, '%.4f') ')']);
xlabel('Time');
ylabel('Signal');
legend('show');
grid on;

% Plot residuals
subplot(2, 1, 2);
stem(processedData.time, errors);
hold on;
plot([min(processedData.time), max(processedData.time)], [0, 0], 'r--');
title(['Residuals (RMSE = ' num2str(rmse, '%.4f') ')']);
xlabel('Time');
ylabel('Error');
grid on;

%% 5. Forecasting and Simulation
disp('---------------------------------------------------------');
disp('5. Forecasting and Simulation');
disp('---------------------------------------------------------');

% Extend time for prediction
forecastHorizon = 5;  % 5 time units ahead
newTime = (max(processedData.time)+0.1:0.1:max(processedData.time)+forecastHorizon)';

% Create feature matrix for new time points
Xnew = ones(length(newTime), 1);
for n = 1:order
    Xnew = [Xnew, sin(n*2*pi*newTime), cos(n*2*pi*newTime)];
end

% Make predictions
newPredictions = Xnew * beta;

% Visualize forecasts
figure('Name', 'Forecasting');
plot(processedData.time, y, 'b-', 'DisplayName', 'Historical Data');
hold on;
plot(processedData.time, yHat, 'g-', 'DisplayName', 'Model Fit');
plot(newTime, newPredictions, 'r--', 'DisplayName', 'Forecast');
title('Time Series Forecasting');
xlabel('Time');
ylabel('Signal');
legend('show');
grid on;

% Add vertical line at current time
xline(max(processedData.time), 'k-', 'Present', 'LineWidth', 1.5);

%% 6. Tasks
disp('---------------------------------------------------------');
disp('6. Tasks for Practice');
disp('---------------------------------------------------------');
disp('Task 1: Import a time series dataset and identify trend, seasonality, and noise components');
disp('Task 2: Perform frequency domain analysis using the Fast Fourier Transform');
disp('Task 3: Create a moving window analysis to detect local patterns and anomalies');
disp('Task 4: Fit a simple model to the data and evaluate its performance');
disp('Task 5: Create a workflow that automatically processes and analyses new data as it becomes available');

%% 7. Solutions to Tasks
disp('---------------------------------------------------------');
disp('7. Solutions to Tasks');
disp('---------------------------------------------------------');

% Generate sample time series data with known components
n = 1000;
t = (1:n)';
trend = 0.01 * t;
seasonality1 = 2 * sin(2*pi*t/50);   % Period of 50
seasonality2 = 1 * cos(2*pi*t/120);  % Period of 120
noise = 0.5 * randn(size(t));
timeSeries = trend + seasonality1 + seasonality2 + noise;

% Task 1: Decompose time series into components
disp('Task 1: Time Series Decomposition');
figure('Name', 'Time Series Decomposition');

% Plot original time series
subplot(5, 1, 1);
plot(t, timeSeries);
title('Original Time Series');
xlabel('Time');
ylabel('Value');
grid on;

% Extract and plot trend using moving average
windowSize = 100;
extractedTrend = movmean(timeSeries, windowSize);
subplot(5, 1, 2);
plot(t, extractedTrend);
title('Extracted Trend (Moving Average)');
xlabel('Time');
ylabel('Value');
grid on;

% Remove trend to get seasonality + noise
detrended = timeSeries - extractedTrend;
subplot(5, 1, 3);
plot(t, detrended);
title('Detrended Series (Seasonality + Noise)');
xlabel('Time');
ylabel('Value');
grid on;

% Extract seasonality using STL decomposition or simple filtering
% We'll use a simple low-pass filter here
windowSize = 10;
extractedSeasonal = movmean(detrended, windowSize);
subplot(5, 1, 4);
plot(t, extractedSeasonal);
title('Extracted Seasonality');
xlabel('Time');
ylabel('Value');
grid on;

% Extract residuals (noise)
residuals = detrended - extractedSeasonal;
subplot(5, 1, 5);
plot(t, residuals);
title('Residuals (Noise)');
xlabel('Time');
ylabel('Value');
grid on;

% Task 2: Frequency domain analysis using FFT
disp('Task 2: Frequency Domain Analysis');
figure('Name', 'Frequency Domain Analysis');

% Compute the FFT
Y = fft(detrended);
P2 = abs(Y/n);
P1 = P2(1:n/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f = (0:(n/2))/n;  % Normalized frequency

% Plot the single-sided amplitude spectrum
subplot(2, 1, 1);
plot(f, P1);
title('Single-Sided Amplitude Spectrum');
xlabel('Normalized Frequency');
ylabel('|Y(f)|');
grid on;

% Zoom in to see the peaks
subplot(2, 1, 2);
plot(f(1:200), P1(1:200));
title('Zoomed Amplitude Spectrum');
xlabel('Normalized Frequency');
ylabel('|Y(f)|');
grid on;
[peakValues, peakIndices] = findpeaks(P1(1:200), 'MinPeakHeight', max(P1(1:200))/5);
hold on;
plot(f(peakIndices), peakValues, 'ro', 'MarkerSize', 10);
for i = 1:length(peakIndices)
    frequency = f(peakIndices(i));
    period = 1/frequency;
    text(frequency, peakValues(i), ['Period ≈ ' num2str(round(period))], ...
         'VerticalAlignment', 'bottom');
end

% Task 3: Moving window analysis
disp('Task 3: Moving Window Analysis');
figure('Name', 'Moving Window Analysis');

% Calculate moving statistics
windowSize = 50;
movingMean = movmean(timeSeries, windowSize);
movingStd = movstd(timeSeries, windowSize);
movingMax = movmax(timeSeries, windowSize);
movingMin = movmin(timeSeries, windowSize);

% Plot the original data with moving statistics
subplot(2, 1, 1);
plot(t, timeSeries, 'b-', 'LineWidth', 1);
hold on;
plot(t, movingMean, 'r-', 'LineWidth', 2);
plot(t, movingMean + 2*movingStd, 'g--');
plot(t, movingMean - 2*movingStd, 'g--');
title('Moving Window Statistics');
xlabel('Time');
ylabel('Value');
legend('Original', 'Moving Mean', '±2σ Bounds', 'Location', 'best');
grid on;

% Detect and plot anomalies (points outside 3-sigma bounds)
subplot(2, 1, 2);
anomalyIndices = abs(timeSeries - movingMean) > 3*movingStd;
plot(t, timeSeries, 'b-', 'LineWidth', 1);
hold on;
plot(t(anomalyIndices), timeSeries(anomalyIndices), 'ro', 'MarkerSize', 8);
title('Anomaly Detection');
xlabel('Time');
ylabel('Value');
legend('Time Series', 'Anomalies', 'Location', 'best');
grid on;
disp(['Number of anomalies detected: ' num2str(sum(anomalyIndices))]);

% Task 4: Model fitting and evaluation
disp('Task 4: Model Fitting and Evaluation');
figure('Name', 'Model Fitting and Evaluation');

% Create feature matrix for linear regression
X = [ones(size(t)), t, sin(2*pi*t/50), cos(2*pi*t/50), ...
     sin(2*pi*t/120), cos(2*pi*t/120)];

% Fit linear regression model
beta = X \ timeSeries;
predictions = X * beta;

% Plot results
subplot(2, 1, 1);
plot(t, timeSeries, 'b.', 'MarkerSize', 3);
hold on;
plot(t, predictions, 'r-', 'LineWidth', 2);
title('Model Fitting');
xlabel('Time');
ylabel('Value');
legend('Data', 'Model', 'Location', 'best');
grid on;

% Evaluate model performance
residuals = timeSeries - predictions;
mse = mean(residuals.^2);
rmse = sqrt(mse);
mae = mean(abs(residuals));
r2 = 1 - sum(residuals.^2)/sum((timeSeries - mean(timeSeries)).^2);

% Display metrics
disp('Model Performance Metrics:');
disp(['MSE: ' num2str(mse)]);
disp(['RMSE: ' num2str(rmse)]);
disp(['MAE: ' num2str(mae)]);
disp(['R²: ' num2str(r2)]);

% Plot residuals
subplot(2, 1, 2);
plot(t, residuals, 'b-');
hold on;
plot([min(t), max(t)], [0, 0], 'k--');
title('Model Residuals');
xlabel('Time');
ylabel('Residual');
grid on;

% Task 5: Automated analysis workflow
disp('Task 5: Automated Analysis Workflow');
% Simulate new data arriving in chunks
initialData = timeSeries(1:500);
newDataChunks = {timeSeries(501:600), timeSeries(601:700), ...
                timeSeries(701:800), timeSeries(801:900), ...
                timeSeries(901:end)};

% Create a processNewData function
fprintf('Setting up automated workflow for processing new data chunks...\n');

% Demonstrate workflow with first chunk
currentData = initialData;
chunkIndex = 1;
fprintf('Processing data chunk %d of %d...\n', chunkIndex, length(newDataChunks));
newData = newDataChunks{chunkIndex};

% Process the first chunk as demonstration
% Combine existing and new data
combinedData = [currentData; newData];
combinedTime = (1:length(combinedData))';

% Update model with combined data
X = [ones(size(combinedTime)), combinedTime, sin(2*pi*combinedTime/50), cos(2*pi*combinedTime/50), ...
     sin(2*pi*combinedTime/120), cos(2*pi*combinedTime/120)];
beta = X \ combinedData;

% Make predictions with updated model
predictions = X * beta;

% Calculate metrics
residuals = combinedData - predictions;
rmse = sqrt(mean(residuals.^2));
r2 = 1 - sum(residuals.^2)/sum((combinedData - mean(combinedData)).^2);

% Plot updated results
figure('Name', 'Online Data Processing Demonstration');
plot(combinedTime, combinedData, 'b.', 'MarkerSize', 3);
hold on;
plot(combinedTime, predictions, 'r-', 'LineWidth', 2);
newStart = length(initialData) + 1;
xline(newStart, 'g--', 'LineWidth', 2);
title(['Updated Model After New Data - RMSE: ' num2str(rmse)]);
xlabel('Time');
ylabel('Value');
legend('Data', 'Model', 'New Data Start', 'Location', 'best');
grid on;

fprintf('Automated workflow demonstration completed.\n');
fprintf('In a real application, this would continue with each new data chunk.\n');

disp('Laboratory 3 completed successfully');