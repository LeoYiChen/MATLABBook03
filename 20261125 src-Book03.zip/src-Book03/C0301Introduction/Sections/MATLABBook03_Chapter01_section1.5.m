%% MATLABBook03_Chapter01_section1.5.m
% Key Themes and Cross-Cutting Methodologies in MATLAB
% This script demonstrates the common methodological approaches that appear
% across different application domains in MATLAB.
%
% MATLAB Roadmap to Applications - Volume III Multidisciplinary Applications
% Chapter 1: Introduction
% Section 1.5: Key Themes and Cross-Cutting Methodologies
% 
% Version: 1.0
% Date: June 2023
% Author: Dr Leo Chen
% MATLAB Version: R2023a

%% Clear workspace and set random seed for reproducibility
clear;
clc;
close all;
rng(42);

%% 1.5.1 Data-Centric Approaches
% Demonstrating how data processing workflows appear across disciplines

% Generate a sample dataset (could represent signals, financial data, sensor readings, etc.)
sampleSize = 1000;
time = linspace(0, 10, sampleSize)';
% Add various components to simulate real-world data
trend = 0.2 * time;
seasonality = 2 * sin(2*pi*time/2);
noise = 1.5 * randn(sampleSize, 1);
outliers = zeros(sampleSize, 1);
outlierIndices = randperm(sampleSize, 10);
outliers(outlierIndices) = 10 * randn(10, 1);

rawData = trend + seasonality + noise + outliers;

% Create a figure to demonstrate the data-centric workflow
figure('Name', 'Data-Centric Approaches Across Disciplines', 'Position', [100, 100, 1000, 600]);

% Step 1: Raw Data Visualization
subplot(2, 3, 1);
plot(time, rawData, 'b-');
title('1. Raw Data');
xlabel('Time');
ylabel('Value');
grid on;

% Step 2: Data Cleaning (outlier removal)
subplot(2, 3, 2);
% Simple outlier detection and removal
zScores = abs((rawData - mean(rawData)) / std(rawData));
outliersMask = zScores > 3;
cleanData = rawData;
cleanData(outliersMask) = NaN;
plot(time, rawData, 'b.', 'MarkerSize', 8);
hold on;
plot(time, cleanData, 'g-', 'LineWidth', 1.5);
plot(time(outliersMask), rawData(outliersMask), 'rx', 'MarkerSize', 10, 'LineWidth', 2);
title('2. Data Cleaning');
xlabel('Time');
ylabel('Value');
legend('Raw Data', 'Cleaned Data', 'Outliers', 'Location', 'northwest');
grid on;

% Step 3: Feature Extraction
subplot(2, 3, 3);
% Fill NaN values for further processing
filledData = fillmissing(cleanData, 'linear');
% Use moving averages of different windows to extract features
shortTermMA = movmean(filledData, 10);
longTermMA = movmean(filledData, 100);
% Plot the extracted features
plot(time, filledData, 'b-', 'LineWidth', 0.5);
hold on;
plot(time, shortTermMA, 'g-', 'LineWidth', 1.5);
plot(time, longTermMA, 'r-', 'LineWidth', 2);
title('3. Feature Extraction');
xlabel('Time');
ylabel('Value');
legend('Cleaned Data', 'Short-term Trend', 'Long-term Trend', 'Location', 'northwest');
grid on;

% Step 4: Analysis & Modeling
subplot(2, 3, 4);
% Create a simple linear model
X = [ones(sampleSize, 1), time, sin(2*pi*time/2), cos(2*pi*time/2)];
beta = X \ filledData;
modelFit = X * beta;
% Plot the data and model
plot(time, filledData, 'b.', 'MarkerSize', 4);
hold on;
plot(time, modelFit, 'r-', 'LineWidth', 2);
title('4. Analysis & Modeling');
xlabel('Time');
ylabel('Value');
legend('Data', 'Model Fit', 'Location', 'northwest');
grid on;
% Add model equation
residuals = filledData - modelFit;
rSquared = 1 - sum(residuals.^2) / sum((filledData - mean(filledData)).^2);
modelEqn = sprintf('y = %.2f + %.2ft + %.2fsin(πt) + %.2fcos(πt)\nR² = %.3f', ...
                  beta(1), beta(2), beta(3), beta(4), rSquared);
text(0.5, max(filledData)-2, modelEqn, 'FontSize', 8, 'BackgroundColor', [0.9 0.9 0.9]);

% Step 5: Prediction
subplot(2, 3, 5);
% Extend time for prediction
futurePeriod = 3;
futureTime = linspace(10, 10+futurePeriod, sampleSize*futurePeriod/10)';
% Create prediction matrix
XFuture = [ones(length(futureTime), 1), futureTime, sin(2*pi*futureTime/2), cos(2*pi*futureTime/2)];
predictions = XFuture * beta;
% Plot historical data and predictions
plot(time, filledData, 'b-', 'LineWidth', 1);
hold on;
plot(futureTime, predictions, 'r--', 'LineWidth', 2);
title('5. Prediction');
xlabel('Time');
ylabel('Value');
legend('Historical Data', 'Predictions', 'Location', 'northwest');
grid on;
% Add vertical line at current time
line([10, 10], ylim, 'Color', 'k', 'LineStyle', '--', 'LineWidth', 1);
text(10.1, max(ylim)-1, 'Present', 'FontSize', 8);

% Step 6: Insight Generation & Visualization
subplot(2, 3, 6);
% Create a more insightful visualization combining multiple aspects
% Plot historical data and predictions
plot(time, filledData, 'b-', 'LineWidth', 1, 'Alpha', 0.5);
hold on;
plot(futureTime, predictions, 'r--', 'LineWidth', 2);
% Add prediction intervals (simplified)
predictionStd = std(residuals);
upperBound = predictions + 1.96 * predictionStd;
lowerBound = predictions - 1.96 * predictionStd;
fill([futureTime; flipud(futureTime)], ...
     [upperBound; flipud(lowerBound)], ...
     'r', 'FaceAlpha', 0.2, 'EdgeColor', 'none');
% Add annotations
maxPoint = max(filledData);
maxIdx = find(filledData == maxPoint, 1);
plot(time(maxIdx), maxPoint, 'ro', 'MarkerSize', 10, 'LineWidth', 2);
text(time(maxIdx)+0.3, maxPoint, 'Peak Value', 'FontSize', 8);
% Add trend indicators
averageTrend = beta(2);
trendText = 'Upward Trend';
if averageTrend < 0
    trendText = 'Downward Trend';
elseif abs(averageTrend) < 0.05
    trendText = 'Stable Trend';
end
text(5, min(filledData)+1, ['Trend Analysis: ' trendText], ...
     'FontSize', 10, 'BackgroundColor', [0.9 0.9 0.9]);
title('6. Insight Generation');
xlabel('Time');
ylabel('Value');
legend('Historical Data', 'Predictions', '95% Prediction Interval', 'Location', 'northwest');
grid on;

% Add overall title
sgtitle('Data-Centric Approach: Common Workflow Across Disciplines');

%% 1.5.2 Visualization as Insight Generation
% Demonstrating how visualization techniques apply across disciplines

figure('Name', 'Visualization Techniques Across Disciplines', 'Position', [100, 100, 1000, 600]);

% Generate sample data for visualization
[X, Y] = meshgrid(linspace(-3, 3, 50), linspace(-3, 3, 50));
Z = peaks(50);  % Using MATLAB's peaks function for interesting data

% Basic Visualization Techniques
subplot(2, 3, 1);
contour(X, Y, Z);
title('Contour Plot');
xlabel('X');
ylabel('Y');
colorbar;
grid on;
text(-2.8, 2.8, 'Used in: Geography,\nPhysics, Engineering', ...
     'FontSize', 8, 'BackgroundColor', [0.9 0.9 0.9]);

subplot(2, 3, 2);
surf(X, Y, Z);
title('Surface Plot');
xlabel('X');
ylabel('Y');
zlabel('Z');
text(-3, -3, 5, 'Used in: Material Science,\nFinance, Bioinformatics', ...
     'FontSize', 8, 'BackgroundColor', [0.9 0.9 0.9]);

subplot(2, 3, 3);
imagesc(Z);
title('Image/Heatmap');
xlabel('X Index');
ylabel('Y Index');
colorbar;
axis equal;
text(5, 5, 'Used in: Image Processing,\nRemote Sensing, Medicine', ...
     'FontSize', 8, 'BackgroundColor', [0.9 0.9 0.9], 'Color', 'w');

% Advanced Visualization Techniques
subplot(2, 3, 4);
% Vector field visualization
[u, v] = gradient(Z);
quiver(X, Y, u, v);
title('Vector Field');
xlabel('X');
ylabel('Y');
grid on;
text(-2.8, 2.8, 'Used in: Fluid Dynamics,\nElectromagnetics, Economics', ...
     'FontSize', 8, 'BackgroundColor', [0.9 0.9 0.9]);

subplot(2, 3, 5);
% Create a scatter plot with multiple dimensions encoded
x = X(:);
y = Y(:);
z = Z(:);
[~, sortIdx] = sort(z);  % Sort by z value for better visualization
scatter(x(sortIdx), y(sortIdx), 30, z(sortIdx), 'filled');
title('Multidimensional Visualization');
xlabel('X');
ylabel('Y');
colorbar;
grid on;
text(-2.8, 2.8, 'Used in: Data Science,\nSocial Sciences, Biology', ...
     'FontSize', 8, 'BackgroundColor', [0.9 0.9 0.9]);

subplot(2, 3, 6);
% 3D streamlines
[sx, sy] = meshgrid(linspace(-3, 3, 10), linspace(-3, 3, 10));
streamline(X, Y, u, v, sx, sy);
title('Streamlines/Flow Visualization');
xlabel('X');
ylabel('Y');
grid on;
text(-2.8, 2.8, 'Used in: Aerodynamics,\nWeather Modeling, Transportation', ...
     'FontSize', 8, 'BackgroundColor', [0.9 0.9 0.9]);

% Add overall title
sgtitle('Visualization Techniques Apply Across Different Disciplines');

%% 1.5.3 Model-Based Design
% Demonstrate model-based design approach across disciplines

figure('Name', 'Model-Based Design Across Disciplines', 'Position', [100, 100, 1000, 600]);

% Simple pendulum model (physics/mechanical engineering)
subplot(2, 2, 1);
% Pendulum parameters
g = 9.81;  % Gravity (m/s^2)
L = 1.0;   % Length (m)
m = 1.0;   % Mass (kg)

% Pendulum differential equation: d^2θ/dt^2 + (g/L)*sin(θ) = 0
% For small angles: d^2θ/dt^2 + (g/L)*θ = 0

% Time vector
t = linspace(0, 10, 1000);
% Initial conditions: θ(0) = π/6, dθ/dt(0) = 0
theta0 = pi/6;
omega0 = 0;

% Analytical solution for small angles
theta_linear = theta0 * cos(sqrt(g/L) * t);

% Numerical solution for the full nonlinear equation
[t_nonlin, y_nonlin] = ode45(@(t, y) [y(2); -g/L*sin(y(1))], t, [theta0; omega0]);

% Plot both solutions
plot(t, theta_linear, 'b-', t_nonlin, y_nonlin(:,1), 'r--', 'LineWidth', 2);
title('Physical System Model (Pendulum)');
xlabel('Time (s)');
ylabel('Angle (rad)');
legend('Linear Model', 'Nonlinear Model', 'Location', 'best');
grid on;
text(0.5, -0.4, 'Used in: Physics, Mechanical Engineering, Robotics', ...
     'FontSize', 8, 'BackgroundColor', [0.9 0.9 0.9]);

% Economic model (economics/finance)
subplot(2, 2, 2);
% Simple predator-prey model for market dynamics
% dX/dt = a*X - b*X*Y
% dY/dt = -c*Y + d*X*Y
% where X is prey (e.g., buyers) and Y is predator (e.g., sellers)

% Parameters
a = 1.1;  % Growth rate of buyers
b = 0.4;  % Rate at which sellers reduce buyers
c = 0.4;  % Death rate of sellers
d = 0.1;  % Growth rate of sellers due to buyers

% Time vector
t = linspace(0, 40, 1000);
% Initial conditions
X0 = 2;
Y0 = 1;

% Solve the differential equations
[t_pp, y_pp] = ode45(@(t, y) [a*y(1) - b*y(1)*y(2); -c*y(2) + d*y(1)*y(2)], t, [X0; Y0]);

% Plot the results
plot(t_pp, y_pp(:,1), 'b-', t_pp, y_pp(:,2), 'r-', 'LineWidth', 2);
title('Economic System Model (Market Dynamics)');
xlabel('Time');
ylabel('Population');
legend('Buyers', 'Sellers', 'Location', 'best');
grid on;
text(2, 0.5, 'Used in: Economics, Finance, Resource Management', ...
     'FontSize', 8, 'BackgroundColor', [0.9 0.9 0.9]);

% Control system model (engineering/automation)
subplot(2, 2, 3);
% Simple PID control system
s = tf('s');
% Plant transfer function (e.g., motor)
G = 1/(s^2 + 0.5*s + 1);

% PID controller
Kp = 2;
Ki = 1;
Kd = 1;
C = Kp + Ki/s + Kd*s;

% Closed-loop system
sys_cl = feedback(C*G, 1);

% Step response
t = 0:0.1:15;
[y, t] = step(sys_cl, t);

% Plot the response
plot(t, y, 'b-', 'LineWidth', 2);
title('Control System Model (PID Controller)');
xlabel('Time');
ylabel('Output');
grid on;
% Add step reference
hold on;
plot([0, max(t)], [1, 1], 'r--', 'LineWidth', 1);
legend('System Response', 'Reference', 'Location', 'best');
text(8, 0.4, 'Used in: Control Engineering, Automation, Robotics', ...
     'FontSize', 8, 'BackgroundColor', [0.9 0.9 0.9]);

% Biological system model (biology/medicine)
subplot(2, 2, 4);
% Simple SIR epidemiology model
% dS/dt = -β*S*I
% dI/dt = β*S*I - γ*I
% dR/dt = γ*I

% Parameters
beta = 0.3;   % Infection rate
gamma = 0.1;  % Recovery rate

% Time vector
t = linspace(0, 50, 1000);
% Initial conditions (99% susceptible, 1% infected, 0% recovered)
S0 = 0.99;
I0 = 0.01;
R0 = 0;

% Solve the differential equations
[t_sir, y_sir] = ode45(@(t, y) [-beta*y(1)*y(2); beta*y(1)*y(2) - gamma*y(2); gamma*y(2)], ...
                      t, [S0; I0; R0]);

% Plot the results
plot(t_sir, y_sir(:,1), 'b-', t_sir, y_sir(:,2), 'r-', t_sir, y_sir(:,3), 'g-', 'LineWidth', 2);
title('Biological System Model (Epidemic)');
xlabel('Time (days)');
ylabel('Population Fraction');
legend('Susceptible', 'Infected', 'Recovered', 'Location', 'best');
grid on;
text(30, 0.8, 'Used in: Epidemiology, Biology, Healthcare', ...
     'FontSize', 8, 'BackgroundColor', [0.9 0.9 0.9]);

% Add overall title
sgtitle('Model-Based Design: Similar Approaches Across Different Systems');

%% 1.5.4 Machine Learning Integration
% Demonstrate how machine learning approaches are applied across disciplines

figure('Name', 'Machine Learning Integration Across Disciplines', 'Position', [100, 100, 1000, 600]);

% Generate sample data for ML examples
rng(123);  % For reproducibility

% Classification example (e.g., medical diagnosis, fault detection)
subplot(2, 2, 1);
% Generate two classes of data
nPoints = 100;
class1 = mvnrnd([1, 1], [0.5, 0.3; 0.3, 0.5], nPoints);
class2 = mvnrnd([3, 3], [0.6, 0; 0, 0.6], nPoints);
X = [class1; class2];
y = [zeros(nPoints, 1); ones(nPoints, 1)];

% Train a simple classifier
mdl = fitcsvm(X, y, 'KernelFunction', 'rbf', 'Standardize', true);

% Create a grid to visualize the decision boundary
[x1Grid, x2Grid] = meshgrid(linspace(min(X(:,1))-0.5, max(X(:,1))+0.5, 100), ...
                          linspace(min(X(:,2))-0.5, max(X(:,2))+0.5, 100));
xGrid = [x1Grid(:), x2Grid(:)];
[~, scores] = predict(mdl, xGrid);

% Plot the data and decision boundary
contourf(x1Grid, x2Grid, reshape(scores(:,2), size(x1Grid)), [0 0], 'LineWidth', 2);
hold on;
scatter(class1(:,1), class1(:,2), 50, 'b', 'filled', 'MarkerFaceAlpha', 0.5);
scatter(class2(:,1), class2(:,2), 50, 'r', 'filled', 'MarkerFaceAlpha', 0.5);
colormap('gray');
title('Classification (SVM)');
xlabel('Feature 1');
ylabel('Feature 2');
legend('Decision Boundary', 'Class 1', 'Class 2', 'Location', 'best');
text(0, 4, 'Used in: Medical Diagnosis, Quality Control,\nSecurity, Image Recognition', ...
     'FontSize', 8, 'BackgroundColor', [0.9 0.9 0.9]);

% Regression example (e.g., property prediction, forecasting)
subplot(2, 2, 2);
% Generate nonlinear data with noise
x = linspace(0, 10, 200)';
y_true = sin(x) .* exp(-0.1 * x);
y_noisy = y_true + 0.1 * randn(size(y_true));

% Train a neural network for regression
inputs = x';
targets = y_noisy';
hiddenLayerSize = 10;
net = fitnet(hiddenLayerSize);
net.divideParam.trainRatio = 0.7;
net.divideParam.valRatio = 0.15;
net.divideParam.testRatio = 0.15;
[net, ~] = train(net, inputs, targets);

% Generate predictions
y_pred = net(inputs)';

% Plot the results
plot(x, y_noisy, 'b.', 'MarkerSize', 8);
hold on;
plot(x, y_true, 'g-', 'LineWidth', 1.5);
plot(x, y_pred, 'r-', 'LineWidth', 2);
title('Regression (Neural Network)');
xlabel('Input Variable');
ylabel('Output Variable');
legend('Noisy Data', 'True Function', 'NN Prediction', 'Location', 'best');
grid on;
text(0.5, -0.8, 'Used in: Financial Forecasting, Engineering,\nMaterial Science, Healthcare', ...
     'FontSize', 8, 'BackgroundColor', [0.9 0.9 0.9]);

% Clustering example (e.g., customer segmentation, image segmentation)
subplot(2, 2, 3);
% Generate clustered data
nClusters = 4;
nPointsPerCluster = 50;
centers = [1 1; 5 1; 3 5; 7 4];
X = [];
for i = 1:nClusters
    X = [X; mvnrnd(centers(i,:), eye(2)*0.5, nPointsPerCluster)];
end

% Apply k-means clustering
[idx, centroids] = kmeans(X, nClusters);

% Plot the clusters
gscatter(X(:,1), X(:,2), idx, 'brgm', 'o+*x', 8);
hold on;
plot(centroids(:,1), centroids(:,2), 'k*', 'MarkerSize', 15, 'LineWidth', 2);
title('Clustering (K-means)');
xlabel('Feature 1');
ylabel('Feature 2');
legend('Cluster 1', 'Cluster 2', 'Cluster 3', 'Cluster 4', 'Centroids', 'Location', 'best');
grid on;
text(0.5, 6, 'Used in: Market Segmentation, Image Processing,\nBioinformatics, Social Network Analysis', ...
     'FontSize', 8, 'BackgroundColor', [0.9 0.9 0.9]);

% Time series prediction (e.g., stock prices, weather, energy consumption)
subplot(2, 2, 4);
% Generate a time series with multiple components
t = linspace(0, 5, 500)';
trend = 0.1 * t;
seasonality = 0.5 * sin(2*pi*t) + 0.3 * cos(4*pi*t);
noise = 0.2 * randn(size(t));
ts = trend + seasonality + noise;

% Create lagged inputs for time series prediction
laggedData = zeros(length(ts)-3, 3);
for i = 1:3
    laggedData(:,i) = ts(i:end-3+i-1);
end
targets = ts(4:end);

% Train a simple linear regression model
mdl = fitlm(laggedData, targets);

% Make predictions
predictions = predict(mdl, laggedData);

% Plot the results
plot(t(4:end), ts(4:end), 'b-', 'LineWidth', 1);
hold on;
plot(t(4:end), predictions, 'r-', 'LineWidth', 2);
title('Time Series Prediction');
xlabel('Time');
ylabel('Value');
legend('Actual', 'Predicted', 'Location', 'best');
grid on;
text(0.2, max(ts), 'Used in: Financial Forecasting, Weather Prediction,\nEnergy Management, Supply Chain', ...
     'FontSize', 8, 'BackgroundColor', [0.9 0.9 0.9]);

% Add overall title
sgtitle('Machine Learning Integration Across Disciplines');

disp('Section 1.5 script completed successfully.');