%% MATLABBook03_Chapter01_section1.2.m
% MATLAB as a Platform for Multidisciplinary Applications
% This script demonstrates how MATLAB serves as a common platform across different
% disciplines through its ability to handle various data types and problems.
%
% MATLAB Roadmap to Applications - Volume III Multidisciplinary Applications
% Chapter 1: Introduction
% Section 1.2: MATLAB as a Platform for Multidisciplinary Applications
% 
% Version: 1.0
% Date: June 2023
% Author: Dr Leo Chen
% MATLAB Version: R2023a

%% 1.2.1 Different Data Types Across Disciplines
% Demonstrating how MATLAB handles data from various disciplines

% Clear workspace and set random seed for reproducibility
clear;
clc;
rng(42);

% Create a figure to visualize different data types
figure('Name', 'MATLAB as a Cross-Disciplinary Platform', 'Position', [100, 100, 1000, 800]);

%% Time Series Data (e.g., Economics, Engineering, Earth Sciences)
% Generate time series with trend, seasonality, and noise
nPoints = 500;
t = (1:nPoints)';
trend = 0.05 * t;
seasonality = 2 * sin(2*pi*t/50);
cycle = 1.5 * cos(2*pi*t/100);
noise = 0.5 * randn(size(t));

timeSeries = trend + seasonality + cycle + noise;

% Plot the time series
subplot(3, 2, 1);
plot(t, timeSeries, 'b-');
hold on;
plot(t, trend, 'r--', 'LineWidth', 1.5);
title('Time Series Data');
xlabel('Time');
ylabel('Value');
legend('Observed Data', 'Trend', 'Location', 'northwest');
grid on;
text(nPoints*0.7, min(timeSeries), 'Used in: Economics, Engineering,\nEarth Sciences, Finance', ...
     'BackgroundColor', [0.9 0.9 0.9], 'EdgeColor', 'k');

%% Image Data (e.g., Medical Imaging, Remote Sensing, Computer Vision)
% Load a sample image (or create one)
subplot(3, 2, 2);
try
    % Try to load a built-in image
    boatImage = imread('peppers.png');
    imshow(boatImage);
    title('Image Data');
catch
    % If the image isn't available, create a synthetic one
    [X, Y] = meshgrid(linspace(-8, 8, 200));
    R = sqrt(X.^2 + Y.^2) + eps;
    Z = sin(R)./R;
    imagesc(Z);
    colormap('gray');
    axis equal;
    axis off;
    title('Image Data (Synthetic)');
end
text(10, 180, 'Used in: Medical Imaging, Remote Sensing,\nComputer Vision, Material Science', ...
     'BackgroundColor', [0.9 0.9 0.9], 'EdgeColor', 'k', 'Color', 'k');

%% Spatial Data (e.g., Geography, Environmental Science, Urban Planning)
% Generate a 2D spatial dataset with patterns
subplot(3, 2, 3);
[X, Y] = meshgrid(linspace(-3, 3, 100), linspace(-3, 3, 100));
ZBase = 3*exp(-X.^2 - Y.^2);
ZFeatures = 1.5*exp(-(X-1.5).^2 - (Y-1.5).^2) + exp(-(X+2).^2 - (Y+1).^2);
ZNoise = 0.1 * randn(size(X));
Z = ZBase + ZFeatures + ZNoise;

% Plot the spatial data as a contour map
contourf(X, Y, Z, 20);
title('Spatial Data');
xlabel('X Coordinate');
ylabel('Y Coordinate');
colormap('jet');
colorbar;
text(-2.8, 2.8, 'Used in: Geography, Environmental Science,\nUrban Planning, Archaeology', ...
     'BackgroundColor', [0.9 0.9 0.9], 'EdgeColor', 'k');

%% Network Data (e.g., Social Sciences, Communications, Biological Networks)
subplot(3, 2, 4);
% Create a simple network/graph
nNodes = 20;
% Create random node positions
nodePositions = 10*rand(nNodes, 2);
% Create random connections (adjacency matrix)
adjacencyMatrix = rand(nNodes) < 0.15;
adjacencyMatrix = triu(adjacencyMatrix, 1) + triu(adjacencyMatrix, 1)';  % Make symmetric
% Make sure no self-connections
for i = 1:nNodes
    adjacencyMatrix(i, i) = 0;
end

% Plot the network
gplot(adjacencyMatrix, nodePositions, '-');
hold on;
scatter(nodePositions(:,1), nodePositions(:,2), 100, 'filled', 'MarkerFaceColor', 'b');
title('Network Data');
axis([0 10 0 10]);
axis square;
text(0.5, 9.5, 'Used in: Social Sciences, Communications,\nBiological Networks, Transportation', ...
     'BackgroundColor', [0.9 0.9 0.9], 'EdgeColor', 'k');
axis off;

%% Multivariate Data (e.g., Social Sciences, Biomedical, Materials Science)
% Generate multivariate data with correlations
subplot(3, 2, 5);
nSamples = 200;
nVariables = 4;

% Create correlation structure
correlationMatrix = [1.0, 0.7, 0.3, -0.2;
                     0.7, 1.0, 0.6,  0.0;
                     0.3, 0.6, 1.0,  0.4;
                    -0.2, 0.0, 0.4,  1.0];
                   
% Cholesky decomposition to generate correlated data
L = chol(correlationMatrix, 'lower');
uncorrelatedData = randn(nSamples, nVariables);
multivariateData = uncorrelatedData * L;

% Add different means and scales
means = [10, 25, 100, 5];
scales = [2, 5, 15, 1];
for i = 1:nVariables
    multivariateData(:,i) = multivariateData(:,i) * scales(i) + means(i);
end

% Create a scatter plot matrix
plotmatrix(multivariateData);
title('Multivariate Data');
text(15, 100, 'Used in: Social Sciences, Biomedical,\nMaterials Science, Economics', ...
     'BackgroundColor', [0.9 0.9 0.9], 'EdgeColor', 'k');

%% Mixed Data Types (e.g., Robotics, Healthcare, Smart Cities)
subplot(3, 2, 6);

% Create a mixed visualization showing how MATLAB can integrate
% multiple data types in a single application

% Base spatial data
[X, Y] = meshgrid(linspace(0, 10, 50));
Z = 0.1 * (X - 5).^2 + 0.1 * (Y - 5).^2;  % Simple terrain
contourf(X, Y, Z, 10);
hold on;

% Add a path (like a robot trajectory)
path = [1, 1; 2, 3; 4, 5; 7, 6; 9, 8];
plot(path(:,1), path(:,2), 'r-', 'LineWidth', 3);

% Add points representing sensors/data collection
sensorLocs = [2, 2; 5, 5; 8, 3];
scatter(sensorLocs(:,1), sensorLocs(:,2), 100, 'filled', 'MarkerFaceColor', 'g');

% Add time series data at one location
xOffset = 6;
yOffset = 2;
tLocal = linspace(0, 2*pi, 50);
signal = 0.5 * sin(tLocal) + 0.2;
plot(xOffset + signal, yOffset + tLocal/pi, 'b-', 'LineWidth', 2);

title('Multi-Domain Integration');
text(0.5, 9.5, 'Used in: Robotics, Healthcare, Smart Cities,\nDigital Twins, Industry 4.0', ...
     'BackgroundColor', [0.9 0.9 0.9], 'EdgeColor', 'k');
xlabel('X Coordinate');
ylabel('Y Coordinate');
colormap('jet');

%% 1.2.2 Cross-Disciplinary Tool Integration Example
figure('Name', 'MATLAB as an Integration Platform');

% Create a simulated workflow showing how different domain tools integrate
subplot(1,1,1);
% This is a conceptual diagram
axis([0 10 0 10]);
axis square;
hold on;

% Draw the central MATLAB hub
rectangle('Position', [4, 4, 2, 2], 'Curvature', [1 1], ...
          'FaceColor', [0.8, 0.8, 1], 'EdgeColor', 'b', 'LineWidth', 2);
text(5, 5, 'MATLAB', 'HorizontalAlignment', 'center', 'FontSize', 14, 'FontWeight', 'bold');

% Draw the connected tools/domains
toolPositions = [
    2, 8;    % Image Processing
    8, 8;    % Statistics
    9, 5;    % Machine Learning
    8, 2;    % Signal Processing
    2, 2;    % Control Systems
    1, 5;    % Hardware Interface
];

toolNames = {
    'Image Processing';
    'Statistics';
    'Machine Learning';
    'Signal Processing';
    'Control Systems';
    'Hardware Interface';
};

% Draw each tool and connect to MATLAB
for i = 1:length(toolNames)
    % Draw the tool box
    rectangle('Position', [toolPositions(i,1)-1, toolPositions(i,2)-0.5, 2, 1], ...
              'Curvature', [0.2 0.2], 'FaceColor', [1, 0.9, 0.8], 'EdgeColor', 'k');
    % Add the name
    text(toolPositions(i,1), toolPositions(i,2), toolNames{i}, ...
         'HorizontalAlignment', 'center', 'FontSize', 10);
    % Connect to MATLAB
    line([5, toolPositions(i,1)], [5, toolPositions(i,2)], 'Color', 'k', 'LineStyle', '-', 'LineWidth', 1.5);
end

% Add a title and explanation
title('MATLAB as a Cross-Disciplinary Integration Platform');
text(5, 0.5, 'MATLAB serves as a central hub connecting specialized tools and methods across disciplines', ...
     'HorizontalAlignment', 'center', 'FontSize', 12);

axis off;

disp('Section 1.2 script completed successfully.');