%% MATLABBook03_Chapter01_section1.1.m
% Demonstrating the Evolution and Impact of MATLAB
% This script showcases the fundamental capabilities that made MATLAB influential
% across disciplines: matrix operations, visualization, and data analysis.
%
% MATLAB Roadmap to Applications - Volume III Multidisciplinary Applications
% Chapter 1: Introduction
% Section 1.1: The Evolution and Impact of MATLAB
% 
% Version: 1.0
% Date: June 2023
% Author: Dr Leo Chen
% MATLAB Version: R2023a

%% 1.1.1 Matrix Operations - The Foundation of MATLAB
% Demonstrating the matrix operations that formed the original core of MATLAB
% and remain fundamental to all disciplines using MATLAB

% Create matrices
A = [1 2 3; 4 5 6; 7 8 9];
B = [9 8 7; 6 5 4; 3 2 1];

% Basic matrix operations
sumMatrix = A + B;
productMatrix = A * B;
elementProduct = A .* B;

% Display results
disp('Matrix A:');
disp(A);
disp('Matrix B:');
disp(B);
disp('Matrix Sum (A + B):');
disp(sumMatrix);
disp('Matrix Product (A * B):');
disp(productMatrix);
disp('Element-wise Product (A .* B):');
disp(elementProduct);

% Advanced matrix operations (added in later versions of MATLAB)
disp('Matrix determinant:');
disp(det(A));
disp('Matrix eigenvalues:');
disp(eig(A));
disp('Matrix singular value decomposition:');
[U, S, V] = svd(A);
disp('U:'); disp(U);
disp('S:'); disp(S);
disp('V:'); disp(V);

%% 1.1.2 Visualization Capabilities - Making Data Meaningful
% MATLAB's plotting capabilities have been a key factor in its adoption

% Generate sample data
x = linspace(0, 2*pi, 100);
y1 = sin(x);
y2 = cos(x);

% Create a simple 2D plot
figure('Name', 'MATLAB Visualization Evolution');
subplot(2, 2, 1);
plot(x, y1, 'b-', x, y2, 'r--', 'LineWidth', 2);
title('Basic Line Plot (1980s)');
xlabel('x (radians)');
ylabel('Amplitude');
legend('sin(x)', 'cos(x)', 'Location', 'best');
grid on;

% Create a 3D plot
subplot(2, 2, 2);
[X, Y] = meshgrid(linspace(-2, 2, 20), linspace(-2, 2, 20));
Z = sin(sqrt(X.^2 + Y.^2)) ./ (sqrt(X.^2 + Y.^2) + eps);
mesh(X, Y, Z);
title('3D Mesh Plot (1990s)');
xlabel('X');
ylabel('Y');
zlabel('Z');

% Create a modern visualization
subplot(2, 2, 3);
[X, Y] = meshgrid(linspace(-3, 3, 50), linspace(-3, 3, 50));
Z = 3*exp(-X.^2 - Y.^2);
surf(X, Y, Z, 'EdgeColor', 'none');
title('Modern Surface Plot (2000s)');
xlabel('X');
ylabel('Y');
zlabel('Z');
colormap('jet');
colorbar;

% Create an advanced visualization
subplot(2, 2, 4);
t = linspace(0, 4*pi, 100);
x = 16*sin(t).^3;
y = 13*cos(t) - 5*cos(2*t) - 2*cos(3*t) - cos(4*t);
scatter(x, y, 36, t, 'filled');
title('Advanced Visualization (2010s+)');
xlabel('X');
ylabel('Y');
colormap('parula');
colorbar;
axis equal;

%% 1.1.3 Data Analysis Evolution
% Simple to increasingly sophisticated data analysis capabilities

% Generate sample data with trend, seasonality, and noise
n = 200;
t = (1:n)';
trend = 0.05 * t;
seasonality = 2 * sin(2*pi*t/50);
noise = 0.5 * randn(size(t));
timeSeries = trend + seasonality + noise;

% Simple statistical analysis (early MATLAB)
meanValue = mean(timeSeries);
stdValue = std(timeSeries);
maxValue = max(timeSeries);
minValue = min(timeSeries);

figure('Name', 'MATLAB Data Analysis Evolution');
subplot(2, 2, 1);
plot(t, timeSeries, 'b-');
hold on;
plot([1, n], [meanValue, meanValue], 'r--', 'LineWidth', 2);
title('Basic Statistics (1980s)');
legend('Time Series', 'Mean', 'Location', 'northwest');
grid on;

% Time series decomposition (1990s-2000s)
subplot(2, 2, 2);
estimatedTrend = movmean(timeSeries, 50);
detrended = timeSeries - estimatedTrend;
plot(t, timeSeries, 'b-', t, estimatedTrend, 'r-', 'LineWidth', 2);
title('Trend Analysis (1990s-2000s)');
legend('Original', 'Trend', 'Location', 'northwest');
grid on;

% Frequency domain analysis
subplot(2, 2, 3);
Y = fft(detrended);
L = length(detrended);
P2 = abs(Y/L);
P1 = P2(1:floor(L/2)+1);
P1(2:end-1) = 2*P1(2:end-1);
f = (0:(L/2))/L;
plot(f, P1);
title('Fourier Analysis (2000s)');
xlabel('Frequency (cycles/sample)');
ylabel('Magnitude');
xlim([0 0.1]);
grid on;

% Modern machine learning integration
subplot(2, 2, 4);
% Simple linear regression model
X = [ones(size(t)), t, sin(2*pi*t/50), cos(2*pi*t/50)];
beta = X \ timeSeries;
predicted = X * beta;
plot(t, timeSeries, 'b.', t, predicted, 'r-', 'LineWidth', 2);
title('Model-Based Analysis (2010s+)');
xlabel('Time');
ylabel('Value');
legend('Data', 'Model Fit', 'Location', 'northwest');
grid on;

% Print summary statistics
fprintf('\nEvolution of MATLAB Data Analysis Capabilities:\n');
fprintf('Basic Statistics (1980s):\n');
fprintf('  Mean: %.4f\n', meanValue);
fprintf('  Standard Deviation: %.4f\n', stdValue);
fprintf('  Range: %.4f to %.4f\n', minValue, maxValue);

fprintf('\nModel Performance (Modern MATLAB):\n');
residuals = timeSeries - predicted;
fprintf('  R-squared: %.4f\n', 1 - sum(residuals.^2)/sum((timeSeries-mean(timeSeries)).^2));
fprintf('  RMSE: %.4f\n', sqrt(mean(residuals.^2)));

disp('Section 1.1 script completed successfully.');