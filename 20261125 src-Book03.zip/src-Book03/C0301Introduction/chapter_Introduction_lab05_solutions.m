%% chapter_Introduction_lab05_solutions.m
% Solutions to machine learning tasks.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0301Introduction/
% Listing label         : chapter_Introduction_lab05_solutions
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Common dataset for multiple tasks - Create synthetic multidisciplinary data
% This could represent various scenarios: medical data, sensor readings, etc.
rng(42);  % For reproducibility
nSamples = 1000;

% Generate features
X1 = randn(nSamples, 5);  % 5 informative features
X2 = 0.1*randn(nSamples, 5);  % 5 noise features
X = [X1, X2];

% Generate target variables for different tasks
% Classification target (binary)
yClass = (X1(:,1) + X1(:,2) > 0);
% Regression target (continuous)
yReg = 2*X1(:,1) - 1.5*X1(:,2) + 0.5*X1(:,3).^2 + 0.5*randn(nSamples, 1);

% Task 1: Classification, Regression, and Clustering
figure('Name', 'Multiple ML Tasks on Same Dataset');

% Part A: Classification
% Split data
cv = cvpartition(nSamples, 'Holdout', 0.3);
idxTrain = training(cv);
idxTest = test(cv);
XTrain = X(idxTrain, :);
yClassTrain = yClass(idxTrain);
XTest = X(idxTest, :);
yClassTest = yClass(idxTest);

% Train classification model (decision tree)
classTree = fitctree(XTrain, yClassTrain);

% Make predictions
yClassPred = predict(classTree, XTest);

% Calculate accuracy
accuracy = sum(yClassPred == yClassTest) / length(yClassTest);

% Plot confusion matrix
subplot(2, 2, 1);
confusionchart(yClassTest, yClassPred);
title(['Classification Accuracy: ' num2str(accuracy*100, '%.1f') '%']);

% Part B: Regression
% Use same train/test split
yRegTrain = yReg(idxTrain);
yRegTest = yReg(idxTest);

% Train regression model
regTree = fitrtree(XTrain, yRegTrain);

% Make predictions
yRegPred = predict(regTree, XTest);

% Calculate RMSE
rmse = sqrt(mean((yRegTest - yRegPred).^2));

% Plot results
subplot(2, 2, 2);
scatter(yRegTest, yRegPred, 20, 'filled');
hold on;
plot([-10, 10], [-10, 10], 'r--', 'LineWidth', 2);
title(['Regression - RMSE: ' num2str(rmse, '%.3f')]);
xlabel('True Values');
ylabel('Predicted Values');
grid on;
axis equal;

% Part C: Clustering
% PCA for visualisation
[~, score] = pca(X);
X2D = score(:, 1:2);

% K-means clustering
k = 3;
[idx, centroids] = kmeans(X, k);

% Plot clusters
subplot(2, 2, 3);
gscatter(X2D(:, 1), X2D(:, 2), idx, 'bgr', 'o+*', 8);
hold on;
% Project centroids to 2*D space
centroidsPCA = centroids * pca_coeffs(:, 1:2);
scatter(centroidsPCA(:, 1), centroidsPCA(:, 2), 200, 'k', 'x', 'LineWidth', 3);
title('K-means Clustering (k=3)');
xlabel('Principal Component 1');
ylabel('Principal Component 2');
grid on;

% Task 2: Feature Selection and Dimensionality Reduction
figure('Name', 'Feature Selection and Dimensionality Reduction');

% Part A: Feature Importance from Decision Tree
subplot(2, 2, 1);
importance = predictorImportance(classTree);
bar(importance);
title('Feature Importance (Decision Tree)');
xlabel('Feature Index');
ylabel('Importance Score');
xticks(1:10);
grid on;

% Identify important features
[~, sortedIndices] = sort(importance, 'descend');
topFeatures = sortedIndices(1:5);
disp('Top features by importance:');
disp(topFeatures);

% Part B: Principal Component Analysis (PCA)
[coeff, score, latent] = pca(X);

% Plot variance explained
subplot(2, 2, 2);
pareto(latent / sum(latent) * 100);
title('PCA: Variance Explained');
xlabel('Principal Component');
ylabel('Variance Explained (%)');
grid on;

% Determine number of components for 90% variance
explainedVariance = cumsum(latent) / sum(latent);
numComponentsFor90 = find(explainedVariance >= 0.9, 1);
disp(['Number of PCs for 90% variance: ' num2str(numComponentsFor90)]);

% Part C: Compare model performance with feature selection
% Train and evaluate with all features
fullModelTree = fitctree(XTrain, yClassTrain);
fullModelPred = predict(fullModelTree, XTest);
fullModelAccuracy = sum(fullModelPred == yClassTest) / length(yClassTest);

% Train and evaluate with only top features
topFeatTree = fitctree(XTrain(:, topFeatures), yClassTrain);
topFeatPred = predict(topFeatTree, XTest(:, topFeatures));
topFeatAccuracy = sum(topFeatPred == yClassTest) / length(yClassTest);

% Train and evaluate with PCA features
numPCs = numComponentsFor90;
pcaTree = fitctree(score(idxTrain, 1:numPCs), yClassTrain);
pcaPred = predict(pcaTree, score(idxTest, 1:numPCs));
pcaAccuracy = sum(pcaPred == yClassTest) / length(yClassTest);

% Compare results
subplot(2, 2, 3);
bar([fullModelAccuracy, topFeatAccuracy, pcaAccuracy]);
title('Model Accuracy Comparison');
xticklabels({'All Features', 'Top Features', 'PCA'});
ylabel('Accuracy');
ylim([0, 1]);
grid on;

% Part D: Feature selection for regression
% Full model
fullRegTree = fitrtree(XTrain, yRegTrain);
fullRegPred = predict(fullRegTree, XTest);
fullRegRMSE = sqrt(mean((yRegTest - fullRegPred).^2));

% Top features model
topRegTree = fitrtree(XTrain(:, topFeatures), yRegTrain);
topRegPred = predict(topRegTree, XTest(:, topFeatures));
topRegRMSE = sqrt(mean((yRegTest - topRegPred).^2));

% PCA model
pcaRegTree = fitrtree(score(idxTrain, 1:numPCs), yRegTrain);
pcaRegPred = predict(pcaRegTree, score(idxTest, 1:numPCs));
pcaRegRMSE = sqrt(mean((yRegTest - pcaRegPred).^2));

% Compare results
subplot(2, 2, 4);
bar([fullRegRMSE, topRegRMSE, pcaRegRMSE]);
title('Regression RMSE Comparison');
xticklabels({'All Features', 'Top Features', 'PCA'});
ylabel('RMSE');
grid on;

% Task 3: Algorithm Comparison
figure('Name', 'Algorithm Comparison');

% Classification algorithms to compare
% 1. Decision Tree
treeModel = fitctree(XTrain, yClassTrain);
treePred = predict(treeModel, XTest);
treeAccuracy = sum(treePred == yClassTest) / length(yClassTest);

% 2. SVM
svmModel = fitcsvm(XTrain, yClassTrain, 'KernelFunction', 'rbf', 'Standardize', true);
svmPred = predict(svmModel, XTest);
svmAccuracy = sum(svmPred == yClassTest) / length(yClassTest);

% 3. Naive Bayes
nbModel = fitcnb(XTrain, yClassTrain);
nbPred = predict(nbModel, XTest);
nbAccuracy = sum(nbPred == yClassTest) / length(yClassTest);

% 4. KNN
knnModel = fitcknn(XTrain, yClassTrain, 'NumNeighbors', 5);
knnPred = predict(knnModel, XTest);
knnAccuracy = sum(knnPred == yClassTest) / length(yClassTest);

% 5. Ensemble (AdaBoost)
ensModel = fitcensemble(XTrain, yClassTrain, 'Method', 'AdaBoostM1');
ensPred = predict(ensModel, XTest);
ensAccuracy = sum(ensPred == yClassTest) / length(yClassTest);

% Compare classification accuracies
subplot(2, 1, 1);
algorithms = {'Decision Tree', 'SVM', 'Naive Bayes', 'KNN', 'AdaBoost'};
accuracies = [treeAccuracy, svmAccuracy, nbAccuracy, knnAccuracy, ensAccuracy];
bar(accuracies);
title('Classification Algorithm Comparison');
xticks(1:5);
xticklabels(algorithms);
ylabel('Accuracy');
ylim([0, 1]);
grid on;

% Add text labels above bars
for i = 1:length(accuracies)
    text(i, accuracies(i) + 0.02, [num2str(accuracies(i)*100, '%.1f') '%'], ...
         'HorizontalAlignment', 'center');
end

% Regression algorithms to compare
% 1. Linear Regression
lmModel = fitlm(XTrain, yRegTrain);
lmPred = predict(lmModel, XTest);
lmRMSE = sqrt(mean((yRegTest - lmPred).^2));

% 2. Decision Tree
treeRegModel = fitrtree(XTrain, yRegTrain);
treeRegPred = predict(treeRegModel, XTest);
treeRegRMSE = sqrt(mean((yRegTest - treeRegPred).^2));

% 3. SVR
svrModel = fitrlinear(XTrain, yRegTrain);
svrPred = predict(svrModel, XTest);
svrRMSE = sqrt(mean((yRegTest - svrPred).^2));

% 4. Gaussian Process Regression
gpModel = fitrgp(XTrain, yRegTrain, 'BasisFunction', 'constant', ...
                'KernelFunction', 'ardsquaredexponential');
gpPred = predict(gpModel, XTest);
gpRMSE = sqrt(mean((yRegTest - gpPred).^2));

% 5. Ensemble (Bagging)
bagModel = fitrensemble(XTrain, yRegTrain, 'Method', 'Bag');
bagPred = predict(bagModel, XTest);
bagRMSE = sqrt(mean((yRegTest - bagPred).^2));

% Compare regression RMSEs
subplot(2, 1, 2);
regAlgorithms = {'Linear', 'Decision Tree', 'SVR', 'Gaussian Process', 'Bagging'};
rmses = [lmRMSE, treeRegRMSE, svrRMSE, gpRMSE, bagRMSE];
bar(rmses);
title('Regression Algorithm Comparison');
xticks(1:5);
xticklabels(regAlgorithms);
ylabel('RMSE (lower is better)');
grid on;

% Add text labels above bars
for i = 1:length(rmses)
    text(i, rmses(i) + 0.05, num2str(rmses(i), '%.3f'), ...
         'HorizontalAlignment', 'center');
end

% Task 4: Anomaly Detection for Time Series
figure('Name', 'Time Series Anomaly Detection');

% Generate synthetic time series with anomalies
n = 1000;
t = (1:n)';
normalPattern = 3*sin(2*pi*t/100) + 0.5*sin(2*pi*t/10) + 0.1*randn(n, 1);

% Insert anomalies
anomalyIndices = [150, 400, 450, 451, 452, 700, 701, 900];
anomalies = zeros(n, 1);
anomalies(anomalyIndices) = 4 * randn(length(anomalyIndices), 1);
timeSeries = normalPattern + anomalies;

% 1. Method: Z-score based detection
windowSize = 20;
zScores = zeros(size(timeSeries));
for i = windowSize+1:n
    window = timeSeries(i-windowSize:i-1);
    zScores(i) = (timeSeries(i) - mean(window)) / std(window);
end

% Detect anomalies (points with |z-score| > 3)
anomalyMask1 = abs(zScores) > 3;

% 2. Method: Isolation Forest
% Prepare features (lagged values)
numLags = 5;
X_if = zeros(n-numLags, numLags);
for i = 1:numLags
    X_if(:, i) = timeSeries(i:n-numLags+i-1);
end

% Train isolation forest
contaminationLevel = length(anomalyIndices)/(n-numLags); % Estimated anomaly ratio
iforest = fitensemble(X_if, ones(size(X_if, 1), 1), 'Method', 'Bag', ...
                     'NumLearningCycles', 100, 'Learners', 'tree');

% Calculate anomaly scores
scores = anomalyScores(iforest, X_if);
threshold = prctile(scores, 100*(1-contaminationLevel));
anomalyMask2 = [false(numLags, 1); scores > threshold];

% 3. Method: One-class SVM
% Train one-class SVM
svmModel = fitcsvm(X_if, ones(size(X_if, 1), 1), 'KernelFunction', 'rbf', ...
                  'Nu', contaminationLevel, 'OutlierFraction', contaminationLevel);

% Predict anomalies
[~, scoresSVM] = predict(svmModel, X_if);
anomalyMask3 = [false(numLags, 1); scoresSVM(:, 2) > 0];

% Plot results
subplot(4, 1, 1);
plot(t, timeSeries, 'b-', 'LineWidth', 1);
hold on;
scatter(t(anomalyIndices), timeSeries(anomalyIndices), 100, 'r', 'x', 'LineWidth', 2);
title('Time Series with Known Anomalies');
xlabel('Time');
ylabel('Value');
legend('Time Series', 'True Anomalies', 'Location', 'best');
grid on;

subplot(4, 1, 2);
plot(t, timeSeries, 'b-', 'LineWidth', 1);
hold on;
scatter(t(anomalyMask1), timeSeries(anomalyMask1), 100, 'g', 'o', 'LineWidth', 2);
title('Z-Score Based Anomaly Detection');
xlabel('Time');
ylabel('Value');
legend('Time Series', 'Detected Anomalies', 'Location', 'best');
grid on;

subplot(4, 1, 3);
plot(t, timeSeries, 'b-', 'LineWidth', 1);
hold on;
scatter(t(anomalyMask2), timeSeries(anomalyMask2), 100, 'g', 'o', 'LineWidth', 2);
title('Isolation Forest Based Anomaly Detection');
xlabel('Time');
ylabel('Value');
legend('Time Series', 'Detected Anomalies', 'Location', 'best');
grid on;

subplot(4, 1, 4);
plot(t, timeSeries, 'b-', 'LineWidth', 1);
hold on;
scatter(t(anomalyMask3), timeSeries(anomalyMask3), 100, 'g', 'o', 'LineWidth', 2);
title('One-Class SVM Based Anomaly Detection');
xlabel('Time');
ylabel('Value');
legend('Time Series', 'Detected Anomalies', 'Location', 'best');
grid on;

% Calculate metrics for each method
truePos1 = sum(anomalyMask1(anomalyIndices));
falsePos1 = sum(anomalyMask1) - truePos1;
truePos2 = sum(anomalyMask2(anomalyIndices));
falsePos2 = sum(anomalyMask2) - truePos2;
truePos3 = sum(anomalyMask3(anomalyIndices));
falsePos3 = sum(anomalyMask3) - truePos3;

precision1 = truePos1 / (truePos1 + falsePos1);
recall1 = truePos1 / length(anomalyIndices);
precision2 = truePos2 / (truePos2 + falsePos2);
recall2 = truePos2 / length(anomalyIndices);
precision3 = truePos3 / (truePos3 + falsePos3);
recall3 = truePos3 / length(anomalyIndices);

disp('Anomaly Detection Method Comparison:');
disp(['Z-Score: Precision = ' num2str(precision1*100, '%.1f') '%, Recall = ' num2str(recall1*100, '%.1f') '%']);
disp(['Isolation Forest: Precision = ' num2str(precision2*100, '%.1f') '%, Recall = ' num2str(recall2*100, '%.1f') '%']);
disp(['One-Class SVM: Precision = ' num2str(precision3*100, '%.1f') '%, Recall = ' num2str(recall3*100, '%.1f') '%']);
