%% chapter_Introduction_lab02_basic.m
% Basic plotting in MATLAB.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0301Introduction/
% Listing label         : chapter_Introduction_lab02_basic
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Generate sample data
x = linspace(0, 2*pi, 100);
y1 = sin(x);
y2 = cos(x);
y3 = sin(x) .* cos(x);

% Create a simple 2*D plot
figure;
plot(x, y1, 'b-', x, y2, 'r--', 'LineWidth', 2);
title('Sine and Cosine Functions');
xlabel('x (radians)');
ylabel('Amplitude');
legend('sin(x)', 'cos(x)', 'Location', 'best');
grid on;
