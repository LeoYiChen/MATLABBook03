%% chapter_Introduction_lab04_basic.m
% Basic model definition and simulation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0301Introduction/
% Listing label         : chapter_Introduction_lab04_basic
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Define a simple linear model
A = [0.9, 0.1; 0, 0.8];  % System matrix
B = [0; 1];              % Input matrix
C = [1, 0];              % Output matrix
D = 0;                   % Feedthrough matrix

% Create state-space model
sys = ss(A, B, C, D, 0.1);  % 0.1 is the sample time

% Simulate the system response to an input
t = 0:0.1:10;
u = ones(size(t));  % Step input
[y, t, x] = lsim(sys, u, t, [0; 0]);  % Simulate with zero initial state

% Plot the results
figure;
subplot(2, 1, 1);
plot(t, u, 'r-', 'LineWidth', 2);
title('Input Signal');
xlabel('Time (s)');
ylabel('Amplitude');
grid on;

subplot(2, 1, 2);
plot(t, y, 'b-', 'LineWidth', 2);
title('System Response');
xlabel('Time (s)');
ylabel('Amplitude');
grid on;
