%% chapter_Introduction_lab01_solutions.m
% Solutions to matrix operations tasks.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0301Introduction/
% Listing label         : chapter_Introduction_lab01_solutions
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Task 1: Create a 4*x4 matrix with random integers
randomMatrix = randi(10, 4, 4);
disp('Random 4*x4 matrix:');
disp(randomMatrix);

% Task 2: Calculate determinant and eigenvalues
detValue = det(randomMatrix);
eigenvalues = eig(randomMatrix);
disp('Determinant:');
disp(detValue);
disp('Eigenvalues:');
disp(eigenvalues);

% Task 3: Solve system of linear equations
b = ones(4, 1);
x = randomMatrix \ b;  % More efficient than inv(randomMatrix) * b
disp('Solution to Ax = b:');
disp(x);
disp('Verification (should be close to b):');
disp(randomMatrix * x);

% Task 4: Create a sparse matrix
sparseSize = 1000;
i = randi(sparseSize, 100, 1);  % Row indices
j = randi(sparseSize, 100, 1);  % Column indices
values = rand(100, 1);          % Values
sparseMatrix = sparse(i, j, values, sparseSize, sparseSize);
disp('Sparse matrix properties:');
disp(['Size: ' num2str(size(sparseMatrix, 1)) 'x' num2str(size(sparseMatrix, 2))]);
disp(['Number of non-zeros: ' num2str(nnz(sparseMatrix))]);
disp(['Sparsity: ' num2str(1 - nnz(sparseMatrix)/(sparseSize^2))]);

% Task 5: Matrix factorisation
[L, U, P] = lu(randomMatrix);
[Q, R] = qr(randomMatrix);
disp('LU Decomposition verification (should be close to randomMatrix):');
disp(P' * L * U);
disp('QR Decomposition verification (should be close to randomMatrix):');
disp(Q * R);
