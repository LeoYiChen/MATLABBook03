%% chapter_Introduction_lab03_solutions.m
% Solutions to data analysis tasks.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0301Introduction/
% Listing label         : chapter_Introduction_lab03_solutions
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Generate sample time series data with known components
n = 1000;
t = (1:n)';
trend = 0.01 * t;
seasonality1 = 2 * sin(2*pi*t/50);   % Period of 50
seasonality2 = 1 * cos(2*pi*t/120);  % Period of 120
noise = 0.5 * randn(size(t));
timeSeries = trend + seasonality1 + seasonality2 + noise;

% Task 1: Decompose time series into components
figure('Name', 'Time Series Decomposition');

% Plot original time series
subplot(5, 1, 1);
plot(t, timeSeries);
title('Original Time Series');
xlabel('Time');
ylabel('Value');
grid on;

% Extract and plot trend using moving average
windowSize = 100;
extractedTrend = movmean(timeSeries, windowSize);
subplot(5, 1, 2);
plot(t, extractedTrend);
title('Extracted Trend (Moving Average)');
xlabel('Time');
ylabel('Value');
grid on;

% Remove trend to get seasonality + noise
detrended = timeSeries - extractedTrend;
subplot(5, 1, 3);
plot(t, detrended);
title('Detrended Series (Seasonality + Noise)');
xlabel('Time');
ylabel('Value');
grid on;

% Extract seasonality using STL decomposition or simple filtering
% We'll use a simple low-pass filter here
windowSize = 10;
extractedSeasonal = movmean(detrended, windowSize);
subplot(5, 1, 4);
plot(t, extractedSeasonal);
title('Extracted Seasonality');
xlabel('Time');
ylabel('Value');
grid on;

% Extract residuals (noise)
residuals = detrended - extractedSeasonal;
subplot(5, 1, 5);
plot(t, residuals);
title('Residuals (Noise)');
xlabel('Time');
ylabel('Value');
grid on;

% Task 2: Frequency domain analysis using FFT
figure('Name', 'Frequency Domain Analysis');

% Compute the FFT
Y = fft(detrended);
P2 = abs(Y/n);
P1 = P2(1:n/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f = (0:(n/2))/n;  % Normalized frequency

% Plot the single-sided amplitude spectrum
subplot(2, 1, 1);
plot(f, P1);
title('Single-Sided Amplitude Spectrum');
xlabel('Normalized Frequency');
ylabel('|Y(f)|');
grid on;

% Zoom in to see the peaks
subplot(2, 1, 2);
plot(f(1:200), P1(1:200));
title('Zoomed Amplitude Spectrum');
xlabel('Normalized Frequency');
ylabel('|Y(f)|');
grid on;
[peakValues, peakIndices] = findpeaks(P1(1:200), 'MinPeakHeight', max(P1(1:200))/5);
hold on;
plot(f(peakIndices), peakValues, 'ro', 'MarkerSize', 10);
for i = 1:length(peakIndices)
    frequency = f(peakIndices(i));
    period = 1/frequency;
    text(frequency, peakValues(i), ['Period ¡Ö ' num2str(round(period))], ...
         'VerticalAlignment', 'bottom');
end

% Task 3: Moving window analysis
figure('Name', 'Moving Window Analysis');

% Calculate moving statistics
windowSize = 50;
movingMean = movmean(timeSeries, windowSize);
movingStd = movstd(timeSeries, windowSize);
movingMax = movmax(timeSeries, windowSize);
movingMin = movmin(timeSeries, windowSize);

% Plot the original data with moving statistics
subplot(2, 1, 1);
plot(t, timeSeries, 'b-', 'LineWidth', 1);
hold on;
plot(t, movingMean, 'r-', 'LineWidth', 2);
plot(t, movingMean + 2*movingStd, 'g--');
plot(t, movingMean - 2*movingStd, 'g--');
title('Moving Window Statistics');
xlabel('Time');
ylabel('Value');
legend('Original', 'Moving Mean', '¡À2¦Ò Bounds', 'Location', 'best');
grid on;

% Detect and plot anomalies (points outside 3-sigma bounds)
subplot(2, 1, 2);
anomalyIndices = abs(timeSeries - movingMean) > 3*movingStd;
plot(t, timeSeries, 'b-', 'LineWidth', 1);
hold on;
plot(t(anomalyIndices), timeSeries(anomalyIndices), 'ro', 'MarkerSize', 8);
title('Anomaly Detection');
xlabel('Time');
ylabel('Value');
legend('Time Series', 'Anomalies', 'Location', 'best');
grid on;
disp(['Number of anomalies detected: ' num2str(sum(anomalyIndices))]);

% Task 4: Model fitting and evaluation
figure('Name', 'Model Fitting and Evaluation');

% Create feature matrix for linear regression
X = [ones(size(t)), t, sin(2*pi*t/50), cos(2*pi*t/50), ...
     sin(2*pi*t/120), cos(2*pi*t/120)];

% Fit linear regression model
beta = X \ timeSeries;
predictions = X * beta;

% Plot results
subplot(2, 1, 1);
plot(t, timeSeries, 'b.', 'MarkerSize', 3);
hold on;
plot(t, predictions, 'r-', 'LineWidth', 2);
title('Model Fitting');
xlabel('Time');
ylabel('Value');
legend('Data', 'Model', 'Location', 'best');
grid on;

% Evaluate model performance
residuals = timeSeries - predictions;
mse = mean(residuals.^2);
rmse = sqrt(mse);
mae = mean(abs(residuals));
r2 = 1 - sum(residuals.^2)/sum((timeSeries - mean(timeSeries)).^2);

% Display metrics
disp('Model Performance Metrics:');
disp(['MSE: ' num2str(mse)]);
disp(['RMSE: ' num2str(rmse)]);
disp(['MAE: ' num2str(mae)]);
disp(['R?: ' num2str(r2)]);

% Plot residuals
subplot(2, 1, 2);
plot(t, residuals, 'b-');
hold on;
plot([min(t), max(t)], [0, 0], 'k--');
title('Model Residuals');
xlabel('Time');
ylabel('Residual');
grid on;

% Task 5: Automated analysis workflow
% Simulate new data arriving in chunks
initialData = timeSeries(1:500);
newDataChunks = {timeSeries(501:600), timeSeries(601:700), ...
                timeSeries(701:800), timeSeries(801:900), ...
                timeSeries(901:end)};

% Create a function to process new data

% Simulate online processing of new data chunks
currentData = initialData;
for i = 1:length(newDataChunks)
    disp(['Processing data chunk ' num2str(i)]);
    currentData = processNewData(currentData, newDataChunks{i});
    pause(1);  % Pause to see each update
end

% Local functions (moved to end so this listing is a valid MATLAB script)
function processNewData(existingData, newData)
    % Combine existing and new data
    combinedData = [existingData; newData];
    
    % Update model with combined data
    t = (1:length(combinedData))';
    X = [ones(size(t)), t, sin(2*pi*t/50), cos(2*pi*t/50), ...
         sin(2*pi*t/120), cos(2*pi*t/120)];
    beta = X \ combinedData;
    
    % Make predictions with updated model
    predictions = X * beta;
    
    % Calculate metrics
    residuals = combinedData - predictions;
    rmse = sqrt(mean(residuals.^2));
    
    % Plot updated results
    figure('Name', 'Online Data Processing');
    plot(t, combinedData, 'b.', 'MarkerSize', 3);
    hold on;
    plot(t, predictions, 'r-', 'LineWidth', 2);
    newStart = length(existingData) + 1;
    x = [newStart, newStart];
    y = [min(combinedData), max(combinedData)];
    plot(x, y, 'g--', 'LineWidth', 2);
    title(['Updated Model - RMSE: ' num2str(rmse)]);
    xlabel('Time');
    ylabel('Value');
    legend('Data', 'Model', 'New Data Start', 'Location', 'best');
    grid on;
    
    % Return updated dataset
    updatedData = combinedData;
end
