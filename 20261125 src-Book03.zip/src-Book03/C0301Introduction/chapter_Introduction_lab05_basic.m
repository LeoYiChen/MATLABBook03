%% chapter_Introduction_lab05_basic.m
% Basic machine learning workflow.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0301Introduction/
% Listing label         : chapter_Introduction_lab05_basic
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Generate sample data
rng(1); % For reproducibility
x = linspace(0, 10, 100)';
y = sin(x) + 0.1*randn(size(x));

% Split into training and test sets
cv = cvpartition(length(y), 'HoldOut', 0.3);
idxTrain = training(cv);
idxTest = test(cv);
xTrain = x(idxTrain);
yTrain = y(idxTrain);
xTest = x(idxTest);
yTest = y(idxTest);

% Train a regression model
mdl = fitlm(xTrain, yTrain);

% Make predictions on the test set
predictions = predict(mdl, xTest);

% Evaluate the model
rmse = sqrt(mean((yTest - predictions).^2));
disp(['Test RMSE: ' num2str(rmse)]);

% Plot results
figure;
plot(xTrain, yTrain, 'bo', 'DisplayName', 'Training Data');
hold on;
plot(xTest, yTest, 'ko', 'DisplayName', 'Test Data');
plot(xTest, predictions, 'r*', 'DisplayName', 'Predictions');
xlabel('x');
ylabel('y');
title(['Linear Regression Model - Test RMSE: ' num2str(rmse)]);
legend('show');
grid on;
