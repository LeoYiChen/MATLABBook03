%% MATLABBook03_Chapter01_Problem07.m
% Advanced Data Visualization for Multidisciplinary Applications
% MATLAB Roadmap to Applications - Volume III: Multidisciplinary Applications
% Chapter 1: Introduction
%
% Version 1.0
% Author: [Your Name]
% Created: [Current Date]
%
% This problem explores advanced visualization techniques that facilitate
% data interpretation across multiple disciplines.

%% Problem Description:
% You are working as a data scientist in a multidisciplinary research team.
% Your task is to develop effective visualizations for complex datasets from
% different scientific domains to facilitate understanding and communication
% across team members with diverse backgrounds.

%% Task 1: Medical Imaging Visualization
% Create a visualization pipeline for 3D medical imaging data

% Load sample MRI data (or generate synthetic data if not available)
try
    % Try to load sample MRI data
    load mri
    D = squeeze(D);
catch
    % Generate synthetic 3D data if MRI data is not available
    [x,y,z] = meshgrid(1:64, 1:64, 1:32);
    D = 100*exp(-((x-32).^2 + (y-32).^2 + (z-16).^2)/100);
    D = D + 10*randn(size(D)); % Add noise
end

% YOUR CODE HERE:
% 1. Visualize the 3D volume using isosurfaces
% 2. Create three orthogonal slice planes
% 3. Implement interactive threshold adjustment
% 4. Add colormap that enhances specific features
% 5. Add appropriate lighting and camera settings

%% Task 2: Geographic Data Visualization
% Create an interactive visualization of geographic data

% Generate or load sample geographic data
lat = 30:0.5:50;
lon = -130:0.5:-60;
[LON, LAT] = meshgrid(lon, lat);

% Create sample temperature and pressure fields
Z_temp = 15 + 10*cos((LAT-40)*pi/40) .* cos((LON+95)*pi/60);
Z_pressure = 1000 + 10*sin((LAT-35)*pi/30) .* sin((LON+100)*pi/70);

% YOUR CODE HERE:
% 1. Create a geographic basemap
% 2. Overlay temperature as a color-coded surface
% 3. Add pressure contour lines
% 4. Create a wind vector field (derived from pressure gradient)
% 5. Add interactive elements to toggle between visualizations
% 6. Create a custom colorbar with scientific units

%% Task 3: Network and Graph Visualization
% Visualize complex network data with custom styling

% Generate a sample complex network
n_nodes = 100;
n_edges = 300;

% Create random adjacency matrix with communities
nodes = 1:n_nodes;
communities = ceil(4*rand(1, n_nodes)); % Assign nodes to 4 communities

% Create preferential connections within communities
adj_matrix = zeros(n_nodes);
edges_created = 0;
while edges_created < n_edges
    % Pick random source and target nodes
    i = randi(n_nodes);
    j = randi(n_nodes);
    
    % Higher probability for connection if in same community
    if i ~= j && adj_matrix(i,j) == 0
        if communities(i) == communities(j)
            p_connect = 0.8;
        else
            p_connect = 0.2;
        end
        
        if rand() < p_connect
            adj_matrix(i,j) = 1;
            adj_matrix(j,i) = 1; % Undirected graph
            edges_created = edges_created + 1;
        end
    end
end

% Create node metrics
node_centrality = sum(adj_matrix, 2);
node_clustering = zeros(n_nodes, 1);

% YOUR CODE HERE:
% 1. Compute clustering coefficient for each node
% 2. Create a graph visualization where:
%    - Node size represents centrality
%    - Node color represents community
%    - Node transparency represents clustering coefficient
%    - Edge thickness represents connection strength
% 3. Implement a force-directed layout algorithm
% 4. Add interactivity to highlight node connections on hover/click
% 5. Create a subgraph filtering function

%% Task 4: Multidimensional Scientific Data Visualization
% Create an interactive dashboard for exploring multidimensional scientific data

% Generate synthetic scientific dataset
n_samples = 1000;
n_dimensions = 6;

% Create correlated variables with physical meaning
% (e.g., temperature, pressure, chemical concentrations, reaction rates)
base_data = randn(n_samples, 2); % Two underlying factors
X = zeros(n_samples, n_dimensions);

% Temperature strongly affected by factor 1
X(:,1) = 300 + 30 * base_data(:,1) + 5 * base_data(:,2) + 2 * randn(n_samples, 1);

% Pressure negatively correlated with temperature, affected by factor 2
X(:,2) = 101 - 5 * base_data(:,1) + 10 * base_data(:,2) + 1 * randn(n_samples, 1);

% Chemical concentration A increases with temperature
X(:,3) = 50 + 8 * base_data(:,1) + 3 * randn(n_samples, 1);

% Chemical concentration B decreases with temperature
X(:,4) = 30 - 6 * base_data(:,1) + 2 * randn(n_samples, 1);

% Reaction rate depends on both temperature and concentrations
X(:,5) = 0.5 + 0.1 * X(:,1)/300 .* sqrt(X(:,3) .* X(:,4)) + 0.05 * randn(n_samples, 1);

% Yield depends on reaction rate and pressure
X(:,6) = 70 + 50 * X(:,5) - 0.2 * (X(:,2) - 100) + 3 * randn(n_samples, 1);

% Variable names
var_names = {'Temperature (K)', 'Pressure (kPa)', 'Concentration A (mol/L)', ...
             'Concentration B (mol/L)', 'Reaction Rate (mol/L/s)', 'Yield (%)'};

% YOUR CODE HERE:
% 1. Create a correlation matrix visualization with hierarchical clustering
% 2. Implement a parallel coordinates plot with interactive brushing
% 3. Create a scatter plot matrix with distribution histograms on diagonal
% 4. Build a PCA visualization to show principal directions of variation
% 5. Implement a 3D interactive plot for exploring relationships between
%    three selected variables at a time
% 6. Add interactive filtering capabilities

%% Task 5: Time Series Animation
% Create an animated visualization of time series data

% Generate time-varying data (e.g., complex dynamical system)
t = linspace(0, 10, 500);
dt = t(2) - t(1);

% Lorenz attractor parameters
sigma = 10;
beta = 8/3;
rho = 28;

% Initialize state
state = [1, 1, 1];
n_steps = length(t);
X_lorenz = zeros(n_steps, 3);
X_lorenz(1,:) = state;

% Simulate Lorenz system using Runge-Kutta method
for i = 1:n_steps-1
    % YOUR CODE HERE: Implement 4th order Runge-Kutta
    % to integrate the Lorenz system
end

% YOUR CODE HERE:
% 1. Create an animated 3D plot showing the evolution of the Lorenz attractor
% 2. Add a time series plot that updates with the animation
% 3. Implement custom camera control to follow the trajectory
% 4. Add visual cues to highlight specific dynamical features
% 5. Enable save-to-video functionality

%% Extension Challenge:
% Create a custom visualization technique for a specific scientific domain
% of your choice (e.g., fluid flow, quantum states, neural activity).
% Implement it with interactivity and annotation capabilities.

% YOUR CODE HERE