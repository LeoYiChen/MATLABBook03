%% MATLABBook03_Chapter01_Problem06.m
% Integration with External Systems and Data Sources
% Part of "MATLAB Roadmap to Applications - Volume III Multidisciplinary Applications"
%
% Author: [Author Name]
% Date: [Current Date]
% Version: 1.0
%
% Copyright Notice: [Copyright Information]
%
% This script demonstrates techniques for integrating MATLAB with external
% systems, data sources, and file formats commonly used across disciplines.
% The ability to connect with different data sources is essential for
% multidisciplinary applications.

%% 1. Importing Data from Various File Formats

% Clear workspace and close figures
clear all;
close all;
clc;

disp('========= MATLAB Integration with External Systems =========');
disp('This script demonstrates how MATLAB can interface with various');
disp('external data sources and systems across disciplines.');

%% 1.1 CSV and Text Files
disp('--- Working with CSV and Text Files ---');

% Create sample data
data = rand(10, 3);
headers = {'Temperature', 'Pressure', 'FlowRate'};

% Write to CSV
filename = 'sample_data.csv';
fid = fopen(filename, 'w');
fprintf(fid, '%s,%s,%s\n', headers{:});
for i = 1:size(data, 1)
    fprintf(fid, '%.4f,%.4f,%.4f\n', data(i, :));
end
fclose(fid);
disp(['Created sample CSV file: ' filename]);

% Read CSV using readtable (modern approach)
dataTable = readtable(filename);
disp('Data imported using readtable:');
disp(dataTable(1:3,:));

% Read CSV using textscan (traditional approach)
fid = fopen(filename, 'r');
headerLine = fgetl(fid); % Read header line
formatSpec = '%f%f%f'; % Define format
dataArray = textscan(fid, formatSpec, 'Delimiter', ',', 'HeaderLines', 0);
fclose(fid);
disp('Data imported using textscan:');
disp([dataArray{1}(1:3), dataArray{2}(1:3), dataArray{3}(1:3)]);

%% 1.2 Excel Files
disp('--- Working with Excel Files ---');

% Create an Excel file
excelFilename = 'sample_excel.xlsx';
writetable(dataTable, excelFilename, 'Sheet', 'MeasurementData');
disp(['Created sample Excel file: ' excelFilename]);

% Read Excel data
try
    % Try to read the Excel file (requires appropriate support)
    excelData = readtable(excelFilename);
    disp('Data imported from Excel:');
    disp(excelData(1:3,:));
catch e
    disp('Excel file operations require the supporting functionality:');
    disp(e.message);
end

%% 1.3 JSON Data
disp('--- Working with JSON Data ---');

% Create a sample structure for JSON
jsonStruct = struct();
jsonStruct.measurements = struct();
jsonStruct.measurements.temperature = data(:,1);
jsonStruct.measurements.pressure = data(:,2);
jsonStruct.measurements.flowRate = data(:,3);
jsonStruct.timestamp = datestr(now);
jsonStruct.units = struct('temperature', 'Celsius', 'pressure', 'kPa', 'flowRate', 'm^3/s');

% Write to JSON file
jsonFilename = 'sample_data.json';
try
    % Encode JSON (requires appropriate support)
    jsonText = jsonencode(jsonStruct);
    fid = fopen(jsonFilename, 'w');
    fprintf(fid, '%s', jsonText);
    fclose(fid);
    disp(['Created sample JSON file: ' jsonFilename]);
    
    % Read JSON file
    fid = fopen(jsonFilename, 'r');
    jsonText = fread(fid, '*char')';
    fclose(fid);
    jsonData = jsondecode(jsonText);
    disp('Data imported from JSON:');
    disp('Temperature values:');
    disp(jsonData.measurements.temperature(1:3));
catch e
    disp('JSON operations require the supporting functionality:');
    disp(e.message);
end

%% 2. Database Connectivity

disp('--- Database Connectivity ---');
disp('MATLAB can connect to various database systems including:');
disp('- SQL databases (MySQL, PostgreSQL, SQLite, etc.)');
disp('- NoSQL databases (MongoDB, etc.)');
disp('- Cloud databases (Amazon RDS, Azure SQL, etc.)');

% Example of database connection using Database Toolbox (commented out)
disp('Example of database connection (commands shown but not executed):');
disp('conn = database(''databaseName'', ''username'', ''password'', ''JDBC'', ''jdbc:mysql://localhost:3306/mydb'');');
disp('data = select(conn, ''SELECT * FROM measurements WHERE sensor_id = 1'');');
disp('close(conn);');

%% 3. Web Data and APIs

disp('--- Working with Web Data and APIs ---');

% URL of a sample REST API
apiUrl = 'https://jsonplaceholder.typicode.com/todos/1';
disp(['Attempting to fetch data from: ' apiUrl]);

try
    % Create web options with timeout
    options = weboptions('Timeout', 10);
    
    % Fetch data from the web
    data = webread(apiUrl, options);
    
    % Display the response
    disp('API Response:');
    disp(data);
catch e
    disp('Web API request failed:');
    disp(e.message);
    disp('Note: This example requires internet connectivity and the specified API to be accessible.');
end

%% 4. Image and Audio File Formats

disp('--- Working with Multimedia Files ---');

%% 4.1 Image Data
disp('Image processing example:');

% Create a sample image
img = peaks(200);
figure;
imagesc(img);
colormap jet;
colorbar;
title('Sample Generated Image');
xlabel('X');
ylabel('Y');

% Save image to file
imwrite(rescale(img), 'sample_image.png');
disp('Saved sample image to: sample_image.png');

% Read image file
readImg = imread('sample_image.png');
figure;
imshow(readImg);
title('Image Read from File');

%% 4.2 Audio Data
disp('Audio processing example:');

% Create a sample audio signal
Fs = 44100; % Sample rate (Hz)
t = 0:1/Fs:0.5; % 0.5 seconds
f1 = 440; % A4 note (Hz)
f2 = 587.33; % D5 note (Hz)
audio = 0.5*sin(2*pi*f1*t) + 0.5*sin(2*pi*f2*t);

% Save audio to file
audioFilename = 'sample_audio.wav';
try
    audiowrite(audioFilename, audio, Fs);
    disp(['Saved sample audio to: ' audioFilename]);
    
    % Read audio file
    [audioData, sampleRate] = audioread(audioFilename);
    
    % Plot the waveform
    figure;
    plot(t(1:1000), audio(1:1000), 'b-');
    title('Original Audio Waveform (First 1000 Samples)');
    xlabel('Time (s)');
    ylabel('Amplitude');
catch e
    disp('Audio operations may require additional support:');
    disp(e.message);
end

%% 5. Interfacing with Other Programming Languages

disp('--- Interfacing with Other Programming Languages ---');
disp('MATLAB can interface with several languages including:');
disp('- Python (through MATLAB Engine API for Python or Python libraries like matlab.engine)');
disp('- C/C++ (through MEX files)');
disp('- Java (through Java interface)');
disp('- .NET languages (through MATLAB Builder NE)');

% Example of running a system command (OS-dependent)
disp('Example of running a system command:');
try
    if ispc  % Windows
        [status, cmdout] = system('dir');
    else     % Unix/Mac
        [status, cmdout] = system('ls -la');
    end
    
    if status == 0
        disp('System command output (first few lines):');
        lines = strsplit(cmdout, '\n');
        for i = 1:min(5, length(lines))
            disp(lines{i});
        end
    else
        disp('System command failed');
    end
catch e
    disp('System command execution failed:');
    disp(e.message);
end

%% 6. Cloud Services Integration

disp('--- Cloud Services Integration ---');
disp('MATLAB can integrate with various cloud services:');
disp('- MATLAB Drive for cloud storage');
disp('- MATLAB Production Server for deploying MATLAB applications');
disp('- MATLAB Parallel Server for scaling computations');
disp('- Cloud providers (AWS, Azure, Google Cloud) through ThingSpeak IoT platform');

%% 7. Exercises

disp('========= EXERCISES =========');
disp('1. Import a dataset from a publicly available API and perform basic analysis.');
disp('2. Create a MATLAB function that exports data to both CSV and JSON formats.');
disp('3. Write a script that takes a directory of images, processes them, and saves the results.');
disp('4. Create a simple dashboard that reads data from an external source and updates in real-time.');
disp('5. Implement a data pipeline that combines data from multiple file formats into a unified dataset.');

%% 8. Conclusion

disp('========= CONCLUSION =========');
disp('This script demonstrated various methods for integrating MATLAB with external');
disp('systems and data sources - a critical capability for multidisciplinary applications.');
disp('The ability to seamlessly work with diverse data types and external systems');
disp('enables MATLAB to serve as a powerful integration platform across disciplines.');

% Clean up
delete('sample_data.csv');
delete('sample_excel.xlsx');
delete('sample_data.json');
delete('sample_image.png');
delete('sample_audio.wav');
disp('Temporary files cleaned up.');

disp('End of MATLABBook03_Chapter01_Problem06.m');