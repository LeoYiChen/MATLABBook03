%% MATLABBook03_Chapter01_Problem03.m
% Signal Processing Fundamentals
% MATLAB Roadmap to Applications - Volume III: Multidisciplinary Applications
% Chapter 1: Introduction
%
% Version 1.0
% Author: [Your Name]
% Created: [Current Date]
%
% This problem explores fundamental signal processing techniques
% that are widely applicable across multiple disciplines.

%% Problem Description:
% As a researcher working with experimental data from various sensors,
% you need to develop robust signal processing techniques to extract
% meaningful information. This problem focuses on time-series analysis,
% filtering, spectral analysis, and other signal processing methods
% essential in fields ranging from biomedical engineering to geophysics.

%% Task 1: Signal Generation and Basic Analysis
% Generate and analyze various test signals

% Parameters
fs = 1000;          % Sampling frequency (Hz)
t = 0:1/fs:1-1/fs;  % Time vector (1 second)
N = length(t);      % Number of samples

% Generate test signals
% 1. Sinusoidal signal with frequency of 10 Hz
f1 = 10;
sin_signal = sin(2*pi*f1*t);

% 2. Signal with multiple frequency components (10, 50, 120 Hz)
f2 = 50;
f3 = 120;
multi_freq_signal = sin(2*pi*f1*t) + 0.5*sin(2*pi*f2*t) + 0.25*sin(2*pi*f3*t);

% 3. Chirp signal (frequency sweeping from 5 Hz to 100 Hz)
chirp_signal = chirp(t, 5, 1, 100);

% 4. Noisy signal (sinusoid with additive white Gaussian noise)
SNR = 10;  % Signal-to-noise ratio in dB
noisy_signal = sin_signal + 10^(-SNR/20)*randn(size(t));

% YOUR CODE HERE:
% 1. Calculate basic statistics for each signal (mean, variance, RMS)
% 2. Plot all signals in time domain
% 3. Find and mark the peaks in the multi-frequency signal
% 4. Calculate and plot the envelope of the chirp signal using Hilbert transform
% 5. Calculate and display the SNR of the noisy signal

%% Task 2: Spectral Analysis
% Analyze signals in the frequency domain

% YOUR CODE HERE:
% 1. Compute and plot the magnitude spectrum for each signal using FFT
% 2. Identify the frequency components in the multi-frequency signal
% 3. Compare the power spectrum using different window functions
%    (rectangular, Hamming, Hann, etc.)
% 4. Compute and plot the spectrogram of the chirp signal
% 5. Implement a function to calculate the power spectral density using Welch's method

function [psd, f] = calculatePSD(signal, fs, window_length, overlap)
    % Calculate the power spectral density using Welch's method
    % Inputs:
    %   signal - input time series
    %   fs - sampling frequency (Hz)
    %   window_length - window length for segments (samples)
    %   overlap - overlap between segments (fraction)
    % Outputs:
    %   psd - power spectral density estimate
    %   f - frequency vector
    
    % YOUR CODE HERE
end

%% Task 3: Digital Filtering
% Design and apply various digital filters

% Generate a test signal with multiple components and noise
test_signal = sin(2*pi*5*t) + sin(2*pi*50*t) + sin(2*pi*120*t) + 0.5*randn(size(t));

% YOUR CODE HERE:
% 1. Design and apply a low-pass filter (cutoff at 10 Hz)
% 2. Design and apply a band-pass filter (pass band: 40-60 Hz)
% 3. Design and apply a high-pass filter (cutoff at 100 Hz)
% 4. Design and apply a notch filter to remove 50 Hz component
% 5. Plot the original and filtered signals in both time and frequency domains
% 6. Compare the performance of FIR and IIR filters

%% Task 4: Time-Frequency Analysis
% Implement and compare various time-frequency analysis methods

% Generate a test signal with time-varying frequency content
test_signal_tf = chirp(t, 5, 0.5, 100) + chirp(t, 150, 1, 50);
% Add a transient component
test_signal_tf(floor(N/4):floor(N/4)+50) = test_signal_tf(floor(N/4):floor(N/4)+50) + 2;

% YOUR CODE HERE:
% 1. Compute and plot the Short-Time Fourier Transform (STFT)
% 2. Compute and plot the Continuous Wavelet Transform (CWT)
% 3. Compare the time-frequency resolution of both methods
% 4. Identify the transient component and time-varying frequencies
% 5. Implement a function for the Wigner-Ville Distribution

function [stft, f, t_stft] = calculateSTFT(signal, fs, window_length, overlap)
    % Calculate the Short-Time Fourier Transform
    % Inputs:
    %   signal - input time series
    %   fs - sampling frequency (Hz)
    %   window_length - window length (samples)
    %   overlap - overlap between windows (fraction)
    % Outputs:
    %   stft - Short-Time Fourier Transform
    %   f - frequency vector
    %   t_stft - time vector for STFT
    
    % YOUR CODE HERE
end

%% Task 5: Signal Decomposition and Reconstruction
% Apply various signal decomposition techniques

% Generate a composite signal
composite_signal = sin(2*pi*3*t) + 0.5*square(2*pi*7*t) + 0.3*sawtooth(2*pi*11*t);

% YOUR CODE HERE:
% 1. Decompose the signal using Fourier series approximation
% 2. Decompose the signal using Empirical Mode Decomposition (EMD)
% 3. Decompose the signal using Singular Spectrum Analysis (SSA)
% 4. Reconstruct the signal using a subset of components from each method
% 5. Compare the original and reconstructed signals
% 6. Evaluate the approximation error for each method

%% Task 6: Real-World Application
% Apply signal processing techniques to a real-world dataset

% Choose and load a real-world dataset
% If no dataset is available, generate a synthetic dataset
% that mimics real-world characteristics

% Examples:
% - ECG data (cardiac signals)
% - Seismic data
% - Speech signals
% - Vibration measurements

% For synthetic ECG data:
fs_ecg = 250;  % Hz
t_ecg = 0:1/fs_ecg:10-1/fs_ecg;  % 10 seconds
% Simple ECG model with PQRST complexes
ecg_data = zeros(size(t_ecg));
heart_rate = 60;  % beats per minute
interval = fs_ecg * 60 / heart_rate;  % samples between beats

% Generate PQRST complexes
for i = 1:floor(length(t_ecg)/interval)
    center = round(i * interval);
    if center + 100 <= length(ecg_data)
        % P wave
        ecg_data(center-25:center-5) = ecg_data(center-25:center-5) + 0.25 * exp(-((1:21) - 10).^2 / 50);
        % QRS complex
        ecg_data(center-5:center+5) = ecg_data(center-5:center+5) + [-0.2, -0.2, -0.3, 1.2, 1.5, 1.2, -0.2, -0.2, -0.3, -0.2, -0.1];
        % T wave
        ecg_data(center+15:center+45) = ecg_data(center+15:center+45) + 0.35 * exp(-((1:31) - 15).^2 / 100);
    end
end

% Add noise
ecg_data = ecg_data + 0.1*randn(size(ecg_data));

% YOUR CODE HERE:
% 1. Apply appropriate preprocessing (detrending, noise removal)
% 2. Detect specific features in the data (e.g., QRS complexes in ECG)
% 3. Apply spectral analysis to identify frequency components
% 4. Extract and visualize key parameters
% 5. Implement a classification or anomaly detection algorithm

%% Additional Challenge:
% Develop a comprehensive signal processing toolbox that:
% 1. Provides a unified interface for different analysis methods
% 2. Automatically selects appropriate methods based on signal characteristics
% 3. Generates comprehensive reports with multiple visualizations
% 4. Implements adaptive filtering for non-stationary signals

% YOUR CODE HERE