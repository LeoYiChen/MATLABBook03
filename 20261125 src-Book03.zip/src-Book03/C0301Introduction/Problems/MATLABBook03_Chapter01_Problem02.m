%% MATLABBook03_Chapter01_Problem02.m
% Mathematical Modeling and Simulation
% MATLAB Roadmap to Applications - Volume III: Multidisciplinary Applications
% Chapter 1: Introduction
%
% Version 1.0
% Author: [Your Name]
% Created: [Current Date]
%
% This problem explores mathematical modeling and simulation techniques
% that are widely applicable across scientific and engineering disciplines.

%% Problem Description:
% You are tasked with developing mathematical models for various physical 
% phenomena and implementing numerical simulations to analyze their behavior.
% These fundamental techniques are critical across disciplines from physics 
% to finance, biology to engineering.

%% Task 1: Ordinary Differential Equations (ODEs)
% Implement and solve ODEs representing different dynamical systems

% A. Simple Harmonic Oscillator
% The equation: d²x/dt² + ω²x = 0
% Or as a system: dx/dt = v, dv/dt = -ω²x

% Parameters
omega = 2;  % Angular frequency
tspan = [0, 10];  % Time span
y0 = [1; 0];  % Initial conditions: x(0) = 1, v(0) = 0

% YOUR CODE HERE:
% 1. Define the ODE function for a simple harmonic oscillator
% 2. Solve using ode45
% 3. Plot the solution showing position and velocity versus time

function dydt = harmonicOscillator(t, y, omega)
    % State variables: y(1) = position x, y(2) = velocity v
    % YOUR CODE HERE
end

% B. Nonlinear Pendulum
% The equation: d²θ/dt² + (g/L)sin(θ) = 0
% Or as a system: dθ/dt = ω, dω/dt = -(g/L)sin(θ)

% Parameters
g = 9.81;  % Gravitational acceleration (m/s²)
L = 1;     % Pendulum length (m)
tspan = [0, 20];  % Time span
theta0 = [pi/6; 0];  % Initial conditions: θ(0) = 30°, ω(0) = 0

% YOUR CODE HERE:
% 1. Define the ODE function for a nonlinear pendulum
% 2. Solve using ode45
% 3. Compare with the linear approximation for small angles
% 4. Plot the solutions showing the difference

function dydt = pendulum(t, y, g, L)
    % State variables: y(1) = angle θ, y(2) = angular velocity ω
    % YOUR CODE HERE
end

%% Task 2: Partial Differential Equations (PDEs)
% Solve a 1D heat equation using finite difference method

% Heat equation: ∂u/∂t = α ∂²u/∂x²

% Parameters
alpha = 0.01;  % Thermal diffusivity
L = 1;         % Length of the rod
T = 5;         % Total time
nx = 50;       % Number of spatial points
nt = 1000;     % Number of time points

% Spatial and temporal discretization
dx = L/(nx-1);
dt = T/(nt-1);
x = linspace(0, L, nx);
t = linspace(0, T, nt);

% Initial and boundary conditions
u0 = zeros(nx, 1);  % Initial temperature distribution
% Set initial temperature as a sine wave
u0 = sin(pi*x);
u = zeros(nx, nt);
u(:,1) = u0;
% Fixed boundary conditions: u(0,t) = 0, u(L,t) = 0

% Check stability condition
stability = alpha*dt/dx^2;
fprintf('Stability parameter: %.4f (should be <= 0.5)\n', stability);

% YOUR CODE HERE:
% 1. Implement the finite difference method for the heat equation
% 2. Apply the initial and boundary conditions
% 3. Plot the temperature distribution at different times
% 4. Create an animation of the temperature evolution

%% Task 3: Stochastic Processes
% Implement random walk and other stochastic processes

% A. 1D Random Walk

% Parameters
n_steps = 1000;
n_walks = 5;

% YOUR CODE HERE:
% 1. Implement multiple 1D random walks
% 2. Calculate and plot the mean squared displacement
% 3. Compare with the theoretical prediction: <x²> = n

% B. Brownian Motion (Wiener Process)

% Parameters
T = 1;         % Total time
dt = 0.001;    % Time step
n_paths = 5;   % Number of paths

% YOUR CODE HERE:
% 1. Implement Brownian motion simulation
% 2. Plot multiple realizations
% 3. Calculate and plot the variance at each time point
% 4. Compare with the theoretical prediction: Var(W(t)) = t

%% Task 4: Cellular Automata
% Implement a 1D cellular automaton (e.g., Rule 30)

% Parameters
n_cells = 100;     % Number of cells
n_steps = 75;      % Number of time steps
rule_number = 30;  % CA rule to implement

% Convert rule to binary representation
rule_binary = de2bi(rule_number, 8);

% Initialize the automaton
ca = zeros(n_steps, n_cells);
ca(1, round(n_cells/2)) = 1;  % Start with a single cell active

% YOUR CODE HERE:
% 1. Implement the cellular automaton update rule
% 2. Run the simulation for n_steps
% 3. Visualize the evolution using imagesc
% 4. Try different rules and initial conditions

%% Task 5: System Dynamics and Control
% Model and control a simple dynamical system

% Consider a DC motor modeled as:
% J(d²θ/dt²) + b(dθ/dt) = Ki
% di/dt + (R/L)i + (K/L)(dθ/dt) = (1/L)V

% Parameters
J = 0.01;    % Moment of inertia (kg.m²)
b = 0.1;     % Damping ratio (N.m.s)
K = 0.01;    % Electromotive force constant (V/rad/s)
R = 1;       % Resistance (Ohm)
L = 0.5;     % Inductance (H)

% State-space representation: dx/dt = Ax + Bu, y = Cx + Du
% States: x = [θ, dθ/dt, i]'
% Input: u = V (applied voltage)
% Output: y = θ (angular position)

% YOUR CODE HERE:
% 1. Define the state-space matrices A, B, C, D
% 2. Analyze the system (eigenvalues, stability)
% 3. Simulate the system response to a step input
% 4. Design a PID controller to regulate the motor position
% 5. Simulate the closed-loop controlled system

%% Additional Challenge:
% Implement a more complex simulation that combines multiple modeling techniques
% (e.g., a reaction-diffusion system, a predator-prey model with spatial components,
% or a multiphysics simulation of heat transfer with fluid flow).

% YOUR CODE HERE