%% MATLABBook03_Chapter01_Problem01.m
% Basic MATLAB Programming for Multidisciplinary Applications
% MATLAB Roadmap to Applications - Volume III: Multidisciplinary Applications
% Chapter 1: Introduction
%
% Version 1.0
% Author: [Your Name]
% Created: [Current Date]
%
% This problem introduces fundamental MATLAB programming concepts
% essential for multidisciplinary applications.

%% Problem Description:
% As a research assistant in a multidisciplinary laboratory, you need to develop
% MATLAB scripts that can be used by researchers from different disciplines.
% This problem covers essential programming techniques that form the foundation
% for more complex applications.

%% Task 1: Vector and Matrix Operations
% Implement basic vector and matrix operations common in scientific computing

% Create test vectors and matrices
v1 = [3, 1, 4, 1, 5, 9];
v2 = [2, 7, 1, 8, 2, 8];
A = [1, 2, 3; 4, 5, 6; 7, 8, 9];
B = [9, 8, 7; 6, 5, 4; 3, 2, 1];

% YOUR CODE HERE:
% 1. Calculate dot product of v1 and v2
dotProduct = 

% 2. Calculate cross product of two 3D vectors
vector1 = [1, 0, 0];
vector2 = [0, 1, 0];
crossProduct = 

% 3. Matrix multiplication A*B
matrixProduct = 

% 4. Element-wise multiplication A.*B
elementWiseProduct = 

% 5. Calculate the determinant of matrix A
det_A = 

% 6. Calculate the inverse of matrix B
inv_B = 

% 7. Solve the linear system Ax = b, where b = [6; 15; 24]
b = [6; 15; 24];
x = 

%% Task 2: Data Structures
% Implement and manipulate different MATLAB data structures

% YOUR CODE HERE:
% 1. Create a cell array containing:
%    - A 3x3 matrix of random numbers
%    - A character vector with your name
%    - A logical array of size 1x5
%    - A vector of even numbers from 2 to 20
myCell = 

% 2. Create a structure to store experiment data with fields:
%    - date: today's date
%    - temperature: a random value between 20 and 30
%    - pressure: a random value between 990 and 1010
%    - measurements: a 1x100 vector of random measurements
experimentData = 

% 3. Access and modify elements in your data structures
% Display the second element of your cell array
% Add a new field 'humidity' to your structure with random value between 30 and 90

%% Task 3: Control Flow
% Implement conditional statements and loops for data processing

% Generate sample data for processing
sampleData = randn(100, 1);

% YOUR CODE HERE:
% 1. Use if-else statements to classify values in sampleData:
%    - Create a vector of categories ('High', 'Medium', 'Low')
%    - Values > 1: 'High'
%    - Values between -1 and 1: 'Medium'
%    - Values < -1: 'Low'
categories = cell(size(sampleData));

% 2. Use a for loop to calculate the cumulative sum of sampleData
cumulativeSum = zeros(size(sampleData));

% 3. Use a while loop to find when the cumulative sum exceeds 10
%    (if it never exceeds 10, stop at the end of the array)

%% Task 4: Function Implementation
% Create modular, reusable functions

% YOUR CODE HERE:
% 1. Create a function 'statsCalculator' that:
%    - Takes a numeric vector as input
%    - Returns a structure with fields: mean, median, std, min, max
% 2. Create a function 'dataFilter' that:
%    - Takes a vector and threshold values
%    - Returns data points between the thresholds
% 3. Test your functions on sampleData

function stats = statsCalculator(data)
    % Calculate descriptive statistics of input data
    % Input: data - numeric vector
    % Output: stats - structure with statistical measures
    
    % YOUR CODE HERE
end

function filteredData = dataFilter(data, lowerThreshold, upperThreshold)
    % Filter data between specified thresholds
    % Input: data - numeric vector
    %        lowerThreshold - minimum value to include
    %        upperThreshold - maximum value to include
    % Output: filteredData - filtered vector
    
    % YOUR CODE HERE
end

%% Task 5: File I/O and Data Import/Export
% Implement data reading and writing operations

% YOUR CODE HERE:
% 1. Save experimentData structure to a MAT file named 'experiment_results.mat'

% 2. Write a CSV file with columns for:
%    - Index (1 to 100)
%    - Random measurement data
%    - Category ('High', 'Medium', 'Low')

% 3. Read the CSV file back into MATLAB
%    - Use readtable() function
%    - Display the first 5 rows

%% Additional Challenge:
% Create a comprehensive data processing script that:
% 1. Imports data from a user-specified file
% 2. Cleans the data (removes NaN values, outliers)
% 3. Applies statistical analysis
% 4. Visualizes the results
% 5. Exports processed data and figures

% YOUR CODE HERE