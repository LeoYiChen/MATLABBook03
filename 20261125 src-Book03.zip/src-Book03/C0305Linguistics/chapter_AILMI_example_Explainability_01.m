%% chapter_AILMI_example_Explainability_01.m
% LIME implementation for text classification explainability with local model approximation and feature importance ranking.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_Explainability_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Explainable AI: LIME for Text Classification
% Local Interpretable Model-agnostic Explanations

fprintf('=== LIME for Text Classification Explainability ===\n\n');

% - Step 1: Train a Black-Box Classifier -

fprintf('Step 1: Training black-box sentiment classifier...\n');

% Training data
trainingTexts = [
    "This product is excellent and exceeded all expectations";
    "Terrible quality very disappointed with purchase";
    "Amazing service highly recommend to everyone";
    "Poor performance does not work as advertised";
    "Outstanding value great features happy customer";
    "Awful experience waste of money completely useless";
    "Fantastic design beautiful appearance love it";
    "Horrible quality broke after one week";
    "Brilliant product solves my problem perfectly";
    "Disappointing results not worth the price"
];

trainingLabels = ["positive"; "negative"; "positive"; "negative"; ...
    "positive"; "negative"; "positive"; "negative"; "positive"; "negative"];

% Replicate to create larger training set
trainingTexts = repmat(trainingTexts, 20, 1);
trainingLabels = repmat(trainingLabels, 20, 1);

% Tokenise and extract features
documents = tokenizedDocument(trainingTexts);
documents = removeStopWords(erasePunctuation(lower(documents)));

bag = bagOfWords(documents);
tfidfFeatures = tfidf(bag);
tfidfFeatures = full(tfidfFeatures);

% Train SVM classifier (black box)
blackBoxClassifier = fitcsvm(tfidfFeatures, trainingLabels, ...
    'KernelFunction', 'rbf');

fprintf('  Black-box classifier trained\n');
fprintf('  Model type: SVM with RBF kernel\n');
fprintf('  Vocabulary size: %d words\n\n', bag.NumWords);

% - Step 2: Define Instance to Explain -

fprintf('Step 2: Selecting instance for explanation...\n');

instanceToExplain = "The product quality is outstanding and " + ...
    "performance exceeded expectations highly recommended";

fprintf('  Instance to explain:\n');
fprintf('  "%s"\n\n', instanceToExplain);

% Get prediction for this instance
instanceDoc = tokenizedDocument(instanceToExplain);
instanceDoc = removeStopWords(erasePunctuation(lower(instanceDoc)));
instanceEncoding = encode(bag, instanceDoc);
instanceTfidf = tfidf(bag, instanceEncoding);
instanceTfidf = full(instanceTfidf);

[predictedLabel, predictedScore] = predict(blackBoxClassifier, instanceTfidf);

fprintf('  Black-box prediction: %s\n', predictedLabel);
fprintf('  Confidence score: %.4f\n\n', max(predictedScore));

% - Step 3: Generate Perturbed Instances -

fprintf('Step 3: Generating perturbed instances for local approximation...\n');

% Extract words from instance
instanceWords = string(instanceDoc.Vocabulary);
numWords = length(instanceWords);

% Number of perturbations
numPerturbations = 1000;

% Generate perturbations by randomly removing words
perturbedTexts = strings(numPerturbations, 1);
perturbedFeatures = zeros(numPerturbations, numWords);

for pertIdx = 1:numPerturbations
    % Randomly select words to keep (binary mask)
    keepMask = rand(numWords, 1) > 0.3;  % Keep ~70% of words
    
    % Create perturbed text
    keptWords = instanceWords(keepMask);
    perturbedTexts(pertIdx) = strjoin(keptWords, ' ');
    
    % Store binary feature representation
    perturbedFeatures(pertIdx, :) = keepMask';
end

fprintf('  Generated %d perturbed instances\n', numPerturbations);
fprintf('  Example perturbation: "%s"\n\n', perturbedTexts(1));

% - Step 4: Get Black-Box Predictions for Perturbations -

fprintf('Step 4: Obtaining black-box predictions for perturbations...\n');

% Process all perturbations
perturbedDocs = tokenizedDocument(perturbedTexts);
perturbedDocs = removeStopWords(erasePunctuation(lower(perturbedDocs)));

% Encode and get predictions
perturbedPredictions = strings(numPerturbations, 1);
perturbedScores = zeros(numPerturbations, 1);

for pertIdx = 1:numPerturbations
    if strlength(perturbedTexts(pertIdx)) > 0
        pertEncoding = encode(bag, perturbedDocs(pertIdx));
        pertTfidf = tfidf(bag, pertEncoding);
        pertTfidf = full(pertTfidf);
        
        [predLabel, predScore] = predict(blackBoxClassifier, pertTfidf);
        perturbedPredictions(pertIdx) = predLabel;
        
        % Use positive class probability as target
        if predLabel == "positive"
            perturbedScores(pertIdx) = max(predScore);
        else
            perturbedScores(pertIdx) = -max(predScore);
        end
    end
end

fprintf('  Predictions obtained for all perturbations\n\n');

% - Step 5: Fit Local Linear Model -

fprintf('Step 5: Fitting local interpretable linear model (LIME)...\n');

% Calculate instance similarities (kernel weights)
% Distance = Hamming distance in binary feature space
originalFeatures = ones(1, numWords);
distances = sum(abs(perturbedFeatures - originalFeatures), 2);

% Exponential kernel for weighting
kernelWidth = sqrt(numWords) * 0.75;
instanceWeights = exp(-(distances.^2) / (2 * kernelWidth^2));

% Fit weighted linear regression
% Target: black-box predictions
% Features: binary word presence indicators
% Weights: similarity to original instance

limeModel = fitlm(perturbedFeatures, perturbedScores, 'Weights', instanceWeights);

fprintf('  Local linear model fitted\n');
fprintf('  R-squared: %.4f\n', limeModel.Rsquared.Ordinary);
fprintf('  RMSE: %.4f\n\n', limeModel.RMSE);

% - Step 6: Extract Feature Importance -

fprintf('Step 6: Extracting feature importance from local model...\n');

% Get coefficients (feature importance)
coefficients = limeModel.Coefficients.Estimate(2:end);  % Exclude intercept
pValues = limeModel.Coefficients.pValue(2:end);

% Rank features by absolute importance
[sortedCoefs, sortIdx] = sort(abs(coefficients), 'descend');

fprintf('  Top 10 most important words for this prediction:\n');
fprintf('  (positive values support positive classification)\n\n');

for rankIdx = 1:min(10, length(sortIdx))
    wordIdx = sortIdx(rankIdx);
    word = instanceWords(wordIdx);
    coef = coefficients(wordIdx);
    pVal = pValues(wordIdx);
    
    if coef > 0
        direction = "positive";
        symbol = "+";
    else
        direction = "negative";
        symbol = "-";
    end
    
    fprintf('  %2*d. "%s": %s%.4f (p=%.4f) [%s influence]\n', ...
        rankIdx, word, symbol, abs(coef), pVal, direction);
end
fprintf('\n');

% - Step 7: Generate Natural Language Explanation -

fprintf('Step 7: Generating natural language explanation...\n');

% Select top positive and negative features
topPositive = sortIdx(coefficients(sortIdx) > 0);
topNegative = sortIdx(coefficients(sortIdx) < 0);

topPositive = topPositive(1:min(3, length(topPositive)));
topNegative = topNegative(1:min(3, length(topNegative)));

explanation = sprintf(['The classifier predicted "%s" for this text. ' ...
    'This prediction was primarily influenced by the presence of words ' ...
    'suggesting positive sentiment: "%s". '], ...
    predictedLabel, strjoin(instanceWords(topPositive), '", "'));

if ~isempty(topNegative)
    explanation = sprintf(['%sHowever, words like "%s" provided some ' ...
        'evidence against this classification.'], ...
        explanation, strjoin(instanceWords(topNegative), '", "'));
end

fprintf('  Natural language explanation:\n');
fprintf('  %s\n\n', explanation);

% - Step 8: Visualisation -

fprintf('Step 8: Generating explanation visualisations...\n');

figure('Position', [100, 100, 1600, 1000]);

% Plot 1: Feature importance (top 15 words)
subplot(2, 3, 1);
topK = min(15, length(sortIdx));
topWords = instanceWords(sortIdx(1:topK));
topCoefs = coefficients(sortIdx(1:topK));

barh(topCoefs, 'FaceColor', [0.3, 0.6, 0.9]);
set(gca, 'YTickLabel', topWords, 'YDir', 'reverse');
xlabel('Feature Importance (LIME coefficient)');
title('Top Features Influencing Prediction');
grid on;

% Plot 2: Perturbation predictions distribution
subplot(2, 3, 2);
histogram(perturbedScores, 30, 'Normalization', 'probability', ...
    'FaceColor', [0.6, 0.4, 0.8]);
hold on;
xline(perturbedScores(1), 'r-', 'LineWidth', 2, ...
    'Label', 'Original Instance');
hold off;
xlabel('Prediction Score');
ylabel('Probability');
title('Black-Box Predictions on Perturbations');
grid on;

% Plot 3: Local model fit quality
subplot(2, 3, 3);
scatter(limeModel.Fitted, perturbedScores, 20, instanceWeights, 'filled');
hold on;
plot([min(perturbedScores), max(perturbedScores)], ...
    [min(perturbedScores), max(perturbedScores)], 'r-', 'LineWidth', 2);
hold off;
xlabel('LIME Predicted Score');
ylabel('Black-Box Actual Score');
title(sprintf('Local Model Fit (R^2=%.3f)', limeModel.Rsquared.Ordinary));
colorbar('Label', 'Instance Weight');
grid on;

% Plot 4: Word presence vs importance
subplot(2, 3, 4);
scatter(abs(coefficients), pValues, 50, 'filled');
xlabel('Absolute Feature Importance');
ylabel('Statistical Significance (p-value)');
title('Feature Importance vs Significance');
grid on;
set(gca, 'YScale', 'log');

% Plot 5: Positive vs negative feature contributions
subplot(2, 3, 5);
positiveContrib = sum(coefficients(coefficients > 0));
negativeContrib = sum(abs(coefficients(coefficients < 0)));

bar([positiveContrib, negativeContrib], 'FaceColor', [0.5, 0.7, 0.5]);
set(gca, 'XTickLabel', {'Positive Evidence', 'Negative Evidence'});
ylabel('Total Feature Contribution');
title('Evidence Supporting vs Opposing Prediction');
grid on;

% Plot 6: Word cloud of feature importance
subplot(2, 3, 6);
% Create simple text-based visualisation
wordImportance = abs(coefficients);
[~, importanceRank] = sort(wordImportance, 'descend');

text(0.5, 0.9, 'Feature Importance Summary', 'FontSize', 14, ...
    'FontWeight', 'bold', 'HorizontalAlignment', 'center');

yPos = 0.75;
for rankIdx = 1:min(8, length(importanceRank))
    wordIdx = importanceRank(rankIdx);
    word = instanceWords(wordIdx);
    importance = wordImportance(wordIdx);
    
    fontSize = 8 + importance * 30;  % Scale font by importance
    
    if coefficients(wordIdx) > 0
        color = [0, 0.6, 0];  % Green for positive
    else
        color = [0.8, 0, 0];  % Red for negative
    end
    
    text(0.5, yPos, word, 'FontSize', fontSize, 'Color', color, ...
        'HorizontalAlignment', 'center', 'FontWeight', 'bold');
    
    yPos = yPos - 0.1;
end

axis off;
title('Important Words (size=importance, green=positive, red=negative)');

sgtitle('LIME Explainability Analysis for Text Classification', ...
    'FontSize', 14, 'FontWeight', 'bold');

print('lime_explainability_analysis', '-dpng', '-r300');

fprintf('\nLIME explainability analysis complete!\n');
fprintf('Identified %d important features with local model R^2 = %.3f\n', ...
    topK, limeModel.Rsquared.Ordinary);
fprintf('Top contributing word: "%s" (coefficient: %.4f)\n', ...
    instanceWords(sortIdx(1)), coefficients(sortIdx(1)));
