%% chapter_AILMI_example_hist_02.m
% Bigram language model for text probability estimation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_hist_02
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Sample training corpus
corpus = ["the cat sat on the mat"; 
          "the dog sat on the log";
          "the cat chased the dog"];

% Tokenise and preprocess
documents = tokenizedDocument(corpus);
documents = erasePunctuation(lower(documents));

% Extract all words from corpus
allWords = [];
for i = 1:numel(documents)
    allWords = [allWords; string(documents(i).Vocabulary)'];
end

% Create bigram counts (word pairs)
bigramCounts = containers.Map('KeyType', 'char', ...
                               'ValueType', 'double');
unigramCounts = containers.Map('KeyType', 'char', ...
                                'ValueType', 'double');

% Count bigrams and unigrams
for i = 1:numel(documents)
    words = string(documents(i).Vocabulary)';
    % Count unigrams
    for j = 1:length(words)
        word = char(words(j));
        if isKey(unigramCounts, word)
            unigramCounts(word) = unigramCounts(word) + 1;
        else
            unigramCounts(word) = 1;
        end
    end
    % Count bigrams
    for j = 1:length(words)-1
        bigram = char(strjoin([words(j), words(j+1)], ' '));
        if isKey(bigramCounts, bigram)
            bigramCounts(bigram) = bigramCounts(bigram) + 1;
        else
            bigramCounts(bigram) = 1;
        end
    end
end

% Calculate bigram probability: P(word2|word1)

% Example: Calculate probability of "the cat"
prob = bigramProb('the', 'cat', bigramCounts, unigramCounts);
fprintf('P(cat|the) = %.3f\n', prob);

% Local functions (moved to end so this listing is a valid MATLAB script)
function prob = bigramProb(word1, word2, bigramCounts, unigramCounts)
    bigram = char(strjoin([string(word1), string(word2)], ' '));
    if isKey(bigramCounts, bigram) && isKey(unigramCounts, char(word1))
        prob = bigramCounts(bigram) / unigramCounts(char(word1));
    else
        prob = 0;  % Unseen bigram
    end
end
