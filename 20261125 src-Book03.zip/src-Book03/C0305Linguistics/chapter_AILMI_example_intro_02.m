%% chapter_AILMI_example_intro_02.m
% Word cloud visualisation for text exploration.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_intro_02
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Load sample text data (news articles)
textData = ["Artificial intelligence transforms healthcare delivery"; 
            "Machine learning algorithms improve diagnostic accuracy";
            "Deep learning revolutionises medical imaging analysis";
            "AI systems assist doctors in treatment planning";
            "Healthcare AI applications expand rapidly worldwide"];

% Create and preprocess documents
documents = tokenizedDocument(textData);
documents = erasePunctuation(lower(documents));
documents = removeStopWords(documents);

% Create bag-of-words model
bag = bagOfWords(documents);

% Generate word cloud visualisation
figure;
wordcloud(bag);
title('Healthcare AI Topic Analysis');

% Display top keywords
topWords = topkwords(bag, 10);
disp('Top 10 Keywords:');
disp(topWords);
