%% chapter_AILMI_example_ContentModeration_01.m
% Multi-class content moderation system combining text classification, simulated image analysis, and risk scoring with human review prioritisation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_ContentModeration_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Content Moderation System
% Multi-class classification for harmful content detection

fprintf('=== Automated Content Moderation System ===\n\n');

% - Step 1: Generate Synthetic Content Dataset -

fprintf('Step 1: Creating synthetic content moderation dataset...\n');

% Content categories
categories = ["Safe", "Hate Speech", "Violence", "Spam", "Adult"];
numCategories = length(categories);

% Generate labeled training samples
numSamplesPerCategory = 100;
numSamples = numSamplesPerCategory * numCategories;

contentTexts = strings(numSamples, 1);
contentLabels = strings(numSamples, 1);
contentImageFeatures = zeros(numSamples, 10);  % Simulated image features

sampleIdx = 1;

% Safe content
for i = 1:numSamplesPerCategory
    templates = [
        "Enjoying a beautiful day with family and friends";
        "Just finished reading an interesting book about history";
        "Looking forward to the weekend activities";
        "Sharing pictures from my holiday travels";
        "Congratulations to everyone on their achievements"
    ];
    contentTexts(sampleIdx) = templates(randi(length(templates)));
    contentLabels(sampleIdx) = "Safe";
    contentImageFeatures(sampleIdx, :) = rand(1, 10) * 0.3;  % Low risk features
    sampleIdx = sampleIdx + 1;
end

% Hate speech
for i = 1:numSamplesPerCategory
    templates = [
        "These people do not belong here and should leave";
        "All members of that group are criminals";
        "They are inferior and dangerous to our society";
        "We need to remove them from our community";
        "Their kind is responsible for all problems"
    ];
    contentTexts(sampleIdx) = templates(randi(length(templates)));
    contentLabels(sampleIdx) = "Hate Speech";
    contentImageFeatures(sampleIdx, :) = [rand(1, 5)*0.8+0.2, rand(1, 5)*0.3];
    sampleIdx = sampleIdx + 1;
end

% Violence
for i = 1:numSamplesPerCategory
    templates = [
        "Graphic images of weapons and fighting";
        "Video shows violent confrontation with injuries";
        "Content contains disturbing scenes of harm";
        "Footage depicts physical assault and blood";
        "Graphic documentation of violent incident"
    ];
    contentTexts(sampleIdx) = templates(randi(length(templates)));
    contentLabels(sampleIdx) = "Violence";
    contentImageFeatures(sampleIdx, :) = [rand(1, 3)*0.3, rand(1, 4)*0.8+0.2, ...
        rand(1, 3)*0.3];
    sampleIdx = sampleIdx + 1;
end

% Spam
for i = 1:numSamplesPerCategory
    templates = [
        "Click here now for amazing deals buy cheap products";
        "Make money fast with this one simple trick link below";
        "Free prizes claim your reward visit our website now";
        "Hot singles in your area click to meet them today";
        "Discount offers limited time buy now before expires"
    ];
    contentTexts(sampleIdx) = templates(randi(length(templates)));
    contentLabels(sampleIdx) = "Spam";
    contentImageFeatures(sampleIdx, :) = [rand(1, 2)*0.3, rand(1, 3)*0.7+0.3, ...
        rand(1, 5)*0.3];
    sampleIdx = sampleIdx + 1;
end

% Adult content
for i = 1:numSamplesPerCategory
    templates = [
        "Explicit adult content not suitable for minors";
        "Sexual imagery and mature themes present";
        "Adult material with nudity and suggestive content";
        "Content contains explicit scenes intended for adults";
        "Mature sexual content warning advised"
    ];
    contentTexts(sampleIdx) = templates(randi(length(templates)));
    contentLabels(sampleIdx) = "Adult";
    contentImageFeatures(sampleIdx, :) = [rand(1, 7)*0.3, rand(1, 3)*0.8+0.2];
    sampleIdx = sampleIdx + 1;
end

fprintf('  Generated %d labeled content samples\n', numSamples);
fprintf('  Categories: %s\n', strjoin(categories, ', '));
fprintf('\n');

% - Step 2: Extract Text Features -

fprintf('Step 2: Extracting text features for classification...\n');

% Tokenise and preprocess
documents = tokenizedDocument(contentTexts);
documents = removeStopWords(erasePunctuation(lower(documents)));

% Create bag-of-words
bag = bagOfWords(documents);

% TF-IDF features
tfidfFeatures = tfidf(bag);
tfidfFeatures = full(tfidfFeatures);

fprintf('  Text features: %d samples x %d TF-IDF features\n', size(tfidfFeatures));
fprintf('\n');

% - Step 3: Combine Text and Image Features -

fprintf('Step 3: Creating multimodal feature representation...\n');

% Normalise image features
contentImageFeatures = (contentImageFeatures - mean(contentImageFeatures)) ./ ...
    std(contentImageFeatures);

% Combine text and image features
allFeatures = [tfidfFeatures, contentImageFeatures];

fprintf('  Combined features: %d samples x %d features\n', size(allFeatures));
fprintf('    Text features: %d\n', size(tfidfFeatures, 2));
fprintf('    Image features: %d\n', size(contentImageFeatures, 2));
fprintf('\n');

% - Step 4: Train Multi-Class Classifier -

fprintf('Step 4: Training content moderation classifier...\n');

% Split into training and testing
rng(42);
trainRatio = 0.8;
numTrain = round(numSamples * trainRatio);
trainIdx = randperm(numSamples, numTrain);
testIdx = setdiff(1:numSamples, trainIdx);

XTrain = allFeatures(trainIdx, :);
YTrain = contentLabels(trainIdx);
XTest = allFeatures(testIdx, :);
YTest = contentLabels(testIdx);

% Train multi-class ensemble classifier
moderationClassifier = fitcecoc(XTrain, YTrain, ...
    'Learners', 'tree', ...
    'NumBins', 50);

fprintf('  Classifier trained (multi-class ECOC with decision trees)\n');

% - Step 5: Evaluate Performance -

fprintf('Step 5: Evaluating moderation system performance...\n\n');

% Predictions on test set
[predictedLabels, scores] = predict(moderationClassifier, XTest);

% Overall accuracy
accuracy = sum(predictedLabels == YTest) / length(YTest);
fprintf('  Overall accuracy: %.2f%%\n\n', accuracy * 100);

% Confusion matrix
confMat = confusionmat(YTest, predictedLabels, 'Order', categories);

fprintf('  Confusion Matrix:\n');
fprintf('  (rows = true, columns = predicted)\n');
fprintf('            ');
for i = 1:numCategories
    fprintf('%12*s ', categories(i));
end
fprintf('\n');

for i = 1:numCategories
    fprintf('%12*s ', categories(i));
    for j = 1:numCategories
        fprintf('%12*d ', confMat(i, j));
    end
    fprintf('\n');
end
fprintf('\n');

% Per-category metrics
fprintf('  Per-Category Performance:\n');
for catIdx = 1:numCategories
    % True positives, false positives, false negatives
    truePos = confMat(catIdx, catIdx);
    falsePos = sum(confMat(:, catIdx)) - truePos;
    falseNeg = sum(confMat(catIdx, :)) - truePos;
    
    % Precision, recall, F1
    if truePos + falsePos > 0
        precision = truePos / (truePos + falsePos);
    else
        precision = 0;
    end
    
    if truePos + falseNeg > 0
        recall = truePos / (truePos + falseNeg);
    else
        recall = 0;
    end
    
    if precision + recall > 0
        f1 = 2 * (precision * recall) / (precision + recall);
    else
        f1 = 0;
    end
    
    fprintf('    %s:\n', categories(catIdx));
    fprintf('      Precision: %.2f%%  Recall: %.2f%%  F1: %.2f%%\n', ...
        precision*100, recall*100, f1*100);
end
fprintf('\n');

% - Step 6: Risk Scoring and Prioritisation -

fprintf('Step 6: Computing risk scores for human review prioritisation...\n');

% Calculate risk scores (higher = more likely harmful)
% Risk = max probability of harmful class
riskScores = zeros(length(YTest), 1);

for sampleIdx = 1:length(YTest)
    sampleScores = scores(sampleIdx, :);
    
    % Probability of harmful categories (not Safe)
    harmfulIdx = find(categories ~= "Safe");
    harmfulProbs = sampleScores(harmfulIdx);
    
    riskScores(sampleIdx) = max(harmfulProbs);
end

% Sort by risk score
[sortedRisks, riskIdx] = sort(riskScores, 'descend');

% Identify high-risk content for human review
highRiskThreshold = 0.7;
highRiskContent = find(sortedRisks > highRiskThreshold);

fprintf('  Risk scoring complete\n');
fprintf('  High-risk items (score > %.2f): %d\n', highRiskThreshold, ...
    length(highRiskContent));
fprintf('\n');

% Display top risky items
fprintf('  Top 5 Highest Risk Items:\n');
for i = 1:min(5, length(riskIdx))
    idx = testIdx(riskIdx(i));
    fprintf('    %d. "%s..."\n', i, extractBefore(contentTexts(idx), 40));
    fprintf('       True: %s, Predicted: %s, Risk: %.3f\n', ...
        YTest(riskIdx(i)), predictedLabels(riskIdx(i)), sortedRisks(i));
end
fprintf('\n');

% - Step 7: False Positive Analysis -

fprintf('Step 7: Analysing false positives (safe content flagged)...\n');

% Find false positives (Safe content classified as harmful)
safeTestIdx = find(YTest == "Safe");
safePredictions = predictedLabels(safeTestIdx);
falsePositives = find(safePredictions ~= "Safe");

falsePositiveRate = length(falsePositives) / length(safeTestIdx);

fprintf('  False positive rate: %.2f%% (%d/%d safe items)\n', ...
    falsePositiveRate*100, length(falsePositives), length(safeTestIdx));

if ~isempty(falsePositives)
    fprintf('  Sample false positives:\n');
    for i = 1:min(3, length(falsePositives))
        fpIdx = safeTestIdx(falsePositives(i));
        origIdx = testIdx(fpIdx);
        fprintf('    "%s..."\n', extractBefore(contentTexts(origIdx), 50));
        fprintf('    Incorrectly classified as: %s\n', safePredictions(falsePositives(i)));
    end
end
fprintf('\n');

% - Step 8: Processing Time Simulation -

fprintf('Step 8: Estimating processing throughput...\n');

% Simulate processing time
processingTimePerItem = 0.05;  % 50*ms per item (automated)
humanReviewTimePerItem = 30;   % 30 seconds per item (manual)

automatedTime = length(YTest) * processingTimePerItem;
humanOnlyTime = length(YTest) * humanReviewTimePerItem;

% Items requiring human review (high risk + unclear predictions)
uncertaintyThreshold = 0.6;
uncertainItems = sum(max(scores, [], 2) < uncertaintyThreshold);
reviewItems = length(highRiskContent) + uncertainItems;

hybridTime = automatedTime + reviewItems * humanReviewTimePerItem;

timeSavings = (humanOnlyTime - hybridTime) / humanOnlyTime * 100;

fprintf('  Performance estimates:\n');
fprintf('    Automated processing time: %.1f seconds\n', automatedTime);
fprintf('    Human-only processing time: %.1f seconds (%.1f minutes)\n', ...
    humanOnlyTime, humanOnlyTime/60);
fprintf('    Hybrid system time: %.1f seconds (%.1f minutes)\n', ...
    hybridTime, hybridTime/60);
fprintf('    Time savings: %.1f%%\n', timeSavings);
fprintf('    Items flagged for human review: %d/%d (%.1f%%)\n', ...
    reviewItems, length(YTest), reviewItems/length(YTest)*100);
fprintf('\n');

% - Step 9: Visualisation -

fprintf('Step 9: Generating performance visualisations...\n');

figure('Position', [100, 100, 1600, 1000]);

% Plot 1: Confusion matrix heatmap
subplot(2, 3, 1);
confMatNorm = confMat ./ sum(confMat, 2);
imagesc(confMatNorm);
colorbar;
colormap(gca, hot);
xlabel('Predicted Category');
ylabel('True Category');
title('Normalised Confusion Matrix');
set(gca, 'XTick', 1:numCategories, 'XTickLabel', categories, ...
    'XTickLabelRotation', 45, 'YTick', 1:numCategories, ...
    'YTickLabel', categories);

% Plot 2: Risk score distribution
subplot(2, 3, 2);
histogram(riskScores, 30, 'Normalization', 'probability', ...
    'FaceColor', [0.8, 0.3, 0.3]);
hold on;
plot([highRiskThreshold, highRiskThreshold], ylim, 'r-', 'LineWidth', 2);
hold off;
xlabel('Risk Score');
ylabel('Probability');
title('Content Risk Score Distribution');
legend('Risk Scores', sprintf('High Risk Threshold (%.2f)', highRiskThreshold), ...
    'Location', 'best');
grid on;

% Plot 3: Per-category F1 scores
subplot(2, 3, 3);
f1Scores = zeros(numCategories, 1);
for catIdx = 1:numCategories
    truePos = confMat(catIdx, catIdx);
    falsePos = sum(confMat(:, catIdx)) - truePos;
    falseNeg = sum(confMat(catIdx, :)) - truePos;
    
    precision = truePos / max(1, truePos + falsePos);
    recall = truePos / max(1, truePos + falseNeg);
    f1Scores(catIdx) = 2 * (precision * recall) / max(0.001, precision + recall);
end
bar(f1Scores, 'FaceColor', [0.3, 0.6, 0.9]);
set(gca, 'XTickLabel', categories, 'XTickLabelRotation', 45);
ylabel('F1 Score');
title('Classification Performance by Category');
ylim([0, 1]);
grid on;

% Plot 4: True vs predicted label distribution
subplot(2, 3, 4);
trueCounts = histcounts(categorical(YTest), categories);
predCounts = histcounts(categorical(predictedLabels), categories);
bar([trueCounts; predCounts]', 'grouped');
set(gca, 'XTickLabel', categories, 'XTickLabelRotation', 45);
ylabel('Count');
title('True vs Predicted Category Distribution');
legend('True Labels', 'Predicted Labels', 'Location', 'best');
grid on;

% Plot 5: Processing time comparison
subplot(2, 3, 5);
timeMethods = ["Automated Only", "Hybrid (Auto+Human)", "Human Only"];
times = [automatedTime/60, hybridTime/60, humanOnlyTime/60];
bar(times, 'FaceColor', [0.6, 0.4, 0.8]);
set(gca, 'XTickLabel', timeMethods, 'XTickLabelRotation', 45);
ylabel('Time (minutes)');
title('Processing Time Comparison');
grid on;

% Plot 6: False positive rate by category
subplot(2, 3, 6);
fpRates = zeros(numCategories, 1);
for catIdx = 1:numCategories
    catTestIdx = find(YTest == categories(catIdx));
    if ~isempty(catTestIdx)
        catPreds = predictedLabels(catTestIdx);
        catFP = sum(catPreds ~= categories(catIdx));
        fpRates(catIdx) = catFP / length(catTestIdx);
    end
end
bar(fpRates * 100, 'FaceColor', [0.8, 0.5, 0.3]);
set(gca, 'XTickLabel', categories, 'XTickLabelRotation', 45);
ylabel('False Positive Rate (%)');
title('Misclassification Rate by Category');
grid on;

sgtitle('Content Moderation System Performance Analysis', ...
    'FontSize', 14, 'FontWeight', 'bold');

print('content_moderation_analysis', '-dpng', '-r300');

fprintf('\nContent moderation system complete!\n');
fprintf('Achieved %.2f%% accuracy with %.1f%% time savings vs human-only moderation\n', ...
    accuracy*100, timeSavings);
fprintf('System flags %.1f%% of content for human review.\n', ...
    reviewItems/length(YTest)*100);
