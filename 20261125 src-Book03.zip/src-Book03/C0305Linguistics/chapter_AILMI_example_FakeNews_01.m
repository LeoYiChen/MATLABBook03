%% chapter_AILMI_example_FakeNews_01.m
% Fake news detection system combining linguistic features, metadata signals, and ensemble classification with interpretability analysis.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_FakeNews_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Fake News Detection System
% Multi-modal approach combining content and network features

fprintf('=== Fake News Detection System ===\n\n');

% - Step 1: Generate Synthetic News Dataset -

fprintf('Step 1: Creating synthetic news article dataset...\n');

% Number of articles
numArticles = 500;

% Generate fake and real news articles with distinctive patterns
articleTexts = strings(numArticles, 1);
articleLabels = zeros(numArticles, 1);  % 0 = Real, 1 = Fake

% Real news templates (factual, balanced, professional)
realTemplates = [
    "Government officials announced new economic policy addressing inflation concerns. " + ...
    "Economists present mixed reactions to proposed measures. Further analysis required.";
    
    "Scientific research published in peer-reviewed journal reveals novel findings. " + ...
    "Experts emphasise need for replication studies before drawing conclusions.";
    
    "International summit addresses climate change cooperation. " + ...
    "Delegates from multiple nations discuss emission reduction strategies and targets.";
    
    "Technology company reports quarterly earnings showing moderate growth. " + ...
    "Industry analysts attribute performance to market conditions and product developments.";
    
    "Public health authorities update vaccination guidelines based on recent data. " + ...
    "Medical professionals recommend following official guidance and consulting doctors."
];

% Fake news templates (sensational, emotional, definitive)
fakeTemplates = [
    "SHOCKING revelation exposes massive government conspiracy! " + ...
    "Insiders confirm everything you feared is TRUE! Share before deleted!";
    
    "BREAKING: Scientists discover miracle cure they don't want you to know! " + ...
    "Big pharma desperately trying to suppress this information! Act now!";
    
    "URGENT: Climate disaster imminent according to secret documents! " + ...
    "Mainstream media covering up the TRUTH! Everyone must see this!";
    
    "Tech giant admits manipulating users in disturbing confession! " + ...
    "Whistleblower reveals shocking practices! This changes everything!";
    
    "Vaccine contains dangerous substances confirmed by anonymous expert! " + ...
    "Authorities hiding risks from public! Share to warn others!"
];

% Generate articles
for articleIdx = 1:numArticles
    if rand() < 0.5
        % Generate real news (balanced, professional)
        templateIdx = randi(size(realTemplates, 1));
        baseText = realTemplates(templateIdx);
        
        % Add moderate language
        additions = [" Research continues.", " Details forthcoming.", ...
            " Experts divided.", " Monitoring situation."];
        baseText = baseText + additions(randi(length(additions)));
        
        articleTexts(articleIdx) = baseText;
        articleLabels(articleIdx) = 0;  % Real
    else
        % Generate fake news (sensational, emotional)
        templateIdx = randi(size(fakeTemplates, 1));
        baseText = fakeTemplates(templateIdx);
        
        % Add emotional appeals
        additions = [" You won't believe this!", " Absolutely shocking!", ...
            " Don't be fooled!", " Wake up people!"];
        baseText = baseText + additions(randi(length(additions)));
        
        articleTexts(articleIdx) = baseText;
        articleLabels(articleIdx) = 1;  % Fake
    end
end

fprintf('  Generated %d articles (%d real, %d fake)\n', numArticles, ...
    sum(articleLabels == 0), sum(articleLabels == 1));
fprintf('  Sample real news: %s...\n', extractBefore(articleTexts(find(articleLabels == 0, 1)), 80));
fprintf('  Sample fake news: %s...\n\n', extractBefore(articleTexts(find(articleLabels == 1, 1)), 80));

% - Step 2: Extract Linguistic Features -

fprintf('Step 2: Extracting linguistic content features...\n');

% Tokenise documents
documents = tokenizedDocument(articleTexts);

% Preprocessing
documentsProcessed = removeStopWords(erasePunctuation(lower(documents)));

% Create bag-of-words
bag = bagOfWords(documentsProcessed);

% TF-IDF features
tfidfFeatures = tfidf(bag);
tfidfFeatures = full(tfidfFeatures);

% Linguistic features
linguisticFeatures = zeros(numArticles, 8);

for articleIdx = 1:numArticles
    text = articleTexts(articleIdx);
    tokens = documents(articleIdx).Vocabulary;
    
    % Feature 1: Sentiment intensity (emotional language)
    emotionalWords = ["shocking", "urgent", "breaking", "truth", "conspiracy", ...
        "miracle", "dangerous", "secret", "massive", "wake"];
    emotionalCount = sum(contains(lower(text), emotionalWords));
    linguisticFeatures(articleIdx, 1) = emotionalCount / max(1, length(tokens));
    
    % Feature 2: Capitalisation (SHOUTING)
    upperCount = sum(isstrprop(char(text), 'upper'));
    linguisticFeatures(articleIdx, 2) = upperCount / max(1, strlength(text));
    
    % Feature 3: Exclamation marks
    exclamationCount = count(text, '!');
    linguisticFeatures(articleIdx, 3) = exclamationCount / max(1, strlength(text)) * 100;
    
    % Feature 4: First-person pronouns
    firstPersonWords = ["i", "we", "my", "our"];
    firstPersonCount = sum(contains(tokens, firstPersonWords));
    linguisticFeatures(articleIdx, 4) = firstPersonCount / max(1, length(tokens));
    
    % Feature 5: Definitive language
    definitiveWords = ["confirm", "prove", "fact", "absolutely", "definitely"];
    definitiveCount = sum(contains(lower(text), definitiveWords));
    linguisticFeatures(articleIdx, 5) = definitiveCount / max(1, length(tokens));
    
    % Feature 6: Imperative verbs (calls to action)
    imperativeWords = ["share", "act", "wake", "see", "warn"];
    imperativeCount = sum(contains(lower(text), imperativeWords));
    linguisticFeatures(articleIdx, 6) = imperativeCount / max(1, length(tokens));
    
    % Feature 7: Lexical diversity (unique words / total words)
    if ~isempty(tokens)
        linguisticFeatures(articleIdx, 7) = length(unique(tokens)) / length(tokens);
    end
    
    % Feature 8: Average word length
    if ~isempty(tokens)
        wordLengths = cellfun(@length, tokens);
        linguisticFeatures(articleIdx, 8) = mean(wordLengths);
    end
end

fprintf('  Extracted 8 linguistic features + %d TF-IDF features\n', size(tfidfFeatures, 2));
fprintf('  Total content features: %d\n\n', size(linguisticFeatures, 2) + size(tfidfFeatures, 2));

% - Step 3: Generate Network Propagation Features -

fprintf('Step 3: Simulating network propagation features...\n');

% Network features (in real system, extracted from sharing patterns)
networkFeatures = zeros(numArticles, 5);

for articleIdx = 1:numArticles
    isFake = articleLabels(articleIdx);
    
    % Feature 1: Spread velocity (shares per hour)
    % Fake news spreads faster
    if isFake
        networkFeatures(articleIdx, 1) = 50 + randn() * 20;
    else
        networkFeatures(articleIdx, 1) = 20 + randn() * 10;
    end
    networkFeatures(articleIdx, 1) = max(1, networkFeatures(articleIdx, 1));
    
    % Feature 2: Source credibility score
    % Real news from more credible sources
    if isFake
        networkFeatures(articleIdx, 2) = 0.3 + rand() * 0.3;
    else
        networkFeatures(articleIdx, 2) = 0.6 + rand() * 0.4;
    end
    
    % Feature 3: Bot sharing ratio
    % Fake news shared more by bots
    if isFake
        networkFeatures(articleIdx, 3) = 0.4 + rand() * 0.3;
    else
        networkFeatures(articleIdx, 3) = 0.1 + rand() * 0.2;
    end
    
    % Feature 4: Cross-verification (other sources reporting)
    % Real news corroborated by multiple sources
    if isFake
        networkFeatures(articleIdx, 4) = randi([0, 2]);
    else
        networkFeatures(articleIdx, 4) = randi([3, 8]);
    end
    networkFeatures(articleIdx, 4) = networkFeatures(articleIdx, 4) / 10;
    
    % Feature 5: User engagement rate
    % Fake news often higher engagement
    if isFake
        networkFeatures(articleIdx, 5) = 0.15 + rand() * 0.15;
    else
        networkFeatures(articleIdx, 5) = 0.08 + rand() * 0.10;
    end
end

fprintf('  Generated 5 network propagation features\n');
fprintf('  Average spread velocity: %.1f shares/hour\n', mean(networkFeatures(:, 1)));
fprintf('  Average source credibility: %.3f\n\n', mean(networkFeatures(:, 2)));

% - Step 4: Combine Features and Train Classifier -

fprintf('Step 4: Training fake news detection classifier...\n');

% Combine all features
% Use subset of TF-IDF (top variance features)
tfidfVariance = var(tfidfFeatures, 0, 1);
[~, topVarianceIdx] = sort(tfidfVariance, 'descend');
numTfidfFeatures = min(50, size(tfidfFeatures, 2));
selectedTfidf = tfidfFeatures(:, topVarianceIdx(1:numTfidfFeatures));

allFeatures = [linguisticFeatures, selectedTfidf, networkFeatures];

fprintf('  Combined feature matrix: %d samples x %d features\n', size(allFeatures));

% Split into training and testing
rng(42);
trainRatio = 0.8;
numTrain = round(numArticles * trainRatio);
trainIdx = randperm(numArticles, numTrain);
testIdx = setdiff(1:numArticles, trainIdx);

XTrain = allFeatures(trainIdx, :);
YTrain = articleLabels(trainIdx);
XTest = allFeatures(testIdx, :);
YTest = articleLabels(testIdx);

% Train ensemble classifier (Random Forest via bagging)
fakeNewsClassifier = fitcensemble(XTrain, YTrain, ...
    'Method', 'Bag', ...
    'NumLearningCycles', 100, ...
    'Learners', 'tree');

fprintf('  Ensemble classifier trained (100 decision trees)\n\n');

% - Step 5: Evaluate Performance -

fprintf('Step 5: Evaluating classifier performance...\n');

% Predictions on test set
[predictedLabels, scores] = predict(fakeNewsClassifier, XTest);

% Calculate metrics
accuracy = sum(predictedLabels == YTest) / length(YTest);

% Confusion matrix
confMat = confusionmat(YTest, predictedLabels);
trueNeg = confMat(1, 1);
falsePos = confMat(1, 2);
falseNeg = confMat(2, 1);
truePos = confMat(2, 2);

% Precision, Recall, F1
precision = truePos / (truePos + falsePos);
recall = truePos / (truePos + falseNeg);
f1Score = 2 * (precision * recall) / (precision + recall);

fprintf('  Detection Performance:\n');
fprintf('    Accuracy:  %.2f%%\n', accuracy * 100);
fprintf('    Precision: %.2f%% (of predicted fake, how many truly fake)\n', precision * 100);
fprintf('    Recall:    %.2f%% (of truly fake, how many detected)\n', recall * 100);
fprintf('    F1 Score:  %.2f%%\n\n', f1Score * 100);

fprintf('  Confusion Matrix:\n');
fprintf('                Predicted Real  Predicted Fake\n');
fprintf('    True Real:  %13*d  %14*d\n', trueNeg, falsePos);
fprintf('    True Fake:  %13*d  %14*d\n\n', falseNeg, truePos);

% - Step 6: Feature Importance Analysis -

fprintf('Step 6: Analysing feature importance...\n');

% Estimate feature importance using permutation approach
% (full importance calculation computationally expensive for ensemble)

% For demonstration, estimate from single tree
singleTree = fitctree(XTrain, YTrain);
importance = predictorImportance(singleTree);

% Get top features
[sortedImportance, importanceIdx] = sort(importance, 'descend');
topFeatureIndices = importanceIdx(1:10);

featureNames = [
    "Emotional Words", "Capitalisation", "Exclamations", ...
    "First Person", "Definitive Language", "Imperatives", ...
    "Lexical Diversity", "Avg Word Length", ...
    repmat("TF-IDF", 1, numTfidfFeatures), ...
    "Spread Velocity", "Source Credibility", "Bot Ratio", ...
    "Cross-Verification", "Engagement Rate"
];

fprintf('  Top 10 most important features:\n');
for i = 1:10
    featIdx = topFeatureIndices(i);
    if featIdx <= length(featureNames)
        fprintf('    %2*d. %s (importance: %.4f)\n', i, ...
            featureNames(featIdx), sortedImportance(i));
    end
end
fprintf('\n');

% - Step 7: Cross-Validation -

fprintf('Step 7: Performing cross-validation...\n');

% 5-fold cross-validation
cvModel = crossval(fakeNewsClassifier, 'KFold', 5);
cvAccuracy = 1 - kfoldLoss(cvModel);

fprintf('  5-fold cross-validation accuracy: %.2f%%\n', cvAccuracy * 100);
fprintf('  Standard error: %.2f%%\n\n', kfoldLoss(cvModel, 'Mode', 'individual') * 100);

% - Step 8: Analyse Misclassifications -

fprintf('Step 8: Analysing misclassification patterns...\n');

% Find false positives and false negatives
falsePosIdx = testIdx(YTest == 0 & predictedLabels == 1);
falseNegIdx = testIdx(YTest == 1 & predictedLabels == 0);

fprintf('  False Positives (real news classified as fake): %d\n', length(falsePosIdx));
if ~isempty(falsePosIdx)
    fprintf('    Example: %s...\n', extractBefore(articleTexts(falsePosIdx(1)), 60));
end

fprintf('  False Negatives (fake news classified as real): %d\n', length(falseNegIdx));
if ~isempty(falseNegIdx)
    fprintf('    Example: %s...\n\n', extractBefore(articleTexts(falseNegIdx(1)), 60));
end

% - Step 9: Visualisation -

fprintf('Step 9: Generating detection performance visualisations...\n');

figure('Position', [100, 100, 1800, 1200]);

% Plot 1: ROC Curve
subplot(2, 4, 1);
[X, Y, ~, AUC] = perfcurve(YTest, scores(:, 2), 1);
plot(X, Y, 'b-', 'LineWidth', 2);
hold on;
plot([0, 1], [0, 1], 'r-', 'LineWidth', 1);
hold off;
xlabel('False Positive Rate');
ylabel('True Positive Rate');
title(sprintf('ROC Curve (AUC = %.3f)', AUC));
legend('Classifier', 'Random', 'Location', 'southeast');
grid on;

% Plot 2: Confusion Matrix
subplot(2, 4, 2);
confMatNorm = confMat ./ sum(confMat, 2);  % Normalise by row
imagesc(confMatNorm);
colorbar;
colormap(gca, hot);
xlabel('Predicted Label');
ylabel('True Label');
title('Normalised Confusion Matrix');
set(gca, 'XTick', [1, 2], 'XTickLabel', {'Real', 'Fake'}, ...
    'YTick', [1, 2], 'YTickLabel', {'Real', 'Fake'});

% Plot 3: Feature importance
subplot(2, 4, 3);
bar(sortedImportance(1:10), 'FaceColor', [0.3, 0.6, 0.9]);
xlabel('Feature Rank');
ylabel('Importance Score');
title('Top 10 Feature Importance');
grid on;

% Plot 4: Prediction confidence distribution
subplot(2, 4, 4);
fakeScores = scores(YTest == 1, 2);  % Scores for truly fake news
realScores = scores(YTest == 0, 2);  % Scores for truly real news
histogram(realScores, 20, 'Normalization', 'probability', 'FaceAlpha', 0.5);
hold on;
histogram(fakeScores, 20, 'Normalization', 'probability', 'FaceAlpha', 0.5);
hold off;
xlabel('Fake News Probability');
ylabel('Density');
title('Prediction Confidence Distribution');
legend('True Real', 'True Fake', 'Location', 'best');
grid on;

% Plot 5: Linguistic feature comparison
subplot(2, 4, 5);
realLingMean = mean(linguisticFeatures(articleLabels == 0, :), 1);
fakeLingMean = mean(linguisticFeatures(articleLabels == 1, :), 1);
featuresToPlot = 1:6;
bar([realLingMean(featuresToPlot); fakeLingMean(featuresToPlot)]', 'grouped');
set(gca, 'XTickLabel', featureNames(featuresToPlot), 'XTickLabelRotation', 45);
ylabel('Average Value');
title('Linguistic Features: Real vs Fake');
legend('Real News', 'Fake News', 'Location', 'best');
grid on;

% Plot 6: Network feature comparison
subplot(2, 4, 6);
realNetMean = mean(networkFeatures(articleLabels == 0, :), 1);
fakeNetMean = mean(networkFeatures(articleLabels == 1, :), 1);
netFeatureNames = ["Spread Velocity", "Source Cred.", "Bot Ratio", ...
    "Cross-Verif.", "Engagement"];
bar([realNetMean; fakeNetMean]', 'grouped');
set(gca, 'XTickLabel', netFeatureNames, 'XTickLabelRotation', 45);
ylabel('Average Value');
title('Network Features: Real vs Fake');
legend('Real News', 'Fake News', 'Location', 'best');
grid on;

% Plot 7: Performance metrics comparison
subplot(2, 4, 7);
metrics = [accuracy, precision, recall, f1Score];
bar(metrics, 'FaceColor', [0.6, 0.4, 0.8]);
set(gca, 'XTickLabel', {'Accuracy', 'Precision', 'Recall', 'F1 Score'}, ...
    'XTickLabelRotation', 45);
ylabel('Score');
title('Detection Performance Metrics');
ylim([0, 1]);
grid on;

% Plot 8: Misclassification analysis
subplot(2, 4, 8);
misclassTypes = [falsePos, falseNeg];
bar(misclassTypes, 'FaceColor', [0.8, 0.5, 0.3]);
set(gca, 'XTickLabel', {'False Positives', 'False Negatives'});
ylabel('Count');
title('Misclassification Breakdown');
grid on;

sgtitle('Fake News Detection System Performance Analysis', 'FontSize', 14, ...
    'FontWeight', 'bold');

print('fake_news_detection_analysis', '-dpng', '-r300');

fprintf('\nFake news detection system complete!\n');
fprintf('Achieved %.2f%% accuracy with %.2f%% precision and %.2f%% recall\n', ...
    accuracy * 100, precision * 100, recall * 100);
fprintf('System ready for deployment with continuous monitoring.\n');
