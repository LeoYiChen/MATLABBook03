%% chapter_AILMI_example_AI_01.m
% Naive Bayes sentiment classification in MATLAB.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_AI_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Sample training data for sentiment classification
trainingDocuments = [
    "This product is absolutely wonderful and exceeded expectations.";
    "Terrible quality, completely disappointed with purchase.";
    "Amazing features, highly recommend to everyone.";
    "Waste of money, poor design and functionality.";
    "Outstanding performance, best purchase this year.";
    "Defective product, requesting immediate refund.";
    "Excellent value, extremely satisfied with quality.";
    "Horrible experience, would not recommend.";
    "Superb craftsmanship, exceeded all expectations.";
    "Completely useless, total waste of time."];

% Sentiment labels: 1 = positive, 0 = negative
trainingLabels = categorical([1; 0; 1; 0; 1; 0; 1; 0; 1; 0]);

% Preprocess training documents
trainTokens = tokenizedDocument(trainingDocuments);
trainTokens = erasePunctuation(lower(trainTokens));
trainTokens = removeStopWords(trainTokens);
trainTokens = removeShortWords(trainTokens, 2);

% Create bag-of-words model
bag = bagOfWords(trainTokens);

% Convert to document-term matrix
trainMatrix = bag.Counts;

% Train Naive Bayes classifier
naiveBayesModel = fitcnb(trainMatrix, trainingLabels);

fprintf('Naive Bayes Model Training Completed\n');
fprintf('Number of features: %d\n', size(trainMatrix, 2));
fprintf('Training accuracy: %.2f%%\n', ...
        (1 - resubLoss(naiveBayesModel)) * 100);

% Test documents for prediction
testDocuments = [
    "This is an excellent product with great features.";
    "Poor quality and terrible customer service.";
    "Absolutely fantastic, highly recommended purchase.";
    "Disappointing performance, not worth the price."];

% Preprocess and encode test documents
testTokens = tokenizedDocument(testDocuments);
testTokens = erasePunctuation(lower(testTokens));
testTokens = removeStopWords(testTokens);
testTokens = removeShortWords(testTokens, 2);

% Encode using training vocabulary
testMatrix = encode(bag, testTokens);

% Make predictions
[predictedLabels, posteriorProbs] = predict(naiveBayesModel, testMatrix);

% Display results
fprintf('\nSentiment Classification Results:\n');
fprintf('%-60*s %-12*s %-10*s\n', 'Document', 'Prediction', 'Confidence');
fprintf('%-60*s %-12*s %-10*s\n', repmat('-', 1, 60), ...
        repmat('-', 1, 12), repmat('-', 1, 10));

for i = 1:length(testDocuments)
    sentiment = char(predictedLabels(i));
    confidence = max(posteriorProbs(i, :)) * 100;
    
    % Truncate long documents for display
    docDisplay = char(testDocuments(i));
    if length(docDisplay) > 55
        docDisplay = [docDisplay(1:52), '...'];
    end
    
    fprintf('%-60*s %-12*s %.2f%%\n', docDisplay, sentiment, confidence);
end

% Analyse feature importance (log probability ratios)
[~, scores] = predictorImportance(naiveBayesModel);
[sortedScores, indices] = sort(scores, 'descend');

fprintf('\nMost discriminative features:\n');
vocabulary = bag.Vocabulary;
for i = 1:min(10, length(indices))
    fprintf('  %d. %s (score: %.4f)\n', ...
            i, vocabulary(indices(i)), sortedScores(i));
end

% Visualise posterior probabilities
figure('Position', [100, 100, 800, 500]);

subplot(1, 2, 1);
bar(posteriorProbs);
xlabel('Test Document');
ylabel('Posterior Probability');
title('Classification Probabilities');
legend({'Negative', 'Positive'}, 'Location', 'best');
grid on;

subplot(1, 2, 2);
confusionchart(trainingLabels, predict(naiveBayesModel, trainMatrix));
title('Training Set Confusion Matrix');
