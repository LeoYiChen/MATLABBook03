%% chapter_AILMI_example_sentiment_01.m
% Comprehensive lexicon-based sentiment analysis with visualisation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_sentiment_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Lexicon-Based Sentiment Analysis
% Demonstrates dictionary-based opinion mining with linguistic rules

fprintf('=== Lexicon-Based Sentiment Analysis ===\n\n');

% - Step 1: Create Sentiment Lexicon -

fprintf('Step 1: Constructing sentiment lexicon...\n');

% Define positive words with scores
positiveWords = ["excellent", "great", "wonderful", "fantastic", "amazing", ...
    "good", "best", "love", "perfect", "brilliant", "outstanding", ...
    "beautiful", "happy", "delightful", "impressive", "superb", ...
    "awesome", "terrific", "fabulous", "exceptional", "magnificent"];

positiveScores = [0.8, 0.7, 0.75, 0.8, 0.85, 0.6, 0.9, 0.8, 0.85, 0.8, ...
    0.9, 0.75, 0.7, 0.7, 0.75, 0.8, 0.85, 0.75, 0.8, 0.9, 0.85];

% Define negative words with scores
negativeWords = ["bad", "terrible", "awful", "poor", "disappointing", ...
    "worst", "hate", "horrible", "disgusting", "pathetic", "useless", ...
    "terrible", "dreadful", "appalling", "abysmal", "mediocre", ...
    "inferior", "defective", "faulty", "substandard", "inadequate"];

negativeScores = [-0.7, -0.8, -0.85, -0.7, -0.75, -0.9, -0.8, -0.85, ...
    -0.9, -0.75, -0.8, -0.8, -0.85, -0.9, -0.95, -0.6, -0.7, ...
    -0.75, -0.7, -0.65, -0.7];

% Define intensifiers and modifiers
intensifiers = ["very", "extremely", "incredibly", "absolutely", "completely", ...
    "utterly", "totally", "really", "particularly", "especially"];
intensifierBoost = 0.3;  % Boost sentiment score by this amount

negators = ["not", "no", "never", "neither", "nobody", "nothing", ...
    "nowhere", "hardly", "scarcely", "barely"];

% Combine into lexicon structure
lexicon = struct();
for i = 1:length(positiveWords)
    lexicon.*(positiveWords{i}) = positiveScores(i);
end
for i = 1:length(negativeWords)
    lexicon.*(negativeWords{i}) = negativeScores(i);
end

fprintf('  Lexicon constructed:\n');
fprintf('    Positive words: %d\n', length(positiveWords));
fprintf('    Negative words: %d\n', length(negativeWords));
fprintf('    Intensifiers: %d\n', length(intensifiers));
fprintf('    Negators: %d\n\n', length(negators));

% - Step 2: Sample Documents -

fprintf('Step 2: Preparing sample documents...\n');

sampleTexts = [
    "This product is excellent and works perfectly"
    "Absolutely terrible experience with poor customer service"
    "Good quality but not great value for money"
    "I love this item it is fantastic and amazing"
    "Worst purchase ever completely disappointed"
    "Not bad for the price quite acceptable"
    "Beautiful design but awful performance"
    "Exceptional quality really impressed with this"
    "Mediocre at best nothing special here"
    "Absolutely brilliant highly recommended"
    "Terrible quality very disappointing experience"
    "Great product excellent value perfect condition"
    "Not good at all quite poor actually"
    "Outstanding performance incredibly happy with purchase"
    "Useless product complete waste of money"
    "Wonderful experience very satisfied customer"
    "Dreadful service will never buy again"
    "Perfect product exactly what I wanted"
    "Horrible quality extremely disappointed"
    "Good product but shipping was terrible"
];

numDocuments = length(sampleTexts);
fprintf('  Number of documents: %d\n\n', numDocuments);

% - Step 3: Analyse Sentiment -

fprintf('Step 3: Analysing document sentiment...\n');

sentimentScores = zeros(numDocuments, 1);
matchedWordCounts = zeros(numDocuments, 1);

for docIdx = 1:numDocuments
    text = lower(sampleTexts{docIdx});
    
    % Tokenise (split into words)
    text = erase(text, [".", ",", "!", "?"]);  % Remove punctuation
    tokens = split(text);
    tokens = tokens(strlength(tokens) > 0);  % Remove empty strings
    
    score = 0;
    wordCount = 0;
    
    % Process each token
    for tokenIdx = 1:length(tokens)
        token = char(tokens{tokenIdx});
        
        % Check for negation in previous word
        negated = false;
        if tokenIdx > 1
            prevToken = char(tokens{tokenIdx-1});
            if any(strcmp(prevToken, negators))
                negated = true;
            end
        end
        
        % Check for intensifier in previous word
        intensified = false;
        if tokenIdx > 1
            prevToken = char(tokens{tokenIdx-1});
            if any(strcmp(prevToken, intensifiers))
                intensified = true;
            end
        end
        
        % Look up sentiment score
        if isfield(lexicon, token)
            wordScore = lexicon.*(token);
            
            % Apply negation (reverse polarity)
            if negated
                wordScore = -wordScore;
            end
            
            % Apply intensification
            if intensified
                wordScore = wordScore * (1 + intensifierBoost);
            end
            
            score = score + wordScore;
            wordCount = wordCount + 1;
        end
    end
    
    % Normalise by number of matched words
    if wordCount > 0
        sentimentScores(docIdx) = score / wordCount;
    else
        sentimentScores(docIdx) = 0;
    end
    
    matchedWordCounts(docIdx) = wordCount;
end

fprintf('  Sentiment analysis complete.\n');
fprintf('  Mean sentiment score: %.3f\n', mean(sentimentScores));
fprintf('  Std deviation: %.3f\n', std(sentimentScores));
fprintf('  Score range: [%.3f, %.3f]\n\n', ...
    min(sentimentScores), max(sentimentScores));

% - Step 4: Classify Sentiment -

fprintf('Step 4: Classifying sentiment polarity...\n');

% Define thresholds
positiveThreshold = 0.15;
negativeThreshold = -0.15;

% Classify
sentimentLabels = categorical(zeros(numDocuments, 1), ...
    [0, 1, 2], {'Negative', 'Neutral', 'Positive'});

for i = 1:numDocuments
    if sentimentScores(i) > positiveThreshold
        sentimentLabels(i) = 'Positive';
    elseif sentimentScores(i) < negativeThreshold
        sentimentLabels(i) = 'Negative';
    else
        sentimentLabels(i) = 'Neutral';
    end
end

% Count distribution
posCount = sum(sentimentLabels == 'Positive');
negCount = sum(sentimentLabels == 'Negative');
neuCount = sum(sentimentLabels == 'Neutral');

fprintf('  Classification thresholds:\n');
fprintf('    Positive: > %.2f\n', positiveThreshold);
fprintf('    Negative: < %.2f\n', negativeThreshold);
fprintf('    Neutral: otherwise\n\n');

fprintf('  Sentiment distribution:\n');
fprintf('    Positive: %d (%.1f%%)\n', posCount, 100*posCount/numDocuments);
fprintf('    Negative: %d (%.1f%%)\n', negCount, 100*negCount/numDocuments);
fprintf('    Neutral: %d (%.1f%%)\n\n', neuCount, 100*neuCount/numDocuments);

% - Step 5: Detailed Results -

fprintf('Step 5: Detailed sentiment results:\n\n');

resultsTable = table(sampleTexts, sentimentScores, matchedWordCounts, ...
    sentimentLabels, 'VariableNames', ...
    {'Text', 'Score', 'MatchedWords', 'Sentiment'});

% Display first 10 results
disp(resultsTable(1:10, :));

% - Step 6: Visualisation -

fprintf('\nStep 6: Visualising sentiment analysis results...\n');

figure('Position', [100, 100, 1400, 900]);

% Plot 1: Sentiment score distribution
subplot(2, 3, 1);
histogram(sentimentScores, 20, 'FaceColor', [0.3, 0.6, 0.9]);
xlabel('Sentiment Score');
ylabel('Frequency');
title('Sentiment Score Distribution');
grid on;
hold on;
xline(positiveThreshold, 'g-', 'LineWidth', 2, 'Label', 'Positive');
xline(negativeThreshold, 'r-', 'LineWidth', 2, 'Label', 'Negative');
hold off;

% Plot 2: Sentiment classification pie chart
subplot(2, 3, 2);
sentimentCounts = [posCount, neuCount, negCount];
sentimentNames = {'Positive', 'Neutral', 'Negative'};
pie(sentimentCounts, sentimentNames);
title('Sentiment Classification Distribution');
colormap([0.2, 0.8, 0.2; 0.8, 0.8, 0.2; 0.8, 0.2, 0.2]);

% Plot 3: Sentiment scores timeline
subplot(2, 3, 3);
plot(1:numDocuments, sentimentScores, 'o-', 'LineWidth', 1.5, ...
    'MarkerSize', 6, 'MarkerFaceColor', 'b');
hold on;
yline(positiveThreshold, 'g-', 'LineWidth', 1.5);
yline(negativeThreshold, 'r-', 'LineWidth', 1.5);
yline(0, 'k:', 'LineWidth', 1);
hold off;
xlabel('Document Index');
ylabel('Sentiment Score');
title('Sentiment Scores Across Documents');
grid on;

% Plot 4: Matched word count analysis
subplot(2, 3, 4);
bar(matchedWordCounts, 'FaceColor', [0.9, 0.6, 0.3]);
xlabel('Document Index');
ylabel('Number of Matched Words');
title('Lexicon Coverage Per Document');
grid on;

% Plot 5: Scatter plot of matched words vs sentiment
subplot(2, 3, 5);
scatter(matchedWordCounts, sentimentScores, 80, ...
    double(sentimentLabels), 'filled');
xlabel('Number of Matched Words');
ylabel('Sentiment Score');
title('Coverage vs Sentiment');
colormap([0.8, 0.2, 0.2; 0.8, 0.8, 0.2; 0.2, 0.8, 0.2]);
colorbar('Ticks', [1, 2, 3], ...
    'TickLabels', {'Negative', 'Neutral', 'Positive'});
grid on;

% Plot 6: Positive vs negative word contribution
subplot(2, 3, 6);
posContribution = zeros(numDocuments, 1);
negContribution = zeros(numDocuments, 1);

for docIdx = 1:numDocuments
    text = lower(sampleTexts{docIdx});
    text = erase(text, [".", ",", "!", "?"]);
    tokens = split(text);
    tokens = tokens(strlength(tokens) > 0);
    
    for tokenIdx = 1:length(tokens)
        token = char(tokens{tokenIdx});
        if isfield(lexicon, token)
            wordScore = lexicon.*(token);
            if wordScore > 0
                posContribution(docIdx) = posContribution(docIdx) + wordScore;
            else
                negContribution(docIdx) = negContribution(docIdx) + abs(wordScore);
            end
        end
    end
end

bar(1:numDocuments, [posContribution, negContribution], 'stacked');
xlabel('Document Index');
ylabel('Cumulative Score Contribution');
title('Positive vs Negative Word Contributions');
legend('Positive Words', 'Negative Words', 'Location', 'best');
grid on;

sgtitle('Lexicon-Based Sentiment Analysis: Comprehensive Results', ...
    'FontSize', 14, 'FontWeight', 'bold');

print('lexicon_sentiment_analysis', '-dpng', '-r300');

fprintf('\nLexicon-based sentiment analysis demonstration complete!\n');
