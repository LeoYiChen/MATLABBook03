%% chapter_AILMI_example_AI_07.m
% Transfer learning with pre-trained language models in MATLAB.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_AI_07
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Transfer Learning for Sentiment Classification

% Load pre-trained word embedding model
fprintf('Transfer Learning Demonstration\n');
fprintf('Loading pre-trained word embeddings...\n');

embModel = fastTextWordEmbedding;
embDim = embModel.Dimension(2);

fprintf('  Embedding dimension: %d\n', embDim);
fprintf('  Vocabulary size: %d words\n\n', embModel.Dimension(1));

% Training data for fine-tuning
trainingReviews = [ ...
    "This movie is absolutely fantastic and entertaining."; ...
    "Terrible film, complete waste of time and money."; ...
    "Brilliant performances, highly recommend watching."; ...
    "Boring plot, disappointing and poorly executed."; ...
    "Outstanding cinematography, truly masterpiece."; ...
    "Awful script, terrible acting throughout."; ...
    "Excellent storytelling, engaging from start."; ...
    "Horrible pacing, could not finish watching."; ...
    "Wonderful direction, exceeded all expectations."; ...
    "Dreadful movie, worst film this year."; ...
    "Amazing special effects, visually stunning."; ...
    "Poor quality, not worth rental price."; ...
    "Superb cast, memorable emotional experience."; ...
    "Disappointing sequel, failed to deliver."; ...
    "Incredible soundtrack, perfectly captures mood."; ...
    "Unwatchable disaster, avoid at all costs."];

sentimentLabels = categorical([1; 0; 1; 0; 1; 0; 1; 0; ...
                               1; 0; 1; 0; 1; 0; 1; 0]);

fprintf('Training dataset: %d reviews\n', length(trainingReviews));

% Preprocess reviews
docs = tokenizedDocument(trainingReviews);
docs = erasePunctuation(lower(docs));
docs = removeStopWords(docs);

% Create feature vectors using pre-trained embeddings
maxSeqLen = 15;
XTrain = zeros(embDim, maxSeqLen, numel(docs));

for i = 1:numel(docs)
    words = string(docs(i).Vocabulary);
    numWords = min(numel(words), maxSeqLen);
    
    for j = 1:numWords
        % Use pre-trained embeddings (transfer learning)
        if isVocabularyWord(embModel, words(j))
            wordVec = word2vec(embModel, words(j));
            XTrain(:, j, i) = wordVec;
        else
            % Unknown words: use zero vector
            XTrain(:, j, i) = zeros(embDim, 1);
        end
    end
end

% Define classification architecture
% (freezing embedding layer, training classifier)
numClasses = 2;

layers = [ ...
    sequenceInputLayer(embDim, 'Name', 'input')
    lstmLayer(128, 'OutputMode', 'last', 'Name', 'lstm')
    dropoutLayer(0.3, 'Name', 'dropout')
    fullyConnectedLayer(64, 'Name', 'fc1')
    reluLayer('Name', 'relu')
    fullyConnectedLayer(numClasses, 'Name', 'fc2')
    softmaxLayer('Name', 'softmax')
    classificationLayer('Name', 'output')];

% Training options for fine-tuning
options = trainingOptions('adam', ...
    'MaxEpochs', 50, ...
    'MiniBatchSize', 4, ...
    'InitialLearnRate', 0.001, ...
    'Shuffle', 'every-epoch', ...
    'ValidationFrequency', 10, ...
    'Verbose', false, ...
    'Plots', 'none');

fprintf('\nFine-tuning classification model...\n');

% Train classifier
net = trainNetwork(XTrain, sentimentLabels, layers, options);

fprintf('Fine-tuning completed.\n\n');

% Evaluate on training set
trainPredictions = classify(net, XTrain);
trainAccuracy = sum(trainPredictions == sentimentLabels) / ...
                numel(sentimentLabels) * 100;

fprintf('Training accuracy: %.2f%%\n\n', trainAccuracy);

% Test on new reviews
testReviews = [ ...
    "Absolutely brilliant film, loved every minute."; ...
    "Complete disaster, terrible in every aspect."; ...
    "Wonderful experience, highly entertaining."; ...
    "Waste of money, extremely disappointing."];

fprintf('Testing transfer learned model:\n\n');

% Preprocess test reviews
testDocs = tokenizedDocument(testReviews);
testDocs = erasePunctuation(lower(testDocs));
testDocs = removeStopWords(testDocs);

% Create test features
XTest = zeros(embDim, maxSeqLen, numel(testDocs));

for i = 1:numel(testDocs)
    words = string(testDocs(i).Vocabulary);
    numWords = min(numel(words), maxSeqLen);
    
    for j = 1:numWords
        if isVocabularyWord(embModel, words(j))
            wordVec = word2vec(embModel, words(j));
            XTest(:, j, i) = wordVec;
        end
    end
end

% Make predictions
[predictions, scores] = classify(net, XTest);

% Display results
sentimentNames = ["Negative", "Positive"];

for i = 1:length(testReviews)
    fprintf('Review %d: "%s"\n', i, testReviews(i));
    fprintf('  Prediction: %s\n', sentimentNames(double(predictions(i))));
    fprintf('  Confidence: %.2f%%\n', max(scores(i, :)) * 100);
    fprintf('  Score distribution: [Negative: %.3f, Positive: %.3f]\n\n', ...
            scores(i, 1), scores(i, 2));
end

% Compare with baseline (no transfer learning)
fprintf('Comparing with baseline (random embeddings)...\n');

% Train model with random embeddings
XBaseline = randn(embDim, maxSeqLen, numel(docs));
netBaseline = trainNetwork(XBaseline, sentimentLabels, ...
                          layers, options);

trainPredBaseline = classify(netBaseline, XBaseline);
baselineAccuracy = sum(trainPredBaseline == sentimentLabels) / ...
                   numel(sentimentLabels) * 100;

fprintf('Baseline training accuracy: %.2f%%\n', baselineAccuracy);
fprintf('Transfer learning improvement: %.2f%%\n\n', ...
        trainAccuracy - baselineAccuracy);

% Visualise learned representations
figure('Position', [100, 100, 1400, 500]);

% Training loss comparison (simulated)
subplot(1, 3, 1);
epochs = 1:50;
transferLoss = 0.8 * exp(-epochs/15) + 0.1;
baselineLoss = 0.9 * exp(-epochs/25) + 0.2;

plot(epochs, transferLoss, 'LineWidth', 2, 'DisplayName', ...
     'Transfer Learning');
hold on;
plot(epochs, baselineLoss, 'LineWidth', 2, 'DisplayName', ...
     'Random Init');
xlabel('Epoch');
ylabel('Loss');
title('Training Loss Comparison');
legend('Location', 'best');
grid on;
hold off;

% Confusion matrix
subplot(1, 3, 2);
confusionchart(sentimentLabels, trainPredictions);
title('Transfer Learning Performance');

% Feature space visualisation
subplot(1, 3, 3);
% Extract features from penultimate layer
penultimateLayer = 'fc1';
features = activations(net, XTrain, penultimateLayer, ...
                      'OutputAs', 'columns');

% Apply t-SNE for visualisation
rng(42);
embeddedFeatures = tsne(features', 'NumDimensions', 2);

gscatter(embeddedFeatures(:, 1), embeddedFeatures(:, 2), ...
         sentimentLabels, 'rb', 'ox', 10);
xlabel('t-SNE Dimension 1');
ylabel('t-SNE Dimension 2');
title('Learned Feature Space');
legend('Negative', 'Positive');
grid on;

fprintf('Visualisations complete.\n');
