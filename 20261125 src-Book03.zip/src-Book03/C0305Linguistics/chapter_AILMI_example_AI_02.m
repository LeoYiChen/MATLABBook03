%% chapter_AILMI_example_AI_02.m
% Support Vector Machine text classification with kernel comparison.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_AI_02
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Training corpus for multi-class topic classification
trainingTexts = [
    "Machine learning algorithms classify data patterns.";
    "Neural networks process information like human brain.";
    "Stock markets fluctuate based on economic indicators.";
    "Investment portfolios require diversification strategy.";
    "Protein synthesis occurs within cellular ribosomes.";
    "DNA replication ensures genetic information transfer.";
    "Quantum mechanics describes subatomic particle behaviour.";
    "Thermodynamics governs energy transformation processes.";
    "Deep learning revolutionises computer vision tasks.";
    "Artificial intelligence transforms healthcare diagnostics.";
    "Financial derivatives hedge investment risk exposure.";
    "Cryptocurrency markets exhibit high volatility patterns.";
    "Cellular respiration generates adenosine triphosphate.";
    "Gene expression regulates protein production levels.";
    "Particle physics explores fundamental force interactions.";
    "Statistical mechanics connects microscopic molecular motion."];

% Topic labels: 1 = Computer Science, 2 = Finance, 
%               3 = Biology, 4 = Physics
topicLabels = categorical([1; 1; 2; 2; 3; 3; 4; 4; ...
                           1; 1; 2; 2; 3; 3; 4; 4]);

% Preprocess documents
trainTokens = tokenizedDocument(trainingTexts);
trainTokens = erasePunctuation(lower(trainTokens));
trainTokens = removeStopWords(trainTokens);

% Create TF-IDF representation
bag = bagOfWords(trainTokens);
trainMatrix = tfidf(bag);

% Train SVM with different kernels
fprintf('Training SVM Classifiers with Different Kernels\n\n');

% Linear kernel SVM
svmLinear = fitcecoc(trainMatrix, topicLabels, ...
                     'Learners', templateSVM('KernelFunction', 'linear'));

% RBF kernel SVM
svmRBF = fitcecoc(trainMatrix, topicLabels, ...
                  'Learners', templateSVM('KernelFunction', 'rbf'));

% Polynomial kernel SVM
svmPoly = fitcecoc(trainMatrix, topicLabels, ...
                   'Learners', templateSVM('KernelFunction', 'polynomial', ...
                                          'PolynomialOrder', 2));

% Evaluate training accuracy
linearAcc = (1 - resubLoss(svmLinear)) * 100;
rbfAcc = (1 - resubLoss(svmRBF)) * 100;
polyAcc = (1 - resubLoss(svmPoly)) * 100;

fprintf('Training Accuracies:\n');
fprintf('  Linear Kernel:     %.2f%%\n', linearAcc);
fprintf('  RBF Kernel:        %.2f%%\n', rbfAcc);
fprintf('  Polynomial Kernel: %.2f%%\n', polyAcc);

% Cross-validation for generalisation estimate
cvLinear = crossval(svmLinear, 'KFold', 4);
cvRBF = crossval(svmRBF, 'KFold', 4);
cvPoly = crossval(svmPoly, 'KFold', 4);

cvLinearAcc = (1 - kfoldLoss(cvLinear)) * 100;
cvRBFAcc = (1 - kfoldLoss(cvRBF)) * 100;
cvPolyAcc = (1 - kfoldLoss(cvPoly)) * 100;

fprintf('\nCross-Validation Accuracies (4-fold):\n');
fprintf('  Linear Kernel:     %.2f%%\n', cvLinearAcc);
fprintf('  RBF Kernel:        %.2f%%\n', cvRBFAcc);
fprintf('  Polynomial Kernel: %.2f%%\n', cvPolyAcc);

% Test documents
testTexts = [
    "Convolutional neural networks excel at image recognition.";
    "Portfolio optimisation minimises risk whilst maximising returns.";
    "Mitochondria serve as cellular powerhouse organelles.";
    "Quantum entanglement demonstrates non-local correlations."];

testTokens = tokenizedDocument(testTexts);
testTokens = erasePunctuation(lower(testTokens));
testTokens = removeStopWords(testTokens);
testMatrix = tfidf(bag, encode(bag, testTokens));

% Predictions using best model (RBF kernel)
[predictedLabels, scores] = predict(svmRBF, testMatrix);

fprintf('\nTopic Classification Results (RBF Kernel SVM):\n');
topicNames = ["Computer Science", "Finance", "Biology", "Physics"];

for i = 1:length(testTexts)
    fprintf('\nDocument %d: "%s"\n', i, testTexts(i));
    fprintf('  Predicted Topic: %s\n', ...
            topicNames(double(predictedLabels(i))));
    fprintf('  Confidence Scores:\n');
    
    for j = 1:length(topicNames)
        fprintf('    %s: %.4f\n', topicNames(j), scores(i, j));
    end
end

% Visualise kernel comparison
figure('Position', [100, 100, 1200, 400]);

kernelNames = {'Linear', 'RBF', 'Polynomial'};
trainAccuracies = [linearAcc, rbfAcc, polyAcc];
cvAccuracies = [cvLinearAcc, cvRBFAcc, cvPolyAcc];

subplot(1, 3, 1);
bar([trainAccuracies; cvAccuracies]');
xlabel('Kernel Function');
ylabel('Accuracy (%)');
title('SVM Kernel Comparison');
legend({'Training', 'Cross-Validation'}, 'Location', 'best');
set(gca, 'XTickLabel', kernelNames);
grid on;

subplot(1, 3, 2);
confusionchart(topicLabels, predict(svmRBF, trainMatrix));
title('Confusion Matrix (RBF Kernel)');

subplot(1, 3, 3);
% Visualise decision boundaries using PCA projection
[coeff, score] = pca(trainMatrix, 'NumComponents', 2);

scatter(score(:, 1), score(:, 2), 100, double(topicLabels), ...
        'filled', 'MarkerFaceAlpha', 0.6);
xlabel('First Principal Component');
ylabel('Second Principal Component');
title('SVM Classification in PCA Space');
colormap('jet');
colorbar('Ticks', 1:4, 'TickLabels', topicNames);
grid on;
