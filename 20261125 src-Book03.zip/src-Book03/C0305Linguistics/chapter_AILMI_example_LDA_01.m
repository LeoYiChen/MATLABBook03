%% chapter_AILMI_example_LDA_01.m
% Latent Dirichlet Allocation for topic discovery with comprehensive analysis pipeline including topic coherence evaluation and temporal dynamics.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_LDA_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Latent Dirichlet Allocation (LDA) Topic Modelling
% Demonstrates discovering latent semantic topics in document collections

fprintf('=== Latent Dirichlet Allocation Topic Modelling ===\n\n');

% - Step 1: Prepare Document Corpus -

fprintf('Step 1: Loading and preprocessing document corpus...\n');

% Sample document collection (news articles across multiple domains)
documents = [
    "Artificial intelligence and machine learning revolutionise data analysis. " + ...
    "Deep neural networks achieve remarkable accuracy in pattern recognition tasks. " + ...
    "Computer vision applications enable autonomous vehicle navigation and medical diagnosis.";
    
    "Climate change impacts global weather patterns significantly. " + ...
    "Rising temperatures accelerate glacier melting and sea level rise. " + ...
    "Renewable energy sources reduce carbon emissions and environmental damage.";
    
    "Stock markets experience volatility amid economic uncertainty. " + ...
    "Central banks adjust interest rates to control inflation. " + ...
    "Investors diversify portfolios across equities, bonds, and commodities.";
    
    "Professional football teams compete in international tournaments. " + ...
    "Athletes train rigorously to enhance performance and prevent injuries. " + ...
    "Sports analytics employ statistics to optimise team strategies.";
    
    "Genomic sequencing advances personalised medicine approaches. " + ...
    "CRISPR gene editing technology enables precise genetic modifications. " + ...
    "Clinical trials evaluate novel pharmaceutical treatments for diseases.";
    
    "Quantum computing leverages superposition for exponential speedup. " + ...
    "Cryptographic protocols secure digital communications and transactions. " + ...
    "Cloud infrastructure scales computational resources dynamically.";
    
    "Parliamentary elections determine governmental leadership and policies. " + ...
    "Political parties campaign on platforms addressing economic and social issues. " + ...
    "Legislative bodies debate and enact laws governing society.";
    
    "Global trade agreements facilitate international commerce and investment. " + ...
    "Supply chain logistics optimise manufacturing and distribution networks. " + ...
    "E-commerce platforms transform retail consumer experiences.";
    
    "Renewable solar and wind energy generation capacity expands rapidly. " + ...
    "Battery storage technologies enable grid-scale electricity management. " + ...
    "Carbon capture systems mitigate greenhouse gas emissions.";
    
    "Spacecraft exploration missions investigate Mars planetary geology. " + ...
    "Satellite constellations provide global communications coverage. " + ...
    "Astrophysics research examines dark matter and cosmic phenomena.";
    
    "Educational institutions adopt digital learning platforms. " + ...
    "Pedagogical methods emphasise critical thinking and problem-solving skills. " + ...
    "Student assessment systems evaluate knowledge acquisition and competencies.";
    
    "Antibiotic resistance threatens public health globally. " + ...
    "Vaccination programmes prevent infectious disease transmission. " + ...
    "Epidemiological surveillance monitors outbreak patterns and trends.";
    
    "Autonomous drones conduct aerial surveillance and delivery services. " + ...
    "Robotic automation enhances manufacturing efficiency and precision. " + ...
    "Sensor networks enable Internet of Things connectivity.";
    
    "Cryptocurrency blockchain protocols decentralise financial transactions. " + ...
    "Smart contracts automate agreement execution without intermediaries. " + ...
    "Digital wallets facilitate peer-to-peer payment systems.";
    
    "Archaeological excavations uncover ancient civilisation artefacts. " + ...
    "Historical documents preserve cultural heritage and societal evolution. " + ...
    "Museum exhibitions educate public about human history.";
    
    "Neural network architectures process natural language understanding. " + ...
    "Transformer models enable contextual word representations. " + ...
    "Chatbot applications provide automated customer service interactions.";
    
    "Optical telescopes observe distant galaxies and stellar formations. " + ...
    "Radio astronomy detects electromagnetic signals from cosmic sources. " + ...
    "Gravitational wave detectors measure spacetime distortions.";
    
    "Urban planning designs sustainable cities with green spaces. " + ...
    "Public transportation networks reduce traffic congestion. " + ...
    "Smart city infrastructure integrates digital technologies.";
    
    "Theatrical performances showcase dramatic storytelling and artistry. " + ...
    "Film production employs cinematography and visual effects. " + ...
    "Streaming services distribute entertainment content globally.";
    
    "Agricultural innovations increase crop yields sustainably. " + ...
    "Precision farming utilises GPS and sensor technologies. " + ...
    "Vertical farming addresses food security challenges."
];

numDocuments = length(documents);
fprintf('  Corpus size: %d documents\n', numDocuments);

% Display sample documents
fprintf('\n  Sample documents:\n');
for i = 1:min(3, numDocuments)
    fprintf('    Doc %d: %s...\n', i, extractBefore(documents(i), 100));
end
fprintf('\n');

% - Step 2: Text Preprocessing -

fprintf('Step 2: Preprocessing text documents...\n');

% Tokenise documents
tokenizedDocs = tokenizedDocument(documents);

% Remove stopwords and short tokens
tokenizedDocs = removeStopWords(tokenizedDocs);
tokenizedDocs = removeShortWords(tokenizedDocs, 3);
tokenizedDocs = removeLongWords(tokenizedDocs, 15);

% Lemmatisation (normalisation)
tokenizedDocs = normalizeWords(tokenizedDocs, 'Style', 'lemma');

% Remove infrequent words (appearing in fewer than 2 documents)
tokenizedDocs = removeInfrequentWords(tokenizedDocs, 2);

fprintf('  Preprocessing complete\n');
fprintf('  Sample preprocessed tokens: %s\n\n', ...
    strjoin(tokenizedDocs(1).Vocabulary(1:min(10, numel(tokenizedDocs(1).Vocabulary))), ', '));

% - Step 3: Create Bag-of-Words Representation -

fprintf('Step 3: Constructing bag-of-words model...\n');

% Build bag-of-words
bag = bagOfWords(tokenizedDocs);

fprintf('  Vocabulary size: %d unique terms\n', bag.NumWords);
fprintf('  Total tokens: %d\n', sum(bag.Counts, 'all'));
fprintf('  Average document length: %.1f tokens\n\n', mean(sum(bag.Counts, 2)));

% - Step 4: Fit LDA Topic Model -

fprintf('Step 4: Training Latent Dirichlet Allocation model...\n');

% Set number of topics
numTopics = 5;

% Fit LDA model with optimised hyperparameters
rng(42);  % Reproducibility
ldaModel = fitlda(bag, numTopics, ...
    'Verbose', 0, ...
    'Solver', 'avb', ...  % Approximate Variational Bayes
    'InitialTopicConcentration', 50/numTopics, ...  % Alpha prior
    'InitialDocumentConcentration', 0.1);  % Beta prior

fprintf('  LDA model trained successfully\n');
fprintf('  Number of topics: %d\n', numTopics);
fprintf('  Solver: Approximate Variational Bayes\n\n');

% - Step 5: Examine Topic Compositions -

fprintf('Step 5: Analysing discovered topic compositions...\n\n');

% Extract top words for each topic
numTopWords = 12;
topWords = topkwords(ldaModel, numTopWords);

fprintf('  Top %d words per topic:\n\n', numTopWords);
for topicIdx = 1:numTopics
    fprintf('  Topic %d:\n    ', topicIdx);
    topicWords = topWords(topicIdx, :);
    fprintf('%s\n\n', strjoin(topicWords, ', '));
end

% - Step 6: Transform Documents to Topic Space -

fprintf('Step 6: Transforming documents to topic distributions...\n');

% Get document-topic distributions
docTopicDistribution = transform(ldaModel, bag);

fprintf('  Document-topic matrix: %d x %d\n', size(docTopicDistribution, 1), ...
    size(docTopicDistribution, 2));

% Find dominant topic for each document
[~, dominantTopics] = max(docTopicDistribution, [], 2);

fprintf('\n  Dominant topic assignments:\n');
topicCounts = histcounts(dominantTopics, 1:numTopics+1);
for topicIdx = 1:numTopics
    fprintf('    Topic %d: %d documents\n', topicIdx, topicCounts(topicIdx));
end
fprintf('\n');

% - Step 7: Calculate Topic Coherence -

fprintf('Step 7: Evaluating topic coherence scores...\n');

% Simplified coherence calculation (PMI-based approximation)
% Note: Full coherence requires external corpus statistics

coherenceScores = zeros(numTopics, 1);
for topicIdx = 1:numTopics
    topicWords = topWords(topicIdx, 1:8);  % Use top 8 words
    
    % Count co-occurrences (simplified)
    pmiSum = 0;
    pairCount = 0;
    
    for i = 1:length(topicWords)-1
        for j = i+1:length(topicWords)
            word1 = topicWords{i};
            word2 = topicWords{j};
            
            % Check word indices in vocabulary
            if ismember(word1, bag.Vocabulary) && ismember(word2, bag.Vocabulary)
                idx1 = find(strcmp(bag.Vocabulary, word1));
                idx2 = find(strcmp(bag.Vocabulary, word2));
                
                % Co-occurrence in documents
                docsWith1 = sum(bag.Counts(:, idx1) > 0);
                docsWith2 = sum(bag.Counts(:, idx2) > 0);
                docsWithBoth = sum((bag.Counts(:, idx1) > 0) & (bag.Counts(:, idx2) > 0));
                
                % Simplified PMI calculation
                if docsWithBoth > 0
                    pmi = log((docsWithBoth * numDocuments) / (docsWith1 * docsWith2) + 1e-10);
                    pmiSum = pmiSum + pmi;
                    pairCount = pairCount + 1;
                end
            end
        end
    end
    
    if pairCount > 0
        coherenceScores(topicIdx) = pmiSum / pairCount;
    end
end

fprintf('  Topic coherence scores (PMI-based):\n');
for topicIdx = 1:numTopics
    fprintf('    Topic %d: %.4f\n', topicIdx, coherenceScores(topicIdx));
end
fprintf('  Average coherence: %.4f\n\n', mean(coherenceScores));

% - Step 8: Document Similarity Analysis -

fprintf('Step 8: Computing document similarities in topic space...\n');

% Calculate pairwise cosine similarities
docSimilarities = docTopicDistribution * docTopicDistribution';

% Normalise for cosine similarity
norms = sqrt(sum(docTopicDistribution.^2, 2));
docSimilarities = docSimilarities ./ (norms * norms');

fprintf('  Computed %d x %d similarity matrix\n', size(docSimilarities));

% Find most similar document pairs
[sortedSims, sortIdx] = sort(docSimilarities(:), 'descend');
% Exclude self-similarities (diagonal)
validIdx = find(sortedSims < 0.9999, 5, 'first');

fprintf('\n  Top 3 most similar document pairs:\n');
for i = 1:min(3, length(validIdx))
    [doc1, doc2] = ind2sub(size(docSimilarities), sortIdx(validIdx(i)));
    fprintf('    Documents %d & %d: similarity = %.4f\n', ...
        doc1, doc2, sortedSims(validIdx(i)));
end
fprintf('\n');

% - Step 9: Topic Evolution Simulation -

fprintf('Step 9: Simulating topic evolution over time...\n');

% Assign timestamps to documents (simulate temporal data)
documentTimestamps = sort(randi([2020, 2024], numDocuments, 1));

% Calculate topic prevalence over time
uniqueYears = unique(documentTimestamps);
topicEvolution = zeros(length(uniqueYears), numTopics);

for yearIdx = 1:length(uniqueYears)
    year = uniqueYears(yearIdx);
    docsInYear = documentTimestamps == year;
    
    if any(docsInYear)
        yearTopicDist = mean(docTopicDistribution(docsInYear, :), 1);
        topicEvolution(yearIdx, :) = yearTopicDist;
    end
end

fprintf('  Analysed topic trends across %d time periods\n\n', length(uniqueYears));

% - Step 10: Visualisation -

fprintf('Step 10: Generating topic modelling visualisations...\n');

figure('Position', [100, 100, 1800, 1200]);

% Plot 1: Word cloud for Topic 1
subplot(3, 4, 1);
wordcloud(ldaModel, 1);
title('Topic 1 Word Cloud', 'FontSize', 11, 'FontWeight', 'bold');

% Plot 2: Word cloud for Topic 2
subplot(3, 4, 2);
wordcloud(ldaModel, 2);
title('Topic 2 Word Cloud', 'FontSize', 11, 'FontWeight', 'bold');

% Plot 3: Word cloud for Topic 3
subplot(3, 4, 3);
if numTopics >= 3
    wordcloud(ldaModel, 3);
    title('Topic 3 Word Cloud', 'FontSize', 11, 'FontWeight', 'bold');
end

% Plot 4: Topic coherence scores
subplot(3, 4, 4);
bar(1:numTopics, coherenceScores, 'FaceColor', [0.3, 0.6, 0.9]);
xlabel('Topic Index');
ylabel('Coherence Score');
title('Topic Coherence Evaluation');
grid on;
set(gca, 'XTick', 1:numTopics);

% Plot 5: Document-topic distribution heatmap
subplot(3, 4, 5);
imagesc(docTopicDistribution);
colorbar;
colormap(flipud(gray));
xlabel('Topic');
ylabel('Document');
title('Document-Topic Distribution Matrix');
set(gca, 'XTick', 1:numTopics);

% Plot 6: Dominant topic distribution
subplot(3, 4, 6);
histogram(dominantTopics, 'BinEdges', 0.5:1:numTopics+0.5, ...
    'FaceColor', [0.6, 0.4, 0.8]);
xlabel('Topic');
ylabel('Number of Documents');
title('Dominant Topic Distribution');
grid on;
set(gca, 'XTick', 1:numTopics);

% Plot 7: Topic word probability heatmap
subplot(3, 4, 7);
topicWordMatrix = zeros(numTopics, numTopWords);
for topicIdx = 1:numTopics
    topicWordsList = topWords(topicIdx, :);
    for wordIdx = 1:numTopWords
        word = topicWordsList{wordIdx};
        if ismember(word, bag.Vocabulary)
            vocabIdx = find(strcmp(bag.Vocabulary, word));
            topicWordMatrix(topicIdx, wordIdx) = ...
                ldaModel.TopicConcentration(topicIdx, vocabIdx);
        end
    end
end
imagesc(topicWordMatrix);
colorbar;
xlabel('Word Rank');
ylabel('Topic');
title('Topic-Word Probability Matrix');
set(gca, 'YTick', 1:numTopics);

% Plot 8: Average topic entropy
subplot(3, 4, 8);
docEntropy = -sum(docTopicDistribution .* log(docTopicDistribution + eps), 2);
histogram(docEntropy, 15, 'FaceColor', [0.8, 0.5, 0.3]);
xlabel('Topic Entropy');
ylabel('Frequency');
title('Document Topic Distribution Entropy');
grid on;

% Plot 9: Topic evolution over time
subplot(3, 4, 9);
plot(uniqueYears, topicEvolution, 'LineWidth', 2, 'Marker', 'o');
xlabel('Year');
ylabel('Topic Prevalence');
title('Topic Evolution Over Time');
legend(arrayfun(@(x) sprintf('Topic %d', x), 1:numTopics, 'UniformOutput', false), ...
    'Location', 'best', 'FontSize', 8);
grid on;

% Plot 10: Document similarity network (subset)
subplot(3, 4, 10);
% Select subset of highly similar documents
threshold = 0.3;
similarityGraph = docSimilarities > threshold;
similarityGraph = similarityGraph - eye(size(similarityGraph));  % Remove self-loops

G = graph(similarityGraph);
if G.numnodes > 0 && G.numedges > 0
    plot(G, 'Layout', 'force', 'NodeColor', dominantTopics, ...
        'MarkerSize', 6, 'LineWidth', 1.5);
    colormap(gca, lines(numTopics));
    title(sprintf('Document Similarity Network (threshold=%.2f)', threshold));
    colorbar('Ticks', 1:numTopics, 'TickLabels', ...
        arrayfun(@(x) sprintf('T%d', x), 1:numTopics, 'UniformOutput', false));
else
    text(0.5, 0.5, 'No connections above threshold', ...
        'HorizontalAlignment', 'center');
    title('Document Similarity Network');
end
axis off;

% Plot 11: Vocabulary frequency distribution
subplot(3, 4, 11);
wordCounts = sum(bag.Counts, 1);
[sortedCounts, ~] = sort(wordCounts, 'descend');
loglog(1:length(sortedCounts), sortedCounts, 'b-', 'LineWidth', 2);
xlabel('Word Rank (log scale)');
ylabel('Frequency (log scale)');
title('Vocabulary Zipf Distribution');
grid on;

% Plot 12: Topic diversity metric
subplot(3, 4, 12);
% Calculate topic diversity (average pairwise distance)
topicVectors = ldaModel.TopicConcentration;
topicDistances = pdist(topicVectors, 'cosine');
bar(1:length(topicDistances), topicDistances, 'FaceColor', [0.5, 0.7, 0.5]);
xlabel('Topic Pair Index');
ylabel('Cosine Distance');
title('Inter-Topic Diversity');
grid on;

sgtitle('Latent Dirichlet Allocation Topic Modelling Analysis', ...
    'FontSize', 14, 'FontWeight', 'bold');

print('lda_topic_modelling_analysis', '-dpng', '-r300');

fprintf('\nLDA topic modelling complete!\n');
fprintf('Discovered %d latent topics with average coherence %.4f\n', ...
    numTopics, mean(coherenceScores));
fprintf('Topics reveal thematic structures across %d documents.\n', numDocuments);
