%% chapter_AILMI_example_fund_01.m
% Part-of-speech tagging for syntactic analysis.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_fund_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Sample sentences for linguistic analysis
sentences = ["The cat sat on the mat.";
             "Natural language processing enables machines.";
             "Computational linguistics bridges theory and practice."];

% Create tokenised documents
documents = tokenizedDocument(sentences);

% Perform part-of-speech tagging
posModel = addPartOfSpeechDetails(documents);

% Display tagged results
for i = 1:numel(posModel)
    tokens = posModel(i).Token;
    posTags = posModel(i).PartOfSpeech;
    
    fprintf('\nSentence %d: %s\n', i, sentences(i));
    fprintf('%-20*s %-15*s\n', 'Token', 'POS Tag');
    fprintf('%-20*s %-15*s\n', '--', '--');
    
    for j = 1:length(tokens)
        fprintf('%-20*s %-15*s\n', tokens(j), posTags(j));
    end
end

% Analyse POS distribution
allPOS = [];
for i = 1:numel(posModel)
    allPOS = [allPOS; posModel(i).PartOfSpeech];
end

% Count POS tag frequencies
posCategories = unique(allPOS);
posCounts = zeros(length(posCategories), 1);

for i = 1:length(posCategories)
    posCounts(i) = sum(allPOS == posCategories(i));
end

% Visualise POS distribution
figure;
bar(categorical(posCategories), posCounts);
xlabel('Part-of-Speech Category');
ylabel('Frequency');
title('Part-of-Speech Distribution');
grid on;
