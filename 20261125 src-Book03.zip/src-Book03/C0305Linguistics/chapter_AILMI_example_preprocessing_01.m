%% chapter_AILMI_example_preprocessing_01.m
% Comprehensive text preprocessing pipeline demonstrating tokenisation, normalisation, stop word removal, and lemmatisation in MATLAB.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_preprocessing_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Sample textual data representing diverse linguistic phenomena
rawText = ["Artificial Intelligence is revolutionising linguistics!";
           "The rapid advancements in AI offer new analytical tools.";
           "Researchers are employing MATLAB for sophisticated NLP tasks.";
           "Text preprocessing requires careful consideration of linguistic nuances."];

% Step 1: Tokenisation - Convert raw strings into tokenised document objects
% The tokenizedDocument function segments text into discrete tokens whilst
% preserving document structure and enabling subsequent preprocessing operations
documents = tokenizedDocument(rawText);
fprintf('=== Stage 1: Initial Tokenisation ===\n');
fprintf('First document tokens: ');
disp(documents(1).Vocabulary);

% Step 2: Lowercase Normalisation - Ensure case-insensitive processing
% This operation treats "AI", "Ai", and "ai" as identical tokens,
% reducing vocabulary size and improving statistical reliability
documents = lower(documents);
fprintf('\n=== Stage 2: Lowercase Normalisation ===\n');
fprintf('First document after lowercasing: ');
disp(documents(1).Vocabulary);

% Step 3: Punctuation Removal - Eliminate non-alphanumeric characters
% For many tasks, punctuation contributes noise rather than signal,
% though sentiment analysis and stylometry may benefit from retention
documents = erasePunctuation(documents);
fprintf('\n=== Stage 3: Punctuation Removal ===\n');
fprintf('First document after punctuation removal: ');
disp(documents(1).Vocabulary);

% Step 4: Stop Word Removal - Filter high-frequency, low-content words
% MATLAB provides default English stop word lists derived from
% information retrieval research; custom lists can be specified
documents = removeStopWords(documents);
fprintf('\n=== Stage 4: Stop Word Removal ===\n');
fprintf('First document after stop word removal: ');
disp(documents(1).Vocabulary);

% Step 5: Lemmatisation - Reduce words to canonical dictionary forms
% This linguistically principled approach outperforms crude stemming
% for applications requiring semantic precision
documents = normalizeWords(documents, 'Style', 'lemma');
fprintf('\n=== Stage 5: Lemmatisation ===\n');
fprintf('First document after lemmatisation: ');
disp(documents(1).Vocabulary);

% Generate summary statistics across the corpus
fprintf('\n=== Corpus Summary Statistics ===\n');
fprintf('Total documents: %d\n', numel(documents));
fprintf('Total unique tokens after preprocessing: %d\n', ...
        numel(unique([documents.Vocabulary])));

% Visualise token frequency distribution
allTokens = [documents.Vocabulary];
[uniqueTokens, ~, tokenIndices] = unique(allTokens);
tokenCounts = accumarray(tokenIndices, 1);
[sortedCounts, sortOrder] = sort(tokenCounts, 'descend');
sortedTokens = uniqueTokens(sortOrder);

% Display top 10 most frequent tokens
fprintf('\nTop 10 Most Frequent Tokens:\n');
for idx = 1:min(10, numel(sortedTokens))
    fprintf('  %d. "%s" (frequency: %d)\n', idx, ...
            sortedTokens(idx), sortedCounts(idx));
end

% Create visualisation of token frequency distribution
figure('Position', [100, 100, 800, 500]);
bar(sortedCounts(1:min(20, numel(sortedCounts))), 'FaceColor', [0.2 0.4 0.7]);
xlabel('Token Rank', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Frequency', 'FontSize', 12, 'FontWeight', 'bold');
title('Token Frequency Distribution (Top 20)', ...
      'FontSize', 14, 'FontWeight', 'bold');
grid on;
set(gca, 'XTick', 1:min(20, numel(sortedTokens)), ...
         'XTickLabel', sortedTokens(1:min(20, numel(sortedTokens))), ...
         'XTickLabelRotation', 45);
