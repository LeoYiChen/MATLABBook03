%% chapter_AILMI_example_AI_06.m
% Transformer architecture components and attention visualisation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_AI_06
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Simplified Transformer Attention Mechanism Demonstration

% Sample sentences for attention analysis
sentences = [ ...
    "The cat sat on the mat."; ...
    "The dog chased the cat."; ...
    "The bird flew over the tree."];

% Preprocess and create embeddings
docs = tokenizedDocument(sentences);
docs = erasePunctuation(lower(docs));

% Create word embeddings
embeddingDim = 64;
emb = wordEmbedding(docs, embeddingDim);

fprintf('Transformer Attention Mechanism Analysis\n\n');

% Function to compute scaled dot-product attention

% Analyse attention for first sentence
firstSent = docs(1);
words = string(firstSent.Vocabulary);
numWords = numel(words);

fprintf('Analysing sentence: "%s"\n', sentences(1));
fprintf('Number of tokens: %d\n\n', numWords);

% Get word embeddings
wordVectors = zeros(embeddingDim, numWords);
for i = 1:numWords
    wordVectors(:, i) = word2vec(emb, words(i));
end

% Compute self-attention (simplified single-head)
% In practice, Q, K, V would be linear projections
queries = wordVectors;
keys = wordVectors;
values = wordVectors;

[attentionOutput, attentionWeights] = ...
    scaledDotProductAttention(queries, keys, values);

% Display attention weights
fprintf('Self-Attention Weight Matrix:\n');
fprintf('Rows: Query words, Columns: Key words\n\n');

% Print header
fprintf('%-12*s', '');
for i = 1:numWords
    fprintf('%-12*s', words(i));
end
fprintf('\n');

% Print attention weights
for i = 1:numWords
    fprintf('%-12*s', words(i));
    for j = 1:numWords
        fprintf('%-12.4*f', attentionWeights(i, j));
    end
    fprintf('\n');
end

% Visualise attention patterns
figure('Position', [100, 100, 1400, 500]);

% Attention weight heatmap
subplot(1, 3, 1);
imagesc(attentionWeights);
colorbar;
colormap('hot');
title('Self-Attention Weights');
xlabel('Key Position');
ylabel('Query Position');
xticks(1:numWords);
yticks(1:numWords);
xticklabels(words);
yticklabels(words);
xtickangle(45);
axis square;

% Attention weight distribution
subplot(1, 3, 2);
histogram(attentionWeights(:), 20);
xlabel('Attention Weight');
ylabel('Frequency');
title('Attention Weight Distribution');
grid on;

% Multi-head attention simulation
numHeads = 4;
subplot(1, 3, 3);

for head = 1:numHeads
    % Simulate different projections (in practice, learned)
    rng(head);  % Different seed for each head
    projectionQ = randn(embeddingDim, embeddingDim / numHeads);
    projectionK = randn(embeddingDim, embeddingDim / numHeads);
    projectionV = randn(embeddingDim, embeddingDim / numHeads);
    
    % Project queries, keys, values
    Q_head = projectionQ' * queries;
    K_head = projectionK' * keys;
    V_head = projectionV' * values;
    
    % Compute attention for this head
    [~, headAttention] = scaledDotProductAttention(...
                        Q_head, K_head, V_head);
    
    % Visualise attention pattern for each head
    subplot(2, numHeads/2, head);
    imagesc(headAttention);
    colorbar;
    colormap('hot');
    title(sprintf('Head %d Attention', head));
    xticks(1:numWords);
    yticks(1:numWords);
    xticklabels(words);
    yticklabels(words);
    xtickangle(45);
    axis square;
end

% Demonstrate positional encoding
fprintf('\n\nPositional Encoding\n');

maxLen = 50;
posEncoding = zeros(embeddingDim, maxLen);

for pos = 1:maxLen
    for i = 1:2:embeddingDim
        posEncoding(i, pos) = sin(pos / (10000^(i/embeddingDim)));
        if i+1 <= embeddingDim
            posEncoding(i+1, pos) = cos(pos / (10000^(i/embeddingDim)));
        end
    end
end

% Visualise positional encodings
figure('Position', [100, 100, 1000, 400]);

subplot(1, 2, 1);
imagesc(posEncoding);
colorbar;
colormap('jet');
title('Positional Encoding Matrix');
xlabel('Position');
ylabel('Embedding Dimension');

subplot(1, 2, 2);
plot(posEncoding(1:5, :)');
xlabel('Position');
ylabel('Encoding Value');
title('Positional Encoding Patterns');
legend(arrayfun(@(x) sprintf('Dim %d', x), 1:5, ...
       'UniformOutput', false), 'Location', 'best');
grid on;

fprintf('Positional encoding visualisation complete.\n');

% Local functions (moved to end so this listing is a valid MATLAB script)
function [output, attentionWeights] = scaledDotProductAttention(...
         queries, keys, values)
    % queries, keys, values: [embDim x seqLen]
    
    % Compute attention scores
    dK = size(keys, 1);
    scores = (queries' * keys) / sqrt(dK);  % [seqLen x seqLen]
    
    % Apply softmax to get attention weights
    attentionWeights = softmax(scores, 2);
    
    % Compute weighted sum of values
    output = values * attentionWeights';  % [embDim x seqLen]
end
