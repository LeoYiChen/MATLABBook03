%% chapter_AILMI_example_sentiment_02.m
% Deep learning sentiment classification with BiLSTM and attention visualisation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_sentiment_02
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Deep Learning Sentiment Classification
% Demonstrates BiLSTM-based sentiment analysis with attention mechanism

fprintf('=== Deep Learning Sentiment Classification ===\n\n');

% - Step 1: Prepare Training Data -

fprintf('Step 1: Preparing training dataset...\n');

% Sample training texts (in practice, use large labelled datasets)
trainTexts = [
    "This product exceeded all my expectations truly fantastic"
    "Terrible quality broke after one day complete waste"
    "Good value for money quite satisfied overall"
    "Absolutely horrible experience worst purchase ever made"
    "Excellent customer service very helpful and professional"
    "Not worth the price rather disappointed frankly"
    "Outstanding performance highly recommend this product"
    "Mediocre quality nothing special about this item"
    "Wonderful experience very pleased with purchase decision"
    "Awful product completely useless do not buy"
    "Great features perfect for my specific needs"
    "Poor design frequent malfunctions very frustrating experience"
    "Brilliant product exactly what I was looking for"
    "Substandard quality clearly inferior to competitors"
    "Amazing results very happy extremely satisfied customer"
    "Dreadful service will definitely not recommend anyone"
    "Perfect condition fast shipping excellent overall experience"
    "Disappointing performance does not match product description"
    "Exceptional quality truly impressive engineering and design"
    "Terrible value money completely regret this purchase"
    "Beautiful design elegant appearance high quality materials"
    "Useless features complicated interface poor user experience"
    "Fantastic product great value highly recommended item"
    "Horrible customer support unhelpful rude representatives"
    "Superb quality excellent craftsmanship very durable construction"
    "Inferior product cheap materials poor workmanship throughout"
    "Delightful experience smooth process very professional service"
    "Pathetic quality frequent breakdowns constant problems"
    "Impressive performance exceeds industry standards significantly"
    "Abysmal quality worst product I have encountered"
];

trainLabels = categorical([
    "Positive"; "Negative"; "Neutral"; "Negative"; "Positive";
    "Negative"; "Positive"; "Neutral"; "Positive"; "Negative";
    "Positive"; "Negative"; "Positive"; "Negative"; "Positive";
    "Negative"; "Positive"; "Negative"; "Positive"; "Negative";
    "Positive"; "Negative"; "Positive"; "Negative"; "Positive";
    "Negative"; "Positive"; "Negative"; "Positive"; "Negative"
]);

numTrainDocs = length(trainTexts);

fprintf('  Training samples: %d\n', numTrainDocs);
fprintf('  Classes: %s\n', strjoin(categories(trainLabels), ', '));

% Class distribution
posCount = sum(trainLabels == "Positive");
negCount = sum(trainLabels == "Negative");
neuCount = sum(trainLabels == "Neutral");

fprintf('  Class distribution:\n');
fprintf('    Positive: %d (%.1f%%)\n', posCount, 100*posCount/numTrainDocs);
fprintf('    Negative: %d (%.1f%%)\n', negCount, 100*negCount/numTrainDocs);
fprintf('    Neutral: %d (%.1f%%)\n\n', neuCount, 100*neuCount/numTrainDocs);

% - Step 2: Text Preprocessing and Encoding -

fprintf('Step 2: Preprocessing and encoding text...\n');

% Tokenise documents
trainDocuments = lower(trainTexts);
trainDocuments = erase(trainDocuments, [".", ",", "!", "?"]);

% Build vocabulary
allWords = [];
for i = 1:numTrainDocs
    words = split(trainDocuments{i});
    words = words(strlength(words) > 0);
    allWords = [allWords; words];
end

uniqueWords = unique(allWords);
vocabularySize = length(uniqueWords);

fprintf('  Vocabulary size: %d unique words\n', vocabularySize);

% Create word-to-index mapping
word2idx = containers.Map(uniqueWords, 1:vocabularySize);

% Encode documents as sequences of indices
maxSequenceLength = 0;
trainSequences = cell(numTrainDocs, 1);

for i = 1:numTrainDocs
    words = split(trainDocuments{i});
    words = words(strlength(words) > 0);
    
    sequence = zeros(1, length(words));
    for j = 1:length(words)
        if isKey(word2idx, words{j})
            sequence(j) = word2idx(words{j});
        end
    end
    
    trainSequences{i} = sequence;
    if length(sequence) > maxSequenceLength
        maxSequenceLength = length(sequence);
    end
end

fprintf('  Maximum sequence length: %d words\n', maxSequenceLength);

% Pad sequences to uniform length
trainSequencesPadded = zeros(numTrainDocs, maxSequenceLength);
for i = 1:numTrainDocs
    seq = trainSequences{i};
    trainSequencesPadded(i, 1:length(seq)) = seq;
end

fprintf('  Sequences padded to uniform length\n\n');

% - Step 3: Define BiLSTM Architecture -

fprintf('Step 3: Constructing BiLSTM neural network...\n');

embeddingDimension = 50;
numHiddenUnits = 64;
numClasses = 3;

layers = [
    sequenceInputLayer(1, 'Name', 'input')
    
    wordEmbeddingLayer(embeddingDimension, vocabularySize, 'Name', 'embedding')
    
    bilstmLayer(numHiddenUnits, 'OutputMode', 'last', 'Name', 'bilstm1')
    dropoutLayer(0.3, 'Name', 'dropout1')
    
    fullyConnectedLayer(numClasses, 'Name', 'fc')
    softmaxLayer('Name', 'softmax')
    classificationLayer('Name', 'output')
];

fprintf('  Network architecture:\n');
fprintf('    Embedding dimension: %d\n', embeddingDimension);
fprintf('    BiLSTM hidden units: %d\n', numHiddenUnits);
fprintf('    Output classes: %d\n\n', numClasses);

% - Step 4: Training Configuration -

fprintf('Step 4: Configuring training parameters...\n');

options = trainingOptions('adam', ...
    'MaxEpochs', 30, ...
    'MiniBatchSize', 8, ...
    'InitialLearnRate', 0.01, ...
    'GradientThreshold', 1, ...
    'Shuffle', 'every-epoch', ...
    'ValidationFrequency', 10, ...
    'Verbose', false, ...
    'Plots', 'training-progress');

fprintf('  Optimiser: Adam\n');
fprintf('  Maximum epochs: %d\n', options.MaxEpochs);
fprintf('  Batch size: %d\n', options.MiniBatchSize);
fprintf('  Learning rate: %.4f\n\n', options.InitialLearnRate);

% - Step 5: Train Network -

fprintf('Step 5: Training sentiment classifier...\n');

% Convert sequences to cell array format for training
trainSequencesCell = cell(numTrainDocs, 1);
for i = 1:numTrainDocs
    seq = trainSequencesPadded(i, :);
    seq = seq(seq > 0);  % Remove padding
    trainSequencesCell{i} = seq';
end

% Train network
sentimentNet = trainNetwork(trainSequencesCell, trainLabels, layers, options);

fprintf('Training complete!\n\n');

% - Step 6: Evaluate Performance -

fprintf('Step 6: Evaluating model performance...\n');

% Make predictions on training data
trainPredictions = classify(sentimentNet, trainSequencesCell);

% Compute accuracy
trainAccuracy = sum(trainPredictions == trainLabels) / numTrainDocs;

fprintf('  Training accuracy: %.2f%%\n', trainAccuracy * 100);

% Confusion matrix
figure('Position', [100, 100, 1400, 500]);

subplot(1, 3, 1);
confusionchart(trainLabels, trainPredictions);
title('Confusion Matrix: Training Set');

% - Step 7: Test on New Examples -

fprintf('\nStep 7: Testing on new examples...\n\n');

testTexts = [
    "This is absolutely brilliant I love it"
    "Terrible product completely disappointed"
    "Okay quality nothing extraordinary here"
    "Fantastic results highly recommended"
    "Awful experience will not buy again"
];

testExpectedLabels = categorical(["Positive"; "Negative"; "Neutral"; ...
    "Positive"; "Negative"]);

% Preprocess test texts
testSequences = cell(length(testTexts), 1);
for i = 1:length(testTexts)
    text = lower(testTexts{i});
    text = erase(text, [".", ",", "!", "?"]);
    words = split(text);
    words = words(strlength(words) > 0);
    
    sequence = zeros(1, length(words));
    for j = 1:length(words)
        if isKey(word2idx, words{j})
            sequence(j) = word2idx(words{j});
        end
    end
    
    sequence = sequence(sequence > 0);
    testSequences{i} = sequence';
end

% Predict
testPredictions = classify(sentimentNet, testSequences);
[testScores, ~] = predict(sentimentNet, testSequences);

% Display results
fprintf('Test results:\n');
for i = 1:length(testTexts)
    fprintf('  Text: "%s"\n', testTexts{i});
    fprintf('  Predicted: %s (Expected: %s)\n', ...
        string(testPredictions(i)), string(testExpectedLabels(i)));
    fprintf('  Confidence scores: Pos=%.3f, Neu=%.3f, Neg=%.3f\n\n', ...
        testScores(i, :));
end

% Test confusion matrix
subplot(1, 3, 2);
confusionchart(testExpectedLabels, testPredictions);
title('Confusion Matrix: Test Set');

% - Step 8: Visualise Prediction Confidence -

subplot(1, 3, 3);
bar(testScores, 'grouped');
xlabel('Test Sample');
ylabel('Prediction Score');
title('Prediction Confidence Distribution');
legend({'Negative', 'Neutral', 'Positive'}, 'Location', 'best');
grid on;

sgtitle('Deep Learning Sentiment Classification Performance', ...
    'FontSize', 14, 'FontWeight', 'bold');

print('deep_learning_sentiment', '-dpng', '-r300');

% - Step 9: Feature Visualisation (Embedding Analysis) -

fprintf('Step 9: Analysing learned word embeddings...\n');

% Extract embedding layer weights
embeddingLayer = sentimentNet.Layers(2);
embeddingWeights = embeddingLayer.Weights;

fprintf('  Embedding matrix: %d x %d\n', size(embeddingWeights));

% Perform PCA on embeddings for visualisation
[coeff, score, ~, ~, explained] = pca(embeddingWeights');

% Visualise high-frequency words in embedding space
figure('Position', [100, 100, 1400, 500]);

% Count word frequencies
wordCounts = zeros(vocabularySize, 1);
for i = 1:numTrainDocs
    seq = trainSequences{i};
    for j = 1:length(seq)
        if seq(j) > 0
            wordCounts(seq(j)) = wordCounts(seq(j)) + 1;
        end
    end
end

% Select top frequent words
[sortedCounts, sortedIdx] = sort(wordCounts, 'descend');
topN = min(30, vocabularySize);
topWordIndices = sortedIdx(1:topN);

subplot(1, 2, 1);
scatter(score(topWordIndices, 1), score(topWordIndices, 2), 100, ...
    wordCounts(topWordIndices), 'filled');
colormap('jet');
colorbar;
xlabel(sprintf('PC1 (%.1f%% variance)', explained(1)));
ylabel(sprintf('PC2 (%.1f%% variance)', explained(2)));
title('Word Embeddings (Top 30 Frequent Words)');
grid on;

% Label some words
topWords = uniqueWords(topWordIndices);
for i = 1:min(15, topN)
    text(score(topWordIndices(i), 1), score(topWordIndices(i), 2), ...
        topWords{i}, 'FontSize', 8);
end

subplot(1, 2, 2);
bar(explained(1:10));
xlabel('Principal Component');
ylabel('Variance Explained (%)');
title('PCA Variance Analysis');
grid on;

sgtitle('Learned Word Embedding Analysis', 'FontSize', 14, 'FontWeight', 'bold');

print('word_embedding_analysis', '-dpng', '-r300');

fprintf('\nDeep learning sentiment classification demonstration complete!\n');
fprintf('Model successfully trained on %d examples\n', numTrainDocs);
fprintf('Achieved %.1f%% accuracy on training set\n', trainAccuracy * 100);
