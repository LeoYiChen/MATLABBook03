%% chapter_AILMI_example_generation_01.m
% Autoregressive language model with LSTM for text generation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_generation_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Autoregressive Language Model for Text Generation
% Demonstrates character-level and word-level language modelling with LSTM

fprintf('=== Autoregressive Language Model ===\n\n');

% - Step 1: Prepare Training Text -

fprintf('Step 1: Preparing training corpus...\n');

% Sample training text (expanded corpus for better learning)
trainingText = [...
    "The quick brown fox jumps over the lazy dog. " ...
    "Machine learning enables computers to learn from data. " ...
    "Deep neural networks transform artificial intelligence. " ...
    "Natural language processing analyzes human language. " ...
    "Text generation creates coherent linguistic output. " ...
    "Language models predict subsequent words accurately. " ...
    "Recurrent networks maintain contextual information. " ...
    "Long short-term memory networks learn dependencies. " ...
    "Transformers revolutionized natural language understanding. " ...
    "Attention mechanisms focus on relevant context. " ...
    "Pre-training improves downstream task performance. " ...
    "Fine-tuning adapts models to specific applications. " ...
    "Large language models exhibit emergent capabilities. " ...
    "Autoregressive generation predicts tokens sequentially. " ...
    "Sampling strategies control generation diversity. " ...
    "Temperature parameter modulates output randomness. " ...
    "Beam search explores multiple generation paths. " ...
    "Nucleus sampling selects from probable continuations. " ...
    "Coherent text requires long-range dependencies. " ...
    "Evaluation metrics assess generation quality. "
];

fullText = join(trainingText, "");
textLength = strlength(fullText);

fprintf('  Total training text length: %d characters\n', textLength);
fprintf('  Text preview: "%s..."\n\n', extractBefore(fullText, 101));

% - Step 2: Character-Level Vocabulary -

fprintf('Step 2: Building character-level vocabulary...\n');

% Extract unique characters
characters = unique(char(fullText));
characters = string(characters');
vocabSize = length(characters);

% Create character-to-index and index-to-character mappings
char2idx = containers.Map(characters, 1:vocabSize);
idx2char = containers.Map(1:vocabSize, characters);

fprintf('  Vocabulary size: %d characters\n', vocabSize);
fprintf('  Vocabulary: %s\n\n', strjoin(characters, ' '));

% - Step 3: Prepare Training Sequences -

fprintf('Step 3: Creating training sequences...\n');

sequenceLength = 40;  % Context length for prediction
stepSize = 3;  % Sliding window step

numSequences = floor((textLength - sequenceLength) / stepSize);
inputSequences = zeros(numSequences, sequenceLength);
targetSequences = zeros(numSequences, sequenceLength);

textChars = char(fullText);
sequenceIdx = 1;

for i = 1:stepSize:(textLength - sequenceLength)
    if sequenceIdx > numSequences
        break;
    end
    
    % Input: characters at positions i to i+sequenceLength-1
    for j = 1:sequenceLength
        charStr = string(textChars(i + j - 1));
        if isKey(char2idx, charStr)
            inputSequences(sequenceIdx, j) = char2idx(charStr);
        end
    end
    
    % Target: characters at positions i+1 to i+sequenceLength
    for j = 1:sequenceLength
        charStr = string(textChars(i + j));
        if isKey(char2idx, charStr)
            targetSequences(sequenceIdx, j) = char2idx(charStr);
        end
    end
    
    sequenceIdx = sequenceIdx + 1;
end

% Trim to actual number created
inputSequences = inputSequences(1:sequenceIdx-1, :);
targetSequences = targetSequences(1:sequenceIdx-1, :);
numSequences = size(inputSequences, 1);

fprintf('  Number of training sequences: %d\n', numSequences);
fprintf('  Sequence length: %d\n', sequenceLength);
fprintf('  Example input: "%s"\n', strjoin(arrayfun(@(x) idx2char(x), ...
    inputSequences(1, :), 'UniformOutput', false), ''));
fprintf('  Example target: "%s"\n\n', strjoin(arrayfun(@(x) idx2char(x), ...
    targetSequences(1, :), 'UniformOutput', false), ''));

% - Step 4: Prepare Data for Training -

fprintf('Step 4: Formatting data for network training...\n');

% Convert to cell arrays of sequences (required for LSTM training)
XTrain = cell(numSequences, 1);
YTrain = cell(numSequences, 1);

for i = 1:numSequences
    XTrain{i} = inputSequences(i, :)';
    YTrain{i} = categorical(targetSequences(i, :)');
end

fprintf('  Training samples prepared: %d\n\n', numSequences);

% - Step 5: Define LSTM Language Model -

fprintf('Step 5: Constructing LSTM language model architecture...\n');

embeddingDimension = 64;
numHiddenUnits = 128;

layers = [
    sequenceInputLayer(1, 'Name', 'input')
    
    wordEmbeddingLayer(embeddingDimension, vocabSize, 'Name', 'embedding')
    
    lstmLayer(numHiddenUnits, 'OutputMode', 'sequence', 'Name', 'lstm1')
    dropoutLayer(0.2, 'Name', 'dropout1')
    
    lstmLayer(numHiddenUnits, 'OutputMode', 'sequence', 'Name', 'lstm2')
    dropoutLayer(0.2, 'Name', 'dropout2')
    
    fullyConnectedLayer(vocabSize, 'Name', 'fc')
    softmaxLayer('Name', 'softmax')
    classificationLayer('Name', 'classification')
];

fprintf('  Embedding dimension: %d\n', embeddingDimension);
fprintf('  LSTM hidden units: %d\n', numHiddenUnits);
fprintf('  Number of layers: %d\n', length(layers));

% - Step 6: Configure Training Options -

fprintf('\nStep 6: Configuring training options...\n');

options = trainingOptions('adam', ...
    'MaxEpochs', 50, ...
    'MiniBatchSize', 32, ...
    'InitialLearnRate', 0.01, ...
    'LearnRateSchedule', 'piecewise', ...
    'LearnRateDropFactor', 0.5, ...
    'LearnRateDropPeriod', 20, ...
    'GradientThreshold', 1, ...
    'Shuffle', 'every-epoch', ...
    'Verbose', false, ...
    'Plots', 'none');

fprintf('  Maximum epochs: %d\n', options.MaxEpochs);
fprintf('  Batch size: %d\n', options.MiniBatchSize);
fprintf('  Initial learning rate: %.4f\n', options.InitialLearnRate);

% - Step 7: Train Language Model -

fprintf('\nStep 7: Training autoregressive language model...\n');
fprintf('  (This may take a few minutes...)\n');

tic;
languageModel = trainNetwork(XTrain, YTrain, layers, options);
trainingTime = toc;

fprintf('  Training completed in %.2f seconds\n\n', trainingTime);

% - Step 8: Generate Text (Greedy Decoding) -

fprintf('Step 8: Generating text with greedy decoding...\n');

% Start with seed text
seedText = "The quick";
generatedLength = 100;

currentText = lower(seedText);
fprintf('  Seed text: "%s"\n', seedText);

for i = 1:generatedLength
    % Prepare input sequence (last sequenceLength characters)
    if strlength(currentText) >= sequenceLength
        inputChars = char(extractAfter(currentText, strlength(currentText) - sequenceLength));
    else
        inputChars = char(currentText);
    end
    
    % Convert to indices
    inputSeq = zeros(sequenceLength, 1);
    for j = 1:min(length(inputChars), sequenceLength)
        charStr = string(inputChars(j));
        if isKey(char2idx, charStr)
            inputSeq(j) = char2idx(charStr);
        else
            inputSeq(j) = 1;  % Unknown character
        end
    end
    
    % Predict next character
    try
        predicted = classify(languageModel, inputSeq);
        nextCharIdx = double(predicted(end));
        
        if isKey(idx2char, nextCharIdx)
            nextChar = idx2char(nextCharIdx);
            currentText = currentText + nextChar;
        else
            break;
        end
    catch
        break;
    end
end

fprintf('  Generated text (%d chars):\n', strlength(currentText) - strlength(seedText));
fprintf('  "%s"\n\n', currentText);

% - Step 9: Generate with Temperature Sampling -

fprintf('Step 9: Demonstrating temperature sampling...\n');

temperatures = [0.5, 1.0, 1.5];
numTemperatures = length(temperatures);

fprintf('  Comparing different temperature settings:\n\n');

for tempIdx = 1:numTemperatures
    temperature = temperatures(tempIdx);
    
    currentText = lower(seedText);
    
    for i = 1:50  % Shorter for comparison
        if strlength(currentText) >= sequenceLength
            inputChars = char(extractAfter(currentText, strlength(currentText) - sequenceLength));
        else
            inputChars = char(currentText);
        end
        
        inputSeq = zeros(sequenceLength, 1);
        for j = 1:min(length(inputChars), sequenceLength)
            charStr = string(inputChars(j));
            if isKey(char2idx, charStr)
                inputSeq(j) = char2idx(charStr);
            end
        end
        
        % Get probability distribution
        try
            predicted = classify(languageModel, inputSeq);
            % Note: MATLAB's classify returns categorical, 
            % actual temperature sampling would require predict() 
            % with raw scores
            nextCharIdx = double(predicted(end));
            
            if isKey(idx2char, nextCharIdx)
                nextChar = idx2char(nextCharIdx);
                currentText = currentText + nextChar;
            end
        catch
            break;
        end
    end
    
    fprintf('  Temperature %.1f: "%s"\n', temperature, currentText);
end

% - Step 10: Calculate Perplexity -

fprintf('\nStep 10: Computing model perplexity...\n');

% Evaluate on training data (ideally use validation set)
numEvalSamples = min(100, numSequences);
evalIndices = randperm(numSequences, numEvalSamples);

totalLogProb = 0;
totalTokens = 0;

for i = 1:numEvalSamples
    idx = evalIndices(i);
    inputSeq = XTrain{idx};
    targetSeq = YTrain{idx};
    
    try
        predicted = classify(languageModel, inputSeq);
        
        % Count correct predictions (simplified perplexity estimate)
        for j = 1:length(targetSeq)
            if predicted(j) == targetSeq(j)
                totalLogProb = totalLogProb + log(0.9);  % Simplified
            else
                totalLogProb = totalLogProb + log(0.1 / vocabSize);
            end
            totalTokens = totalTokens + 1;
        end
    catch
        continue;
    end
end

perplexity = exp(-totalLogProb / totalTokens);

fprintf('  Evaluated samples: %d\n', numEvalSamples);
fprintf('  Total tokens: %d\n', totalTokens);
fprintf('  Estimated perplexity: %.2f\n', perplexity);
fprintf('  (Lower perplexity indicates better model)\n');

% - Step 11: Visualisation -

fprintf('\nStep 11: Visualising language model properties...\n');

figure('Position', [100, 100, 1400, 900]);

% Plot 1: Character frequency in training text
subplot(2, 3, 1);
charCounts = zeros(vocabSize, 1);
for i = 1:textLength
    charStr = string(textChars(i));
    if isKey(char2idx, charStr)
        charCounts(char2idx(charStr)) = charCounts(char2idx(charStr)) + 1;
    end
end

[sortedCounts, sortedIdx] = sort(charCounts, 'descend');
topN = min(20, vocabSize);

bar(sortedCounts(1:topN), 'FaceColor', [0.3, 0.6, 0.9]);
xlabel('Character Rank');
ylabel('Frequency');
title('Character Frequency Distribution');
grid on;

% Plot 2: Sequence length distribution
subplot(2, 3, 2);
seqLengths = cellfun(@length, XTrain);
histogram(seqLengths, 20, 'FaceColor', [0.6, 0.4, 0.8]);
xlabel('Sequence Length');
ylabel('Count');
title('Training Sequence Lengths');
grid on;

% Plot 3: Simulated training loss curve
subplot(2, 3, 3);
epochs = 1:options.MaxEpochs;
% Simulate realistic loss curve (actual training would record this)
simulatedLoss = 4.5 * exp(-epochs/15) + 1.5 + 0.1 * randn(size(epochs));
plot(epochs, simulatedLoss, 'b-', 'LineWidth', 2);
xlabel('Epoch');
ylabel('Cross-Entropy Loss');
title('Training Loss Curve (Simulated)');
grid on;

% Plot 4: Perplexity vs epoch (simulated)
subplot(2, 3, 4);
simulatedPerplexity = exp(simulatedLoss);
plot(epochs, simulatedPerplexity, 'r-', 'LineWidth', 2);
xlabel('Epoch');
ylabel('Perplexity');
title('Perplexity Over Training (Simulated)');
grid on;

% Plot 5: Vocabulary coverage
subplot(2, 3, 5);
categories = categorical({'Total Vocab', 'Used in Text', 'Frequent (>10)'});
counts = [vocabSize, sum(charCounts > 0), sum(charCounts > 10)];
bar(categories, counts, 'FaceColor', [0.4, 0.7, 0.4]);
ylabel('Count');
title('Vocabulary Statistics');
grid on;

% Plot 6: Generated text length comparison
subplot(2, 3, 6);
genLengths = [strlength(seedText), 50, 100, generatedLength];
genLabels = {'Seed', 'Short', 'Medium', 'Long'};
bar(categorical(genLabels, genLabels), genLengths, 'FaceColor', [0.8, 0.5, 0.3]);
ylabel('Length (characters)');
title('Generation Length Options');
grid on;

sgtitle('Autoregressive Language Model Analysis', 'FontSize', 14, ...
    'FontWeight', 'bold');

print('language_model_analysis', '-dpng', '-r300');

fprintf('\nAutoregressive language model demonstration complete!\n');
fprintf('Model trained to predict next characters sequentially.\n');
