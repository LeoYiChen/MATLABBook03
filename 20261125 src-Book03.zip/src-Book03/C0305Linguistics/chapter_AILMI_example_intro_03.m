%% chapter_AILMI_example_intro_03.m
% Sentiment analysis using machine learning classification.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_intro_03
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Sample movie reviews with sentiment labels
reviews = ["Absolutely brilliant film, Oscar-worthy performance!";
           "Disappointing and boring, waste of time.";
           "Decent movie, had some good moments.";
           "Masterpiece! Best film of the year!";
           "Terrible acting, poor storyline.";
           "Enjoyable entertainment, worth watching."];

% Sentiment labels (1=Positive, 0=Negative)
sentiments = categorical([1; 0; 1; 1; 0; 1], [0 1], ...
                        {'Negative', 'Positive'});

% Preprocess text
documents = erasePunctuation(lower(tokenizedDocument(reviews)));
documents = removeStopWords(documents);

% Create bag-of-words features
bag = bagOfWords(documents);
X = bag.Counts;

% Train simple Naive Bayes classifier
mdl = fitcnb(X, sentiments);

% Test prediction on new review
newReview = "This film was exceptional and moving!";
newDoc = removeStopWords(erasePunctuation(...
         lower(tokenizedDocument(newReview))));
newFeatures = encode(bag, newDoc);
predictedSentiment = predict(mdl, newFeatures);

fprintf('Predicted sentiment: %s\n', char(predictedSentiment));
