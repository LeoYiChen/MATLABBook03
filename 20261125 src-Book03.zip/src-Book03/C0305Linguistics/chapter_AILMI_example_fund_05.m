%% chapter_AILMI_example_fund_05.m
% N-gram language model and text generation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_fund_05
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Training corpus for language model
corpus = ["The quick brown fox jumps over the lazy dog.";
          "The lazy cat sleeps on the warm mat.";
          "The brown dog chases the quick cat.";
          "The cat and dog play in the garden.";
          "The fox runs through the green garden."];

% Preprocess text
tokenDocs = tokenizedDocument(corpus);
tokenDocs = erasePunctuation(lower(tokenDocs));

% Extract all tokens for n-gram model
allTokens = [];
for i = 1:numel(tokenDocs)
    tokens = string(tokenDocs(i).Vocabulary)';
    allTokens = [allTokens; tokens];
end

% Build bigram model (word pairs)
bigramCounts = containers.Map('KeyType', 'char', ...
                              'ValueType', 'double');
unigramCounts = containers.Map('KeyType', 'char', ...
                               'ValueType', 'double');

% Count unigrams and bigrams
for i = 1:numel(tokenDocs)
    tokens = string(tokenDocs(i).Vocabulary)';
    
    % Count unigrams
    for j = 1:length(tokens)
        word = char(tokens(j));
        if isKey(unigramCounts, word)
            unigramCounts(word) = unigramCounts(word) + 1;
        else
            unigramCounts(word) = 1;
        end
    end
    
    % Count bigrams
    for j = 1:length(tokens)-1
        bigram = char(strjoin([tokens(j), tokens(j+1)], '|'));
        if isKey(bigramCounts, bigram)
            bigramCounts(bigram) = bigramCounts(bigram) + 1;
        else
            bigramCounts(bigram) = 1;
        end
    end
end

% Calculate bigram probabilities

% Display some bigram probabilities
fprintf('Sample Bigram Probabilities:\n');
fprintf('%-20*s %-20*s %s\n', 'Word 1', 'Word 2', 'P(W2|W1)');
fprintf('%-20*s %-20*s %s\n', '-', '-', '--');

testPairs = {{'the', 'cat'}, {'the', 'dog'}, {'quick', 'brown'}, ...
             {'lazy', 'cat'}, {'brown', 'fox'}};

for i = 1:length(testPairs)
    pair = testPairs{i};
    prob = bigramProbability(pair{1}, pair{2}, ...
                            bigramCounts, unigramCounts);
    fprintf('%-20*s %-20*s %.4f\n', pair{1}, pair{2}, prob);
end

% Generate text using bigram model

% Generate sample sentences
fprintf('\n\nGenerated Text Samples:\n');
for i = 1:5
    rng(i);  % Different seed for each sample
    generated = generateText('the', 8, bigramCounts, unigramCounts);
    fprintf('  %d. %s\n', i, generated);
end

% Calculate model perplexity on test sentence
testSentence = "the cat jumps over the dog";
testTokens = lower(tokenizedDocument(testSentence));
testWords = string(testTokens.Vocabulary)';

logProb = 0;
numBigrams = 0;

for i = 1:length(testWords)-1
    prob = bigramProbability(testWords(i), testWords(i+1), ...
                            bigramCounts, unigramCounts);
    if prob > 0
        logProb = logProb + log2(prob);
        numBigrams = numBigrams + 1;
    end
end

perplexity = 2^(-logProb / numBigrams);
fprintf('\nTest sentence: "%s"\n', testSentence);
fprintf('Perplexity: %.2f\n', perplexity);

% Local functions (moved to end so this listing is a valid MATLAB script)
function prob = bigramProbability(word1, word2, ...
                                 bigramCounts, unigramCounts)
    bigram = char(strjoin([string(word1), string(word2)], '|'));
    word1Char = char(word1);
    
    if isKey(bigramCounts, bigram) && isKey(unigramCounts, word1Char)
        prob = bigramCounts(bigram) / unigramCounts(word1Char);
    else
        prob = 0;
    end
end

function generatedText = generateText(startWord, length, ...
                                     bigramCounts, unigramCounts)
    generatedText = string(startWord);
    currentWord = startWord;
    
    for i = 1:length-1
        % Find all possible next words
        bigramKeys = keys(bigramCounts);
        possibleWords = [];
        probabilities = [];
        
        for j = 1:length(bigramKeys)
            key = bigramKeys{j};
            parts = split(string(key), '|');
            if strcmp(parts(1), currentWord)
                possibleWords = [possibleWords; parts(2)];
                prob = bigramProbability(currentWord, parts(2), ...
                                        bigramCounts, unigramCounts);
                probabilities = [probabilities; prob];
            end
        end
        
        if isempty(possibleWords)
            break;
        end
        
        % Sample next word based on probabilities
        probabilities = probabilities / sum(probabilities);
        cumulativeProb = cumsum(probabilities);
        randVal = rand();
        nextIdx = find(cumulativeProb >= randVal, 1, 'first');
        nextWord = possibleWords(nextIdx);
        
        generatedText = strjoin([generatedText, nextWord], ' ');
        currentWord = nextWord;
    end
end
