%% chapter_AILMI_example_fund_03.m
% TF-IDF weighting and document retrieval.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_fund_03
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Document corpus for information retrieval
corpus = ["Artificial intelligence transforms healthcare delivery.";
          "Machine learning improves diagnostic accuracy in medicine.";
          "Deep neural networks process medical imaging data.";
          "Healthcare systems integrate AI technologies.";
          "Quantum computing promises revolutionary capabilities.";
          "Quantum algorithms solve complex optimisation problems."];

% Preprocess documents
tokenDocs = tokenizedDocument(corpus);
tokenDocs = erasePunctuation(lower(tokenDocs));
tokenDocs = removeStopWords(tokenDocs);

% Create bag-of-words and calculate TF-IDF
bag = bagOfWords(tokenDocs);
tfidfMatrix = tfidf(bag);

fprintf('TF-IDF Matrix dimensions: %d documents x %d terms\n', ...
        size(tfidfMatrix, 1), size(tfidfMatrix, 2));

% Query-based document retrieval
query = "artificial intelligence healthcare";
queryDoc = removeStopWords(erasePunctuation(...
           lower(tokenizedDocument(query))));

% Encode query using same vocabulary
queryVec = encode(bag, queryDoc);
queryTFIDF = tfidf(bag, queryVec);

% Calculate similarity between query and all documents
numDocs = size(tfidfMatrix, 1);
similarities = zeros(numDocs, 1);

for i = 1:numDocs
    docVec = tfidfMatrix(i, :);
    similarities(i) = dot(queryTFIDF, docVec) / ...
                      (norm(queryTFIDF) * norm(docVec) + eps);
end

% Rank documents by relevance
[sortedScores, rankedIndices] = sort(similarities, 'descend');

fprintf('\nQuery: "%s"\n\n', query);
fprintf('Ranked Documents:\n');
fprintf('%-5*s %-10*s %s\n', 'Rank', 'Score', 'Document');
fprintf('%-5*s %-10*s %s\n', '-', '--', '--');

for i = 1:numDocs
    idx = rankedIndices(i);
    fprintf('%-5*d %-10.4*f %s\n', i, sortedScores(i), corpus(idx));
end

% Visualise TF-IDF weights for top document
topDocIdx = rankedIndices(1);
topDocWeights = tfidfMatrix(topDocIdx, :);
[sortedWeights, wordIndices] = sort(topDocWeights, 'descend');

% Display top weighted terms
fprintf('\nTop weighted terms in most relevant document:\n');
vocab = bag.Vocabulary;
for i = 1:min(10, length(wordIndices))
    if sortedWeights(i) > 0
        wordIdx = wordIndices(i);
        fprintf('  %s: %.4f\n', vocab(wordIdx), sortedWeights(i));
    end
end

% Visualise TF-IDF distribution
figure;
histogram(tfidfMatrix(:), 50);
xlabel('TF-IDF Weight');
ylabel('Frequency');
title('Distribution of TF-IDF Weights');
grid on;
