%% chapter_AILMI_example_AI_05.m
% LSTM networks for text generation and sentiment classification.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_AI_05
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Part 1: Text Generation using LSTM

% Training text for character-level generation
trainingText = [ ...
    "The quick brown fox jumps over the lazy dog. " ...
    "The cat sat on the mat and watched the bird. " ...
    "The dog ran through the park chasing butterflies. " ...
    "The bird flew high above the trees singing songs. " ...
    "The fish swam gracefully through the clear water."];

% Character-level vocabulary
chars = unique(char(trainingText));
numChars = length(chars);
char2idx = containers.Map(cellstr(chars'), 1:numChars);

fprintf('Character-Level LSTM Language Model\n');
fprintf('Vocabulary size: %d characters\n', numChars);
fprintf('Training text length: %d characters\n\n', ...
        length(trainingText));

% Prepare sequence data
sequenceLength = 20;
XTrain = {};
YTrain = {};

for i = 1:length(trainingText)-sequenceLength
    inputSeq = trainingText(i:i+sequenceLength-1);
    targetChar = trainingText(i+sequenceLength);
    
    % One-hot encode input sequence
    inputEncoded = zeros(numChars, sequenceLength);
    for j = 1:sequenceLength
        charIdx = char2idx(inputSeq(j));
        inputEncoded(charIdx, j) = 1;
    end
    
    XTrain{end+1} = inputEncoded;
    YTrain{end+1} = char2idx(targetChar);
end

fprintf('Training sequences created: %d\n', length(XTrain));

% Define LSTM architecture for generation
numHiddenUnits = 128;

layersGen = [ ...
    sequenceInputLayer(numChars)
    lstmLayer(numHiddenUnits, 'OutputMode', 'last')
    dropoutLayer(0.2)
    fullyConnectedLayer(numChars)
    softmaxLayer
    classificationLayer];

% Training options
optionsGen = trainingOptions('adam', ...
    'MaxEpochs', 150, ...
    'MiniBatchSize', 64, ...
    'GradientThreshold', 1, ...
    'Shuffle', 'every-epoch', ...
    'Verbose', false);

% Train generation model
fprintf('\nTraining text generation LSTM...\n');
XTrainGen = XTrain';
YTrainGen = categorical([YTrain{:}]');

netGen = trainNetwork(XTrainGen, YTrainGen, layersGen, optionsGen);
fprintf('Generation model training completed.\n');

% Generate text

% Generate sample text
idx2char = containers.Map(1:numChars, cellstr(chars'));
seedText = "The cat sat on the ";
generatedOutput = generateText(netGen, seedText, 100, ...
                               char2idx, idx2char, numChars);

fprintf('\nGenerated Text:\n');
fprintf('Seed: "%s"\n', seedText);
fprintf('Output: "%s"\n\n', generatedOutput);

% Part 2: Sentiment Classification using LSTM

% Sentiment training data
sentimentTexts = [ ...
    "This product is absolutely wonderful and amazing."; ...
    "Terrible quality, completely waste of money."; ...
    "Excellent performance, highly recommended purchase."; ...
    "Disappointing results, not worth the price."; ...
    "Outstanding features, exceeded expectations."; ...
    "Poor design, numerous quality issues."; ...
    "Fantastic value, extremely satisfied customer."; ...
    "Awful experience, requesting immediate refund."; ...
    "Brilliant innovation, love this product."; ...
    "Horrible service, will never buy again."];

sentimentLabels = categorical([1; 0; 1; 0; 1; 0; 1; 0; 1; 0]);

% Preprocess sentiment data
sentDocs = tokenizedDocument(sentimentTexts);
sentDocs = erasePunctuation(lower(sentDocs));
sentDocs = removeStopWords(sentDocs);

% Create word embeddings
embDim = 50;
sentEmb = wordEmbedding(sentDocs, embDim);

% Prepare padded sequences
maxSeqLen = 10;
XSent = zeros(embDim, maxSeqLen, numel(sentDocs));

for i = 1:numel(sentDocs)
    words = sentDocs(i).Vocabulary;
    numWords = min(numel(words), maxSeqLen);
    
    for j = 1:numWords
        wordVec = word2vec(sentEmb, words(j));
        XSent(:, j, i) = wordVec;
    end
end

% Define LSTM architecture for sentiment
layersSent = [ ...
    sequenceInputLayer(embDim)
    lstmLayer(64, 'OutputMode', 'last')
    dropoutLayer(0.3)
    fullyConnectedLayer(2)
    softmaxLayer
    classificationLayer];

% Training options
optionsSent = trainingOptions('adam', ...
    'MaxEpochs', 100, ...
    'MiniBatchSize', 2, ...
    'Shuffle', 'every-epoch', ...
    'Verbose', false);

% Train sentiment model
fprintf('Training sentiment classification LSTM...\n');
netSent = trainNetwork(XSent, sentimentLabels, ...
                       layersSent, optionsSent);
fprintf('Sentiment model training completed.\n\n');

% Test sentiment classification
testSents = [ ...
    "This is an excellent and wonderful product."; ...
    "Terrible quality and poor customer service."];

fprintf('Sentiment Classification Results:\n');

for i = 1:length(testSents)
    testDoc = removeStopWords(erasePunctuation(...
              lower(tokenizedDocument(testSents(i)))));
    
    testSeq = zeros(embDim, maxSeqLen);
    words = testDoc.Vocabulary;
    numWords = min(numel(words), maxSeqLen);
    
    for j = 1:numWords
        wordVec = word2vec(sentEmb, words(j));
        testSeq(:, j) = wordVec;
    end
    
    [predLabel, scores] = classify(netSent, testSeq);
    
    fprintf('\n  Text: "%s"\n', testSents(i));
    fprintf('  Prediction: %s\n', string(predLabel));
    fprintf('  Confidence: %.2f%%\n', max(scores) * 100);
end

% Visualisations
figure('Position', [100, 100, 1200, 400]);

% LSTM cell state evolution
subplot(1, 2, 1);
sampleSeq = XSent(:, :, 1);
lstmAct = activations(netSent, sampleSeq, 'lstm_1');

plot(lstmAct, 'LineWidth', 1.5);
xlabel('Hidden Unit Index');
ylabel('Activation Value');
title('LSTM Hidden State Activations');
grid on;

% Sentiment classification confusion matrix
subplot(1, 2, 2);
trainPred = classify(netSent, XSent);
confusionchart(sentimentLabels, trainPred);
title('Sentiment Classification Performance');

% Local functions (moved to end so this listing is a valid MATLAB script)
function generatedText = generateText(net, seed, length, ...
                                     char2idx, idx2char, numChars)
    generatedText = seed;
    currentSeq = seed;
    
    for i = 1:length
        % Encode current sequence
        inputSeq = zeros(numChars, numel(currentSeq));
        for j = 1:numel(currentSeq)
            if isKey(char2idx, currentSeq(j))
                inputSeq(char2idx(currentSeq(j)), j) = 1;
            end
        end
        
        % Predict next character
        scores = predict(net, inputSeq);
        [~, nextIdx] = max(scores);
        nextChar = idx2char(nextIdx);
        
        generatedText = [generatedText, nextChar];
        
        % Update sequence (sliding window)
        if numel(currentSeq) >= 20
            currentSeq = [currentSeq(2:end), nextChar];
        else
            currentSeq = [currentSeq, nextChar];
        end
    end
end
