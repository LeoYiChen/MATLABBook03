%% chapter_AILMI_example_AI_03.m
% Random Forest ensemble learning for text classification.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_AI_03
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Expanded training corpus for robust ensemble learning
trainingCorpus = [
    "Machine learning transforms data analysis capabilities.";
    "Neural networks enable pattern recognition systems.";
    "Deep learning revolutionises artificial intelligence.";
    "Algorithm optimisation improves computational efficiency.";
    "Stock market volatility affects investment returns.";
    "Financial derivatives hedge portfolio risk exposure.";
    "Economic indicators predict market trends.";
    "Cryptocurrency trading requires risk management.";
    "Cellular biology studies living organism functions.";
    "Genetic engineering modifies DNA sequences.";
    "Protein folding determines molecular structure.";
    "Evolutionary biology explains species adaptation.";
    "Quantum mechanics governs subatomic behaviour.";
    "Thermodynamics describes energy transformations.";
    "Particle physics explores fundamental forces.";
    "Relativity theory revolutionised space-time understanding.";
    "Computer vision enables image understanding.";
    "Natural language processing analyses text data.";
    "Cryptocurrency blockchain ensures transaction security.";
    "Portfolio diversification reduces investment risk.";
    "Molecular biology investigates cellular processes.";
    "Ecological systems exhibit complex interactions.";
    "Statistical mechanics connects microscopic dynamics.";
    "Quantum computing promises computational breakthroughs."];

% Domain labels: 1 = Technology, 2 = Finance, 
%                3 = Biology, 4 = Physics
domainLabels = categorical([1; 1; 1; 1; 2; 2; 2; 2; ...
                            3; 3; 3; 3; 4; 4; 4; 4; ...
                            1; 1; 2; 2; 3; 3; 4; 4]);

% Preprocess and create feature matrix
trainTokens = tokenizedDocument(trainingCorpus);
trainTokens = erasePunctuation(lower(trainTokens));
trainTokens = removeStopWords(trainTokens);

bag = bagOfWords(trainTokens);
featureMatrix = tfidf(bag);

fprintf('Random Forest Text Classification\n');
fprintf('Training set size: %d documents\n', size(featureMatrix, 1));
fprintf('Feature dimension: %d terms\n\n', size(featureMatrix, 2));

% Train Random Forest with different numbers of trees
numTreesOptions = [10, 50, 100, 200];
oobErrors = zeros(length(numTreesOptions), 1);

fprintf('Training Random Forests with varying ensemble sizes:\n');

for i = 1:length(numTreesOptions)
    nTrees = numTreesOptions(i);
    
    % Train Random Forest using TreeBagger
    randomForest = TreeBagger(nTrees, featureMatrix, domainLabels, ...
                              'OOBPrediction', 'On', ...
                              'Method', 'classification', ...
                              'MinLeafSize', 1);
    
    % Calculate out-of-bag error
    oobError = oobError(randomForest);
    oobErrors(i) = oobError(end);
    
    fprintf('  %3*d trees: OOB Error = %.4f (%.2f%% accuracy)\n', ...
            nTrees, oobError(end), (1 - oobError(end)) * 100);
end

% Train final model with optimal number of trees
optimalTrees = 100;
finalForest = TreeBagger(optimalTrees, featureMatrix, domainLabels, ...
                         'OOBPrediction', 'On', ...
                         'OOBPredictorImportance', 'On', ...
                         'Method', 'classification', ...
                         'MinLeafSize', 1);

fprintf('\nFinal Random Forest Model:\n');
fprintf('  Number of trees: %d\n', optimalTrees);
fprintf('  OOB accuracy: %.2f%%\n', (1 - oobError(finalForest, 'end')) * 100);

% Feature importance analysis
featureImportance = finalForest.OOBPermutedPredictorDeltaError;
[sortedImportance, importanceIndices] = sort(featureImportance, 'descend');

fprintf('\nMost Important Features:\n');
vocabulary = bag.Vocabulary;

for i = 1:min(15, length(importanceIndices))
    idx = importanceIndices(i);
    fprintf('  %2*d. %-20*s (importance: %.6f)\n', ...
            i, vocabulary(idx), sortedImportance(i));
end

% Test document classification
testDocs = [
    "Artificial neural networks learn complex patterns from data.";
    "Investment strategies require careful risk assessment.";
    "Genetic mu*tations drive evolutionary adaptation.";
    "Quantum entanglement exhibits non-local correlations."];

testTokens = tokenizedDocument(testDocs);
testTokens = erasePunctuation(lower(testTokens));
testTokens = removeStopWords(testTokens);
testFeatures = tfidf(bag, encode(bag, testTokens));

% Predict with probability estimates
[predictions, scores] = predict(finalForest, testFeatures);

fprintf('\nClassification Results:\n');
domainNames = ["Technology", "Finance", "Biology", "Physics"];

for i = 1:length(testDocs)
    fprintf('\nDocument %d: "%s"\n', i, testDocs(i));
    fprintf('  Predicted: %s\n', predictions{i});
    fprintf('  Confidence Distribution:\n');
    
    for j = 1:length(domainNames)
        fprintf('    %s: %.2f%%\n', domainNames(j), scores(i, j) * 100);
    end
end

% Visualisations
figure('Position', [100, 100, 1400, 500]);

% OOB error vs number of trees
subplot(1, 3, 1);
plot(oobError(finalForest), 'LineWidth', 2);
xlabel('Number of Trees');
ylabel('Out-of-Bag Error');
title('Random Forest Convergence');
grid on;

% Feature importance
subplot(1, 3, 2);
topN = 10;
topFeatures = vocabulary(importanceIndices(1:topN));
topImportances = sortedImportance(1:topN);

barh(topImportances);
set(gca, 'YTickLabel', topFeatures, 'YDir', 'reverse');
xlabel('Importance Score');
title('Top 10 Feature Importance');
grid on;

% Confusion matrix
subplot(1, 3, 3);
trainPredictions = predict(finalForest, featureMatrix);
trainPredictionsCateg = categorical(trainPredictions);
confusionchart(domainLabels, trainPredictionsCateg);
title('Training Set Confusion Matrix');
