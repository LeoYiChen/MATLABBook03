%% chapter_AILMI_example_hist_01.m
% Simple pattern-matching chatbot inspired by ELIZA.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_hist_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Example usage
userStatement = "I am feeling anxious about work";
botResponse = simpleEliza(userStatement);
fprintf('User: %s\n', userStatement);
fprintf('ELIZA: %s\n', botResponse);

% Local functions (moved to end so this listing is a valid MATLAB script)
function response = simpleEliza(userInput)
    % Convert input to lowercase for pattern matching
    userInput = lower(char(userInput));
    
    % Define pattern-response pairs
    patterns = {'i am ', 'i feel ', 'i think ', ...
                'i want ', 'my ', 'why '};
    responses = {'Why do you say you are %s?', ...
                 'Tell me more about feeling %s.', ...
                 'What makes you think %s?', ...
                 'What would it mean if you got %s?', ...
                 'Tell me more about your %s.', ...
                 'Why do you ask about %s?'};
    
    % Default response
    response = 'Please tell me more.';
    
    % Search for patterns and generate response
    for i = 1:length(patterns)
        if contains(userInput, patterns{i})
            % Extract content after pattern
            idx = strfind(userInput, patterns{i});
            content = userInput(idx + length(patterns{i}):end);
            response = sprintf(responses{i}, content);
            return;
        end
    end
end
