%% chapter_AILMI_example_InfluencerID_01.m
% Influencer identification through network analysis combining centrality metrics and engagement patterns with community detection.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_InfluencerID_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Influencer Identification in Social Networks
% Demonstrates network analysis for identifying influential users

fprintf('=== Influencer Identification System ===\n\n');

% - Step 1: Generate Synthetic Social Network -

fprintf('Step 1: Constructing synthetic social network...\n');

% Network parameters
numUsers = 200;
connectionProb = 0.03;  % Sparse network

% Generate random graph (Erd?s-Rényi model)
rng(42);
adjacencyMatrix = rand(numUsers) < connectionProb;
adjacencyMatrix = triu(adjacencyMatrix, 1);  % Upper triangular (undirected)
adjacencyMatrix = adjacencyMatrix + adjacencyMatrix';  % Make symmetric

% Add preferential attachment (scale-free properties)
% High-degree hubs get more connections
degrees = sum(adjacencyMatrix, 2);
for userIdx = 1:round(numUsers * 0.1)  % 10% get bonus connections
    [~, hubIdx] = max(degrees);
    
    % Connect hub to random users
    numNewConnections = randi([5, 15]);
    targetUsers = randperm(numUsers, numNewConnections);
    
    for targetIdx = 1:length(targetUsers)
        target = targetUsers(targetIdx);
        if target ~= hubIdx
            adjacencyMatrix(hubIdx, target) = 1;
            adjacencyMatrix(target, hubIdx) = 1;
        end
    end
    
    degrees = sum(adjacencyMatrix, 2);
    degrees(hubIdx) = 0;  % Don't select same hub again
end

% Create graph object
socialGraph = graph(adjacencyMatrix);

numEdges = socialGraph.numedges;
avgDegree = mean(degree(socialGraph));

fprintf('  Network: %d users, %d connections\n', numUsers, numEdges);
fprintf('  Average degree: %.2f\n', avgDegree);
fprintf('  Network density: %.4f\n\n', 2*numEdges/(numUsers*(numUsers-1)));

% - Step 2: Simulate User Engagement Metrics -

fprintf('Step 2: Simulating user engagement metrics...\n');

% User engagement metrics (correlated with network position)
userDegrees = degree(socialGraph);

% Posts per user (higher degree users post more)
postsPerUser = round(20 + userDegrees * 2 + randn(numUsers, 1) * 5);
postsPerUser(postsPerUser < 1) = 1;

% Engagement rates (likes, shares per post)
engagementRates = 0.05 + userDegrees / max(userDegrees) * 0.3 + ...
    randn(numUsers, 1) * 0.05;
engagementRates(engagementRates < 0) = 0.01;

% Response rates (replies received)
responseRates = 0.03 + userDegrees / max(userDegrees) * 0.2 + ...
    randn(numUsers, 1) * 0.04;
responseRates(responseRates < 0) = 0.01;

% Amplification factor (how often content is shared)
amplificationFactors = 1 + userDegrees / max(userDegrees) * 4 + ...
    randn(numUsers, 1) * 0.5;
amplificationFactors(amplificationFactors < 0.5) = 0.5;

fprintf('  Generated engagement metrics for %d users\n', numUsers);
fprintf('  Average posts per user: %.1f\n', mean(postsPerUser));
fprintf('  Average engagement rate: %.3f\n', mean(engagementRates));
fprintf('  Average amplification: %.2fx\n\n', mean(amplificationFactors));

% - Step 3: Calculate Network Centrality Metrics -

fprintf('Step 3: Computing network centrality measures...\n');

% Degree centrality (already have from graph)
degreeCentrality = userDegrees / max(userDegrees);  % Normalised

% Betweenness centrality
betweennessCentrality = centrality(socialGraph, 'betweenness', 'Cost', ...
    socialGraph.Edges.Weight);
betweennessCentrality = betweennessCentrality / max(betweennessCentrality);

% Closeness centrality
closenessCentrality = centrality(socialGraph, 'closeness', 'Cost', ...
    socialGraph.Edges.Weight);
closenessCentrality = closenessCentrality / max(closenessCentrality);

% Eigenvector centrality (PageRank variant)
eigenvectorCentrality = centrality(socialGraph, 'eigenvector', 'Importance', ...
    socialGraph.Edges.Weight);
eigenvectorCentrality = eigenvectorCentrality / max(eigenvectorCentrality);

% PageRank
pageRankScores = centrality(socialGraph, 'pagerank');
pageRankScores = pageRankScores / max(pageRankScores);

fprintf('  Computed 5 centrality metrics\n');
fprintf('  Average degree centrality: %.3f\n', mean(degreeCentrality));
fprintf('  Average betweenness: %.3f\n', mean(betweennessCentrality));
fprintf('  Average closeness: %.3f\n', mean(closenessCentrality));
fprintf('  Average eigenvector centrality: %.3f\n', mean(eigenvectorCentrality));
fprintf('  Average PageRank: %.3f\n\n', mean(pageRankScores));

% - Step 4: Composite Influence Score -

fprintf('Step 4: Computing composite influence scores...\n');

% Combine network centrality and engagement metrics
% Weighted combination (weights sum to 1)
weights = struct();
weights.pagerank = 0.25;
weights.betweenness = 0.15;
weights.engagement = 0.25;
weights.amplification = 0.20;
weights.response = 0.15;

influenceScores = weights.pagerank * pageRankScores + ...
    weights.betweenness * betweennessCentrality + ...
    weights.engagement * (engagementRates / max(engagementRates)) + ...
    weights.amplification * (amplificationFactors / max(amplificationFactors)) + ...
    weights.response * (responseRates / max(responseRates));

% Normalise to [0, 1]
influenceScores = influenceScores / max(influenceScores);

fprintf('  Computed composite influence scores\n');
fprintf('  Weight distribution: PageRank=%.0f%%, Betweenness=%.0f%%, ' + ...
    'Engagement=%.0f%%, Amplification=%.0f%%, Response=%.0f%%\n', ...
    weights.pagerank*100, weights.betweenness*100, weights.engagement*100, ...
    weights.amplification*100, weights.response*100);
fprintf('  Average influence score: %.3f\n\n', mean(influenceScores));

% Identify top influencers
numTopInfluencers = 10;
[sortedScores, influencerIdx] = sort(influenceScores, 'descend');
topInfluencers = influencerIdx(1:numTopInfluencers);

fprintf('  Top %d influencers identified:\n', numTopInfluencers);
for i = 1:numTopInfluencers
    userIdx = topInfluencers(i);
    fprintf('    User %3*d: Influence=%.3f, Degree=%d, PageRank=%.3f\n', ...
        userIdx, influenceScores(userIdx), userDegrees(userIdx), ...
        pageRankScores(userIdx));
end
fprintf('\n');

% - Step 5: Community Detection -

fprintf('Step 5: Detecting network communities...\n');

% Find communities using modularity optimisation
communities = conncomp(socialGraph);

% If network is connected, use alternative method
if max(communities) == 1
    % Use clustering coefficient-based approach
    % Simplified: use k-means on adjacency patterns
    [communities, ~] = kmeans(adjacencyMatrix, 5, 'Replicates', 10);
end

numCommunities = max(communities);

fprintf('  Detected %d communities\n', numCommunities);

% Find influential users in each community
communityInfluencers = cell(numCommunities, 1);

for commIdx = 1:numCommunities
    commMembers = find(communities == commIdx);
    
    if isempty(commMembers)
        continue;
    end
    
    % Top influencer in this community
    [~, localMaxIdx] = max(influenceScores(commMembers));
    communityInfluencers{commIdx} = commMembers(localMaxIdx);
    
    fprintf('    Community %d: %d members, top influencer = User %d\n', ...
        commIdx, length(commMembers), communityInfluencers{commIdx});
end
fprintf('\n');

% - Step 6: Influence Propagation Simulation -

fprintf('Step 6: Simulating influence propagation...\n');

% Select seed user (top influencer)
seedUser = topInfluencers(1);

% Simulate information cascade (Independent Cascade Model)
% Each edge has probability of activation
activationProb = 0.1;

activated = false(numUsers, 1);
activated(seedUser) = true;
newlyActivated = seedUser;

cascadeSteps = [];
stepCount = 0;
maxSteps = 10;

while ~isempty(newlyActivated) && stepCount < maxSteps
    stepCount = stepCount + 1;
    currentActivated = [];
    
    for userIdx = 1:length(newlyActivated)
        user = newlyActivated(userIdx);
        
        % Find neighbours
        neighbours = find(adjacencyMatrix(user, :));
        
        for neighIdx = 1:length(neighbours)
            neighbour = neighbours(neighIdx);
            
            % Try to activate if not already activated
            if ~activated(neighbour) && rand() < activationProb
                activated(neighbour) = true;
                currentActivated = [currentActivated; neighbour];
            end
        end
    end
    
    newlyActivated = currentActivated;
    cascadeSteps = [cascadeSteps; length(currentActivated)];
end

totalActivated = sum(activated);
cascadeReach = totalActivated / numUsers;

fprintf('  Cascade from User %d reached %d users (%.1f%% of network)\n', ...
    seedUser, totalActivated, cascadeReach * 100);
fprintf('  Cascade completed in %d steps\n\n', stepCount);

% - Step 7: Influencer Diversity Analysis -

fprintf('Step 7: Analysing influencer diversity...\n');

% Check if top influencers span different communities
influencerCommunities = communities(topInfluencers);
uniqueCommRepresented = length(unique(influencerCommunities));

fprintf('  Top influencers span %d different communities\n', ...
    uniqueCommRepresented);
fprintf('  Community representation: %.1f%%\n\n', ...
    (uniqueCommRepresented / numCommunities) * 100);

% - Step 8: Correlation Analysis -

fprintf('Step 8: Analysing metric correlations...\n');

% Correlation between different centrality metrics
metricsMatrix = [degreeCentrality, betweennessCentrality, closenessCentrality, ...
    eigenvectorCentrality, pageRankScores];
metricNames = {'Degree', 'Betweenness', 'Closeness', 'Eigenvector', 'PageRank'};

corrMatrix = corr(metricsMatrix);

fprintf('  Correlation matrix computed\n');
fprintf('  Highest correlation: %.3f (Degree-Eigenvector)\n', ...
    max(corrMatrix(corrMatrix < 0.999)));  % Exclude diagonal
fprintf('  Lowest correlation: %.3f\n\n', min(corrMatrix(:)));

% - Step 9: Visualisation -

fprintf('Step 9: Generating network visualisations...\n');

figure('Position', [100, 100, 1800, 1200]);

% Plot 1: Network graph with influence-based sizing
subplot(2, 3, 1);
plot(socialGraph, 'NodeCData', influenceScores, 'MarkerSize', ...
    5 + influenceScores * 15, 'Layout', 'force');
colormap(gca, parula);
colorbar;
title('Social Network (node size = influence)');
axis off;

% Plot 2: Influence score distribution
subplot(2, 3, 2);
histogram(influenceScores, 30, 'Normalization', 'probability', ...
    'FaceColor', [0.3, 0.6, 0.9]);
xlabel('Influence Score');
ylabel('Probability');
title('Influence Score Distribution');
grid on;

% Plot 3: Top influencers comparison
subplot(2, 3, 3);
influencerMetrics = [pageRankScores(topInfluencers), ...
    betweennessCentrality(topInfluencers), ...
    engagementRates(topInfluencers) / max(engagementRates)];
bar(influencerMetrics, 'grouped');
xlabel('Top Influencer Rank');
ylabel('Normalised Score');
legend('PageRank', 'Betweenness', 'Engagement', 'Location', 'best');
title('Top 10 Influencers: Metric Breakdown');
grid on;

% Plot 4: Degree distribution (log-log for power law)
subplot(2, 3, 4);
[degreeCount, degreeEdges] = histcounts(userDegrees, 'BinMethod', 'integers');
degreeValues = degreeEdges(1:end-1);
loglog(degreeValues, degreeCount, 'bo-', 'MarkerSize', 8, 'LineWidth', 1.5);
xlabel('Degree (log scale)');
ylabel('Frequency (log scale)');
title('Degree Distribution (Power Law)');
grid on;

% Plot 5: Centrality correlation heatmap
subplot(2, 3, 5);
imagesc(corrMatrix);
colorbar;
colormap(gca, hot);
set(gca, 'XTick', 1:5, 'XTickLabel', metricNames, 'XTickLabelRotation', 45, ...
    'YTick', 1:5, 'YTickLabel', metricNames);
title('Centrality Metric Correlations');

% Plot 6: Cascade propagation
subplot(2, 3, 6);
if ~isempty(cascadeSteps)
    bar(1:length(cascadeSteps), cascadeSteps, 'FaceColor', [0.6, 0.4, 0.8]);
    xlabel('Cascade Step');
    ylabel('Newly Activated Users');
    title(sprintf('Influence Cascade from User %d', seedUser));
    grid on;
end

sgtitle('Influencer Identification and Network Analysis', 'FontSize', 14, ...
    'FontWeight', 'bold');

print('influencer_network_analysis', '-dpng', '-r300');

fprintf('\nInfluencer identification complete!\n');
fprintf('Identified %d top influencers with average score %.3f\n', ...
    numTopInfluencers, mean(influenceScores(topInfluencers)));
fprintf('Simulated cascade reached %.1f%% of network.\n', cascadeReach * 100);
