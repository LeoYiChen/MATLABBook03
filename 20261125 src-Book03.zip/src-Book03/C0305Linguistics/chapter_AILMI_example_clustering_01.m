%% chapter_AILMI_example_clustering_01.m
% Document clustering using k-means with dimensionality reduction and comprehensive cluster evaluation including silhouette analysis and topic-cluster integration.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_clustering_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Document Clustering System
% Demonstrates clustering algorithms for organising text collections

fprintf('=== Document Clustering System ===\n\n');

% - Step 1: Prepare Document Corpus -

fprintf('Step 1: Loading document corpus for clustering...\n');

% Extended document collection spanning multiple topics
documents = [
    % Technology cluster
    "Machine learning algorithms analyse large datasets efficiently";
    "Neural networks enable deep learning applications";
    "Artificial intelligence transforms business processes";
    "Computer vision systems recognise objects accurately";
    "Natural language processing understands text semantics";
    
    % Climate cluster  
    "Global warming accelerates ice sheet melting";
    "Renewable energy reduces carbon dioxide emissions";
    "Climate change impacts agricultural productivity";
    "Greenhouse gases trap atmospheric heat";
    "Sustainable practices mitigate environmental damage";
    
    % Finance cluster
    "Stock markets exhibit price volatility patterns";
    "Investment portfolios balance risk and return";
    "Economic indicators predict market trends";
    "Financial derivatives hedge investment risks";
    "Central banks regulate monetary policy";
    
    % Healthcare cluster
    "Precision medicine personalises patient treatments";
    "Medical imaging diagnostics improve accuracy";
    "Pharmaceutical research develops novel therapeutics";
    "Clinical trials evaluate treatment efficacy";
    "Genetic sequencing identifies disease mu*tations";
    
    % Sports cluster
    "Athletes optimise training regimens systematically";
    "Sports analytics employ statistical models";
    "Team strategies leverage performance data";
    "Professional competitions attract global audiences";
    "Physical conditioning prevents athletic injuries";
    
    % Space cluster
    "Spacecraft explore planetary surfaces remotely";
    "Astronomical observations reveal cosmic phenomena";
    "Satellite systems provide communications coverage";
    "Rocket propulsion enables orbital launches";
    "Astrophysics models predict stellar evolution";
    
    % Politics cluster
    "Electoral systems determine governmental representation";
    "Political campaigns influence voter decisions";
    "Legislative processes enact policy changes";
    "International diplomacy resolves conflicts peacefully";
    "Democratic institutions uphold civil liberties";
    
    % Education cluster
    "Pedagogical methods enhance student learning";
    "Educational technology facilitates remote instruction";
    "Assessment systems measure knowledge acquisition";
    "Curriculum design aligns learning objectives";
    "Teacher training improves instructional quality"
];

numDocuments = length(documents);
fprintf('  Total documents: %d\n\n', numDocuments);

% - Step 2: Text Preprocessing and Vectorisation -

fprintf('Step 2: Preprocessing and vectorising documents...\n');

% Tokenise and clean
tokenizedDocs = tokenizedDocument(documents);
tokenizedDocs = removeStopWords(tokenizedDocs);
tokenizedDocs = removeShortWords(tokenizedDocs, 3);
tokenizedDocs = normalizeWords(tokenizedDocs, 'Style', 'lemma');

% Create bag-of-words and compute TF-IDF
bag = bagOfWords(tokenizedDocs);
tfidfFeatures = tfidf(bag);
tfidfFeatures = full(tfidfFeatures);

[numDocs, numFeatures] = size(tfidfFeatures);
fprintf('  Feature matrix: %d documents x %d features\n', numDocs, numFeatures);
fprintf('  Feature type: TF-IDF weighted term frequencies\n\n');

% - Step 3: Dimensionality Reduction (PCA) -

fprintf('Step 3: Applying PCA for dimensionality reduction...\n');

% Determine optimal number of components (retain 90% variance)
[coeff, score, latent, ~, explained] = pca(tfidfFeatures);

cumulativeVariance = cumsum(explained);
numComponentsFor90 = find(cumulativeVariance >= 90, 1, 'first');

fprintf('  Components for 90%% variance: %d (from %d features)\n', ...
    numComponentsFor90, numFeatures);

% Use moderate dimensionality for clustering
numComponents = min(20, numComponentsFor90);
reducedFeatures = score(:, 1:numComponents);

fprintf('  Using %d principal components for clustering\n', numComponents);
fprintf('  Variance retained: %.2f%%\n\n', cumulativeVariance(numComponents));

% - Step 4: Determine Optimal Cluster Count -

fprintf('Step 4: Determining optimal number of clusters...\n');

% Test multiple cluster counts
maxClusters = 10;
silhouetteScores = zeros(maxClusters-1, 1);
daviesBouldinScores = zeros(maxClusters-1, 1);

fprintf('  Evaluating cluster counts from 2 to %d...\n', maxClusters);

for k = 2:maxClusters
    % Perform k-means clustering
    [idx, ~] = kmeans(reducedFeatures, k, ...
        'Distance', 'sqeuclidean', ...
        'Replicates', 10, ...
        'MaxIter', 500);
    
    % Calculate silhouette score
    silhouetteVals = silhouette(reducedFeatures, idx);
    silhouetteScores(k-1) = mean(silhouetteVals);
    
    % Calculate Davies-Bouldin index
    daviesBouldinScores(k-1) = evalclusters(reducedFeatures, idx, ...
        'DaviesBouldin').CriterionValues;
end

% Select optimal k (highest silhouette)
[maxSilhouette, optimalKIdx] = max(silhouetteScores);
optimalK = optimalKIdx + 1;

fprintf('\n  Optimal cluster count: %d (silhouette = %.4f)\n\n', ...
    optimalK, maxSilhouette);

% - Step 5: Perform Final Clustering -

fprintf('Step 5: Performing final k-means clustering...\n');

% Cluster with optimal k
rng(42);  % Reproducibility
[clusterIdx, centroids, sumD] = kmeans(reducedFeatures, optimalK, ...
    'Distance', 'sqeuclidean', ...
    'Replicates', 20, ...
    'MaxIter', 1000);

fprintf('  Clustering complete with k = %d\n', optimalK);
fprintf('  Total sum of distances: %.4f\n', sum(sumD));

% Cluster sizes
clusterSizes = histcounts(clusterIdx, 1:optimalK+1);
fprintf('\n  Cluster sizes:\n');
for k = 1:optimalK
    fprintf('    Cluster %d: %d documents\n', k, clusterSizes(k));
end
fprintf('\n');

% - Step 6: Characterise Clusters by Top Terms -

fprintf('Step 6: Characterising clusters by representative terms...\n\n');

clusterTerms = cell(optimalK, 1);

for k = 1:optimalK
    % Documents in this cluster
    clusterDocs = find(clusterIdx == k);
    
    % Aggregate TF-IDF scores
    clusterTFIDF = sum(tfidfFeatures(clusterDocs, :), 1);
    
    % Find top terms
    [sortedScores, sortIdx] = sort(clusterTFIDF, 'descend');
    topTermIdx = sortIdx(1:min(8, length(sortIdx)));
    clusterTerms{k} = bag.Vocabulary(topTermIdx);
    
    fprintf('  Cluster %d representative terms:\n    ', k);
    fprintf('%s\n\n', strjoin(clusterTerms{k}, ', '));
end

% - Step 7: Cluster Quality Evaluation -

fprintf('Step 7: Evaluating cluster quality metrics...\n');

% Silhouette analysis
silhouetteVals = silhouette(reducedFeatures, clusterIdx);
avgSilhouette = mean(silhouetteVals);

fprintf('  Average silhouette coefficient: %.4f\n', avgSilhouette);

% Per-cluster silhouette
fprintf('  Per-cluster silhouette scores:\n');
for k = 1:optimalK
    clusterSilhouette = mean(silhouetteVals(clusterIdx == k));
    fprintf('    Cluster %d: %.4f\n', k, clusterSilhouette);
end

% Davies-Bouldin index
dbEval = evalclusters(reducedFeatures, clusterIdx, 'DaviesBouldin');
fprintf('  Davies-Bouldin index: %.4f (lower is better)\n\n', ...
    dbEval.CriterionValues);

% - Step 8: Cluster-Topic Integration -

fprintf('Step 8: Integrating clustering with topic modelling...\n');

% Fit LDA for comparison
numTopics = optimalK;
ldaModel = fitlda(bag, numTopics, 'Verbose', 0);

% Get document-topic distributions
docTopicDist = transform(ldaModel, bag);

% Compare cluster assignments with dominant topics
[~, dominantTopics] = max(docTopicDist, [], 2);

% Confusion matrix between clusters and topics
confusionMat = zeros(optimalK, numTopics);
for docIdx = 1:numDocs
    confusionMat(clusterIdx(docIdx), dominantTopics(docIdx)) = ...
        confusionMat(clusterIdx(docIdx), dominantTopics(docIdx)) + 1;
end

fprintf('  Cluster-Topic alignment matrix computed\n');
fprintf('  Alignment strength: %.2f%%\n\n', ...
    100 * trace(confusionMat) / numDocs);

% - Step 9: Document Similarity Network -

fprintf('Step 9: Constructing document similarity network...\n');

% Compute cosine similarities
docSimilarities = reducedFeatures * reducedFeatures';
norms = sqrt(sum(reducedFeatures.^2, 2));
docSimilarities = docSimilarities ./ (norms * norms');

% Threshold for network edges
similarityThreshold = 0.4;
adjacencyMatrix = docSimilarities > similarityThreshold;
adjacencyMatrix = adjacencyMatrix - eye(size(adjacencyMatrix));

G = graph(adjacencyMatrix);
fprintf('  Similarity network: %d nodes, %d edges\n', ...
    G.numnodes, G.numedges);
fprintf('  Threshold: %.2f\n\n', similarityThreshold);

% - Step 10: Visualisation -

fprintf('Step 10: Generating document clustering visualisations...\n');

figure('Position', [100, 100, 1800, 1200]);

% Plot 1: Elbow plot (sum of distances)
subplot(3, 4, 1);
sumDistances = zeros(maxClusters-1, 1);
for k = 2:maxClusters
    [~, ~, sumd] = kmeans(reducedFeatures, k, 'Replicates', 5);
    sumDistances(k-1) = sum(sumd);
end
plot(2:maxClusters, sumDistances, 'b-o', 'LineWidth', 2, 'MarkerSize', 8);
xlabel('Number of Clusters (k)');
ylabel('Total Within-Cluster Sum of Squares');
title('Elbow Method for Optimal k');
grid on;

% Plot 2: Silhouette scores
subplot(3, 4, 2);
plot(2:maxClusters, silhouetteScores, 'r-s', 'LineWidth', 2, 'MarkerSize', 8);
hold on;
plot(optimalK, maxSilhouette, 'g*', 'MarkerSize', 15, 'LineWidth', 2);
hold off;
xlabel('Number of Clusters (k)');
ylabel('Average Silhouette Score');
title('Silhouette Analysis');
legend('Silhouette', 'Optimal k', 'Location', 'best');
grid on;

% Plot 3: 2*D cluster visualisation (first 2 PCs)
subplot(3, 4, 3);
gscatter(reducedFeatures(:, 1), reducedFeatures(:, 2), clusterIdx, ...
    [], 'o', 8, 'filled');
hold on;
plot(centroids(:, 1), centroids(:, 2), 'kx', 'MarkerSize', 15, 'LineWidth', 3);
hold off;
xlabel('First Principal Component');
ylabel('Second Principal Component');
title('Document Clusters (PC1 vs PC2)');
legend off;
grid on;

% Plot 4: 3*D cluster visualisation
subplot(3, 4, 4);
if numComponents >= 3
    scatter3(reducedFeatures(:, 1), reducedFeatures(:, 2), ...
        reducedFeatures(:, 3), 80, clusterIdx, 'filled');
    xlabel('PC1');
    ylabel('PC2');
    zlabel('PC3');
    title('3*D Cluster Visualisation');
    grid on;
    view(45, 30);
end

% Plot 5: Cluster size distribution
subplot(3, 4, 5);
bar(1:optimalK, clusterSizes, 'FaceColor', [0.3, 0.7, 0.5]);
xlabel('Cluster Index');
ylabel('Number of Documents');
title('Cluster Size Distribution');
grid on;
set(gca, 'XTick', 1:optimalK);

% Plot 6: Silhouette plot
subplot(3, 4, 6);
silhouette(reducedFeatures, clusterIdx);
title('Silhouette Plot by Cluster');
xlabel('Silhouette Value');
ylabel('Cluster');

% Plot 7: Cluster-Topic confusion matrix
subplot(3, 4, 7);
imagesc(confusionMat);
colorbar;
colormap(gca, hot);
xlabel('LDA Topic');
ylabel('K-means Cluster');
title('Cluster-Topic Alignment');
set(gca, 'XTick', 1:numTopics, 'YTick', 1:optimalK);

% Plot 8: PCA variance explained
subplot(3, 4, 8);
bar(1:min(15, length(explained)), explained(1:min(15, length(explained))), ...
    'FaceColor', [0.6, 0.4, 0.8]);
xlabel('Principal Component');
ylabel('Variance Explained (%)');
title('PCA Variance Contribution');
grid on;

% Plot 9: Document similarity heatmap (subset)
subplot(3, 4, 9);
% Show subset for clarity
subsetSize = min(30, numDocs);
imagesc(docSimilarities(1:subsetSize, 1:subsetSize));
colorbar;
xlabel('Document');
ylabel('Document');
title(sprintf('Document Similarity (first %d)', subsetSize));

% Plot 10: Similarity network graph
subplot(3, 4, 10);
if G.numedges > 0
    plot(G, 'Layout', 'force', 'NodeColor', clusterIdx, ...
        'MarkerSize', 7, 'LineWidth', 1);
    title('Document Similarity Network');
    colormap(gca, lines(optimalK));
    axis off;
end

% Plot 11: Davies-Bouldin index
subplot(3, 4, 11);
plot(2:maxClusters, daviesBouldinScores, 'm-d', 'LineWidth', 2, 'MarkerSize', 8);
xlabel('Number of Clusters (k)');
ylabel('Davies-Bouldin Index');
title('Davies-Bouldin Evaluation (lower is better)');
grid on;

% Plot 12: Inter-cluster distances
subplot(3, 4, 12);
clusterDistances = pdist(centroids, 'euclidean');
squareDistances = squareform(clusterDistances);
imagesc(squareDistances);
colorbar;
xlabel('Cluster');
ylabel('Cluster');
title('Inter-Cluster Distance Matrix');
set(gca, 'XTick', 1:optimalK, 'YTick', 1:optimalK);

sgtitle('Document Clustering Comprehensive Analysis', 'FontSize', 14, ...
    'FontWeight', 'bold');

print('document_clustering_analysis', '-dpng', '-r300');

fprintf('\nDocument clustering complete!\n');
fprintf('Discovered %d clusters with average silhouette %.4f\n', ...
    optimalK, avgSilhouette);
fprintf('Cluster quality indicates well-separated document groups.\n');
