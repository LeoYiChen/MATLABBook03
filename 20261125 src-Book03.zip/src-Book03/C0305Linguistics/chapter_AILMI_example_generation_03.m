%% chapter_AILMI_example_generation_03.m
% Evaluation metrics for generated text quality assessment.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_generation_03
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Text Generation Evaluation Metrics
% Demonstrates perplexity, BLEU, diversity, and quality assessment

fprintf('=== Text Generation Evaluation ===\n\n');

% - Step 1: Prepare Reference and Generated Texts -

fprintf('Step 1: Loading reference and generated text samples...\n');

% Reference texts (human-written gold standard)
referenceTexts = [
    "The quick brown fox jumps over the lazy dog"
    "Machine learning enables computers to learn from data"
    "Natural language processing analyzes human language"
    "Deep neural networks achieve remarkable performance"
    "Artificial intelligence transforms modern technology"
];

% Generated texts from different models/configurations
% Model A: High quality
generatedTextsA = [
    "A swift brown fox leaps over a lazy dog"
    "Machine learning allows computers to learn from information"
    "Natural language processing examines human communication"
    "Deep neural networks attain impressive results"
    "Artificial intelligence revolutionizes current technology"
];

% Model B: Medium quality  
generatedTextsB = [
    "The brown fox jumps lazy dog"
    "Machine learning computers learn data"
    "Language processing human language"
    "Neural networks performance"
    "Intelligence technology"
];

% Model C: Low quality (repetitive, poor grammar)
generatedTextsC = [
    "The the fox fox jumps jumps"
    "Machine machine learning learning data data"
    "Language language processing processing"
    "Network network network network"
    "Technology technology artificial artificial"
];

numSamples = length(referenceTexts);

fprintf('  Reference texts: %d\n', numSamples);
fprintf('  Generated text systems: 3 (A, B, C)\n\n');

% - Step 2: Tokenise All Texts -

fprintf('Step 2: Tokenising texts for evaluation...\n');

% Tokenise references
refTokens = cell(numSamples, 1);
for i = 1:numSamples
    text = lower(referenceTexts{i});
    words = split(text);
    refTokens{i} = words(strlength(words) > 0);
end

% Tokenise generated texts
genTokensA = cell(numSamples, 1);
genTokensB = cell(numSamples, 1);
genTokensC = cell(numSamples, 1);

for i = 1:numSamples
    text = lower(generatedTextsA{i});
    words = split(text);
    genTokensA{i} = words(strlength(words) > 0);
    
    text = lower(generatedTextsB{i});
    words = split(text);
    genTokensB{i} = words(strlength(words) > 0);
    
    text = lower(generatedTextsC{i});
    words = split(text);
    genTokensC{i} = words(strlength(words) > 0);
end

fprintf('  Tokenisation complete\n\n');

% - Step 3: Calculate BLEU Scores -

fprintf('Step 3: Computing BLEU scores...\n');

bleuA = zeros(numSamples, 1);
bleuB = zeros(numSamples, 1);
bleuC = zeros(numSamples, 1);

for i = 1:numSamples
    bleuA(i) = calculateSimpleBLEU(genTokensA{i}, refTokens{i});
    bleuB(i) = calculateSimpleBLEU(genTokensB{i}, refTokens{i});
    bleuC(i) = calculateSimpleBLEU(genTokensC{i}, refTokens{i});
end

avgBleuA = mean(bleuA);
avgBleuB = mean(bleuB);
avgBleuC = mean(bleuC);

fprintf('  Average BLEU scores:\n');
fprintf('    Model A (high quality): %.4f\n', avgBleuA);
fprintf('    Model B (medium quality): %.4f\n', avgBleuB);
fprintf('    Model C (low quality): %.4f\n\n', avgBleuC);

% - Step 4: Calculate Perplexity (Simplified) -

fprintf('Step 4: Estimating perplexity...\n');

% Build simple unigram language model from references
wordCounts = containers.Map('KeyType', 'char', 'ValueType', 'double');
totalWords = 0;

for i = 1:numSamples
    tokens = refTokens{i};
    for j = 1:length(tokens)
        word = char(tokens{j});
        if isKey(wordCounts, word)
            wordCounts(word) = wordCounts(word) + 1;
        else
            wordCounts(word) = 1;
        end
        totalWords = totalWords + 1;
    end
end

% Calculate perplexity on generated texts
perplexityA = calculatePerplexity(genTokensA, wordCounts, totalWords);
perplexityB = calculatePerplexity(genTokensB, wordCounts, totalWords);
perplexityC = calculatePerplexity(genTokensC, wordCounts, totalWords);

fprintf('  Estimated perplexity:\n');
fprintf('    Model A: %.2f\n', perplexityA);
fprintf('    Model B: %.2f\n', perplexityB);
fprintf('    Model C: %.2f\n\n', perplexityC);

% - Step 5: Calculate Diversity Metrics -

fprintf('Step 5: Computing diversity metrics...\n');

% Distinct-1 (unique unigrams / total unigrams)
distinct1A = calculateDistinct1(genTokensA);
distinct1B = calculateDistinct1(genTokensB);
distinct1C = calculateDistinct1(genTokensC);

fprintf('  Distinct-1 (lexical diversity):\n');
fprintf('    Model A: %.4f\n', distinct1A);
fprintf('    Model B: %.4f\n', distinct1B);
fprintf('    Model C: %.4f\n\n', distinct1C);

% Repetition rate
repRateA = calculateRepetitionRate(genTokensA);
repRateB = calculateRepetitionRate(genTokensB);
repRateC = calculateRepetitionRate(genTokensC);

fprintf('  Repetition rate (lower is better):\n');
fprintf('    Model A: %.4f\n', repRateA);
fprintf('    Model B: %.4f\n', repRateB);
fprintf('    Model C: %.4f\n\n', repRateC);

% - Step 6: Length Analysis -

fprintf('Step 6: Analysing generation lengths...\n');

refLengths = cellfun(@length, refTokens);
genLengthsA = cellfun(@length, genTokensA);
genLengthsB = cellfun(@length, genTokensB);
genLengthsC = cellfun(@length, genTokensC);

fprintf('  Average lengths (words):\n');
fprintf('    Reference: %.2f\n', mean(refLengths));
fprintf('    Model A: %.2f\n', mean(genLengthsA));
fprintf('    Model B: %.2f\n', mean(genLengthsB));
fprintf('    Model C: %.2f\n\n', mean(genLengthsC));

% - Step 7: Simulated Human Ratings -

fprintf('Step 7: Simulating human quality ratings...\n');

% Simulate ratings on 1-5 scale (in practice, from human annotators)
rng(42);
humanRatingsA = 4 + 0.5 * randn(numSamples, 1);
humanRatingsA = max(1, min(5, humanRatingsA));

humanRatingsB = 3 + 0.5 * randn(numSamples, 1);
humanRatingsB = max(1, min(5, humanRatingsB));

humanRatingsC = 2 + 0.5 * randn(numSamples, 1);
humanRatingsC = max(1, min(5, humanRatingsC));

fprintf('  Simulated human ratings (1-5 scale):\n');
fprintf('    Model A: %.2f ± %.2f\n', mean(humanRatingsA), std(humanRatingsA));
fprintf('    Model B: %.2f ± %.2f\n', mean(humanRatingsB), std(humanRatingsB));
fprintf('    Model C: %.2f ± %.2f\n\n', mean(humanRatingsC), std(humanRatingsC));

% - Step 8: Metric Correlation with Human Ratings -

fprintf('Step 8: Analysing metric-human correlation...\n');

allBleu = [bleuA; bleuB; bleuC];
allHumanRatings = [humanRatingsA; humanRatingsB; humanRatingsC];

bleuCorr = corr(allBleu, allHumanRatings);

fprintf('  BLEU correlation with human ratings: %.4f\n', bleuCorr);
fprintf('  (Higher correlation indicates better automatic metric)\n\n');

% - Step 9: Comprehensive Evaluation Summary -

fprintf('Step 9: Generation quality summary:\n\n');

fprintf('Model A (High Quality):\n');
fprintf('  BLEU: %.4f | Perplexity: %.2f | Distinct-1: %.4f\n', ...
    avgBleuA, perplexityA, distinct1A);
fprintf('  Human Rating: %.2f/5\n\n', mean(humanRatingsA));

fprintf('Model B (Medium Quality):\n');
fprintf('  BLEU: %.4f | Perplexity: %.2f | Distinct-1: %.4f\n', ...
    avgBleuB, perplexityB, distinct1B);
fprintf('  Human Rating: %.2f/5\n\n', mean(humanRatingsB));

fprintf('Model C (Low Quality):\n');
fprintf('  BLEU: %.4f | Perplexity: %.2f | Distinct-1: %.4f\n', ...
    avgBleuC, perplexityC, distinct1C);
fprintf('  Human Rating: %.2f/5\n\n', mean(humanRatingsC));

% - Step 10: Visualisation -

fprintf('Step 10: Visualising evaluation metrics...\n');

figure('Position', [100, 100, 1400, 900]);

% Plot 1: BLEU score comparison
subplot(2, 3, 1);
modelNames = categorical({'Model A', 'Model B', 'Model C'});
bleuScores = [avgBleuA, avgBleuB, avgBleuC];
bar(modelNames, bleuScores, 'FaceColor', [0.3, 0.6, 0.9]);
ylabel('BLEU Score');
title('BLEU Score Comparison');
ylim([0, 1]);
grid on;

% Plot 2: Perplexity comparison
subplot(2, 3, 2);
perplexities = [perplexityA, perplexityB, perplexityC];
bar(modelNames, perplexities, 'FaceColor', [0.8, 0.4, 0.3]);
ylabel('Perplexity');
title('Perplexity Comparison (Lower is Better)');
grid on;

% Plot 3: Diversity comparison
subplot(2, 3, 3);
distinct1Scores = [distinct1A, distinct1B, distinct1C];
bar(modelNames, distinct1Scores, 'FaceColor', [0.4, 0.7, 0.4]);
ylabel('Distinct-1 Score');
title('Lexical Diversity (Higher is Better)');
ylim([0, 1]);
grid on;

% Plot 4: Human ratings distribution
subplot(2, 3, 4);
hold on;
histogram(humanRatingsA, 'BinEdges', 0.5:0.5:5.5, 'FaceColor', [0.3, 0.8, 0.3], ...
    'FaceAlpha', 0.6, 'DisplayName', 'Model A');
histogram(humanRatingsB, 'BinEdges', 0.5:0.5:5.5, 'FaceColor', [0.8, 0.8, 0.3], ...
    'FaceAlpha', 0.6, 'DisplayName', 'Model B');
histogram(humanRatingsC, 'BinEdges', 0.5:0.5:5.5, 'FaceColor', [0.8, 0.3, 0.3], ...
    'FaceAlpha', 0.6, 'DisplayName', 'Model C');
hold off;
xlabel('Human Rating (1-5)');
ylabel('Frequency');
title('Human Rating Distributions');
legend('Location', 'best');
grid on;

% Plot 5: BLEU vs Human correlation
subplot(2, 3, 5);
scatter(allBleu, allHumanRatings, 80, 'filled');
xlabel('BLEU Score');
ylabel('Human Rating');
title(sprintf('BLEU-Human Correlation (r=%.3f)', bleuCorr));
grid on;

% Add regression line
coeffs = polyfit(allBleu, allHumanRatings, 1);
xFit = linspace(min(allBleu), max(allBleu), 100);
yFit = polyval(coeffs, xFit);
hold on;
plot(xFit, yFit, 'r-', 'LineWidth', 2);
hold off;

% Plot 6: Multi-metric comparison (radar-like)
subplot(2, 3, 6);

% Normalise metrics to 0-1 range
normBleu = bleuScores;
normPerp = 1 ./ (1 + perplexities/10);  % Inverse normalised
normDiv = distinct1Scores;
normHuman = [mean(humanRatingsA), mean(humanRatingsB), mean(humanRatingsC)] / 5;

metrics = [normBleu; normPerp; normDiv; normHuman]';
metricNames = {'BLEU', 'Perplexity^{-1}', 'Diversity', 'Human'};

xPos = 1:4;
hold on;
plot(xPos, metrics(1, :), 'o-', 'LineWidth', 2, 'MarkerSize', 10, ...
    'DisplayName', 'Model A');
plot(xPos, metrics(2, :), 's-', 'LineWidth', 2, 'MarkerSize', 10, ...
    'DisplayName', 'Model B');
plot(xPos, metrics(3, :), '^-', 'LineWidth', 2, 'MarkerSize', 10, ...
    'DisplayName', 'Model C');
hold off;

set(gca, 'XTick', xPos, 'XTickLabel', metricNames);
ylabel('Normalised Score');
title('Multi-Metric Comparison');
legend('Location', 'best');
ylim([0, 1]);
grid on;

sgtitle('Text Generation Evaluation Metrics', 'FontSize', 14, ...
    'FontWeight', 'bold');

print('generation_evaluation_metrics', '-dpng', '-r300');

fprintf('\nText generation evaluation demonstration complete!\n');

% - Helper Functions -

function bleu = calculateSimpleBLEU(candidate, reference)
    % Simplified BLEU-1 (unigram precision with brevity penalty)
    
    if isempty(candidate) || isempty(reference)
        bleu = 0;
        return;
    end
    
    % Count matching unigrams
    matches = 0;
    for i = 1:length(candidate)
        if any(strcmp(candidate{i}, reference))
            matches = matches + 1;
        end
    end
    
    precision = matches / length(candidate);
    
    % Brevity penalty
    if length(candidate) > length(reference)
        bp = 1;
    else
        bp = exp(1 - length(reference)/length(candidate));
    end
    
    bleu = bp * precision;
end

function perplexity = calculatePerplexity(tokenCells, wordCounts, totalWords)
    % Calculate perplexity using unigram language model
    
    logProb = 0;
    numTokens = 0;
    smoothing = 1e-5;
    
    for i = 1:length(tokenCells)
        tokens = tokenCells{i};
        for j = 1:length(tokens)
            word = char(tokens{j});
            if isKey(wordCounts, word)
                prob = (wordCounts(word) + smoothing) / (totalWords + smoothing * 1000);
            else
                prob = smoothing / (totalWords + smoothing * 1000);
            end
            logProb = logProb + log(prob);
            numTokens = numTokens + 1;
        end
    end
    
    perplexity = exp(-logProb / numTokens);
end

function distinct1 = calculateDistinct1(tokenCells)
    % Calculate Distinct-1 (ratio of unique unigrams)
    
    allTokens = [];
    for i = 1:length(tokenCells)
        allTokens = [allTokens; tokenCells{i}];
    end
    
    if isempty(allTokens)
        distinct1 = 0;
        return;
    end
    
    uniqueTokens = unique(allTokens);
    distinct1 = length(uniqueTokens) / length(allTokens);
end

function repRate = calculateRepetitionRate(tokenCells)
    % Calculate word repetition rate
    
    totalWords = 0;
    repeatedWords = 0;
    
    for i = 1:length(tokenCells)
        tokens = tokenCells{i};
        if length(tokens) > 1
            for j = 2:length(tokens)
                if strcmp(tokens{j}, tokens{j-1})
                    repeatedWords = repeatedWords + 1;
                end
                totalWords = totalWords + 1;
            end
        end
    end
    
    if totalWords > 0
        repRate = repeatedWords / totalWords;
    else
        repRate = 0;
    end
end
