%% chapter_AILMI_example_Privacy_01.m
% Text anonymisation system with named entity recognition, pattern-based redaction, and privacy-preserving transformations.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_Privacy_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Text Anonymisation and Privacy Protection System
% Demonstrates techniques for removing personally identifiable information

fprintf('=== Text Anonymisation and Privacy Protection System ===\n\n');

% - Step 1: Define Sample Sensitive Text -

fprintf('Step 1: Loading sample text containing personal information...\n');

sensitiveTexts = [
    "John Smith lives at 123 Oak Street in Manchester and can be " + ...
    "reached at john.smith@email.com or +44 161 555 0123";
    
    "Dr Sarah Johnson treated patient ID 98765 on 15 March 2024 " + ...
    "for diabetes at Royal Hospital";
    
    "The meeting scheduled for 10:00 AM on Monday will include " + ...
    "David Chen from TechCorp and Mary Williams from FinanceGlobal";
    
    "Credit card number 4532-1234-5678-9010 expires 12/25 and " + ...
    "belongs to account holder Robert Brown";
    
    "Email from alice.taylor@company.org states quarterly revenue " + ...
    "reached ?2.5 million with 15% growth"
];

numTexts = length(sensitiveTexts);

fprintf('  Loaded %d text samples containing PII\n', numTexts);
fprintf('  Sample text:\n  "%s"\n\n', sensitiveTexts(1));

% - Step 2: Define Entity Types and Patterns -

fprintf('Step 2: Defining anonymisation rules and patterns...\n');

% Entity types to anonymise
entityTypes = ["PERSON", "EMAIL", "PHONE", "ADDRESS", "DATE", ...
    "CREDIT_CARD", "ORGANISATION", "MONETARY"];

% Define regex patterns for detection
patterns = struct();

% Person names (simplified: Title + FirstName + LastName)
patterns(1).type = "PERSON";
patterns(1).regex = "(Dr|Mr|Mrs|Ms|Professor)\s+[A-Z][a-z]+\s+[A-Z][a-z]+|" + ...
    "[A-Z][a-z]+\s+[A-Z][a-z]+";
patterns(1).replacement = "[PERSON]";

% Email addresses
patterns(2).type = "EMAIL";
patterns(2).regex = "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}";
patterns(2).replacement = "[EMAIL]";

% Phone numbers (UK format)
patterns(3).type = "PHONE";
patterns(3).regex = "\+44\s?\d{3}\s?\d{3}\s?\d{4}|\d{4}\s?\d{6}";
patterns(3).replacement = "[PHONE]";

% Street addresses (simplified)
patterns(4).type = "ADDRESS";
patterns(4).regex = "\d+\s+[A-Z][a-z]+\s+Street";
patterns(4).replacement = "[ADDRESS]";

% Dates
patterns(5).type = "DATE";
patterns(5).regex = "\d{1,2}\s+(January|February|March|April|May|June|July|" + ...
    "August|September|October|November|December)\s+\d{4}|\d{2}/\d{2}/\d{4}";
patterns(5).replacement = "[DATE]";

% Credit card numbers
patterns(6).type = "CREDIT_CARD";
patterns(6).regex = "\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}";
patterns(6).replacement = "[CREDIT_CARD]";

% Organisations (simplified: ends with Corp, Ltd, Hospital, etc.)
patterns(7).type = "ORGANISATION";
patterns(7).regex = "[A-Z][a-zA-Z]+\s?(Corp|Ltd|Hospital|Global|" + ...
    "Corporation|Limited)";
patterns(7).replacement = "[ORGANISATION]";

% Monetary amounts
patterns(8).type = "MONETARY";
patterns(8).regex = "?\d+(\.\d+)?\s?(million|billion|thousand)?";
patterns(8).replacement = "[AMOUNT]";

fprintf('  Defined %d entity type patterns\n', length(patterns));
fprintf('  Entity types: %s\n\n', strjoin(entityTypes, ', '));

% - Step 3: Apply Anonymisation -

fprintf('Step 3: Anonymising text by detecting and redacting entities...\n');

anonymisedTexts = strings(numTexts, 1);
detectionStats = struct();

for entityIdx = 1:length(patterns)
    detectionStats(entityIdx).type = patterns(entityIdx).type;
    detectionStats(entityIdx).count = 0;
end

for textIdx = 1:numTexts
    currentText = sensitiveTexts(textIdx);
    
    % Apply each pattern sequentially
    for patternIdx = 1:length(patterns)
        pattern = patterns(patternIdx).regex;
        replacement = patterns(patternIdx).replacement;
        
        % Find matches
        matches = regexp(currentText, pattern, 'match');
        numMatches = length(matches);
        
        % Replace with anonymisation token
        currentText = regexprep(currentText, pattern, replacement);
        
        % Update statistics
        detectionStats(patternIdx).count = ...
            detectionStats(patternIdx).count + numMatches;
    end
    
    anonymisedTexts(textIdx) = currentText;
end

fprintf('  Anonymisation complete\n');
fprintf('  Detection statistics:\n');
for entityIdx = 1:length(detectionStats)
    fprintf('    %s: %d instances detected and redacted\n', ...
        detectionStats(entityIdx).type, detectionStats(entityIdx).count);
end
fprintf('\n');

% - Step 4: Display Before/After Comparison -

fprintf('Step 4: Comparing original and anonymised texts...\n\n');

for textIdx = 1:min(3, numTexts)
    fprintf('  - Example %d -\n', textIdx);
    fprintf('  Original:\n  "%s"\n\n', sensitiveTexts(textIdx));
    fprintf('  Anonymised:\n  "%s"\n\n', anonymisedTexts(textIdx));
end

% - Step 5: Compute Privacy Metrics -

fprintf('Step 5: Computing privacy preservation metrics...\n');

% Calculate redaction rate (percentage of text replaced)
totalOriginalChars = sum(strlength(sensitiveTexts));
totalAnonymisedChars = sum(strlength(anonymisedTexts));
totalReplacementChars = sum(strlength(anonymisedTexts) .* ...
    contains(anonymisedTexts, "["));

% Count total entities redacted
totalEntitiesRedacted = sum([detectionStats.count]);

% Estimate information loss (simplified: character reduction)
infoLossRate = 1 - (totalAnonymisedChars / totalOriginalChars);

fprintf('  Privacy metrics:\n');
fprintf('    Total entities redacted: %d\n', totalEntitiesRedacted);
fprintf('    Original text length: %d characters\n', totalOriginalChars);
fprintf('    Anonymised text length: %d characters\n', totalAnonymisedChars);
fprintf('    Information reduction: %.1f%%\n', abs(infoLossRate) * 100);
fprintf('\n');

% - Step 6: Linguistic Utility Preservation -

fprintf('Step 6: Assessing linguistic utility preservation...\n');

% Extract linguistic features before and after anonymisation
originalDocs = tokenizedDocument(sensitiveTexts);
anonymisedDocs = tokenizedDocument(anonymisedTexts);

% Remove stopwords and create bag-of-words
originalDocsClean = removeStopWords(erasePunctuation(lower(originalDocs)));
anonymisedDocsClean = removeStopWords(erasePunctuation(lower(anonymisedDocs)));

bagOriginal = bagOfWords(originalDocsClean);
bagAnonymised = bagOfWords(anonymisedDocsClean);

% Compare vocabulary retention
vocabOriginal = bagOriginal.Vocabulary;
vocabAnonymised = bagAnonymised.Vocabulary;

% Vocabulary overlap (excluding anonymisation tokens)
anonymTokens = ["person", "email", "phone", "address", "date", ...
    "credit_card", "organisation", "amount"];
vocabAnonymisedFiltered = setdiff(vocabAnonymised, anonymTokens);

vocabOverlap = intersect(vocabOriginal, vocabAnonymisedFiltered);
vocabRetentionRate = length(vocabOverlap) / length(vocabOriginal);

fprintf('  Linguistic utility metrics:\n');
fprintf('    Original vocabulary size: %d unique words\n', ...
    length(vocabOriginal));
fprintf('    Anonymised vocabulary size: %d unique words\n', ...
    length(vocabAnonymised));
fprintf('    Vocabulary retention rate: %.1f%%\n', vocabRetentionRate * 100);
fprintf('\n');

% - Step 7: Re-identification Risk Assessment -

fprintf('Step 7: Assessing re-identification risk...\n');

% Simulate re-identification attempt by checking for remaining PII patterns
reidentRisk = zeros(numTexts, 1);

for textIdx = 1:numTexts
    text = anonymisedTexts(textIdx);
    
    % Check for potential remaining identifiers
    % (simplified: any capitalised word sequences not in common words)
    capsMatches = regexp(text, '[A-Z][a-z]+', 'match');
    
    % Common words that don't indicate PII
    commonWords = ["The", "A", "An", "In", "On", "At", "For", "To", ...
        "From", "With", "By"];
    
    potentialPII = setdiff(capsMatches, commonWords);
    
    % Risk score based on remaining potential identifiers
    reidentRisk(textIdx) = length(potentialPII) / max(1, length(capsMatches));
end

avgReidentRisk = mean(reidentRisk);

fprintf('  Re-identification risk assessment:\n');
fprintf('    Average re-identification risk: %.2f (0=low, 1=high)\n', ...
    avgReidentRisk);
fprintf('    Maximum risk score: %.2f\n', max(reidentRisk));
fprintf('    Minimum risk score: %.2f\n\n', min(reidentRisk));

% - Step 8: Visualisation -

fprintf('Step 8: Generating privacy analysis visualisations...\n');

figure('Position', [100, 100, 1600, 800]);

% Plot 1: Entity detection statistics
subplot(2, 3, 1);
entityCounts = [detectionStats.count];
bar(entityCounts, 'FaceColor', [0.3, 0.6, 0.9]);
set(gca, 'XTickLabel', {detectionStats.type}, 'XTickLabelRotation', 45);
ylabel('Number of Detections');
title('Detected and Redacted Entity Types');
grid on;

% Plot 2: Text length comparison
subplot(2, 3, 2);
textLengths = [strlength(sensitiveTexts), strlength(anonymisedTexts)];
bar(textLengths);
xlabel('Text Sample Index');
ylabel('Character Count');
title('Text Length: Original vs Anonymised');
legend('Original', 'Anonymised', 'Location', 'best');
grid on;

% Plot 3: Re-identification risk distribution
subplot(2, 3, 3);
histogram(reidentRisk, 10, 'Normalization', 'probability', ...
    'FaceColor', [0.8, 0.3, 0.3]);
xlabel('Re-identification Risk Score');
ylabel('Probability');
title('Re-identification Risk Distribution');
grid on;

% Plot 4: Privacy-utility trade-off
subplot(2, 3, 4);
privacyScore = 1 - avgReidentRisk;
utilityScore = vocabRetentionRate;
scatter(utilityScore, privacyScore, 200, 'filled');
xlabel('Linguistic Utility (Vocabulary Retention)');
ylabel('Privacy Protection (1 - Risk)');
title('Privacy-Utility Trade-off');
xlim([0, 1]);
ylim([0, 1]);
grid on;
hold on;
plot([0, 1], [0, 1], 'r-', 'LineWidth', 1.5);
text(0.5, 0.5, 'Ideal: High Privacy & High Utility', ...
    'HorizontalAlignment', 'center', 'FontSize', 10);
hold off;

% Plot 5: Anonymisation coverage by text
subplot(2, 3, 5);
coverageRates = zeros(numTexts, 1);
for textIdx = 1:numTexts
    redactedChars = sum(regexp(anonymisedTexts(textIdx), '\[.*?\]', 'match'));
    coverageRates(textIdx) = redactedChars / max(1, ...
        strlength(sensitiveTexts(textIdx)));
end
bar(coverageRates * 100, 'FaceColor', [0.6, 0.4, 0.8]);
xlabel('Text Sample Index');
ylabel('Redaction Coverage (%)');
title('Anonymisation Coverage per Text');
grid on;

% Plot 6: Entity type distribution (pie chart)
subplot(2, 3, 6);
nonZeroEntities = entityCounts(entityCounts > 0);
nonZeroTypes = {detectionStats(entityCounts > 0).type};
pie(nonZeroEntities, nonZeroTypes);
title('Distribution of Detected Entity Types');

sgtitle('Text Anonymisation and Privacy Protection Analysis', ...
    'FontSize', 14, 'FontWeight', 'bold');

print('privacy_anonymisation_analysis', '-dpng', '-r300');

fprintf('\nText anonymisation system complete!\n');
fprintf('Successfully redacted %d personal entities across %d texts\n', ...
    totalEntitiesRedacted, numTexts);
fprintf('Achieved %.1f%% vocabulary retention with %.2f re-identification risk.\n', ...
    vocabRetentionRate * 100, avgReidentRisk);
