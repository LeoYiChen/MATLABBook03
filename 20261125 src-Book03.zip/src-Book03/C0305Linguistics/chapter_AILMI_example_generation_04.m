%% chapter_AILMI_example_generation_04.m
% Comparative analysis of modern large language model capabilities and performance characteristics.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_generation_04
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Modern Language Model Comparison and Analysis
% Demonstrates capability profiling across frontier models (2023-2024)

fprintf('=== Modern Language Model Comparison ===\n\n');

% - Step 1: Define Model Specifications -

fprintf('Step 1: Loading modern language model specifications...\n');

% Model names
models = {
    'GPT-4', 'GPT-4 Turbo', 'GPT-4*o', ...
    'Claude 3 Opus', 'Claude 3.5 Sonnet', ...
    'Gemini 1.0 Ultra', 'Gemini 1.5 Pro', ...
    'Llama 3 70*B', 'Llama 3.1 405*B', ...
    'Qwen-2 72*B', 'DeepSeek-V2', 'Mistral Large'
};

numModels = length(models);

% Context window sizes (in thousands of tokens)
contextSizes = [8, 128, 128, 200, 200, 32, 1000, 8, 128, 128, 128, 32];

% Multimodal capabilities (1 = yes, 0 = no)
multimodal = [1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0];

% Benchmark scores (MMLU, HumanEval, GSM8K)
mmluScores = [86.4, 86.4, 87.2, 86.8, 88.7, 90.0, 85.9, 82.0, 87.3, 84.2, 78.5, 81.2];
humanEvalScores = [67.0, 69.0, 90.2, 84.9, 92.0, 74.4, 71.9, 81.7, 89.0, 64.6, 81.1, 83.6];
gsm8kScores = [92.0, 92.0, 94.8, 95.0, 96.4, 94.4, 91.7, 93.0, 96.8, 91.1, 85.0, 91.2];

% Model categories
categories = {
    'Proprietary', 'Proprietary', 'Proprietary', ...
    'Proprietary', 'Proprietary', ...
    'Proprietary', 'Proprietary', ...
    'Open-Source', 'Open-Source', ...
    'Open-Source', 'Open-Source', 'Proprietary'
};

fprintf('  Models loaded: %d\n', numModels);
fprintf('  Benchmark metrics: MMLU, HumanEval, GSM8K\n\n');

% - Step 2: Context Window Analysis -

fprintf('Step 2: Analysing context window capabilities...\n');

% Find models with largest contexts
[sortedContext, sortIdx] = sort(contextSizes, 'descend');
fprintf('  Largest context windows:\n');
for i = 1:min(5, numModels)
    idx = sortIdx(i);
    fprintf('    %s: %d K tokens\n', models{idx}, contextSizes(idx));
end

avgContext = mean(contextSizes);
fprintf('  Average context size: %.1f K tokens\n\n', avgContext);

% - Step 3: Benchmark Performance Analysis -

fprintf('Step 3: Computing benchmark performance statistics...\n');

% Best performers on each benchmark
[~, bestMMLU] = max(mmluScores);
[~, bestHumanEval] = max(humanEvalScores);
[~, bestGSM8K] = max(gsm8kScores);

fprintf('  Best MMLU performance: %s (%.1f%%)\n', models{bestMMLU}, mmluScores(bestMMLU));
fprintf('  Best HumanEval performance: %s (%.1f%%)\n', models{bestHumanEval}, humanEvalScores(bestHumanEval));
fprintf('  Best GSM8K performance: %s (%.1f%%)\n', models{bestGSM8K}, gsm8kScores(bestGSM8K));

% Average scores by category
openSourceIdx = strcmp(categories, 'Open-Source');
proprietaryIdx = strcmp(categories, 'Proprietary');

avgMMLU_open = mean(mmluScores(openSourceIdx));
avgMMLU_prop = mean(mmluScores(proprietaryIdx));

fprintf('\n  Average MMLU scores:\n');
fprintf('    Open-Source: %.2f%%\n', avgMMLU_open);
fprintf('    Proprietary: %.2f%%\n\n', avgMMLU_prop);

% - Step 4: Capability Profiling -

fprintf('Step 4: Creating capability profiles...\n');

% Normalise metrics to 0-1 scale for comparison
normMMLU = mmluScores / 100;
normHumanEval = humanEvalScores / 100;
normGSM8K = gsm8kScores / 100;
normContext = contextSizes / max(contextSizes);

% Composite capability score
capabilityScores = 0.4 * normMMLU + 0.3 * normHumanEval + ...
                   0.2 * normGSM8K + 0.1 * normContext;

[sortedCapability, capIdx] = sort(capabilityScores, 'descend');

fprintf('  Top 5 models by composite capability:\n');
for i = 1:min(5, numModels)
    idx = capIdx(i);
    fprintf('    %d. %s (score: %.3f)\n', i, models{idx}, capabilityScores(idx));
end
fprintf('\n');

% - Step 5: Multimodal Analysis -

fprintf('Step 5: Analysing multimodal capabilities...\n');

multimodalCount = sum(multimodal);
textOnlyCount = numModels - multimodalCount;

fprintf('  Multimodal models: %d (%.1f%%)\n', multimodalCount, ...
    100 * multimodalCount / numModels);
fprintf('  Text-only models: %d (%.1f%%)\n', textOnlyCount, ...
    100 * textOnlyCount / numModels);

% Performance comparison: multimodal vs text-only
mmluMultimodal = mean(mmluScores(multimodal == 1));
mmluTextOnly = mean(mmluScores(multimodal == 0));

fprintf('  Average MMLU (Multimodal): %.2f%%\n', mmluMultimodal);
fprintf('  Average MMLU (Text-only): %.2f%%\n\n', mmluTextOnly);

% - Step 6: Trend Analysis -

fprintf('Step 6: Computing performance trends...\n');

% Simulate temporal progression (simplified - actual dates vary)
% Assign approximate release order
releaseOrder = [1, 4, 6, 2, 5, 3, 7, 8, 9, 10, 11, 12];

% Track MMLU improvement over releases
fprintf('  MMLU score progression:\n');
fprintf('    Early models (avg): %.2f%%\n', mean(mmluScores(releaseOrder(1:4))));
fprintf('    Mid-period (avg): %.2f%%\n', mean(mmluScores(releaseOrder(5:8))));
fprintf('    Latest models (avg): %.2f%%\n\n', mean(mmluScores(releaseOrder(9:12))));

% - Step 7: Efficiency Metrics -

fprintf('Step 7: Estimating efficiency characteristics...\n');

% Efficiency approximation: performance per context size
% (higher is better - more capability for less context cost)
efficiencyMetric = capabilityScores ./ (log10(contextSizes + 1));

[sortedEfficiency, effIdx] = sort(efficiencyMetric, 'descend');

fprintf('  Most efficient models (capability per context):\n');
for i = 1:min(5, numModels)
    idx = effIdx(i);
    fprintf('    %d. %s (efficiency: %.3f)\n', i, models{idx}, efficiencyMetric(idx));
end
fprintf('\n');

% - Step 8: Capability Clustering -

fprintf('Step 8: Performing capability clustering...\n');

% Feature matrix: [MMLU, HumanEval, GSM8K, Context, Multimodal]
features = [normMMLU', normHumanEval', normGSM8K', normContext', multimodal'];

% Simple k-means clustering (k=3: tier-1, tier-2, tier-3)
rng(42);  % Reproducibility
k = 3;
[clusterIdx, clusterCenters] = kmeans(features, k, 'Replicates', 10);

fprintf('  Models clustered into %d capability tiers:\n', k);
for tier = 1:k
    tierModels = find(clusterIdx == tier);
    fprintf('    Tier %d: %s\n', tier, strjoin(models(tierModels), ', '));
end
fprintf('\n');

% - Step 9: Benchmark Correlation Analysis -

fprintf('Step 9: Analysing benchmark correlations...\n');

% Correlation between benchmarks
corrMMLU_HumanEval = corr(mmluScores', humanEvalScores');
corrMMLU_GSM8K = corr(mmluScores', gsm8kScores');
corrHumanEval_GSM8K = corr(humanEvalScores', gsm8kScores');

fprintf('  Benchmark correlations:\n');
fprintf('    MMLU <-> HumanEval: %.3f\n', corrMMLU_HumanEval);
fprintf('    MMLU <-> GSM8K: %.3f\n', corrMMLU_GSM8K);
fprintf('    HumanEval <-> GSM8K: %.3f\n', corrHumanEval_GSM8K);
fprintf('  (Higher correlation suggests benchmarks measure similar capabilities)\n\n');

% - Step 10: Visualisation -

fprintf('Step 10: Generating comparative visualisations...\n');

figure('Position', [100, 100, 1600, 1000]);

% Plot 1: MMLU Performance Comparison
subplot(3, 3, 1);
bar(mmluScores, 'FaceColor', [0.3, 0.6, 0.9]);
set(gca, 'XTick', 1:numModels, 'XTickLabel', models, 'XTickLabelRotation', 45);
ylabel('MMLU Score (%)');
title('MMLU Performance');
grid on;
ylim([70, 95]);

% Plot 2: HumanEval Performance
subplot(3, 3, 2);
bar(humanEvalScores, 'FaceColor', [0.9, 0.5, 0.3]);
set(gca, 'XTick', 1:numModels, 'XTickLabel', models, 'XTickLabelRotation', 45);
ylabel('HumanEval Score (%)');
title('Coding Performance (HumanEval)');
grid on;
ylim([60, 95]);

% Plot 3: GSM8K Performance
subplot(3, 3, 3);
bar(gsm8kScores, 'FaceColor', [0.4, 0.8, 0.4]);
set(gca, 'XTick', 1:numModels, 'XTickLabel', models, 'XTickLabelRotation', 45);
ylabel('GSM8K Score (%)');
title('Mathematical Reasoning (GSM8K)');
grid on;
ylim([80, 100]);

% Plot 4: Context Window Comparison
subplot(3, 3, 4);
bar(log10(contextSizes), 'FaceColor', [0.7, 0.4, 0.7]);
set(gca, 'XTick', 1:numModels, 'XTickLabel', models, 'XTickLabelRotation', 45);
ylabel('log_{10}(Context Size)');
title('Context Window Capacity');
grid on;

% Plot 5: Multimodal vs Text-only
subplot(3, 3, 5);
categories_plot = categorical({'Multimodal', 'Text-only'});
counts = [multimodalCount, textOnlyCount];
bar(categories_plot, counts, 'FaceColor', [0.5, 0.7, 0.8]);
ylabel('Count');
title('Multimodal Capabilities');
grid on;

% Plot 6: Capability Scatter (MMLU vs HumanEval)
subplot(3, 3, 6);
scatter(mmluScores, humanEvalScores, 100, capabilityScores, 'filled');
xlabel('MMLU Score (%)');
ylabel('HumanEval Score (%)');
title('MMLU vs HumanEval Performance');
colorbar;
colormap(jet);
grid on;

% Plot 7: Radar Chart for Top Models
subplot(3, 3, 7);
topModelsIdx = capIdx(1:5);
theta = linspace(0, 2*pi, 4);
theta = [theta, theta(1)];  % Close the circle

hold on;
for i = 1:5
    idx = topModelsIdx(i);
    values = [normMMLU(idx), normHumanEval(idx), normGSM8K(idx), normContext(idx), normMMLU(idx)];
    polarplot(theta, values, 'LineWidth', 2, 'DisplayName', models{idx});
end
hold off;
title('Top 5 Models - Capability Profile');
legend('Location', 'best', 'FontSize', 7);
theta*ticks([0, 90, 180, 270]);
theta*ticklabels({'MMLU', 'HumanEval', 'GSM8K', 'Context'});

% Plot 8: Composite Capability Scores
subplot(3, 3, 8);
[sortedCap, sortCapIdx] = sort(capabilityScores, 'descend');
bar(sortedCap, 'FaceColor', [0.8, 0.6, 0.3]);
set(gca, 'XTick', 1:numModels, 'XTickLabel', models(sortCapIdx), 'XTickLabelRotation', 45);
ylabel('Composite Score');
title('Overall Capability Ranking');
grid on;

% Plot 9: Efficiency Analysis
subplot(3, 3, 9);
scatter(contextSizes, capabilityScores, 100, multimodal*50 + 50, 'filled');
xlabel('Context Size (K tokens)');
ylabel('Capability Score');
title('Efficiency: Capability vs Context Size');
set(gca, 'XScale', 'log');
grid on;
colorbar('Ticks', [50, 100], 'TickLabels', {'Text-only', 'Multimodal'});

sgtitle('Modern Language Model Comparative Analysis (2023-2024)', ...
    'FontSize', 14, 'FontWeight', 'bold');

print('modern_llm_comparison', '-dpng', '-r300');

fprintf('\nModern language model analysis complete!\n');
fprintf('Frontier models demonstrate remarkable capabilities across\n');
fprintf('reasoning, coding, mathematics, and multimodal understanding.\n');
