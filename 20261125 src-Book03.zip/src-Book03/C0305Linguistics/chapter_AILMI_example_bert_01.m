%% chapter_AILMI_example_bert_01.m
% Leveraging pre-trained BERT for contextual embeddings and transfer learning in text classification tasks.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_bert_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% BERT-based contextual embedding extraction and fine-tuning

fprintf('=== BERT Contextual Embedding Extraction ===\n\n');

% Sample documents for embedding generation
sampleTexts = [
    "Natural language processing transforms unstructured text.";
    "Deep learning enables sophisticated semantic understanding.";
    "Contextual embeddings capture nuanced linguistic meaning.";
    "Transfer learning accelerates model development significantly."
];

try
    % Load pre-trained BERT model (requires one-time download)
    % Default model: 'bert-base-uncased' (110*M parameters)
    mdl = bert;
    fprintf('BERT model loaded successfully.\n');
    fprintf('Model configuration:\n');
    fprintf('  Architecture: %s\n', 'BERT-base-uncased');
    fprintf('  Parameters: ~110 million\n');
    fprintf('  Embedding dimension: 768\n');
    fprintf('  Maximum sequence length: 512 tokens\n\n');
    
    % Generate contextual embeddings
    % BERT produces both token-level and document-level representations
    encodedData = encode(mdl, sampleTexts);
    
    fprintf('- Embedding Structure -\n');
    fprintf('Document embeddings: [%d samples × %d dimensions]\n', ...
            size(encodedData.Document, 1), size(encodedData.Document, 2));
    fprintf('Token embeddings: Cell array with %d documents\n', ...
            numel(encodedData.Tokens));
    
    % Examine first document's embeddings
    fprintf('\n- Sample Document Analysis -\n');
    fprintf('Text: "%s"\n', sampleTexts(1));
    fprintf('Document embedding (first 8 dimensions):\n');
    fprintf('  [%.4f, %.4f, %.4f, %.4f, %.4f, %.4f, %.4f, %.4f, ...]\n', ...
            encodedData.Document(1, 1:8));
    
    if ~isempty(encodedData.Tokens{1})
        numTokens = size(encodedData.Tokens{1}, 1);
        fprintf('\nToken-level embeddings:\n');
        fprintf('  Number of tokens: %d\n', numTokens);
        fprintf('  First token embedding (first 5 dims): [%.4f, %.4f, %.4f, %.4f, %.4f, ...]\n', ...
                encodedData.Tokens{1}(1, 1:5));
    end
    
    % Compute document similarity using BERT embeddings
    % Cosine similarity in contextual embedding space
    documentVectors = encodedData.Document;
    similarityMatrix = documentVectors * documentVectors';
    norms = sqrt(diag(similarityMatrix));
    similarityMatrix = similarityMatrix ./ (norms * norms');
    
    fprintf('\n- Document Similarity Matrix (BERT embeddings) -\n');
    fprintf('(Values range 0-1: higher indicates greater semantic similarity)\n');
    disp(array2table(similarityMatrix, ...
         'VariableNames', compose('Doc%d', 1:numel(sampleTexts)), ...
         'RowNames', compose('Doc%d', 1:numel(sampleTexts))));
    
    % Conceptual fine-tuning workflow
    % BERT embeddings serve as features for task-specific classification
    fprintf('\n- Transfer Learning Workflow -\n');
    fprintf('1. Extract BERT embeddings: X_features = encodedData.Document\n');
    fprintf('2. Prepare task labels: Y_labels = categorical(taskLabels)\n');
    fprintf('3. Define classification head:\n');
    fprintf('   layers = [featureInputLayer(768);\n');
    fprintf('             fullyConnectedLayer(numClasses);\n');
    fprintf('             softmaxLayer; classificationLayer];\n');
    fprintf('4. Train: net = trainNetwork(X_features, Y_labels, layers, options)\n');
    fprintf('5. Deploy: predictions = classify(net, newBERTfeatures)\n');
    
catch ME
    fprintf('Warning: BERT model unavailable.\n');
    fprintf('Error: %s\n', ME.message);
    fprintf('\nInstallation instructions:\n');
    fprintf('1. Open Add-On Explorer (Home tab > Add-Ons > Get Add-Ons)\n');
    fprintf('2. Search for "Text Analytics Toolbox Model for BERT"\n');
    fprintf('3. Install the support package (one-time download ~400*MB)\n');
end

fprintf('\n=== BERT Integration Complete ===\n');
