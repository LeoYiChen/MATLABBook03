%% chapter_AILMI_example_multimodal_03.m
% Cross-modal attention mechanism for multimodal fusion.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_multimodal_03
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Cross-Modal Attention Mechanism
% Demonstrates attention between visual and textual modalities

fprintf('=== Cross-Modal Attention Mechanism ===\n\n');

% Parameters
numVisualRegions = 49;      % e.g., 7*x7 spatial grid from CNN
numTextTokens = 12;         % Number of words/tokens in text
featureDimension = 256;     % Embedding dimension
numHeads = 4;               % Multi-head attention
headDimension = featureDimension / numHeads;

fprintf('Attention configuration:\n');
fprintf('  Visual regions: %d\n', numVisualRegions);
fprintf('  Text tokens: %d\n', numTextTokens);
fprintf('  Feature dimension: %d\n', featureDimension);
fprintf('  Number of attention heads: %d\n', numHeads);
fprintf('  Dimension per head: %d\n\n', headDimension);

% - Step 1: Generate Sample Representations -

fprintf('Step 1: Generating sample visual and text representations...\n');

% Visual features: simulating CNN output for image regions
visualFeatures = randn(numVisualRegions, featureDimension);

% Text features: simulating word embeddings
textFeatures = randn(numTextTokens, featureDimension);

fprintf('  Visual features: %d x %d\n', size(visualFeatures));
fprintf('  Text features: %d x %d\n\n', size(textFeatures));

% - Step 2: Single-Head Attention (Text attending to Vision) -

fprintf('Step 2: Computing single-head cross-modal attention...\n');
fprintf('  Query: Text features\n');
fprintf('  Key/Value: Visual features\n\n');

% Text features serve as queries, visual features as keys and values
Q_text = textFeatures;                    % Queries from text
K_visual = visualFeatures;                % Keys from vision
V_visual = visualFeatures;                % Values from vision

% Compute attention scores (text queries × visual keys)
attentionScoresRaw = Q_text * K_visual';  % [numTextTokens x numVisualRegions]

% Scale by square root of dimension
scalingFactor = sqrt(featureDimension);
attentionScoresScaled = attentionScoresRaw / scalingFactor;

% Apply softmax to get attention weights
attentionWeights = softmax(attentionScoresScaled, 2);  % Softmax along regions dimension

fprintf('  Attention score matrix: %d x %d\n', size(attentionScoresRaw));
fprintf('  Scaling factor: %.2f\n', scalingFactor);
fprintf('  Attention weights sum per query: %.4f (should be 1.0)\n', ...
    sum(attentionWeights(1, :)));

% Compute attended visual features
attendedVisual = attentionWeights * V_visual;  % [numTextTokens x featureDimension]

fprintf('  Attended visual features: %d x %d\n\n', size(attendedVisual));

% - Step 3: Visualise Attention Patterns -

fprintf('Step 3: Visualising attention patterns...\n');

figure('Position', [100, 100, 1400, 900]);

% Plot 1: Attention weight heatmap
subplot(2, 3, 1);
imagesc(attentionWeights);
colormap('hot');
colorbar;
xlabel('Visual Regions');
ylabel('Text Tokens');
title('Cross-Modal Attention Weights');
set(gca, 'YDir', 'normal');

% Plot 2: Reshape to spatial grid for visualisation
spatialGridSize = sqrt(numVisualRegions);
subplot(2, 3, 2);
attentionSpatial = reshape(attentionWeights(5, :), ...
    [spatialGridSize, spatialGridSize]);
imagesc(attentionSpatial);
colormap('hot');
colorbar;
axis square;
title('Spatial Attention for Token 5');
xlabel('Spatial X');
ylabel('Spatial Y');

% Plot 3: Average attention across tokens
subplot(2, 3, 3);
avgAttention = mean(attentionWeights, 1);
avgAttentionSpatial = reshape(avgAttention, ...
    [spatialGridSize, spatialGridSize]);
imagesc(avgAttentionSpatial);
colormap('hot');
colorbar;
axis square;
title('Average Attention Across Tokens');
xlabel('Spatial X');
ylabel('Spatial Y');

% Plot 4: Attention distribution for multiple tokens
subplot(2, 3, 4);
hold on;
for tokenIdx = [1, 4, 8, 12]
    plot(attentionWeights(tokenIdx, :), 'LineWidth', 1.5, ...
        'DisplayName', sprintf('Token %d', tokenIdx));
end
hold off;
xlabel('Visual Region Index');
ylabel('Attention Weight');
title('Attention Distributions for Selected Tokens');
legend('Location', 'best');
grid on;

% Plot 5: Feature similarity before and after attention
subplot(2, 3, 5);
% Compute cosine similarity between text and visual features
textNorm = sqrt(sum(textFeatures.^2, 2));
visualNorm = sqrt(sum(visualFeatures.^2, 2));
cosineSim = (textFeatures * visualFeatures') ./ (textNorm * visualNorm');

imagesc(cosineSim);
colormap('jet');
colorbar;
xlabel('Visual Regions');
ylabel('Text Tokens');
title('Feature Similarity (Before Attention)');

% Plot 6: Attended feature norms
subplot(2, 3, 6);
originalNorms = sqrt(sum(textFeatures.^2, 2));
attendedNorms = sqrt(sum(attendedVisual.^2, 2));
plot(1:numTextTokens, originalNorms, 'b-o', 'LineWidth', 1.5, ...
    'DisplayName', 'Original Text Features');
hold on;
plot(1:numTextTokens, attendedNorms, 'r-s', 'LineWidth', 1.5, ...
    'DisplayName', 'Attended Visual Features');
hold off;
xlabel('Token Index');
ylabel('L2 Norm');
title('Feature Magnitude Comparison');
legend('Location', 'best');
grid on;

sgtitle('Cross-Modal Attention: Text Attending to Vision', ...
    'FontSize', 14, 'FontWeight', 'bold');

print('cross_modal_attention_patterns', '-dpng', '-r300');

% - Step 4: Multi-Head Attention -

fprintf('\nStep 4: Implementing multi-head attention...\n');

% Initialize projection matrices for multi-head attention
% In practice, these would be learned parameters
W_Q = cell(numHeads, 1);
W_K = cell(numHeads, 1);
W_V = cell(numHeads, 1);

for h = 1:numHeads
    W_Q{h} = randn(featureDimension, headDimension) * 0.1;
    W_K{h} = randn(featureDimension, headDimension) * 0.1;
    W_V{h} = randn(featureDimension, headDimension) * 0.1;
end

% Output projection
W_O = randn(featureDimension, featureDimension) * 0.1;

% Compute multi-head attention
headOutputs = cell(numHeads, 1);

for h = 1:numHeads
    % Project to head-specific subspace
    Q_h = textFeatures * W_Q{h};        % [numTextTokens x headDimension]
    K_h = visualFeatures * W_K{h};      % [numVisualRegions x headDimension]
    V_h = visualFeatures * W_V{h};      % [numVisualRegions x headDimension]
    
    % Compute attention
    scores_h = Q_h * K_h';              % [numTextTokens x numVisualRegions]
    scores_h = scores_h / sqrt(headDimension);
    weights_h = softmax(scores_h, 2);
    
    % Attended output for this head
    headOutputs{h} = weights_h * V_h;   % [numTextTokens x headDimension]
end

% Concatenate head outputs
multiHeadOutput = cat(2, headOutputs{:});  % [numTextTokens x featureDimension]

% Final projection
finalOutput = multiHeadOutput * W_O;

fprintf('  Multi-head attention computed:\n');
fprintf('    Number of heads: %d\n', numHeads);
fprintf('    Concatenated output: %d x %d\n', size(multiHeadOutput));
fprintf('    Final output: %d x %d\n\n', size(finalOutput));

% - Step 5: Bidirectional Cross-Modal Attention -

fprintf('Step 5: Computing bidirectional attention...\n');

% Vision attending to text
Q_visual = visualFeatures;
K_text = textFeatures;
V_text = textFeatures;

visualToTextScores = (Q_visual * K_text') / sqrt(featureDimension);
visualToTextWeights = softmax(visualToTextScores, 2);
attendedText = visualToTextWeights * V_text;

fprintf('  Text-to-Vision attention: %d x %d\n', size(attendedVisual));
fprintf('  Vision-to-Text attention: %d x %d\n', size(attendedText));

% Visualise bidirectional attention
figure('Position', [100, 100, 1400, 500]);

subplot(1, 2, 1);
imagesc(attentionWeights);
colormap('hot');
colorbar;
xlabel('Visual Regions');
ylabel('Text Tokens');
title('Text → Vision Attention');
set(gca, 'YDir', 'normal');

subplot(1, 2, 2);
imagesc(visualToTextWeights);
colormap('hot');
colorbar;
xlabel('Text Tokens');
ylabel('Visual Regions');
title('Vision → Text Attention');
set(gca, 'YDir', 'normal');

sgtitle('Bidirectional Cross-Modal Attention', ...
    'FontSize', 14, 'FontWeight', 'bold');

print('bidirectional_attention', '-dpng', '-r300');

% - Step 6: Attention Statistics and Analysis -

fprintf('\nStep 6: Analysing attention characteristics...\n');

% Compute attention entropy (measure of focus)
attentionEntropy = zeros(numTextTokens, 1);
for i = 1:numTextTokens
    weights = attentionWeights(i, :);
    % Avoid log(0) by adding small epsilon
    entropy = -sum(weights .* log(weights + 1e-10));
    attentionEntropy(i) = entropy;
end

fprintf('  Attention entropy statistics:\n');
fprintf('    Mean: %.4f\n', mean(attentionEntropy));
fprintf('    Std: %.4f\n', std(attentionEntropy));
fprintf('    Min: %.4f (most focused)\n', min(attentionEntropy));
fprintf('    Max: %.4f (least focused)\n', max(attentionEntropy));

% Maximum attention score per token
[maxAttention, maxRegion] = max(attentionWeights, [], 2);

fprintf('\n  Peak attention statistics:\n');
fprintf('    Mean max weight: %.4f\n', mean(maxAttention));
fprintf('    Std: %.4f\n', std(maxAttention));

fprintf('\nCross-modal attention demonstration complete!\n');
