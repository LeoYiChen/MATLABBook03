%% chapter_AILMI_example_features_01.m
% Feature extraction methods in MATLAB: Bag-of-Words, TF-IDF, and word embeddings demonstrated with comparative analysis.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_features_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Preprocessed documents from previous example
% For demonstration, recreate small corpus
rawText = ["Machine learning transforms data analysis fundamentally.";
           "Deep learning revolutionises pattern recognition capabilities.";
           "Statistical methods remain essential for robust inference.";
           "Computational linguistics bridges theoretical and applied research."];

% Preprocess text
documents = removeStopWords(erasePunctuation(lower(...
            tokenizedDocument(rawText))));

fprintf('=== Feature Extraction Methods Comparison ===\n\n');

% Method 1: Bag-of-Words Model
% Creates sparse matrix where columns represent unique vocabulary terms
% and values represent term frequencies within documents
bag = bagOfWords(documents);
fprintf('- Bag-of-Words Model -\n');
fprintf('Vocabulary size: %d unique terms\n', bag.NumWords);
fprintf('Number of documents: %d\n', bag.NumDocuments);
fprintf('Sparsity: %.2f%% (proportion of zero entries)\n', ...
        100 * (1 - nnz(bag.Counts) / numel(bag.Counts)));

% Display top terms by frequency
topTerms = topkwords(bag, 10);
fprintf('\nTop 10 most frequent terms:\n');
disp(topTerms);

% Method 2: TF-IDF Weighting
% Applies term frequency-inverse document frequency transformation
% to emphasise distinctive terms whilst suppressing common vocabulary
tfidfMatrix = tfidf(bag);
fprintf('\n- TF-IDF Weighted Features -\n');
fprintf('Feature matrix dimensions: %d documents × %d terms\n', ...
        size(tfidfMatrix, 1), size(tfidfMatrix, 2));
fprintf('Average non-zero TF-IDF weight: %.4f\n', ...
        mean(nonzeros(tfidfMatrix)));

% Compute document similarity using cosine distance
% Cosine similarity measures angular separation in feature space,
% ranging from 0 (orthogonal, completely dissimilar) to 1 (identical)
documentSimilarity = 1 - pdist(tfidfMatrix, 'cosine');
documentSimilarity = squareform(documentSimilarity);
fprintf('\nDocument similarity matrix (cosine similarity):\n');
disp(array2table(documentSimilarity, ...
     'VariableNames', compose('Doc%d', 1:numel(documents)), ...
     'RowNames', compose('Doc%d', 1:numel(documents))));

% Method 3: Word Embeddings (FastText)
% Load pre-trained embedding model capturing semantic relationships
try
    embeddingModel = fastTextWordEmbedding;
    fprintf('\n- Word Embeddings (FastText) -\n');
    fprintf('Embedding dimensionality: %d\n', embeddingModel.Dimension(2));
    fprintf('Vocabulary size: %d\n', embeddingModel.Dimension(1));
    
    % Demonstrate semantic similarity using embeddings
    % Words with similar meanings occupy proximate vector space regions
    queryWord = "learning";
    queryVector = word2vec(embeddingModel, queryWord);
    similarWords = vec2word(embeddingModel, queryVector, 8);
    
    fprintf('\nWords semantically similar to "%s":\n', queryWord);
    for idx = 1:numel(similarWords)
        wordVec = word2vec(embeddingModel, similarWords(idx));
        cosineSim = dot(queryVector, wordVec) / ...
                    (norm(queryVector) * norm(wordVec));
        fprintf('  %d. %s (similarity: %.4f)\n', idx, ...
                similarWords(idx), cosineSim);
    end
    
    % Encode documents using mean word embedding
    % Each document represented as average of constituent word vectors
    documentEmbeddings = zeros(numel(documents), ...
                               embeddingModel.Dimension(2));
    for docIdx = 1:numel(documents)
        wordVectors = word2vec(embeddingModel, documents(docIdx));
        if ~isempty(wordVectors)
            documentEmbeddings(docIdx, :) = mean(wordVectors, 1);
        end
    end
    
    fprintf('\nDocument embedding matrix dimensions: %d × %d\n', ...
            size(documentEmbeddings, 1), size(documentEmbeddings, 2));
    
catch ME
    fprintf('\n- Word Embeddings -\n');
    fprintf('Warning: FastText model unavailable. %s\n', ME.message);
    fprintf('Install via Add-On Explorer: Text Analytics Toolbox Model for FastText\n');
end

% Visualise TF-IDF feature importance for first document
figure('Position', [100, 100, 900, 500]);
[topWeights, topIndices] = maxk(full(tfidfMatrix(1, :)), 10);
topWords = bag.Vocabulary(topIndices);

barh(topWeights, 'FaceColor', [0.3 0.6 0.8]);
set(gca, 'YTick', 1:numel(topWords), 'YTickLabel', topWords, ...
         'FontSize', 11);
xlabel('TF-IDF Weight', 'FontSize', 12, 'FontWeight', 'bold');
title('Top 10 TF-IDF Weighted Terms (Document 1)', ...
      'FontSize', 14, 'FontWeight', 'bold');
grid on;
