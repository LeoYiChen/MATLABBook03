%% chapter_AILMI_example_hist_03.m
% Exploring word embeddings and semantic relationships.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_hist_03
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Load pre-trained word embedding model
emb = fastTextWordEmbedding;

% Example words to analyse
word1 = "king";
word2 = "queen";
word3 = "man";
word4 = "woman";

% Get word vectors
vec1 = word2vec(emb, word1);
vec2 = word2vec(emb, word2);
vec3 = word2vec(emb, word3);
vec4 = word2vec(emb, word4);

% Calculate cosine similarities

% Explore semantic relationships
sim_king_queen = cosineSim(vec1, vec2);
sim_man_woman = cosineSim(vec3, vec4);

fprintf('Similarity between "%s" and "%s": %.4f\n', ...
        word1, word2, sim_king_queen);
fprintf('Similarity between "%s" and "%s": %.4f\n', ...
        word3, word4, sim_man_woman);

% Vector arithmetic: king - man + woman ≈ queen
result_vec = vec1 - vec3 + vec4;

% Find nearest words to result vector
nearestWords = vec2word(emb, result_vec, 5);
fprintf('\nNearest words to "king - man + woman":\n');
disp(nearestWords);

% Visualise word relationships in 2*D using t-SNE
words = ["king", "queen", "man", "woman", "prince", ...
         "princess", "boy", "girl", "father", "mother"];
wordVectors = word2vec(emb, words);

% Apply t-SNE for dimensionality reduction
rng(1);  % For reproducibility
Y = tsne(wordVectors, 'NumDimensions', 2);

% Plot results
figure;
scatter(Y(:,1), Y(:,2), 100, 'filled');
text(Y(:,1)+0.02, Y(:,2), words, 'FontSize', 12);
title('Word Embedding Visualisation (t-SNE)');
xlabel('Dimension 1');
ylabel('Dimension 2');
grid on;

% Local functions (moved to end so this listing is a valid MATLAB script)
function similarity = cosineSim(vec1, vec2)
    similarity = dot(vec1, vec2) / (norm(vec1) * norm(vec2));
end
