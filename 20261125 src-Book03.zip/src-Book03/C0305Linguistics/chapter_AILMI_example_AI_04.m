%% chapter_AILMI_example_AI_04.m
% Recurrent Neural Network for sequence modelling in MATLAB.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_AI_04
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Training corpus for language modelling
textData = [ ...
    "The cat sat on the mat."; ...
    "The dog ran in the park."; ...
    "The bird flew over the tree."; ...
    "The fish swam in the pond."; ...
    "The cat chased the mouse."; ...
    "The dog played with the ball."; ...
    "The bird built a nest."; ...
    "The fish jumped from the water."];

% Preprocess text data
documents = tokenizedDocument(textData);
documents = erasePunctuation(lower(documents));

% Build vocabulary
vocab = unique([documents.Vocabulary]);
numWords = numel(vocab);

fprintf('RNN Language Model Training\n');
fprintf('Vocabulary size: %d words\n', numWords);
fprintf('Number of sequences: %d\n\n', numel(documents));

% Create word encoding
word2idx = containers.Map(string(vocab), 1:numWords);

% Prepare sequence data for RNN training
XTrain = {};
YTrain = {};

for i = 1:numel(documents)
    words = string(documents(i).Vocabulary);
    
    if numel(words) < 2
        continue;
    end
    
    % Create input-output pairs for prediction
    for j = 1:numel(words)-1
        % Input: sequence up to current word
        inputSeq = zeros(numWords, j);
        for k = 1:j
            idx = word2idx(words(k));
            inputSeq(idx, k) = 1;  % One-hot encoding
        end
        XTrain{end+1} = inputSeq;
        
        % Target: next word
        targetIdx = word2idx(words(j+1));
        targetVec = zeros(numWords, 1);
        targetVec(targetIdx) = 1;
        YTrain{end+1} = targetVec;
    end
end

fprintf('Training examples created: %d\n', numel(XTrain));

% Define RNN architecture
inputSize = numWords;
numHiddenUnits = 50;
outputSize = numWords;

layers = [ ...
    sequenceInputLayer(inputSize)
    lstmLayer(numHiddenUnits, 'OutputMode', 'last')
    fullyConnectedLayer(outputSize)
    softmaxLayer
    classificationLayer];

% Training options
options = trainingOptions('adam', ...
    'MaxEpochs', 100, ...
    'MiniBatchSize', 8, ...
    'Shuffle', 'every-epoch', ...
    'Verbose', false, ...
    'Plots', 'none');

% Convert data format for training
XTrainSeq = XTrain';
YTrainCat = cellfun(@(x) find(x), YTrain, 'UniformOutput', false);
YTrainCat = categorical([YTrainCat{:}]');

% Train network
fprintf('Training RNN model...\n');
net = trainNetwork(XTrainSeq, YTrainCat, layers, options);
fprintf('Training completed.\n\n');

% Test prediction
testSeeds = ["the cat", "the dog", "the bird"];

fprintf('Next-word Predictions:\n');

for i = 1:length(testSeeds)
    words = split(testSeeds(i));
    
    % Encode input sequence
    inputSeq = zeros(numWords, numel(words));
    for j = 1:numel(words)
        if isKey(word2idx, words(j))
            idx = word2idx(words(j));
            inputSeq(idx, j) = 1;
        end
    end
    
    % Predict next word
    predScores = predict(net, inputSeq);
    [~, predIdx] = max(predScores);
    predictedWord = vocab(predIdx);
    
    fprintf('  Input: "%s" -> Predicted: "%s"\n', ...
            testSeeds(i), predictedWord);
end

% Visualise hidden layer activations
figure('Position', [100, 100, 1200, 400]);

subplot(1, 2, 1);
% Sample sentence for activation visualisation
sampleWords = string(documents(1).Vocabulary);
sampleSeq = zeros(numWords, numel(sampleWords));

for i = 1:numel(sampleWords)
    idx = word2idx(sampleWords(i));
    sampleSeq(idx, i) = 1;
end

% Extract hidden states (approximate using network activations)
act = activations(net, sampleSeq, 'lstm_1');

imagesc(act');
colorbar;
xlabel('Hidden Unit');
ylabel('Time Step');
title('LSTM Hidden State Activations');
yticks(1:numel(sampleWords));
yticklabels(sampleWords);

subplot(1, 2, 2);
% Visualise embedding similarity
embeddingMatrix = net.Layers(2).InputWeights;
[U, S, V] = svds(embeddingMatrix, 2);
reducedEmbed = U * S;

scatter(reducedEmbed(:, 1), reducedEmbed(:, 2), 100, 'filled');
hold on;

for i = 1:min(20, numWords)
    text(reducedEmbed(i, 1), reducedEmbed(i, 2), ...
         vocab(i), 'FontSize', 8);
end

xlabel('First Dimension');
ylabel('Second Dimension');
title('Word Embedding Visualisation (SVD)');
grid on;
hold off;
