%% chapter_AILMI_example_multimodal_01.m
% Early fusion for multimodal media classification in MATLAB.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_multimodal_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Early Fusion for Multimodal Classification
% Demonstrates feature extraction from multiple modalities and their concatenation

fprintf('=== Early Fusion Multimodal Classification ===\n\n');

% Simulation parameters
numSamples = 100;            % Number of training samples
numClasses = 5;              % Classification categories

% Define feature dimensions for each modality
visualFeatureDim = 2048;     % e.g., ResNet-50 features
audioFeatureDim = 128;       % e.g., MFCCs or VGGish features
textFeatureDim = 300;        % e.g., Word2Vec or GloVe embeddings

fprintf('Multimodal Feature Dimensions:\n');
fprintf('  Visual features: %d dimensions\n', visualFeatureDim);
fprintf('  Audio features: %d dimensions\n', audioFeatureDim);
fprintf('  Text features: %d dimensions\n\n', textFeatureDim);

% - Step 1: Feature Extraction from Each Modality -

% Visual Feature Extraction (using pre-trained CNN)
fprintf('Step 1: Extracting features from each modality...\n');

% Load pre-trained ResNet-50 for visual feature extraction
visualNet = resnet50;
featureLayer = 'avg_pool';

% Generate synthetic visual data for demonstration
% In practice, load actual images using imageDatastore
imageHeight = visualNet.Layers(1).InputSize(1);
imageWidth = visualNet.Layers(1).InputSize(2);

% Extract features from sample images
fprintf('  Extracting visual features...\n');
visualFeatures = zeros(numSamples, visualFeatureDim, 'single');

% Demonstrate with a few actual images
sampleImage = imread('peppers.png');
sampleImage = imresize(sampleImage, [imageHeight, imageWidth]);

% Extract features for sample
sampleVisualFeats = activations(visualNet, sampleImage, featureLayer, ...
    'OutputAs', 'rows');

% For demonstration, generate synthetic features for remaining samples
for i = 1:numSamples
    if i == 1
        visualFeatures(i, :) = sampleVisualFeats;
    else
        % Simulate extracted features (in practice, extract from real images)
        visualFeatures(i, :) = randn(1, visualFeatureDim) * 0.5 + ...
            sampleVisualFeats * (1 + 0.1*randn);
    end
end

fprintf('  Visual features extracted: %d samples x %d features\n', ...
    size(visualFeatures));

% Audio Feature Extraction (MFCC-based)
fprintf('  Extracting audio features...\n');

% Load sample audio file
[audioSignal, sampleRate] = audioread('handel.mat');

% Compute MFCCs for sample audio
mfccCoeffs = mfcc(audioSignal, sampleRate, 'NumCoeffs', 13);

% Average MFCCs over time to get fixed-length representation
avgMFCC = mean(mfccCoeffs, 1);

% Expand to desired dimension through transformation
% In practice, use more sophisticated audio embeddings (e.g., VGGish)
audioFeatures = zeros(numSamples, audioFeatureDim, 'single');

for i = 1:numSamples
    % Simulate audio features based on MFCC extraction
    baseFeature = [avgMFCC, randn(1, audioFeatureDim - length(avgMFCC))];
    audioFeatures(i, :) = baseFeature + 0.1 * randn(1, audioFeatureDim);
end

fprintf('  Audio features extracted: %d samples x %d features\n', ...
    size(audioFeatures));

% Text Feature Extraction (Word Embeddings)
fprintf('  Extracting text features...\n');

% Simulate text embeddings (in practice, use word2vec or BERT)
% Generate random embeddings with some structure
textFeatures = randn(numSamples, textFeatureDim, 'single') * 0.5;

fprintf('  Text features extracted: %d samples x %d features\n\n', ...
    size(textFeatures));

% - Step 2: Early Fusion (Concatenation) -

fprintf('Step 2: Performing early fusion...\n');

% Concatenate all features
fusedFeatures = [visualFeatures, audioFeatures, textFeatures];

fusedFeatureDim = size(fusedFeatures, 2);
fprintf('  Concatenated feature dimension: %d\n', fusedFeatureDim);
fprintf('  (Visual: %d + Audio: %d + Text: %d)\n\n', ...
    visualFeatureDim, audioFeatureDim, textFeatureDim);

% Normalise features for better training
fusedFeaturesMean = mean(fusedFeatures, 1);
fusedFeaturesStd = std(fusedFeatures, 0, 1) + 1e-8;
fusedFeaturesNorm = (fusedFeatures - fusedFeaturesMean) ./ fusedFeaturesStd;

fprintf('  Features normalised (zero mean, unit variance)\n\n');

% Generate synthetic labels for classification
labels = categorical(randi([1, numClasses], numSamples, 1));

% - Step 3: Build Unified Classification Model -

fprintf('Step 3: Constructing unified classification network...\n');

% Define network architecture for fused features
layers = [
    featureInputLayer(fusedFeatureDim, 'Name', 'fused_input')
    
    % First hidden layer
    fullyConnectedLayer(512, 'Name', 'fc1')
    batchNormalizationLayer('Name', 'bn1')
    reluLayer('Name', 'relu1')
    dropoutLayer(0.5, 'Name', 'dropout1')
    
    % Second hidden layer
    fullyConnectedLayer(256, 'Name', 'fc2')
    batchNormalizationLayer('Name', 'bn2')
    reluLayer('Name', 'relu2')
    dropoutLayer(0.5, 'Name', 'dropout2')
    
    % Output layer
    fullyConnectedLayer(numClasses, 'Name', 'fc_output')
    softmaxLayer('Name', 'softmax')
    classificationLayer('Name', 'output')];

fprintf('  Network architecture:\n');
fprintf('    Input: %d-dimensional fused features\n', fusedFeatureDim);
fprintf('    Hidden layers: 512 -> 256 units\n');
fprintf('    Output: %d classes\n\n', numClasses);

% Training options
options = trainingOptions('adam', ...
    'MaxEpochs', 20, ...
    'MiniBatchSize', 16, ...
    'InitialLearnRate', 0.001, ...
    'Shuffle', 'every-epoch', ...
    'Verbose', false, ...
    'Plots', 'training-progress');

fprintf('  Training configuration:\n');
fprintf('    Optimiser: Adam\n');
fprintf('    Epochs: %d\n', options.MaxEpochs);
fprintf('    Batch size: %d\n', options.MiniBatchSize);
fprintf('    Learning rate: %.4f\n\n', options.InitialLearnRate);

% Train the network
fprintf('Step 4: Training early fusion model...\n');
multimodalNet = trainNetwork(fusedFeaturesNorm, labels, layers, options);

fprintf('Early fusion model training complete!\n\n');

% - Step 5: Visualise Feature Distributions -

fprintf('Step 5: Visualising multimodal feature space...\n');

% Perform PCA for visualisation
[coeff, score, ~, ~, explained] = pca(fusedFeaturesNorm);

% Plot first 3 principal components
figure('Position', [100, 100, 1400, 500]);

subplot(1, 3, 1);
scatter(score(:, 1), score(:, 2), 50, double(labels), 'filled');
colormap('jet');
colorbar;
xlabel(sprintf('PC1 (%.1f%% variance)', explained(1)));
ylabel(sprintf('PC2 (%.1f%% variance)', explained(2)));
title('Fused Feature Space (PC1 vs PC2)');
grid on;

subplot(1, 3, 2);
scatter3(score(:, 1), score(:, 2), score(:, 3), 50, double(labels), 'filled');
colormap('jet');
colorbar;
xlabel(sprintf('PC1 (%.1f%%)', explained(1)));
ylabel(sprintf('PC2 (%.1f%%)', explained(2)));
zlabel(sprintf('PC3 (%.1f%%)', explained(3)));
title('3*D Feature Space Visualisation');
grid on;
view(45, 30);

subplot(1, 3, 3);
bar(explained(1:10));
xlabel('Principal Component');
ylabel('Variance Explained (%)');
title('PCA Variance Explained');
grid on;

sgtitle('Early Fusion: Multimodal Feature Space Analysis', ...
    'FontSize', 14, 'FontWeight', 'bold');

print('early_fusion_feature_space', '-dpng', '-r300');

% Analyse modality contribution
fprintf('\n  Feature space analysis:\n');
fprintf('    First 3 PCs explain %.1f%% of variance\n', sum(explained(1:3)));
fprintf('    First 10 PCs explain %.1f%% of variance\n', sum(explained(1:10)));

% Examine feature importance by modality
visualContribution = sum(abs(coeff(1:visualFeatureDim, 1:3)), 'all');
audioContribution = sum(abs(coeff(visualFeatureDim+1:visualFeatureDim+audioFeatureDim, 1:3)), 'all');
textContribution = sum(abs(coeff(visualFeatureDim+audioFeatureDim+1:end, 1:3)), 'all');

totalContribution = visualContribution + audioContribution + textContribution;

fprintf('\n  Modality contribution to top 3 PCs:\n');
fprintf('    Visual: %.1f%%\n', 100*visualContribution/totalContribution);
fprintf('    Audio: %.1f%%\n', 100*audioContribution/totalContribution);
fprintf('    Text: %.1f%%\n', 100*textContribution/totalContribution);

fprintf('\nEarly fusion demonstration complete!\n');
