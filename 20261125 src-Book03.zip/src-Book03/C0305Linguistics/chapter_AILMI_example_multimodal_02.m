%% chapter_AILMI_example_multimodal_02.m
% Late fusion for multimodal classification with multiple combination strategies.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_multimodal_02
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Late Fusion for Multimodal Classification
% Demonstrates independent processing of modalities and decision-level combination

fprintf('=== Late Fusion Multimodal Classification ===\n\n');

% Simulation parameters
numSamples = 200;
numTrainSamples = 150;
numTestSamples = numSamples - numTrainSamples;
numClasses = 5;

fprintf('Dataset configuration:\n');
fprintf('  Total samples: %d\n', numSamples);
fprintf('  Training samples: %d\n', numTrainSamples);
fprintf('  Test samples: %d\n', numTestSamples);
fprintf('  Number of classes: %d\n\n', numClasses);

% Generate ground truth labels
allLabels = categorical(randi([1, numClasses], numSamples, 1));
trainLabels = allLabels(1:numTrainSamples);
testLabels = allLabels(numTrainSamples+1:end);

% - Step 1: Train Modality-Specific Models -

fprintf('Step 1: Training modality-specific classifiers...\n');

% Visual Modality Classifier
fprintf('  Training visual classifier...\n');
visualFeatureDim = 2048;
trainVisualFeatures = randn(numTrainSamples, visualFeatureDim) * 0.5;

% Add class-dependent patterns
for i = 1:numTrainSamples
    classIdx = double(trainLabels(i));
    trainVisualFeatures(i, :) = trainVisualFeatures(i, :) + ...
        classIdx * 0.3 * randn(1, visualFeatureDim);
end

% Define visual network
visualLayers = [
    featureInputLayer(visualFeatureDim, 'Name', 'visual_input')
    fullyConnectedLayer(256, 'Name', 'visual_fc1')
    reluLayer('Name', 'visual_relu1')
    dropoutLayer(0.3, 'Name', 'visual_dropout')
    fullyConnectedLayer(numClasses, 'Name', 'visual_output')
    softmaxLayer('Name', 'visual_softmax')
    classificationLayer('Name', 'visual_class')];

visualOptions = trainingOptions('adam', ...
    'MaxEpochs', 15, ...
    'MiniBatchSize', 32, ...
    'InitialLearnRate', 0.001, ...
    'Verbose', false);

visualNet = trainNetwork(trainVisualFeatures, trainLabels, ...
    visualLayers, visualOptions);

fprintf('    Visual classifier trained.\n');

% Audio Modality Classifier
fprintf('  Training audio classifier...\n');
audioFeatureDim = 128;
trainAudioFeatures = randn(numTrainSamples, audioFeatureDim) * 0.5;

for i = 1:numTrainSamples
    classIdx = double(trainLabels(i));
    trainAudioFeatures(i, :) = trainAudioFeatures(i, :) + ...
        classIdx * 0.4 * randn(1, audioFeatureDim);
end

audioLayers = [
    featureInputLayer(audioFeatureDim, 'Name', 'audio_input')
    fullyConnectedLayer(128, 'Name', 'audio_fc1')
    reluLayer('Name', 'audio_relu1')
    dropoutLayer(0.3, 'Name', 'audio_dropout')
    fullyConnectedLayer(numClasses, 'Name', 'audio_output')
    softmaxLayer('Name', 'audio_softmax')
    classificationLayer('Name', 'audio_class')];

audioOptions = trainingOptions('adam', ...
    'MaxEpochs', 15, ...
    'MiniBatchSize', 32, ...
    'InitialLearnRate', 0.001, ...
    'Verbose', false);

audioNet = trainNetwork(trainAudioFeatures, trainLabels, ...
    audioLayers, audioOptions);

fprintf('    Audio classifier trained.\n');

% Text Modality Classifier
fprintf('  Training text classifier...\n');
textFeatureDim = 300;
trainTextFeatures = randn(numTrainSamples, textFeatureDim) * 0.5;

for i = 1:numTrainSamples
    classIdx = double(trainLabels(i));
    trainTextFeatures(i, :) = trainTextFeatures(i, :) + ...
        classIdx * 0.35 * randn(1, textFeatureDim);
end

textLayers = [
    featureInputLayer(textFeatureDim, 'Name', 'text_input')
    fullyConnectedLayer(200, 'Name', 'text_fc1')
    reluLayer('Name', 'text_relu1')
    dropoutLayer(0.3, 'Name', 'text_dropout')
    fullyConnectedLayer(numClasses, 'Name', 'text_output')
    softmaxLayer('Name', 'text_softmax')
    classificationLayer('Name', 'text_class')];

textOptions = trainingOptions('adam', ...
    'MaxEpochs', 15, ...
    'MiniBatchSize', 32, ...
    'InitialLearnRate', 0.001, ...
    'Verbose', false);

textNet = trainNetwork(trainTextFeatures, trainLabels, ...
    textLayers, textOptions);

fprintf('    Text classifier trained.\n\n');

% - Step 2: Generate Test Predictions -

fprintf('Step 2: Generating individual modality predictions...\n');

% Generate test features
testVisualFeatures = randn(numTestSamples, visualFeatureDim) * 0.5;
testAudioFeatures = randn(numTestSamples, audioFeatureDim) * 0.5;
testTextFeatures = randn(numTestSamples, textFeatureDim) * 0.5;

for i = 1:numTestSamples
    classIdx = double(testLabels(i));
    testVisualFeatures(i, :) = testVisualFeatures(i, :) + ...
        classIdx * 0.3 * randn(1, visualFeatureDim);
    testAudioFeatures(i, :) = testAudioFeatures(i, :) + ...
        classIdx * 0.4 * randn(1, audioFeatureDim);
    testTextFeatures(i, :) = testTextFeatures(i, :) + ...
        classIdx * 0.35 * randn(1, textFeatureDim);
end

% Get probability scores from each modality
visualScores = predict(visualNet, testVisualFeatures);
audioScores = predict(audioNet, testAudioFeatures);
textScores = predict(textNet, testTextFeatures);

fprintf('  Prediction scores obtained from all modalities.\n\n');

% - Step 3: Late Fusion Strategies -

fprintf('Step 3: Applying different late fusion strategies...\n');

% Strategy 1: Uniform Average
uniformFusedScores = (visualScores + audioScores + textScores) / 3;
[~, uniformPredictions] = max(uniformFusedScores, [], 2);
uniformAccuracy = sum(uniformPredictions == double(testLabels)) / numTestSamples;

fprintf('  Uniform averaging accuracy: %.2f%%\n', uniformAccuracy * 100);

% Strategy 2: Weighted Average (learned weights)
% Estimate optimal weights on training data
trainVisualScores = predict(visualNet, trainVisualFeatures);
trainAudioScores = predict(audioNet, trainAudioFeatures);
trainTextScores = predict(textNet, trainTextFeatures);

% Simple grid search for weights
bestAccuracy = 0;
bestWeights = [0.33, 0.33, 0.34];

for w1 = 0.1:0.1:0.8
    for w2 = 0.1:0.1:(0.9-w1)
        w3 = 1 - w1 - w2;
        fusedTrainScores = w1*trainVisualScores + w2*trainAudioScores + ...
            w3*trainTextScores;
        [~, trainPreds] = max(fusedTrainScores, [], 2);
        accuracy = sum(trainPreds == double(trainLabels)) / numTrainSamples;
        
        if accuracy > bestAccuracy
            bestAccuracy = accuracy;
            bestWeights = [w1, w2, w3];
        end
    end
end

weightedFusedScores = bestWeights(1)*visualScores + ...
    bestWeights(2)*audioScores + bestWeights(3)*textScores;
[~, weightedPredictions] = max(weightedFusedScores, [], 2);
weightedAccuracy = sum(weightedPredictions == double(testLabels)) / numTestSamples;

fprintf('  Weighted averaging accuracy: %.2f%%\n', weightedAccuracy * 100);
fprintf('    Optimal weights: Visual=%.2f, Audio=%.2f, Text=%.2f\n', ...
    bestWeights);

% Strategy 3: Majority Voting
[~, visualPreds] = max(visualScores, [], 2);
[~, audioPreds] = max(audioScores, [], 2);
[~, textPreds] = max(textScores, [], 2);

votingPredictions = mode([visualPreds, audioPreds, textPreds], 2);
votingAccuracy = sum(votingPredictions == double(testLabels)) / numTestSamples;

fprintf('  Majority voting accuracy: %.2f%%\n', votingAccuracy * 100);

% Strategy 4: Maximum Confidence
maxConfVisual = max(visualScores, [], 2);
maxConfAudio = max(audioScores, [], 2);
maxConfText = max(textScores, [], 2);

maxConfPredictions = zeros(numTestSamples, 1);
for i = 1:numTestSamples
    [~, maxModality] = max([maxConfVisual(i), maxConfAudio(i), maxConfText(i)]);
    if maxModality == 1
        maxConfPredictions(i) = visualPreds(i);
    elseif maxModality == 2
        maxConfPredictions(i) = audioPreds(i);
    else
        maxConfPredictions(i) = textPreds(i);
    end
end

maxConfAccuracy = sum(maxConfPredictions == double(testLabels)) / numTestSamples;

fprintf('  Maximum confidence accuracy: %.2f%%\n\n', maxConfAccuracy * 100);

% - Step 4: Visualise Results -

fprintf('Step 4: Visualising fusion performance...\n');

figure('Position', [100, 100, 1400, 500]);

% Individual modality accuracies
visualIndivAcc = sum(visualPreds == double(testLabels)) / numTestSamples;
audioIndivAcc = sum(audioPreds == double(testLabels)) / numTestSamples;
textIndivAcc = sum(textPreds == double(testLabels)) / numTestSamples;

subplot(1, 3, 1);
accuracies = [visualIndivAcc, audioIndivAcc, textIndivAcc, ...
    uniformAccuracy, weightedAccuracy, votingAccuracy, maxConfAccuracy];
methodNames = {'Visual', 'Audio', 'Text', 'Uniform', 'Weighted', ...
    'Voting', 'MaxConf'};
bar(accuracies * 100);
ylabel('Accuracy (%)');
title('Performance Comparison');
set(gca, 'XTickLabel', methodNames, 'XTickLabelRotation', 45);
grid on;

% Confusion matrix for best fusion method
subplot(1, 3, 2);
[~, bestMethod] = max([uniformAccuracy, weightedAccuracy, ...
    votingAccuracy, maxConfAccuracy]);
if bestMethod == 1
    bestPredictions = uniformPredictions;
    methodName = 'Uniform Averaging';
elseif bestMethod == 2
    bestPredictions = weightedPredictions;
    methodName = 'Weighted Averaging';
elseif bestMethod == 3
    bestPredictions = votingPredictions;
    methodName = 'Majority Voting';
else
    bestPredictions = maxConfPredictions;
    methodName = 'Maximum Confidence';
end

confMat = confusionmat(double(testLabels), bestPredictions);
confusionchart(confMat);
title(sprintf('Confusion Matrix: %s', methodName));

% Score distribution
subplot(1, 3, 3);
hold on;
plot(weightedFusedScores(:, 1), 'r-', 'LineWidth', 1.5, 'DisplayName', 'Class 1');
plot(weightedFusedScores(:, 2), 'g-', 'LineWidth', 1.5, 'DisplayName', 'Class 2');
plot(weightedFusedScores(:, 3), 'b-', 'LineWidth', 1.5, 'DisplayName', 'Class 3');
hold off;
xlabel('Sample Index');
ylabel('Prediction Score');
title('Fused Prediction Scores (First 3 Classes)');
legend('Location', 'best');
grid on;

sgtitle('Late Fusion: Performance Analysis', 'FontSize', 14, 'FontWeight', 'bold');

print('late_fusion_performance', '-dpng', '-r300');

fprintf('\nLate fusion demonstration complete!\n');
fprintf('Best fusion strategy: %s (%.2f%% accuracy)\n', ...
    methodName, max(accuracies(4:end)) * 100);
