%% chapter_AILMI_example_fund_04.m
% Word embeddings exploration and semantic analogies.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_fund_04
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Load pre-trained word embedding model
emb = fastTextWordEmbedding;

fprintf('Embedding model loaded:\n');
fprintf('  Vocabulary size: %d words\n', emb.Dimension(1));
fprintf('  Embedding dimension: %d\n', emb.Dimension(2));

% Function to compute cosine similarity

% Explore semantic similarity
word = "computer";
vec = word2vec(emb, word);

% Find most similar words
similarWords = vec2word(emb, vec, 10);
fprintf('\nWords most similar to "%s":\n', word);
for i = 2:length(similarWords)  % Skip first (the word itself)
    simVec = word2vec(emb, similarWords(i));
    similarity = computeCosineSimilarity(vec, simVec);
    fprintf('  %s (%.4f)\n', similarWords(i), similarity);
end

% Solve semantic analogies: king - man + woman = ?
fprintf('\nSemantic analogy: king - man + woman = ?\n');
vecKing = word2vec(emb, "king");
vecMan = word2vec(emb, "man");
vecWoman = word2vec(emb, "woman");

analogyVec = vecKing - vecMan + vecWoman;
analogyResults = vec2word(emb, analogyVec, 5);

fprintf('Results:\n');
for i = 1:length(analogyResults)
    fprintf('  %d. %s\n', i, analogyResults(i));
end

% Explore syntactic relationships
fprintf('\nSyntactic analogy: walking - walk + swim = ?\n');
vecWalking = word2vec(emb, "walking");
vecWalk = word2vec(emb, "walk");
vecSwim = word2vec(emb, "swim");

syntacticVec = vecWalking - vecWalk + vecSwim;
syntacticResults = vec2word(emb, syntacticVec, 5);

fprintf('Results:\n');
for i = 1:length(syntacticResults)
    fprintf('  %d. %s\n', i, syntacticResults(i));
end

% Visualise word embeddings using t-SNE
wordList = ["king", "queen", "man", "woman", "prince", "princess", ...
            "doctor", "nurse", "teacher", "student", ...
            "computer", "software", "hardware", "algorithm", ...
            "cat", "dog", "animal", "pet", "bird", "fish"];

wordVectors = word2vec(emb, wordList);

% Apply t-SNE for 2*D visualisation
rng(42);  % For reproducibility
embeddedVecs = tsne(wordVectors, 'NumDimensions', 2, ...
                   'Perplexity', 5);

% Plot embeddings
figure;
scatter(embeddedVecs(:,1), embeddedVecs(:,2), 100, 'filled', ...
        'MarkerFaceAlpha', 0.6);
hold on;

% Add word labels
for i = 1:length(wordList)
    text(embeddedVecs(i,1)+0.3, embeddedVecs(i,2), wordList(i), ...
         'FontSize', 10, 'FontWeight', 'bold');
end

title('Word Embedding Visualisation (t-SNE Projection)');
xlabel('Dimension 1');
ylabel('Dimension 2');
grid on;
hold off;

% Compute and visualise similarity matrix
fprintf('\nComputing pairwise similarities...\n');
numWords = length(wordList);
simMatrix = zeros(numWords, numWords);

for i = 1:numWords
    for j = 1:numWords
        simMatrix(i,j) = computeCosineSimilarity(...
                        wordVectors(i,:), wordVectors(j,:));
    end
end

% Plot similarity heatmap
figure;
imagesc(simMatrix);
colorbar;
colormap('hot');
title('Word Similarity Matrix');
xticks(1:numWords);
yticks(1:numWords);
xticklabels(wordList);
yticklabels(wordList);
xtickangle(45);
axis square;

% Local functions (moved to end so this listing is a valid MATLAB script)
function similarity = computeCosineSimilarity(vec1, vec2)
    similarity = dot(vec1, vec2) / (norm(vec1) * norm(vec2));
end
