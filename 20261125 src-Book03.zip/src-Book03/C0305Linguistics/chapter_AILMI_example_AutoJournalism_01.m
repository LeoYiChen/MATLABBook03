%% chapter_AILMI_example_AutoJournalism_01.m
% Automated journalism system for financial earnings report generation with multi-template selection and anomaly detection.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_AutoJournalism_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Automated Journalism System - Financial Earnings Reporter
% Generates news articles from structured financial data

fprintf('=== Automated Journalism System ===\n\n');

% - Step 1: Simulate Financial Earnings Data -

fprintf('Step 1: Loading financial earnings data...\n');

% Company names
companies = ["TechCorp", "FinanceGlobal", "RetailMart", "EnergyPlus", ...
    "HealthSystems", "AutoDrive", "MediaNet", "FoodChain"];
numCompanies = length(companies);

% Generate quarterly earnings data
quarters = ["Q1 2024", "Q2 2024", "Q3 2024", "Q4 2024"];
currentQuarter = "Q4 2024";

% Financial metrics
earningsData = struct();

for companyIdx = 1:numCompanies
    company = companies(companyIdx);
    
    % Revenue (in billions)
    earningsData(companyIdx).company = company;
    earningsData(companyIdx).quarter = currentQuarter;
    earningsData(companyIdx).revenue = 10 + rand() * 80;  % $10*B-$90*B
    earningsData(companyIdx).revenueYoY = -10 + rand() * 30;  % -10% to +20%
    
    % Net income (in billions)
    earningsData(companyIdx).netIncome = earningsData(companyIdx).revenue * ...
        (0.05 + rand() * 0.15);  % 5%-20% margin
    earningsData(companyIdx).netIncomeYoY = -15 + rand() * 35;  % -15% to +20%
    
    % Earnings per share
    earningsData(companyIdx).eps = 1 + rand() * 8;  % $1-$9
    earningsData(companyIdx).epsEstimate = earningsData(companyIdx).eps + ...
        (-0.5 + rand());  % Analyst estimate
    
    % Other metrics
    earningsData(companyIdx).marketCap = earningsData(companyIdx).revenue * ...
        (8 + rand() * 12);  % Price-to-sales multiple
    earningsData(companyIdx).sector = ["Technology", "Finance", "Retail", ...
        "Energy", "Healthcare", "Automotive", "Media", "Consumer"][companyIdx];
end

fprintf('  Loaded earnings data for %d companies\n', numCompanies);
fprintf('  Reporting period: %s\n\n', currentQuarter);

% Display sample data
fprintf('  Sample: %s\n', earningsData(1).company);
fprintf('    Revenue: $%.2fB (%.1f%% YoY)\n', earningsData(1).revenue, ...
    earningsData(1).revenueYoY);
fprintf('    Net Income: $%.2fB (%.1f%% YoY)\n', earningsData(1).netIncome, ...
    earningsData(1).netIncomeYoY);
fprintf('    EPS: $%.2f (Est: $%.2f)\n\n', earningsData(1).eps, ...
    earningsData(1).epsEstimate);

% - Step 2: Event Detection and Newsworthiness -

fprintf('Step 2: Detecting newsworthy events...\n');

% Define newsworthiness criteria
newsworthinessScores = zeros(numCompanies, 1);

for companyIdx = 1:numCompanies
    score = 0;
    
    % Strong revenue growth or decline
    if abs(earningsData(companyIdx).revenueYoY) > 15
        score = score + 3;
    elseif abs(earningsData(companyIdx).revenueYoY) > 8
        score = score + 1;
    end
    
    % Earnings surprise (beat or miss estimates significantly)
    epsSurprise = earningsData(companyIdx).eps - ...
        earningsData(companyIdx).epsEstimate;
    if abs(epsSurprise) > 0.5
        score = score + 2;
    end
    
    % Strong profit margin changes
    if abs(earningsData(companyIdx).netIncomeYoY) > 20
        score = score + 2;
    end
    
    % Large company (higher newsworthiness)
    if earningsData(companyIdx).marketCap > 500
        score = score + 1;
    end
    
    newsworthinessScores(companyIdx) = score;
end

% Rank by newsworthiness
[sortedScores, rankIdx] = sort(newsworthinessScores, 'descend');

fprintf('  Newsworthiness rankings:\n');
for i = 1:min(5, numCompanies)
    companyIdx = rankIdx(i);
    fprintf('    %d. %s (score: %d)\n', i, ...
        earningsData(companyIdx).company, sortedScores(i));
end
fprintf('\n');

% - Step 3: Template-Based Article Generation -

fprintf('Step 3: Generating news articles using NLG templates...\n');

% Define article templates with variations
templates = struct();

% Headline templates
templates.headlines = [
    "%s Reports %s %s Revenue of $%.2fB in %s";
    "%s %s Analyst Expectations with $%.2f EPS";
    "%s Posts %.1f%% Revenue Growth in %s Quarter";
    "%s Earnings: Revenue %s to $%.2fB"
];

% Lead paragraph templates
templates.leads = [
    "%s reported %s quarterly revenue of $%.2f billion for %s, " + ...
    "representing a %.1f%% %s compared to the same period last year. " + ...
    "The %s company posted earnings per share of $%.2f, %s analyst " + ...
    "estimates of $%.2f.";
    
    "In its latest quarterly results, %s announced revenue of $%.2f billion, " + ...
    "marking a %.1f%% year-over-year %s. Net income totalled $%.2f billion, " + ...
    "%s by %.1f%% from the prior year period.";
    
    "%s shares moved %s in after-hours trading following the release of " + ...
    "%s earnings results. The company generated $%.2f billion in revenue, " + ...
    "%s Wall Street projections."
];

% Performance descriptor functions



% Generate articles for top companies
generatedArticles = cell(numCompanies, 1);

for companyIdx = 1:numCompanies
    data = earningsData(companyIdx);
    
    % Select templates based on newsworthiness
    if newsworthinessScores(companyIdx) >= 4
        headlineTemplate = templates.headlines(1);
        leadTemplate = templates.leads(1);
    elseif newsworthinessScores(companyIdx) >= 2
        headlineTemplate = templates.headlines(2);
        leadTemplate = templates.leads(2);
    else
        headlineTemplate = templates.headlines(4);
        leadTemplate = templates.leads(2);
    end
    
    % Generate headline
    perfDesc = getPerformanceDescriptor(data.revenueYoY, 8);
    compPhrase = getComparisonPhrase(data.eps, data.epsEstimate);
    
    if contains(headlineTemplate, "Analyst")
        headline = sprintf(headlineTemplate, data.company, compPhrase, data.eps);
    else
        trendWord = getTrendPhrase(data.revenueYoY);
        headline = sprintf(headlineTemplate, data.company, perfDesc, ...
            trendWord, data.revenue, data.quarter);
    end
    
    % Generate lead paragraph
    trendPhrase = getTrendPhrase(data.revenueYoY);
    comparisonPhrase = getComparisonPhrase(data.eps, data.epsEstimate);
    
    if data.revenueYoY > 0
        changeDir = "increase";
    else
        changeDir = "decrease";
    end
    
    if data.netIncomeYoY > 0
        incomeChange = "increasing";
    else
        incomeChange = "decreasing";
    end
    
    lead = sprintf(leadTemplate, data.company, perfDesc, data.revenue, ...
        data.quarter, abs(data.revenueYoY), changeDir, lower(data.sector), ...
        data.eps, comparisonPhrase, data.epsEstimate);
    
    % Combine into article
    article = struct();
    article.headline = headline;
    article.lead = lead;
    article.company = data.company;
    article.timestamp = datetime('now');
    
    generatedArticles{companyIdx} = article;
end

fprintf('  Generated %d articles\n\n', numCompanies);

% Display top articles
fprintf('  Top 3 Generated Articles:\n\n');
for i = 1:min(3, numCompanies)
    companyIdx = rankIdx(i);
    article = generatedArticles{companyIdx};
    
    fprintf('  - Article %d -\n', i);
    fprintf('  HEADLINE: %s\n', article.headline);
    fprintf('  LEAD: %s\n', article.lead);
    fprintf('  Published: %s\n\n', datestr(article.timestamp));
end

% - Step 4: Fact Verification and Quality Checks -

fprintf('Step 4: Performing automated fact verification...\n');

% Verification checks
verificationResults = struct();
allPassed = true;

for companyIdx = 1:numCompanies
    data = earningsData(companyIdx);
    article = generatedArticles{companyIdx};
    
    checks = struct();
    
    % Check 1: Revenue figure accuracy
    checks.revenueAccurate = contains(article.lead, ...
        sprintf('%.2f', data.revenue));
    
    % Check 2: EPS figure accuracy  
    checks.epsAccurate = contains(article.lead, sprintf('%.2f', data.eps));
    
    % Check 3: Logical consistency (growth should match sign)
    if data.revenueYoY > 0
        checks.growthConsistent = contains(lower(article.lead), ...
            ["increase", "growth", "gain"]);
    else
        checks.growthConsistent = contains(lower(article.lead), ...
            ["decrease", "decline", "fall"]);
    end
    
    % Check 4: Comparison accuracy
    epsDiff = data.eps - data.epsEstimate;
    if epsDiff > 0
        checks.comparisonAccurate = contains(lower(article.lead), ...
            ["exceed", "beat", "surpass", "top"]);
    else
        checks.comparisonAccurate = contains(lower(article.lead), ...
            ["miss", "below", "short", "disappoint"]);
    end
    
    % Overall pass/fail
    checks.allPassed = checks.revenueAccurate && checks.epsAccurate && ...
        checks.growthConsistent && checks.comparisonAccurate;
    
    verificationResults(companyIdx) = checks;
    
    if ~checks.allPassed
        allPassed = false;
    end
end

passCount = sum([verificationResults.allPassed]);
fprintf('  Verification complete: %d/%d articles passed all checks\n', ...
    passCount, numCompanies);

if allPassed
    fprintf('  All articles verified successfully!\n\n');
else
    fprintf('  Some articles require review:\n');
    for companyIdx = 1:numCompanies
        if ~verificationResults(companyIdx).allPassed
            fprintf('    - %s: Failed checks\n', ...
                earningsData(companyIdx).company);
        end
    end
    fprintf('\n');
end

% - Step 5: Analytics and Performance Metrics -

fprintf('Step 5: Computing journalism system performance metrics...\n');

% Calculate generation statistics
avgWordsPerArticle = 0;
for companyIdx = 1:numCompanies
    article = generatedArticles{companyIdx};
    wordCount = length(strsplit(article.lead));
    avgWordsPerArticle = avgWordsPerArticle + wordCount;
end
avgWordsPerArticle = avgWordsPerArticle / numCompanies;

% Estimate time savings vs manual writing
minutesPerManualArticle = 15;  % Typical time for earnings brief
totalManualMinutes = numCompanies * minutesPerManualArticle;
systemGenerationSeconds = 2;  % Automated generation time

timeSavings = (totalManualMinutes * 60 - systemGenerationSeconds) / 60;

fprintf('  Performance Metrics:\n');
fprintf('    Articles generated: %d\n', numCompanies);
fprintf('    Average article length: %.0f words\n', avgWordsPerArticle);
fprintf('    Generation time: %.0f seconds\n', systemGenerationSeconds);
fprintf('    Estimated time savings: %.0f minutes (vs manual writing)\n', ...
    timeSavings);
fprintf('    Verification pass rate: %.1f%%\n', (passCount/numCompanies)*100);
fprintf('\n');

% - Step 6: Content Diversity Analysis -

fprintf('Step 6: Analysing content diversity and variation...\n');

% Extract all headlines and leads
allHeadlines = strings(numCompanies, 1);
allLeads = strings(numCompanies, 1);

for companyIdx = 1:numCompanies
    article = generatedArticles{companyIdx};
    allHeadlines(companyIdx) = article.headline;
    allLeads(companyIdx) = article.lead;
end

% Calculate lexical diversity (unique words / total words)
allText = strjoin([allHeadlines; allLeads], ' ');
tokens = lower(strsplit(allText));
uniqueTokens = unique(tokens);
lexicalDiversity = length(uniqueTokens) / length(tokens);

fprintf('  Content diversity metrics:\n');
fprintf('    Total unique words: %d\n', length(uniqueTokens));
fprintf('    Total words: %d\n', length(tokens));
fprintf('    Lexical diversity: %.3f\n', lexicalDiversity);
fprintf('\n');

% - Step 7: Visualisation -

fprintf('Step 7: Generating visualisations...\n');

figure('Position', [100, 100, 1600, 1000]);

% Plot 1: Newsworthiness scores
subplot(2, 3, 1);
bar(newsworthinessScores(rankIdx), 'FaceColor', [0.3, 0.6, 0.9]);
xlabel('Company Rank');
ylabel('Newsworthiness Score');
title('Article Newsworthiness Rankings');
grid on;

% Plot 2: Revenue distribution
subplot(2, 3, 2);
revenues = [earningsData.revenue];
histogram(revenues, 15, 'FaceColor', [0.6, 0.4, 0.8]);
xlabel('Revenue ($B)');
ylabel('Frequency');
title('Company Revenue Distribution');
grid on;

% Plot 3: YoY revenue growth
subplot(2, 3, 3);
revenueYoY = [earningsData.revenueYoY];
bar(1:numCompanies, revenueYoY(rankIdx), 'FaceColor', [0.5, 0.7, 0.5]);
xlabel('Company Rank');
ylabel('YoY Growth (%)');
title('Revenue Year-over-Year Growth');
grid on;
hold on;
plot([0, numCompanies+1], [0, 0], 'r-', 'LineWidth', 1.5);
hold off;

% Plot 4: EPS vs Estimates
subplot(2, 3, 4);
eps = [earningsData.eps];
epsEst = [earningsData.epsEstimate];
scatter(epsEst(rankIdx), eps(rankIdx), 100, 'filled');
hold on;
plot([min(epsEst), max(epsEst)], [min(epsEst), max(epsEst)], ...
    'r-', 'LineWidth', 2);
hold off;
xlabel('Analyst Estimate ($)');
ylabel('Actual EPS ($)');
title('Earnings Per Share: Actual vs Estimates');
legend('Companies', 'Perfect Match', 'Location', 'best');
grid on;

% Plot 5: Verification results
subplot(2, 3, 5);
verificationCategories = {'Revenue', 'EPS', 'Growth Logic', 'Comparison'};
passRates = [
    sum([verificationResults.revenueAccurate])/numCompanies*100, ...
    sum([verificationResults.epsAccurate])/numCompanies*100, ...
    sum([verificationResults.growthConsistent])/numCompanies*100, ...
    sum([verificationResults.comparisonAccurate])/numCompanies*100
];
bar(passRates, 'FaceColor', [0.8, 0.5, 0.3]);
set(gca, 'XTickLabel', verificationCategories, 'XTickLabelRotation', 45);
ylabel('Pass Rate (%)');
title('Fact Verification Check Results');
ylim([0, 105]);
grid on;

% Plot 6: Article length distribution
subplot(2, 3, 6);
articleLengths = zeros(numCompanies, 1);
for companyIdx = 1:numCompanies
    article = generatedArticles{companyIdx};
    articleLengths(companyIdx) = length(strsplit(article.lead));
end
histogram(articleLengths, 10, 'FaceColor', [0.4, 0.5, 0.9]);
xlabel('Word Count');
ylabel('Frequency');
title('Generated Article Length Distribution');
grid on;

sgtitle('Automated Journalism System Performance Dashboard', ...
    'FontSize', 14, 'FontWeight', 'bold');

print('automated_journalism_dashboard', '-dpng', '-r300');

fprintf('\nAutomated journalism system complete!\n');
fprintf('Generated %d earnings articles in %.0f seconds\n', ...
    numCompanies, systemGenerationSeconds);
fprintf('System achieved %.1f%% fact verification pass rate\n', ...
    (passCount/numCompanies)*100);
fprintf('Estimated %.0f minutes saved compared to manual writing.\n', ...
    timeSavings);

% Local functions (moved to end so this listing is a valid MATLAB script)
function desc = getPerformanceDescriptor(value, threshold)
    if value > threshold
        descriptors = ["strong", "robust", "impressive", "solid"];
        desc = descriptors(randi(length(descriptors)));
    elseif value < -threshold
        descriptors = ["weak", "disappointing", "challenging", "declining"];
        desc = descriptors(randi(length(descriptors)));
    else
        descriptors = ["mixed", "moderate", "steady"];
        desc = descriptors(randi(length(descriptors)));
    end
end

function comp = getComparisonPhrase(actual, estimate)
    diff = actual - estimate;
    if diff > 0.3
        phrases = ["significantly exceeding", "handily beating", ...
            "surpassing"];
    elseif diff > 0
        phrases = ["slightly exceeding", "beating", "topping"];
    elseif diff > -0.3
        phrases = ["slightly missing", "coming in below", ...
            "falling short of"];
    else
        phrases = ["significantly missing", "well below", ...
            "disappointing relative to"];
    end
    comp = phrases(randi(length(phrases)));
end

function trend = getTrendPhrase(yoyChange)
    if yoyChange > 10
        trend = "increase";
    elseif yoyChange > 0
        trend = "gain";
    elseif yoyChange > -10
        trend = "decline";
    else
        trend = "decrease";
    end
end
