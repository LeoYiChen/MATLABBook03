%% chapter_AILMI_example_fund_02.m
% Bag-of-Words model construction and document similarity.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_fund_02
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Sample document collection
documents = ["Machine learning transforms data analysis.";
             "Deep learning revolutionises pattern recognition.";
             "Data science combines statistics and programming.";
             "Machine learning applies statistical methods."];

% Preprocess documents
tokenDocs = tokenizedDocument(documents);
tokenDocs = erasePunctuation(lower(tokenDocs));
tokenDocs = removeStopWords(tokenDocs);

% Create bag-of-words model
bag = bagOfWords(tokenDocs);

% Display vocabulary and document-term matrix
fprintf('Vocabulary size: %d words\n', bag.NumWords);
fprintf('\nTop 10 words:\n');
topWords = topkwords(bag, 10);
disp(topWords);

% Get document-term matrix (word counts)
dtMatrix = bag.Counts;

fprintf('\nDocument-Term Matrix:\n');
disp(dtMatrix);

% Calculate document similarity using cosine similarity

% Compute similarity matrix
simMatrix = calculateCosineSimilarity(dtMatrix);

fprintf('\nDocument Similarity Matrix:\n');
disp(simMatrix);

% Visualise similarity matrix
figure;
imagesc(simMatrix);
colorbar;
title('Document Similarity Matrix (BoW)');
xlabel('Document Index');
ylabel('Document Index');
colormap('hot');
axis square;

% Local functions (moved to end so this listing is a valid MATLAB script)
function simMatrix = calculateCosineSimilarity(dtMatrix)
    numDocs = size(dtMatrix, 1);
    simMatrix = zeros(numDocs, numDocs);
    
    for i = 1:numDocs
        for j = 1:numDocs
            vec1 = dtMatrix(i, :);
            vec2 = dtMatrix(j, :);
            simMatrix(i, j) = dot(vec1, vec2) / ...
                              (norm(vec1) * norm(vec2));
        end
    end
end
