%% chapter_AILMI_example_relation_extraction_01.m
% Relation extraction system using BiLSTM with positional embeddings for entity relationship identification.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_relation_extraction_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Relation Extraction with BiLSTM
% Demonstrates identifying semantic relationships between named entities

fprintf('=== Relation Extraction System ===\n\n');

% - Step 1: Prepare Relation Extraction Data -

fprintf('Step 1: Loading relation extraction training corpus...\n');

% Training data: (sentence, entity1, entity2, relation_type)
% Simplified representation for demonstration
relationData = {
    'Apple Inc. was founded by Steve Jobs', 'Apple Inc.', 'Steve Jobs', 'founded_by';
    'Microsoft is headquartered in Redmond', 'Microsoft', 'Redmond', 'headquartered_in';
    'Barack Obama was born in Hawaii', 'Barack Obama', 'Hawaii', 'born_in';
    'Google acquired YouTube in 2006', 'Google', 'YouTube', 'acquired';
    'Tim Cook is CEO of Apple', 'Tim Cook', 'Apple', 'CEO_of';
    'Amazon operates in Seattle', 'Amazon', 'Seattle', 'located_in';
    'Marie Curie won the Nobel Prize', 'Marie Curie', 'Nobel Prize', 'won';
    'Tesla opened factory in Shanghai', 'Tesla', 'Shanghai', 'opened_in';
    'IBM partnered with Microsoft', 'IBM', 'Microsoft', 'partnered_with';
    'Stanford University is located in California', 'Stanford University', 'California', 'located_in'
};

numRelations = size(relationData, 1);
fprintf('  Training relation instances: %d\n', numRelations);

% Define relation types
relationTypes = {'founded_by', 'headquartered_in', 'born_in', 'acquired', ...
                 'CEO_of', 'located_in', 'won', 'opened_in', 'partnered_with', 'no_relation'};
numRelationTypes = length(relationTypes);

fprintf('  Relation types: %d\n', numRelationTypes);
fprintf('  Types: %s\n\n', strjoin(relationTypes, ', '));

% - Step 2: Build Vocabulary -

fprintf('Step 2: Building vocabulary for relation extraction...\n');

allSentences = relationData(:, 1);
allWords = {};

for i = 1:numRelations
    sentence = lower(relationData{i, 1});
    words = split(sentence);
    words = words(strlength(words) > 0);
    allWords = [allWords; words];
end

vocabulary = unique(['<PAD>', '<UNK>', allWords']);
vocabSize = length(vocabulary);
word2idx = containers.Map(vocabulary, 1:vocabSize);
idx2word = containers.Map(1:vocabSize, vocabulary);

fprintf('  Vocabulary size: %d words\n\n', vocabSize);

% Create relation type to index mapping
relation2idx = containers.Map(relationTypes, 1:numRelationTypes);
idx2relation = containers.Map(1:numRelationTypes, relationTypes);

% - Step 3: Encode Sequences with Positional Information -

fprintf('Step 3: Encoding sequences with entity positional embeddings...\n');

XTrain = cell(numRelations, 1);
YTrain = zeros(numRelations, 1);

maxPositionDistance = 50;  % Maximum relative position encoding

for i = 1:numRelations
    sentence = lower(relationData{i, 1});
    entity1 = lower(relationData{i, 2});
    entity2 = lower(relationData{i, 3});
    relationType = relationData{i, 4};
    
    % Tokenise sentence
    words = split(sentence);
    words = words(strlength(words) > 0);
    seqLength = length(words);
    
    % Find entity positions (simplified - exact match)
    entity1Words = split(entity1);
    entity2Words = split(entity2);
    
    entity1Pos = [];
    entity2Pos = [];
    
    % Find entity 1 position
    for j = 1:seqLength - length(entity1Words) + 1
        match = true;
        for k = 1:length(entity1Words)
            if ~strcmp(words{j+k-1}, entity1Words{k})
                match = false;
                break;
            end
        end
        if match
            entity1Pos = j:(j + length(entity1Words) - 1);
            break;
        end
    end
    
    % Find entity 2 position
    for j = 1:seqLength - length(entity2Words) + 1
        match = true;
        for k = 1:length(entity2Words)
            if ~strcmp(words{j+k-1}, entity2Words{k})
                match = false;
                break;
            end
        end
        if match
            entity2Pos = j:(j + length(entity2Words) - 1);
            break;
        end
    end
    
    % Create feature representation: [word_idx; pos_to_e1; pos_to_e2]
    features = zeros(3, seqLength);
    
    for j = 1:seqLength
        % Word index
        if isKey(word2idx, words{j})
            features(1, j) = word2idx(words{j});
        else
            features(1, j) = word2idx('<UNK>');
        end
        
        % Relative position to entity 1 (clipped)
        if ~isempty(entity1Pos)
            relPos1 = j - mean(entity1Pos);
            features(2, j) = max(-maxPositionDistance, min(maxPositionDistance, relPos1));
        end
        
        % Relative position to entity 2 (clipped)
        if ~isempty(entity2Pos)
            relPos2 = j - mean(entity2Pos);
            features(3, j) = max(-maxPositionDistance, min(maxPositionDistance, relPos2));
        end
    end
    
    XTrain{i} = features;
    
    % Relation label
    if isKey(relation2idx, relationType)
        YTrain(i) = relation2idx(relationType);
    else
        YTrain(i) = relation2idx('no_relation');
    end
end

fprintf('  Encoded relation instances: %d\n', numRelations);
fprintf('  Feature dimensions: word + position_e1 + position_e2\n\n');

% Convert labels to categorical
YTrainCat = categorical(YTrain);

% - Step 4: Define Relation Extraction Architecture -

fprintf('Step 4: Constructing BiLSTM relation extraction network...\n');

embeddingDim = 50;
positionEmbeddingDim = 25;
numHiddenUnits = 100;

% Note: MATLAB's standard layers expect single input
% This simplified version uses word features only
% Full implementation would concatenate word + positional embeddings

% Extract word indices only for standard LSTM
XTrainWords = cell(numRelations, 1);
for i = 1:numRelations
    XTrainWords{i} = XTrain{i}(1, :)';  % Word indices only
end

layers = [
    sequenceInputLayer(1, 'Name', 'input')
    
    wordEmbeddingLayer(embeddingDim, vocabSize, 'Name', 'word_embedding')
    
    bilstmLayer(numHiddenUnits, 'OutputMode', 'last', 'Name', 'bilstm')
    dropoutLayer(0.3, 'Name', 'dropout')
    
    fullyConnectedLayer(numRelationTypes, 'Name', 'fc')
    softmaxLayer('Name', 'softmax')
    classificationLayer('Name', 'classification')
];

fprintf('  Architecture: BiLSTM with relation classification head\n');
fprintf('    Word embedding: %d dimensions\n', embeddingDim);
fprintf('    BiLSTM hidden units: %d\n', numHiddenUnits);
fprintf('    Output relation types: %d\n\n', numRelationTypes);

% - Step 5: Training Configuration -

fprintf('Step 5: Configuring relation extraction training...\n');

options = trainingOptions('adam', ...
    'MaxEpochs', 80, ...
    'MiniBatchSize', 2, ...
    'InitialLearnRate', 0.01, ...
    'GradientThreshold', 1, ...
    'Shuffle', 'every-epoch', ...
    'Verbose', false, ...
    'Plots', 'none');

fprintf('  Training epochs: %d\n', options.MaxEpochs);
fprintf('  Learning rate: %.4f\n\n', options.InitialLearnRate);

% - Step 6: Train Relation Extraction Model -

fprintf('Step 6: Training relation extraction model...\n');

tic;
relationModel = trainNetwork(XTrainWords, YTrainCat, layers, options);
trainingTime = toc;

fprintf('  Training completed in %.2f seconds\n\n', trainingTime);

% - Step 7: Test Relation Extraction -

fprintf('Step 7: Testing relation extraction on new sentences...\n');

testSentences = {
    'Facebook was founded by Mark Zuckerberg', 'Facebook', 'Mark Zuckerberg';
    'Oxford University is located in England', 'Oxford University', 'England';
    'Elon Musk is CEO of Tesla', 'Elon Musk', 'Tesla'
};

numTestSentences = size(testSentences, 1);

fprintf('  Test sentences: %d\n\n', numTestSentences);

for i = 1:numTestSentences
    sentence = lower(testSentences{i, 1});
    entity1 = lower(testSentences{i, 2});
    entity2 = lower(testSentences{i, 3});
    
    % Tokenise
    words = split(sentence);
    words = words(strlength(words) > 0);
    seqLength = length(words);
    
    % Convert to indices
    wordIndices = zeros(seqLength, 1);
    for j = 1:seqLength
        if isKey(word2idx, words{j})
            wordIndices(j) = word2idx(words{j});
        else
            wordIndices(j) = word2idx('<UNK>');
        end
    end
    
    % Predict relation
    predictedRelation = classify(relationModel, wordIndices);
    relationIdx = double(predictedRelation);
    
    if isKey(idx2relation, relationIdx)
        relationName = idx2relation(relationIdx);
    else
        relationName = 'unknown';
    end
    
    fprintf('  Test %d:\n', i);
    fprintf('    Sentence: %s\n', testSentences{i, 1});
    fprintf('    Entity 1: %s\n', testSentences{i, 2});
    fprintf('    Entity 2: %s\n', testSentences{i, 3});
    fprintf('    Predicted Relation: %s\n\n', relationName);
end

% - Step 8: Visualisation -

fprintf('Step 8: Generating relation extraction visualisations...\n');

figure('Position', [100, 100, 1600, 900]);

% Plot 1: Relation type distribution
subplot(2, 3, 1);
relationCounts = zeros(numRelationTypes, 1);
for i = 1:numRelations
    relationCounts(YTrain(i)) = relationCounts(YTrain(i)) + 1;
end

bar(relationCounts, 'FaceColor', [0.3, 0.7, 0.9]);
set(gca, 'XTick', 1:numRelationTypes, 'XTickLabel', relationTypes, ...
    'XTickLabelRotation', 45);
ylabel('Count');
title('Relation Type Distribution');
grid on;

% Plot 2: Sequence length distribution
subplot(2, 3, 2);
seqLengths = cellfun(@(x) size(x, 2), XTrain);
histogram(seqLengths, 'BinWidth', 1, 'FaceColor', [0.6, 0.4, 0.8]);
xlabel('Sequence Length (tokens)');
ylabel('Frequency');
title('Sentence Length Distribution');
grid on;

% Plot 3: Entity position heatmap (simulated)
subplot(2, 3, 3);
% Simulated positional attention weights
positionRange = -10:10;
attentionWeights = exp(-(positionRange.^2)/20);  % Gaussian-like
plot(positionRange, attentionWeights, 'b-', 'LineWidth', 2);
xlabel('Relative Position to Entity');
ylabel('Attention Weight (simulated)');
title('Positional Attention Pattern');
grid on;

% Plot 4: Training loss (simulated)
subplot(2, 3, 4);
epochs = 1:options.MaxEpochs;
simulatedLoss = 2.0 * exp(-epochs/20) + 0.4 + 0.05 * randn(size(epochs));
plot(epochs, simulatedLoss, 'r-', 'LineWidth', 2);
xlabel('Epoch');
ylabel('Cross-Entropy Loss');
title('Training Loss Curve (Simulated)');
grid on;

% Plot 5: Confusion matrix (simulated)
subplot(2, 3, 5);
% Simulated confusion matrix for top 5 relations
topRelations = min(5, numRelationTypes);
confusionMat = eye(topRelations) * 0.8 + rand(topRelations) * 0.1;
confusionMat = confusionMat ./ sum(confusionMat, 2);

imagesc(confusionMat);
colorbar;
colormap(flipud(gray));
xlabel('Predicted Relation');
ylabel('True Relation');
title('Relation Classification Matrix (Simulated)');
set(gca, 'XTick', 1:topRelations, 'YTick', 1:topRelations);

% Plot 6: Feature importance (simulated)
subplot(2, 3, 6);
features = categorical({'Word Embedding', 'Position E1', 'Position E2', 'BiLSTM'});
importance = [0.35, 0.20, 0.20, 0.25];
bar(features, importance, 'FaceColor', [0.8, 0.6, 0.3]);
ylabel('Importance');
title('Feature Contribution (Conceptual)');
ylim([0, 0.5]);
grid on;

sgtitle('Relation Extraction System Analysis', 'FontSize', 14, 'FontWeight', 'bold');

print('relation_extraction_analysis', '-dpng', '-r300');

fprintf('\nRelation extraction demonstration complete!\n');
fprintf('System identifies semantic relationships between entities,\n');
fprintf('enabling knowledge graph construction and information retrieval.\n');
