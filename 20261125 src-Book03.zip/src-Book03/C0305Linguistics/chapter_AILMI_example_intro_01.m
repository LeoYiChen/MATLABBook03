%% chapter_AILMI_example_intro_01.m
% Basic text preprocessing and sentiment analysis in MATLAB.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_intro_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Load sample customer reviews
reviewText = ["This product exceeded my expectations!"; 
              "Terrible quality, would not recommend.";
              "Average product, nothing special.";
              "Absolutely brilliant, highly satisfied!"];

% Create tokenised documents
documents = tokenizedDocument(reviewText);

% Perform preprocessing operations
documents = erasePunctuation(documents);
documents = lower(documents);
documents = removeStopWords(documents);

% Display preprocessed text
disp('Preprocessed Reviews:');
disp(documents);

% Basic word frequency analysis
bag = bagOfWords(documents);
topWords = topkwords(bag, 5);
disp('Most frequent words:');
disp(topWords);
