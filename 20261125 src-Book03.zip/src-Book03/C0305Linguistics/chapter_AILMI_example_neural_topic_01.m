%% chapter_AILMI_example_neural_topic_01.m
% Neural topic model using autoencoder architecture for document representation learning with topic interpretation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_neural_topic_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Neural Topic Model - Autoencoder-Based Approach
% Demonstrates deep learning for document topic discovery

fprintf('=== Neural Topic Model with Autoencoder ===\n\n');

% - Step 1: Prepare Document Data -

fprintf('Step 1: Loading document corpus for neural topic modelling...\n');

% Use same corpus as LDA example for comparison
documents = [
    "Artificial intelligence machine learning deep neural networks computer vision applications";
    "Climate change global warming renewable energy carbon emissions environmental";
    "Stock market economic growth interest rates investment financial portfolio";
    "Football soccer sports athletes training competition performance analytics";
    "Genomic sequencing personalised medicine CRISPR gene editing clinical trials";
    "Quantum computing cryptography cloud infrastructure computational resources";
    "Parliamentary elections political parties governmental policies legislative laws";
    "International trade commerce supply chain manufacturing distribution retail";
    "Solar wind renewable energy battery storage electricity grid systems";
    "Spacecraft Mars exploration satellite communications astrophysics research";
    "Digital learning educational platforms pedagogical teaching assessment students";
    "Antibiotic resistance vaccination epidemiology public health infectious disease";
    "Autonomous drones robotics automation sensor networks Internet Things";
    "Cryptocurrency blockchain smart contracts digital payments decentralised finance";
    "Archaeological historical artefacts museum cultural heritage preservation";
    "Natural language processing transformer models chatbot applications";
    "Optical radio telescopes astronomy gravitational waves cosmic phenomena";
    "Urban planning sustainable cities public transportation smart infrastructure";
    "Theatrical film cinematography streaming entertainment media production";
    "Agricultural precision farming GPS vertical farming food security"
];

numDocuments = length(documents);
fprintf('  Documents: %d\n\n', numDocuments);

% - Step 2: Create TF-IDF Feature Representation -

fprintf('Step 2: Constructing TF-IDF document vectors...\n');

% Preprocess documents
tokenizedDocs = tokenizedDocument(documents);
tokenizedDocs = removeStopWords(tokenizedDocs);
tokenizedDocs = removeShortWords(tokenizedDocs, 3);

% Build bag-of-words and compute TF-IDF
bag = bagOfWords(tokenizedDocs);
tfidfMatrix = tfidf(bag);
tfidfMatrix = full(tfidfMatrix);  % Convert to full matrix

[numDocs, vocabSize] = size(tfidfMatrix);
fprintf('  TF-IDF matrix: %d documents x %d features\n', numDocs, vocabSize);
fprintf('  Sparsity: %.2f%%\n\n', 100 * (1 - nnz(tfidfMatrix)/(numDocs*vocabSize)));

% Normalise features (L2 normalisation)
docNorms = sqrt(sum(tfidfMatrix.^2, 2));
tfidfNormalised = tfidfMatrix ./ (docNorms + eps);

% - Step 3: Define Autoencoder Architecture -

fprintf('Step 3: Designing neural autoencoder architecture...\n');

% Architecture parameters
inputDim = vocabSize;
hiddenDim1 = 128;
latentDim = 10;  % Topic dimension
hiddenDim2 = 128;
outputDim = vocabSize;

fprintf('  Architecture: %d -> %d -> %d -> %d -> %d\n', ...
    inputDim, hiddenDim1, latentDim, hiddenDim2, outputDim);
fprintf('  Latent dimensions represent learned topics\n\n');

% Define encoder layers
encoderLayers = [
    featureInputLayer(inputDim, 'Name', 'input')
    
    fullyConnectedLayer(hiddenDim1, 'Name', 'encoder_hidden1')
    reluLayer('Name', 'encoder_relu1')
    dropoutLayer(0.3, 'Name', 'encoder_dropout1')
    
    fullyConnectedLayer(latentDim, 'Name', 'latent_representation')
    tanhLayer('Name', 'latent_activation')
];

% Define decoder layers  
decoderLayers = [
    fullyConnectedLayer(hiddenDim2, 'Name', 'decoder_hidden1')
    reluLayer('Name', 'decoder_relu1')
    dropoutLayer(0.3, 'Name', 'decoder_dropout1')
    
    fullyConnectedLayer(outputDim, 'Name', 'reconstruction')
    sigmoidLayer('Name', 'output_activation')
    
    regressionLayer('Name', 'output')
];

% Combine encoder and decoder
autoencoderLayers = [encoderLayers; decoderLayers];

fprintf('  Total layers: %d\n', length(autoencoderLayers));

% - Step 4: Training Configuration -

fprintf('\nStep 4: Configuring autoencoder training...\n');

options = trainingOptions('adam', ...
    'MaxEpochs', 100, ...
    'MiniBatchSize', 4, ...
    'InitialLearnRate', 0.001, ...
    'LearnRateSchedule', 'piecewise', ...
    'LearnRateDropFactor', 0.5, ...
    'LearnRateDropPeriod', 30, ...
    'Shuffle', 'every-epoch', ...
    'L2Regularization', 0.0001, ...
    'Verbose', false, ...
    'Plots', 'none');

fprintf('  Optimiser: Adam\n');
fprintf('  Learning rate: %.4f (with decay)\n', options.InitialLearnRate);
fprintf('  Epochs: %d\n', options.MaxEpochs);
fprintf('  Batch size: %d\n\n', options.MiniBatchSize);

% - Step 5: Train Autoencoder -

fprintf('Step 5: Training neural autoencoder...\n');

% Prepare training data (input = output for autoencoder)
XTrain = tfidfNormalised';
YTrain = tfidfNormalised';

tic;
autoencoderNet = trainNetwork(XTrain, YTrain, autoencoderLayers, options);
trainingTime = toc;

fprintf('  Training completed in %.2f seconds\n\n', trainingTime);

% - Step 6: Extract Latent Topic Representations -

fprintf('Step 6: Extracting document topic representations...\n');

% Create encoder network (truncate at latent layer)
encoderNet = layerGraph(autoencoderLayers(1:6));  % Up to latent layer
encoderNet = assembleNetwork(encoderNet);

% Get latent representations
latentRepresentations = predict(encoderNet, XTrain);
latentRepresentations = latentRepresentations';

fprintf('  Latent representation matrix: %d x %d\n', ...
    size(latentRepresentations, 1), size(latentRepresentations, 2));

% Normalise to probability-like distributions (softmax)
latentSoftmax = exp(latentRepresentations);
latentSoftmax = latentSoftmax ./ sum(latentSoftmax, 2);

fprintf('  Converted to topic probability distributions\n\n');

% - Step 7: Interpret Neural Topics -

fprintf('Step 7: Interpreting learned neural topics...\n');

% Extract decoder weights to find top words per topic
decoderWeights = autoencoderNet.Layers(end-3).Weights;  % First decoder FC layer
topicWordWeights = decoderWeights';  % Transpose: topics x words

% Find top words for each latent dimension
numTopWords = 10;
topNeuralTopicWords = cell(latentDim, numTopWords);

fprintf('\n  Top %d words per neural topic:\n\n', numTopWords);
for topicIdx = 1:latentDim
    [sortedWeights, sortIdx] = sort(topicWordWeights(topicIdx, :), 'descend');
    
    topWordIndices = sortIdx(1:numTopWords);
    topNeuralTopicWords(topicIdx, :) = bag.Vocabulary(topWordIndices);
    
    fprintf('  Neural Topic %d:\n    ', topicIdx);
    fprintf('%s\n\n', strjoin(topNeuralTopicWords(topicIdx, :), ', '));
end

% - Step 8: Evaluate Reconstruction Quality -

fprintf('Step 8: Evaluating autoencoder reconstruction quality...\n');

% Reconstruct documents
reconstructed = predict(autoencoderNet, XTrain);
reconstructed = reconstructed';

% Calculate reconstruction errors
reconErrors = sqrt(sum((tfidfNormalised - reconstructed).^2, 2));
meanReconError = mean(reconErrors);
medianReconError = median(reconErrors);

fprintf('  Mean reconstruction error: %.6f\n', meanReconError);
fprintf('  Median reconstruction error: %.6f\n', medianReconError);

% Calculate correlation between original and reconstructed
correlations = zeros(numDocs, 1);
for docIdx = 1:numDocs
    correlations(docIdx) = corr(tfidfNormalised(docIdx, :)', ...
        reconstructed(docIdx, :)');
end

fprintf('  Average reconstruction correlation: %.4f\n\n', mean(correlations));

% - Step 9: Topic Coherence in Neural Topics -

fprintf('Step 9: Estimating neural topic coherence...\n');

% Simplified coherence based on word co-occurrence
neuralCoherence = zeros(latentDim, 1);

for topicIdx = 1:latentDim
    topWords = topNeuralTopicWords(topicIdx, 1:8);
    
    pmiSum = 0;
    pairCount = 0;
    
    for i = 1:length(topWords)-1
        for j = i+1:length(topWords)
            word1 = topWords{i};
            word2 = topWords{j};
            
            if ismember(word1, bag.Vocabulary) && ismember(word2, bag.Vocabulary)
                idx1 = find(strcmp(bag.Vocabulary, word1));
                idx2 = find(strcmp(bag.Vocabulary, word2));
                
                docsWith1 = sum(bag.Counts(:, idx1) > 0);
                docsWith2 = sum(bag.Counts(:, idx2) > 0);
                docsWithBoth = sum((bag.Counts(:, idx1) > 0) & ...
                    (bag.Counts(:, idx2) > 0));
                
                if docsWithBoth > 0
                    pmi = log((docsWithBoth * numDocs) / ...
                        (docsWith1 * docsWith2) + 1e-10);
                    pmiSum = pmiSum + pmi;
                    pairCount = pairCount + 1;
                end
            end
        end
    end
    
    if pairCount > 0
        neuralCoherence(topicIdx) = pmiSum / pairCount;
    end
end

fprintf('  Neural topic coherence scores:\n');
for topicIdx = 1:latentDim
    fprintf('    Neural Topic %d: %.4f\n', topicIdx, neuralCoherence(topicIdx));
end
fprintf('  Average neural coherence: %.4f\n\n', mean(neuralCoherence));

% - Step 10: Visualisation -

fprintf('Step 10: Generating neural topic model visualisations...\n');

figure('Position', [100, 100, 1800, 1200]);

% Plot 1: Latent topic distribution heatmap
subplot(3, 4, 1);
imagesc(latentSoftmax);
colorbar;
colormap(flipud(gray));
xlabel('Neural Topic');
ylabel('Document');
title('Document-Topic Distributions (Neural)');
set(gca, 'XTick', 1:latentDim);

% Plot 2: Topic activation patterns
subplot(3, 4, 2);
avgTopicActivation = mean(latentSoftmax, 1);
bar(1:latentDim, avgTopicActivation, 'FaceColor', [0.3, 0.7, 0.5]);
xlabel('Neural Topic');
ylabel('Average Activation');
title('Average Topic Prevalence');
grid on;
set(gca, 'XTick', 1:latentDim);

% Plot 3: Reconstruction error distribution
subplot(3, 4, 3);
histogram(reconErrors, 15, 'FaceColor', [0.6, 0.4, 0.8]);
xlabel('Reconstruction Error (L2)');
ylabel('Frequency');
title('Document Reconstruction Error');
grid on;

% Plot 4: Original vs Reconstructed correlation
subplot(3, 4, 4);
scatter(1:numDocs, correlations, 50, 'filled', 'MarkerFaceColor', [0.8, 0.5, 0.3]);
xlabel('Document Index');
ylabel('Correlation');
title('Original-Reconstructed Correlation');
ylim([0, 1]);
grid on;
hold on;
plot([1, numDocs], [mean(correlations), mean(correlations)], 'r-', 'LineWidth', 2);
hold off;
legend('Documents', 'Mean', 'Location', 'best');

% Plot 5-7: Neural topic word clouds (top 3 topics)
for plotIdx = 1:min(3, latentDim)
    subplot(3, 4, 4 + plotIdx);
    
    % Create word-weight pairs for word cloud
    topWords = topNeuralTopicWords(plotIdx, :);
    [~, wordIndices] = ismember(topWords, bag.Vocabulary);
    wordWeights = topicWordWeights(plotIdx, wordIndices);
    wordWeights = wordWeights / max(wordWeights);  % Normalise
    
    % Generate word cloud
    wordcloud(topWords, wordWeights);
    title(sprintf('Neural Topic %d', plotIdx), 'FontSize', 11);
end

% Plot 8: Neural topic coherence comparison
subplot(3, 4, 8);
bar(1:latentDim, neuralCoherence, 'FaceColor', [0.4, 0.6, 0.9]);
xlabel('Neural Topic');
ylabel('Coherence Score');
title('Neural Topic Coherence');
grid on;
set(gca, 'XTick', 1:latentDim);

% Plot 9: Latent space PCA visualisation
subplot(3, 4, 9);
if latentDim >= 2
    [coeff, score, ~] = pca(latentRepresentations);
    scatter(score(:, 1), score(:, 2), 100, 1:numDocs, 'filled');
    xlabel('PC1');
    ylabel('PC2');
    title('Document Embeddings (PCA Projection)');
    colorbar;
    grid on;
end

% Plot 10: Topic correlation matrix
subplot(3, 4, 10);
topicCorrelation = corr(latentSoftmax);
imagesc(topicCorrelation);
colorbar;
colormap(gca, redblue);
xlabel('Neural Topic');
ylabel('Neural Topic');
title('Inter-Topic Correlation Matrix');
set(gca, 'XTick', 1:latentDim, 'YTick', 1:latentDim);

% Plot 11: Latent dimension variance
subplot(3, 4, 11);
latentVariance = var(latentRepresentations, 0, 1);
bar(1:latentDim, latentVariance, 'FaceColor', [0.7, 0.4, 0.5]);
xlabel('Latent Dimension');
ylabel('Variance');
title('Latent Dimension Variance');
grid on;
set(gca, 'XTick', 1:latentDim);

% Plot 12: Training loss curve (simulated)
subplot(3, 4, 12);
epochs = 1:options.MaxEpochs;
simulatedLoss = 0.5 * exp(-epochs/25) + 0.05 + 0.01 * randn(size(epochs));
plot(epochs, simulatedLoss, 'b-', 'LineWidth', 2);
xlabel('Epoch');
ylabel('Reconstruction Loss');
title('Training Loss Curve (Simulated)');
grid on;

sgtitle('Neural Topic Model - Autoencoder Analysis', 'FontSize', 14, ...
    'FontWeight', 'bold');

print('neural_topic_model_analysis', '-dpng', '-r300');

fprintf('\nNeural topic modelling complete!\n');
fprintf('Learned %d latent topic dimensions with %.4f average coherence\n', ...
    latentDim, mean(neuralCoherence));
fprintf('Autoencoder achieves %.4f average reconstruction correlation.\n', ...
    mean(correlations));

% Helper function for red-blue colormap
function cmap = redblue(m)
    if nargin < 1
        m = 64;
    end
    bottom = [0, 0, 1];
    middle = [1, 1, 1];
    top = [1, 0, 0];
    
    n = ceil(m/2);
    r = [linspace(bottom(1), middle(1), n), linspace(middle(1), top(1), n)];
    g = [linspace(bottom(2), middle(2), n), linspace(middle(2), top(2), n)];
    b = [linspace(bottom(3), middle(3), n), linspace(middle(3), top(3), n)];
    
    cmap = [r', g', b'];
    cmap = cmap(1:m, :);
end
