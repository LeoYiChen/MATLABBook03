%% chapter_AILMI_example_Recommendation_01.m
% Content-based recommendation system using TF-IDF similarity with user profiling and diversity enhancement.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_Recommendation_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Content-Based Recommendation System
% Recommends articles based on user reading history and content similarity

fprintf('=== Content-Based Recommendation System ===\n\n');

% - Step 1: Create Article Database -

fprintf('Step 1: Building article content database...\n');

% Article titles and content (simplified for demonstration)
articleTitles = [
    "Machine Learning Advances Transform Healthcare";
    "Climate Change Impacts on Global Agriculture";
    "Quantum Computing Breakthrough Announced";
    "Economic Outlook: Markets Face Uncertainty";
    "Artificial Intelligence in Education Technology";
    "Renewable Energy Investment Reaches Record High";
    "Space Exploration: Mars Mission Progress Update";
    "Healthcare AI Improves Diagnostic Accuracy";
    "Financial Markets Rally on Policy News";
    "Educational Technology Adoption Accelerates";
    "Climate Models Predict Temperature Rise";
    "Quantum Algorithms Solve Optimisation Problems";
    "Investment Strategies for Volatile Markets";
    "Machine Learning Enables Precision Medicine";
    "Agricultural Innovation Boosts Food Security"
];

% Article content (keyword-rich summaries)
articleContent = [
    "machine learning algorithms healthcare patient diagnosis treatment " + ...
    "medical data analysis predictive models clinical outcomes";
    
    "climate change global warming agriculture crop yields temperature " + ...
    "precipitation patterns farming adaptation strategies";
    
    "quantum computing qubits superposition entanglement algorithms " + ...
    "processing power breakthrough technology advancement";
    
    "economic markets financial investment uncertainty volatility " + ...
    "growth inflation monetary policy outlook";
    
    "artificial intelligence education learning technology students " + ...
    "personalised adaptive teaching methods AI tutoring";
    
    "renewable energy solar wind investment sustainability " + ...
    "clean power carbon emissions reduction climate";
    
    "space exploration Mars mission NASA rover astronaut " + ...
    "planetary science discovery spacecraft launch";
    
    "healthcare diagnosis AI medical imaging accuracy patient " + ...
    "treatment decision support clinical systems";
    
    "financial markets rally stocks investment trading policy " + ...
    "economic growth bull market performance";
    
    "education technology adoption digital learning online " + ...
    "students schools EdTech platforms pandemic";
    
    "climate models temperature prediction warming emissions " + ...
    "global environmental change impact scenarios";
    
    "quantum algorithms optimisation computation problem solving " + ...
    "processing classical computers advantage applications";
    
    "investment strategies portfolio diversification markets volatile " + ...
    "risk management financial planning assets";
    
    "machine learning precision medicine genomics personalised " + ...
    "treatment healthcare patient outcomes data";
    
    "agriculture innovation food security farming technology " + ...
    "crops productivity sustainable practices global"
];

numArticles = length(articleTitles);

fprintf('  Created database with %d articles\n', numArticles);
fprintf('  Sample article: "%s"\n\n', articleTitles(1));

% - Step 2: Feature Extraction using TF-IDF -

fprintf('Step 2: Extracting content features with TF-IDF...\n');

% Tokenise and preprocess
documents = tokenizedDocument(articleContent);
documents = removeStopWords(erasePunctuation(lower(documents)));

% Create bag-of-words model
bag = bagOfWords(documents);

fprintf('  Vocabulary size: %d unique terms\n', bag.NumWords);

% Compute TF-IDF features
tfidfMatrix = tfidf(bag);
tfidfMatrix = full(tfidfMatrix);  % Convert to full matrix

fprintf('  TF-IDF feature matrix: %d articles x %d features\n', ...
    size(tfidfMatrix, 1), size(tfidfMatrix, 2));
fprintf('\n');

% - Step 3: Simulate User Reading History -

fprintf('Step 3: Creating user reading history...\n');

% Define multiple users with different interests
numUsers = 5;
userHistories = cell(numUsers, 1);

% User 1: Interested in AI/ML and healthcare
userHistories{1} = [1, 5, 8, 14];  % Articles about AI, ML, healthcare

% User 2: Interested in climate and environment
userHistories{2} = [2, 6, 11];  % Articles about climate, energy

% User 3: Interested in finance and economics
userHistories{3} = [4, 9, 13];  % Articles about markets, investment

% User 4: Interested in quantum computing and technology
userHistories{4} = [3, 12];  % Articles about quantum computing

% User 5: Diverse interests (education, space, agriculture)
userHistories{5} = [7, 10, 15];  % Articles about space, education, agriculture

fprintf('  Created %d user profiles with reading histories\n', numUsers);
for userIdx = 1:numUsers
    fprintf('    User %d: read %d articles\n', userIdx, ...
        length(userHistories{userIdx}));
end
fprintf('\n');

% - Step 4: Build User Profiles -

fprintf('Step 4: Building user preference profiles...\n');

% For each user, create profile as average of read articles' features
userProfiles = zeros(numUsers, size(tfidfMatrix, 2));

for userIdx = 1:numUsers
    readArticles = userHistories{userIdx};
    
    % Average TF-IDF vectors of read articles
    userProfiles(userIdx, :) = mean(tfidfMatrix(readArticles, :), 1);
end

fprintf('  User profiles constructed (%d users x %d features)\n', ...
    size(userProfiles, 1), size(userProfiles, 2));
fprintf('\n');

% - Step 5: Generate Recommendations -

fprintf('Step 5: Generating personalised recommendations...\n');

% Number of recommendations per user
numRecommendations = 5;

% Store recommendations for all users
allRecommendations = cell(numUsers, 1);

for userIdx = 1:numUsers
    readArticles = userHistories{userIdx};
    
    % Calculate cosine similarity between user profile and all articles
    userProfile = userProfiles(userIdx, :);
    
    similarities = zeros(numArticles, 1);
    for articleIdx = 1:numArticles
        articleFeatures = tfidfMatrix(articleIdx, :);
        
        % Cosine similarity
        dotProduct = sum(userProfile .* articleFeatures);
        normProduct = norm(userProfile) * norm(articleFeatures);
        
        if normProduct > 0
            similarities(articleIdx) = dotProduct / normProduct;
        else
            similarities(articleIdx) = 0;
        end
    end
    
    % Exclude already-read articles
    similarities(readArticles) = -Inf;
    
    % Sort by similarity and get top-N
    [sortedSim, sortedIdx] = sort(similarities, 'descend');
    recommendations = sortedIdx(1:numRecommendations);
    recommendationScores = sortedSim(1:numRecommendations);
    
    % Store results
    allRecommendations{userIdx} = struct(...
        'articles', recommendations, ...
        'scores', recommendationScores);
    
    % Display recommendations
    fprintf('  User %d recommendations:\n', userIdx);
    for recIdx = 1:numRecommendations
        articleIdx = recommendations(recIdx);
        score = recommendationScores(recIdx);
        fprintf('    %d. %s (similarity: %.3f)\n', recIdx, ...
            articleTitles(articleIdx), score);
    end
    fprintf('\n');
end

% - Step 6: Recommendation Diversity Analysis -

fprintf('Step 6: Analysing recommendation diversity...\n');

% For each user, calculate diversity of recommendations
diversityScores = zeros(numUsers, 1);

for userIdx = 1:numUsers
    recommendations = allRecommendations{userIdx}.articles;
    
    % Calculate pairwise similarities between recommended articles
    numRecs = length(recommendations);
    pairwiseSims = zeros(numRecs * (numRecs - 1) / 2, 1);
    pairIdx = 1;
    
    for i = 1:numRecs
        for j = i+1:numRecs
            article1 = tfidfMatrix(recommendations(i), :);
            article2 = tfidfMatrix(recommendations(j), :);
            
            % Cosine similarity
            dotProd = sum(article1 .* article2);
            normProd = norm(article1) * norm(article2);
            
            if normProd > 0
                pairwiseSims(pairIdx) = dotProd / normProd;
            end
            
            pairIdx = pairIdx + 1;
        end
    end
    
    % Diversity = 1 - average pairwise similarity
    diversityScores(userIdx) = 1 - mean(pairwiseSims);
end

fprintf('  Recommendation diversity scores:\n');
for userIdx = 1:numUsers
    fprintf('    User %d: %.3f (higher = more diverse)\n', ...
        userIdx, diversityScores(userIdx));
end
fprintf('\n');

% - Step 7: Coverage Analysis -

fprintf('Step 7: Computing recommendation coverage...\n');

% Coverage = percentage of catalogue recommended to at least one user
recommendedArticles = [];
for userIdx = 1:numUsers
    recommendedArticles = [recommendedArticles; ...
        allRecommendations{userIdx}.articles];
end
uniqueRecommended = unique(recommendedArticles);

catalogueCoverage = length(uniqueRecommended) / numArticles;

fprintf('  Catalogue coverage: %.1f%% (%d/%d articles recommended)\n', ...
    catalogueCoverage * 100, length(uniqueRecommended), numArticles);
fprintf('\n');

% - Step 8: Similarity Heatmap -

fprintf('Step 8: Computing article similarity matrix...\n');

% Calculate full article-article similarity matrix
articleSimMatrix = zeros(numArticles, numArticles);

for i = 1:numArticles
    for j = i:numArticles
        if i == j
            articleSimMatrix(i, j) = 1;
        else
            article1 = tfidfMatrix(i, :);
            article2 = tfidfMatrix(j, :);
            
            dotProd = sum(article1 .* article2);
            normProd = norm(article1) * norm(article2);
            
            if normProd > 0
                sim = dotProd / normProd;
                articleSimMatrix(i, j) = sim;
                articleSimMatrix(j, i) = sim;
            end
        end
    end
end

fprintf('  Computed %d x %d article similarity matrix\n', ...
    numArticles, numArticles);
fprintf('  Average inter-article similarity: %.3f\n\n', ...
    mean(articleSimMatrix(articleSimMatrix < 1)));

% - Step 9: Visualisation -

fprintf('Step 9: Generating visualisation...\n');

figure('Position', [100, 100, 1600, 1000]);

% Plot 1: User profile comparison (PCA projection)
subplot(2, 3, 1);
[coeff, score] = pca(userProfiles);
scatter(score(:, 1), score(:, 2), 150, 1:numUsers, 'filled');
xlabel('First Principal Component');
ylabel('Second Principal Component');
title('User Preference Profiles (PCA Projection)');
colormap(jet);
colorbar('Ticks', 1:numUsers, 'TickLabels', ...
    arrayfun(@(x) sprintf('User %d', x), 1:numUsers, 'UniformOutput', false));
grid on;
for userIdx = 1:numUsers
    text(score(userIdx, 1), score(userIdx, 2), sprintf('  U%d', userIdx), ...
        'FontSize', 10, 'FontWeight', 'bold');
end

% Plot 2: Article similarity heatmap
subplot(2, 3, 2);
imagesc(articleSimMatrix);
colorbar;
colormap(gca, hot);
xlabel('Article Index');
ylabel('Article Index');
title('Article Similarity Matrix');

% Plot 3: Recommendation scores distribution
subplot(2, 3, 3);
allScores = [];
for userIdx = 1:numUsers
    allScores = [allScores; allRecommendations{userIdx}.scores];
end
histogram(allScores, 20, 'Normalization', 'probability', ...
    'FaceColor', [0.3, 0.6, 0.9]);
xlabel('Similarity Score');
ylabel('Probability');
title('Recommendation Score Distribution');
grid on;

% Plot 4: User reading history sizes
subplot(2, 3, 4);
histSizes = cellfun(@length, userHistories);
bar(histSizes, 'FaceColor', [0.6, 0.4, 0.8]);
xlabel('User ID');
ylabel('Number of Read Articles');
title('User Reading History Sizes');
grid on;

% Plot 5: Recommendation diversity
subplot(2, 3, 5);
bar(diversityScores, 'FaceColor', [0.5, 0.7, 0.5]);
xlabel('User ID');
ylabel('Diversity Score');
title('Recommendation Diversity by User');
ylim([0, 1]);
grid on;

% Plot 6: Top recommended articles (frequency)
subplot(2, 3, 6);
[uniqueArticles, ~, idx] = unique(recommendedArticles);
articleCounts = histcounts(idx, 1:length(uniqueArticles)+1);
[sortedCounts, sortIdx] = sort(articleCounts, 'descend');
topArticles = uniqueArticles(sortIdx(1:min(10, length(uniqueArticles))));
bar(sortedCounts(1:min(10, length(sortedCounts))), ...
    'FaceColor', [0.8, 0.5, 0.3]);
xlabel('Article Rank');
ylabel('Recommendation Frequency');
title('Most Frequently Recommended Articles');
grid on;

sgtitle('Content-Based Recommendation System Analysis', ...
    'FontSize', 14, 'FontWeight', 'bold');

print('content_recommendation_analysis', '-dpng', '-r300');

fprintf('\nRecommendation system complete!\n');
fprintf('Generated personalised recommendations for %d users\n', numUsers);
fprintf('Average diversity score: %.3f\n', mean(diversityScores));
fprintf('Catalogue coverage: %.1f%%\n', catalogueCoverage * 100);
