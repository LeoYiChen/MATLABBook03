%% chapter_AILMI_example_BiasDetection_01.m
% Bias detection and mitigation framework for sentiment classification with fairness-aware evaluation and data augmentation strategies.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_BiasDetection_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Algorithmic Bias Detection and Mitigation System
% Demonstrates fairness evaluation and bias reduction techniques

fprintf('=== Algorithmic Bias Detection and Mitigation System ===\n\n');

% - Step 1: Generate Biased Dataset -

fprintf('Step 1: Creating synthetic biased sentiment dataset...\n');

% Simulate dataset with demographic bias
% Group A: Majority group (standard dialect)
% Group B: Minority group (non-standard dialect)

numSamplesPerGroup = 500;

% Group A samples (standard dialect, balanced sentiment)
groupA_positive = [
    "This product is excellent and works perfectly";
    "I absolutely love the quality and service";
    "Outstanding performance exceeded expectations";
    "Highly recommend this wonderful experience";
    "Fantastic results very satisfied customer"
];

groupA_negative = [
    "This product is terrible and disappointing";
    "I hate the poor quality and service";
    "Awful performance failed to meet expectations";
    "Do not recommend this horrible experience";
    "Terrible results very dissatisfied customer"
];

% Group B samples (non-standard dialect, biased labelling)
% These samples contain dialectal features that are systematically
% mislabelled as negative due to biased training data
groupB_positive = [
    "This thing be fire and working real good";
    "I be loving the quality they got going";
    "Mad decent performance better than expected";
    "Y'all should check this sick experience";
    "Crazy good results I be happy customer"
];

groupB_negative = [
    "This thing be trash and disappointing bad";
    "I be hating the wack quality they got";
    "Terrible performance ain't meeting expectations";
    "Don't be getting this awful experience";
    "Bad results I be unhappy customer"
];

% Generate complete dataset
allTexts = [];
allLabels = [];
allGroups = [];

% Add Group A samples
for sampleIdx = 1:numSamplesPerGroup
    % Positive samples
    templateIdx = randi(length(groupA_positive));
    allTexts = [allTexts; groupA_positive(templateIdx)];
    allLabels = [allLabels; "positive"];
    allGroups = [allGroups; "GroupA"];
    
    % Negative samples
    templateIdx = randi(length(groupA_negative));
    allTexts = [allTexts; groupA_negative(templateIdx)];
    allLabels = [allLabels; "negative"];
    allGroups = [allGroups; "GroupA"];
end

% Add Group B samples with systematic bias
% Introduce 30% label noise for Group B to simulate biased annotations
biasRate = 0.3;

for sampleIdx = 1:numSamplesPerGroup
    % Positive samples (some mislabelled as negative due to bias)
    templateIdx = randi(length(groupB_positive));
    allTexts = [allTexts; groupB_positive(templateIdx)];
    
    if rand() < biasRate
        allLabels = [allLabels; "negative"];  % Biased mislabelling
    else
        allLabels = [allLabels; "positive"];  % Correct label
    end
    allGroups = [allGroups; "GroupB"];
    
    % Negative samples
    templateIdx = randi(length(groupB_negative));
    allTexts = [allTexts; groupB_negative(templateIdx)];
    allLabels = [allLabels; "negative"];
    allGroups = [allGroups; "GroupB"];
end

numTotalSamples = length(allTexts);

fprintf('  Generated %d samples\n', numTotalSamples);
fprintf('    Group A (majority): %d samples\n', sum(allGroups == "GroupA"));
fprintf('    Group B (minority): %d samples\n', sum(allGroups == "GroupB"));
fprintf('    Introduced %.0f%% label bias for Group B\n\n', biasRate*100);

% - Step 2: Extract Features and Train Baseline Model -

fprintf('Step 2: Training baseline sentiment classifier...\n');

% Tokenise and preprocess
documents = tokenizedDocument(allTexts);
documents = removeStopWords(erasePunctuation(lower(documents)));

% Create bag-of-words
bag = bagOfWords(documents);

% Extract TF-IDF features
tfidfFeatures = tfidf(bag);
tfidfFeatures = full(tfidfFeatures);

% Split into train and test
rng(42);
trainRatio = 0.8;
numTrain = round(numTotalSamples * trainRatio);
trainIdx = randperm(numTotalSamples, numTrain);
testIdx = setdiff(1:numTotalSamples, trainIdx);

XTrain = tfidfFeatures(trainIdx, :);
YTrain = allLabels(trainIdx);
GroupTrain = allGroups(trainIdx);

XTest = tfidfFeatures(testIdx, :);
YTest = allLabels(testIdx);
GroupTest = allGroups(testIdx);

% Train baseline classifier
baselineClassifier = fitcsvm(XTrain, YTrain);

fprintf('  Baseline classifier trained\n\n');

% - Step 3: Evaluate Baseline Performance by Group -

fprintf('Step 3: Evaluating baseline model for bias...\n');

% Predictions on test set
baselinePredictions = predict(baselineClassifier, XTest);

% Overall accuracy
overallAccuracy = sum(baselinePredictions == YTest) / length(YTest);
fprintf('  Overall accuracy: %.2f%%\n\n', overallAccuracy * 100);

% Group-disaggregated performance
groupATestIdx = find(GroupTest == "GroupA");
groupBTestIdx = find(GroupTest == "GroupB");

groupAAccuracy = sum(baselinePredictions(groupATestIdx) == ...
    YTest(groupATestIdx)) / length(groupATestIdx);
groupBAccuracy = sum(baselinePredictions(groupBTestIdx) == ...
    YTest(groupBTestIdx)) / length(groupBTestIdx);

fprintf('  Group-specific performance:\n');
fprintf('    Group A accuracy: %.2f%%\n', groupAAccuracy * 100);
fprintf('    Group B accuracy: %.2f%%\n', groupBAccuracy * 100);
fprintf('    Accuracy gap: %.2f%%\n\n', ...
    abs(groupAAccuracy - groupBAccuracy) * 100);

% Calculate false positive rates by group
groupA_FPR = sum(baselinePredictions(groupATestIdx) == "positive" & ...
    YTest(groupATestIdx) == "negative") / ...
    sum(YTest(groupATestIdx) == "negative");

groupB_FPR = sum(baselinePredictions(groupBTestIdx) == "positive" & ...
    YTest(groupBTestIdx) == "negative") / ...
    sum(YTest(groupBTestIdx) == "negative");

fprintf('  False Positive Rates:\n');
fprintf('    Group A FPR: %.2f%%\n', groupA_FPR * 100);
fprintf('    Group B FPR: %.2f%%\n', groupB_FPR * 100);
fprintf('    FPR disparity: %.2f%%\n\n', abs(groupA_FPR - groupB_FPR) * 100);

% - Step 4: Implement Data Augmentation for Debiasing -

fprintf('Step 4: Applying data augmentation for bias mitigation...\n');

% Oversample Group B to balance representation
groupBTrainIdx = find(GroupTrain == "GroupB");
groupATrainSize = sum(GroupTrain == "GroupA");
groupBTrainSize = length(groupBTrainIdx);

oversampleFactor = ceil(groupATrainSize / groupBTrainSize);

% Replicate Group B samples
augmentedTrainIdx = trainIdx;
for repeatIdx = 1:oversampleFactor-1
    augmentedTrainIdx = [augmentedTrainIdx; trainIdx(groupBTrainIdx)];
end

XTrainAug = tfidfFeatures(augmentedTrainIdx, :);
YTrainAug = allLabels(augmentedTrainIdx);
GroupTrainAug = allGroups(augmentedTrainIdx);

fprintf('  Data augmentation applied:\n');
fprintf('    Original training size: %d\n', length(trainIdx));
fprintf('    Augmented training size: %d\n', length(augmentedTrainIdx));
fprintf('    Group B oversample factor: %dx\n\n', oversampleFactor);

% Train debiased classifier
debiasedClassifier = fitcsvm(XTrainAug, YTrainAug);

fprintf('  Debiased classifier trained\n\n');

% - Step 5: Evaluate Debiased Model -

fprintf('Step 5: Evaluating debiased model performance...\n');

% Predictions from debiased model
debiasedPredictions = predict(debiasedClassifier, XTest);

% Overall accuracy
debiasedAccuracy = sum(debiasedPredictions == YTest) / length(YTest);
fprintf('  Overall accuracy: %.2f%%\n', debiasedAccuracy * 100);
fprintf('  Change from baseline: %+.2f%%\n\n', ...
    (debiasedAccuracy - overallAccuracy) * 100);

% Group-specific performance
groupAAccuracyDeb = sum(debiasedPredictions(groupATestIdx) == ...
    YTest(groupATestIdx)) / length(groupATestIdx);
groupBAccuracyDeb = sum(debiasedPredictions(groupBTestIdx) == ...
    YTest(groupBTestIdx)) / length(groupBTestIdx);

fprintf('  Group-specific performance:\n');
fprintf('    Group A accuracy: %.2f%% (baseline: %.2f%%)\n', ...
    groupAAccuracyDeb * 100, groupAAccuracy * 100);
fprintf('    Group B accuracy: %.2f%% (baseline: %.2f%%)\n', ...
    groupBAccuracyDeb * 100, groupBAccuracy * 100);
fprintf('    Accuracy gap: %.2f%% (baseline: %.2f%%)\n\n', ...
    abs(groupAAccuracyDeb - groupBAccuracyDeb) * 100, ...
    abs(groupAAccuracy - groupBAccuracy) * 100);

% False positive rates
groupA_FPR_Deb = sum(debiasedPredictions(groupATestIdx) == "positive" & ...
    YTest(groupATestIdx) == "negative") / ...
    sum(YTest(groupATestIdx) == "negative");

groupB_FPR_Deb = sum(debiasedPredictions(groupBTestIdx) == "positive" & ...
    YTest(groupBTestIdx) == "negative") / ...
    sum(YTest(groupBTestIdx) == "negative");

fprintf('  False Positive Rates:\n');
fprintf('    Group A FPR: %.2f%% (baseline: %.2f%%)\n', ...
    groupA_FPR_Deb * 100, groupA_FPR * 100);
fprintf('    Group B FPR: %.2f%% (baseline: %.2f%%)\n', ...
    groupB_FPR_Deb * 100, groupB_FPR * 100);
fprintf('    FPR disparity: %.2f%% (baseline: %.2f%%)\n\n', ...
    abs(groupA_FPR_Deb - groupB_FPR_Deb) * 100, ...
    abs(groupA_FPR - groupB_FPR) * 100);

% - Step 6: Fairness Metrics Computation -

fprintf('Step 6: Computing comprehensive fairness metrics...\n');

% Demographic Parity: P(Y_hat = positive | Group = A) vs P(Y_hat = positive | Group = B)
demParity_Baseline = abs(sum(baselinePredictions(groupATestIdx) == "positive") / ...
    length(groupATestIdx) - ...
    sum(baselinePredictions(groupBTestIdx) == "positive") / ...
    length(groupBTestIdx));

demParity_Debiased = abs(sum(debiasedPredictions(groupATestIdx) == "positive") / ...
    length(groupATestIdx) - ...
    sum(debiasedPredictions(groupBTestIdx) == "positive") / ...
    length(groupBTestIdx));

fprintf('  Demographic Parity Difference:\n');
fprintf('    Baseline: %.4f\n', demParity_Baseline);
fprintf('    Debiased: %.4f\n', demParity_Debiased);
fprintf('    Improvement: %.4f\n\n', demParity_Baseline - demParity_Debiased);

% Equalised Odds: TPR and FPR should be equal across groups
% True Positive Rate
groupA_TPR = sum(baselinePredictions(groupATestIdx) == "positive" & ...
    YTest(groupATestIdx) == "positive") / ...
    sum(YTest(groupATestIdx) == "positive");

groupB_TPR = sum(baselinePredictions(groupBTestIdx) == "positive" & ...
    YTest(groupBTestIdx) == "positive") / ...
    sum(YTest(groupBTestIdx) == "positive");

groupA_TPR_Deb = sum(debiasedPredictions(groupATestIdx) == "positive" & ...
    YTest(groupATestIdx) == "positive") / ...
    sum(YTest(groupATestIdx) == "positive");

groupB_TPR_Deb = sum(debiasedPredictions(groupBTestIdx) == "positive" & ...
    YTest(groupBTestIdx) == "positive") / ...
    sum(YTest(groupBTestIdx) == "positive");

fprintf('  True Positive Rate Parity:\n');
fprintf('    Baseline TPR gap: %.4f\n', abs(groupA_TPR - groupB_TPR));
fprintf('    Debiased TPR gap: %.4f\n\n', abs(groupA_TPR_Deb - groupB_TPR_Deb));

% - Step 7: Visualisation -

fprintf('Step 7: Generating bias analysis visualisations...\n');

figure('Position', [100, 100, 1600, 1000]);

% Plot 1: Accuracy by group (baseline vs debiased)
subplot(2, 3, 1);
groupNames = {'Group A', 'Group B'};
accuracies = [groupAAccuracy, groupBAccuracy; ...
              groupAAccuracyDeb, groupBAccuracyDeb];
bar(accuracies');
set(gca, 'XTickLabel', groupNames);
ylabel('Accuracy');
title('Classification Accuracy by Demographic Group');
legend('Baseline', 'Debiased', 'Location', 'best');
grid on;
ylim([0, 1]);

% Plot 2: False positive rates
subplot(2, 3, 2);
fprData = [groupA_FPR, groupB_FPR; ...
           groupA_FPR_Deb, groupB_FPR_Deb];
bar(fprData');
set(gca, 'XTickLabel', groupNames);
ylabel('False Positive Rate');
title('False Positive Rates by Group');
legend('Baseline', 'Debiased', 'Location', 'best');
grid on;

% Plot 3: Fairness metrics comparison
subplot(2, 3, 3);
fairnessMetrics = [demParity_Baseline, demParity_Debiased; ...
                   abs(groupA_FPR - groupB_FPR), ...
                   abs(groupA_FPR_Deb - groupB_FPR_Deb); ...
                   abs(groupA_TPR - groupB_TPR), ...
                   abs(groupA_TPR_Deb - groupB_TPR_Deb)];
bar(fairnessMetrics);
set(gca, 'XTickLabel', {'Demographic Parity', 'FPR Parity', 'TPR Parity'}, ...
    'XTickLabelRotation', 45);
ylabel('Disparity (lower is fairer)');
title('Fairness Metrics: Baseline vs Debiased');
legend('Baseline', 'Debiased', 'Location', 'best');
grid on;

% Plot 4: Confusion matrices by group (baseline)
subplot(2, 3, 4);
confMatA_Base = confusionmat(YTest(groupATestIdx), ...
    baselinePredictions(groupATestIdx), 'Order', ["negative", "positive"]);
confMatA_Norm = confMatA_Base ./ sum(confMatA_Base, 2);
imagesc(confMatA_Norm);
colorbar;
colormap(gca, hot);
title('Baseline: Group A Confusion Matrix');
xlabel('Predicted');
ylabel('True');
set(gca, 'XTick', [1, 2], 'XTickLabel', {'Neg', 'Pos'}, ...
    'YTick', [1, 2], 'YTickLabel', {'Neg', 'Pos'});

% Plot 5: Group B baseline confusion matrix
subplot(2, 3, 5);
confMatB_Base = confusionmat(YTest(groupBTestIdx), ...
    baselinePredictions(groupBTestIdx), 'Order', ["negative", "positive"]);
confMatB_Norm = confMatB_Base ./ sum(confMatB_Base, 2);
imagesc(confMatB_Norm);
colorbar;
colormap(gca, hot);
title('Baseline: Group B Confusion Matrix');
xlabel('Predicted');
ylabel('True');
set(gca, 'XTick', [1, 2], 'XTickLabel', {'Neg', 'Pos'}, ...
    'YTick', [1, 2], 'YTickLabel', {'Neg', 'Pos'});

% Plot 6: Training data distribution
subplot(2, 3, 6);
trainDist = [sum(GroupTrain == "GroupA"), sum(GroupTrainAug == "GroupA"); ...
             sum(GroupTrain == "GroupB"), sum(GroupTrainAug == "GroupB")];
bar(trainDist');
set(gca, 'XTickLabel', groupNames);
ylabel('Number of Training Samples');
title('Training Data Distribution');
legend('Original', 'Augmented', 'Location', 'best');
grid on;

sgtitle('Algorithmic Bias Detection and Mitigation Analysis', ...
    'FontSize', 14, 'FontWeight', 'bold');

print('bias_mitigation_analysis', '-dpng', '-r300');

fprintf('\nBias mitigation analysis complete!\n');
fprintf('Accuracy gap reduced from %.2f%% to %.2f%%\n', ...
    abs(groupAAccuracy - groupBAccuracy) * 100, ...
    abs(groupAAccuracyDeb - groupBAccuracyDeb) * 100);
fprintf('Demographic parity improved from %.4f to %.4f\n', ...
    demParity_Baseline, demParity_Debiased);
