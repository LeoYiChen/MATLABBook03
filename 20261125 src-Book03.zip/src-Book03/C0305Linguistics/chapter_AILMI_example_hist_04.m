%% chapter_AILMI_example_hist_04.m
% Simplified attention mechanism implementation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_hist_04
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Example usage: Attend over sequence of word embeddings
rng(42);  % For reproducibility
d = 8;    % Embedding dimension
n = 5;    % Sequence length

% Simulate word embeddings for a sequence
wordEmbeddings = randn(n, d);

% Query is the current position we're attending from
queryPosition = 3;
query = wordEmbeddings(queryPosition, :);

% Keys and values are all positions in sequence
keys = wordEmbeddings;
values = wordEmbeddings;

% Compute attention
[output, weights] = attentionMechanism(query, keys, values);

% Visualise attention weights
fprintf('Attention weights from position %d:\n', queryPosition);
for i = 1:n
    fprintf('  Position %d: %.4f', i, weights(i));
    if i == queryPosition
        fprintf(' (self)');
    end
    fprintf('\n');
end

% Plot attention distribution
figure;
bar(1:n, weights);
xlabel('Sequence Position');
ylabel('Attention Weight');
title(sprintf('Attention Distribution from Position %d', ...
              queryPosition));
ylim([0, max(weights)*1.2]);
grid on;

% Local functions (moved to end so this listing is a valid MATLAB script)
function [output, attentionWeights] = attentionMechanism(...
    query, keys, values)
    % Simplified attention: Attention(Q,K,V) = softmax(QK'/sqrt(d))*V
    %
    % Inputs:
    %   query: Query vector (1 x d)
    %   keys: Key vectors (n x d)
    %   values: Value vectors (n x d_v)
    %
    % Outputs:
    %   output: Weighted sum of values (1 x d_v)
    %   attentionWeights: Attention distribution (1 x n)
    
    % Get dimension for scaling
    d_k = size(keys, 2);
    
    % Calculate attention scores: Q * K^T
    scores = query * keys' / sqrt(d_k);
    
    % Apply softmax to get attention weights
    attentionWeights = softmax(scores, 2);
    
    % Calculate weighted sum of values
    output = attentionWeights * values;
end
