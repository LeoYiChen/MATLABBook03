%% chapter_AILMI_example_lstm_01.m
% LSTM network architecture for sentiment classification, demonstrating sequence processing and classification layer composition.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_lstm_01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Define LSTM network for sentiment analysis
% Architecture processes sequences of word embeddings to predict sentiment

% Network hyperparameters
inputDimension = 100;      % Word embedding dimension (e.g., FastText)
numHiddenUnits = 128;      % LSTM hidden state dimensionality
numClasses = 3;            % Sentiment classes: Positive, Negative, Neutral
maxSequenceLength = 50;    % Maximum document length (tokens)

% Construct network architecture using layer composition
% Sequential specification enables intuitive pipeline definition
layers = [
    sequenceInputLayer(inputDimension, ...
                      'Name', 'input_sequences', ...
                      'Normalization', 'zscore')
    
    lstmLayer(numHiddenUnits, ...
             'OutputMode', 'last', ...
             'Name', 'lstm_layer')
    
    dropoutLayer(0.3, 'Name', 'dropout_regularisation')
    
    fullyConnectedLayer(numClasses, 'Name', 'fully_connected')
    
    softmaxLayer('Name', 'softmax_probabilities')
    
    classificationLayer('Name', 'classification_output')
];

fprintf('=== LSTM Sentiment Classification Architecture ===\n\n');

% Analyse network structure
analyseNetwork = layerGraph(layers);
fprintf('Network comprises %d layers:\n', numel(layers));
for layerIdx = 1:numel(layers)
    fprintf('  Layer %d: %s (%s)\n', layerIdx, ...
            layers(layerIdx).Name, class(layers(layerIdx)));
end

% Configure training options with best practices
% Adam optimiser combines momentum with adaptive learning rates
% Gradient clipping prevents exploding gradients in recurrent networks
options = trainingOptions('adam', ...
    'MaxEpochs', 25, ...
    'MiniBatchSize', 32, ...
    'InitialLearnRate', 0.001, ...
    'LearnRateSchedule', 'piecewise', ...
    'LearnRateDropFactor', 0.5, ...
    'LearnRateDropPeriod', 10, ...
    'GradientThreshold', 1, ...
    'Shuffle', 'every-epoch', ...
    'ValidationFrequency', 30, ...
    'Verbose', false, ...
    'Plots', 'training-progress');

fprintf('\n- Training Configuration -\n');
fprintf('Optimiser: %s\n', options.Solveroptimiser);
fprintf('Initial learning rate: %.4f\n', options.InitialLearnRate);
fprintf('Gradient threshold: %.1f\n', options.GradientThreshold);
fprintf('Mini-batch size: %d\n', options.MiniBatchSize);

% Training would proceed as follows (requires actual labelled data):
% trainedNetwork = trainNetwork(XTrain, YTrain, layers, options);
% predictions = classify(trainedNetwork, XTest);
% accuracy = sum(predictions == YTest) / numel(YTest);

fprintf('\n=== Network Defined Successfully ===\n');
fprintf('To train: trainNetwork(XSequences, YLabels, layers, options)\n');
fprintf('XSequences: Cell array of [inputDim × seqLength] matrices\n');
fprintf('YLabels: Categorical vector of sentiment labels\n');
