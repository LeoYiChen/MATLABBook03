%% chapter_AILMI_example_generation_02.m
% Controlled text generation with attribute conditioning.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_generation_02
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Controlled Text Generation with Attribute Conditioning
% Demonstrates conditional language modelling with sentiment/topic control

fprintf('=== Controlled Text Generation ===\n\n');

% - Step 1: Prepare Attributed Training Data -

fprintf('Step 1: Creating attributed training corpus...\n');

% Texts with sentiment labels (positive/negative)
positiveTexts = [
    "I love this wonderful product"
    "The service was excellent and amazing"
    "This experience exceeded all expectations"
    "Absolutely fantastic and delightful"
    "Highly recommend this great solution"
    "Outstanding quality and performance"
    "Truly impressive and remarkable"
    "Best decision I ever made"
];

negativeTexts = [
    "This product is terrible and disappointing"
    "The service was poor and inadequate"
    "Very unsatisfied with this experience"
    "Absolutely horrible and frustrating"
    "Would not recommend at all"
    "Waste of time and money"
    "Completely unacceptable quality"
    "Worst purchase I ever made"
];

% Combine datasets
allTexts = [positiveTexts; negativeTexts];
numTexts = length(allTexts);

% Create labels (1 = positive, 2 = negative)
sentimentLabels = [ones(length(positiveTexts), 1); 
                   2 * ones(length(negativeTexts), 1)];

fprintf('  Total training texts: %d\n', numTexts);
fprintf('  Positive samples: %d\n', length(positiveTexts));
fprintf('  Negative samples: %d\n\n', length(negativeTexts));

% - Step 2: Build Vocabulary -

fprintf('Step 2: Building vocabulary from attributed text...\n');

allWords = [];
for i = 1:numTexts
    text = lower(allTexts{i});
    words = split(text);
    words = words(strlength(words) > 0);
    allWords = [allWords; words];
end

% Add special tokens
vocabulary = unique(['<PAD>'; '<START>'; '<END>'; allWords]);
vocabSize = length(vocabulary);
word2idx = containers.Map(vocabulary, 1:vocabSize);
idx2word = containers.Map(1:vocabSize, vocabulary);

fprintf('  Vocabulary size: %d words\n\n', vocabSize);

% - Step 3: Encode Sequences with Attributes -

fprintf('Step 3: Encoding sequences with sentiment attributes...\n');

maxSeqLength = 0;
for i = 1:numTexts
    text = lower(allTexts{i});
    words = split(text);
    words = words(strlength(words) > 0);
    if length(words) > maxSeqLength
        maxSeqLength = length(words);
    end
end

% Prepare input sequences (words + sentiment embedding)
inputSequences = cell(numTexts, 1);
targetSequences = cell(numTexts, 1);
attributeInputs = zeros(numTexts, 1);

padIdx = word2idx('<PAD>');
startIdx = word2idx('<START>');
endIdx = word2idx('<END>');

for i = 1:numTexts
    text = lower(allTexts{i});
    words = split(text);
    words = words(strlength(words) > 0);
    
    % Convert to indices
    wordIndices = zeros(length(words), 1);
    for j = 1:length(words)
        if isKey(word2idx, words{j})
            wordIndices(j) = word2idx(words{j});
        else
            wordIndices(j) = padIdx;
        end
    end
    
    % Input: <START> + words
    inputSequences{i} = [startIdx; wordIndices];
    
    % Target: words + <END>
    targetSequences{i} = categorical([wordIndices; endIdx]);
    
    % Attribute: sentiment label
    attributeInputs(i) = sentimentLabels(i);
end

fprintf('  Encoded %d sequences\n', numTexts);
fprintf('  Maximum sequence length: %d\n\n', maxSeqLength);

% - Step 4: Create Conditional Model Architecture -

fprintf('Step 4: Constructing conditional language model...\n');

embeddingDim = 32;
numHiddenUnits = 64;
numSentiments = 2;  % Positive, Negative

% Note: In MATLAB, implementing true conditional generation
% requires custom training loops. This demonstrates the concept.

% Simplified architecture combining word input and sentiment
fprintf('  Conditional model components:\n');
fprintf('    - Word embedding dimension: %d\n', embeddingDim);
fprintf('    - Sentiment embedding dimension: %d\n', numSentiments);
fprintf('    - LSTM hidden units: %d\n', numHiddenUnits);
fprintf('    - Output vocabulary size: %d\n\n', vocabSize);

% Conceptual architecture (full implementation needs custom loop):
% 1. Word embedding layer
% 2. Sentiment embedding (one-hot or learnt)
% 3. Concatenate word + sentiment embeddings
% 4. LSTM processing
% 5. Output layer

% - Step 5: Demonstrate Attribute-Based Filtering -

fprintf('Step 5: Demonstrating attribute-based text selection...\n');

% Show samples by sentiment
fprintf('  Positive sentiment samples:\n');
for i = 1:3
    fprintf('    "%s"\n', positiveTexts{i});
end

fprintf('\n  Negative sentiment samples:\n');
for i = 1:3
    fprintf('    "%s"\n', negativeTexts{i});
end

% - Step 6: Simulate Controlled Generation -

fprintf('\nStep 6: Simulating controlled generation process...\n');

% In actual implementation, would:
% 1. Input desired attribute (e.g., sentiment = positive)
% 2. Concatenate attribute embedding with word embeddings
% 3. Generate text autoregressively
% 4. Sample from conditional distribution P(w_t | w_<t, attribute)

desiredSentiment = 'positive';
seedWord = 'The';

fprintf('  Desired sentiment: %s\n', desiredSentiment);
fprintf('  Seed word: "%s"\n', seedWord);
fprintf('  Generated text would be steered toward %s sentiment\n', ...
    desiredSentiment);

% Demonstrate vocabulary filtering by sentiment
fprintf('\n  High-frequency words by sentiment:\n');

% Count words in positive texts
positiveWordCounts = containers.Map('KeyType', 'char', 'ValueType', 'double');
for i = 1:length(positiveTexts)
    text = lower(positiveTexts{i});
    words = split(text);
    for j = 1:length(words)
        word = char(words{j});
        if strlength(word) > 2  % Skip short words
            if isKey(positiveWordCounts, word)
                positiveWordCounts(word) = positiveWordCounts(word) + 1;
            else
                positiveWordCounts(word) = 1;
            end
        end
    end
end

% Count words in negative texts
negativeWordCounts = containers.Map('KeyType', 'char', 'ValueType', 'double');
for i = 1:length(negativeTexts)
    text = lower(negativeTexts{i});
    words = split(text);
    for j = 1:length(words)
        word = char(words{j});
        if strlength(word) > 2
            if isKey(negativeWordCounts, word)
                negativeWordCounts(word) = negativeWordCounts(word) + 1;
            else
                negativeWordCounts(word) = 1;
            end
        end
    end
end

fprintf('\n  Positive indicators: %s\n', ...
    strjoin(keys(positiveWordCounts), ', '));
fprintf('  Negative indicators: %s\n', ...
    strjoin(keys(negativeWordCounts), ', '));

% - Step 7: Attribute Control Strength -

fprintf('\nStep 7: Demonstrating attribute control strength...\n');

% In PPLM-style approaches, control strength parameter
% determines how strongly to enforce attribute
controlStrengths = [0.1, 0.5, 1.0, 2.0];

fprintf('  Control strength effects:\n');
for i = 1:length(controlStrengths)
    strength = controlStrengths(i);
    fprintf('    Strength %.1f: ', strength);
    
    if strength < 0.5
        fprintf('Weak control, high fluency\n');
    elseif strength < 1.5
        fprintf('Moderate control, balanced\n');
    else
        fprintf('Strong control, potential fluency degradation\n');
    end
end

% - Step 8: Visualisation -

fprintf('\nStep 8: Visualising controlled generation properties...\n');

figure('Position', [100, 100, 1400, 900]);

% Plot 1: Sentiment distribution
subplot(2, 3, 1);
sentimentCounts = [length(positiveTexts), length(negativeTexts)];
bar(categorical({'Positive', 'Negative'}), sentimentCounts, ...
    'FaceColor', [0.3, 0.7, 0.4]);
ylabel('Count');
title('Sentiment Distribution in Training Data');
grid on;

% Plot 2: Text length by sentiment
subplot(2, 3, 2);
positiveLengths = cellfun(@(x) length(split(x)), positiveTexts);
negativeLengths = cellfun(@(x) length(split(x)), negativeTexts);

hold on;
histogram(positiveLengths, 'BinWidth', 1, 'FaceColor', [0.3, 0.8, 0.3], ...
    'DisplayName', 'Positive');
histogram(negativeLengths, 'BinWidth', 1, 'FaceColor', [0.8, 0.3, 0.3], ...
    'DisplayName', 'Negative');
hold off;
xlabel('Text Length (words)');
ylabel('Frequency');
title('Text Length Distribution by Sentiment');
legend('Location', 'best');
grid on;

% Plot 3: Vocabulary overlap
subplot(2, 3, 3);
posWords = keys(positiveWordCounts);
negWords = keys(negativeWordCounts);
sharedWords = intersect(posWords, negWords);

categories = categorical({'Positive Only', 'Shared', 'Negative Only'});
counts = [length(posWords) - length(sharedWords), length(sharedWords), ...
          length(negWords) - length(sharedWords)];
bar(categories, counts, 'FaceColor', [0.6, 0.4, 0.8]);
ylabel('Unique Words');
title('Vocabulary Overlap Between Sentiments');
grid on;

% Plot 4: Control strength vs fluency (conceptual)
subplot(2, 3, 4);
controlX = 0:0.1:2;
fluency = exp(-0.5 * (controlX - 0.5).^2);  % Simulated
attributeMatch = 1 - exp(-1.5 * controlX);  % Simulated

plot(controlX, fluency, 'b-', 'LineWidth', 2, 'DisplayName', 'Fluency');
hold on;
plot(controlX, attributeMatch, 'r-', 'LineWidth', 2, ...
    'DisplayName', 'Attribute Match');
hold off;
xlabel('Control Strength');
ylabel('Score');
title('Control Strength Trade-off (Conceptual)');
legend('Location', 'best');
grid on;

% Plot 5: Word frequency comparison
subplot(2, 3, 5);

% Get top words from each sentiment
if ~isempty(keys(positiveWordCounts))
    posWordsList = keys(positiveWordCounts);
    posCountsList = cell2mat(values(positiveWordCounts, posWordsList));
    [~, sortIdx] = sort(posCountsList, 'descend');
    topPosWords = posWordsList(sortIdx(1:min(5, length(sortIdx))));
    topPosCounts = posCountsList(sortIdx(1:min(5, length(sortIdx))));
else
    topPosWords = {};
    topPosCounts = [];
end

if ~isempty(keys(negativeWordCounts))
    negWordsList = keys(negativeWordCounts);
    negCountsList = cell2mat(values(negativeWordCounts, negWordsList));
    [~, sortIdx] = sort(negCountsList, 'descend');
    topNegWords = negWordsList(sortIdx(1:min(5, length(sortIdx))));
    topNegCounts = negCountsList(sortIdx(1:min(5, length(sortIdx))));
else
    topNegWords = {};
    topNegCounts = [];
end

if ~isempty(topPosWords) && ~isempty(topNegWords)
    maxWords = max(length(topPosWords), length(topNegWords));
    yPos = (1:length(topPosWords)) * 2;
    yNeg = (1:length(topNegWords)) * 2 + 0.8;
    
    barh(yPos, topPosCounts, 'FaceColor', [0.3, 0.8, 0.3], ...
        'DisplayName', 'Positive');
    hold on;
    barh(yNeg, topNegCounts, 'FaceColor', [0.8, 0.3, 0.3], ...
        'DisplayName', 'Negative');
    hold off;
    
    xlabel('Frequency');
    title('Top Words by Sentiment');
    legend('Location', 'best');
    grid on;
end

% Plot 6: Attribute embedding space (conceptual 2*D projection)
subplot(2, 3, 6);

% Simulate 2*D embeddings for positive/negative
numSamples = 50;
rng(42);
posEmbeddings = [randn(numSamples, 1) + 1, randn(numSamples, 1) + 1];
negEmbeddings = [randn(numSamples, 1) - 1, randn(numSamples, 1) - 1];

scatter(posEmbeddings(:, 1), posEmbeddings(:, 2), 60, 'g', 'filled', ...
    'DisplayName', 'Positive');
hold on;
scatter(negEmbeddings(:, 1), negEmbeddings(:, 2), 60, 'r', 'filled', ...
    'DisplayName', 'Negative');
hold off;
xlabel('Dimension 1');
ylabel('Dimension 2');
title('Attribute Embedding Space (Conceptual)');
legend('Location', 'best');
grid on;

sgtitle('Controlled Text Generation with Attribute Conditioning', ...
    'FontSize', 14, 'FontWeight', 'bold');

print('controlled_generation_analysis', '-dpng', '-r300');

fprintf('\nControlled generation demonstration complete!\n');
fprintf('Attributes enable steering generated text properties.\n');
