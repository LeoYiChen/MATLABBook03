%% chapter_AILMI_example_intro_04.m
% Text data visualisation using dimensionality reduction.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0305Linguistics/
% Listing label         : chapter_AILMI_example_intro_04
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Sample documents from different topics
techDocs = ["Machine learning advances artificial intelligence";
            "Neural networks process complex data patterns";
            "Algorithm optimisation improves performance"];

sportsDocs = ["Football team wins championship match";
              "Athletes break records in Olympic games";
              "Basketball tournament draws massive crowds"];

% Combine and label documents
allDocs = [techDocs; sportsDocs];
labels = categorical([ones(3,1); 2*ones(3,1)], [1 2], ...
                    {'Technology', 'Sports'});

% Preprocess
documents = removeStopWords(erasePunctuation(...
           lower(tokenizedDocument(allDocs))));

% Extract TF-IDF features
bag = bagOfWords(documents);
tfidfMatrix = tfidf(bag);

% Apply PCA for dimensionality reduction to 2*D
[coeff, score] = pca(tfidfMatrix);

% Visualise document clustering
figure;
gscatter(score(:,1), score(:,2), labels, 'rb', 'ox', 10);
xlabel('First Principal Component');
ylabel('Second Principal Component');
title('Document Clustering Visualisation');
legend('Location', 'best');
grid on;
