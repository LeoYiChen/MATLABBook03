%% chapter_AI_ICT_neural_evolution.m
% Evolution of Neural Networks in Communication Systems
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0303ICT/
% Listing label         : chapter_AI_ICT_neural_evolution
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [performance_history, network_evolution] = neuralEvolutionDemo(communication_data, evolution_params)
% Demonstrates the historical evolution of neural network approaches
% in communication systems, from perceptrons to deep learning

num_eras = length(evolution_params.eras);
performance_history = struct();
network_evolution = struct();

for era = 1:num_eras
era_name = evolution_params.eras{era}.name;
era_config = evolution_params.eras{era}.config;

 
fprintf('Simulating %s era (%s)\n', era_name, era_config.period);

switch era_name
    case 'perceptron_era'
        % Single-layer perceptron (1950*s-1960*s)
        [performance, network] = simulatePerceptronEra(communication_data, era_config);
        
    case 'ai_winter'
        % Limited neural network research (1970*s-1980*s)
        [performance, network] = simulateAIWinter(communication_data, era_config);
        
    case 'backprop_renaissance'
        % Multi-layer networks with backpropagation (1980*s-1990*s)
        [performance, network] = simulateBackpropEra(communication_data, era_config);
        
    case 'deep_learning_revolution'
        % Deep networks with modern training techniques (2000*s-present)
        [performance, network] = simulateDeepLearningEra(communication_data, era_config);
        
    otherwise
        error('Unknown era: %s', era_name);
end

performance_history.*(era_name) = performance;
network_evolution.*(era_name) = network;

% Display era-specific insights
displayEraInsights(era_name, performance, era_config);
end

% Generate comparative analysis across eras
comparative_analysis = generateComparativeAnalysis(performance_history);
network_evolution.comparative_analysis = comparative_analysis;
end

function [performance, network] = simulatePerceptronEra(data, config)
% Simulate single-layer perceptron performance (1950*s-1960*s approach)
fprintf(' Implementing Rosenblatt-style perceptron learning...\n');

% Simple linear classification for signal detection
X = data.received_signals;
y = data.signal_present; % Binary classification

% Single-layer perceptron with perceptron learning rule
weights = randn(size(X, 1), 1) * 0.01;
bias = 0;
learning_rate = config.learning_rate;

performance.training_accuracy = zeros(config.max_epochs, 1);
performance.training_loss = zeros(config.max_epochs, 1);

for epoch = 1:config.max_epochs
epoch_errors = 0;
 
for sample = 1:size(X, 2)
    % Forward pass
    net_input = weights' * X(:, sample) + bias;
    output = double(net_input > 0); % Step activation function
    
    % Perceptron learning rule (only for misclassified samples)
    error = y(sample) - output;
    if error ~= 0
        weights = weights + learning_rate * error * X(:, sample);
        bias = bias + learning_rate * error;
        epoch_errors = epoch_errors + 1;
    end
end

% Evaluate performance
predictions = double((weights' * X + bias) > 0);
performance.training_accuracy(epoch) = mean(predictions == y);
performance.training_loss(epoch) = epoch_errors / size(X, 2);

% Early stopping if no errors (linearly separable case)
if epoch_errors == 0
    fprintf('  Perceptron converged at epoch %d\n', epoch);
    break;
end
end

network.weights = weights;
network.bias = bias;
network.architecture = 'single_layer_perceptron';
network.historical_note = 'Rosenblatt Mark I Perceptron style (1960)';
end

function [performance, network] = simulateAIWinter(data, config)
% Simulate AI winter period with limited neural network research
fprintf(' Simulating AI winter period - limited progress...\n');

% Simple linear methods dominated this era
X = data.received_signals;
y = data.transmitted_symbols;

% Linear least squares estimation (dominant approach during AI winter)
weights = (X * X') \ (X * y');

% Evaluate performance
predictions = weights' * X;
mse = mean((y - predictions).^2);

performance.mse = mse;
performance.historical_context = 'AI winter period (1970*s-1980*s)';
performance.dominant_methods = {'Linear estimation', 'Classical signal processing'};

network.weights = weights;
network.architecture = 'linear_regression';
network.historical_note = 'Neural networks largely abandoned during this period';
end

function [performance, network] = simulateBackpropEra(data, config)
% Simulate backpropagation era (1980*s-1990*s)
fprintf(' Implementing multi-layer network with backpropagation...\n');

X = data.received_signals;
y = data.transmitted_symbols;

% Multi-layer perceptron architecture
input_size = size(X, 1);
hidden_size = config.hidden_units;
output_size = size(y, 1);

% Initialize weights (Xavier initialization wasn't invented yet)
W1 = randn(hidden_size, input_size) * 0.1;
b1 = zeros(hidden_size, 1);
W2 = randn(output_size, hidden_size) * 0.1;
b2 = zeros(output_size, 1);

learning_rate = config.learning_rate;
num_samples = size(X, 2);

performance.training_loss = zeros(config.max_epochs, 1);

for epoch = 1:config.max_epochs
epoch_loss = 0;

 
for sample = 1:num_samples
    % Forward pass
    z1 = W1 * X(:, sample) + b1;
    a1 = tanh(z1); % Tanh was popular in this era
    z2 = W2 * a1 + b2;
    a2 = z2; % Linear output
    
    % Compute loss (mean squared error)
    loss = 0.5 * sum((y(:, sample) - a2).^2);
    epoch_loss = epoch_loss + loss;
    
    % Backward pass (backpropagation)
    dL_da2 = -(y(:, sample) - a2);
    dL_dz2 = dL_da2;
    dL_dW2 = dL_dz2 * a1';
    dL_db2 = dL_dz2;
    
    dL_da1 = W2' * dL_dz2;
    dL_dz1 = dL_da1 .* (1 - a1.^2); % Derivative of tanh
    dL_dW1 = dL_dz1 * X(:, sample)';
    dL_db1 = dL_dz1;
    
    % Update weights
    W2 = W2 - learning_rate * dL_dW2;
    b2 = b2 - learning_rate * dL_db2;
    W1 = W1 - learning_rate * dL_dW1;
    b1 = b1 - learning_rate * dL_db1;
end

performance.training_loss(epoch) = epoch_loss / num_samples;

if mod(epoch, 100) == 0
    fprintf('  Epoch %d: Loss = %.6f\n', epoch, performance.training_loss(epoch));
end
end

network.W1 = W1; network.b1 = b1;
network.W2 = W2; network.b2 = b2;
network.architecture = 'multi_layer_perceptron';
network.historical_note = 'Backpropagation renaissance (1986 Rumelhart, Hinton, Williams)';
end

function [performance, network] = simulateDeepLearningEra(data, config)
% Simulate modern deep learning approaches (2000*s-present)
fprintf(' Implementing deep learning with modern techniques...\n');

X = data.received_signals;
y = data.transmitted_symbols;

% Deep network architecture with modern techniques
input_size = size(X, 1);
hidden_sizes = config.hidden_layers;
output_size = size(y, 1);

% Modern techniques: He initialization, batch normalization concepts, etc.
layers = cell(length(hidden_sizes) + 1, 1);

% Input layer
prev_size = input_size;
for i = 1:length(hidden_sizes)
% He initialization for ReLU networks
layers{i}.W = randn(hidden_sizes(i), prev_size) * sqrt(2/prev_size);
layers{i}.b = zeros(hidden_sizes(i), 1);
prev_size = hidden_sizes(i);
end

% Output layer
layers{end}.W = randn(output_size, prev_size) * sqrt(2/prev_size);
layers{end}.b = zeros(output_size, 1);

% Modern optimization: Adam-like adaptive learning rates
learning_rate = config.learning_rate;
beta1 = 0.9; beta2 = 0.999; epsilon = 1e-8;

% Initialize momentum terms for Adam optimizer
for i = 1:length(layers)
layers{i}.m_W = zeros(size(layers{i}.W));
layers{i}.v_W = zeros(size(layers{i}.W));
layers{i}.m_b = zeros(size(layers{i}.b));
layers{i}.v_b = zeros(size(layers{i}.b));
end

performance.training_loss = zeros(config.max_epochs, 1);
batch_size = min(32, size(X, 2)); % Mini-batch processing

for epoch = 1:config.max_epochs
epoch_loss = 0;
num_batches = ceil(size(X, 2) / batch_size);
 
% Shuffle data (modern practice)
perm = randperm(size(X, 2));
X_shuffled = X(:, perm);
y_shuffled = y(:, perm);

for batch = 1:num_batches
    batch_start = (batch-1) * batch_size + 1;
    batch_end = min(batch * batch_size, size(X, 2));
    
    X_batch = X_shuffled(:, batch_start:batch_end);
    y_batch = y_shuffled(:, batch_start:batch_end);
    
    % Forward pass with ReLU activations
    activations = cell(length(layers), 1);
    current_input = X_batch;
    
    for i = 1:length(layers)-1
        z = layers{i}.W * current_input + layers{i}.b;
        activations{i} = max(0, z); % ReLU activation
        current_input = activations{i};
    end
    
    % Output layer (linear)
    z_out = layers{end}.W * current_input + layers{end}.b;
    activations{end} = z_out;
    
    % Compute loss
    batch_loss = 0.5 * sum(sum((y_batch - activations{end}).^2));
    epoch_loss = epoch_loss + batch_loss;
    
    % Backward pass (modern implementation)
    gradients = cell(length(layers), 1);
    
    % Output layer gradients
    dL_da = -(y_batch - activations{end});
    gradients{end}.dW = dL_da * current_input' / size(X_batch, 2);
    gradients{end}.db = mean(dL_da, 2);
    
    % Hidden layer gradients
    dL_da_next = layers{end}.W' * dL_da;
    for i = length(layers)-1:-1:1
        if i > 1
            current_input = activations{i-1};
        else
            current_input = X_batch;
        end
        
        % ReLU derivative
        dL_dz = dL_da_next .* double(activations{i} > 0);
        gradients{i}.dW = dL_dz * current_input' / size(X_batch, 2);
        gradients{i}.db = mean(dL_dz, 2);
        
        if i > 1
            dL_da_next = layers{i}.W' * dL_dz;
        end
    end
    
    % Adam optimizer update
    t = (epoch-1) * num_batches + batch; % Time step
    
    for i = 1:length(layers)
        % Update momentum terms
        layers{i}.m_W = beta1 * layers{i}.m_W + (1-beta1) * gradients{i}.dW;
        layers{i}.v_W = beta2 * layers{i}.v_W + (1-beta2) * gradients{i}.dW.^2;
        layers{i}.m_b = beta1 * layers{i}.m_b + (1-beta1) * gradients{i}.db;
        layers{i}.v_b = beta2 * layers{i}.v_b + (1-beta2) * gradients{i}.db.^2;
        
        % Bias correction
        m_W_corr = layers{i}.m_W / (1 - beta1^t);
        v_W_corr = layers{i}.v_W / (1 - beta2^t);
        m_b_corr = layers{i}.m_b / (1 - beta1^t);
        v_b_corr = layers{i}.v_b / (1 - beta2^t);
        
        % Parameter updates
        layers{i}.W = layers{i}.W - learning_rate * m_W_corr ./ (sqrt(v_W_corr) + epsilon);
        layers{i}.b = layers{i}.b - learning_rate * m_b_corr ./ (sqrt(v_b_corr) + epsilon);
    end
end

performance.training_loss(epoch) = epoch_loss / size(X, 2);

if mod(epoch, 50) == 0
    fprintf('  Epoch %d: Loss = %.6f\n', epoch, performance.training_loss(epoch));
end
end

network.layers = layers;
network.architecture = 'deep_neural_network';
network.historical_note = 'Deep learning revolution (2006 Hinton, 2012 AlexNet breakthrough)';
network.modern_techniques = {'He initialization', 'ReLU activations', 'Adam optimizer', 'Mini-batch training'};
end
