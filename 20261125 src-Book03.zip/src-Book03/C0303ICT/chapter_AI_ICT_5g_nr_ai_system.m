%% chapter_AI_ICT_5g_nr_ai_system.m
% Advanced 5G NR System Implementation with AI-Enhanced Channel Processing
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0303ICT/
% Listing label         : chapter_AI_ICT_5g_nr_ai_system
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [performance_analysis, ai_enhancement_metrics] = advanced5GNRWithAI(simulation_config)
% Advanced 5*G NR system implementation with comprehensive AI enhancements
% Demonstrates standards-compliant implementation with machine learning integration
%
% Inputs:
% simulation_config: comprehensive configuration structure for simulation parameters
% Outputs:
% performance_analysis: detailed performance metrics and analysis
% ai_enhancement_metrics: quantified improvements from AI integration

fprintf('Initialising Advanced 5*G NR System with AI Enhancement...\n');

% Validate MATLAB 5*G Toolbox availability
if ~license('test', '5*G_Toolbox')
error('5*G Toolbox license not available. Please ensure 5*G Toolbox is installed.');
end

% Configure 5*G NR carrier parameters according to 3*GPP specifications
carrier = nrCarrierConfig;
carrier.SubcarrierSpacing = simulation_config.subcarrier_spacing; % 15, 30, 60, 120, 240 kHz
carrier.CyclicPrefix = simulation_config.cyclic_prefix; % 'normal' or 'extended'
carrier.NSizeGrid = simulation_config.num_resource_blocks; % Number of RBs
carrier.NStartGrid = 0; % Starting RB index

% Advanced PDSCH configuration with AI-optimised parameters
pdsch = nrPDSCHConfig;
pdsch.PRBSet = 0:carrier.NSizeGrid-1; % Full bandwidth allocation
pdsch.SymbolAllocation = [0, carrier.SymbolsPerSlot]; % Full slot allocation
pdsch.MCS = simulation_config.modulation_coding_scheme; % Modulation and Coding Scheme
pdsch.NumLayers = simulation_config.num_transmission_layers; % MIMO layers
pdsch.RNTI = simulation_config.radio_network_identifier; % Radio Network Temporary Identifier
pdsch.Modulation = qamdemod([], 2^simulation_config.modulation_order); % QAM constellation

% Configure DMRS for robust channel estimation
dmrs_config = nrPDSCHDMRSConfig;
dmrs_config.DMRSPortSet = 0:pdsch.NumLayers-1;
dmrs_config.DMRSTypeAPosition = simulation_config.dmrs_type_a_position;
dmrs_config.DMRSAdditionalPosition = simulation_config.dmrs_additional_position;
dmrs_config.DMRSLength = simulation_config.dmrs_length;
dmrs_config.NIDNSCID = simulation_config.dmrs_scrambling_id;
dmrs_config.NSCID = 0;

% Advanced channel model configuration
channel_model = nrTDLChannel;
channel_model.DelayProfile = simulation_config.delay_profile; % 'TDL-A', 'TDL-B', 'TDL-C', etc.
channel_model.DelaySpread = simulation_config.rms_delay_spread; % RMS delay spread in seconds
channel_model.MaximumDopplerShift = simulation_config.maximum_doppler; % Hz
channel_model.MIMOCorrelation = simulation_config.mimo_correlation; % 'Low', 'Medium', 'High'
channel_model.TransmissionDirection = 'Downlink';
channel_model.NumTransmitAntennas = pdsch.NumLayers;
channel_model.NumReceiveAntennas = simulation_config.num_receive_antennas;
channel_model.NormalizePathGains = true;
channel_model.NormalizeChannelOutputs = false;

% Configure simulation parameters
snr_range_db = simulation_config.snr_range;
num_simulation_frames = simulation_config.num_frames;
max_errors_per_point = simulation_config.max_errors;

% Initialise comprehensive results structure
performance_analysis = struct();
performance_analysis.snr_values_db = snr_range_db;
performance_analysis.bler_classical = zeros(size(snr_range_db));
performance_analysis.bler_ai_enhanced = zeros(size(snr_range_db));
performance_analysis.throughput_classical = zeros(size(snr_range_db));
performance_analysis.throughput_ai_enhanced = zeros(size(snr_range_db));
performance_analysis.channel_estimation_error = struct();

% Initialise AI enhancement components
fprintf('Training AI-based enhancement modules...\n');
ai_channel_estimator = initialiseAIChannelEstimator(simulation_config);
ai_detector = initialiseAISymbolDetector(simulation_config);
adaptive_scheduler = initialiseAdaptiveScheduler(simulation_config);

% Main simulation loop across SNR range
for snr_idx = 1:length(snr_range_db)
current_snr_db = snr_range_db(snr_idx);
fprintf('Simulating SNR = %d dB...\n', current_snr_db);

 
% Reset performance counters
num_errors_classical = 0;
num_errors_ai_enhanced = 0;
total_bits_classical = 0;
total_bits_ai_enhanced = 0;
frame_count = 0;

% Channel estimation error tracking
channel_est_errors_classical = [];
channel_est_errors_ai = [];

% Reset channel for each SNR point to ensure statistical independence
reset(channel_model);

% Simulation loop for current SNR value
while (num_errors_classical < max_errors_per_point || ...
       num_errors_ai_enhanced < max_errors_per_point) && ...
       frame_count < num_simulation_frames
    
    % Generate transport block with realistic size
    transport_block_size = nrTBS(pdsch.MCS, pdsch.NumLayers, ...
                               length(pdsch.PRBSet), pdsch.SymbolAllocation(2));
    
    % Generate random information bits
    information_bits = randi([0 1], transport_block_size, 1);
    
    % 5*G NR downlink shared channel encoding
    codeword = nrDLSCH(information_bits, pdsch.MCS, pdsch.NumLayers, ...
                      length(pdsch.PRBSet), pdsch.SymbolAllocation(2));
    
    % PDSCH symbol generation with proper modulation
    pdsch_symbols = nrPDSCH(codeword, pdsch.Modulation);
    
    % Generate DMRS symbols for channel estimation
    dmrs_symbols = nrPDSCHDMRS(carrier, pdsch, dmrs_config);
    dmrs_indices = nrPDSCHDMRSIndices(carrier, pdsch, dmrs_config);
    
    % Resource grid allocation and mapping
    tx_resource_grid = nrResourceGrid(carrier, pdsch.NumLayers);
    
    % Map PDSCH symbols to resource grid
    pdsch_indices = nrPDSCHIndices(carrier, pdsch);
    tx_resource_grid(pdsch_indices) = pdsch_symbols;
    
    % Map DMRS symbols to resource grid
    tx_resource_grid(dmrs_indices) = dmrs_symbols;
    
    % OFDM modulation to generate time-domain waveform
    tx_waveform = nrOFDMModulate(carrier, tx_resource_grid);
    
    % Channel propagation with realistic impairments
    [rx_waveform, path_gains, sample_times] = channel_model(tx_waveform);
    
    % Add AWGN with specified SNR
    rx_waveform_noisy = awgn(rx_waveform, current_snr_db, 'measured');
    
    % Perfect timing synchronisation (can be enhanced with AI)
    rx_resource_grid = nrOFDMDemodulate(carrier, rx_waveform_noisy);
    
    % Extract received DMRS for channel estimation
    rx_dmrs_symbols = rx_resource_grid(dmrs_indices);
    
    % Classical channel estimation using least squares
    [channel_estimate_classical, noise_variance_classical] = ...
        nrChannelEstimate(rx_resource_grid, dmrs_indices, dmrs_symbols, ...
                        'CDMLengths', [2 1]);
    
    % AI-enhanced channel estimation
    [channel_estimate_ai, confidence_metric] = ...
        enhanceChannelEstimation(channel_estimate_classical, ...
                               rx_dmrs_symbols, dmrs_symbols, ...
                               ai_channel_estimator, simulation_config);
    
    % Calculate channel estimation errors for analysis
    if ~isempty(path_gains)
        true_channel = getActualChannelResponse(path_gains, sample_times, ...
                                              carrier, pdsch_indices);
        
        error_classical = mean(abs(channel_estimate_classical(pdsch_indices) - ...
                                 true_channel).^2);
        error_ai = mean(abs(channel_estimate_ai(pdsch_indices) - ...
                           true_channel).^2);
        
        channel_est_errors_classical = [channel_est_errors_classical; error_classical];
        channel_est_errors_ai = [channel_est_errors_ai; error_ai];
    end
    
    % Extract received PDSCH symbols
    rx_pdsch_symbols = rx_resource_grid(pdsch_indices);
    
    % Classical MMSE equalisation
    [equalised_symbols_classical, channel_state_info_classical] = ...
        nrEqualizeMMSE(rx_pdsch_symbols, ...
                     channel_estimate_classical(pdsch_indices), ...
                     noise_variance_classical);
    
    % AI-enhanced equalisation
    [equalised_symbols_ai, channel_state_info_ai] = ...
        aiEnhancedEqualisation(rx_pdsch_symbols, ...
                             channel_estimate_ai(pdsch_indices), ...
                             noise_variance_classical, ...
                             ai_detector, simulation_config);
    
    % Soft demodulation to generate LLRs (Classical approach)
    llr_classical = nrPDSCHDecode(equalised_symbols_classical, ...
                                pdsch.Modulation, pdsch.NumLayers, ...
                                noise_variance_classical, ...
                                channel_state_info_classical);
    
    % Soft demodulation with AI enhancement
    llr_ai_enhanced = nrPDSCHDecode(equalised_symbols_ai, ...
                                  pdsch.Modulation, pdsch.NumLayers, ...
                                  noise_variance_classical, ...
                                  channel_state_info_ai);
    
    % Apply AI-based LLR enhancement if configured
    if simulation_config.enable_ai_llr_enhancement
        llr_ai_enhanced = enhanceLLRs(llr_ai_enhanced, ai_detector, ...
                                    simulation_config);
    end
    
    % Channel decoding (Classical)
    [decoded_bits_classical, crc_status_classical] = ...
        nrDLSCHDecode(llr_classical, pdsch.MCS, pdsch.NumLayers, ...
                    length(pdsch.PRBSet), pdsch.SymbolAllocation(2));
    
    % Channel decoding (AI-enhanced)
    [decoded_bits_ai, crc_status_ai] = ...
        nrDLSCHDecode(llr_ai_enhanced, pdsch.MCS, pdsch.NumLayers, ...
                    length(pdsch.PRBSet), pdsch.SymbolAllocation(2));
    
    % Error detection and counting
    if crc_status_classical ~= 0 % CRC failure indicates block error
        num_errors_classical = num_errors_classical + 1;
    end
    
    if crc_status_ai ~= 0
        num_errors_ai_enhanced = num_errors_ai_enhanced + 1;
    end
    
    % Update throughput calculations
    successful_bits_classical = (crc_status_classical == 0) * transport_block_size;
    successful_bits_ai = (crc_status_ai == 0) * transport_block_size;
    
    total_bits_classical = total_bits_classical + successful_bits_classical;
    total_bits_ai_enhanced = total_bits_ai_enhanced + successful_bits_ai;
    
    frame_count = frame_count + 1;
end

% Calculate performance metrics for current SNR
performance_analysis.bler_classical(snr_idx) = num_errors_classical / frame_count;
performance_analysis.bler_ai_enhanced(snr_idx) = num_errors_ai_enhanced / frame_count;

% Calculate normalised throughput
max_possible_bits = frame_count * transport_block_size;
performance_analysis.throughput_classical(snr_idx) = total_bits_classical / max_possible_bits;
performance_analysis.throughput_ai_enhanced(snr_idx) = total_bits_ai_enhanced / max_possible_bits;

% Store channel estimation error statistics
performance_analysis.channel_estimation_error.classical_mean(snr_idx) = ...
    mean(channel_est_errors_classical);
performance_analysis.channel_estimation_error.ai_enhanced_mean(snr_idx) = ...
    mean(channel_est_errors_ai);

fprintf('  Classical BLER: %.4f, AI-Enhanced BLER: %.4f\n', ...
        performance_analysis.bler_classical(snr_idx), ...
        performance_analysis.bler_ai_enhanced(snr_idx));
fprintf('  Classical Throughput: %.3f, AI-Enhanced Throughput: %.3f\n', ...
        performance_analysis.throughput_classical(snr_idx), ...
        performance_analysis.throughput_ai_enhanced(snr_idx));
end

% Calculate comprehensive AI enhancement metrics
ai_enhancement_metrics = calculateAIEnhancementMetrics(performance_analysis, simulation_config);

% Generate visualisation and analysis
generatePerformanceVisualisation(performance_analysis, ai_enhancement_metrics, simulation_config);

fprintf('5*G NR AI-Enhanced System Simulation Completed Successfully.\n');
end

function ai_estimator = initialiseAIChannelEstimator(config)
% Initialise AI-based channel estimator using built-in MATLAB capabilities
% This function creates a simplified AI channel estimator using available tools

fprintf(' Initialising AI Channel Estimator...\n');

% Create a simple neural network for channel estimation enhancement
% Using basic feedforward network architecture
input_features = config.channel_estimator.input_dimension;
hidden_units = config.channel_estimator.hidden_units;
output_features = config.channel_estimator.output_dimension;

% Create network layers using standard MATLAB functions
ai_estimator = struct();
ai_estimator.type = 'feedforward_neural_network';
ai_estimator.input_size = input_features;
ai_estimator.hidden_size = hidden_units;
ai_estimator.output_size = output_features;

% Initialise weights using Xavier initialisation
ai_estimator.weights_input_hidden = randn(hidden_units, input_features) * ...
sqrt(2 / input_features);
ai_estimator.weights_hidden_output = randn(output_features, hidden_units) * ...
sqrt(2 / hidden_units);
ai_estimator.bias_hidden = zeros(hidden_units, 1);
ai_estimator.bias_output = zeros(output_features, 1);

% Training parameters
ai_estimator.learning_rate = config.channel_estimator.learning_rate;
ai_estimator.training_iterations = config.channel_estimator.training_iterations;

% Pre-training with synthetic data (simplified approach)
ai_estimator = pretrainChannelEstimator(ai_estimator, config);

fprintf(' AI Channel Estimator initialised successfully.\n');
end

function ai_detector = initialiseAISymbolDetector(config)
% Initialise AI-based symbol detector for enhanced signal processing

fprintf(' Initialising AI Symbol Detector...\n');

ai_detector = struct();
ai_detector.type = 'maximum_likelihood_enhanced';
ai_detector.constellation_size = config.symbol_detector.constellation_size;
ai_detector.noise_adaptation = config.symbol_detector.adaptive_noise_estimation;

% Create lookup tables for enhanced detection
constellation_points = qammod(0:ai_detector.constellation_size-1, ...
log2(ai_detector.constellation_size));
ai_detector.reference_constellation = constellation_points;

% Adaptive parameters
ai_detector.adaptation_factor = config.symbol_detector.adaptation_factor;
ai_detector.decision_threshold = config.symbol_detector.decision_threshold;

fprintf(' AI Symbol Detector initialised successfully.\n');
end

function scheduler = initialiseAdaptiveScheduler(config)
% Initialise adaptive scheduling algorithm for resource allocation

fprintf(' Initialising Adaptive Scheduler...\n');

scheduler = struct();
scheduler.type = 'proportional_fair_enhanced';
scheduler.adaptation_window = config.scheduler.adaptation_window;
scheduler.fairness_factor = config.scheduler.fairness_factor;
scheduler.qos_weights = config.scheduler.qos_weights;

% Initialise scheduling metrics
scheduler.average_throughput = [];
scheduler.instantaneous_rates = [];
scheduler.scheduling_decisions = [];

fprintf(' Adaptive Scheduler initialised successfully.\n');
end

function [enhanced_estimate, confidence] = enhanceChannelEstimation(classical_estimate, rx_dmrs, tx_dmrs, ai_estimator, config)
% Enhance classical channel estimation using AI techniques

% Apply temporal and spatial filtering for enhancement
enhanced_estimate = classical_estimate;

% Simple enhancement using statistical processing
if config.enable_temporal_smoothing
% Apply temporal smoothing filter
smoothing_factor = config.temporal_smoothing_factor;
if isfield(ai_estimator, 'previous_estimate')
enhanced_estimate = smoothing_factor * enhanced_estimate + ...
(1 - smoothing_factor) * ai_estimator.previous_estimate;
end
ai_estimator.previous_estimate = enhanced_estimate;
end

% Calculate confidence metric based on estimation consistency
if ~isempty(rx_dmrs) && ~isempty(tx_dmrs)
estimation_error = rx_dmrs - tx_dmrs .* classical_estimate(1:length(rx_dmrs));
confidence = exp(-mean(abs(estimation_error).^2));
else
confidence = 1.0;
end

% Apply noise reduction based on confidence
if confidence < config.confidence_threshold
enhanced_estimate = enhanced_estimate * config.low_confidence_factor;
end
end

function [enhanced_symbols, enhanced_csi] = aiEnhancedEqualisation(rx_symbols, channel_estimate, noise_variance, ai_detector, config)
% AI-enhanced equalisation combining MMSE with machine learning

% Standard MMSE equalisation as baseline
channel_magnitude_squared = abs(channel_estimate).^2;
mmse_weights = conj(channel_estimate) ./ (channel_magnitude_squared + noise_variance);
enhanced_symbols = mmse_weights .* rx_symbols;

% Apply AI-based post-processing for enhancement
if config.enable_ai_post_processing
% Iterative refinement using AI detector feedback
for iteration = 1:config.ai_iterations
% Soft decision feedback
soft_decisions = enhanced_symbols ./ abs(enhanced_symbols);
 
    % Apply adaptive correction
    correction_factor = ai_detector.adaptation_factor;
    enhanced_symbols = enhanced_symbols + correction_factor * ...
                     (soft_decisions - enhanced_symbols) .* ...
                     (abs(enhanced_symbols) > ai_detector.decision_threshold);
end
end

% Enhanced channel state information
enhanced_csi = channel_magnitude_squared ./ (channel_magnitude_squared + noise_variance);

% Apply CSI enhancement based on AI detector confidence
if isfield(ai_detector, 'confidence_metric')
enhanced_csi = enhanced_csi * ai_detector.confidence_metric;
end
end

function enhanced_llrs = enhanceLLRs(original_llrs, ai_detector, config)
% Enhance Log-Likelihood Ratios using AI-based post-processing

enhanced_llrs = original_llrs;

% Apply confidence-based scaling
confidence_scaling = config.llr_confidence_scaling;
enhanced_llrs = enhanced_llrs * confidence_scaling;

% Adaptive clipping to prevent saturation
max_llr_magnitude = config.max_llr_magnitude;
enhanced_llrs = max(-max_llr_magnitude, min(max_llr_magnitude, enhanced_llrs));

% Apply noise-adaptive enhancement
if isfield(ai_detector, 'noise_adaptation') && ai_detector.noise_adaptation
noise_factor = config.noise_adaptation_factor;
enhanced_llrs = enhanced_llrs * noise_factor;
end
end

function metrics = calculateAIEnhancementMetrics(performance_analysis, config)
% Calculate comprehensive metrics quantifying AI enhancement benefits

metrics = struct();

% BLER improvement calculation
bler_improvement = (performance_analysis.bler_classical - ...
performance_analysis.bler_ai_enhanced) ./ ...
performance_analysis.bler_classical;
metrics.average_bler_improvement = mean(bler_improvement(~isnan(bler_improvement)));

% Throughput enhancement calculation
throughput_gain = (performance_analysis.throughput_ai_enhanced - ...
performance_analysis.throughput_classical) ./ ...
performance_analysis.throughput_classical;
metrics.average_throughput_gain = mean(throughput_gain(~isnan(throughput_gain)));

% SNR gain calculation (at 10% BLER threshold)
target_bler = 0.1;
snr_classical_10_percent = interpolateRequiredSNR(performance_analysis.snr_values_db, ...
performance_analysis.bler_classical, ...
target_bler);
snr_ai_10_percent = interpolateRequiredSNR(performance_analysis.snr_values_db, ...
performance_analysis.bler_ai_enhanced, ...
target_bler);
metrics.snr_gain_db = snr_classical_10_percent - snr_ai_10_percent;

% Channel estimation improvement
if isfield(performance_analysis, 'channel_estimation_error')
est_improvement = (performance_analysis.channel_estimation_error.classical_mean - ...
performance_analysis.channel_estimation_error.ai_enhanced_mean) ./ ...
performance_analysis.channel_estimation_error.classical_mean;
metrics.channel_estimation_improvement = mean(est_improvement(~isnan(est_improvement)));
end

% Robustness metrics
metrics.performance_variance_classical = var(performance_analysis.bler_classical);
metrics.performance_variance_ai = var(performance_analysis.bler_ai_enhanced);
metrics.robustness_improvement = (metrics.performance_variance_classical - ...
metrics.performance_variance_ai) / ...
metrics.performance_variance_classical;

fprintf('AI Enhancement Metrics:\n');
fprintf(' Average BLER Improvement: %.2f%%\n', metrics.average_bler_improvement * 100);
fprintf(' Average Throughput Gain: %.2f%%\n', metrics.average_throughput_gain * 100);
fprintf(' SNR Gain at 10%% BLER: %.2f dB\n', metrics.snr_gain_db);
if isfield(metrics, 'channel_estimation_improvement')
fprintf(' Channel Estimation Improvement: %.2f%%\n', ...
metrics.channel_estimation_improvement * 100);
end
fprintf(' Robustness Improvement: %.2f%%\n', metrics.robustness_improvement * 100);
end

function required_snr = interpolateRequiredSNR(snr_values, bler_values, target_bler)
% Interpolate required SNR for target BLER using linear interpolation

% Find the two SNR points that bracket the target BLER
valid_indices = ~isnan(bler_values) & ~isinf(bler_values);
snr_valid = snr_values(valid_indices);
bler_valid = bler_values(valid_indices);

if isempty(bler_valid) || all(bler_valid > target_bler) || all(bler_valid < target_bler)
required_snr = NaN;
return;
end

% Perform linear interpolation
required_snr = interp1(bler_valid, snr_valid, target_bler, 'linear', 'extrap');
end

function generatePerformanceVisualisation(performance_analysis, ai_metrics, config)
% Generate comprehensive visualisation of simulation results

% Create figure with multiple subplots
figure('Position', [100, 100, 1200, 800]);

% BLER vs SNR comparison
subplot(2, 2, 1);
semilogy(performance_analysis.snr_values_db, performance_analysis.bler_classical, ...
'b-o', 'LineWidth', 2, 'MarkerSize', 6);
hold on;
semilogy(performance_analysis.snr_values_db, performance_analysis.bler_ai_enhanced, ...
'r-s', 'LineWidth', 2, 'MarkerSize', 6);
xlabel('SNR (dB)');
ylabel('Block Error Rate');
title('5*G NR BLER Performance Comparison');
legend('Classical', 'AI-Enhanced', 'Location', 'southwest');
grid on;
axis tight;

% Throughput comparison
subplot(2, 2, 2);
plot(performance_analysis.snr_values_db, performance_analysis.throughput_classical, ...
'b-o', 'LineWidth', 2, 'MarkerSize', 6);
hold on;
plot(performance_analysis.snr_values_db, performance_analysis.throughput_ai_enhanced, ...
'r-s', 'LineWidth', 2, 'MarkerSize', 6);
xlabel('SNR (dB)');
ylabel('Normalised Throughput');
title('Throughput Performance Comparison');
legend('Classical', 'AI-Enhanced', 'Location', 'southeast');
grid on;
axis tight;

% Channel estimation error comparison (if available)
if isfield(performance_analysis, 'channel_estimation_error')
subplot(2, 2, 3);
semilogy(performance_analysis.snr_values_db, ...
performance_analysis.channel_estimation_error.classical_mean, ...
'b-o', 'LineWidth', 2, 'MarkerSize', 6);
hold on;
semilogy(performance_analysis.snr_values_db, ...
performance_analysis.channel_estimation_error.ai_enhanced_mean, ...
'r-s', 'LineWidth', 2, 'MarkerSize', 6);
xlabel('SNR (dB)');
ylabel('Channel Estimation MSE');
title('Channel Estimation Error Comparison');
legend('Classical', 'AI-Enhanced', 'Location', 'southwest');
grid on;
axis tight;
end

% AI enhancement gains
subplot(2, 2, 4);
bler_improvement = (performance_analysis.bler_classical - ...
performance_analysis.bler_ai_enhanced) ./ ...
performance_analysis.bler_classical * 100;
plot(performance_analysis.snr_values_db, bler_improvement, ...
'g-^', 'LineWidth', 2, 'MarkerSize', 6);
xlabel('SNR (dB)');
ylabel('BLER Improvement (%)');
title('AI Enhancement Benefits');
grid on;
axis tight;

% Add overall enhancement metrics as text
enhancement_text = sprintf(['AI Enhancement Summary:\n' ...
'Avg BLER Improvement: %.1f%%\n' ...
'Avg Throughput Gain: %.1f%%\n' ...
'SNR Gain: %.1f dB'], ...
ai_metrics.average_bler_improvement * 100, ...
ai_metrics.average_throughput_gain * 100, ...
ai_metrics.snr_gain_db);

annotation('textbox', [0.02, 0.02, 0.3, 0.15], 'String', enhancement_text, ...
'FontSize', 10, 'BackgroundColor', 'white', 'EdgeColor', 'black');

sgtitle('5*G NR AI-Enhanced System Performance Analysis', 'FontSize', 14, 'FontWeight', 'bold');
end
