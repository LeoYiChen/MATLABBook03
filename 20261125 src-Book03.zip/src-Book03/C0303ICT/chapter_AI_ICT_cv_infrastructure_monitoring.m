%% chapter_AI_ICT_cv_infrastructure_monitoring.m
% Comprehensive Computer Vision Framework for ICT Infrastructure Monitoring
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0303ICT/
% Listing label         : chapter_AI_ICT_cv_infrastructure_monitoring
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [inspection_results, performance_metrics] = intelligentInfrastructureMonitoring(image_data, monitoring_config)
% Comprehensive computer vision framework for automated ICT infrastructure monitoring
% Implements multi-scale defect detection, condition assessment, and predictive analysis
%
% Inputs:
% image_data: structure containing image datasets from various infrastructure components
% monitoring_config: configuration parameters for different inspection tasks
% Outputs:
% inspection_results: detailed analysis results for each infrastructure component
% performance_metrics: quantitative assessment of monitoring system performance

fprintf('Initialising Intelligent Infrastructure Monitoring System...\n');

% Validate Computer Vision Toolbox availability
if ~license('test', 'Video_and_Image_Blockset')
error('Computer Vision Toolbox license not available. Please ensure Computer Vision Toolbox is installed.');
end

% Define infrastructure monitoring tasks
monitoring_tasks = {'corrosion_detection', 'crack_analysis', 'component_degradation', ...
'thermal_anomaly', 'geometric_deformation', 'surface_contamination'};
num_tasks = length(monitoring_tasks);

% Initialise comprehensive results structure
inspection_results = struct();
performance_metrics = struct();

% Configure advanced image preprocessing pipeline
preprocessing_params = configurePreprocessing(monitoring_config);

% Initialise machine learning models for each monitoring task
fprintf('Loading pre-trained models for infrastructure analysis...\n');
detection_models = initialiseDetectionModels(monitoring_config);

% Process each monitoring task
for task_idx = 1:num_tasks
task_name = monitoring_tasks{task_idx};
fprintf('\nProcessing %s analysis...\n', strrep(task_name, '_', ' '));

 
% Extract task-specific image data
if isfield(image_data, task_name)
    task_images = image_data.*(task_name);
    
    % Comprehensive image analysis pipeline
    [task_results, task_metrics] = processInfrastructureTask(task_images, ...
                                                           task_name, ...
                                                           detection_models.*(task_name), ...
                                                           preprocessing_params, ...
                                                           monitoring_config);
    
    % Store results
    inspection_results.*(task_name) = task_results;
    performance_metrics.*(task_name) = task_metrics;
    
    fprintf('  Completed %s: %.1f%% accuracy, %.2f ms average processing time\n', ...
            task_name, task_metrics.accuracy * 100, task_metrics.avg_processing_time * 1000);
else
    fprintf('  No data available for %s analysis\n', task_name);
end
end

% Generate comprehensive infrastructure health assessment
infrastructure_health = assessInfrastructureHealth(inspection_results, monitoring_config);
inspection_results.overall_assessment = infrastructure_health;

% Predictive maintenance recommendations
maintenance_recommendations = generateMaintenanceRecommendations(inspection_results, monitoring_config);
inspection_results.maintenance_recommendations = maintenance_recommendations;

% Performance analysis and visualisation
generateComprehensiveReport(inspection_results, performance_metrics, monitoring_config);

fprintf('\nIntelligent Infrastructure Monitoring completed successfully.\n');
end

function preprocessing_params = configurePreprocessing(config)
% Configure advanced preprocessing pipeline for infrastructure monitoring

preprocessing_params = struct();

% Image enhancement parameters
preprocessing_params.contrast_enhancement = struct();
preprocessing_params.contrast_enhancement.method = 'adapthisteq'; % Adaptive histogram equalisation
preprocessing_params.contrast_enhancement.clip_limit = config.contrast.clip_limit;
preprocessing_params.contrast_enhancement.num_tiles = config.contrast.num_tiles;

% Noise reduction parameters
preprocessing_params.noise_reduction = struct();
preprocessing_params.noise_reduction.method = 'wiener'; % Wiener filtering
preprocessing_params.noise_reduction.noise_variance = config.noise.estimated_variance;

% Geometric correction parameters
preprocessing_params.geometric_correction = struct();
preprocessing_params.geometric_correction.enable_correction = config.geometry.enable_correction;
preprocessing_params.geometric_correction.reference_points = config.geometry.reference_points;

% Illumination normalisation parameters
preprocessing_params.illumination = struct();
preprocessing_params.illumination.method = 'homomorphic'; % Homomorphic filtering
preprocessing_params.illumination.high_frequency_gain = config.illumination.hf_gain;
preprocessing_params.illumination.low_frequency_gain = config.illumination.lf_gain;

fprintf(' Preprocessing pipeline configured successfully\n');
end

function detection_models = initialiseDetectionModels(config)
% Initialise detection models for various infrastructure monitoring tasks

detection_models = struct();

% Corrosion detection model
fprintf(' Initialising corrosion detection model...\n');
detection_models.corrosion_detection = initialiseCorrosionModel(config.corrosion);

% Crack analysis model
fprintf(' Initialising crack analysis model...\n');
detection_models.crack_analysis = initialiseCrackModel(config.crack);

% Component degradation model
fprintf(' Initialising component degradation model...\n');
detection_models.component_degradation = initialiseDegradationModel(config.degradation);

% Thermal anomaly detection model
fprintf(' Initialising thermal anomaly model...\n');
detection_models.thermal_anomaly = initialiseThermalModel(config.thermal);

% Geometric deformation model
fprintf(' Initialising geometric deformation model...\n');
detection_models.geometric_deformation = initialiseDeformationModel(config.deformation);

% Surface contamination model
fprintf(' Initialising surface contamination model...\n');
detection_models.surface_contamination = initialiseContaminationModel(config.contamination);

fprintf(' All detection models initialised successfully\n');
end

function model = initialiseCorrosionModel(config)
% Initialise corrosion detection model using colour and texture analysis

model = struct();
model.type = 'multi_feature_classifier';

% Colour-based detection parameters
model.colour_features = struct();
model.colour_features.hsv_thresholds = config.hsv_corrosion_range;
model.colour_features.lab_thresholds = config.lab_corrosion_range;

% Texture analysis parameters using GLCM (Grey-Level Co-occurrence Matrix)
model.texture_features = struct();
model.texture_features.glcm_distances = [1, 2, 4]; % Pixel distances for GLCM
model.texture_features.glcm_angles = [0, 45, 90, 135] * pi/180; % Angles in radians
model.texture_features.properties = {'contrast', 'correlation', 'energy', 'homogeneity'};

% Machine learning classifier (simplified SVM approach)
model.classifier = struct();
model.classifier.type = 'support_vector_machine';
model.classifier.kernel = 'rbf';
model.classifier.training_data = config.training_dataset;

% Decision fusion parameters
model.fusion = struct();
model.fusion.colour_weight = config.colour_weight;
model.fusion.texture_weight = config.texture_weight;
model.fusion.decision_threshold = config.decision_threshold;
end

function model = initialiseCrackModel(config)
% Initialise crack detection model using edge detection and morphological analysis

model = struct();
model.type = 'edge_morphology_classifier';

% Edge detection parameters
model.edge_detection = struct();
model.edge_detection.method = 'canny'; % Canny edge detector
model.edge_detection.threshold = config.canny_thresholds;
model.edge_detection.sigma = config.gaussian_sigma;

% Morphological processing parameters
model.morphology = struct();
model.morphology.structuring_element = strel('line', config.line_length, config.line_angle);
model.morphology.close_iterations = config.close_iterations;
model.morphology.open_iterations = config.open_iterations;

% Geometric filtering parameters
model.geometric_filter = struct();
model.geometric_filter.min_area = config.min_crack_area;
model.geometric_filter.max_area = config.max_crack_area;
model.geometric_filter.aspect_ratio_range = config.aspect_ratio_range;
model.geometric_filter.solidity_threshold = config.solidity_threshold;
end

function [task_results, task_metrics] = processInfrastructureTask(task_images, task_name, model, preprocessing_params, config)
% Process individual infrastructure monitoring task

num_images = length(task_images);
task_results = struct();
task_results.detections = cell(num_images, 1);
task_results.confidence_scores = cell(num_images, 1);
task_results.processing_times = zeros(num_images, 1);

% Performance tracking
correct_detections = 0;
total_processing_time = 0;

fprintf(' Processing %d images for %s...\n', num_images, task_name);

for img_idx = 1:num_images
tic; % Start timing
 
% Load and validate image
current_image = task_images{img_idx};
if ischar(current_image)
    current_image = imread(current_image);
end

% Comprehensive preprocessing
processed_image = applyPreprocessing(current_image, preprocessing_params);

% Task-specific analysis
switch task_name
    case 'corrosion_detection'
        [detections, confidence] = detectCorrosion(processed_image, model, config);
        
    case 'crack_analysis'
        [detections, confidence] = detectCracks(processed_image, model, config);
        
    case 'component_degradation'
        [detections, confidence] = assessDegradation(processed_image, model, config);
        
    case 'thermal_anomaly'
        [detections, confidence] = detectThermalAnomalies(processed_image, model, config);
        
    case 'geometric_deformation'
        [detections, confidence] = detectDeformation(processed_image, model, config);
        
    case 'surface_contamination'
        [detections, confidence] = detectContamination(processed_image, model, config);
        
    otherwise
        error('Unknown task: %s', task_name);
end

processing_time = toc;

% Store results
task_results.detections{img_idx} = detections;
task_results.confidence_scores{img_idx} = confidence;
task_results.processing_times(img_idx) = processing_time;

total_processing_time = total_processing_time + processing_time;

% Performance evaluation (if ground truth available)
if isfield(config, 'ground_truth') && ~isempty(config.ground_truth)
    if img_idx <= length(config.ground_truth)
        ground_truth = config.ground_truth{img_idx};
        if evaluateDetection(detections, ground_truth, config.evaluation_threshold)
            correct_detections = correct_detections + 1;
        end
    end
end
end

% Calculate task metrics
task_metrics = struct();
task_metrics.total_images = num_images;
task_metrics.avg_processing_time = total_processing_time / num_images;
task_metrics.total_processing_time = total_processing_time;

if isfield(config, 'ground_truth') && ~isempty(config.ground_truth)
task_metrics.accuracy = correct_detections / min(num_images, length(config.ground_truth));
task_metrics.num_correct = correct_detections;
else
task_metrics.accuracy = NaN; % No ground truth available
task_metrics.num_correct = NaN;
end

% Statistical analysis of confidence scores
all_confidences = cell2mat(task_results.confidence_scores);
if ~isempty(all_confidences)
task_metrics.mean_confidence = mean(all_confidences);
task_metrics.confidence_std = std(all_confidences);
task_metrics.min_confidence = min(all_confidences);
task_metrics.max_confidence = max(all_confidences);
end
end

function processed_image = applyPreprocessing(input_image, params)
% Apply comprehensive preprocessing pipeline

processed_image = input_image;

% Convert to appropriate format if necessary
if size(processed_image, 3) == 3 && isfield(params, 'convert_to_grayscale') && params.convert_to_grayscale
processed_image = rgb2gray(processed_image);
end

% Contrast enhancement
if isfield(params, 'contrast_enhancement')
switch params.contrast_enhancement.method
case 'adapthisteq'
if size(processed_image, 3) == 1
processed_image = adapthisteq(processed_image, ...
'ClipLimit', params.contrast_enhancement.clip_limit, ...
'NumTiles', params.contrast_enhancement.num_tiles);
else
% Apply to each channel separately
for ch = 1:size(processed_image, 3)
processed_image(:,:,ch) = adapthisteq(processed_image(:,:,ch), ...
'ClipLimit', params.contrast_enhancement.clip_limit, ...
'NumTiles', params.contrast_enhancement.num_tiles);
end
end
 
    case 'histeq'
        if size(processed_image, 3) == 1
            processed_image = histeq(processed_image);
        else
            for ch = 1:size(processed_image, 3)
                processed_image(:,:,ch) = histeq(processed_image(:,:,ch));
            end
        end
end
end

% Noise reduction
if isfield(params, 'noise_reduction')
switch params.noise_reduction.method
case 'wiener'
if size(processed_image, 3) == 1
processed_image = wiener2(processed_image);
else
for ch = 1:size(processed_image, 3)
processed_image(:,:,ch) = wiener2(processed_image(:,:,ch));
end
end
 
    case 'median'
        processed_image = medfilt2(processed_image);
        
    case 'gaussian'
        h = fspecial('gaussian', [5 5], 1);
        processed_image = imfilter(processed_image, h);
end
end

% Geometric correction (if enabled)
if isfield(params, 'geometric_correction') && params.geometric_correction.enable_correction
if isfield(params.geometric_correction, 'reference_points') && ...
~isempty(params.geometric_correction.reference_points)
% Apply perspective correction using reference points
% This is a simplified implementation
processed_image = applyGeometricCorrection(processed_image, ...
params.geometric_correction.reference_points);
end
end
end

function [detections, confidence] = detectCorrosion(image, model, config)
% Detect corrosion using colour and texture analysis

% Convert to multiple colour spaces for robust detection
rgb_image = image;
if size(image, 3) == 1
rgb_image = repmat(image, [1, 1, 3]);
end

hsv_image = rgb2hsv(rgb_image);
lab_image = rgb2lab(rgb_image);

% Colour-based detection in HSV space
hsv_mask = (hsv_image(:,:,1) >= model.colour_features.hsv_thresholds(1,1)) & ...
(hsv_image(:,:,1) <= model.colour_features.hsv_thresholds(1,2)) & ...
(hsv_image(:,:,2) >= model.colour_features.hsv_thresholds(2,1)) & ...
(hsv_image(:,:,2) <= model.colour_features.hsv_thresholds(2,2)) & ...
(hsv_image(:,:,3) >= model.colour_features.hsv_thresholds(3,1)) & ...
(hsv_image(:,:,3) <= model.colour_features.hsv_thresholds(3,2));

% Colour-based detection in LAB space
lab_mask = (lab_image(:,:,2) >= model.colour_features.lab_thresholds(1,1)) & ...
(lab_image(:,:,2) <= model.colour_features.lab_thresholds(1,2)) & ...
(lab_image(:,:,3) >= model.colour_features.lab_thresholds(2,1)) & ...
(lab_image(:,:,3) <= model.colour_features.lab_thresholds(2,2));

% Combine colour masks
colour_mask = hsv_mask | lab_mask;

% Texture analysis using GLCM
gray_image = rgb2gray(rgb_image);
texture_features = calculateGLCMFeatures(gray_image, model.texture_features);

% Simple texture-based classification (can be enhanced with ML)
texture_score = calculateTextureScore(texture_features, model.texture_features);

% Combine colour and texture information
combined_mask = colour_mask & (texture_score > model.fusion.decision_threshold);

% Morphological post-processing
se = strel('disk', 3);
combined_mask = imopen(combined_mask, se);
combined_mask = imclose(combined_mask, se);

% Extract connected components
cc = bwconncomp(combined_mask);
stats = regionprops(cc, 'Area', 'BoundingBox', 'Centroid');

% Filter detections based on size and shape criteria
valid_detections = [stats.Area] > config.min_corrosion_area & ...
[stats.Area] < config.max_corrosion_area;

detections = stats(valid_detections);

% Calculate confidence scores based on colour and texture consistency
confidence = zeros(length(detections), 1);
for i = 1:length(detections)
% Extract region
bbox = round(detections(i).BoundingBox);
region = rgb_image(bbox(2):min(bbox(2)+bbox(4)-1, size(rgb_image,1)), ...
bbox(1):min(bbox(1)+bbox(3)-1, size(rgb_image,2)), :);

 
% Calculate confidence based on colour consistency
colour_confidence = calculateColourConfidence(region, model.colour_features);

% Calculate confidence based on texture consistency
texture_confidence = calculateTextureConfidence(region, model.texture_features);

% Weighted combination
confidence(i) = model.fusion.colour_weight * colour_confidence + ...
               model.fusion.texture_weight * texture_confidence;
end
end

function [detections, confidence] = detectCracks(image, model, config)
% Detect cracks using edge detection and morphological analysis

% Convert to grayscale if necessary
if size(image, 3) == 3
gray_image = rgb2gray(image);
else
gray_image = image;
end

% Edge detection using Canny detector
edge_image = edge(gray_image, 'canny', model.edge_detection.threshold, ...
model.edge_detection.sigma);

% Morphological processing to enhance crack-like structures
processed_image = imclose(edge_image, model.morphology.structuring_element);
processed_image = imopen(processed_image, strel('disk', 2));

% Remove small noise components
processed_image = bwareaopen(processed_image, config.min_crack_area);

% Extract connected components and analyse geometry
cc = bwconncomp(processed_image);
stats = regionprops(cc, 'Area', 'BoundingBox', 'MajorAxisLength', ...
'MinorAxisLength', 'Solidity', 'Extent');

% Filter based on crack-like geometric properties
aspect_ratios = [stats.MajorAxisLength] ./ [stats.MinorAxisLength];
valid_cracks = ([stats.Area] >= model.geometric_filter.min_area) & ...
([stats.Area] <= model.geometric_filter.max_area) & ...
(aspect_ratios >= model.geometric_filter.aspect_ratio_range(1)) & ...
(aspect_ratios <= model.geometric_filter.aspect_ratio_range(2)) & ...
([stats.Solidity] >= model.geometric_filter.solidity_threshold);

detections = stats(valid_cracks);

% Calculate confidence based on geometric properties and edge strength
confidence = zeros(length(detections), 1);
for i = 1:length(detections)
% Geometric confidence
aspect_ratio = detections(i).MajorAxisLength / detections(i).MinorAxisLength;
geom_confidence = min(aspect_ratio / 10, 1.0); % Normalise to [0,1]

 
% Edge strength confidence (simplified)
bbox = round(detections(i).BoundingBox);
region_edges = edge_image(bbox(2):min(bbox(2)+bbox(4)-1, size(edge_image,1)), ...
                         bbox(1):min(bbox(1)+bbox(3)-1, size(edge_image,2)));
edge_density = sum(region_edges(:)) / numel(region_edges);

confidence(i) = 0.7 * geom_confidence + 0.3 * edge_density;
end
end
