# C0303ICT - Supplementary MATLAB Source Code

| Field | Value |
| --- | --- |
| Book | MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications |
| Chapter | Information and Communication Technologies: Advanced Theory and Implementation |
| Package version | 1.0.1 |
| Release stamp | 2026-11-10 |
| Source manuscript | `P03-20261111` |
| Source chapter file | `P0302main/C0303ICT/` (included by `P03_20261005.tex`) |
| Code files | 25 (25 `.m`, 0 `.f`) |
| Code lines relocated | 7,448 |

## Why this folder exists

The editor reported that a large volume of programming code was present in the
manuscript and requested that it be moved to a professional repository with the
links supplied as supplementary material. The printed book is subject to a
length target below 1100 pages and to the Springer hard-copy limit of fewer
than 950 print pages. Accordingly, every `lstlisting` (and every MATLAB
`verbatim`) environment in the chapter has been removed from the main body and
deposited here. Only the filename, the listing caption and a reference to this
folder remain in the printed text.

## Naming convention

A file is named after the `label` of the listing it came from:

```latex
\begin{lstlisting}[..., caption={Basic matrix operations ...},
                     label={chapter_Introduction_example_01}]
```

is saved as `chapter_Introduction_example_01.m`.

- Listings without a `label` receive a generated name `C0303ICT_code_NNN.m`.
- Code held in a `verbatim` environment receives `C0303ICT_verbatim_NN.m`
  (or `.f` for the single illustrative Fortran 77 block).
- Where two listings shared the same label, the later file carries a numeric
  suffix (`_02`, `_03`, ...) so nothing is overwritten. This is recorded in
  the table below.

Each file begins with a header comment giving the caption, the original label,
this folder, the version stamp and the public repository URL.

## Finding a file from the book

The main text now shows a one-line note of the form:

> **Source code 3.4:** `chapter_ICT_example_01.m` - *caption*
> (supplementary material: `src-Book03/C0303ICT/`)

The original listing numbers and all `\ref{...}` cross-references are
unchanged, so the in-text reference maps directly to a filename.

## Repository

```
https://github.com/LeoYiChen/MATLABBook03
```

Clone or download `src-Book03/` from this public repository, or use the
Springer supplementary archive. The same address is printed in the preface of
the book. Keep the `src-Book03/` folder name so that the in-text
`src-Book03/C0303ICT/` paths resolve.

## Companion documents

- `VERSION.md` - version, release stamp and release notes
- `USER-GUIDE.md` - how to download, locate and run the code
- `MANIFEST.sha256` - SHA-256 ledger of every file in this folder

## Files

| Filename | Source listing label | Caption |
| --- | --- | --- |
| `chapter_AI_ICT_5g_nr_ai_system.m` | `chapter_AI_ICT_5g_nr_ai_system` | Advanced 5G NR System Implementation with AI-Enhanced Channel Processing |
| `chapter_AI_ICT_6g_cognitive_network.m` | `chapter_AI_ICT_6g_cognitive_network` | Advanced 6G Network Simulation Framework with Cognitive AI Integration |
| `chapter_AI_ICT_adversarial_robustness_framework.m` | `chapter_AI_ICT_adversarial_robustness_framework` | Comprehensive Adversarial Robustness Framework for Communication Systems |
| `chapter_AI_ICT_code_generation_deployment.m` | `chapter_AI_ICT_code_generation_deployment` | Comprehensive Code Generation and Deployment Framework for AI-Enhanced ICT Systems |
| `chapter_AI_ICT_cv_infrastructure_monitoring.m` | `chapter_AI_ICT_cv_infrastructure_monitoring` | Comprehensive Computer Vision Framework for ICT Infrastructure Monitoring |
| `chapter_AI_ICT_deep_modulation_classification.m` | `chapter_AI_ICT_deep_modulation_classification` | Comprehensive Deep Learning Framework for Modulation Classification |
| `chapter_AI_ICT_development_methodology.m` | `chapter_AI_ICT_development_methodology` | Comprehensive Development Methodology Framework for AI-Enhanced ICT Systems |
| `chapter_AI_ICT_digital_twin_framework.m` | `chapter_AI_ICT_digital_twin_framework` | Comprehensive Digital Twin Framework for ICT Network Infrastructure |
| `chapter_AI_ICT_federated_learning_privacy.m` | `chapter_AI_ICT_federated_learning_privacy` | Privacy-Preserving Federated Learning Framework for Communication Networks |
| `chapter_AI_ICT_historical_kalman.m` | `chapter_AI_ICT_historical_kalman` | Historical Implementation of Kalman Filter for Communication Systems |
| `chapter_AI_ICT_lab1.m` | `chapter_AI_ICT_lab1` | Shannon Capacity Calculation. |
| `chapter_AI_ICT_lab2.m` | `chapter_AI_ICT_lab2` | Kalman Filter for Channel Tracking. |
| `chapter_AI_ICT_lab3.m` | `chapter_AI_ICT_lab3` | UKF for Nonlinear Channel Tracking. |
| `chapter_AI_ICT_lab4.m` | `chapter_AI_ICT_lab4` | Capacity vs. SNR Plot. |
| `chapter_AI_ICT_lab5.m` | `chapter_AI_ICT_lab5` | ML-based Capacity Prediction. |
| `chapter_AI_ICT_neural_evolution.m` | `chapter_AI_ICT_neural_evolution` | Evolution of Neural Networks in Communication Systems |
| `chapter_AI_ICT_performance_evaluation.m` | `chapter_AI_ICT_performance_evaluation` | Comprehensive Performance Evaluation Framework for AI-Enhanced ICT Systems |
| `chapter_AI_ICT_q_learning_allocation.m` | `chapter_AI_ICT_q_learning_allocation` | Q-Learning for Dynamic Resource Allocation |
| `chapter_AI_ICT_quantum_communications.m` | `chapter_AI_ICT_quantum_communications` | Quantum-Enhanced Communication System Simulation Framework |
| `chapter_AI_ICT_rl_network_optimisation.m` | `chapter_AI_ICT_rl_network_optimisation` | Advanced Reinforcement Learning Framework for Network Optimisation |
| `chapter_AI_ICT_spectrum_sensing_evolution.m` | `chapter_AI_ICT_spectrum_sensing_evolution` | Historical Evolution of Spectrum Sensing Algorithms |
| `chapter_AI_ICT_svm_signal_intelligence.m` | `chapter_AI_ICT_svm_signal_intelligence` | SVM-Based Signal Intelligence Framework for Communication Systems |
| `chapter_AI_ICT_text_analytics_network_ops.m` | `chapter_AI_ICT_text_analytics_network_ops` | Advanced Text Analytics Framework for Network Operations Intelligence |
| `chapter_AI_ICT_toolbox_integration_framework.m` | `chapter_AI_ICT_toolbox_integration_framework` | Comprehensive Toolbox Integration Framework for AI-Enhanced ICT Systems |
| `chapter_AI_ICT_ukf_historical.m` | `chapter_AI_ICT_ukf_historical` | Unscented Kalman Filter with Historical Context |
