%% chapter_AI_ICT_historical_kalman.m
% Historical Implementation of Kalman Filter for Communication Systems
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0303ICT/
% Listing label         : chapter_AI_ICT_historical_kalman
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [x_est, P_est, innovations, likelihood] = historicalKalmanImplementation(measurements, model_params)
% Implementation inspired by the original Apollo Guidance Computer algorithms
% This version includes historical context and computational considerations
% from the early space programme era

[d, T] = size(measurements);
n = length(model_params.x0);

% Initialisation following Apollo-era practices
x_est = zeros(n, T);
P_est = zeros(n, n, T);
innovations = zeros(d, T);
likelihood = zeros(1, T);

% Initial estimates based on ground-based radar observations
x_pred = model_params.x0;
P_pred = model_params.P0;

% Apollo Guidance Computer had only 4*KB of memory, requiring careful
% memory management and computational efficiency
for t = 1:T
% Prediction step using state transition model
% Original implementation used fixed-point arithmetic
if t > 1
x_pred = model_params.F * x_est(:, t-1);
P_pred = model_params.F * P_est(:, :, t-1) * model_params.F' + model_params.Q;
end

 
% Innovation computation - critical for spacecraft navigation
innovation = measurements(:, t) - model_params.H * x_pred;
S = model_params.H * P_pred * model_params.H' + model_params.R;

% Kalman gain computation using methods suitable for 1960*s computers
% Original implementation avoided matrix inversion when possible
try
    K = P_pred * model_params.H' / S;
catch
    % Fallback method for numerical stability (not available in 1960*s)
    K = P_pred * model_params.H' * pinv(S);
end

% Update step following Apollo mission procedures
x_est(:, t) = x_pred + K * innovation;

% Covariance update using Joseph form for numerical stability
% This was crucial for long-duration space missions
I_KH = eye(n) - K * model_params.H;
P_est(:, :, t) = I_KH * P_pred * I_KH' + K * model_params.R * K';

% Store innovation sequence for mission control monitoring
innovations(:, t) = innovation;

% Compute likelihood for trajectory validation
% Mission controllers used this to verify navigation accuracy
if det(S) > eps % Avoid numerical issues
    likelihood(t) = -0.5 * (d * log(2*pi) + log(det(S)) + ...
                           innovation' * (S \ innovation));
else
    likelihood(t) = -Inf; % Indicate numerical problem
end

% Mission-critical error checking
% Apollo computers had limited error handling capabilities
if any(~isfinite(x_est(:, t)))
    warning('State estimate contains non-finite values at time %d', t);
    % In Apollo era, this would have triggered manual intervention
end
end

% Compute cumulative likelihood for mission analysis
likelihood = cumsum(likelihood);

% Historical note: The success of Kalman filtering in the Apollo programme
% led to its widespread adoption in civilian applications, including
% early satellite communication systems and GPS development
end
