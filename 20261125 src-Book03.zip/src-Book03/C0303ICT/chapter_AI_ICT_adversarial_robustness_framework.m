%% chapter_AI_ICT_adversarial_robustness_framework.m
% Comprehensive Adversarial Robustness Framework for Communication Systems
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0303ICT/
% Listing label         : chapter_AI_ICT_adversarial_robustness_framework
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [robustness_results, defence_performance] = adversarialRobustnessFramework(model_config, attack_config, defence_config)
% Comprehensive framework for evaluating and enhancing adversarial robustness
% in AI-enabled communication systems using MATLAB's built-in capabilities
%
% Inputs:
% model_config: Configuration for the target AI model
% attack_config: Parameters for various adversarial attack methods
% defence_config: Configuration for defence mechanisms
% Outputs:
% robustness_results: Detailed robustness evaluation metrics
% defence_performance: Performance analysis of defence strategies

fprintf('Initialising Adversarial Robustness Evaluation Framework...\n');

% Validate required toolboxes
requiredToolboxes = {'Deep Learning Toolbox', 'Signal Processing Toolbox', ...
'Communications Toolbox', 'Statistics and Machine Learning Toolbox'};
for i = 1:length(requiredToolboxes)
if ~license('test', strrep(requiredToolboxes{i}, ' ', '_'))
error('Required toolbox not available: %s', requiredToolboxes{i});
end
end

% Define attack methodologies for comprehensive evaluation
attack_methods = {'FGSM', 'PGD', 'CW', 'DeepFool', 'SignalDomain', 'FrequencyDomain'};
num_attack_methods = length(attack_methods);

% Initialise comprehensive results structure
robustness_results = struct();
defence_performance = struct();

% Load or create target model for robustness evaluation
fprintf('Loading target communication system model...\n');
target_model = loadOrCreateTargetModel(model_config);

% Prepare evaluation datasets
fprintf('Preparing evaluation datasets...\n');
[clean_data, labels] = prepareEvaluationData(model_config);

% Baseline performance evaluation
fprintf('Evaluating baseline model performance...\n');
baseline_performance = evaluateBaselinePerformance(target_model, clean_data, labels);
robustness_results.baseline_performance = baseline_performance;

% Comprehensive adversarial attack evaluation
fprintf('\nConducting comprehensive adversarial attack evaluation...\n');
for attack_idx = 1:num_attack_methods
attack_method = attack_methods{attack_idx};
fprintf(' Evaluating %s attacks...\n', attack_method);

 
% Generate adversarial examples using specified method
[adversarial_data, attack_metadata] = generateAdversarialExamples(clean_data, labels, ...
                                                                 target_model, ...
                                                                 attack_method, ...
                                                                 attack_config);

% Evaluate model performance under attack
attack_performance = evaluateUnderAttack(target_model, adversarial_data, labels);

% Calculate robustness metrics
robustness_metrics = calculateRobustnessMetrics(baseline_performance, ...
                                               attack_performance, ...
                                               attack_metadata);

% Store results
robustness_results.*(attack_method) = struct();
robustness_results.*(attack_method).attack_performance = attack_performance;
robustness_results.*(attack_method).robustness_metrics = robustness_metrics;
robustness_results.*(attack_method).attack_metadata = attack_metadata;

fprintf('    %s: Clean Accuracy = %.3f, Robust Accuracy = %.3f, Drop = %.3f\n', ...
        attack_method, baseline_performance.accuracy, ...
        attack_performance.accuracy, ...
        baseline_performance.accuracy - attack_performance.accuracy);
end

% Implement and evaluate defence mechanisms
fprintf('\nImplementing and evaluating defence mechanisms...\n');
defence_methods = {'AdversarialTraining', 'DefensiveDistillation', 'InputPreprocessing', ...
'EnsembleDefence', 'CertifiedDefence', 'DetectionBased'};

for defence_idx = 1:length(defence_methods)
defence_method = defence_methods{defence_idx};
fprintf(' Evaluating %s defence...\n', defence_method);

 % Implement defence mechanism
defended_model = implementDefenceMechanism(target_model, defence_method, ...
                                          defence_config, clean_data, labels);

% Evaluate defence effectiveness against all attacks
defence_effectiveness = evaluateDefenceEffectiveness(defended_model, ...
                                                    robustness_results, ...
                                                    clean_data, labels, ...
                                                    attack_config);

% Store defence performance results
defence_performance.*(defence_method) = defence_effectiveness;

fprintf('    %s: Average Robust Accuracy = %.3f, Defence Overhead = %.2f%%\n', ...
        defence_method, defence_effectiveness.average_robust_accuracy, ...
        defence_effectiveness.computational_overhead * 100);
end

% Generate comprehensive robustness analysis
comprehensive_analysis = generateComprehensiveAnalysis(robustness_results, ...
defence_performance, ...
model_config);

% Visualise results and generate recommendations
generateRobustnessVisualisation(robustness_results, defence_performance, comprehensive_analysis);

% Generate security recommendations
security_recommendations = generateSecurityRecommendations(comprehensive_analysis, ...
model_config);

% Package final results
robustness_results.comprehensive_analysis = comprehensive_analysis;
robustness_results.security_recommendations = security_recommendations;

fprintf('\nAdversarial Robustness Evaluation completed successfully.\n');
fprintf('Recommendations: %d critical findings, %d suggested mitigations\n', ...
length(security_recommendations.critical_findings), ...
length(security_recommendations.suggested_mitigations));
end

function target_model = loadOrCreateTargetModel(config)
% Load existing model or create new one for robustness evaluation

if isfield(config, 'existing_model_path') && exist(config.existing_model_path, 'file')
% Load existing trained model
fprintf(' Loading existing model from: %s\n', config.existing_model_path);
model_data = load(config.existing_model_path);
target_model = model_data.trainedNetwork;
else
% Create new model for evaluation
fprintf(' Creating new model for robustness evaluation...\n');
target_model = createEvaluationModel(config);
end

% Validate model architecture
validateModelArchitecture(target_model, config);
end

function model = createEvaluationModel(config)
% Create a representative model for communication systems evaluation

switch config.model_type
case 'modulation_classifier'
model = createModulationClassifier(config);
case 'anomaly_detector'
model = createAnomalyDetector(config);
case 'channel_estimator'
model = createChannelEstimator(config);
case 'spectrum_classifier'
model = createSpectrumClassifier(config);
otherwise
error('Unsupported model type: %s', config.model_type);
end
end

function model = createModulationClassifier(config)
% Create CNN-based modulation classification model

% Define network architecture for modulation classification
layers = [
imageInputLayer([config.input_height, config.input_width, config.num_channels], ...
'Name', 'input', 'Normalization', 'zerocenter')

 
% First convolutional block
convolution2dLayer([5, 5], 32, 'Padding', 'same', 'Name', 'conv1')
batchNormalizationLayer('Name', 'bn1')
reluLayer('Name', 'relu1')
maxPooling2dLayer([2, 2], 'Stride', [2, 2], 'Name', 'pool1')

% Second convolutional block
convolution2dLayer([3, 3], 64, 'Padding', 'same', 'Name', 'conv2')
batchNormalizationLayer('Name', 'bn2')
reluLayer('Name', 'relu2')
maxPooling2dLayer([2, 2], 'Stride', [2, 2], 'Name', 'pool2')

% Third convolutional block
convolution2dLayer([3, 3], 128, 'Padding', 'same', 'Name', 'conv3')
batchNormalizationLayer('Name', 'bn3')
reluLayer('Name', 'relu3')
globalAveragePooling2dLayer('Name', 'gap')

% Classification layers
fullyConnectedLayer(256, 'Name', 'fc1')
dropoutLayer(0.5, 'Name', 'dropout1')
reluLayer('Name', 'relu_fc1')

fullyConnectedLayer(config.num_classes, 'Name', 'fc_output')
softmaxLayer('Name', 'softmax')
classificationLayer('Name', 'classification')];
% Training options for quick evaluation model
options = trainingOptions('adam', ...
'MaxEpochs', 10, ...
'MiniBatchSize', 32, ...
'InitialLearnRate', 1e-3, ...
'Shuffle', 'every-epoch', ...
'Verbose', false, ...
'Plots', 'none');

% Generate synthetic training data for evaluation
[training_data, training_labels] = generateSyntheticTrainingData(config);

% Train the model
model = trainNetwork(training_data, training_labels, layers, options);
end

function [adversarial_data, attack_metadata] = generateAdversarialExamples(clean_data, labels, model, attack_method, config)
% Generate adversarial examples using various attack methods

attack_metadata = struct();
attack_metadata.method = attack_method;
attack_metadata.parameters = config.*(lower(attack_method));

fprintf(' Generating %s adversarial examples...\n', attack_method);

switch attack_method
case 'FGSM'
[adversarial_data, attack_metadata] = generateFGSMAttack(clean_data, labels, model, config.fgsm);

 
case 'PGD'
    [adversarial_data, attack_metadata] = generatePGDAttack(clean_data, labels, model, config.pgd);
    
case 'CW'
    [adversarial_data, attack_metadata] = generateCWAttack(clean_data, labels, model, config.cw);
    
case 'DeepFool'
    [adversarial_data, attack_metadata] = generateDeepFoolAttack(clean_data, labels, model, config.deepfool);
    
case 'SignalDomain'
    [adversarial_data, attack_metadata] = generateSignalDomainAttack(clean_data, labels, model, config.signal_domain);
    
case 'FrequencyDomain'
    [adversarial_data, attack_metadata] = generateFrequencyDomainAttack(clean_data, labels, model, config.frequency_domain);
    
otherwise
    error('Unsupported attack method: %s', attack_method);
end

% Calculate perturbation statistics
attack_metadata.perturbation_stats = calculatePerturbationStatistics(clean_data, adversarial_data);
end

function [adversarial_data, metadata] = generateFGSMAttack(clean_data, labels, model, params)
% Generate Fast Gradient Sign Method (FGSM) adversarial examples

epsilon = params.epsilon;
num_samples = size(clean_data, 4);
adversarial_data = clean_data;

metadata = struct();
metadata.epsilon = epsilon;
metadata.success_rate = 0;
successful_attacks = 0;

% Convert labels to categorical if needed
if isnumeric(labels)
labels = categorical(labels);
end

for i = 1:num_samples
% Extract single sample
current_sample = clean_data(:, :, :, i);
current_label = labels(i);

 
% Calculate gradient with respect to input
[gradient, original_prediction] = calculateInputGradient(model, current_sample, current_label);

% Generate adversarial perturbation
perturbation = epsilon * sign(gradient);

% Apply perturbation
adversarial_sample = current_sample + perturbation;

% Clip to valid range [0, 1] for image data
adversarial_sample = max(0, min(1, adversarial_sample));

% Store adversarial sample
adversarial_data(:, :, :, i) = adversarial_sample;

% Check attack success
adversarial_prediction = classify(model, adversarial_sample);
if adversarial_prediction ~= current_label
    successful_attacks = successful_attacks + 1;
end
end

metadata.success_rate = successful_attacks / num_samples;
metadata.num_successful_attacks = successful_attacks;
end

function [gradient, prediction] = calculateInputGradient(model, input_sample, true_label)
% Calculate gradient of loss with respect to input using automatic differentiation

% Convert input to dlarray for automatic differentiation
dlInput = dlarray(input_sample, 'SSCB');

% Calculate gradient using dlfeval
[loss, prediction, gradient] = dlfeval(@modelLossGradient, model, dlInput, true_label);

% Extract gradient data
gradient = extractdata(gradient);
end

function [loss, prediction, gradient] = modelLossGradient(model, dlInput, true_label)
% Compute loss and gradient for adversarial example generation

% Forward pass
dlPrediction = forward(model, dlInput);
prediction = extractdata(dlPrediction);

% Convert true label to one-hot encoding
num_classes = size(dlPrediction, 1);
if iscategorical(true_label)
label_idx = double(true_label);
else
label_idx = true_label;
end

one_hot_label = zeros(num_classes, 1);
one_hot_label(label_idx) = 1;
dlTrueLabel = dlarray(one_hot_label, 'CB');

% Calculate cross-entropy loss
loss = crossentropy(dlPrediction, dlTrueLabel);

% Calculate gradient
gradient = dlgradient(loss, dlInput);
end

function defended_model = implementDefenceMechanism(original_model, defence_method, config, training_data, training_labels)
% Implement various defence mechanisms against adversarial attacks

fprintf(' Implementing %s defence mechanism...\n', defence_method);

switch defence_method
case 'AdversarialTraining'
defended_model = implementAdversarialTraining(original_model, config.adversarial_training, ...
training_data, training_labels);

 
case 'DefensiveDistillation'
    defended_model = implementDefensiveDistillation(original_model, config.defensive_distillation, ...
                                                   training_data, training_labels);
    
case 'InputPreprocessing'
    defended_model = implementInputPreprocessing(original_model, config.input_preprocessing);
    
case 'EnsembleDefence'
    defended_model = implementEnsembleDefence(original_model, config.ensemble_defence, ...
                                             training_data, training_labels);
    
case 'CertifiedDefence'
    defended_model = implementCertifiedDefence(original_model, config.certified_defence);
    
case 'DetectionBased'
    defended_model = implementDetectionBasedDefence(original_model, config.detection_based, ...
                                                   training_data, training_labels);
    
otherwise
    error('Unsupported defence method: %s', defence_method);
end
end

function defended_model = implementAdversarialTraining(original_model, config, training_data, training_labels)
% Implement adversarial training defence mechanism

% Extract network layers for retraining
layers = original_model.Layers;

% Enhanced training options for adversarial training
options = trainingOptions('adam', ...
'MaxEpochs', config.max_epochs, ...
'MiniBatchSize', config.batch_size, ...
'InitialLearnRate', config.learning_rate, ...
'LearnRateSchedule', 'piecewise', ...
'LearnRateDropPeriod', 10, ...
'LearnRateDropFactor', 0.5, ...
'Shuffle', 'every-epoch', ...
'Verbose', false, ...
'Plots', 'none');

% Generate adversarial examples for training
adversarial_fraction = config.adversarial_fraction;
num_samples = size(training_data, 4);
num_adversarial = round(num_samples * adversarial_fraction);

% Create mixed training set with clean and adversarial examples
mixed_training_data = training_data;
mixed_training_labels = training_labels;

% Generate adversarial examples using FGSM for training
for i = 1:num_adversarial
sample_idx = mod(i-1, num_samples) + 1;
current_sample = training_data(:, :, :, sample_idx);
current_label = training_labels(sample_idx);

 
% Generate adversarial example
[gradient, ~] = calculateInputGradient(original_model, current_sample, current_label);
perturbation = config.epsilon * sign(gradient);
adversarial_sample = max(0, min(1, current_sample + perturbation));

% Add to training set
mixed_training_data = cat(4, mixed_training_data, adversarial_sample);
mixed_training_labels = [mixed_training_labels; current_label];
end

% Train defended model
defended_model = trainNetwork(mixed_training_data, mixed_training_labels, layers, options);
end

function robustness_metrics = calculateRobustnessMetrics(baseline_performance, attack_performance, attack_metadata)
% Calculate comprehensive robustness metrics

robustness_metrics = struct();

% Basic robustness metrics
robustness_metrics.accuracy_drop = baseline_performance.accuracy - attack_performance.accuracy;
robustness_metrics.relative_accuracy_drop = robustness_metrics.accuracy_drop / baseline_performance.accuracy;
robustness_metrics.robust_accuracy = attack_performance.accuracy;

% Attack success rate
robustness_metrics.attack_success_rate = attack_metadata.success_rate;

% Perturbation analysis
if isfield(attack_metadata, 'perturbation_stats')
robustness_metrics.perturbation_stats = attack_metadata.perturbation_stats;
end

% Confidence analysis
if isfield(attack_performance, 'confidence_scores')
robustness_metrics.confidence_degradation = mean(baseline_performance.confidence_scores) - ...
mean(attack_performance.confidence_scores);
end

% Class-specific robustness
if isfield(attack_performance, 'per_class_accuracy')
robustness_metrics.per_class_robustness = attack_performance.per_class_accuracy;
robustness_metrics.most_vulnerable_class = find(attack_performance.per_class_accuracy == ...
min(attack_performance.per_class_accuracy), 1);
end
end

function comprehensive_analysis = generateComprehensiveAnalysis(robustness_results, defence_performance, model_config)
% Generate comprehensive analysis of robustness evaluation results

comprehensive_analysis = struct();

% Extract attack method names
attack_methods = fieldnames(robustness_results);
attack_methods = attack_methods(~ismember(attack_methods, {'baseline_performance', 'comprehensive_analysis', 'security_recommendations'}));

% Overall robustness assessment
overall_robustness = zeros(length(attack_methods), 1);
for i = 1:length(attack_methods)
overall_robustness(i) = robustness_results.*(attack_methods{i}).robustness_metrics.robust_accuracy;
end

comprehensive_analysis.average_robust_accuracy = mean(overall_robustness);
comprehensive_analysis.min_robust_accuracy = min(overall_robustness);
comprehensive_analysis.robustness_variance = var(overall_robustness);

% Most effective attacks
[~, most_effective_idx] = min(overall_robustness);
comprehensive_analysis.most_effective_attack = attack_methods{most_effective_idx};
comprehensive_analysis.most_effective_attack_performance = overall_robustness(most_effective_idx);

% Defence effectiveness analysis
if ~isempty(defence_performance)
defence_methods = fieldnames(defence_performance);
defence_effectiveness = zeros(length(defence_methods), 1);

 
for i = 1:length(defence_methods)
    defence_effectiveness(i) = defence_performance.*(defence_methods{i}).average_robust_accuracy;
end

[max_effectiveness, best_defence_idx] = max(defence_effectiveness);
comprehensive_analysis.best_defence_method = defence_methods{best_defence_idx};
comprehensive_analysis.best_defence_performance = max_effectiveness;
comprehensive_analysis.defence_improvement = max_effectiveness - comprehensive_analysis.average_robust_accuracy;
end

% Vulnerability assessment
vulnerability_threshold = 0.7; % 70% accuracy threshold
vulnerable_attacks = attack_methods(overall_robustness < vulnerability_threshold);
comprehensive_analysis.vulnerable_to_attacks = vulnerable_attacks;
comprehensive_analysis.vulnerability_level = length(vulnerable_attacks) / length(attack_methods);

% Generate security score
comprehensive_analysis.security_score = calculateSecurityScore(comprehensive_analysis, model_config);
end
