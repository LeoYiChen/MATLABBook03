%% chapter_AI_ICT_ukf_historical.m
% Unscented Kalman Filter with Historical Context
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0303ICT/
% Listing label         : chapter_AI_ICT_ukf_historical
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [x_est, P_est, computational_metrics] = historicalUKF(measurements, process_model, obs_model, params)
% UKF implementation with insights from its development history
% Includes computational considerations and practical lessons learned

[d, T] = size(measurements);
n = length(params.x0);
L = n; % State dimension

% UKF parameters discovered through extensive simulation studies
% These values emerged from Julier and Uhlmann's empirical research
alpha = params.alpha; % Spread parameter (typically 1e-3)
beta = params.beta; % Distribution parameter (2 optimal for Gaussian)
kappa = params.kappa; % Secondary scaling parameter

% The lambda parameter balances numerical accuracy with computational cost
lambda = alpha^2 * (L + kappa) - L;
gamma = sqrt(L + lambda);

% Weight computations based on unscented transform theory
Wm = [lambda/(L + lambda), repmat(1/(2*(L + lambda)), 1, 2*L)];
Wc = Wm;
Wc(1) = Wc(1) + (1 - alpha^2 + beta); % Higher-order moment correction

% Storage for estimates and computational analysis
x_est = zeros(n, T);
P_est = zeros(n, n, T);
computational_metrics.matrix_ops = 0;
computational_metrics.function_evals = 0;

x = params.x0;
P = params.P0;

for t = 1:T
% Prediction step with sigma point generation
% The square root operation was computationally expensive in early implementations
tic;
[L_P, decomp_flag] = chol(P, 'lower');
if decomp_flag ~= 0
% Handle numerical conditioning issues
% This problem was particularly acute in early floating-point implementations
[U, S, V] = svd(P);
L_P = U * sqrt(S);
computational_metrics.matrix_ops = computational_metrics.matrix_ops + 1;
end
 
% Generate sigma points around current estimate
X = [x, x + gamma*L_P, x - gamma*L_P];

% Propagate sigma points through nonlinear process model
X_pred = zeros(n, 2*L + 1);
for i = 1:2*L + 1
    X_pred(:, i) = process_model(X(:, i), zeros(size(params.Q, 1), 1));
    computational_metrics.function_evals = computational_metrics.function_evals + 1;
end

% Compute predicted mean using weighted combination
x_pred = zeros(n, 1);
for i = 1:2*L + 1
    x_pred = x_pred + Wm(i) * X_pred(:, i);
end

% Compute predicted covariance with process noise
P_pred = params.Q;
for i = 1:2*L + 1
    diff = X_pred(:, i) - x_pred;
    P_pred = P_pred + Wc(i) * (diff * diff');
end

% Update step with measurement incorporation
[L_P_pred, decomp_flag] = chol(P_pred, 'lower');
if decomp_flag ~= 0
    [U, S, V] = svd(P_pred);
    L_P_pred = U * sqrt(S);
    computational_metrics.matrix_ops = computational_metrics.matrix_ops + 1;
end

% Generate new sigma points from predicted distribution
X_pred_new = [x_pred, x_pred + gamma*L_P_pred, x_pred - gamma*L_P_pred];

% Propagate through observation model
Z_pred = zeros(d, 2*L + 1);
for i = 1:2*L + 1
    Z_pred(:, i) = obs_model(X_pred_new(:, i), zeros(size(params.R, 1), 1));
    computational_metrics.function_evals = computational_metrics.function_evals + 1;
end

% Predicted observation mean
z_pred = zeros(d, 1);
for i = 1:2*L + 1
    z_pred = z_pred + Wm(i) * Z_pred(:, i);
end

% Innovation covariance and cross-covariance computation
Pzz = params.R;
Pxz = zeros(n, d);
for i = 1:2*L + 1
    z_diff = Z_pred(:, i) - z_pred;
    x_diff = X_pred_new(:, i) - x_pred;
    Pzz = Pzz + Wc(i) * (z_diff * z_diff');
    Pxz = Pxz + Wc(i) * (x_diff * z_diff');
end

% Kalman gain and state update
K = Pxz / Pzz;
innovation = measurements(:, t) - z_pred;

x = x_pred + K * innovation;
P = P_pred - K * Pzz * K';

% Store estimates and computational metrics
x_est(:, t) = x;
P_est(:, :, t) = P;
computational_metrics.time_per_iteration(t) = toc;
end

% The UKF's success led to numerous variants optimised for specific applications
% including square-root implementations and constrained state estimation
computational_metrics.total_time = sum(computational_metrics.time_per_iteration);
computational_metrics.avg_time_per_iteration = mean(computational_metrics.time_per_iteration);
end
