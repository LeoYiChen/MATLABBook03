%% chapter_AI_ICT_rl_network_optimisation.m
% Advanced Reinforcement Learning Framework for Network Optimisation
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0303ICT/
% Listing label         : chapter_AI_ICT_rl_network_optimisation
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [trained_agents, performance_analysis] = rlNetworkOptimisation(network_environment, config)
% Comprehensive reinforcement learning framework for communication network optimisation
% Implements multiple RL algorithms with sophisticated environment modelling
%
% Inputs:
% network_environment: structure defining network simulation environment
% config: configuration parameters for RL algorithms and training
% Outputs:
% trained_agents: cell array of trained RL agents for different scenarios
% performance_analysis: detailed performance comparison and analysis

fprintf('Initialising Reinforcement Learning Network Optimisation Framework...\n');

% Define RL algorithms to evaluate
rl_algorithms = {'DQN', 'DDPG', 'A3C', 'PPO'};
num_algorithms = length(rl_algorithms);

% Define network optimisation scenarios
scenarios = {'power_allocation', 'spectrum_access', 'routing_optimisation', 'load_balancing'};
num_scenarios = length(scenarios);

% Initialise storage structures
trained_agents = cell(num_algorithms, num_scenarios);
performance_analysis = struct();

% Create environment models for each scenario
environment_models = createEnvironmentModels(network_environment, scenarios, config);

for scenario_idx = 1:num_scenarios
scenario_name = scenarios{scenario_idx};
fprintf('\nOptimising %s scenario...\n', strrep(scenario_name, '_', ' '));
 
env_model = environment_models.*(scenario_name);
scenario_results = struct();

for alg_idx = 1:num_algorithms
    algorithm_name = rl_algorithms{alg_idx};
    fprintf('  Training %s agent...\n', algorithm_name);
    
    % Create and configure RL agent
    rl_agent = createRLAgent(algorithm_name, env_model, config);
    
    % Train the agent
    [trained_agent, training_metrics] = trainRLAgent(rl_agent, env_model, config);
    
    % Evaluate trained agent
    evaluation_metrics = evaluateRLAgent(trained_agent, env_model, config);
    
    % Store results
    trained_agents{alg_idx, scenario_idx} = trained_agent;
    scenario_results.*(algorithm_name) = struct();
    scenario_results.*(algorithm_name).training_metrics = training_metrics;
    scenario_results.*(algorithm_name).evaluation_metrics = evaluation_metrics;
    scenario_results.*(algorithm_name).agent = trained_agent;
    
    fprintf('    %s: Final Reward = %.3f, Convergence Episodes = %d\n', ...
            algorithm_name, evaluation_metrics.mean_episode_reward, ...
            training_metrics.convergence_episode);
end

performance_analysis.*(scenario_name) = scenario_results;
end

% Generate comprehensive comparative analysis
performance_analysis.comparative_analysis = generateComparativeAnalysis(performance_analysis, scenarios, rl_algorithms);

% Visualise results
visualiseRLResults(performance_analysis, config);

fprintf('\nReinforcement Learning Network Optimisation completed successfully.\n');
end

function environment_models = createEnvironmentModels(network_env, scenarios, config)
% Create environment models for different network optimisation scenarios

environment_models = struct();

for scenario_idx = 1:length(scenarios)
scenario = scenarios{scenario_idx};
 
switch scenario
    case 'power_allocation'
        environment_models.*(scenario) = createPowerAllocationEnvironment(network_env, config);
        
    case 'spectrum_access'
        environment_models.*(scenario) = createSpectrumAccessEnvironment(network_env, config);
        
    case 'routing_optimisation'
        environment_models.*(scenario) = createRoutingEnvironment(network_env, config);
        
    case 'load_balancing'
        environment_models.*(scenario) = createLoadBalancingEnvironment(network_env, config);
        
    otherwise
        error('Unknown scenario: %s', scenario);
end
end
end

function env_model = createPowerAllocationEnvironment(network_env, config)
% Create power allocation optimisation environment

env_model = struct();

% State space definition
% State includes: channel gains, interference levels, queue lengths, battery levels
num_users = network_env.num_users;
num_channels = network_env.num_channels;

env_model.state_dimension = num_users * (2 + num_channels) + num_channels;
env_model.action_dimension = num_users; % Power allocation for each user

% State bounds
env_model.state_bounds = struct();
env_model.state_bounds.low = zeros(env_model.state_dimension, 1);
env_model.state_bounds.high = ones(env_model.state_dimension, 1);

% Action bounds (power levels)
env_model.action_bounds = struct();
env_model.action_bounds.low = zeros(env_model.action_dimension, 1);
env_model.action_bounds.high = network_env.max_power * ones(env_model.action_dimension, 1);

% Environment parameters
env_model.num_users = num_users;
env_model.num_channels = num_channels;
env_model.max_power = network_env.max_power;
env_model.noise_power = network_env.noise_power;
env_model.path_loss_exponent = network_env.path_loss_exponent;

% Reward function parameters
env_model.reward_weights = struct();
env_model.reward_weights.throughput = config.power_allocation.throughput_weight;
env_model.reward_weights.energy = config.power_allocation.energy_weight;
env_model.reward_weights.fairness = config.power_allocation.fairness_weight;

% Environment functions
env_model.reset_function = @() resetPowerAllocationEnvironment(env_model);
env_model.step_function = @(state, action) stepPowerAllocationEnvironment(state, action, env_model);
env_model.reward_function = @(state, action, next_state) computePowerAllocationReward(state, action, next_state, env_model);
end

function rl_agent = createRLAgent(algorithm_name, env_model, config)
% Create RL agent based on specified algorithm

switch algorithm_name
case 'DQN'
rl_agent = createDQNAgent(env_model, config);
 
case 'DDPG'
    rl_agent = createDDPGAgent(env_model, config);
    
case 'A3C'
    rl_agent = createA3CAgent(env_model, config);
    
case 'PPO'
    rl_agent = createPPOAgent(env_model, config);
    
otherwise
    error('Unknown RL algorithm: %s', algorithm_name);
end
end

function agent = createDQNAgent(env_model, config)
% Create Deep Q-Network agent for discrete action spaces

% Discretise continuous action space if necessary
if isfield(env_model, 'action_discretisation')
num_actions = env_model.action_discretisation.num_discrete_actions;
else
% Default discretisation for continuous action spaces
num_actions = config.dqn.num_discrete_actions;

 
% Create action discretisation mapping
action_space = linspace(env_model.action_bounds.low(1), ...
                       env_model.action_bounds.high(1), ...
                       num_actions);
env_model.action_discretisation = struct();
env_model.action_discretisation.num_discrete_actions = num_actions;
env_model.action_discretisation.action_space = action_space;
end

% Create critic network (Q-network)
state_dim = env_model.state_dimension;
hidden_units = config.dqn.hidden_units;

critic_layers = [
featureInputLayer(state_dim, 'Normalization', 'none', 'Name', 'state')
fullyConnectedLayer(hidden_units(1), 'Name', 'fc1')
reluLayer('Name', 'relu1')
fullyConnectedLayer(hidden_units(2), 'Name', 'fc2')
reluLayer('Name', 'relu2')
fullyConnectedLayer(hidden_units(3), 'Name', 'fc3')
reluLayer('Name', 'relu3')
fullyConnectedLayer(num_actions, 'Name', 'output')];

critic_options = rlRepresentationOptions('LearnRate', config.dqn.learning_rate, ...
'GradientThreshold', 1, ...
'L2RegularizationFactor', config.dqn.l2_regularization);

critic = rlQValueRepresentation(critic_layers, ...
observationInfo, actionInfo, ...
'Observation', {'state'}, ...
critic_options);

% Create DQN agent
agent_options = rlDQNAgentOptions('SampleTime', config.sample_time, ...
'TargetSmoothFactor', config.dqn.target_smooth_factor, ...
'ExperienceBufferLength', config.dqn.buffer_length, ...
'MiniBatchSize', config.dqn.batch_size, ...
'NumStepsToLookAhead', config.dqn.n_steps);

agent = rlDQNAgent(critic, agent_options);

% Set exploration policy
agent.AgentOptions.EpsilonGreedyExploration.Epsilon = config.dqn.initial_epsilon;
agent.AgentOptions.EpsilonGreedyExploration.EpsilonDecay = config.dqn.epsilon_decay;
agent.AgentOptions.EpsilonGreedyExploration.EpsilonMin = config.dqn.min_epsilon;
end

function [trained_agent, training_metrics] = trainRLAgent(rl_agent, env_model, config)
% Train RL agent with comprehensive monitoring and logging

fprintf(' Starting agent training...\n');

% Training configuration
max_episodes = config.training.max_episodes;
max_steps_per_episode = config.training.max_steps_per_episode;

% Performance tracking
episode_rewards = zeros(max_episodes, 1);
episode_steps = zeros(max_episodes, 1);
convergence_window = config.training.convergence_window;
convergence_threshold = config.training.convergence_threshold;
convergence_episode = max_episodes;

% Training loop
for episode = 1:max_episodes
% Reset environment
current_state = env_model.reset_function();
episode_reward = 0;
step_count = 0;
 
for step = 1:max_steps_per_episode
    % Get action from agent
    action = getAction(rl_agent, current_state);
    
    % Execute action in environment
    [next_state, reward, is_done] = env_model.step_function(current_state, action);
    
    % Store experience (for off-policy methods)
    if ismethod(rl_agent, 'appendExperience')
        appendExperience(rl_agent, current_state, action, reward, next_state, is_done);
    end
    
    % Update agent (for online methods)
    if ismethod(rl_agent, 'learn')
        learn(rl_agent, current_state, action, reward, next_state, is_done);
    end
    
    % Update tracking variables
    current_state = next_state;
    episode_reward = episode_reward + reward;
    step_count = step_count + 1;
    
    if is_done
        break;
    end
end

% Store episode metrics
episode_rewards(episode) = episode_reward;
episode_steps(episode) = step_count;

% Check for convergence
if episode >= convergence_window
    recent_rewards = episode_rewards(episode-convergence_window+1:episode);
    if std(recent_rewards) < convergence_threshold && convergence_episode == max_episodes
        convergence_episode = episode;
        fprintf('    Agent converged at episode %d\n', episode);
    end
end

% Periodic progress reporting
if mod(episode, config.training.report_interval) == 0
    avg_reward = mean(episode_rewards(max(1, episode-99):episode));
    fprintf('    Episode %d: Average Reward = %.3f\n', episode, avg_reward);
end
end

% Package training metrics
training_metrics = struct();
training_metrics.episode_rewards = episode_rewards;
training_metrics.episode_steps = episode_steps;
training_metrics.convergence_episode = convergence_episode;
training_metrics.final_avg_reward = mean(episode_rewards(max(1, end-99):end));

% Return trained agent
trained_agent = rl_agent;

fprintf(' Training completed. Final average reward: %.3f\n', training_metrics.final_avg_reward);
end

function evaluation_metrics = evaluateRLAgent(trained_agent, env_model, config)
% Comprehensive evaluation of trained RL agent

num_eval_episodes = config.evaluation.num_episodes;
eval_rewards = zeros(num_eval_episodes, 1);
eval_steps = zeros(num_eval_episodes, 1);

% Disable exploration for evaluation
if isprop(trained_agent, 'UseExploration')
trained_agent.UseExploration = false;
end

fprintf(' Evaluating trained agent...\n');

for episode = 1:num_eval_episodes
current_state = env_model.reset_function();
episode_reward = 0;
step_count = 0;

 
for step = 1:config.evaluation.max_steps_per_episode
    % Get action from agent (no exploration)
    action = getAction(trained_agent, current_state);
    
    % Execute action
    [next_state, reward, is_done] = env_model.step_function(current_state, action);
    
    current_state = next_state;
    episode_reward = episode_reward + reward;
    step_count = step_count + 1;
    
    if is_done
        break;
    end
end

eval_rewards(episode) = episode_reward;
eval_steps(episode) = step_count;
end

% Compute evaluation metrics
evaluation_metrics = struct();
evaluation_metrics.mean_episode_reward = mean(eval_rewards);
evaluation_metrics.std_episode_reward = std(eval_rewards);
evaluation_metrics.mean_episode_steps = mean(eval_steps);
evaluation_metrics.success_rate = sum(eval_rewards > config.evaluation.success_threshold) / num_eval_episodes;
evaluation_metrics.all_episode_rewards = eval_rewards;

fprintf(' Evaluation completed. Mean reward: %.3f \pm %.3f\n', ...
evaluation_metrics.mean_episode_reward, evaluation_metrics.std_episode_reward);
end
