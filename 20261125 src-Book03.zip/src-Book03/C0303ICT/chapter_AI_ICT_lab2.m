%% chapter_AI_ICT_lab2.m
% Kalman Filter for Channel Tracking.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0303ICT/
% Listing label         : chapter_AI_ICT_lab2
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% MATLABBook02_Chapter01_Lab2.m
% Author: Dr Leo Chen
% Version: 1.0 (MATLAB R2024b)
% Description: Kalman filter for tracking channel gain

% Parameters
F = 1; H = 1; Q = 1e-5; R = 1e-2;
trueGain = cumsum(randn(1,100) * 0.01);
measurements = trueGain + sqrt(R) * randn(size(trueGain));

% Kalman filter initialisation
x_est = 0; P_est = 1;

for t = 1:length(measurements)
    % Prediction
    x_pred = F * x_est;
    P_pred = F * P_est * F' + Q;
    
    % Update
    K = P_pred * H' / (H * P_pred * H' + R);
    x_est = x_pred + K * (measurements(t) - H * x_pred);
    P_est = (1 - K * H) * P_pred;
    
    disp(['Step ', num2str(t), ': Estimated Gain = ', num2str(x_est)]);
end
