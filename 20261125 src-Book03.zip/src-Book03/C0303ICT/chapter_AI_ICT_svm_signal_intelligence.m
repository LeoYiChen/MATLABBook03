%% chapter_AI_ICT_svm_signal_intelligence.m
% SVM-Based Signal Intelligence Framework for Communication Systems
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0303ICT/
% Listing label         : chapter_AI_ICT_svm_signal_intelligence
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [trained_models, performance_metrics] = svmSignalIntelligence(signal_data, config)
% Comprehensive SVM-based signal intelligence system for communication applications
% Demonstrates classical supervised learning techniques with modern enhancements
%
% Inputs:
% signal_data: structure containing training and test datasets
% config: configuration parameters for SVM training and evaluation
% Outputs:
% trained_models: cell array of trained SVM models for different tasks
% performance_metrics: comprehensive performance evaluation results

fprintf('Initialising SVM Signal Intelligence Framework...\n');

% Define signal intelligence tasks
tasks = {'modulation_classification', 'interference_detection', ...
'signal_quality_prediction', 'spectrum_occupancy'};
num_tasks = length(tasks);

% Initialise storage structures
trained_models = cell(num_tasks, 1);
performance_metrics = struct();

for task_idx = 1:num_tasks
task_name = tasks{task_idx};
fprintf('Training SVM for %s...\n', strrep(task_name, '_', ' '));

 
% Extract task-specific data
task_data = signal_data.*(task_name);
X_train = task_data.features_train;
y_train = task_data.labels_train;
X_test = task_data.features_test;
y_test = task_data.labels_test;

% Feature preprocessing and normalisation
[X_train_norm, normalisation_params] = preprocessFeatures(X_train, config);
X_test_norm = applyNormalisation(X_test, normalisation_params);

% Determine problem type (classification vs regression)
if strcmp(task_name, 'signal_quality_prediction')
    % Regression task using Support Vector Regression (SVR)
    [model, training_metrics] = trainSVR(X_train_norm, y_train, config);
    [test_predictions, test_metrics] = evaluateSVR(model, X_test_norm, y_test);
else
    % Classification task using SVM with RBF kernel
    [model, training_metrics] = trainSVMClassifier(X_train_norm, y_train, config);
    [test_predictions, test_metrics] = evaluateSVMClassifier(model, X_test_norm, y_test);
end

% Store trained model with metadata
trained_models{task_idx} = struct();
trained_models{task_idx}.model = model;
trained_models{task_idx}.task_name = task_name;
trained_models{task_idx}.normalisation_params = normalisation_params;
trained_models{task_idx}.training_metrics = training_metrics;

% Store performance metrics
performance_metrics.*(task_name) = test_metrics;
performance_metrics.*(task_name).predictions = test_predictions;

fprintf('  Completed %s: Accuracy/R? = %.3f\n', task_name, test_metrics.primary_metric);
end

% Generate comprehensive analysis
performance_metrics.summary = generatePerformanceSummary(performance_metrics, tasks);
performance_metrics.cross_task_analysis = analyseCrossTaskPerformance(trained_models, signal_data);

% Visualise results
visualiseResults(performance_metrics, config);

fprintf('SVM Signal Intelligence Framework training completed successfully.\n');
end

function [X_norm, norm_params] = preprocessFeatures(X, config)
% Advanced feature preprocessing with multiple normalisation options

[num_samples, num_features] = size(X);

% Feature selection based on mu*tual information (simplified)
if config.perform_feature_selection
feature_importance = zeros(num_features, 1);
for feat = 1:num_features
% Compute feature variance as simple importance measure
feature_importance(feat) = var(X(:, feat));
end

 
% Select top features
[~, sorted_idx] = sort(feature_importance, 'descend');
selected_features = sorted_idx(1:min(config.max_features, num_features));
X = X(:, selected_features);
norm_params.selected_features = selected_features;
else
norm_params.selected_features = 1:num_features;
end

% Multiple normalisation strategies
switch config.normalisation_method
case 'zscore'
% Z-score normalisation (zero mean, unit variance)
norm_params.mean_vals = mean(X, 1);
norm_params.std_vals = std(X, 0, 1);
% Handle zero standard deviation
norm_params.std_vals(norm_params.std_vals == 0) = 1;
X_norm = (X - norm_params.mean_vals) ./ norm_params.std_vals;
 
case 'minmax'
    % Min-max normalisation to [0, 1]
    norm_params.min_vals = min(X, [], 1);
    norm_params.max_vals = max(X, [], 1);
    range_vals = norm_params.max_vals - norm_params.min_vals;
    range_vals(range_vals == 0) = 1; % Handle constant features
    X_norm = (X - norm_params.min_vals) ./ range_vals;
    
case 'robust'
    % Robust normalisation using median and MAD
    norm_params.median_vals = median(X, 1);
    norm_params.mad_vals = mad(X, 1, 1);
    norm_params.mad_vals(norm_params.mad_vals == 0) = 1;
    X_norm = (X - norm_params.median_vals) ./ norm_params.mad_vals;
    
otherwise
    % No normalisation
    X_norm = X;
    norm_params.method = 'none';
end

norm_params.method = config.normalisation_method;
end

function X_norm = applyNormalisation(X, norm_params)
% Apply previously computed normalisation parameters

% Apply feature selection
X = X(:, norm_params.selected_features);

% Apply normalisation
switch norm_params.method
case 'zscore'
X_norm = (X - norm_params.mean_vals) ./ norm_params.std_vals;
case 'minmax'
range_vals = norm_params.max_vals - norm_params.min_vals;
X_norm = (X - norm_params.min_vals) ./ range_vals;
case 'robust'
X_norm = (X - norm_params.median_vals) ./ norm_params.mad_vals;
otherwise
X_norm = X;
end
end

function [model, metrics] = trainSVMClassifier(X_train, y_train, config)
% Train SVM classifier with hyperparameter optimisation

% Convert labels to categorical if necessary
if isnumeric(y_train)
unique_labels = unique(y_train);
if length(unique_labels) <= 10 % Assume classification if few unique values
y_train = categorical(y_train);
end
end

% Grid search for hyperparameter optimisation
C_values = config.C_range;
sigma_values = config.sigma_range;
best_accuracy = 0;
best_params = struct();

fprintf(' Performing hyperparameter optimisation...\n');

for C = C_values
for sigma = sigma_values
% 5-fold cross-validation
cv_accuracy = performCrossValidation(X_train, y_train, C, sigma, 5);

 
    if cv_accuracy > best_accuracy
        best_accuracy = cv_accuracy;
        best_params.C = C;
        best_params.sigma = sigma;
    end
end
end

fprintf(' Best parameters: C = %.3f, sigma  = %.3f (CV Accuracy: %.3f)\n', ...
best_params.C, best_params.sigma, best_accuracy);

% Train final model with best parameters
t = templateSVM('KernelFunction', 'rbf', ...
'BoxConstraint', best_params.C, ...
'KernelScale', best_params.sigma);

if length(unique(y_train)) > 2
% Multi-class classification
model = fitcecoc(X_train, y_train, 'Learners', t);
else
% Binary classification
model = fitcsvm(X_train, y_train, 'KernelFunction', 'rbf', ...
'BoxConstraint', best_params.C, ...
'KernelScale', best_params.sigma);
end

% Training metrics
train_predictions = predict(model, X_train);
train_accuracy = mean(train_predictions == y_train);

metrics = struct();
metrics.best_parameters = best_params;
metrics.cv_accuracy = best_accuracy;
metrics.train_accuracy = train_accuracy;
metrics.num_support_vectors = model.NumSupportVectors;
end

function cv_accuracy = performCrossValidation(X, y, C, sigma, k_folds)
% Perform k-fold cross-validation for SVM hyperparameter selection

n_samples = size(X, 1);
fold_size = floor(n_samples / k_folds);
accuracies = zeros(k_folds, 1);

% Create random permutation for cross-validation
perm = randperm(n_samples);

for fold = 1:k_folds
% Define test indices for current fold
test_start = (fold - 1) * fold_size + 1;
if fold == k_folds
test_end = n_samples; % Include remaining samples in last fold
else
test_end = fold * fold_size;
end

 
test_indices = perm(test_start:test_end);
train_indices = setdiff(perm, test_indices);

% Split data
X_fold_train = X(train_indices, :);
y_fold_train = y(train_indices);
X_fold_test = X(test_indices, :);
y_fold_test = y(test_indices);

% Train SVM on fold
try
    if length(unique(y_fold_train)) > 2
        t = templateSVM('KernelFunction', 'rbf', ...
                       'BoxConstraint', C, ...
                       'KernelScale', sigma);
        fold_model = fitcecoc(X_fold_train, y_fold_train, 'Learners', t);
    else
        fold_model = fitcsvm(X_fold_train, y_fold_train, ...
                           'KernelFunction', 'rbf', ...
                           'BoxConstraint', C, ...
                           'KernelScale', sigma);
    end
    
    % Evaluate on fold test set
    fold_predictions = predict(fold_model, X_fold_test);
    accuracies(fold) = mean(fold_predictions == y_fold_test);
catch
    % Handle training failures (e.g., insufficient data)
    accuracies(fold) = 0;
end
end

cv_accuracy = mean(accuracies);
end

function [predictions, metrics] = evaluateSVMClassifier(model, X_test, y_test)
% Comprehensive evaluation of trained SVM classifier

% Generate predictions and probability estimates
[predictions, scores] = predict(model, X_test);

% Basic accuracy metrics
accuracy = mean(predictions == y_test);

% Confusion matrix analysis
if isa(y_test, 'categorical') || isa(y_test, 'string')
unique_labels = unique(y_test);
else
unique_labels = unique(y_test);
end

confusion_matrix = confusionmat(y_test, predictions);

% Per-class metrics
num_classes = length(unique_labels);
precision = zeros(num_classes, 1);
recall = zeros(num_classes, 1);
f1_score = zeros(num_classes, 1);

for class_idx = 1:num_classes
tp = confusion_matrix(class_idx, class_idx);
fp = sum(confusion_matrix(:, class_idx)) - tp;
fn = sum(confusion_matrix(class_idx, :)) - tp;

 
if tp + fp > 0
    precision(class_idx) = tp / (tp + fp);
end

if tp + fn > 0
    recall(class_idx) = tp / (tp + fn);
end

if precision(class_idx) + recall(class_idx) > 0
    f1_score(class_idx) = 2 * precision(class_idx) * recall(class_idx) / ...
                         (precision(class_idx) + recall(class_idx));
end
end

% Aggregate metrics
macro_precision = mean(precision);
macro_recall = mean(recall);
macro_f1 = mean(f1_score);

% Confidence analysis
if size(scores, 2) > 1
% Multi-class: use maximum probability as confidence
confidence_scores = max(scores, [], 2);
else
% Binary: use absolute score as confidence
confidence_scores = abs(scores);
end

mean_confidence = mean(confidence_scores);
confidence_std = std(confidence_scores);

% Package results
metrics = struct();
metrics.primary_metric = accuracy;
metrics.accuracy = accuracy;
metrics.confusion_matrix = confusion_matrix;
metrics.precision = precision;
metrics.recall = recall;
metrics.f1_score = f1_score;
metrics.macro_precision = macro_precision;
metrics.macro_recall = macro_recall;
metrics.macro_f1 = macro_f1;
metrics.mean_confidence = mean_confidence;
metrics.confidence_std = confidence_std;
metrics.unique_labels = unique_labels;
end
