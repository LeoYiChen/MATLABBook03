%% chapter_AI_ICT_q_learning_allocation.m
% Q-Learning for Dynamic Resource Allocation
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0303ICT/
% Listing label         : chapter_AI_ICT_q_learning_allocation
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [optimal_policy, q_table, learning_curve] = qLearningResourceAllocation(network_env, rl_params)
% Q-learning algorithm for dynamic resource allocation in wireless networks
% Inputs:
% network_env: structure containing network environment parameters
% rl_params: reinforcement learning parameters (alpha, gamma, epsilon, episodes)
% Outputs:
% optimal_policy: learned policy mapping states to actions
% q_table: final Q-value table
% learning_curve: episode rewards for convergence analysis

num_states = network_env.num_states;
num_actions = network_env.num_actions;
num_episodes = rl_params.num_episodes;

% Initialise Q-table and parameters
q_table = zeros(num_states, num_actions);
learning_curve = zeros(num_episodes, 1);
epsilon = rl_params.epsilon_start;
epsilon_decay = (rl_params.epsilon_start - rl_params.epsilon_end) / num_episodes;

for episode = 1:num_episodes
% Reset environment and initialise episode
current_state = randi(num_states); % Random initial state
episode_reward = 0;
steps = 0;
 
while steps < rl_params.max_steps_per_episode
    % Epsilon-greedy action selection
    if rand < epsilon
        action = randi(num_actions); % Exploration
    else
        [~, action] = max(q_table(current_state, :)); % Exploitation
    end
    
    % Take action and observe result
    [next_state, reward, is_terminal] = takeNetworkAction(current_state, action, network_env);
    
    % Q-learning update rule
    best_next_action_value = max(q_table(next_state, :));
    td_target = reward + rl_params.gamma * best_next_action_value;
    td_error = td_target - q_table(current_state, action);
    q_table(current_state, action) = q_table(current_state, action) + ...
                                     rl_params.alpha * td_error;
    
    % Update state and accumulate reward
    current_state = next_state;
    episode_reward = episode_reward + reward;
    steps = steps + 1;
    
    if is_terminal
        break;
    end
end

% Store episode performance and decay exploration
learning_curve(episode) = episode_reward;
epsilon = max(rl_params.epsilon_end, epsilon - epsilon_decay);

% Display progress
if mod(episode, 100) == 0
    avg_reward = mean(learning_curve(max(1, episode-99):episode));
    fprintf('Episode %d: Average Reward = %.2f, Epsilon = %.3f\n', ...
            episode, avg_reward, epsilon);
end
end

% Extract optimal policy from Q-table
[~, optimal_policy] = max(q_table, [], 2);
end

function [next_state, reward, is_terminal] = takeNetworkAction(state, action, env)
% Simulate network environment response to resource allocation action
% This function models the network dynamics and reward structure

% Decode state into network parameters
[num_users, traffic_load, channel_quality] = decodeNetworkState(state, env);

% Decode action into resource allocation strategy
[power_allocation, bandwidth_allocation] = decodeNetworkAction(action, env);

% Compute network performance metrics
throughput = computeNetworkThroughput(num_users, traffic_load, channel_quality, ...
power_allocation, bandwidth_allocation, env);
delay = computeAverageDelay(num_users, traffic_load, throughput, env);
energy_consumption = computeEnergyConsumption(power_allocation, env);

% Reward function balancing throughput, delay, and energy efficiency
reward = env.throughput_weight * throughput - ...
env.delay_weight * delay - ...
env.energy_weight * energy_consumption;

% Determine next state based on network dynamics
next_state = updateNetworkState(state, action, env);

% Terminal condition (end of scheduling frame)
is_terminal = (rand < env.terminal_probability);
end
