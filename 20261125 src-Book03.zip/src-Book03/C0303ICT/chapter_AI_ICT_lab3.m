%% chapter_AI_ICT_lab3.m
% UKF for Nonlinear Channel Tracking.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0303ICT/
% Listing label         : chapter_AI_ICT_lab3
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% MATLABBook02_Chapter01_Lab3.m
% Author: Dr Leo Chen
% Version: 1.0 (MATLAB R2024b)
% Description: UKF for nonlinear channel tracking

process_model = @(x, w) 0.5*x + 25*x/(1+x^2) + 8*cos(1.2) + w;
obs_model = @(x, v) x^2/20 + v;

% (Implementation similar to Listing~\ref{chapter_AI_ICT_ukf_example})
