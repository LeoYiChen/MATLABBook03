%% chapter_AI_ICT_deep_modulation_classification.m
% Comprehensive Deep Learning Framework for Modulation Classification
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0303ICT/
% Listing label         : chapter_AI_ICT_deep_modulation_classification
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [classification_results, model_comparison] = deepModulationClassification(signal_dataset, config)
% Advanced deep learning framework for automatic modulation classification
% Implements multiple architectures with comprehensive evaluation and comparison
%
% Inputs:
% signal_dataset: structure containing training/validation/test data
% config: configuration parameters for different network architectures
% Outputs:
% classification_results: detailed results for each architecture
% model_comparison: comparative analysis of different approaches

fprintf('Initialising Deep Learning Modulation Classification Framework...\n');

% Define modulation schemes to classify
modulation_schemes = config.modulation_schemes;
num_classes = length(modulation_schemes);

% Architecture types to evaluate
architectures = {'CNN_Spectrogram', 'CNN_IQ', 'LSTM_TimeSeries', 'Hybrid_CNN_LSTM'};
num_architectures = length(architectures);

% Initialise results storage
classification_results = struct();
model_comparison = struct();

% Data preprocessing for different input representations
processed_data = preprocessSignalData(signal_dataset, config);

for arch_idx = 1:num_architectures
architecture_name = architectures{arch_idx};
fprintf('\nTraining %s architecture...\n', strrep(architecture_name, '_', ' '));

 
% Select appropriate data representation
arch_data = selectDataRepresentation(processed_data, architecture_name);

% Create network architecture
[layers, training_options] = createArchitecture(architecture_name, config, num_classes);

% Train the network
[trained_net, training_info] = trainDeepNetwork(arch_data, layers, training_options);

% Comprehensive evaluation
evaluation_results = evaluateModulationClassifier(trained_net, arch_data.test, config);

% Store results
classification_results.*(architecture_name) = struct();
classification_results.*(architecture_name).network = trained_net;
classification_results.*(architecture_name).training_info = training_info;
classification_results.*(architecture_name).evaluation = evaluation_results;
classification_results.*(architecture_name).architecture_type = architecture_name;

fprintf('  %s: Test Accuracy = %.2f%%, Inference Time = %.2f ms\n', ...
        architecture_name, evaluation_results.accuracy * 100, ...
        evaluation_results.mean_inference_time * 1000);
end

% Generate comparative analysis
model_comparison = generateModelComparison(classification_results, architectures);

% Visualise comparative results
visualiseClassificationResults(classification_results, model_comparison, config);

fprintf('\nDeep Learning Modulation Classification Framework completed successfully.\n');
end

function processed_data = preprocessSignalData(signal_dataset, config)
% Comprehensive preprocessing for multiple input representations

fprintf(' Preprocessing signal data for multiple representations...\n');

% Extract raw I/Q data
train_signals = signal_dataset.train.iq_data;
train_labels = signal_dataset.train.labels;
val_signals = signal_dataset.validation.iq_data;
val_labels = signal_dataset.validation.labels;
test_signals = signal_dataset.test.iq_data;
test_labels = signal_dataset.test.labels;

processed_data = struct();

% 1. Spectrogram representation for CNN
fprintf(' Generating spectrograms...\n');
[train_spectrograms, spec_params] = generateSpectrograms(train_signals, config);
val_spectrograms = generateSpectrograms(val_signals, config, spec_params);
test_spectrograms = generateSpectrograms(test_signals, config, spec_params);

processed_data.spectrogram = struct();
processed_data.spectrogram.train = struct('features', train_spectrograms, 'labels', train_labels);
processed_data.spectrogram.validation = struct('features', val_spectrograms, 'labels', val_labels);
processed_data.spectrogram.test = struct('features', test_spectrograms, 'labels', test_labels);

% 2. I/Q constellation representation
fprintf(' Preparing I/Q constellation data...\n');
[train_iq_formatted, iq_params] = formatIQData(train_signals, config);
val_iq_formatted = formatIQData(val_signals, config, iq_params);
test_iq_formatted = formatIQData(test_signals, config, iq_params);

processed_data.iq_constellation = struct();
processed_data.iq_constellation.train = struct('features', train_iq_formatted, 'labels', train_labels);
processed_data.iq_constellation.validation = struct('features', val_iq_formatted, 'labels', val_labels);
processed_data.iq_constellation.test = struct('features', test_iq_formatted, 'labels', test_labels);

% 3. Time series representation for LSTM
fprintf(' Formatting time series data...\n');
[train_timeseries, ts_params] = formatTimeSeriesData(train_signals, config);
val_timeseries = formatTimeSeriesData(val_signals, config, ts_params);
test_timeseries = formatTimeSeriesData(test_signals, config, ts_params);

processed_data.timeseries = struct();
processed_data.timeseries.train = struct('features', train_timeseries, 'labels', train_labels);
processed_data.timeseries.validation = struct('features', val_timeseries, 'labels', val_labels);
processed_data.timeseries.test = struct('features', test_timeseries, 'labels', test_labels);

% Store preprocessing parameters
processed_data.preprocessing_params = struct();
processed_data.preprocessing_params.spectrogram = spec_params;
processed_data.preprocessing_params.iq_constellation = iq_params;
processed_data.preprocessing_params.timeseries = ts_params;
end

function [spectrograms, params] = generateSpectrograms(signals, config, existing_params)
% Generate spectrograms for CNN input

if nargin < 3
% First call - compute parameters
params = struct();
params.window_length = config.spectrogram.window_length;
params.overlap = config.spectrogram.overlap;
params.nfft = config.spectrogram.nfft;
params.normalisation = config.spectrogram.normalisation;
else
% Subsequent calls - use existing parameters
params = existing_params;
end

num_signals = size(signals, 1);
signal_length = size(signals, 2);

% Compute representative spectrogram size
temp_signal = signals(1, :);
[S_temp, ~, ~] = spectrogram(temp_signal, params.window_length, ...
params.overlap, params.nfft);
[freq_bins, time_bins] = size(S_temp);

% Preallocate spectrogram array
spectrograms = zeros(freq_bins, time_bins, 1, num_signals);

for signal_idx = 1:num_signals
signal = signals(signal_idx, :);

 
% Compute spectrogram
[S, F, T] = spectrogram(signal, params.window_length, ...
                       params.overlap, params.nfft);

% Convert to magnitude and apply normalisation
S_mag = abs(S);

switch params.normalisation
    case 'log'
        S_normalised = 10 * log10(S_mag + eps);
    case 'linear'
        S_normalised = S_mag;
    case 'zscore'
        S_normalised = (S_mag - mean(S_mag(:))) / std(S_mag(:));
    otherwise
        S_normalised = S_mag;
end

% Store as 4*D array for CNN (Height x Width x Channels x Samples)
spectrograms(:, :, 1, signal_idx) = S_normalised;
end

% Store frequency and time vectors for later use
params.frequency_vector = F;
params.time_vector = T;
end

function [iq_formatted, params] = formatIQData(signals, config, existing_params)
% Format I/Q data for constellation-based CNN

if nargin < 3
% First call - compute parameters
params = struct();
params.constellation_size = config.iq_constellation.size;
params.normalisation = config.iq_constellation.normalisation;

 
% Compute normalisation parameters from training data
all_signals = signals(:);
params.mean_val = mean(all_signals);
params.std_val = std(all_signals);
params.min_val = min(real(all_signals));
params.max_val = max(real(all_signals));
else
% Subsequent calls - use existing parameters
params = existing_params;
end

num_signals = size(signals, 1);
signal_length = size(signals, 2);

% Determine samples per constellation point
samples_per_point = floor(signal_length / params.constellation_size^2);

% Preallocate formatted array
iq_formatted = zeros(params.constellation_size, params.constellation_size, 2, num_signals);

for signal_idx = 1:num_signals
signal = signals(signal_idx, :);

 
% Normalise signal
switch params.normalisation
    case 'zscore'
        signal_norm = (signal - params.mean_val) / params.std_val;
    case 'minmax'
        signal_norm = (signal - params.min_val) / (params.max_val - params.min_val);
    otherwise
        signal_norm = signal;
end

% Reshape into constellation grid
signal_samples = signal_norm(1:samples_per_point * params.constellation_size^2);
signal_reshaped = reshape(signal_samples, params.constellation_size, params.constellation_size);

% Separate I and Q components
iq_formatted(:, :, 1, signal_idx) = real(signal_reshaped);
iq_formatted(:, :, 2, signal_idx) = imag(signal_reshaped);
end
end

function [timeseries_data, params] = formatTimeSeriesData(signals, config, existing_params)
% Format time series data for LSTM networks

if nargin < 3
% First call - compute parameters
params = struct();
params.sequence_length = config.timeseries.sequence_length;
params.feature_type = config.timeseries.feature_type;
params.normalisation = config.timeseries.normalisation;

 
% Compute normalisation parameters
all_signals = signals(:);
params.mean_val = mean(all_signals);
params.std_val = std(all_signals);
else
% Subsequent calls - use existing parameters
params = existing_params;
end

num_signals = size(signals, 1);
signal_length = size(signals, 2);

% Determine number of sequences per signal
num_sequences = floor(signal_length / params.sequence_length);

% Determine feature dimension based on feature type
switch params.feature_type
case 'iq_separate'
feature_dim = 2; % I and Q as separate features
case 'magnitude_phase'
feature_dim = 2; % Magnitude and phase
case 'iq_complex'
feature_dim = 1; % Complex I/Q as single feature
otherwise
feature_dim = 2;
end

% Preallocate timeseries array
timeseries_data = zeros(params.sequence_length, feature_dim, num_signals * num_sequences);

data_idx = 1;
for signal_idx = 1:num_signals
signal = signals(signal_idx, :);

 
% Normalise signal
switch params.normalisation
    case 'zscore'
        signal_norm = (signal - params.mean_val) / params.std_val;
    case 'local_zscore'
        signal_norm = (signal - mean(signal)) / std(signal);
    otherwise
        signal_norm = signal;
end

for seq_idx = 1:num_sequences
    start_idx = (seq_idx - 1) * params.sequence_length + 1;
    end_idx = seq_idx * params.sequence_length;
    
    sequence = signal_norm(start_idx:end_idx);
    
    % Extract features based on feature type
    switch params.feature_type
        case 'iq_separate'
            timeseries_data(:, 1, data_idx) = real(sequence);
            timeseries_data(:, 2, data_idx) = imag(sequence);
        case 'magnitude_phase'
            timeseries_data(:, 1, data_idx) = abs(sequence);
            timeseries_data(:, 2, data_idx) = angle(sequence);
        case 'iq_complex'
            timeseries_data(:, 1, data_idx) = sequence;
        otherwise
            timeseries_data(:, 1, data_idx) = real(sequence);
            timeseries_data(:, 2, data_idx) = imag(sequence);
    end
    
    data_idx = data_idx + 1;
end
end
end

function [layers, training_options] = createArchitecture(architecture_name, config, num_classes)
% Create network architecture based on specified type

switch architecture_name
case 'CNN_Spectrogram'
layers = createCNNSpectrogramArchitecture(config, num_classes);
 
case 'CNN_IQ'
    layers = createCNNIQArchitecture(config, num_classes);
    
case 'LSTM_TimeSeries'
    layers = createLSTMArchitecture(config, num_classes);
    
case 'Hybrid_CNN_LSTM'
    layers = createHybridArchitecture(config, num_classes);
    
otherwise
    error('Unknown architecture: %s', architecture_name);
end

% Common training options with architecture-specific modifications
training_options = trainingOptions('adam', ...
'MaxEpochs', config.training.max_epochs, ...
'MiniBatchSize', config.training.batch_size, ...
'InitialLearnRate', config.training.initial_lr, ...
'LearnRateSchedule', 'piecewise', ...
'LearnRateDropPeriod', config.training.lr_drop_period, ...
'LearnRateDropFactor', config.training.lr_drop_factor, ...
'L2Regularization', config.training.l2_regularization, ...
'GradientThreshold', 1, ...
'ExecutionEnvironment', 'auto', ...
'Shuffle', 'every-epoch', ...
'Verbose', false, ...
'Plots', 'none');
end

function layers = createCNNSpectrogramArchitecture(config, num_classes)
% Create CNN architecture for spectrogram input

input_size = [config.spectrogram.freq_bins, config.spectrogram.time_bins, 1];

layers = [
imageInputLayer(input_size, 'Name', 'input')

 
% First convolutional block
convolution2dLayer([5, 5], 32, 'Padding', 'same', 'Name', 'conv1')
batchNormalizationLayer('Name', 'bn1')
reluLayer('Name', 'relu1')
maxPooling2dLayer([2, 2], 'Stride', [2, 2], 'Name', 'pool1')

% Second convolutional block
convolution2dLayer([3, 3], 64, 'Padding', 'same', 'Name', 'conv2')
batchNormalizationLayer('Name', 'bn2')
reluLayer('Name', 'relu2')
maxPooling2dLayer([2, 2], 'Stride', [2, 2], 'Name', 'pool2')

% Third convolutional block
convolution2dLayer([3, 3], 128, 'Padding', 'same', 'Name', 'conv3')
batchNormalizationLayer('Name', 'bn3')
reluLayer('Name', 'relu3')
maxPooling2dLayer([2, 2], 'Stride', [2, 2], 'Name', 'pool3')

% Fourth convolutional block
convolution2dLayer([3, 3], 256, 'Padding', 'same', 'Name', 'conv4')
batchNormalizationLayer('Name', 'bn4')
reluLayer('Name', 'relu4')

% Global average pooling
globalAveragePooling2dLayer('Name', 'gap')

% Fully connected layers
fullyConnectedLayer(512, 'Name', 'fc1')
dropoutLayer(0.5, 'Name', 'dropout1')
reluLayer('Name', 'relu_fc1')

fullyConnectedLayer(256, 'Name', 'fc2')
dropoutLayer(0.3, 'Name', 'dropout2')
reluLayer('Name', 'relu_fc2')

% Output layer
fullyConnectedLayer(num_classes, 'Name', 'fc_output')
softmaxLayer('Name', 'softmax')
classificationLayer('Name', 'classification')];
end
