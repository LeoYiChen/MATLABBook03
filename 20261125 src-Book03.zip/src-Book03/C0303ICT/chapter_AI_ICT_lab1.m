%% chapter_AI_ICT_lab1.m
% Shannon Capacity Calculation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0303ICT/
% Listing label         : chapter_AI_ICT_lab1
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% MATLABBook02_Chapter01_Lab1.m
% Author: Dr Leo Chen
% Version: 1.0 (MATLAB R2024b)
% Description: Computes Shannon capacity of AWGN channel

% Parameters
bandwidthHz = 1e6; % 1 MHz
signalPowerW = 0.01; % 10 mW
noisePowerW = 1e-6; % 1 uW

% Shannon capacity formula
capacity_bps = bandwidthHz * log2(1 + signalPowerW / noisePowerW);

% Display result
disp(['\textbf{Channel Capacity:} ', num2str(capacity_bps/1e6), ' Mbps']);
