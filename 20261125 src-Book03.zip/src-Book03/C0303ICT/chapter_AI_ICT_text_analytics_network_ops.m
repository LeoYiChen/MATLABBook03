%% chapter_AI_ICT_text_analytics_network_ops.m
% Advanced Text Analytics Framework for Network Operations Intelligence
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0303ICT/
% Listing label         : chapter_AI_ICT_text_analytics_network_ops
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [analytics_results, insights_summary] = networkOperationsTextAnalytics(text_data, analytics_config)
% Comprehensive text analytics framework for extracting intelligence from network operations data
% Processes log files, incident reports, and operational documentation for actionable insights
%
% Inputs:
% text_data: structure containing various types of operational text data
% analytics_config: configuration parameters for different analytics tasks
% Outputs:
% analytics_results: detailed analysis results for each text analytics task
% insights_summary: high-level summary of extracted insights and recommendations

fprintf('Initialising Network Operations Text Analytics Framework...\n');

% Validate Text Analytics Toolbox availability
if ~license('test', 'Text_Analytics_Toolbox')
error('Text Analytics Toolbox license not available. Please ensure Text Analytics Toolbox is installed.');
end

% Define text analytics tasks for network operations
analytics_tasks = {'log_analysis', 'incident_classification', 'sentiment_analysis', ...
'topic_modeling', 'anomaly_detection', 'predictive_maintenance', ...
'root_cause_analysis', 'knowledge_extraction'};
num_tasks = length(analytics_tasks);

% Initialise comprehensive results structure
analytics_results = struct();
insights_summary = struct();

% Configure text preprocessing pipeline
preprocessing_config = configureTextPreprocessing(analytics_config);

% Load and prepare text analytics models
fprintf('Loading text analytics models and resources...\n');
analytics_models = loadTextAnalyticsModels(analytics_config);

% Process each analytics task
for task_idx = 1:num_tasks
task_name = analytics_tasks{task_idx};
fprintf('\nProcessing %s...\n', strrep(task_name, '_', ' '));

 
% Extract task-specific text data
if isfield(text_data, task_name)
    task_text_data = text_data.*(task_name);
    
    % Comprehensive text analysis pipeline
    [task_results, task_insights] = processTextAnalyticsTask(task_text_data, ...
                                                           task_name, ...
                                                           analytics_models, ...
                                                           preprocessing_config, ...
                                                           analytics_config);
    
    % Store results and insights
    analytics_results.*(task_name) = task_results;
    insights_summary.*(task_name) = task_insights;
    
    fprintf('  Completed %s: processed %d documents, extracted %d insights\n', ...
            task_name, task_results.num_documents, length(task_insights.key_findings));
else
    fprintf('  No data available for %s\n', task_name);
end
end

% Generate comprehensive operational intelligence report
operational_intelligence = generateOperationalIntelligence(analytics_results, analytics_config);
insights_summary.operational_intelligence = operational_intelligence;

% Create predictive recommendations
predictive_recommendations = generatePredictiveRecommendations(analytics_results, analytics_config);
insights_summary.predictive_recommendations = predictive_recommendations;

% Generate visualisations and dashboards
generateAnalyticsDashboard(analytics_results, insights_summary, analytics_config);

fprintf('\nNetwork Operations Text Analytics completed successfully.\n');
end

function preprocessing_config = configureTextPreprocessing(config)
% Configure comprehensive text preprocessing pipeline for network operations

preprocessing_config = struct();

% Tokenisation parameters
preprocessing_config.tokenisation = struct();
preprocessing_config.tokenisation.preserve_case = false;
preprocessing_config.tokenisation.remove_punctuation = true;
preprocessing_config.tokenisation.remove_numbers = false; % Keep numbers for error codes, IPs, etc.
preprocessing_config.tokenisation.min_token_length = config.min_token_length;

% Stop words configuration
preprocessing_config.stop_words = struct();
preprocessing_config.stop_words.remove_standard = true;
preprocessing_config.stop_words.custom_stop_words = config.custom_stop_words;
preprocessing_config.stop_words.preserve_technical_terms = true;

% Stemming and lemmatisation
preprocessing_config.morphological = struct();
preprocessing_config.morphological.enable_stemming = config.enable_stemming;
preprocessing_config.morphological.stemmer_type = 'porter'; % Porter stemmer
preprocessing_config.morphological.enable_lemmatisation = config.enable_lemmatisation;

% Domain-specific processing
preprocessing_config.domain_specific = struct();
preprocessing_config.domain_specific.ip_address_handling = 'normalize'; % Normalize IP addresses
preprocessing_config.domain_specific.timestamp_handling = 'extract'; % Extract timestamp features
preprocessing_config.domain_specific.error_code_handling = 'preserve'; % Preserve error codes
preprocessing_config.domain_specific.equipment_id_handling = 'normalize'; % Normalize equipment IDs

% N-gram configuration
preprocessing_config.ngrams = struct();
preprocessing_config.ngrams.unigrams = true;
preprocessing_config.ngrams.bigrams = config.include_bigrams;
preprocessing_config.ngrams.trigrams = config.include_trigrams;
preprocessing_config.ngrams.min_frequency = config.ngram_min_frequency;

fprintf(' Text preprocessing pipeline configured successfully\n');
end

function analytics_models = loadTextAnalyticsModels(config)
% Load and initialise text analytics models for various tasks

analytics_models = struct();

% Log analysis model
fprintf(' Loading log analysis model...\n');
analytics_models.log_analysis = initialiseLogAnalysisModel(config.log_analysis);

% Incident classification model
fprintf(' Loading incident classification model...\n');
analytics_models.incident_classification = initialiseIncidentClassificationModel(config.incident_classification);

% Sentiment analysis model
fprintf(' Loading sentiment analysis model...\n');
analytics_models.sentiment_analysis = initialiseSentimentAnalysisModel(config.sentiment_analysis);

% Topic modeling model
fprintf(' Loading topic modeling model...\n');
analytics_models.topic_modeling = initialiseTopicModelingModel(config.topic_modeling);

% Anomaly detection model
fprintf(' Loading anomaly detection model...\n');
analytics_models.anomaly_detection = initialiseAnomalyDetectionModel(config.anomaly_detection);

% Predictive maintenance model
fprintf(' Loading predictive maintenance model...\n');
analytics_models.predictive_maintenance = initialisePredictiveMaintenanceModel(config.predictive_maintenance);

% Root cause analysis model
fprintf(' Loading root cause analysis model...\n');
analytics_models.root_cause_analysis = initialiseRootCauseAnalysisModel(config.root_cause_analysis);

% Knowledge extraction model
fprintf(' Loading knowledge extraction model...\n');
analytics_models.knowledge_extraction = initialiseKnowledgeExtractionModel(config.knowledge_extraction);

fprintf(' All text analytics models loaded successfully\n');
end

function model = initialiseLogAnalysisModel(config)
% Initialise log analysis model for network equipment logs

model = struct();
model.type = 'hybrid_pattern_ml';

% Pattern-based analysis for structured log components
model.patterns = struct();
model.patterns.timestamp_pattern = '\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}';
model.patterns.ip_pattern = '\b(?:[0-9]{1,3}.){3}[0-9]{1,3}\b';
model.patterns.error_code_pattern = '(ERROR|WARN|CRIT|FATAL):\s*(\d+)';
model.patterns.equipment_id_pattern = config.equipment_id_pattern;

% Machine learning model for log classification
model.classifier = struct();
model.classifier.type = 'multiclass_svm';
model.classifier.features = {'bag_of_words', 'temporal_features', 'frequency_features'};
model.classifier.classes = config.log_categories;

% Anomaly detection parameters
model.anomaly_detection = struct();
model.anomaly_detection.method = 'isolation_forest';
model.anomaly_detection.contamination_rate = config.expected_anomaly_rate;
model.anomaly_detection.feature_extraction = 'tfidf_with_temporal';

% Temporal analysis parameters
model.temporal_analysis = struct();
model.temporal_analysis.time_window = config.temporal_window;
model.temporal_analysis.trend_analysis = true;
model.temporal_analysis.seasonality_detection = true;
end

function model = initialiseIncidentClassificationModel(config)
% Initialise incident classification model for operational reports

model = struct();
model.type = 'hierarchical_text_classifier';

% Feature extraction configuration
model.feature_extraction = struct();
model.feature_extraction.method = 'tfidf_with_domain_terms';
model.feature_extraction.max_features = config.max_vocabulary_size;
model.feature_extraction.domain_terms_weight = config.domain_terms_weight;
model.feature_extraction.include_metadata = true;

% Classification hierarchy
model.classification_hierarchy = struct();
model.classification_hierarchy.level1_categories = config.primary_categories;
model.classification_hierarchy.level2_categories = config.secondary_categories;
model.classification_hierarchy.level3_categories = config.tertiary_categories;

% Multi-label classification support
model.multilabel = struct();
model.multilabel.enable = config.enable_multilabel;
model.multilabel.threshold_strategy = 'adaptive';
model.multilabel.max_labels_per_document = config.max_labels_per_incident;

% Severity assessment
model.severity_assessment = struct();
model.severity_assessment.enable = true;
model.severity_assessment.severity_levels = {'low', 'medium', 'high', 'critical'};
model.severity_assessment.feature_weights = config.severity_feature_weights;
end

function [task_results, task_insights] = processTextAnalyticsTask(task_text_data, task_name, models, preprocessing_config, config)
% Process individual text analytics task with comprehensive analysis

% Initialise results structure
task_results = struct();
task_insights = struct();

% Preprocess text data
fprintf(' Preprocessing text data for %s...\n', task_name);
processed_documents = preprocessTextData(task_text_data, preprocessing_config);

task_results.num_documents = length(processed_documents);
task_results.preprocessing_stats = calculatePreprocessingStats(task_text_data, processed_documents);

% Task-specific analysis
switch task_name
case 'log_analysis'
[analysis_results, insights] = performLogAnalysis(processed_documents, models.log_analysis, config);

 
case 'incident_classification'
    [analysis_results, insights] = performIncidentClassification(processed_documents, models.incident_classification, config);
    
case 'sentiment_analysis'
    [analysis_results, insights] = performSentimentAnalysis(processed_documents, models.sentiment_analysis, config);
    
case 'topic_modeling'
    [analysis_results, insights] = performTopicModeling(processed_documents, models.topic_modeling, config);
    
case 'anomaly_detection'
    [analysis_results, insights] = performTextAnomalyDetection(processed_documents, models.anomaly_detection, config);
    
case 'predictive_maintenance'
    [analysis_results, insights] = performPredictiveMaintenanceAnalysis(processed_documents, models.predictive_maintenance, config);
    
case 'root_cause_analysis'
    [analysis_results, insights] = performRootCauseAnalysis(processed_documents, models.root_cause_analysis, config);
    
case 'knowledge_extraction'
    [analysis_results, insights] = performKnowledgeExtraction(processed_documents, models.knowledge_extraction, config);
    
otherwise
    error('Unknown text analytics task: %s', task_name);
end

% Store detailed results
task_results.analysis_results = analysis_results;
task_results.processing_time = analysis_results.processing_time;
task_results.confidence_metrics = analysis_results.confidence_metrics;

% Extract key insights
task_insights.key_findings = insights.key_findings;
task_insights.actionable_recommendations = insights.recommendations;
task_insights.statistical_summary = insights.statistics;
task_insights.trend_analysis = insights.trends;

fprintf(' Completed %s analysis: %d insights extracted\n', task_name, length(task_insights.key_findings));
end

function processed_documents = preprocessTextData(raw_text_data, config)
% Comprehensive text preprocessing for network operations data

num_documents = length(raw_text_data);
processed_documents = cell(num_documents, 1);

for doc_idx = 1:num_documents
current_doc = raw_text_data{doc_idx};
 
% Handle different input formats
if isstruct(current_doc)
    text_content = current_doc.content;
    metadata = current_doc.metadata;
else
    text_content = current_doc;
    metadata = struct();
end

% Domain-specific preprocessing
processed_text = applyDomainSpecificPreprocessing(text_content, config.domain_specific);

% Tokenisation
tokens = tokenizedDocument(processed_text);

% Case normalisation
if ~config.tokenisation.preserve_case
    tokens = lower(tokens);
end

% Remove punctuation and short tokens
if config.tokenisation.remove_punctuation
    tokens = erasePunctuation(tokens);
end

% Filter by token length
tokens = tokens(strlength(tokens) >= config.tokenisation.min_token_length);

% Stop words removal
if config.stop_words.remove_standard
    tokens = removeStopWords(tokens);
end

% Custom stop words removal
if isfield(config.stop_words, 'custom_stop_words') && ~isempty(config.stop_words.custom_stop_words)
    tokens = removeWords(tokens, config.stop_words.custom_stop_words);
end

% Stemming or lemmatisation
if config.morphological.enable_stemming
    tokens = porterStemmer(tokens);
end

% Create processed document structure
processed_doc = struct();
processed_doc.tokens = tokens;
processed_doc.original_text = text_content;
processed_doc.metadata = metadata;
processed_doc.document_id = doc_idx;

processed_documents{doc_idx} = processed_doc;
end
end

function processed_text = applyDomainSpecificPreprocessing(text, config)
% Apply domain-specific preprocessing for network operations text

processed_text = text;

% IP address normalisation
if strcmp(config.ip_address_handling, 'normalize')
ip_pattern = '\b(?:[0-9]{1,3}.){3}[0-9]{1,3}\b';
processed_text = regexprep(processed_text, ip_pattern, 'IP_ADDRESS');
end

% Timestamp extraction and normalisation
if strcmp(config.timestamp_handling, 'extract')
timestamp_pattern = '\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}';
processed_text = regexprep(processed_text, timestamp_pattern, 'TIMESTAMP');
end

% Error code preservation
if strcmp(config.error_code_handling, 'preserve')
% Identify and mark error codes for special handling
error_pattern = '(ERROR|WARN|CRIT|FATAL):\s*(\d+)';
processed_text = regexprep(processed_text, error_pattern, 'ERROR_CODE_$2');
end

% Equipment ID normalisation
if strcmp(config.equipment_id_handling, 'normalize')
if isfield(config, 'equipment_id_pattern') && ~isempty(config.equipment_id_pattern)
processed_text = regexprep(processed_text, config.equipment_id_pattern, 'EQUIPMENT_ID');
end
end
end

function [analysis_results, insights] = performLogAnalysis(processed_documents, model, config)
% Perform comprehensive log analysis for network equipment

tic; % Start timing

num_documents = length(processed_documents);
analysis_results = struct();

% Extract log-specific features
log_features = extractLogFeatures(processed_documents, model);

% Pattern-based analysis
pattern_analysis = performPatternAnalysis(processed_documents, model.patterns);

% Classification of log entries
if isfield(model, 'classifier')
classification_results = classifyLogEntries(log_features, model.classifier);
else
classification_results = [];
end

% Anomaly detection in log data
if isfield(model, 'anomaly_detection')
anomaly_results = detectLogAnomalies(log_features, model.anomaly_detection);
else
anomaly_results = [];
end

% Temporal analysis
if isfield(model, 'temporal_analysis')
temporal_results = performTemporalLogAnalysis(processed_documents, model.temporal_analysis);
else
temporal_results = [];
end

processing_time = toc;

% Compile analysis results
analysis_results.pattern_analysis = pattern_analysis;
analysis_results.classification_results = classification_results;
analysis_results.anomaly_results = anomaly_results;
analysis_results.temporal_results = temporal_results;
analysis_results.processing_time = processing_time;
analysis_results.confidence_metrics = calculateLogAnalysisConfidence(analysis_results);

% Extract insights
insights = extractLogAnalysisInsights(analysis_results, config);
end

function insights = extractLogAnalysisInsights(analysis_results, config)
% Extract actionable insights from log analysis results

insights = struct();
insights.key_findings = {};
insights.recommendations = {};
insights.statistics = struct();
insights.trends = struct();

% Analyse error patterns
if isfield(analysis_results, 'pattern_analysis')
error_patterns = analysis_results.pattern_analysis.error_patterns;
if ~isempty(error_patterns)
[most_frequent_errors, error_frequencies] = findMostFrequentErrors(error_patterns);

 
    insights.key_findings{end+1} = sprintf('Most frequent error: %s (occurred %d times)', ...
                                         most_frequent_errors{1}, error_frequencies(1));
    
    if error_frequencies(1) > config.error_frequency_threshold
        insights.recommendations{end+1} = sprintf('Investigate root cause of error %s due to high frequency', ...
                                                most_frequent_errors{1});
    end
end
end

% Analyse anomalies
if isfield(analysis_results, 'anomaly_results') && ~isempty(analysis_results.anomaly_results)
num_anomalies = length(analysis_results.anomaly_results.anomaly_indices);
anomaly_rate = num_anomalies / analysis_results.anomaly_results.total_entries;

 
insights.statistics.anomaly_rate = anomaly_rate;
insights.key_findings{end+1} = sprintf('Detected %d anomalous log entries (%.2f%% of total)', ...
                                     num_anomalies, anomaly_rate * 100);

if anomaly_rate > config.anomaly_rate_threshold
    insights.recommendations{end+1} = 'High anomaly rate detected - recommend detailed investigation';
end
end

% Analyse temporal trends
if isfield(analysis_results, 'temporal_results') && ~isempty(analysis_results.temporal_results)
temporal_trends = analysis_results.temporal_results.trends;

 
if isfield(temporal_trends, 'error_rate_trend')
    if temporal_trends.error_rate_trend > 0
        insights.trends.error_rate = 'increasing';
        insights.recommendations{end+1} = 'Error rate is increasing - recommend proactive maintenance';
    else
        insights.trends.error_rate = 'stable_or_decreasing';
    end
end
end

% Statistical summary
insights.statistics.total_log_entries = length(analysis_results.pattern_analysis.all_entries);
insights.statistics.processing_time = analysis_results.processing_time;
insights.statistics.confidence_score = analysis_results.confidence_metrics.overall_confidence;
end
