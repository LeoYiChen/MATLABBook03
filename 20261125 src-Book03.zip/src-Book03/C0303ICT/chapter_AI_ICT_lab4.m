%% chapter_AI_ICT_lab4.m
% Capacity vs. SNR Plot.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0303ICT/
% Listing label         : chapter_AI_ICT_lab4
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% MATLABBook02_Chapter01_Lab4.m
% Author: Dr Leo Chen
% Version: 1.0 (MATLAB R2024b)

B = 1e6; % Hz
SNRdB = 0:20;
SNR = 10.^(SNRdB/10);
C = B .* log2(1 + SNR);

plot(SNRdB, C/1e6, 'LineWidth', 2);
xlabel('$SNR_{dB}$', 'Interpreter', 'latex');
ylabel('$C$ (Mbps)', 'Interpreter', 'latex');
grid on;
