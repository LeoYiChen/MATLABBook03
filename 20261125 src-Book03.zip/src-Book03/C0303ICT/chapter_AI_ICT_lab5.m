%% chapter_AI_ICT_lab5.m
% ML-based Capacity Prediction.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0303ICT/
% Listing label         : chapter_AI_ICT_lab5
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% MATLABBook02_Chapter01_Lab5.m
% Author: Dr Leo Chen
% Version: 1.0 (MATLAB R2024b)

SNRdB = (0:0.5:20)';
B = 1e6;
Capacity = B .* log2(1 + 10.^(SNRdB/10));

mdl = fitlm(SNRdB, Capacity);
predicted = predict(mdl, SNRdB);
