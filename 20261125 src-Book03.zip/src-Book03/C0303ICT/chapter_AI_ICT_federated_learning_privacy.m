%% chapter_AI_ICT_federated_learning_privacy.m
% Privacy-Preserving Federated Learning Framework for Communication Networks
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0303ICT/
% Listing label         : chapter_AI_ICT_federated_learning_privacy
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [federated_results, privacy_analysis] = privacyPreservingFederatedLearning(network_config, privacy_config, learning_config)
% Comprehensive privacy-preserving federated learning implementation
% for communication networks with differential privacy guarantees
%
% Inputs:
% network_config: Network topology and participant configuration
% privacy_config: Privacy parameters and mechanisms
% learning_config: Federated learning algorithm parameters
% Outputs:
% federated_results: Training results and model performance
% privacy_analysis: Privacy guarantee analysis and verification

fprintf('Initialising Privacy-Preserving Federated Learning Framework...\n');

% Validate privacy parameters
validatePrivacyParameters(privacy_config);

% Define federated learning participants
num_participants = network_config.num_participants;
participants = cell(num_participants, 1);

% Initialise global model
fprintf('Initialising global model for federated learning...\n');
global_model = initialiseGlobalModel(learning_config);

% Distribute initial model to all participants
fprintf('Distributing initial model to %d participants...\n', num_participants);
for i = 1:num_participants
participants{i} = initialiseParticipant(i, global_model, network_config, privacy_config);
end

% Federated learning training loop
num_rounds = learning_config.num_rounds;
federated_results = struct();
federated_results.training_history = cell(num_rounds, 1);
federated_results.privacy_budget_usage = zeros(num_rounds, 1);
federated_results.global_model_accuracy = zeros(num_rounds, 1);

fprintf('\nStarting federated learning training...\n');

for round = 1:num_rounds
fprintf('Round %d/%d: ', round, num_rounds);
 
% Select participating clients for this round
participation_rate = learning_config.participation_rate;
num_selected = max(1, floor(num_participants * participation_rate));
selected_participants = randperm(num_participants, num_selected);

fprintf('Selected %d participants\n', num_selected);

% Local training phase with privacy protection
local_updates = cell(num_selected, 1);
local_privacy_costs = zeros(num_selected, 1);

for i = 1:num_selected
    participant_id = selected_participants(i);
    
    % Perform local training with differential privacy
    [local_update, privacy_cost] = performPrivateLocalTraining(participants{participant_id}, ...
                                                               global_model, ...
                                                               privacy_config, ...
                                                               learning_config);
    
    local_updates{i} = local_update;
    local_privacy_costs(i) = privacy_cost;
    
    % Update participant's privacy budget
    participants{participant_id}.privacy_budget_remaining = ...
        participants{participant_id}.privacy_budget_remaining - privacy_cost;
end

% Secure aggregation with additional privacy protection
[aggregated_update, aggregation_privacy_cost] = secureAggregation(local_updates, ...
                                                                  selected_participants, ...
                                                                  privacy_config);

% Update global model
global_model = updateGlobalModel(global_model, aggregated_update, learning_config);

% Evaluate global model performance
global_accuracy = evaluateGlobalModel(global_model, network_config.test_data);

% Calculate total privacy cost for this round
total_privacy_cost = sum(local_privacy_costs) + aggregation_privacy_cost;

% Store round results
federated_results.training_history{round} = struct();
federated_results.training_history{round}.selected_participants = selected_participants;
federated_results.training_history{round}.local_privacy_costs = local_privacy_costs;
federated_results.training_history{round}.aggregation_privacy_cost = aggregation_privacy_cost;
federated_results.training_history{round}.global_accuracy = global_accuracy;

federated_results.privacy_budget_usage(round) = total_privacy_cost;
federated_results.global_model_accuracy(round) = global_accuracy;

fprintf('  Global accuracy: %.4f, Privacy cost: %.6f\n', global_accuracy, total_privacy_cost);

% Check privacy budget constraints
if any([participants{selected_participants}.privacy_budget_remaining] < privacy_config.min_budget_threshold)
    fprintf('Warning: Some participants approaching privacy budget limits\n');
end

% Early stopping based on convergence
if round > learning_config.convergence_window
    recent_accuracies = federated_results.global_model_accuracy(round-learning_config.convergence_window+1:round);
    if std(recent_accuracies) < learning_config.convergence_threshold
        fprintf('Convergence achieved at round %d\n', round);
        break;
    end
end
end

% Store final global model
federated_results.final_global_model = global_model;
federated_results.total_rounds = round;

% Comprehensive privacy analysis
fprintf('\nConducting privacy analysis...\n');
privacy_analysis = conductPrivacyAnalysis(federated_results, participants, privacy_config);

% Generate privacy-utility trade-off analysis
privacy_utility_analysis = analysePrivacyUtilityTradeoff(federated_results, privacy_analysis);
privacy_analysis.privacy_utility_tradeoff = privacy_utility_analysis;

% Visualise results
visualiseFederatedLearningResults(federated_results, privacy_analysis);

fprintf('Privacy-Preserving Federated Learning completed successfully.\n');
fprintf('Final global accuracy: %.4f, Total privacy budget used: %.6f\n', ...
federated_results.global_model_accuracy(end), ...
sum(federated_results.privacy_budget_usage));
end

function participant = initialiseParticipant(participant_id, global_model, network_config, privacy_config)
% Initialise individual participant for federated learning

participant = struct();
participant.id = participant_id;
participant.local_model = global_model;

% Generate local dataset for participant
participant.local_data = generateParticipantData(participant_id, network_config);

% Initialise privacy budget
participant.privacy_budget_total = privacy_config.initial_privacy_budget;
participant.privacy_budget_remaining = privacy_config.initial_privacy_budget;

% Privacy mechanism configuration
participant.privacy_mechanism = privacy_config.mechanism; % 'gaussian', 'laplace', 'moments_accountant'
participant.noise_multiplier = privacy_config.noise_multiplier;

% Local training configuration
participant.local_epochs = network_config.local_epochs;
participant.local_batch_size = network_config.local_batch_size;
participant.local_learning_rate = network_config.local_learning_rate;

fprintf(' Initialised participant %d with %d local samples\n', ...
participant_id, size(participant.local_data.features, 1));
end

function [local_update, privacy_cost] = performPrivateLocalTraining(participant, global_model, privacy_config, learning_config)
% Perform local training with differential privacy guarantees

% Set participant's local model to current global model
participant.local_model = global_model;

% Extract local training data
X_local = participant.local_data.features;
y_local = participant.local_data.labels;

% Local training with privacy protection
num_local_epochs = participant.local_epochs;
batch_size = participant.local_batch_size;
learning_rate = participant.local_learning_rate;

% Privacy parameters
epsilon_per_epoch = privacy_config.epsilon_per_epoch;
delta = privacy_config.delta;
sensitivity = calculateSensitivity(participant.local_model, batch_size);

% Noise calibration for differential privacy
noise_scale = calculateNoiseScale(sensitivity, epsilon_per_epoch, delta, privacy_config.mechanism);

% Training loop with noisy gradients
for epoch = 1:num_local_epochs
% Shuffle local data
num_samples = size(X_local, 1);
perm = randperm(num_samples);
X_shuffled = X_local(perm, :);
y_shuffled = y_local(perm);

 
% Mini-batch training with privacy
num_batches = ceil(num_samples / batch_size);
for batch = 1:num_batches
    batch_start = (batch - 1) * batch_size + 1;
    batch_end = min(batch * batch_size, num_samples);
    
    X_batch = X_shuffled(batch_start:batch_end, :);
    y_batch = y_shuffled(batch_start:batch_end);
    
    % Compute gradients
    gradients = computeModelGradients(participant.local_model, X_batch, y_batch);
    
    % Add calibrated noise for differential privacy
    noisy_gradients = addPrivacyNoise(gradients, noise_scale, privacy_config.mechanism);
    
    % Gradient clipping for bounded sensitivity
    clipped_gradients = clipGradients(noisy_gradients, privacy_config.clip_norm);
    
    % Update local model
    participant.local_model = updateModelWithGradients(participant.local_model, ...
                                                      clipped_gradients, ...
                                                      learning_rate);
end
end

% Calculate model update (difference from global model)
local_update = calculateModelDifference(participant.local_model, global_model);

% Calculate privacy cost for this training round
privacy_cost = num_local_epochs * epsilon_per_epoch;
end

function noise_scale = calculateNoiseScale(sensitivity, epsilon, delta, mechanism)
% Calculate appropriate noise scale for differential privacy mechanism

switch mechanism
case 'gaussian'
% Gaussian mechanism for (\epsilon,\delta)-differential privacy
if delta == 0
error('Gaussian mechanism requires delta > 0');
end
sigma = sensitivity * sqrt(2 * log(1.25 / delta)) / epsilon;
noise_scale = sigma;

 
case 'laplace'
    % Laplace mechanism for epsilon-differential privacy
    b = sensitivity / epsilon;
    noise_scale = b;
    
case 'moments_accountant'
    % Advanced composition using moments accountant
    noise_scale = calculateMomentsAccountantNoise(sensitivity, epsilon, delta);
    
otherwise
    error('Unsupported privacy mechanism: %s', mechanism);
end
end

function noisy_gradients = addPrivacyNoise(gradients, noise_scale, mechanism)
% Add calibrated noise to gradients for differential privacy

switch mechanism
case 'gaussian'
% Add Gaussian noise
noise = noise_scale * randn(size(gradients));
noisy_gradients = gradients + noise;

 
case 'laplace'
    % Add Laplace noise (using inverse CDF method)
    uniform_noise = rand(size(gradients)) - 0.5;
    laplace_noise = -noise_scale * sign(uniform_noise) .* log(1 - 2 * abs(uniform_noise));
    noisy_gradients = gradients + laplace_noise;
    
case 'moments_accountant'
    % Use moments accountant for tighter privacy analysis
    noise = noise_scale * randn(size(gradients));
    noisy_gradients = gradients + noise;
    
otherwise
    error('Unsupported noise mechanism: %s', mechanism);
end
end

function [aggregated_update, privacy_cost] = secureAggregation(local_updates, participant_ids, privacy_config)
% Perform secure aggregation of local updates with additional privacy protection

num_participants = length(local_updates);

% Simple federated averaging with optional additional privacy
if privacy_config.secure_aggregation.enable_additional_noise
% Add server-side noise for enhanced privacy
aggregated_update = zeros(size(local_updates{1}));
 
% Weighted averaging
for i = 1:num_participants
    weight = 1 / num_participants; % Equal weighting for simplicity
    aggregated_update = aggregated_update + weight * local_updates{i};
end

% Add server-side noise
server_noise_scale = privacy_config.secure_aggregation.server_noise_scale;
server_noise = server_noise_scale * randn(size(aggregated_update));
aggregated_update = aggregated_update + server_noise;

privacy_cost = privacy_config.secure_aggregation.server_privacy_cost;
else
% Standard federated averaging without additional noise
aggregated_update = zeros(size(local_updates{1}));

 
for i = 1:num_participants
    weight = 1 / num_participants;
    aggregated_update = aggregated_update + weight * local_updates{i};
end

privacy_cost = 0;
end
end

function privacy_analysis = conductPrivacyAnalysis(federated_results, participants, privacy_config)
% Conduct comprehensive privacy analysis of federated learning

privacy_analysis = struct();

% Calculate total privacy budget consumption
total_budget_used = sum(federated_results.privacy_budget_usage);
privacy_analysis.total_privacy_budget_used = total_budget_used;

% Per-participant privacy analysis
num_participants = length(participants);
participant_budgets = zeros(num_participants, 1);
for i = 1:num_participants
participant_budgets(i) = participants{i}.privacy_budget_total - ...
participants{i}.privacy_budget_remaining;
end

privacy_analysis.per_participant_budget_usage = participant_budgets;
privacy_analysis.max_participant_budget_usage = max(participant_budgets);
privacy_analysis.min_participant_budget_usage = min(participant_budgets);
privacy_analysis.avg_participant_budget_usage = mean(participant_budgets);

% Privacy guarantee verification
[epsilon_total, delta_total] = calculateComposedPrivacyGuarantee(federated_results, privacy_config);
privacy_analysis.composed_epsilon = epsilon_total;
privacy_analysis.composed_delta = delta_total;

% Privacy accounting using advanced composition
if strcmp(privacy_config.composition_method, 'advanced')
[epsilon_advanced, delta_advanced] = advancedComposition(federated_results, privacy_config);
privacy_analysis.advanced_composition_epsilon = epsilon_advanced;
privacy_analysis.advanced_composition_delta = delta_advanced;
end

% Risk assessment
privacy_analysis.privacy_risk_level = assessPrivacyRisk(privacy_analysis, privacy_config);

fprintf(' Total privacy budget used: %.6f\n', total_budget_used);
fprintf(' Composed privacy guarantee: (%.6f, %.2e)-DP\n', epsilon_total, delta_total);
fprintf(' Privacy risk level: %s\n', privacy_analysis.privacy_risk_level);
end

function visualiseFederatedLearningResults(federated_results, privacy_analysis)
% Generate comprehensive visualisation of federated learning results

% Create figure with multiple subplots
figure('Position', [100, 100, 1200, 800]);

% Subplot 1: Training accuracy over rounds
subplot(2, 3, 1);
plot(1:federated_results.total_rounds, federated_results.global_model_accuracy(1:federated_results.total_rounds), ...
'b-', 'LineWidth', 2);
xlabel('Federated Learning Round');
ylabel('Global Model Accuracy');
title('Federated Learning Convergence');
grid on;

% Subplot 2: Privacy budget usage over rounds
subplot(2, 3, 2);
cumulative_privacy_usage = cumsum(federated_results.privacy_budget_usage(1:federated_results.total_rounds));
plot(1:federated_results.total_rounds, cumulative_privacy_usage, 'r-', 'LineWidth', 2);
xlabel('Federated Learning Round');
ylabel('Cumulative Privacy Budget Used');
title('Privacy Budget Consumption');
grid on;

% Subplot 3: Privacy-utility trade-off
subplot(2, 3, 3);
if isfield(privacy_analysis, 'privacy_utility_tradeoff')
privacy_levels = privacy_analysis.privacy_utility_tradeoff.privacy_levels;
utility_values = privacy_analysis.privacy_utility_tradeoff.utility_values;
plot(privacy_levels, utility_values, 'g-o', 'LineWidth', 2, 'MarkerSize', 6);
xlabel('Privacy Level ($\varepsilon$)');
ylabel('Model Utility (Accuracy)');
title('Privacy-Utility Trade-off');
grid on;
end

% Subplot 4: Per-participant privacy usage
subplot(2, 3, 4);
bar(privacy_analysis.per_participant_budget_usage);
xlabel('Participant ID');
ylabel('Privacy Budget Used');
title('Per-Participant Privacy Usage');
grid on;

% Subplot 5: Privacy guarantee evolution
subplot(2, 3, 5);
epsilon_evolution = zeros(federated_results.total_rounds, 1);
for round = 1:federated_results.total_rounds
epsilon_evolution(round) = sum(federated_results.privacy_budget_usage(1:round));
end
semilogy(1:federated_results.total_rounds, epsilon_evolution, 'm-', 'LineWidth', 2);
xlabel('Federated Learning Round');
ylabel('Cumulative $\varepsilon$ (log scale)');
title('Privacy Guarantee Evolution');
grid on;

% Subplot 6: Model performance comparison
subplot(2, 3, 6);
final_accuracy = federated_results.global_model_accuracy(federated_results.total_rounds);
privacy_cost = privacy_analysis.total_privacy_budget_used;

% Simple comparison bars (can be enhanced with baseline comparisons)
categories = {'FL with DP', 'Target'};
accuracies = [final_accuracy, 0.95]; % Assuming target accuracy of 95%
bar(accuracies);
set(gca, 'XTickLabel', categories);
ylabel('Accuracy');
title('Performance Comparison');
ylim([0, 1]);
for i = 1:length(accuracies)
text(i, accuracies(i) + 0.02, sprintf('%.3f', accuracies(i)), ...
'HorizontalAlignment', 'center');
end
 
sgtitle(sprintf('Federated Learning Results ($\varepsilon$=%.4f, $\delta$=%.2e)', ...
privacy_analysis.composed_epsilon, privacy_analysis.composed_delta), ...
'FontSize', 14, 'FontWeight', 'bold');
end
