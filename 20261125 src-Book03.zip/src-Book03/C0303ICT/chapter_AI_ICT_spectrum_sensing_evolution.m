%% chapter_AI_ICT_spectrum_sensing_evolution.m
% Historical Evolution of Spectrum Sensing Algorithms
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/C0303ICT/
% Listing label         : chapter_AI_ICT_spectrum_sensing_evolution
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [sensing_results, algorithm_comparison] = spectrumSensingEvolution(signal_data, sensing_config)
% Demonstrates the historical evolution of spectrum sensing algorithms
% from simple energy detection to modern AI-enhanced techniques

algorithms = {'energy_detection', 'matched_filter', 'cyclostationary', ...
'eigenvalue_based', 'machine_learning', 'deep_learning'};

sensing_results = struct();
algorithm_comparison = struct();

for alg_idx = 1:length(algorithms)
algorithm = algorithms{alg_idx};
fprintf('Testing %s approach...\n', strrep(algorithm, '_', ' '));

 
switch algorithm
    case 'energy_detection'
        % Simplest approach from early cognitive radio research (1999-2005)
        results = energyDetectionSensing(signal_data, sensing_config);
        historical_context = 'First cognitive radio implementations (Mitola era)';
        
    case 'matched_filter'
        % Optimal detector when signal characteristics are known (2005-2008)
        results = matchedFilterSensing(signal_data, sensing_config);
        historical_context = 'Early optimization for known signal types';
        
    case 'cyclostationary'
        % Exploits periodic signal properties (2006-2010)
        results = cyclostationarySensing(signal_data, sensing_config);
        historical_context = 'Leveraging signal cyclostationarity';
        
    case 'eigenvalue_based'
        % Uses eigenvalues of sample covariance matrix (2008-2012)
        results = eigenvalueSensing(signal_data, sensing_config);
        historical_context = 'Random matrix theory applications';
        
    case 'machine_learning'
        % SVM and traditional ML approaches (2010-2015)
        results = machineLearningS(signal_data, sensing_config);
        historical_context = 'Classical machine learning integration';
        
    case 'deep_learning'
        % Deep neural networks (2015-present)
        results = deepLearningSensing(signal_data, sensing_config);
        historical_context = 'Deep learning revolution in cognitive radio';
        
    otherwise
        error('Unknown algorithm: %s', algorithm);
end

results.historical_context = historical_context;
results.algorithm_era = getAlgorithmEra(algorithm);

sensing_results.*(algorithm) = results;

% Display performance summary
fprintf('  Detection Probability: %.3f\n', results.P_d);
fprintf('  False Alarm Probability: %.3f\n', results.P_fa);
fprintf('  Computational Complexity: %s\n', results.complexity);
fprintf('  Historical Context: %s\n\n', historical_context);
end

% Generate comparative analysis
algorithm_comparison = generateAlgorithmComparison(sensing_results);
plotHistoricalEvolution(sensing_results);
end

function results = energyDetectionSensing(signal_data, config)
% Energy detection - the foundation of cognitive radio sensing
% Proposed by Urkowitz (1967), adapted for cognitive radio by Mitola

received_signal = signal_data.received_samples;
noise_power = signal_data.noise_power;
signal_power = signal_data.signal_power;

% Simple energy computation
N = length(received_signal);
energy = sum(abs(received_signal).^2) / N;

% Threshold based on noise power estimate
% This approach assumes known noise statistics
gamma = config.energy_threshold * noise_power;

% Detection decision
detection = energy > gamma;

% Theoretical performance analysis (Urkowitz, 1967)
% Under Gaussian assumptions
snr = signal_power / noise_power;
P_fa_theory = qfunc(config.energy_threshold);
P_d_theory = qfunc(config.energy_threshold - sqrt(N * snr));

results.detection = detection;
results.energy = energy;
results.threshold = gamma;
results.P_d = P_d_theory;
results.P_fa = P_fa_theory;
results.complexity = 'O(N)';
results.advantages = {'Simple implementation', 'No signal knowledge required'};
results.disadvantages = {'Poor performance at low SNR', 'Sensitive to noise uncertainty'};
results.historical_significance = 'Foundation of all cognitive radio sensing algorithms';
end

function results = matchedFilterSensing(signal_data, config)
% Matched filter detection - optimal for known signals
% Became popular when cognitive radios targeted specific primary user types

received_signal = signal_data.received_samples;
reference_signal = signal_data.reference_signal;
noise_power = signal_data.noise_power;

% Matched filter operation
matched_output = conv(received_signal, conj(fliplr(reference_signal)), 'valid');
test_statistic = max(abs(matched_output));

% Threshold setting
gamma = config.matched_filter_threshold * sqrt(noise_power * length(reference_signal));

% Detection decision
detection = test_statistic > gamma;

% Performance computation
snr_matched = signal_data.signal_power / noise_power * length(reference_signal);
P_fa_theory = qfunc(config.matched_filter_threshold);
P_d_theory = qfunc(config.matched_filter_threshold - sqrt(snr_matched));

results.detection = detection;
results.test_statistic = test_statistic;
results.threshold = gamma;
results.P_d = P_d_theory;
results.P_fa = P_fa_theory;
results.complexity = 'O(N*M)'; % N: signal length, M: reference length
results.advantages = {'Optimal for known signals', 'Good performance at low SNR'};
results.disadvantages = {'Requires exact signal knowledge', 'Sensitive to signal variations'};
results.historical_significance = 'Demonstrated importance of signal-specific sensing';
end

function results = cyclostationarySensing(signal_data, config)
% Cyclostationary feature detection
% Exploits the fact that modulated signals exhibit cyclostationarity

received_signal = signal_data.received_samples;
fs = signal_data.sampling_rate;
alpha = config.cyclic_frequency; % Known cyclic frequency

% Compute spectral correlation function (simplified)
N = length(received_signal);
window_size = config.window_size;
overlap = config.overlap;

% Sliding window analysis
num_windows = floor((N - window_size) / (window_size - overlap)) + 1;
cyclic_correlation = zeros(num_windows, 1);

for w = 1:num_windows
start_idx = (w-1) * (window_size - overlap) + 1;
end_idx = start_idx + window_size - 1;
 
window_signal = received_signal(start_idx:end_idx);

% Simplified cyclic correlation computation
% In practice, this would involve more sophisticated spectral correlation
shifted_signal = window_signal .* exp(-1*j * 2 * pi * alpha * (0:window_size-1)' / fs);
cyclic_correlation(w) = abs(mean(window_signal .* conj(shifted_signal)));
end

% Test statistic
test_statistic = mean(cyclic_correlation);
gamma = config.cyclostationary_threshold;

detection = test_statistic > gamma;

% Approximate performance (actual performance depends on signal type)
results.detection = detection;
results.test_statistic = test_statistic;
results.threshold = gamma;
results.P_d = 0.85; % Typical values for illustration
results.P_fa = 0.05;
results.complexity = 'O(N^2)';
results.advantages = {'Robust to noise uncertainty', 'Can distinguish signal types'};
results.disadvantages = {'High computational complexity', 'Requires knowledge of cyclic frequencies'};
results.historical_significance = 'Introduced robustness to noise power uncertainty';
end

function results = eigenvalueSensing(signal_data, config)
% Eigenvalue-based sensing using random matrix theory
% Emerged from advances in understanding large random matrices

received_signal = signal_data.received_samples;
num_antennas = signal_data.num_antennas;

% Create sample covariance matrix
% Assume multiple antennas or time-frequency samples
if num_antennas > 1
% Multi-antenna scenario
signal_matrix = reshape(received_signal, num_antennas, []);
else
% Single antenna - create matrix from overlapping windows
window_size = config.eigenvalue_window;
signal_matrix = hankel(received_signal(1:window_size), ...
received_signal(window_size:end));
end

% Sample covariance matrix
R_sample = (signal_matrix * signal_matrix') / size(signal_matrix, 2);

% Compute eigenvalues
eigenvalues = sort(eig(R_sample), 'descend');

% Various eigenvalue-based tests
lambda_max = eigenvalues(1);
lambda_min = eigenvalues(end);

% Maximum-minimum eigenvalue (MME) test
mme_ratio = lambda_max / lambda_min;
mme_threshold = config.mme_threshold;

% Energy with minimum eigenvalue (EME) test
eme_ratio = sum(eigenvalues) / lambda_min;
eme_threshold = config.eme_threshold;

% Detection decisions
detection_mme = mme_ratio > mme_threshold;
detection_eme = eme_ratio > eme_threshold;

% Use MME as primary detector
detection = detection_mme;
test_statistic = mme_ratio;

results.detection = detection;
results.test_statistic = test_statistic;
results.eigenvalues = eigenvalues;
results.mme_ratio = mme_ratio;
results.eme_ratio = eme_ratio;
results.P_d = 0.90; % Typical performance
results.P_fa = 0.03;
results.complexity = 'O(M^3)'; % M: matrix dimension
results.advantages = {'No noise power knowledge required', 'Robust to noise uncertainty'};
results.disadvantages = {'Requires multiple antennas or samples', 'Moderate complexity'};
results.historical_significance = 'Applied random matrix theory to cognitive radio';
end

function results = machineLearningS(signal_data, config)
% Machine learning-based sensing using traditional ML algorithms
% Support Vector Machines, Random Forests, etc.*(2010-2015 era)

received_signal = signal_data.received_samples;

% Feature extraction
features = extractTraditionalFeatures(received_signal, config);

% Simulate pre-trained SVM classifier
% In practice, this would be trained on labeled data
svm_model = config.svm_model; % Pre-trained model

% Classification
[prediction, scores] = predict(svm_model, features');
detection = prediction == 1; % Assuming class 1 = signal present

% Confidence from SVM score
confidence = abs(scores(1));

results.detection = detection;
results.features = features;
results.confidence = confidence;
results.test_statistic = confidence;
results.P_d = 0.93; % Typical ML performance
results.P_fa = 0.02;
results.complexity = 'O(N*F)'; % F: number of features
results.advantages = {'Learns from data', 'Can handle complex signal types'};
results.disadvantages = {'Requires training data', 'Feature engineering needed'};
results.historical_significance = 'Introduced data-driven approaches to sensing';
end

function results = deepLearningSensing(signal_data, config)
% Deep learning-based sensing - modern AI approach
% Convolutional Neural Networks, Recurrent Networks (2015-present)

received_signal = signal_data.received_samples;

% Prepare input for deep network
% Convert to time-frequency representation (spectrogram)
window_length = config.spectrogram_window;
overlap = config.spectrogram_overlap;
nfft = config.spectrogram_nfft;

[S, F, T] = spectrogram(received_signal, window_length, overlap, nfft);
spectrogram_input = abs(S); % Magnitude spectrogram

% Normalize for neural network
spectrogram_normalized = (spectrogram_input - mean(spectrogram_input(:))) / std(spectrogram_input(:));

% Simulate pre-trained CNN
% In practice, this would be a trained deep network
cnn_model = config.cnn_model; % Pre-trained deep learning model

% Forward pass through network (simplified simulation)
if isfield(config, 'simulate_cnn') && config.simulate_cnn
% Simulate CNN prediction
detection_probability = simulateCNNPrediction(spectrogram_normalized, config);
else
% Use actual trained network if available
detection_probability = predict(cnn_model, spectrogram_normalized);
end

% Threshold detection probability
detection = detection_probability > config.deep_learning_threshold;

results.detection = detection;
results.detection_probability = detection_probability;
results.spectrogram = spectrogram_normalized;
results.test_statistic = detection_probability;
results.P_d = 0.96; % State-of-the-art performance
results.P_fa = 0.01;
results.complexity = 'O(N*log(N))'; % Due to FFT + network inference
results.advantages = {'Learns complex features automatically', 'Excellent performance', 'Robust to various signal types'};
results.disadvantages = {'Requires large training datasets', 'High computational requirements'};
results.historical_significance = 'Current state-of-the-art in spectrum sensing';
end

function features = extractTraditionalFeatures(signal, config)
% Extract traditional signal features for machine learning

N = length(signal);

% Time-domain features
energy = sum(abs(signal).^2) / N;
variance = var(abs(signal));
kurtosis_val = kurtosis(abs(signal));
skewness_val = skewness(abs(signal));

% Frequency-domain features
signal_fft = fft(signal);
psd = abs(signal_fft).^2;
spectral_centroid = sum((1:N) .* psd') / sum(psd);

% Higher-order statistics
cum4 = mean(abs(signal).^4) / (mean(abs(signal).^2))^2; % Kurtosis-like measure

features = [energy, variance, kurtosis_val, skewness_val, spectral_centroid, cum4];
end

function detection_prob = simulateCNNPrediction(spectrogram, config)
% Simulate CNN prediction for demonstration
% In practice, this would be actual network inference

% Simple simulation based on spectrogram characteristics
energy_density = mean(spectrogram(:));
spectral_variation = std(spectrogram(:));

% Simulated CNN decision boundary
if energy_density > 0.1 && spectral_variation > 0.05
detection_prob = 0.9 + 0.1 * randn; % High confidence detection
else
detection_prob = 0.1 + 0.1 * randn; % Low confidence detection
end

% Ensure probability bounds
detection_prob = max(0, min(1, detection_prob));
end
