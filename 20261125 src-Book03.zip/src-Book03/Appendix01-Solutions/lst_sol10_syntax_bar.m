%% lst_sol10_syntax_bar.m
% Grouped bar chart for model comparison.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : lst:sol10_syntax_bar
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
metricMatrix = [fidGAN, fidDiffusion;
                isGAN,  isDiffusion];
bar(metricMatrix);
set(gca, 'XTickLabel', metricNames);
legend({'GAN', 'Diffusion'}, ...
       'Interpreter', 'latex');
