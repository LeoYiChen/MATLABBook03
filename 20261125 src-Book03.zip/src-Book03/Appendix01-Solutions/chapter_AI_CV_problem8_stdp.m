%% chapter_AI_CV_problem8_stdp.m
% STDP learning syntax.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AI_CV_problem8_stdp
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Update synaptic weights using STDP
newWeight = updateSTDPWeight(oldWeight, preSpikeTime, postSpikeTime, stdpParams);

% Apply homeostatic scaling
scaledWeight = applyHomeostasis(newWeight, targetActivity, currentActivity);
