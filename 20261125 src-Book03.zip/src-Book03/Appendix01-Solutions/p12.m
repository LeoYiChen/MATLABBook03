%% p12.m
% MATLABBook03_ChapterAIBHS_Problem12.m
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : p12
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function MATLABBook03_ChapterAIBHS_Problem12
% Purpose: CGM sensitivity degradation and useful-life estimate.
% Author: Dr Leo Chen. R2024b (no toolbox). v1.0 2025-06-01.
    rng(0); day=(0:14)'; trueDecay=0.06;
    sensitivity=1.0*exp(-trueDecay*day)+0.02*randn(size(day));
    coeff=polyfit(day,log(max(sensitivity,1e-3)),1); fittedDecay=-coeff(1);
    threshold=0.7; usefulLife=log(exp(coeff(2))/threshold)/fittedDecay;
    fprintf('Fitted decay rate: %.3f /day\n', fittedDecay);
    fprintf('Useful life (>%.0f%%): %.1f days\n', threshold*100, usefulLife);
    figure; plot(day,sensitivity,'o'); hold on;
    plot(day,exp(coeff(2))*exp(coeff(1)*day),'-'); grid on;
    xlabel('$\mathrm{Day}$'); ylabel('$\mathrm{Relative\ sensitivity}$');
end
