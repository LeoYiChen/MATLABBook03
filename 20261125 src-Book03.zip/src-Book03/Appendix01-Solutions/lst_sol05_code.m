%% lst_sol05_code.m
% GAN for Visual Pattern Generation (MATLABBook02_Chapter10_Problem05.m).
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : lst:sol05_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% MATLABBook02_Chapter10_Problem05.m
%  GAN for Visual Pattern Generation
%  -------------------
%  Author       : Dr Leo Chen
%  Date         : 2024-01-20
%  Modified     : 2024-07-01
%  Version      : 1.2
%  MATLAB Ver.  : R2024a
%  Toolboxes    : Deep Learning Toolbox
%  Description  :
%    Builds and trains a basic GAN to generate simple
%    28x28 grey-scale visual patterns. Discusses mode
%    collapse and training stability.
%  Change Log   :
%    v1.0 - Initial release.
%    v1.1 - Added label smoothing for stability.
%    v1.2 - Added loss plotting and grid display.
%  -------------------

%% Initialisation
clc; clear; close all;

%% --- User Parameters ------------
imageSize       = [28 28 1];
latentDim       = 100;
numEpochs       = 50;
miniBatchSize   = 128;
learnRateGen    = 0.0002;
learnRateDis    = 0.0002;
labelSmoothing  = 0.9;      % Real label = 0.9

%% --- Load Data --------------
% Using a synthetic dataset of simple patterns
[trainingImages, ~] = digitTrain4DArrayData;
% Normalise to [-1, 1]
trainingImages = single(trainingImages) * 2 - 1;
numTrainImages = size(trainingImages, 4);
fprintf('Training images: %d\n', numTrainImages);

%% --- Define Generator -------------
generatorLayers = [
    featureInputLayer(latentDim)
    fullyConnectedLayer(256)
    reluLayer
    fullyConnectedLayer(512)
    reluLayer
    fullyConnectedLayer(prod(imageSize))
    tanhLayer];

generatorNet = dlnetwork(layerGraph(generatorLayers));
fprintf('Generator parameters: %d\n', ...
        numel(generatorNet.Learnables));

%% --- Define Discriminator -----------
discriminatorLayers = [
    imageInputLayer(imageSize, 'Normalization', 'none')
    convolution2dLayer(5, 16, 'Stride', 2, ...
                       'Padding', 'same')
    leakyReluLayer(0.2)
    convolution2dLayer(5, 32, 'Stride', 2, ...
                       'Padding', 'same')
    leakyReluLayer(0.2)
    flattenLayer
    fullyConnectedLayer(1)
    sigmoidLayer];

discriminatorNet = dlnetwork( ...
    layerGraph(discriminatorLayers));
fprintf('Discriminator parameters: %d\n', ...
        numel(discriminatorNet.Learnables));

%% --- Training Loop --------------
genAvgGrad    = [];  genAvgGradSq  = [];
disAvgGrad    = [];  disAvgGradSq  = [];
genLossHistory = [];
disLossHistory = [];
iteration = 0;

for epochIndex = 1:numEpochs
    shuffledIdx = randperm(numTrainImages);

    for batchStart = 1:miniBatchSize:numTrainImages
        iteration = iteration + 1;
        batchEnd  = min(batchStart + miniBatchSize - 1,...
                        numTrainImages);
        batchIdx  = shuffledIdx(batchStart:batchEnd);
        realBatch = dlarray(single( ...
            trainingImages(:,:,:,batchIdx)), 'SSCB');

        noiseInput = dlarray(randn(latentDim, ...
            numel(batchIdx), 'single'), 'CB');

        [genLoss, disLoss, genGrad, disGrad] = ...
            dlfeval(@ganModelGradients, ...
            generatorNet, discriminatorNet, ...
            realBatch, noiseInput, ...
            imageSize, labelSmoothing);

        [discriminatorNet, disAvgGrad, disAvgGradSq]=...
            adamupdate(discriminatorNet, disGrad, ...
            disAvgGrad, disAvgGradSq, ...
            iteration, learnRateDis);

        [generatorNet, genAvgGrad, genAvgGradSq] = ...
            adamupdate(generatorNet, genGrad, ...
            genAvgGrad, genAvgGradSq, ...
            iteration, learnRateGen);

        genLossHistory = [genLossHistory; ...
            double(genLoss)];
        disLossHistory = [disLossHistory; ...
            double(disLoss)];
    end

    fprintf('Epoch %3d  G-loss: %.4f  D-loss: %.4f\n',...
            epochIndex, genLossHistory(end), ...
            disLossHistory(end));
end

%% --- Generate and Display Patterns --------
numDisplay    = 25;
displayNoise  = dlarray(randn(latentDim, numDisplay, ...
                        'single'), 'CB');
generatedFlat = predict(generatorNet, displayNoise);
generatedImgs = reshape( ...
    extractdata(generatedFlat), ...
    [imageSize, numDisplay]);

figure('Color', 'w', 'Position', [100 100 600 600]);
for imgIdx = 1:numDisplay
    subplot(5, 5, imgIdx);
    imshow(generatedImgs(:,:,1,imgIdx), [-1 1]);
end
sgtitle('GAN-Generated Patterns', ...
        'Interpreter', 'latex', 'FontSize', 14);
exportgraphics(gcf, ...
    'MATLABBook02_Chapter10_Problem05_output.pdf', ...
    'ContentType', 'vector');

%% --- Plot Training Losses -----------
figure('Color', 'w');
plot(genLossHistory, 'LineWidth', 1.2); hold on;
plot(disLossHistory, 'LineWidth', 1.2);
legend({'Generator', 'Discriminator'}, ...
       'Interpreter', 'latex');
xlabel('Iteration', 'Interpreter', 'latex');
ylabel('Loss', 'Interpreter', 'latex');
title('GAN Training Loss Curves', ...
      'Interpreter', 'latex', 'FontSize', 14);
grid on;

%% =========================================================
%% LOCAL FUNCTION: ganModelGradients
%% =========================================================
function [genLoss, disLoss, genGrad, disGrad] = ...
        ganModelGradients(generatorNet, ...
        discriminatorNet, realBatch, noiseInput, ...
        imageSize, labelSmoothing)

    fakeFlat  = forward(generatorNet, noiseInput);
    fakeImgs  = reshape(fakeFlat, ...
        [imageSize, size(noiseInput, 2)]);
    fakeImgs  = dlarray(fakeImgs, 'SSCB');

    % Discriminator on real and fake
    realPred = forward(discriminatorNet, realBatch);
    fakePred = forward(discriminatorNet, fakeImgs);

    % Discriminator loss (binary cross-entropy)
    disLossReal = -mean(log(realPred + 1e-8) ...
                  * labelSmoothing);
    disLossFake = -mean(log(1 - fakePred + 1e-8));
    disLoss     = disLossReal + disLossFake;

    % Generator loss
    genLoss = -mean(log(fakePred + 1e-8));

    disGrad = dlgradient(disLoss, ...
        discriminatorNet.Learnables);
    genGrad = dlgradient(genLoss, ...
        generatorNet.Learnables);
end
