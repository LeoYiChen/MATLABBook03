%% chapter_AI_CV_problem11_microwave.m
% Microwave imaging syntax.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AI_CV_problem11_microwave
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Initialize microwave imaging system
mwiSystem = initializeMicrowaveImaging(frequencyRange, antennaArray);

% Reconstruct tissue dielectric properties
[permittivity, conductivity] = reconstructTissueProperties(mwiSystem, measurements);

% Apply AI classification
[diagnosis, confidence] = classifyTissueAbnormalities(permittivity, conductivity, aiModel);
