%% chapter_AI_ICT_problem7_solution.m
% Adversarial Machine Learning Implementation
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AI_ICT_problem7_solution
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [adversarial_results, security_metrics] = adversarialMachineLearning()
% Adversarial Machine Learning in Communication Security
% Author: Dr Leo Chen
% Version: 1.0
% Date: 2024
%
% Implements comprehensive adversarial attacks and defences for AI-based
% automatic modulation classification systems

fprintf('=== Adversarial Machine Learning Solution ===\n');

% Target system configuration
target_system_config = struct();
target_system_config.modulation_schemes = {'BPSK', 'QPSK', '8PSK', '16QAM', '64QAM', 'OFDM', 'FSK', 'ASK'};
target_system_config.snr_range_db = 0:2:20; % Signal-to-noise ratio range
target_system_config.samples_per_symbol = 8; % Oversampling factor
target_system_config.signal_length = 1024; % Samples per signal
target_system_config.num_signals = 10000; % Dataset size

% Adversarial attack configuration
attack_config = struct();
attack_config.attack_types = {'fgsm', 'pgd', 'cw', 'deepfool'};
attack_config.threat_models = {'white_box', 'black_box', 'grey_box'};
attack_config.epsilon_values = [0.01, 0.05, 0.1, 0.2]; % Perturbation budgets
attack_config.attack_success_threshold = 0.8; % Success rate threshold

% Defence mechanism configuration
defence_config = struct();
defence_config.defence_types = {'adversarial_training', 'input_preprocessing', 'ensemble_defence', 'certified_defence'};
defence_config.preprocessing_methods = {'gaussian_noise', 'median_filter', 'jpeg_compression'};
defence_config.ensemble_size = 5; % Number of ensemble models
defence_config.training_adversarial_ratio = 0.3; % Adversarial training ratio

% Generate target classification dataset
fprintf('Generating modulation classification dataset...\n');
[clean_dataset, labels] = generateModulationDataset(target_system_config);

% Train target classification models
fprintf('Training target classification models...\n');
target_models = trainTargetModels(clean_dataset, labels, target_system_config);

% Implement adversarial attacks
fprintf('Implementing adversarial attacks...\n');
attack_results = implementAdversarialAttacks(target_models, clean_dataset, labels, attack_config);

% Implement defence mechanisms
fprintf('Implementing defence mechanisms...\n');
defence_results = implementDefenceMechanisms(target_models, attack_results, defence_config);

% Evaluate adversarial robustness
fprintf('Evaluating adversarial robustness...\n');
robustness_evaluation = evaluateAdversarialRobustness(target_models, attack_results, defence_results);

% Analyse security-accuracy trade-offs
fprintf('Analysing security-accuracy trade-offs...\n');
trade_off_analysis = analyseSecurityAccuracyTradeoffs(robustness_evaluation, target_system_config);

% Compile comprehensive results
adversarial_results = struct();
adversarial_results.clean_performance = evaluateCleanPerformance(target_models, clean_dataset, labels);
adversarial_results.attack_results = attack_results;
adversarial_results.defence_results = defence_results;
adversarial_results.robustness_evaluation = robustness_evaluation;
adversarial_results.trade_off_analysis = trade_off_analysis;

% Calculate security metrics
security_metrics = calculateSecurityMetrics(adversarial_results, attack_config, defence_config);

% Generate comprehensive visualisations
generateAdversarialVisualisations(adversarial_results, security_metrics);

fprintf('Adversarial machine learning analysis completed successfully!\n');
end

function attack_results = implementAdversarialAttacks(target_models, clean_data, labels, attack_config)
% Implement comprehensive adversarial attacks

attack_results = struct();
attack_types = attack_config.attack_types;
epsilon_values = attack_config.epsilon_values;

for attack_idx = 1:length(attack_types)
attack_type = attack_types{attack_idx};
fprintf(' Implementing %s attacks...\n', upper(attack_type));

 
attack_results.(attack_type) = struct();

for eps_idx = 1:length(epsilon_values)
    epsilon = epsilon_values(eps_idx);
    
    switch lower(attack_type)
        case 'fgsm'
            adversarial_examples = implementFGSMAttack(target_models.primary_model, ...
                                                     clean_data, labels, epsilon);
        case 'pgd'
            adversarial_examples = implementPGDAttack(target_models.primary_model, ...
                                                    clean_data, labels, epsilon);
        case 'cw'
            adversarial_examples = implementCWAttack(target_models.primary_model, ...
                                                   clean_data, labels, epsilon);
        case 'deepfool'
            adversarial_examples = implementDeepFoolAttack(target_models.primary_model, ...
                                                         clean_data, labels, epsilon);
    end
    
    % Evaluate attack success rate
    attack_success_rate = evaluateAttackSuccess(target_models.primary_model, ...
                                               adversarial_examples, labels);
    
    % Calculate perturbation statistics
    perturbation_stats = calculatePerturbationStatistics(adversarial_examples, clean_data);
    
    % Store results
    attack_results.(attack_type).(sprintf('epsilon_%.3f', epsilon)) = struct();
    attack_results.(attack_type).(sprintf('epsilon_%.3f', epsilon)).adversarial_examples = adversarial_examples;
    attack_results.(attack_type).(sprintf('epsilon_%.3f', epsilon)).success_rate = attack_success_rate;
    attack_results.(attack_type).(sprintf('epsilon_%.3f', epsilon)).perturbation_stats = perturbation_stats;
end
end

fprintf(' Adversarial attacks implemented: %d attack types\n', length(attack_types));
end

function adversarial_examples = implementFGSMAttack(model, clean_data, labels, epsilon)
% Implement Fast Gradient Sign Method (FGSM) attack

num_samples = size(clean_data, 2);
adversarial_examples = zeros(size(clean_data));

fprintf(' Generating FGSM adversarial examples (--=%.3f)...\n', epsilon);

for sample_idx = 1:num_samples
% Extract current sample and label
x_clean = clean_data(:, sample_idx);
true_label = labels(sample_idx);

 
% Calculate gradient of loss with respect to input
gradient = calculateLossGradient(model, x_clean, true_label);

% Generate adversarial perturbation
perturbation = epsilon * sign(gradient);

% Create adversarial example
x_adversarial = x_clean + perturbation;

% Ensure signal constraints (e.g., power constraints)
x_adversarial = enforceSignalConstraints(x_adversarial);

adversarial_examples(:, sample_idx) = x_adversarial;
end

fprintf(' FGSM attack completed: %d adversarial examples generated\n', num_samples);
end

function adversarial_examples = implementPGDAttack(model, clean_data, labels, epsilon)
% Implement Projected Gradient Descent (PGD) attack

num_samples = size(clean_data, 2);
adversarial_examples = zeros(size(clean_data));
num_iterations = 10;
step_size = epsilon / 4;

fprintf(' Generating PGD adversarial examples (--=%.3f)...\n', epsilon);

for sample_idx = 1:num_samples
% Extract current sample and label
x_clean = clean_data(:, sample_idx);
true_label = labels(sample_idx);

 
% Initialise adversarial example with random perturbation
x_adversarial = x_clean + epsilon * (2 * rand(size(x_clean)) - 1);
x_adversarial = enforceSignalConstraints(x_adversarial);

% Iterative gradient-based optimisation
for iter = 1:num_iterations
    % Calculate gradient
    gradient = calculateLossGradient(model, x_adversarial, true_label);
    
    % Update adversarial example
    x_adversarial = x_adversarial + step_size * sign(gradient);
    
    % Project back to epsilon-ball
    perturbation = x_adversarial - x_clean;
    perturbation = projectToEpsilonBall(perturbation, epsilon);
    x_adversarial = x_clean + perturbation;
    
    % Enforce signal constraints
    x_adversarial = enforceSignalConstraints(x_adversarial);
end

adversarial_examples(:, sample_idx) = x_adversarial;
end

fprintf(' PGD attack completed: %d adversarial examples generated\n', num_samples);
end

function defence_results = implementDefenceMechanisms(target_models, attack_results, defence_config)
% Implement comprehensive defence mechanisms

defence_results = struct();
defence_types = defence_config.defence_types;

for defence_idx = 1:length(defence_types)
defence_type = defence_types{defence_idx};
fprintf(' Implementing %s defence...\n', defence_type);

 
switch lower(defence_type)
    case 'adversarial_training'
        defence_results.adversarial_training = implementAdversarialTraining(target_models, ...
                                                                           attack_results, ...
                                                                           defence_config);
    case 'input_preprocessing'
        defence_results.input_preprocessing = implementInputPreprocessing(target_models, ...
                                                                         attack_results, ...
                                                                         defence_config);
    case 'ensemble_defence'
        defence_results.ensemble_defence = implementEnsembleDefence(target_models, ...
                                                                   attack_results, ...
                                                                   defence_config);
    case 'certified_defence'
        defence_results.certified_defence = implementCertifiedDefence(target_models, ...
                                                                     attack_results, ...
                                                                     defence_config);
end
end

fprintf(' Defence mechanisms implemented: %d defence types\n', length(defence_types));
end

function adversarial_training_results = implementAdversarialTraining(target_models, attack_results, defence_config)
% Implement adversarial training defence mechanism

adversarial_training_results = struct();
training_ratio = defence_config.training_adversarial_ratio;

fprintf(' Training robust model with adversarial examples...\n');

% Extract adversarial examples from attack results
adversarial_data = extractAdversarialData(attack_results);
clean_data = target_models.training_data.features;
clean_labels = target_models.training_data.labels;

% Create mixed training dataset
num_adversarial = round(training_ratio * size(clean_data, 2));
selected_adversarial_indices = randperm(size(adversarial_data, 2), num_adversarial);

mixed_training_data = [clean_data, adversarial_data(:, selected_adversarial_indices)];
mixed_training_labels = [clean_labels; clean_labels(selected_adversarial_indices)];

% Train robust model
robust_model = trainRobustModel(mixed_training_data, mixed_training_labels, target_models.architecture);

% Evaluate robust model performance
clean_accuracy = evaluateModelAccuracy(robust_model, clean_data, clean_labels);
adversarial_accuracy = evaluateModelAccuracy(robust_model, adversarial_data, clean_labels);

adversarial_training_results.robust_model = robust_model;
adversarial_training_results.clean_accuracy = clean_accuracy;
adversarial_training_results.adversarial_accuracy = adversarial_accuracy;
adversarial_training_results.robustness_improvement = adversarial_accuracy / ...
target_models.adversarial_baseline_accuracy;

fprintf(' Adversarial training completed: %.1f%% clean accuracy, %.1f%% adversarial accuracy\n', ...
clean_accuracy * 100, adversarial_accuracy * 100);
end

function preprocessing_results = implementInputPreprocessing(target_models, attack_results, defence_config)
% Implement input preprocessing defence mechanisms

preprocessing_results = struct();
preprocessing_methods = defence_config.preprocessing_methods;

for method_idx = 1:length(preprocessing_methods)
method = preprocessing_methods{method_idx};
fprintf(' Implementing %s preprocessing...\n', method);
 
% Extract adversarial examples
adversarial_data = extractAdversarialData(attack_results);

switch lower(method)
    case 'gaussian_noise'
        processed_data = addGaussianNoise(adversarial_data, 0.01);
    case 'median_filter'
        processed_data = applyMedianFilter(adversarial_data, 3);
    case 'jpeg_compression'
        processed_data = applySignalCompression(adversarial_data, 0.8);
end

% Evaluate preprocessing effectiveness
original_predictions = predict(target_models.primary_model, adversarial_data');
processed_predictions = predict(target_models.primary_model, processed_data');

defence_success_rate = calculateDefenceSuccessRate(original_predictions, processed_predictions);
clean_accuracy_preservation = evaluateCleanAccuracyPreservation(target_models.primary_model, ...
                                                               processed_data, ...
                                                               target_models.test_labels);

preprocessing_results.(method) = struct();
preprocessing_results.(method).processed_data = processed_data;
preprocessing_results.(method).defence_success_rate = defence_success_rate;
preprocessing_results.(method).clean_accuracy_preservation = clean_accuracy_preservation;
end

fprintf(' Input preprocessing implemented: %d methods\n', length(preprocessing_methods));
end
