%% lst_sol09_syntax_table.m
% Creating a formatted table in MATLAB.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : lst:sol09_syntax_table
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
comparisonTable = table(dimensionNames, ...
    stakeholderImpact, mitigationStrategies, ...
    'VariableNames', {'Dimension', 'Impact', ...
                      'Mitigation'});
disp(comparisonTable);
