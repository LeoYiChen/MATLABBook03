%% p7.m
% MATLABBook03_ChapterAIBHS_Problem07.m
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : p7
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function MATLABBook03_ChapterAIBHS_Problem07
% Purpose: compact U-Net lesion segmentation (synthetic).
% Author: Dr Leo Chen. R2024b + Deep Learning + Image Processing. v1.0.
    rng(0); S=64; n=120; img=zeros(S,S,1,n); msk=zeros(S,S,n);
    [xg,yg]=meshgrid(1:S,1:S);
    for i=1:n
        cx=randi([20 44]); cy=randi([20 44]); rad=randi([6 12]);
        les=(xg-cx).^2+(yg-cy).^2<=rad^2;
        img(:,:,1,i)=0.3*randn(S)+double(les); msk(:,:,i)=les;
    end
    lab=categorical(msk,[0 1],["background","lesion"]); sp=round(0.8*n);
    ds=combine(arrayDatastore(img(:,:,:,1:sp),'IterationDimension',4), ...
               arrayDatastore(lab(:,:,1:sp),'IterationDimension',3));
    net=trainNetwork(ds,unetLayers([S S 1],2,'EncoderDepth',2), ...
        trainingOptions('adam','MaxEpochs',8,'Verbose',false,'Plots','none'));
    d=zeros(n-sp,1);
    for i=sp+1:n
        pm=semanticseg(img(:,:,:,i),net)=="lesion"; tb=msk(:,:,i)==1;
        d(i-sp)=2*nnz(pm&tb)/(nnz(pm)+nnz(tb)+eps);
    end
    fprintf('Mean Dice: %.3f\n', mean(d));
end
