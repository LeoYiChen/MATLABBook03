%% chapter_AICSS_problem2_roc_analysis.m
% Comprehensive ROC analysis for security-safety trade-offs.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AICSS_problem2_roc_analysis
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function rocAnalysisResults = performComprehensiveROCAnalysis(predictionScores, groundTruthLabels, costMatrix, analysisOptions)
    % Comprehensive ROC analysis with cost-sensitive evaluation
    % Author: Dr Leo Chen
    % Version: 1.0 - Initial implementation
    % Date: December 2024
    
    fprintf('Executing comprehensive ROC analysis...\n');
    
    % Initialize results structure
    rocAnalysisResults = struct();
    rocAnalysisResults.timestamp = datetime('now');
    rocAnalysisResults.analysisOptions = analysisOptions;
    
    % Generate ROC curve using MATLAB's perfcurve function
    [falsePositiveRate, truePositiveRate, thresholds, areaUnderCurve, optimalPoint] = ...
        perfcurve(groundTruthLabels, predictionScores, 1);
    
    % Store basic ROC metrics
    rocAnalysisResults.fpr = falsePositiveRate;
    rocAnalysisResults.tpr = truePositiveRate;
    rocAnalysisResults.thresholds = thresholds;
    rocAnalysisResults.auc = areaUnderCurve;
    rocAnalysisResults.optimalPoint = optimalPoint;
    
    % Bootstrap confidence intervals for AUC
    bootstrapIterations = 1000;
    aucBootstrapSamples = bootstrp(bootstrapIterations, ...
        @(scores, labels) calculateBootstrapAUC(scores, labels), ...
        predictionScores, groundTruthLabels);
    
    confidenceLevel = 0.95;
    aucConfidenceInterval = prctile(aucBootstrapSamples, ...
        [100*(1-confidenceLevel)/2, 100*(1+confidenceLevel)/2]);
    rocAnalysisResults.aucConfidenceInterval = aucConfidenceInterval;
    
    % Cost-sensitive analysis
    costSensitiveResults = performCostSensitiveAnalysis(falsePositiveRate, truePositiveRate, ...
        thresholds, costMatrix);
    rocAnalysisResults.costSensitive = costSensitiveResults;
    
    % Multi-class ROC analysis if applicable
    uniqueLabels = unique(groundTruthLabels);
    if length(uniqueLabels) > 2
        multiclassResults = performMulticlassROCAnalysis(predictionScores, groundTruthLabels);
        rocAnalysisResults.multiclass = multiclassResults;
    end
    
    % Generate comprehensive visualisation
    generateROCvisualisation(rocAnalysisResults, analysisOptions);
    
    % Statistical significance testing
    rocAnalysisResults.significanceTest = performROCSignificanceTest(areaUnderCurve, length(predictionScores));
    
    % Save results
    saveROCResults(rocAnalysisResults);
    
    fprintf('ROC analysis completed. AUC: %.4f (95%% CI: %.4f-%.4f)\n', ...
        areaUnderCurve, aucConfidenceInterval(1), aucConfidenceInterval(2));
end

function costSensitiveResults = performCostSensitiveAnalysis(fpr, tpr, thresholds, costMatrix)
    % Perform cost-sensitive analysis for ROC evaluation
    
    costSensitiveResults = struct();
    
    % Extract cost parameters
    costFalsePositive = costMatrix.falsePositive;
    costFalseNegative = costMatrix.falseNegative;
    costTruePositive = costMatrix.truePositive;
    costTrueNegative = costMatrix.trueNegative;
    
    % Calculate expected cost for each threshold
    expectedCosts = zeros(length(thresholds), 1);
    for thresholdIndex = 1:length(thresholds)
        currentTPR = tpr(thresholdIndex);
        currentFPR = fpr(thresholdIndex);
        currentFNR = 1 - currentTPR;
        currentTNR = 1 - currentFPR;
        
        expectedCosts(thresholdIndex) = costTruePositive * currentTPR + ...
                                       costFalsePositive * currentFPR + ...
                                       costFalseNegative * currentFNR + ...
                                       costTrueNegative * currentTNR;
    end
    
    % Find optimal threshold based on minimum expected cost
    [minCost, optimalIndex] = min(expectedCosts);
    
    costSensitiveResults.expectedCosts = expectedCosts;
    costSensitiveResults.optimalThreshold = thresholds(optimalIndex);
    costSensitiveResults.optimalTPR = tpr(optimalIndex);
    costSensitiveResults.optimalFPR = fpr(optimalIndex);
    costSensitiveResults.minimumExpectedCost = minCost;
end

function generateROCvisualisation(results, options)
    % Generate comprehensive ROC analysis visualisation
    
    figure('Position', [100, 100, 1600, 1000]);
    
    % Main ROC curve
    subplot(2, 4, [1, 2]);
    plot(results.fpr, results.tpr, 'b-', 'LineWidth', 3);
    hold on;
    plot([0, 1], [0, 1], 'r--', 'LineWidth', 2);
    
    % Highlight optimal point
    if isfield(results, 'costSensitive')
        plot(results.costSensitive.optimalFPR, results.costSensitive.optimalTPR, ...
            'ro', 'MarkerSize', 12, 'MarkerFaceColor', 'red');
    end
    
    xlabel('False Positive Rate', 'FontSize', 12);
    ylabel('True Positive Rate', 'FontSize', 12);
    title(sprintf('ROC Curve (AUC = %.4f)', results.auc), 'FontSize', 14, 'FontWeight', 'bold');
    legend({'ROC Curve', 'Random Classifier', 'Optimal Point'}, 'Location', 'southeast');
    grid on;
    
    % AUC confidence interval visualisation
    subplot(2, 4, 3);
    confidenceInterval = results.aucConfidenceInterval;
    bar([results.auc], 'FaceColor', [0.3, 0.6, 0.9]);
    hold on;
    errorbar(1, results.auc, results.auc - confidenceInterval(1), ...
        confidenceInterval(2) - results.auc, 'k', 'LineWidth', 2, 'CapSize', 10);
    ylabel('AUC Value', 'FontSize', 12);
    title('AUC with 95% Confidence Interval', 'FontSize', 12, 'FontWeight', 'bold');
    ylim([0, 1]);
    grid on;
    
    % Cost-sensitive analysis
    if isfield(results, 'costSensitive')
        subplot(2, 4, 4);
        plot(results.thresholds, results.costSensitive.expectedCosts, 'g-', 'LineWidth', 2);
        hold on;
        plot(results.costSensitive.optimalThreshold, results.costSensitive.minimumExpectedCost, ...
            'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'red');
        xlabel('Decision Threshold', 'FontSize', 12);
        ylabel('Expected Cost', 'FontSize', 12);
        title('Cost-Sensitive Analysis', 'FontSize', 12, 'FontWeight', 'bold');
        legend({'Expected Cost', 'Optimal Point'}, 'Location', 'best');
        grid on;
    end
    
    % Precision-Recall curve
    subplot(2, 4, 5);
    precision = results.tpr ./ (results.tpr + results.fpr + eps);
    recall = results.tpr;
    plot(recall, precision, 'b-', 'LineWidth', 2);
    xlabel('Recall (True Positive Rate)', 'FontSize', 12);
    ylabel('Precision', 'FontSize', 12);
    title('Precision-Recall Curve', 'FontSize', 12, 'FontWeight', 'bold');
    grid on;
    
    % Threshold analysis
    subplot(2, 4, 6);
    plot(results.thresholds, results.tpr, 'b-', 'LineWidth', 2, 'DisplayName', 'True Positive Rate');
    hold on;
    plot(results.thresholds, results.fpr, 'r-', 'LineWidth', 2, 'DisplayName', 'False Positive Rate');
    xlabel('Decision Threshold', 'FontSize', 12);
    ylabel('Rate', 'FontSize', 12);
    title('Threshold vs. Performance Metrics', 'FontSize', 12, 'FontWeight', 'bold');
    legend('show', 'Location', 'best');
    grid on;
    
    % Performance metrics summary
    subplot(2, 4, 7);
    metricsLabels = {'AUC', 'Optimal TPR', 'Optimal FPR', 'Accuracy'};
    if isfield(results, 'costSensitive')
        optimalAccuracy = results.costSensitive.optimalTPR * 0.5 + (1 - results.costSensitive.optimalFPR) * 0.5;
        metricsValues = [results.auc, results.costSensitive.optimalTPR, ...
                        results.costSensitive.optimalFPR, optimalAccuracy];
    else
        metricsValues = [results.auc, 0.8, 0.2, 0.8]; % Default values
    end
    
    bar(metricsValues, 'FaceColor', [0.6, 0.8, 0.4]);
    set(gca, 'XTickLabel', metricsLabels);
    ylabel('Metric Value', 'FontSize', 12);
    title('Performance Metrics Summary', 'FontSize', 12, 'FontWeight', 'bold');
    ylim([0, 1]);
    grid on;
    
    % Statistical summary
    subplot(2, 4, 8);
    axis off;
    summaryText = sprintf('ROC Analysis Summary\n\n');
    summaryText = [summaryText, sprintf('AUC: %.4f\n', results.auc)];
    summaryText = [summaryText, sprintf('95%% CI: [%.4f, %.4f]\n', ...
        results.aucConfidenceInterval(1), results.aucConfidenceInterval(2))];
    if isfield(results, 'costSensitive')
        summaryText = [summaryText, sprintf('Optimal Threshold: %.3f\n', results.costSensitive.optimalThreshold)];
        summaryText = [summaryText, sprintf('Min Expected Cost: %.3f\n', results.costSensitive.minimumExpectedCost)];
    end
    summaryText = [summaryText, sprintf('Analysis Timestamp:\n%s', string(results.timestamp))];
    
    text(0.1, 0.9, summaryText, 'FontSize', 11, 'VerticalAlignment', 'top', ...
        'HorizontalAlignment', 'left', 'Interpreter', 'none', 'FontWeight', 'bold');
    
    % Save visualisation in multiple formats
    saveas(gcf, 'ROCAnalysisResults.fig');
    saveas(gcf, 'ROCAnalysisResults.eps', 'epsc');
    saveas(gcf, 'ROCAnalysisResults.jpg');
    
    fprintf('ROC analysis visualisation saved in multiple formats.\n');
end

function aucBootstrap = calculateBootstrapAUC(scores, labels)
    % Calculate bootstrap AUC sample
    try
        [~, ~, ~, aucBootstrap] = perfcurve(labels, scores, 1);
    catch
        aucBootstrap = 0.5; % Default value for failed calculations
    end
end
