%% chapter_AILMI_prob6_gnn.m
% Graph neural network for multi-hop reasoning.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AILMI_prob6_gnn
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [nodeEmbeddings, attentionWeights] = multihopGNN(nodeFeatures, adjacency, ...
                                                          questionVec, numHops, W, Wa)
    % Perform multi-hop message passing
    % nodeFeatures: [numNodes x featureDim]
    % adjacency: [numNodes x numNodes] sparse adjacency matrix
    % questionVec: [featureDim x 1] encoded question
    
    numNodes = size(nodeFeatures, 1);
    featureDim = size(nodeFeatures, 2);
    
    % Initialise node embeddings
    h = nodeFeatures;
    attentionWeights = cell(numHops, 1);
    
    % Multi-hop message passing
    for k = 1:numHops
        hNew = zeros(numNodes, featureDim);
        alpha = zeros(numNodes, numNodes);
        
        % For each node, aggregate information from neighbours
        for i = 1:numNodes
            neighbours = find(adjacency(i, :));
            
            if isempty(neighbours)
                hNew(i, :) = h(i, :);
                continue;
            end
            
            % Compute attention weights (question-guided)
            for j = neighbours
                % Concatenate node features with question
                combined = [h(i, :), h(j, :), questionVec'];
                
                % Attention score
                alpha(i, j) = questionVec' * (Wa * combined');
            end
            
            % Softmax normalisation over neighbours
            alpha(i, neighbours) = softmax(alpha(i, neighbours));
            
            % Aggregate messages
            messages = zeros(featureDim, 1);
            for j = neighbours
                messages = messages + alpha(i, j) * h(j, :)';
            end
            
            % Update with non-linearity
            hNew(i, :) = relu(W * messages)';
        end
        
        h = hNew;
        attentionWeights{k} = alpha;
    end
    
    nodeEmbeddings = h;
end
