%% lst_sol01_syntax_mfcc.m
% Basic audio read and MFCC computation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : lst:sol01_syntax_mfcc
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
[audioSignal, sampleRate] = audioread('filename.wav');
[mfccCoefficients, ~, ~, mfccTimeLocations] = ...
    mfcc(audioSignal, sampleRate);
