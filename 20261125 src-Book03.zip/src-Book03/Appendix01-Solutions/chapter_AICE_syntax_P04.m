%% chapter_AICE_syntax_P04.m
% Directed graph successor query syntax.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AICE_syntax_P04
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
affectedSpaces = successors(combinedGraph, failedNode);
duallyAffected = intersect(setA, setB);
% - Computational Complexity -
% successors returns the out-neighbours of a single node in
% O(degree) time, which for sparse BIM graphs is effectively
% constant. intersect on two small string arrays is O(n log n).
