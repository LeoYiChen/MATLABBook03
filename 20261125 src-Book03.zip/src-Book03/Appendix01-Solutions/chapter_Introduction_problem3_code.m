%% chapter_Introduction_problem3_code.m
% Cross-domain data import and processing.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_Introduction_problem3_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% MATLABBook03_Chapter01_Problem03.m
% Cross-Domain Data Import and Processing
% This script demonstrates how to import, process, and integrate data from
% multiple formats for multidisciplinary analysis

%% 1. Generate sample datasets in different formats
% For this example, we'll create three datasets that might come from
% different disciplines but share some common variables:
% - Economic data (CSV): GDP, unemployment, dates
% - Environmental data (Excel): temperature, precipitation, pollution, dates
% - Social data (JSON): population, education index, health index, dates

% Create a common time period for all datasets
dates = datetime(2010,1,1):calmonths(3):datetime(2020,12,31); % Quarterly data
dates = dates';
num_periods = length(dates);

% Create economic data (CSV)
gdp_growth = 2.5 + 1.5*sin(linspace(0, 6*pi, num_periods)') + 0.5*randn(num_periods, 1);
unemployment = 6 - 0.2*gdp_growth + 0.3*randn(num_periods, 1);
unemployment = max(unemployment, 3); % Ensure minimum value
economic_data = table(dates, gdp_growth, unemployment);

% Export to CSV
writetable(economic_data, 'economic_data.csv');
disp('Economic data saved to CSV file.');

% Create environmental data (Excel)
temp_anomaly = 0.2*linspace(0, 1, num_periods)' + 0.5*sin(linspace(0, 8*pi, num_periods)') + 0.3*randn(num_periods, 1);
precipitation = 800 + 100*sin(linspace(0, 4*pi, num_periods)') + 50*randn(num_periods, 1);
air_quality_index = 50 + 10*sin(linspace(0, 5*pi, num_periods)') - 2*precipitation/100 + 5*randn(num_periods, 1);
environmental_data = table(dates, temp_anomaly, precipitation, air_quality_index);

% Export to Excel
writetable(environmental_data, 'environmental_data.xlsx');
disp('Environmental data saved to Excel file.');

% Create social data (JSON)
population_millions = 25 + 0.2*linspace(0, num_periods-1, num_periods)' + 0.1*randn(num_periods, 1);
education_index = 0.7 + 0.002*linspace(0, num_periods-1, num_periods)' + 0.01*randn(num_periods, 1);
health_index = 0.8 + 0.001*linspace(0, num_periods-1, num_periods)' - 0.05*temp_anomaly + 0.01*randn(num_periods, 1);
social_data = table(datestr(dates, 'yyyy-mm-dd'), population_millions, education_index, health_index, ...
                  'VariableNames', {'date', 'population_millions', 'education_index', 'health_index'});

% Convert to JSON structure
json_struct = struct();
json_struct.data = table2struct(social_data);
json_struct.metadata.source = 'Social Indicators Database';
json_struct.metadata.updated = datestr(now, 'yyyy-mm-dd');

% Export to JSON
json_str = jsonencode(json_struct, 'PrettyPrint', true);
fid = fopen('social_data.json', 'w');
fprintf(fid, '%s', json_str);
fclose(fid);
disp('Social data saved to JSON file.');

%% 2. Import and process data from each format

% Function to import and process CSV data
function [processed_data] = importCSV(filename)
    % Import data
    data = readtable(filename);
    
    % Check for missing values
    missing_count = sum(ismissing(data));
    if any(missing_count)
        warning('Missing values detected in CSV data:');
        disp(table(data.Properties.VariableNames', missing_count', ...
             'VariableNames', {'Variable', 'MissingCount'}));
        
        % Fill missing values with interpolation for numeric columns
        data = fillmissing(data, 'linear');
    end
    
    % Convert date strings to datetime if needed
    if ~isdatetime(data.dates)
        data.dates = datetime(data.dates);
    end
    
    % Add year and quarter columns for easier merging
    data.year = year(data.dates);
    data.quarter = quarter(data.dates);
    
    % Calculate z-scores for numeric variables
    numeric_vars = varfun(@isnumeric, data, 'OutputFormat', 'uniform');
    numeric_cols = data.Properties.VariableNames(numeric_vars);
    numeric_cols = setdiff(numeric_cols, {'year', 'quarter'}); % Exclude year and quarter
    
    for i = 1:length(numeric_cols)
        col_name = numeric_cols{i};
        z_col_name = ['z_', col_name];
        data.(z_col_name) = zscore(data.(col_name));
    end
    
    % Return processed data
    processed_data = data;
    disp('CSV data imported and processed successfully.');
end

% Function to import and process Excel data
function [processed_data] = importExcel(filename)
    % Import data
    data = readtable(filename);
    
    % Check for missing values
    missing_count = sum(ismissing(data));
    if any(missing_count)
        warning('Missing values detected in Excel data:');
        disp(table(data.Properties.VariableNames', missing_count', ...
             'VariableNames', {'Variable', 'MissingCount'}));
        
        % Fill missing values with interpolation for numeric columns
        data = fillmissing(data, 'linear');
    end
    
    % Convert date strings to datetime if needed
    if ~isdatetime(data.dates)
        data.dates = datetime(data.dates);
    end
    
    % Add year and quarter columns for easier merging
    data.year = year(data.dates);
    data.quarter = quarter(data.dates);
    
    % Calculate rolling averages for environmental data (common preprocessing)
    if ismember('temp_anomaly', data.Properties.VariableNames)
        data.temp_anomaly_12mo = movmean(data.temp_anomaly, [3, 0]);
    end
    
    if ismember('precipitation', data.Properties.VariableNames)
        data.precip_12mo = movmean(data.precipitation, [3, 0]);
    end
    
    % Calculate derived features
    if ismember('temp_anomaly', data.Properties.VariableNames) && ...
       ismember('precipitation', data.Properties.VariableNames)
        % Create drought index (simplified)
        data.drought_index = zscore(data.temp_anomaly - data.precipitation/100);
    end
    
    % Return processed data
    processed_data = data;
    disp('Excel data imported and processed successfully.');
end

% Function to import and process JSON data
function [processed_data] = importJSON(filename)
    % Read JSON file
    fid = fopen(filename, 'r');
    raw_data = fread(fid, '*char')';
    fclose(fid);
    
    % Parse JSON
    json_data = jsondecode(raw_data);
    
    % Extract data and convert to table
    if isfield(json_data, 'data')
        data = struct2table(json_data.data);
    else
        data = struct2table(json_data);
    end
    
    % Convert date strings to datetime
    if ismember('date', data.Properties.VariableNames)
        data.dates = datetime(data.date);
        data = removevars(data, 'date');
    end
    
    % Add year and quarter columns for easier merging
    data.year = year(data.dates);
    data.quarter = quarter(data.dates);
    
    % Calculate derived indicators
    if ismember('education_index', data.Properties.VariableNames) && ...
       ismember('health_index', data.Properties.VariableNames)
        % Create human development index (simplified)
        data.hdi = (data.education_index + data.health_index) / 2;
    end
    
    % Return processed data
    processed_data = data;
    disp('JSON data imported and processed successfully.');
end

% Now import and process each dataset
econ_data = importCSV('economic_data.csv');
env_data = importExcel('environmental_data.xlsx');
social_data = importJSON('social_data.json');

%% 3. Merge datasets

% Function to merge multiple datasets based on common fields
function [merged_data] = mergeDatasets(datasets, merge_vars)
    % Start with the first dataset
    merged_data = datasets{1};
    
    % Merge with each additional dataset
    for i = 2:length(datasets)
        merged_data = outerjoin(merged_data, datasets{i}, 'Keys', merge_vars, ...
                              'MergeKeys', true);
    end
    
    % Handle duplicate variable names from the join
    % Look for variable names ending with _dataset2, etc.
    var_names = merged_data.Properties.VariableNames;
    for i = 1:length(var_names)
        if contains(var_names{i}, '_dataset')
            % Extract original name (before _dataset)
            original_name = regexp(var_names{i}, '(.+)_dataset\d+', 'tokens');
            if ~isempty(original_name)
                original_name = original_name{1}{1};
                % If both variables exist, use the non-NaN value
                if ismember(original_name, var_names)
                    % Create a new column with non-NaN values from either column
                    new_col = merged_data.(original_name);
                    nan_indices = isnan(new_col);
                    new_col(nan_indices) = merged_data.(var_names{i})(nan_indices);
                    merged_data.(original_name) = new_col;
                    % Remove the duplicate column
                    merged_data = removevars(merged_data, var_names{i});
                else
                    % Rename the column to the original name
                    merged_data.Properties.VariableNames{i} = original_name;
                end
            end
        end
    end
    
    % Sort by date
    if ismember('dates', merged_data.Properties.VariableNames)
        merged_data = sortrows(merged_data, 'dates');
    end
end

% Merge the three datasets based on year and quarter
datasets = {econ_data, env_data, social_data};
merge_vars = {'year', 'quarter'};
integrated_data = mergeDatasets(datasets, merge_vars);

disp('Datasets merged successfully.');
disp(['Integrated dataset contains ' num2str(height(integrated_data)) ' rows and ' ...
     num2str(width(integrated_data)) ' columns.']);

%% 4. Analyze integrated dataset

% Display summary statistics
summary_stats = varfun(@(x) [mean(x, 'omitnan'), std(x, 'omitnan'), ...
                           min(x, 'omitnan'), max(x, 'omitnan')], ...
                     integrated_data, 'InputVariables', @isnumeric, ...
                     'OutputFormat', 'table');
summary_stats.Properties.RowNames = integrated_data.Properties.VariableNames(summary_stats.Row);
summary_stats.Properties.VariableNames = {'Mean', 'StdDev', 'Min', 'Max'};
disp('Summary statistics for integrated dataset:');
disp(summary_stats);

% Check for correlations between variables from different domains
numeric_vars = varfun(@isnumeric, integrated_data, 'OutputFormat', 'uniform');
numeric_vars = numeric_vars & ~ismember(integrated_data.Properties.VariableNames, ...
                                    {'year', 'quarter'});
numeric_data = integrated_data(:, numeric_vars);

correlation_matrix = corr(table2array(numeric_data), 'rows', 'complete');
var_names = numeric_data.Properties.VariableNames;

% Display top 5 strongest cross-domain correlations
corr_pairs = [];
for i = 1:length(var_names)
    for j = i+1:length(var_names)
        corr_pairs = [corr_pairs; i, j, correlation_matrix(i,j)];
    end
end

% Sort by absolute correlation
[~, idx] = sort(abs(corr_pairs(:,3)), 'descend');
corr_pairs = corr_pairs(idx,:);

disp('Top 5 strongest variable correlations across domains:');
for i = 1:min(5, size(corr_pairs, 1))
    var1 = var_names{corr_pairs(i,1)};
    var2 = var_names{corr_pairs(i,2)};
    corr_val = corr_pairs(i,3);
    fprintf('%s and %s: %.4f\n', var1, var2, corr_val);
end

%% 5. Visualize integrated data

% Create a figure showing relationships between variables from different domains
figure('Name', 'Integrated Cross-Domain Analysis', 'Position', [100, 100, 1200, 800]);

% Plot 1: Economic and Environmental Trends
subplot(2, 2, 1);
yyaxis left
plot(integrated_data.dates, integrated_data.gdp_growth, 'b-', 'LineWidth', 1.5);
ylabel('GDP Growth (%)');

yyaxis right
plot(integrated_data.dates, integrated_data.temp_anomaly, 'r-', 'LineWidth', 1.5);
ylabel('Temperature Anomaly (--C)');

title('Economic Growth and Temperature Anomaly');
grid on;
legend('GDP Growth', 'Temperature Anomaly', 'Location', 'northwest');

% Plot 2: Social and Environmental Correlation
subplot(2, 2, 2);
scatter(integrated_data.air_quality_index, integrated_data.health_index, 50, ...
      integrated_data.year, 'filled');
colormap(jet);
colorbar;
xlabel('Air Quality Index');
ylabel('Health Index');
title('Health Index vs. Air Quality');
grid on;

% Plot 3: Combined Trend Analysis
subplot(2, 2, 3);
% Normalize key variables for comparison
vars_to_plot = {'gdp_growth', 'unemployment', 'health_index', 'temp_anomaly'};
norm_data = zeros(height(integrated_data), length(vars_to_plot));

for i = 1:length(vars_to_plot)
    var_data = integrated_data.(vars_to_plot{i});
    norm_data(:,i) = (var_data - min(var_data)) / (max(var_data) - min(var_data));
end

plot(integrated_data.dates, norm_data, 'LineWidth', 1.5);
legend(vars_to_plot, 'Location', 'best');
title('Normalized Trends Across Domains');
ylabel('Normalized Value');
grid on;

% Plot 4: Matrix of scatter plots for key variables
subplot(2, 2, 4);
key_vars = {'gdp_growth', 'unemployment', 'temp_anomaly', 'health_index'};
[~, ax] = plotmatrix(integrated_data{:, key_vars});

% Add variable names to the diagonal plots
for i = 1:length(key_vars)
    ylabel(ax(i,1), key_vars{i}, 'Rotation', 0, 'HorizontalAlignment', 'right');
    title(ax(1,i), key_vars{i});
end

%% 6. Export the integrated dataset
% Export to CSV for general use
writetable(integrated_data, 'integrated_multidisciplinary_data.csv');

% Export to MAT file for MATLAB users
save('integrated_multidisciplinary_data.mat', 'integrated_data');

% Export to Excel with multiple sheets
% First sheet: Integrated data
% Second sheet: Metadata and summary
% Third sheet: Correlation matrix

% Create Excel file
filename = 'integrated_multidisciplinary_data.xlsx';
writetable(integrated_data, filename, 'Sheet', 'IntegratedData');

% Create metadata sheet
metadata = table({'Economic (CSV)'; 'Environmental (Excel)'; 'Social (JSON)'}, ...
               {'Economic indicators'; 'Climate measurements'; 'Social indicators'}, ...
               {'Quarterly GDP and unemployment'; 'Temperature and precipitation'; 'Population and development indices'}, ...
               'VariableNames', {'Source', 'Type', 'Description'});
writetable(metadata, filename, 'Sheet', 'Metadata');

% Add summary statistics
writetable(summary_stats, filename, 'Sheet', 'Metadata', 'Range', 'A6');

% Create correlation matrix sheet
correlation_table = array2table(correlation_matrix, 'VariableNames', var_names, 'RowNames', var_names);
writetable(correlation_table, filename, 'Sheet', 'Correlations', 'WriteRowNames', true);

disp(['Integrated dataset exported to CSV, MAT, and Excel formats in folder: ' pwd]);
