%% chapter_Introduction_problem7_code.m
% Interactive multidisciplinary dashboard creation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_Introduction_problem7_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% MATLABBook03_Chapter01_Problem07.m
% Interactive Dashboard Creation Using App Designer
% This script demonstrates how to create an interactive dashboard
% for multidisciplinary data exploration

%% 1. CREATE THE SAMPLE DATASET
% We'll create a sample dataset about cities with variables relevant to
% different disciplines: environmental, economic, and health

% Number of cities and years
num_cities = 50;
years = 2010:2020;
num_years = length(years);

% City names (randomly generated for this example)
city_prefixes = {'North', 'South', 'East', 'West', 'New', 'Old', 'Lake', 'River', 'Mount', 'Port'};
city_roots = {'bridge', 'ford', 'haven', 'ville', 'burg', 'ton', 'field', 'wood', 'land', 'view'};
city_suffixes = {'City', 'Town', 'Heights', 'Springs', 'Junction', '', '', '', '', ''};

rng(42); % For reproducibility
city_names = cell(num_cities, 1);
for i = 1:num_cities
    prefix = city_prefixes{randi(length(city_prefixes))};
    root = city_roots{randi(length(city_roots))};
    suffix = city_suffixes{randi(length(city_suffixes))};
    
    if ~isempty(suffix)
        city_names{i} = [prefix, ' ', root, ' ', suffix];
    else
        city_names{i} = [prefix, ' ', root];
    end
end

% Generate country/region assignments (5 regions)
regions = {'North America', 'Europe', 'Asia', 'Africa', 'South America'};
city_regions = regions(randi(length(regions), num_cities, 1));

% City populations (ranging from small towns to major cities)
population_base = 10000 * 10.^(3*rand(num_cities, 1)); % Range from 10K to 10M
population_growth = 1 + 0.02 * randn(num_cities, num_years); % Annual growth factors
population_growth = cumprod(population_growth, 2); % Cumulative growth

city_populations = zeros(num_cities, num_years);
for i = 1:num_cities
    city_populations(i,:) = population_base(i) * population_growth(i,:);
end

% Environmental variables
% 1. Air Quality Index (AQI) - lower is better
aqi_base = 30 + 70 * rand(num_cities, 1); % Base AQI from 30-100
aqi_trend = -0.5 + rand(num_cities, 1); % Improvement trend between -0.5 and +0.5 per year
aqi_seasonal = 10 * rand(num_cities, 1); % Seasonal variation magnitude
aqi_noise = 5 * randn(num_cities, num_years); % Random fluctuations

air_quality = zeros(num_cities, num_years);
for i = 1:num_cities
    for j = 1:num_years
        seasonal_component = aqi_seasonal(i) * sin(2*pi*((j-1)/num_years));
        trend_component = aqi_trend(i) * (j-1);
        
        air_quality(i,j) = max(10, aqi_base(i) + trend_component + seasonal_component + aqi_noise(i,j));
    end
end

% 2. Green Space (percentage of city area)
green_space_base = 5 + 45 * rand(num_cities, 1); % Base green space from 5-50%
green_space_trend = -0.2 + 0.5 * rand(num_cities, 1); % Trend between -0.2 and +0.3 per year
green_space_noise = 0.5 * randn(num_cities, num_years); % Random fluctuations

green_space = zeros(num_cities, num_years);
for i = 1:num_cities
    for j = 1:num_years
        trend_component = green_space_trend(i) * (j-1);
        
        green_space(i,j) = min(60, max(2, green_space_base(i) + trend_component + green_space_noise(i,j)));
    end
end

% 3. Water Quality Index (0-100, higher is better)
water_quality_base = 50 + 40 * rand(num_cities, 1); % Base water quality from 50-90
water_quality_trend = -0.5 + 1.0 * rand(num_cities, 1); % Trend between -0.5 and +0.5 per year
water_quality_noise = 2 * randn(num_cities, num_years); % Random fluctuations

water_quality = zeros(num_cities, num_years);
for i = 1:num_cities
    for j = 1:num_years
        trend_component = water_quality_trend(i) * (j-1);
        
        water_quality(i,j) = min(100, max(0, water_quality_base(i) + trend_component + water_quality_noise(i,j)));
    end
end

% Economic variables
% 1. GDP per capita (USD)
gdp_base = 5000 + 50000 * rand(num_cities, 1); % Base GDP from 5K-55K USD
gdp_growth = 1 + 0.05 * randn(num_cities, num_years); % Annual growth factors
gdp_growth = cumprod(gdp_growth, 2); % Cumulative growth

gdp_per_capita = zeros(num_cities, num_years);
for i = 1:num_cities
    gdp_per_capita(i,:) = gdp_base(i) * gdp_growth(i,:);
end

% 2. Unemployment rate (%)
unemployment_base = 3 + 12 * rand(num_cities, 1); % Base unemployment from 3-15%
unemployment_cycle = 2 + 3 * rand(num_cities, 1); % Cyclical variation magnitude
unemployment_phase = 2 * pi * rand(num_cities, 1); % Random phase for cycles
unemployment_noise = 0.5 * randn(num_cities, num_years); % Random fluctuations

unemployment = zeros(num_cities, num_years);
for i = 1:num_cities
    for j = 1:num_years
        cycle_component = unemployment_cycle(i) * sin(2*pi*((j-1)/5) + unemployment_phase(i));
        
        unemployment(i,j) = max(1, unemployment_base(i) + cycle_component + unemployment_noise(i,j));
    end
end

% 3. Housing Affordability Index (ratio of median home price to median income, lower is better)
housing_base = 3 + 7 * rand(num_cities, 1); % Base affordability from 3-10
housing_trend = -0.1 + 0.3 * rand(num_cities, 1); % Trend between -0.1 and +0.2 per year
housing_noise = 0.2 * randn(num_cities, num_years); % Random fluctuations

housing_affordability = zeros(num_cities, num_years);
for i = 1:num_cities
    for j = 1:num_years
        trend_component = housing_trend(i) * (j-1);
        
        housing_affordability(i,j) = max(2, housing_base(i) + trend_component + housing_noise(i,j));
    end
end

% Health variables
% 1. Life expectancy (years)
life_exp_base = 65 + 20 * rand(num_cities, 1); % Base life expectancy from 65-85 years
life_exp_trend = 0.1 + 0.2 * rand(num_cities, 1); % Improvement trend between 0.1 and 0.3 per year
life_exp_noise = 0.1 * randn(num_cities, num_years); % Random fluctuations

life_expectancy = zeros(num_cities, num_years);
for i = 1:num_cities
    for j = 1:num_years
        trend_component = life_exp_trend(i) * (j-1);
        
        life_expectancy(i,j) = min(90, life_exp_base(i) + trend_component + life_exp_noise(i,j));
    end
end

% 2. Infant mortality rate (per 1000 live births)
infant_mort_base = 2 + 30 * rand(num_cities, 1); % Base infant mortality from 2-32
infant_mort_trend = -2 * rand(num_cities, 1); % Improvement trend between 0 and -2 per year
infant_mort_noise = 0.5 * randn(num_cities, num_years); % Random fluctuations

infant_mortality = zeros(num_cities, num_years);
for i = 1:num_cities
    for j = 1:num_years
        trend_component = infant_mort_trend(i) * (j-1);
        
        infant_mortality(i,j) = max(1, infant_mort_base(i) + trend_component + infant_mort_noise(i,j));
    end
end

% 3. Healthcare access index (0-100, higher is better)
healthcare_base = 40 + 50 * rand(num_cities, 1); % Base healthcare access from 40-90
healthcare_trend = 0.5 + 1.0 * rand(num_cities, 1); % Improvement trend between 0.5 and 1.5 per year
healthcare_noise = 1.0 * randn(num_cities, num_years); % Random fluctuations

healthcare_access = zeros(num_cities, num_years);
for i = 1:num_cities
    for j = 1:num_years
        trend_component = healthcare_trend(i) * (j-1);
        
        healthcare_access(i,j) = min(100, max(0, healthcare_base(i) + trend_component + healthcare_noise(i,j)));
    end
end

% Create correlations between variables
% 1. GDP influences healthcare access
for i = 1:num_cities
    for j = 1:num_years
        gdp_factor = (gdp_per_capita(i,j) - min(gdp_per_capita(:))) / (max(gdp_per_capita(:)) - min(gdp_per_capita(:)));
        healthcare_access(i,j) = healthcare_access(i,j) * (0.7 + 0.3 * gdp_factor);
    end
end

% 2. Air quality affects life expectancy
for i = 1:num_cities
    for j = 1:num_years
        aqi_factor = 1 - (air_quality(i,j) - min(air_quality(:))) / (max(air_quality(:)) - min(air_quality(:)));
        life_expectancy(i,j) = life_expectancy(i,j) * (0.9 + 0.1 * aqi_factor);
    end
end

% 3. Unemployment affects housing affordability
for i = 1:num_cities
    for j = 1:num_years
        unemp_factor = (unemployment(i,j) - min(unemployment(:))) / (max(unemployment(:)) - min(unemployment(:)));
        housing_affordability(i,j) = housing_affordability(i,j) * (0.8 + 0.2 * unemp_factor);
    end
end

% Combine all data into a table structure
city_data = table();

% Expand data for all years
data_rows = num_cities * num_years;
city_data.City = repelem(city_names, num_years);
city_data.Region = repelem(city_regions, num_years);
city_data.Year = reshape(repmat(years, num_cities, 1), [], 1);

% Reshape all variables to be column vectors
city_data.Population = reshape(city_populations', [], 1);
city_data.AirQualityIndex = reshape(air_quality', [], 1);
city_data.GreenSpacePercent = reshape(green_space', [], 1);
city_data.WaterQualityIndex = reshape(water_quality', [], 1);
city_data.GDPPerCapita = reshape(gdp_per_capita', [], 1);
city_data.UnemploymentRate = reshape(unemployment', [], 1);
city_data.HousingAffordabilityIndex = reshape(housing_affordability', [], 1);
city_data.LifeExpectancy = reshape(life_expectancy', [], 1);
city_data.InfantMortality = reshape(infant_mortality', [], 1);
city_data.HealthcareAccessIndex = reshape(healthcare_access', [], 1);

% Save the data to CSV file for the dashboard to read
writetable(city_data, 'city_multidisciplinary_data.csv');
fprintf('Created sample dataset with %d cities over %d years (%d total records).\n', ...
       num_cities, num_years, height(city_data));

%% 2. APP DESIGNER CODE FOR THE DASHBOARD
% The following code represents what would be created in App Designer.
% In practice, you would create this using the App Designer interface.
% Here we show the programmatic representation of what the app would contain.

% Note: In a real implementation, this would be created using App Designer's
% visual interface, not as a script. The following is a representation of the
% components and callbacks that would be implemented.

function createCityDashboardApp()
    % Create the UI figure and components
    app.UIFigure = uifigure('Name', 'Multidisciplinary City Dashboard', ...
                           'Position', [100, 100, 1200, 800]);
    
    % Create tab group for different disciplinary perspectives
    app.TabGroup = uitabgroup(app.UIFigure, 'Position', [20, 20, 1160, 750]);
    
    % Load Data Tab
    app.LoadDataTab = uitab(app.TabGroup, 'Title', 'Data Loading');
    createLoadDataPanel(app);
    
    % Environmental Tab
    app.EnvironmentalTab = uitab(app.TabGroup, 'Title', 'Environmental');
    createEnvironmentalPanel(app);
    
    % Economic Tab
    app.EconomicTab = uitab(app.TabGroup, 'Title', 'Economic');
    createEconomicPanel(app);
    
    % Health Tab
    app.HealthTab = uitab(app.TabGroup, 'Title', 'Health');
    createHealthPanel(app);
    
    % Cross-Domain Analysis Tab
    app.CrossDomainTab = uitab(app.TabGroup, 'Title', 'Cross-Domain Analysis');
    createCrossDomainPanel(app);
    
    % Statistics and Export Tab
    app.StatsTab = uitab(app.TabGroup, 'Title', 'Statistics & Export');
    createStatsPanel(app);
    
    % Initialize app properties
    app.Data = table(); % Will hold the loaded data
    app.FilteredData = table(); % Will hold filtered data
    app.SelectedCities = {}; % Will hold selected cities
    app.SelectedYears = []; % Will hold selected years
    
    % Initialize the app
    initializeApp(app);
end

function createLoadDataPanel(app)
    % Create panel for data loading and filtering
    loadPanel = uipanel(app.LoadDataTab, 'Title', 'Data Loading and Filtering', ...
                       'Position', [20, 20, 1120, 700]);
    
    % Data loading section
    loadDataBtn = uibutton(loadPanel, 'Text', 'Load Data File', ...
                         'Position', [20, 650, 150, 30], ...
                         'ButtonPushedFcn', @(btn,event) loadDataBtnPushed(app));
    
    app.DataPathLabel = uilabel(loadPanel, 'Text', 'No data loaded', ...
                              'Position', [180, 650, 500, 30]);
    
    % City selection section
    cityListLabel = uilabel(loadPanel, 'Text', 'Available Cities:', ...
                          'Position', [20, 600, 150, 30]);
    app.CityListBox = uilistbox(loadPanel, 'Position', [20, 400, 200, 200], ...
                             'MultiSelect', 'on', ...
                             'ValueChangedFcn', @(lb,event) citySelectionChanged(app));
    
    selectAllCitiesBtn = uibutton(loadPanel, 'Text', 'Select All', ...
                                'Position', [20, 370, 90, 25], ...
                                'ButtonPushedFcn', @(btn,event) selectAllCities(app));
    
    clearCitiesBtn = uibutton(loadPanel, 'Text', 'Clear All', ...
                            'Position', [120, 370, 90, 25], ...
                            'ButtonPushedFcn', @(btn,event) clearAllCities(app));
    
    % Region filter
    regionLabel = uilabel(loadPanel, 'Text', 'Filter by Region:', ...
                        'Position', [20, 340, 150, 30]);
    app.RegionDropDown = uidropdown(loadPanel, 'Position', [20, 310, 200, 30], ...
                                 'ValueChangedFcn', @(dd,event) regionFilterChanged(app));
    
    % Year selection
    yearRangeLabel = uilabel(loadPanel, 'Text', 'Year Range:', ...
                           'Position', [20, 270, 150, 30]);
    app.YearSlider = uislider(loadPanel, 'Position', [20, 250, 200, 3], ...
                           'Limits', [2010, 2020], ...
                           'Value', [2010, 2020], ...
                           'ValueChangedFcn', @(s,event) yearRangeChanged(app));
    
    app.YearRangeLabel = uilabel(loadPanel, 'Text', '2010-2020', ...
                               'Position', [230, 240, 100, 30]);
    
    % Variable information
    varInfoLabel = uilabel(loadPanel, 'Text', 'Dataset Variables:', ...
                         'Position', [350, 600, 150, 30]);
    app.VariableInfoTable = uitable(loadPanel, 'Position', [350, 400, 750, 200], ...
                                 'ColumnName', {'Variable', 'Domain', 'Description', 'Min', 'Max', 'Mean'}, ...
                                 'ColumnWidth', {150, 100, 300, 70, 70, 70});
    
    % Data preview
    dataPreviewLabel = uilabel(loadPanel, 'Text', 'Data Preview:', ...
                             'Position', [350, 370, 150, 30]);
    app.DataPreviewTable = uitable(loadPanel, 'Position', [350, 100, 750, 270]);
    
    % Apply filters button
    app.ApplyFiltersBtn = uibutton(loadPanel, 'Text', 'Apply Filters', ...
                                'Position', [20, 100, 200, 30], ...
                                'ButtonPushedFcn', @(btn,event) applyFilters(app));
    
    % Reset filters button
    resetFiltersBtn = uibutton(loadPanel, 'Text', 'Reset Filters', ...
                             'Position', [20, 60, 200, 30], ...
                             'ButtonPushedFcn', @(btn,event) resetFilters(app));
    
    % Filter status
    app.FilterStatusLabel = uilabel(loadPanel, 'Text', 'No filters applied', ...
                                 'Position', [20, 20, 350, 30]);
end

function createEnvironmentalPanel(app)
    % Create panel for environmental analysis
    envPanel = uipanel(app.EnvironmentalTab, 'Title', 'Environmental Indicators', ...
                      'Position', [20, 20, 1120, 700]);
    
    % Control panel on the left
    controlPanel = uipanel(envPanel, 'Title', 'Controls', ...
                          'Position', [10, 10, 200, 680]);
    
    % visualisation selection
    vizLabel = uilabel(controlPanel, 'Text', 'visualisation Type:', ...
                     'Position', [10, 640, 180, 30]);
    app.EnvVizDropDown = uidropdown(controlPanel, ...
                                 'Position', [10, 610, 180, 30], ...
                                 'Items', {'Air Quality Trends', 'Green Space Comparison', 'Water Quality Map'}, ...
                                 'ValueChangedFcn', @(dd,event) updateEnvironmentalViz(app));
    
    % Variable selection
    varLabel = uilabel(controlPanel, 'Text', 'Variable:', ...
                     'Position', [10, 570, 180, 30]);
    app.EnvVarDropDown = uidropdown(controlPanel, ...
                                 'Position', [10, 540, 180, 30], ...
                                 'Items', {'AirQualityIndex', 'GreenSpacePercent', 'WaterQualityIndex'}, ...
                                 'ValueChangedFcn', @(dd,event) updateEnvironmentalViz(app));
    
    % Grouping options
    groupLabel = uilabel(controlPanel, 'Text', 'Group By:', ...
                       'Position', [10, 500, 180, 30]);
    app.EnvGroupDropDown = uidropdown(controlPanel, ...
                                   'Position', [10, 470, 180, 30], ...
                                   'Items', {'None', 'Region', 'Population Size'}, ...
                                   'ValueChangedFcn', @(dd,event) updateEnvironmentalViz(app));
    
    % visualisation options
    optionsLabel = uilabel(controlPanel, 'Text', 'Options:', ...
                         'Position', [10, 430, 180, 30]);
    app.EnvShowTrendCheckBox = uicheckbox(controlPanel, ...
                                       'Text', 'Show Trendline', ...
                                       'Position', [10, 400, 180, 30], ...
                                       'ValueChangedFcn', @(cb,event) updateEnvironmentalViz(app));
    app.EnvShowAvgCheckBox = uicheckbox(controlPanel, ...
                                     'Text', 'Show Averages', ...
                                     'Position', [10, 370, 180, 30], ...
                                     'ValueChangedFcn', @(cb,event) updateEnvironmentalViz(app));
    
    % Update button
    updateEnvBtn = uibutton(controlPanel, 'Text', 'Update visualisation', ...
                          'Position', [10, 330, 180, 30], ...
                          'ButtonPushedFcn', @(btn,event) updateEnvironmentalViz(app));
    
    % Information panel
    infoLabel = uilabel(controlPanel, 'Text', 'Environmental Indicators:', ...
                      'Position', [10, 290, 180, 30]);
    app.EnvInfoTextArea = uitextarea(controlPanel, ...
                                  'Position', [10, 100, 180, 180], ...
                                  'Value', {
                                      'Environmental indicators show the quality of natural resources and sustainability.', 
                                      '', 
                                      'Air Quality Index (AQI):',
                                      'Lower values indicate cleaner air.',
                                      '',
                                      'Green Space Percentage:',
                                      'Higher values indicate more parks and natural areas.',
                                      '',
                                      'Water Quality Index:',
                                      'Higher values indicate cleaner water.'
                                  }, ...
                                  'Editable', 'off');
    
    % Main visualisation area
    app.EnvPlotPanel = uipanel(envPanel, 'Title', 'visualisation', ...
                            'Position', [220, 10, 890, 680]);
    app.EnvAxes = uiaxes(app.EnvPlotPanel, 'Position', [10, 10, 870, 640]);
end

function createEconomicPanel(app)
    % Create panel for economic analysis
    econPanel = uipanel(app.EconomicTab, 'Title', 'Economic Indicators', ...
                       'Position', [20, 20, 1120, 700]);
    
    % Control panel on the left
    controlPanel = uipanel(econPanel, 'Title', 'Controls', ...
                          'Position', [10, 10, 200, 680]);
    
    % visualisation selection
    vizLabel = uilabel(controlPanel, 'Text', 'visualisation Type:', ...
                     'Position', [10, 640, 180, 30]);
    app.EconVizDropDown = uidropdown(controlPanel, ...
                                  'Position', [10, 610, 180, 30], ...
                                  'Items', {'GDP Growth Trends', 'Unemployment Comparison', 'Housing Affordability Matrix'}, ...
                                  'ValueChangedFcn', @(dd,event) updateEconomicViz(app));
    
    % Variable selection
    varLabel = uilabel(controlPanel, 'Text', 'Variable:', ...
                     'Position', [10, 570, 180, 30]);
    app.EconVarDropDown = uidropdown(controlPanel, ...
                                  'Position', [10, 540, 180, 30], ...
                                  'Items', {'GDPPerCapita', 'UnemploymentRate', 'HousingAffordabilityIndex'}, ...
                                  'ValueChangedFcn', @(dd,event) updateEconomicViz(app));
    
    % Grouping options
    groupLabel = uilabel(controlPanel, 'Text', 'Group By:', ...
                       'Position', [10, 500, 180, 30]);
    app.EconGroupDropDown = uidropdown(controlPanel, ...
                                    'Position', [10, 470, 180, 30], ...
                                    'Items', {'None', 'Region', 'Population Size'}, ...
                                    'ValueChangedFcn', @(dd,event) updateEconomicViz(app));
    
    % visualisation options
    optionsLabel = uilabel(controlPanel, 'Text', 'Options:', ...
                         'Position', [10, 430, 180, 30]);
    app.EconShowGrowthCheckBox = uicheckbox(controlPanel, ...
                                         'Text', 'Show Growth Rate', ...
                                         'Position', [10, 400, 180, 30], ...
                                         'ValueChangedFcn', @(cb,event) updateEconomicViz(app));
    app.EconNormalizeCheckBox = uicheckbox(controlPanel, ...
                                        'Text', 'Normalize Values', ...
                                        'Position', [10, 370, 180, 30], ...
                                        'ValueChangedFcn', @(cb,event) updateEconomicViz(app));
    
    % Update button
    updateEconBtn = uibutton(controlPanel, 'Text', 'Update visualisation', ...
                           'Position', [10, 330, 180, 30], ...
                           'ButtonPushedFcn', @(btn,event) updateEconomicViz(app));
    
    % Information panel
    infoLabel = uilabel(controlPanel, 'Text', 'Economic Indicators:', ...
                      'Position', [10, 290, 180, 30]);
    app.EconInfoTextArea = uitextarea(controlPanel, ...
                                   'Position', [10, 100, 180, 180], ...
                                   'Value', {
                                       'Economic indicators show the financial health and prosperity of cities.', 
                                       '', 
                                       'GDP Per Capita:',
                                       'Higher values indicate greater economic output per person.',
                                       '',
                                       'Unemployment Rate:',
                                       'Lower values indicate stronger labor markets.',
                                       '',
                                       'Housing Affordability Index:',
                                       'Lower values indicate more affordable housing relative to income.'
                                   }, ...
                                   'Editable', 'off');
    
    % Main visualisation area
    app.EconPlotPanel = uipanel(econPanel, 'Title', 'visualisation', ...
                             'Position', [220, 10, 890, 680]);
    app.EconAxes = uiaxes(app.EconPlotPanel, 'Position', [10, 10, 870, 640]);
end

function createHealthPanel(app)
    % Create panel for health analysis
    healthPanel = uipanel(app.HealthTab, 'Title', 'Health Indicators', ...
                         'Position', [20, 20, 1120, 700]);
    
    % Control panel on the left
    controlPanel = uipanel(healthPanel, 'Title', 'Controls', ...
                          'Position', [10, 10, 200, 680]);
    
    % visualisation selection
    vizLabel = uilabel(controlPanel, 'Text', 'visualisation Type:', ...
                     'Position', [10, 640, 180, 30]);
    app.HealthVizDropDown = uidropdown(controlPanel, ...
                                    'Position', [10, 610, 180, 30], ...
                                    'Items', {'Life Expectancy Trends', 'Infant Mortality Comparison', 'Healthcare Access Matrix'}, ...
                                    'ValueChangedFcn', @(dd,event) updateHealthViz(app));
    
    % Variable selection
    varLabel = uilabel(controlPanel, 'Text', 'Variable:', ...
                     'Position', [10, 570, 180, 30]);
    app.HealthVarDropDown = uidropdown(controlPanel, ...
                                    'Position', [10, 540, 180, 30], ...
                                    'Items', {'LifeExpectancy', 'InfantMortality', 'HealthcareAccessIndex'}, ...
                                    'ValueChangedFcn', @(dd,event) updateHealthViz(app));
    
    % Grouping options
    groupLabel = uilabel(controlPanel, 'Text', 'Group By:', ...
                       'Position', [10, 500, 180, 30]);
    app.HealthGroupDropDown = uidropdown(controlPanel, ...
                                      'Position', [10, 470, 180, 30], ...
                                      'Items', {'None', 'Region', 'Income Level'}, ...
                                      'ValueChangedFcn', @(dd,event) updateHealthViz(app));
    
    % visualisation options
    optionsLabel = uilabel(controlPanel, 'Text', 'Options:', ...
                         'Position', [10, 430, 180, 30]);
    app.HealthShowReferenceCheckBox = uicheckbox(controlPanel, ...
                                              'Text', 'Show Reference Lines', ...
                                              'Position', [10, 400, 180, 30], ...
                                              'ValueChangedFcn', @(cb,event) updateHealthViz(app));
    app.HealthHighlightRiskCheckBox = uicheckbox(controlPanel, ...
                                              'Text', 'Highlight Risk Areas', ...
                                              'Position', [10, 370, 180, 30], ...
                                              'ValueChangedFcn', @(cb,event) updateHealthViz(app));
    
    % Update button
    updateHealthBtn = uibutton(controlPanel, 'Text', 'Update visualisation', ...
                             'Position', [10, 330, 180, 30], ...
                             'ButtonPushedFcn', @(btn,event) updateHealthViz(app));
    
    % Information panel
    infoLabel = uilabel(controlPanel, 'Text', 'Health Indicators:', ...
                      'Position', [10, 290, 180, 30]);
    app.HealthInfoTextArea = uitextarea(controlPanel, ...
                                     'Position', [10, 100, 180, 180], ...
                                     'Value', {
                                         'Health indicators show the well-being and healthcare quality in cities.', 
                                         '', 
                                         'Life Expectancy:',
                                         'Higher values indicate better overall health outcomes.',
                                         '',
                                         'Infant Mortality Rate:',
                                         'Lower values indicate better maternal and infant care.',
                                         '',
                                         'Healthcare Access Index:',
                                         'Higher values indicate better access to quality healthcare services.'
                                     }, ...
                                     'Editable', 'off');
    
    % Main visualisation area
    app.HealthPlotPanel = uipanel(healthPanel, 'Title', 'visualisation', ...
                               'Position', [220, 10, 890, 680]);
    app.HealthAxes = uiaxes(app.HealthPlotPanel, 'Position', [10, 10, 870, 640]);
end

function createCrossDomainPanel(app)
    % Create panel for cross-domain analysis
    crossPanel = uipanel(app.CrossDomainTab, 'Title', 'Cross-Domain Analysis', ...
                        'Position', [20, 20, 1120, 700]);
    
    % Control panel on the left
    controlPanel = uipanel(crossPanel, 'Title', 'Controls', ...
                          'Position', [10, 10, 200, 680]);
    
    % visualisation selection
    vizLabel = uilabel(controlPanel, 'Text', 'visualisation Type:', ...
                     'Position', [10, 640, 180, 30]);
    app.CrossVizDropDown = uidropdown(controlPanel, ...
                                   'Position', [10, 610, 180, 30], ...
                                   'Items', {'Correlation Matrix', 'Scatter Plot Matrix', 'Principal Component Analysis'}, ...
                                   'ValueChangedFcn', @(dd,event) updateCrossDomainViz(app));
    
    % Variable selection for X
    xVarLabel = uilabel(controlPanel, 'Text', 'X Variable:', ...
                      'Position', [10, 570, 180, 30]);
    app.CrossXVarDropDown = uidropdown(controlPanel, ...
                                    'Position', [10, 540, 180, 30], ...
                                    'ValueChangedFcn', @(dd,event) updateCrossDomainViz(app));
    
    % Variable selection for Y
    yVarLabel = uilabel(controlPanel, 'Text', 'Y Variable:', ...
                      'Position', [10, 500, 180, 30]);
    app.CrossYVarDropDown = uidropdown(controlPanel, ...
                                    'Position', [10, 470, 180, 30], ...
                                    'ValueChangedFcn', @(dd,event) updateCrossDomainViz(app));
    
    % Color by option
    colorLabel = uilabel(controlPanel, 'Text', 'Color By:', ...
                       'Position', [10, 430, 180, 30]);
    app.CrossColorDropDown = uidropdown(controlPanel, ...
                                     'Position', [10, 400, 180, 30], ...
                                     'Items', {'Region', 'Year', 'Population Size'}, ...
                                     'ValueChangedFcn', @(dd,event) updateCrossDomainViz(app));
    
    % visualisation options
    optionsLabel = uilabel(controlPanel, 'Text', 'Options:', ...
                         'Position', [10, 360, 180, 30]);
    app.CrossShowRegLineCheckBox = uicheckbox(controlPanel, ...
                                           'Text', 'Show Regression Line', ...
                                           'Position', [10, 330, 180, 30], ...
                                           'ValueChangedFcn', @(cb,event) updateCrossDomainViz(app));
    app.CrossShowClusterCheckBox = uicheckbox(controlPanel, ...
                                          'Text', 'Show Clusters', ...
                                          'Position', [10, 300, 180, 30], ...
                                          'ValueChangedFcn', @(cb,event) updateCrossDomainViz(app));
    
    % Update button
    updateCrossBtn = uibutton(controlPanel, 'Text', 'Update visualisation', ...
                            'Position', [10, 260, 180, 30], ...
                            'ButtonPushedFcn', @(btn,event) updateCrossDomainViz(app));
    
    % Information panel
    infoLabel = uilabel(controlPanel, 'Text', 'Cross-Domain Analysis:', ...
                      'Position', [10, 230, 180, 30]);
    app.CrossInfoTextArea = uitextarea(controlPanel, ...
                                    'Position', [10, 50, 180, 170], ...
                                    'Value', {
                                        'Cross-domain analysis reveals relationships between different disciplines.', 
                                        '', 
                                        'Correlation Matrix:',
                                        'Shows pairwise correlations between all variables.',
                                        '',
                                        'Scatter Plot Matrix:',
                                        'Shows pairwise scatter plots for selected variables.',
                                        '',
                                        'Principal Component Analysis:',
                                        'Reduces dimensionality to visualize complex relationships.'
                                    }, ...
                                    'Editable', 'off');
    
    % Main visualisation area
    app.CrossPlotPanel = uipanel(crossPanel, 'Title', 'visualisation', ...
                              'Position', [220, 10, 890, 680]);
    app.CrossAxes = uiaxes(app.CrossPlotPanel, 'Position', [10, 10, 870, 640]);
end

function createStatsPanel(app)
    % Create panel for statistics and export
    statsPanel = uipanel(app.StatsTab, 'Title', 'Statistics & Export', ...
                        'Position', [20, 20, 1120, 700]);
    
    % Statistics section
    statsSection = uipanel(statsPanel, 'Title', 'Statistical Analysis', ...
                          'Position', [10, 350, 1100, 340]);
    
    % Variable selection for statistics
    statsVarLabel = uilabel(statsSection, 'Text', 'Variable:', ...
                          'Position', [10, 300, 150, 30]);
    app.StatsVarDropDown = uidropdown(statsSection, ...
                                   'Position', [170, 300, 200, 30], ...
                                   'ValueChangedFcn', @(dd,event) updateStats(app));
    
    % Group by option for statistics
    statsGroupLabel = uilabel(statsSection, 'Text', 'Group By:', ...
                            'Position', [10, 260, 150, 30]);
    app.StatsGroupDropDown = uidropdown(statsSection, ...
                                     'Position', [170, 260, 200, 30], ...
                                     'Items', {'None', 'Region', 'Year'}, ...
                                     'ValueChangedFcn', @(dd,event) updateStats(app));
    
    % Statistics type
    statsTypeLabel = uilabel(statsSection, 'Text', 'Statistics Type:', ...
                           'Position', [10, 220, 150, 30]);
    app.StatsTypeDropDown = uidropdown(statsSection, ...
                                    'Position', [170, 220, 200, 30], ...
                                    'Items', {'Descriptive', 'Hypothesis Test', 'Regression'}, ...
                                    'ValueChangedFcn', @(dd,event) updateStats(app));
    
    % Run statistics button
    runStatsBtn = uibutton(statsSection, 'Text', 'Run Analysis', ...
                         'Position', [170, 180, 200, 30], ...
                         'ButtonPushedFcn', @(btn,event) updateStats(app));
    
    % Statistics results
    statsResultsLabel = uilabel(statsSection, 'Text', 'Results:', ...
                              'Position', [400, 300, 100, 30]);
    app.StatsResultsTextArea = uitextarea(statsSection, ...
                                       'Position', [400, 50, 690, 250], ...
                                       'Value', {'Run an analysis to see results.'}, ...
                                       'Editable', 'off');
    
    % Statistics visualisation
    app.StatsAxes = uiaxes(statsSection, 'Position', [10, 50, 350, 120]);
    
    % Export section
    exportSection = uipanel(statsPanel, 'Title', 'Export Options', ...
                           'Position', [10, 10, 1100, 330]);
    
    % Export what
    exportWhatLabel = uilabel(exportSection, 'Text', 'Export Content:', ...
                            'Position', [10, 290, 150, 30]);
    app.ExportWhatDropDown = uidropdown(exportSection, ...
                                     'Position', [170, 290, 200, 30], ...
                                     'Items', {'Current visualisation', 'Statistical Results', 'Filtered Dataset', 'All visualisations'});
    
    % Export format
    exportFormatLabel = uilabel(exportSection, 'Text', 'Export Format:', ...
                              'Position', [10, 250, 150, 30]);
    app.ExportFormatDropDown = uidropdown(exportSection, ...
                                       'Position', [170, 250, 200, 30], ...
                                       'Items', {'CSV', 'Excel', 'PDF', 'PNG', 'MATLAB .mat'});
    
    % Export options
    exportOptionsLabel = uilabel(exportSection, 'Text', 'Options:', ...
                               'Position', [10, 210, 150, 30]);
    app.ExportIncludeStatsCheckBox = uicheckbox(exportSection, ...
                                            'Text', 'Include Statistics', ...
                                            'Position', [170, 210, 200, 30]);
    app.ExportIncludeMetadataCheckBox = uicheckbox(exportSection, ...
                                              'Text', 'Include Metadata', ...
                                              'Position', [170, 180, 200, 30]);
    
    % Export button
    exportBtn = uibutton(exportSection, 'Text', 'Export', ...
                       'Position', [170, 140, 200, 30], ...
                       'ButtonPushedFcn', @(btn,event) exportData(app));
    
    % Export preview
    exportPreviewLabel = uilabel(exportSection, 'Text', 'Export Preview:', ...
                               'Position', [400, 290, 150, 30]);
    app.ExportPreviewPanel = uipanel(exportSection, ...
                                  'Position', [400, 50, 690, 240]);
    app.ExportPreviewAxes = uiaxes(app.ExportPreviewPanel, ...
                                'Position', [10, 10, 670, 220]);
end

function initializeApp(app)
    % This function would be called when the app starts
    % It initializes the UI components with default values
    
    % Try to load sample data if it exists
    try
        app.Data = readtable('city_multidisciplinary_data.csv');
        app.DataPathLabel.Text = 'Loaded data: city_multidisciplinary_data.csv';
        app.FilteredData = app.Data; % Initialize filtered data
        
        % Update city list
        unique_cities = unique(app.Data.City);
        app.CityListBox.Items = unique_cities;
        app.SelectedCities = unique_cities; % Select all cities by default
        app.CityListBox.Value = unique_cities;
        
        % Update region dropdown
        regions = unique(app.Data.Region);
        app.RegionDropDown.Items = ['All Regions', regions];
        app.RegionDropDown.Value = 'All Regions';
        
        % Update year slider
        years = unique(app.Data.Year);
        app.YearSlider.Limits = [min(years), max(years)];
        app.YearSlider.Value = [min(years), max(years)];
        app.SelectedYears = years;
        app.YearRangeLabel.Text = [num2str(min(years)), '-', num2str(max(years))];
        
        % Update variable dropdowns in all tabs
        numeric_vars = varfun(@isnumeric, app.Data, 'OutputFormat', 'uniform');
        var_names = app.Data.Properties.VariableNames(numeric_vars);
        % Remove ID-like variables
        var_names = setdiff(var_names, {'Year'});
        
        % Update cross-domain variable dropdowns
        app.CrossXVarDropDown.Items = var_names;
        app.CrossYVarDropDown.Items = var_names;
        app.StatsVarDropDown.Items = var_names;
        
        if ~isempty(var_names)
            app.CrossXVarDropDown.Value = var_names{min(1, length(var_names))};
            app.CrossYVarDropDown.Value = var_names{min(2, length(var_names))};
            app.StatsVarDropDown.Value = var_names{min(1, length(var_names))};
        end
        
        % Initialize variable info table
        updateVariableInfoTable(app);
        
        % Initialize data preview
        updateDataPreview(app);
        
        % Update filter status
        app.FilterStatusLabel.Text = 'No filters applied. Showing all data.';
        
        % Initialize visualisations
        updateEnvironmentalViz(app);
        updateEconomicViz(app);
        updateHealthViz(app);
        updateCrossDomainViz(app);
        updateStats(app);
    catch e
        app.DataPathLabel.Text = ['Error loading data: ', e.message];
    end
end

function loadDataBtnPushed(app)
    % This function would be called when the Load Data button is pressed
    % It opens a file dialog and loads the selected file
    [file, path] = uigetfile({'*.csv;*.xlsx;*.xls', 'Data Files (*.csv, *.xlsx, *.xls)'}, ...
                           'Select Data File');
    if isequal(file, 0)
        return; % User canceled
    end
    
    fullPath = fullfile(path, file);
    try
        if endsWith(file, '.csv')
            app.Data = readtable(fullPath);
        elseif endsWith(file, '.xlsx') || endsWith(file, '.xls')
            app.Data = readtable(fullPath, 'Sheet', 1);
        end
        
        app.DataPathLabel.Text = ['Loaded data: ', fullPath];
        app.FilteredData = app.Data; % Initialize filtered data
        
        % Rest of the initialization as in initializeApp function
        % ...
    catch e
        app.DataPathLabel.Text = ['Error loading data: ', e.message];
    end
end

function citySelectionChanged(app)
    % This function would be called when the city selection changes
    app.SelectedCities = app.CityListBox.Value;
    % No immediate update - wait for Apply Filters button
end

function selectAllCities(app)
    % This function would be called when the Select All button is pressed
    app.CityListBox.Value = app.CityListBox.Items;
    app.SelectedCities = app.CityListBox.Items;
end

function clearAllCities(app)
    % This function would be called when the Clear All button is pressed
    app.CityListBox.Value = {};
    app.SelectedCities = {};
end

function regionFilterChanged(app)
    % This function would be called when the region filter changes
    region = app.RegionDropDown.Value;
    
    if strcmp(region, 'All Regions')
        % Reset to show all cities
        app.CityListBox.Items = unique(app.Data.City);
    else
        % Filter cities by selected region
        regionCities = unique(app.Data.City(strcmp(app.Data.Region, region)));
        app.CityListBox.Items = regionCities;
    end
    
    % Select all displayed cities
    app.CityListBox.Value = app.CityListBox.Items;
    app.SelectedCities = app.CityListBox.Value;
end

function yearRangeChanged(app)
    % This function would be called when the year slider changes
    yearRange = app.YearSlider.Value;
    yearMin = floor(yearRange(1));
    yearMax = ceil(yearRange(2));
    
    app.YearRangeLabel.Text = [num2str(yearMin), '-', num2str(yearMax)];
    app.SelectedYears = yearMin:yearMax;
end

function applyFilters(app)
    % This function would be called when the Apply Filters button is pressed
    % Filter data based on selected cities and years
    city_mask = ismember(app.Data.City, app.SelectedCities);
    year_mask = ismember(app.Data.Year, app.SelectedYears);
    
    app.FilteredData = app.Data(city_mask & year_mask, :);
    
    % Update filter status
    app.FilterStatusLabel.Text = sprintf('Filtered to %d cities and years %d-%d (%d records).', ...
                                     length(app.SelectedCities), ...
                                     min(app.SelectedYears), ...
                                     max(app.SelectedYears), ...
                                     height(app.FilteredData));
    
    % Update data preview
    updateDataPreview(app);
    
    % Update visualisations
    updateEnvironmentalViz(app);
    updateEconomicViz(app);
    updateHealthViz(app);
    updateCrossDomainViz(app);
    updateStats(app);
end

function resetFilters(app)
    % This function would be called when the Reset Filters button is pressed
    % Reset all filters to show all data
    
    % Reset city selection
    app.CityListBox.Value = app.CityListBox.Items;
    app.SelectedCities = app.CityListBox.Items;
    
    % Reset region filter
    app.RegionDropDown.Value = 'All Regions';
    
    % Reset year slider
    years = unique(app.Data.Year);
    app.YearSlider.Value = [min(years), max(years)];
    app.SelectedYears = years;
    app.YearRangeLabel.Text = [num2str(min(years)), '-', num2str(max(years))];
    
    % Apply filters (resets to all data)
    applyFilters(app);
end

function updateVariableInfoTable(app)
    % Update the variable information table with metadata about each variable
    
    % Get variable names and types
    var_names = app.Data.Properties.VariableNames;
    var_types = varfun(@class, app.Data, 'OutputFormat', 'cell');
    
    % Assign domains to variables
    var_domains = cell(size(var_names));
    
    % Environmental variables
    env_vars = {'AirQualityIndex', 'GreenSpacePercent', 'WaterQualityIndex'};
    for i = 1:length(var_names)
        if ismember(var_names{i}, env_vars)
            var_domains{i} = 'Environmental';
        elseif ismember(var_names{i}, {'GDPPerCapita', 'UnemploymentRate', 'HousingAffordabilityIndex'})
            var_domains{i} = 'Economic';
        elseif ismember(var_names{i}, {'LifeExpectancy', 'InfantMortality', 'HealthcareAccessIndex'})
            var_domains{i} = 'Health';
        elseif ismember(var_names{i}, {'Population'})
            var_domains{i} = 'Demographic';
        else
            var_domains{i} = 'Metadata';
        end
    end
    
    % Create descriptions
    var_desc = {
        'City name', ...
        'Geographic region', ...
        'Year of data', ...
        'Total population', ...
        'Air Quality Index (lower is better)', ...
        'Percentage of city area that is green space', ...
        'Water Quality Index (higher is better)', ...
        'Gross Domestic Product per capita in USD', ...
        'Unemployment rate as percentage', ...
        'Housing affordability as ratio of median price to income', ...
        'Life expectancy in years', ...
        'Infant mortality rate per 1000 live births', ...
        'Healthcare access index (higher is better)'
    };
    
    % Calculate basic statistics for numeric variables
    var_min = cell(size(var_names));
    var_max = cell(size(var_names));
    var_mean = cell(size(var_names));
    
    for i = 1:length(var_names)
        if isnumeric(app.Data.(var_names{i}))
            var_min{i} = num2str(min(app.Data.(var_names{i}), [], 'omitnan'), '%.2f');
            var_max{i} = num2str(max(app.Data.(var_names{i}), [], 'omitnan'), '%.2f');
            var_mean{i} = num2str(mean(app.Data.(var_names{i}), 'omitnan'), '%.2f');
        else
            var_min{i} = 'N/A';
            var_max{i} = 'N/A';
            var_mean{i} = 'N/A';
        end
    end
    
    % Combine data for table
    table_data = [var_names', var_domains', var_desc', var_min', var_max', var_mean'];
    
    % Update the table
    app.VariableInfoTable.Data = table_data;
end

function updateDataPreview(app)
    % Update the data preview table with filtered data
    if height(app.FilteredData) > 0
        % Take first 10 rows or all if less than 10
        preview_rows = min(10, height(app.FilteredData));
        app.DataPreviewTable.Data = app.FilteredData(1:preview_rows, :);
        app.DataPreviewTable.ColumnName = app.FilteredData.Properties.VariableNames;
    else
        app.DataPreviewTable.Data = {};
        app.DataPreviewTable.ColumnName = {};
    end
end

function updateEnvironmentalViz(app)
    % Update the environmental visualisation based on current selections
    if isempty(app.FilteredData)
        return;
    end
    
    % Clear the current plot
    cla(app.EnvAxes);
    
    % Get current selections
    viz_type = app.EnvVizDropDown.Value;
    env_var = app.EnvVarDropDown.Value;
    grouping = app.EnvGroupDropDown.Value;
    show_trend = app.EnvShowTrendCheckBox.Value;
    show_avg = app.EnvShowAvgCheckBox.Value;
    
    % Create appropriate visualisation
    title_text = [strrep(env_var, 'Index', ' Index') ' by Year'];
    
    % In a real app, this would contain full visualisation code
    % Here we just show a placeholder message
    text(app.EnvAxes, 0.5, 0.5, sprintf('Environmental visualisation: %s\nVariable: %s\nGrouping: %s', ...
                                     viz_type, env_var, grouping), ...
         'HorizontalAlignment', 'center', ...
         'VerticalAlignment', 'middle', ...
         'FontSize', 12);
    
    % Set axis properties
    title(app.EnvAxes, title_text);
    xlabel(app.EnvAxes, 'Year');
    ylabel(app.EnvAxes, strrep(env_var, 'Index', ' Index'));
    grid(app.EnvAxes, 'on');
end

function updateEconomicViz(app)
    % Update the economic visualisation based on current selections
    if isempty(app.FilteredData)
        return;
    end
    
    % Clear the current plot
    cla(app.EconAxes);
    
    % Get current selections
    viz_type = app.EconVizDropDown.Value;
    econ_var = app.EconVarDropDown.Value;
    grouping = app.EconGroupDropDown.Value;
    show_growth = app.EconShowGrowthCheckBox.Value;
    normalize = app.EconNormalizeCheckBox.Value;
    
    % Create appropriate visualisation
    title_text = [strrep(econ_var, 'Index', ' Index') ' by Year'];
    
    % In a real app, this would contain full visualisation code
    % Here we just show a placeholder message
    text(app.EconAxes, 0.5, 0.5, sprintf('Economic visualisation: %s\nVariable: %s\nGrouping: %s', ...
                                      viz_type, econ_var, grouping), ...
         'HorizontalAlignment', 'center', ...
         'VerticalAlignment', 'middle', ...
         'FontSize', 12);
    
    % Set axis properties
    title(app.EconAxes, title_text);
    xlabel(app.EconAxes, 'Year');
    ylabel(app.EconAxes, strrep(econ_var, 'Index', ' Index'));
    grid(app.EconAxes, 'on');
end

function updateHealthViz(app)
    % Update the health visualisation based on current selections
    if isempty(app.FilteredData)
        return;
    end
    
    % Clear the current plot
    cla(app.HealthAxes);
    
    % Get current selections
    viz_type = app.HealthVizDropDown.Value;
    health_var = app.HealthVarDropDown.Value;
    grouping = app.HealthGroupDropDown.Value;
    show_reference = app.HealthShowReferenceCheckBox.Value;
    highlight_risk = app.HealthHighlightRiskCheckBox.Value;
    
    % Create appropriate visualisation
    title_text = [strrep(health_var, 'Index', ' Index') ' by Year'];
    
    % In a real app, this would contain full visualisation code
    % Here we just show a placeholder message
    text(app.HealthAxes, 0.5, 0.5, sprintf('Health visualisation: %s\nVariable: %s\nGrouping: %s', ...
                                        viz_type, health_var, grouping), ...
         'HorizontalAlignment', 'center', ...
         'VerticalAlignment', 'middle', ...
         'FontSize', 12);
    
    % Set axis properties
    title(app.HealthAxes, title_text);
    xlabel(app.HealthAxes, 'Year');
    ylabel(app.HealthAxes, strrep(health_var, 'Index', ' Index'));
    grid(app.HealthAxes, 'on');
end

function updateCrossDomainViz(app)
    % Update the cross-domain visualisation based on current selections
    if isempty(app.FilteredData)
        return;
    end
    
    % Clear the current plot
    cla(app.CrossAxes);
    
    % Get current selections
    viz_type = app.CrossVizDropDown.Value;
    x_var = app.CrossXVarDropDown.Value;
    y_var = app.CrossYVarDropDown.Value;
    color_by = app.CrossColorDropDown.Value;
    show_reg_line = app.CrossShowRegLineCheckBox.Value;
    show_clusters = app.CrossShowClusterCheckBox.Value;
    
    % Create appropriate visualisation
    title_text = sprintf('%s vs %s Colored by %s', ...
                       strrep(x_var, 'Index', ' Index'), ...
                       strrep(y_var, 'Index', ' Index'), ...
                       color_by);
    
    % In a real app, this would contain full visualisation code
    % Here we just show a placeholder message
    text(app.CrossAxes, 0.5, 0.5, sprintf('Cross-Domain visualisation: %s\nX: %s\nY: %s\nColor: %s', ...
                                       viz_type, x_var, y_var, color_by), ...
         'HorizontalAlignment', 'center', ...
         'VerticalAlignment', 'middle', ...
         'FontSize', 12);
    
    % Set axis properties
    title(app.CrossAxes, title_text);
    xlabel(app.CrossAxes, strrep(x_var, 'Index', ' Index'));
    ylabel(app.CrossAxes, strrep(y_var, 'Index', ' Index'));
    grid(app.CrossAxes, 'on');
end

function updateStats(app)
    % Update the statistical analysis based on current selections
    if isempty(app.FilteredData)
        return;
    end
    
    % Clear the current plot
    cla(app.StatsAxes);
    
    % Get current selections
    stats_var = app.StatsVarDropDown.Value;
    grouping = app.StatsGroupDropDown.Value;
    stats_type = app.StatsTypeDropDown.Value;
    
    % Perform appropriate statistical analysis
    % In a real app, this would contain full statistical analysis code
    % Here we just show a placeholder message
    
    % Update results text
    app.StatsResultsTextArea.Value = {
        sprintf('Statistical Analysis: %s', stats_type), ...
        sprintf('Variable: %s', stats_var), ...
        sprintf('Grouping: %s', grouping), ...
        '', ...
        'Sample Results:', ...
        '-----', ...
        'Mean: 45.67', ...
        'Median: 42.31', ...
        'Standard Deviation: 12.89', ...
        'Minimum: 10.25', ...
        'Maximum: 89.76', ...
        '', ...
        'This is a placeholder for actual statistical analysis results.'
    };
    
    % Create a simple visualisation of the results
    % For example, a histogram of the selected variable
    histogram(app.StatsAxes, app.FilteredData.(stats_var));
    title(app.StatsAxes, ['Distribution of ', strrep(stats_var, 'Index', ' Index')]);
    xlabel(app.StatsAxes, stats_var);
    ylabel(app.StatsAxes, 'Frequency');
    grid(app.StatsAxes, 'on');
end

function exportData(app)
    % Export the selected content in the chosen format
    export_what = app.ExportWhatDropDown.Value;
    export_format = app.ExportFormatDropDown.Value;
    include_stats = app.ExportIncludeStatsCheckBox.Value;
    include_metadata = app.ExportIncludeMetadataCheckBox.Value;
    
    % Show a message in the preview area
    cla(app.ExportPreviewAxes);
    text(app.ExportPreviewAxes, 0.5, 0.5, sprintf('Export Preview:\nContent: %s\nFormat: %s\nStats: %d\nMetadata: %d', ...
                                               export_what, export_format, include_stats, include_metadata), ...
         'HorizontalAlignment', 'center', ...
         'VerticalAlignment', 'middle', ...
         'FontSize', 12);
    
    % In a real app, this would handle the actual export
    % Here we just simulate it
    
    % Show file dialog for user to choose save location
    [file, path] = uiputfile(['*.' lower(export_format)], 'Save File');
    if isequal(file, 0)
        return; % User canceled
    end
    
    % Display a message indicating the export was successful
    msgbox(sprintf('Export simulated successfully to %s', fullfile(path, file)), 'Export Complete');
end

%% 3. CREATE SAMPLE OUTPUT IMAGES
% For demonstration purposes, create some sample visualisations
% that would be produced by the dashboard

% Sample Environmental visualisation
figure('Name', 'Sample Environmental visualisation', 'Position', [400, 400, 800, 600]);
% Create fake data for this example
years = 2010:2020;
cities = {'North Haven', 'South Bridge', 'West Field', 'East Port', 'Lake View'};
num_cities = length(cities);

% Air quality data (lower is better)
rng(42); % For reproducibility
aqi_data = zeros(length(years), num_cities);
for i = 1:num_cities
    base = 30 + 40 * rand();
    trend = -0.5 - 1.5 * rand(); % Improving trend
    aqi_data(:, i) = base + trend * (0:length(years)-1) + 5 * randn(1, length(years));
end

% Plot the data
colors = lines(num_cities);
hold on;
for i = 1:num_cities
    plot(years, aqi_data(:, i), 'o-', 'Color', colors(i,:), 'LineWidth', 1.5, 'MarkerSize', 6);
end

% Add a trend line for the average
avg_aqi = mean(aqi_data, 2);
p = polyfit(years, avg_aqi', 1);
trend_line = polyval(p, years);
plot(years, trend_line, 'k--', 'LineWidth', 2);

% Add reference lines for air quality categories
plot(years([1 end]), [50 50], 'g-', 'LineWidth', 1.5);
plot(years([1 end]), [100 100], 'y-', 'LineWidth', 1.5);
plot(years([1 end]), [150 150], 'r-', 'LineWidth', 1.5);

% Add text labels for categories
text(years(end), 25, 'Good', 'FontSize', 12, 'Color', 'g', 'HorizontalAlignment', 'right');
text(years(end), 75, 'Moderate', 'FontSize', 12, 'Color', [0.8 0.6 0], 'HorizontalAlignment', 'right');
text(years(end), 125, 'Unhealthy for Sensitive Groups', 'FontSize', 12, 'Color', 'r', 'HorizontalAlignment', 'right');
text(years(end), 175, 'Unhealthy', 'FontSize', 12, 'Color', [0.5 0 0], 'HorizontalAlignment', 'right');

title('Air Quality Index Trends (2010-2020)', 'FontSize', 14);
xlabel('Year', 'FontSize', 12);
ylabel('Air Quality Index (Lower is Better)', 'FontSize', 12);
legend([cities, 'Average Trend'], 'Location', 'best');
grid on;
set(gca, 'FontSize', 11);
axis tight;
ylim([0, 200]);

% Sample Economic visualisation
figure('Name', 'Sample Economic visualisation', 'Position', [450, 450, 800, 600]);

% GDP per capita data
gdp_data = zeros(length(years), num_cities);
for i = 1:num_cities
    base = 20000 + 30000 * rand();
    growth = 1.02 + 0.03 * rand(); % Growth rate
    gdp_data(:, i) = base * growth .^ (0:length(years)-1) .* (1 + 0.02 * randn(1, length(years)));
end

% Plot the data with bar chart
bar(years, gdp_data);
colormap(summer);

% Add a line for average
hold on;
avg_gdp = mean(gdp_data, 2);
plot(years, avg_gdp, 'k-', 'LineWidth', 2);

title('GDP Per Capita by City (2010-2020)', 'FontSize', 14);
xlabel('Year', 'FontSize', 12);
ylabel('GDP Per Capita (USD)', 'FontSize', 12);
legend([cities, 'Average'], 'Location', 'northwest');
grid on;
set(gca, 'FontSize', 11);

% Sample Cross-Domain visualisation
figure('Name', 'Sample Cross-Domain visualisation', 'Position', [500, 500, 800, 600]);

% Create fake data for correlation matrix
variables = {'GDP Per Capita', 'Unemployment', 'Housing Index', 'Life Expectancy', ...
            'Infant Mortality', 'Healthcare Access', 'Air Quality', 'Green Space', 'Water Quality'};
num_vars = length(variables);

% Create a correlation matrix with meaningful patterns
rng(42);
% Start with random correlations
corr_matrix = 0.2 * randn(num_vars, num_vars);
% Make diagonals 1
for i = 1:num_vars
    corr_matrix(i, i) = 1;
end
% Add meaningful correlations
% GDP correlates positively with life expectancy, healthcare, green space
corr_matrix(1, 4) = 0.75; corr_matrix(4, 1) = 0.75; % GDP - Life Expectancy
corr_matrix(1, 6) = 0.82; corr_matrix(6, 1) = 0.82; % GDP - Healthcare
corr_matrix(1, 8) = 0.58; corr_matrix(8, 1) = 0.58; % GDP - Green Space

% Unemployment correlates negatively with housing affordability
corr_matrix(2, 3) = -0.67; corr_matrix(3, 2) = -0.67; % Unemployment - Housing

% Healthcare correlates positively with life expectancy, negatively with infant mortality
corr_matrix(6, 4) = 0.78; corr_matrix(4, 6) = 0.78; % Healthcare - Life Expectancy
corr_matrix(6, 5) = -0.81; corr_matrix(5, 6) = -0.81; % Healthcare - Infant Mortality

% Air quality correlates with health metrics
corr_matrix(7, 4) = -0.63; corr_matrix(4, 7) = -0.63; % Air Quality - Life Expectancy
corr_matrix(7, 5) = 0.59; corr_matrix(5, 7) = 0.59; % Air Quality - Infant Mortality

% Make matrix symmetric
corr_matrix = (corr_matrix + corr_matrix')/2;
% Ensure correlations are in [-1, 1]
corr_matrix = max(min(corr_matrix, 1), -1);

% Plot the correlation matrix
imagesc(corr_matrix);
colormap(bluewhitered(100)); % This requires the bluewhitered colormap function
colorbar;
caxis([-1, 1]);

% Add labels
xticks(1:num_vars);
yticks(1:num_vars);
xticklabels(variables);
yticklabels(variables);
xtickangle(45);

% Annotate with correlation values
for i = 1:num_vars
    for j = 1:num_vars
        text(j, i, sprintf('%.2f', corr_matrix(i, j)), 'HorizontalAlignment', 'center', ...
             'FontWeight', 'bold', 'Color', 'k');
    end
end

title('Cross-Domain Correlation Matrix', 'FontSize', 14);
set(gca, 'FontSize', 10);
axis square;

% Function to create bluewhitered colormap
function newmap = bluewhitered(m)
    if nargin < 1
        m = 100;
    end
    
    bottom = [0 0 0.5];
    mid = [1 1 1];
    top = [0.5 0 0];
    
    % Create color map from these colors
    n1 = floor(m/2);
    n2 = m - n1;
    
    % Create bottom to mid gradient
    cm1 = zeros(n1, 3);
    for i = 1:3
        cm1(:, i) = linspace(bottom(i), mid(i), n1);
    end
    
    % Create mid to top gradient
    cm2 = zeros(n2, 3);
    for i = 1:3
        cm2(:, i) = linspace(mid(i), top(i), n2);
    end
    
    newmap = [cm1; cm2];
end

fprintf('Created sample dashboard visualisations.\n');
fprintf('In a real implementation, the dashboard would be created using App Designer UI.\n');
