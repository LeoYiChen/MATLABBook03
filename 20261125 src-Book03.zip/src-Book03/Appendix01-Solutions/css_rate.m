%% css_rate.m
% Per-capita crime-rate ranking in base MATLAB.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : css_rate
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function rateTable = rankCrimeRates(incidentCounts, population, areaNames)
% rankCrimeRates  Rank areas by crime rate per 1,000 residents.
%   rateTable = rankCrimeRates(incidentCounts, population, areaNames)
%   Author: Dr Leo Chen | Version 1.0 | Base MATLAB (R2021b+)

    ratePerThousand = 1000 * incidentCounts(:) ./ population(:);
    [sortedRate, order] = sort(ratePerThousand, 'descend');

    rateTable = table(string(areaNames(order)), sortedRate, ...
        'VariableNames', {'Area', 'RatePerThousand'});
end
