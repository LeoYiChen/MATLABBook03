%% lst_sol03_syntax_lstm.m
% LSTM network definition and training.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : lst:sol03_syntax_lstm
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
layers = [
    sequenceInputLayer(inputSize)
    lstmLayer(hiddenUnits, 'OutputMode', 'last')
    fullyConnectedLayer(numClasses)
    softmaxLayer
    classificationLayer];

options = trainingOptions('adam', ...
    'MaxEpochs',         100, ...
    'MiniBatchSize',     64, ...
    'InitialLearnRate',  0.005);

trainedNet = trainNetwork( ...
    trainingSequences, trainingLabels, layers, options);
