%% chapter_AILMI_prob1_baseline.m
% Logistic regression baseline for domain adaptation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AILMI_prob1_baseline
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Train logistic regression on source domain
mdl = fitcecoc(XTrainSource, YTrainSource, ...
    'Learners', 'logistic', ...
    'ClassNames', categories(YTrainSource));

% Test on target domain (direct transfer)
YPredTarget = predict(mdl, XTestTarget);
accuracy = sum(YPredTarget == YTestTarget) / length(YTestTarget);
