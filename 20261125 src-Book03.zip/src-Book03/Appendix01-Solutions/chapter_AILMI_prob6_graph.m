%% chapter_AILMI_prob6_graph.m
% Entity graph construction for multi-hop reasoning.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AILMI_prob6_graph
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [nodes, edges, adjacency] = constructEntityGraph(passages, entities)
    % Build entity graph from passages
    % passages: cell array of text passages
    % entities: struct array with entity information
    
    numEntities = length(entities);
    nodes = struct('id', {}, 'name', {}, 'type', {}, 'features', {});
    edges = [];
    adjacency = sparse(numEntities, numEntities);
    
    % Create nodes for each unique entity
    for i = 1:numEntities
        nodes(i).id = i;
        nodes(i).name = entities(i).text;
        nodes(i).type = entities(i).type;
        nodes(i).features = entities(i).embedding;
    end
    
    % Create edges based on co-occurrence and relations
    edgeIdx = 1;
    for p = 1:length(passages)
        % Get entities in this passage
        passageEntities = findEntitiesInPassage(passages{p}, entities);
        
        % Co-occurrence edges
        for i = 1:length(passageEntities)
            for j = i+1:length(passageEntities)
                id1 = passageEntities(i).id;
                id2 = passageEntities(j).id;
                
                % Check if entities co-occur in same sentence
                if inSameSentence(passageEntities(i), passageEntities(j))
                    edges(edgeIdx).source = id1;
                    edges(edgeIdx).target = id2;
                    edges(edgeIdx).type = 'cooccurrence';
                    adjacency(id1, id2) = 1;
                    adjacency(id2, id1) = 1;
                    edgeIdx = edgeIdx + 1;
                end
            end
        end
    end
end
