%% chapter_AILMI_prob10_ewc.m
% Elastic Weight Consolidation for continual learning.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AILMI_prob10_ewc
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [newWeights, loss] = elasticWeightConsolidation(oldWeights, ...
                              fisherInfo, newData, newLabels, lambdaEWC)
    % Update model with EWC to prevent catastrophic forgetting
    % oldWeights: Previous model parameters
    % fisherInfo: Importance of each parameter
    % newData, newLabels: New streaming data
    
    % Compute loss on new data
    predictions = forwardPass(newData, oldWeights);
    lossNew = crossEntropyLoss(predictions, newLabels);
    
    % EWC penalty: Prevent changing important parameters
    ewcPenalty = 0;
    numParams = length(oldWeights);
    for i = 1:numParams
        ewcPenalty = ewcPenalty + fisherInfo(i) * (newWeights(i) - oldWeights(i))^2;
    end
    
    % Total loss
    loss = lossNew + lambdaEWC * ewcPenalty;
    
    % Gradient descent update (simplified)
    gradients = computeGradients(loss, newWeights);
    learningRate = 0.0001;
    newWeights = newWeights - learningRate * gradients;
end

function F = computeFisherInformation(model, data, labels)
    % Compute diagonal Fisher Information Matrix
    % F_i = E[(d log P(y|x) / d theta_i)^2]
    
    numParams = length(model.weights);
    F = zeros(numParams, 1);
    
    for i = 1:size(data, 1)
        x = data(i, :);
        y = labels(i);
        
        % Compute gradient of log probability
        logProb = log(forwardPass(x, model.weights));
        grads = computeGradients(logProb(y), model.weights);
        
        % Accumulate squared gradients
        F = F + grads.^2;
    end
    
    F = F / size(data, 1);
end
