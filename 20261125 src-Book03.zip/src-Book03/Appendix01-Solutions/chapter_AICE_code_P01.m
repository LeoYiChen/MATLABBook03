%% chapter_AICE_code_P01.m
% Solution~1: timetable synchronisation and residual anomaly detection (MATLABBook02_Chapter13_section8_Problem01.m).
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AICE_code_P01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% MATLABBook02_Chapter13_section8_Problem01.m
% Problem 1: Timetable Synchronisation and Residual-Based
%             Anomaly Detection
%
% Description : Synchronises irregular sensor data with regular
%               model predictions and detects anomalies via
%               residual thresholds on a bridge bearing.
% Author      : Dr Yi Chen
% Date        : 2025
% MATLAB      : R2024b or later
% Toolboxes   : None (base MATLAB)
% Reference   : Chapter 13, Problem 1
% =================================================================

%% 1. Generate synthetic sensor data (irregular timestamps)
rng(7);
nSensorSamples   = 400;
weekHours        = 168;
sensorTimes      = datetime(2026,7,1) + ...
    hours(sort(weekHours * rand(nSensorSamples, 1)));
dailyCycle       = @(t) 12 * sin(2*pi*(hour(t) + ...
    minute(t)/60 - 9) / 24);
sensorDisplacement = dailyCycle(sensorTimes) ...
    + 0.8 * randn(nSensorSamples, 1) ...
    + 4 * max(0, days(sensorTimes - datetime(2026,7,6)));

%% 2. Generate model predictions (regular 30-minute grid)
modelTimes       = (datetime(2026,7,1) : minutes(30) : ...
    datetime(2026,7,8))';
modelDisplacement = dailyCycle(modelTimes);

%% 3. Build timetable objects
sensorTable = timetable(sensorTimes, sensorDisplacement);
modelTable  = timetable(modelTimes, modelDisplacement);

%% 4. Synchronise onto a common 30-minute grid
alignedData = synchronize(sensorTable, modelTable, ...
    "regular", "linear", "TimeStep", minutes(30));

%% 5. Compute the prediction residual
residual = alignedData.sensorDisplacement ...
         - alignedData.modelDisplacement;

%% 6. Baseline statistics and anomaly flags
baselineCount   = 100;
baselineStd     = std(residual(1:baselineCount), "omitnan");
anomalyThreshold = 3 * baselineStd;
anomalyFlags    = abs(residual) > anomalyThreshold;
nAnomalies      = nnz(anomalyFlags);
nAligned        = numel(residual);

%% 7. Report
fprintf('Aligned time steps        : %d\n', nAligned);
fprintf('Baseline std (mm)         : %.3f\n', baselineStd);
fprintf('Three-sigma threshold (mm): %.3f\n', anomalyThreshold);
fprintf('Anomalous intervals       : %d of %d (%.1f%%)\n', ...
    nAnomalies, nAligned, 100*nAnomalies/nAligned);

%% 8. Plot
figure;
plot(alignedData.Time, alignedData.sensorDisplacement, '.', ...
    'MarkerSize', 4, 'DisplayName', 'Sensor');
hold on;
plot(alignedData.Time, alignedData.modelDisplacement, '-', ...
    'LineWidth', 1.2, 'DisplayName', 'Model');
plot(alignedData.Time(anomalyFlags), ...
    alignedData.sensorDisplacement(anomalyFlags), ...
    'ro', 'MarkerSize', 8, 'DisplayName', 'Anomaly');
xlabel('Time');
ylabel('Displacement (mm)');
legend('Location', 'northwest');
title('Digital Shadow: Bearing Displacement Monitoring');
grid on;
% - Computational Complexity -
% Synchronisation dominates at O(m log m) for m = 400 sensor
% samples. Residual computation and thresholding are each O(q)
% for q aligned steps. Plotting is O(q). The entire pipeline
% executes in milliseconds, comfortably inside any realistic
% monitoring cadence and scalable to thousands of channels.
