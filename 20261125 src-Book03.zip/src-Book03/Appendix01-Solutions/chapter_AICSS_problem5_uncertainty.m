%% chapter_AICSS_problem5_uncertainty.m
% Comprehensive uncertainty quantification and sensitivity analysis framework.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AICSS_problem5_uncertainty
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function uncertaintyResults = performComprehensiveUncertaintyAnalysis(systemModel, parameterDefinitions, analysisOptions)
    % Comprehensive uncertainty quantification and sensitivity analysis
    % Author: Dr Leo Chen
    % Version: 1.0 - Initial implementation
    % Date: December 2024
    
    fprintf('Executing comprehensive uncertainty quantification and sensitivity analysis...\n');
    
    % Initialize results structure
    uncertaintyResults = struct();
    uncertaintyResults.timestamp = datetime('now');
    uncertaintyResults.parameterDefinitions = parameterDefinitions;
    uncertaintyResults.analysisOptions = analysisOptions;
    
    % Extract parameter information
    parameterNames = fieldnames(parameterDefinitions);
    numberOfParameters = length(parameterNames);
    parameterRanges = zeros(numberOfParameters, 2);
    parameterDistributions = cell(numberOfParameters, 1);
    
    for parameterIndex = 1:numberOfParameters
        paramName = parameterNames{parameterIndex};
        paramInfo = parameterDefinitions.(paramName);
        parameterRanges(parameterIndex, :) = [paramInfo.min, paramInfo.max];
        parameterDistributions{parameterIndex} = paramInfo.distribution;
    end
    
    % Generate parameter samples using Latin Hypercube Sampling
    numberOfSamples = analysisOptions.numberOfSamples;
    fprintf('Generating %d parameter samples using Latin Hypercube Sampling...\n', numberOfSamples);
    
    lhsSamples = lhsdesign(numberOfSamples, numberOfParameters);
    scaledSamples = zeros(numberOfSamples, numberOfParameters);
    
    for parameterIndex = 1:numberOfParameters
        minValue = parameterRanges(parameterIndex, 1);
        maxValue = parameterRanges(parameterIndex, 2);
        
        % Apply parameter-specific distributions
        distribution = parameterDistributions{parameterIndex};
        if strcmp(distribution, 'uniform')
            scaledSamples(:, parameterIndex) = minValue + (maxValue - minValue) * lhsSamples(:, parameterIndex);
        elseif strcmp(distribution, 'normal')
            meanValue = (minValue + maxValue) / 2;
            stdValue = (maxValue - minValue) / 6; % 3-sigma range
            scaledSamples(:, parameterIndex) = norminv(lhsSamples(:, parameterIndex), meanValue, stdValue);
        elseif strcmp(distribution, 'lognormal')
            logMean = log((minValue + maxValue) / 2);
            logStd = (log(maxValue) - log(minValue)) / 6;
            scaledSamples(:, parameterIndex) = logninv(lhsSamples(:, parameterIndex), logMean, logStd);
        end
    end
    
    uncertaintyResults.parameterSamples = scaledSamples;
    uncertaintyResults.parameterNames = parameterNames;
    
    % Execute Monte Carlo simulation
    fprintf('Executing Monte Carlo simulation...\n');
    modelOutputs = zeros(numberOfSamples, 1);
    executionTimes = zeros(numberOfSamples, 1);
    
    for sampleIndex = 1:numberOfSamples
        currentParameters = scaledSamples(sampleIndex, :);
        
        try
            % Execute system model with current parameters
            executionStartTime = tic;
            modelOutput = evaluateSystemModelWithUncertainty(systemModel, currentParameters, parameterNames);
            executionTime = toc(executionStartTime);
            
            modelOutputs(sampleIndex) = modelOutput.primaryMetric;
            executionTimes(sampleIndex) = executionTime;
            
        catch modelError
            fprintf('Warning: Model evaluation failed for sample %d: %s\n', sampleIndex, modelError.message);
            modelOutputs(sampleIndex) = NaN;
            executionTimes(sampleIndex) = NaN;
        end
        
        % Progress reporting
        if mod(sampleIndex, floor(numberOfSamples/10)) == 0
            fprintf('Progress: %.0f%% completed\n', 100 * sampleIndex / numberOfSamples);
        end
    end
    
    uncertaintyResults.modelOutputs = modelOutputs;
    uncertaintyResults.executionTimes = executionTimes;
    
    % Statistical analysis of outputs
    validOutputs = ~isnan(modelOutputs);
    uncertaintyResults.outputStatistics = calculateOutputStatistics(modelOutputs(validOutputs));
    
    % Sobol sensitivity indices calculation
    fprintf('Calculating Sobol sensitivity indices...\n');
    sobolResults = calculateSobolIndices(scaledSamples(validOutputs, :), modelOutputs(validOutputs), parameterNames);
    uncertaintyResults.sobolIndices = sobolResults;
    
    % Morris elementary effects screening
    fprintf('Performing Morris elementary effects screening...\n');
    morrisResults = performMorrisScreening(systemModel, parameterRanges, parameterNames, analysisOptions);
    uncertaintyResults.morrisScreening = morrisResults;
    
    % Correlation analysis
    correlationResults = performCorrelationAnalysis(scaledSamples(validOutputs, :), modelOutputs(validOutputs), parameterNames);
    uncertaintyResults.correlationAnalysis = correlationResults;
    
    % Uncertainty propagation analysis
    uncertaintyPropagation = analyseUncertaintyPropagation(uncertaintyResults);
    uncertaintyResults.uncertaintyPropagation = uncertaintyPropagation;
    
    % Generate comprehensive visualisation
    generateUncertaintyvisualisation(uncertaintyResults, analysisOptions);
    
    % Parameter ranking based on sensitivity
    parameterRanking = rankParametersBySensitivity(uncertaintyResults);
    uncertaintyResults.parameterRanking = parameterRanking;
    
    % Save results
    saveUncertaintyResults(uncertaintyResults);
    
    fprintf('Uncertainty quantification and sensitivity analysis completed.\n');
end

function sobolResults = calculateSobolIndices(parameterSamples, modelOutputs, parameterNames)
    % Calculate Sobol sensitivity indices using variance decomposition
    
    sobolResults = struct();
    numberOfParameters = size(parameterSamples, 2);
    
    % Total variance of model outputs
    totalVariance = var(modelOutputs);
    
    % First-order Sobol indices
    firstOrderIndices = zeros(numberOfParameters, 1);
    
    for parameterIndex = 1:numberOfParameters
        % Calculate conditional variance for each parameter
        parameterValues = parameterSamples(:, parameterIndex);
        
        % Divide parameter range into bins for conditional analysis
        numberOfBins = 10;
        [binCounts, binEdges] = histcounts(parameterValues, numberOfBins);
        conditionalMeans = zeros(numberOfBins, 1);
        
        for binIndex = 1:numberOfBins
            binMask = parameterValues >= binEdges(binIndex) & parameterValues < binEdges(binIndex + 1);
            if sum(binMask) > 0
                conditionalMeans(binIndex) = mean(modelOutputs(binMask));
            end
        end
        
        % Calculate variance of conditional means
        validBins = binCounts > 0;
        binWeights = binCounts(validBins) / sum(binCounts);
        weightedConditionalMeans = conditionalMeans(validBins);
        
        conditionalVariance = sum(binWeights .* (weightedConditionalMeans - mean(modelOutputs)).^2);
        
        % First-order Sobol index
        firstOrderIndices(parameterIndex) = conditionalVariance / totalVariance;
    end
    
    sobolResults.firstOrderIndices = firstOrderIndices;
    sobolResults.parameterNames = parameterNames;
    
    % Total-effect indices (simplified estimation)
    totalEffectIndices = zeros(numberOfParameters, 1);
    
    for parameterIndex = 1:numberOfParameters
        % Leave-one-out variance estimation
        otherParameters = parameterSamples;
        otherParameters(:, parameterIndex) = [];
        
        % Estimate total effect using correlation approach
        correlationWithOutput = abs(corr(parameterSamples(:, parameterIndex), modelOutputs));
        totalEffectIndices(parameterIndex) = correlationWithOutput^2;
    end
    
    sobolResults.totalEffectIndices = totalEffectIndices;
    
    % Interaction effects
    sobolResults.interactionEffects = totalEffectIndices - firstOrderIndices;
end

function morrisResults = performMorrisScreening(systemModel, parameterRanges, parameterNames, options)
    % Perform Morris elementary effects screening
    
    morrisResults = struct();
    numberOfParameters = length(parameterNames);
    
    % Morris sampling parameters
    numberOfTrajectories = options.morrisTrajectories;
    numberOfLevels = options.morrisLevels;
    delta = numberOfLevels / (2 * (numberOfLevels - 1));
    
    elementaryEffects = zeros(numberOfTrajectories * numberOfParameters, numberOfParameters);
    effectIndex = 1;
    
    for trajectoryIndex = 1:numberOfTrajectories
        % Generate base point
        basePoint = rand(1, numberOfParameters);
        
        % Scale to parameter ranges
        scaledBasePoint = zeros(1, numberOfParameters);
        for parameterIndex = 1:numberOfParameters
            minValue = parameterRanges(parameterIndex, 1);
            maxValue = parameterRanges(parameterIndex, 2);
            scaledBasePoint(parameterIndex) = minValue + (maxValue - minValue) * basePoint(parameterIndex);
        end
        
        % Evaluate model at base point
        try
            baseOutput = evaluateSystemModelWithUncertainty(systemModel, scaledBasePoint, parameterNames);
            baseValue = baseOutput.primaryMetric;
        catch
            continue; % Skip this trajectory if evaluation fails
        end
        
        % Calculate elementary effects for each parameter
        for parameterIndex = 1:numberOfParameters
            perturbedPoint = scaledBasePoint;
            
            % Apply perturbation
            parameterRange = parameterRanges(parameterIndex, 2) - parameterRanges(parameterIndex, 1);
            perturbation = delta * parameterRange;
            perturbedPoint(parameterIndex) = perturbedPoint(parameterIndex) + perturbation;
            
            % Ensure parameter stays within bounds
            perturbedPoint(parameterIndex) = min(max(perturbedPoint(parameterIndex), ...
                parameterRanges(parameterIndex, 1)), parameterRanges(parameterIndex, 2));
            
            try
                % Evaluate model at perturbed point
                perturbedOutput = evaluateSystemModelWithUncertainty(systemModel, perturbedPoint, parameterNames);
                perturbedValue = perturbedOutput.primaryMetric;
                
                % Calculate elementary effect
                elementaryEffect = (perturbedValue - baseValue) / perturbation;
                elementaryEffects(effectIndex, parameterIndex) = elementaryEffect;
                
            catch
                elementaryEffects(effectIndex, parameterIndex) = NaN;
            end
        end
        
        effectIndex = effectIndex + 1;
    end
    
    % Calculate Morris measures
    validEffects = ~isnan(elementaryEffects);
    morrisMean = zeros(numberOfParameters, 1);
    morrisStd = zeros(numberOfParameters, 1);
    
    for parameterIndex = 1:numberOfParameters
        validData = elementaryEffects(validEffects(:, parameterIndex), parameterIndex);
        if ~isempty(validData)
            morrisMean(parameterIndex) = mean(abs(validData));
            morrisStd(parameterIndex) = std(validData);
        end
    end
    
    morrisResults.mean = morrisMean;
    morrisResults.standardDeviation = morrisStd;
    morrisResults.parameterNames = parameterNames;
    morrisResults.elementaryEffects = elementaryEffects;
end

function generateUncertaintyvisualisation(uncertaintyResults, options)
    % Generate comprehensive uncertainty quantification visualisation
    
    figure('Position', [100, 100, 1800, 1400]);
    
    % Parameter sensitivity ranking
    subplot(4, 4, [1, 2]);
    sobolFirstOrder = uncertaintyResults.sobolIndices.firstOrderIndices;
    sobolTotalEffect = uncertaintyResults.sobolIndices.totalEffectIndices;
    
    parameterIndices = 1:length(sobolFirstOrder);
    barWidth = 0.35;
    
    bar(parameterIndices - barWidth/2, sobolFirstOrder, barWidth, 'FaceColor', [0.3, 0.6, 0.9], 'DisplayName', 'First-order');
    hold on;
    bar(parameterIndices + barWidth/2, sobolTotalEffect, barWidth, 'FaceColor', [0.9, 0.6, 0.3], 'DisplayName', 'Total-effect');
    
    set(gca, 'XTickLabel', uncertaintyResults.parameterNames);
    ylabel('Sobol Index', 'FontSize', 12);
    title('Parameter Sensitivity Analysis', 'FontSize', 14, 'FontWeight', 'bold');
    legend('show', 'Location', 'best');
    xtickangle(45);
    grid on;
    
    % Morris screening results
    subplot(4, 4, 3);
    if isfield(uncertaintyResults, 'morrisScreening')
        morrisMean = uncertaintyResults.morrisScreening.mean;
        morrisStd = uncertaintyResults.morrisScreening.standardDeviation;
        
        scatter(morrisMean, morrisStd, 100, 'filled');
        xlabel('Morris Mean (--*)', 'FontSize', 12);
        ylabel('Morris Std (--)', 'FontSize', 12);
        title('Morris Elementary Effects', 'FontSize', 12, 'FontWeight', 'bold');
        
        % Add parameter labels
        for parameterIndex = 1:length(morrisMean)
            text(morrisMean(parameterIndex), morrisStd(parameterIndex), ...
                sprintf('  %s', uncertaintyResults.parameterNames{parameterIndex}), ...
                'FontSize', 8);
        end
        grid on;
    end
    
    % Output distribution
    subplot(4, 4, 4);
    validOutputs = ~isnan(uncertaintyResults.modelOutputs);
    outputData = uncertaintyResults.modelOutputs(validOutputs);
    
    histogram(outputData, 30, 'FaceColor', [0.6, 0.8, 0.6], 'EdgeColor', 'black');
    xlabel('Model Output', 'FontSize', 12);
    ylabel('Frequency', 'FontSize', 12);
    title('Output Distribution', 'FontSize', 12, 'FontWeight', 'bold');
    
    % Add statistics
    meanOutput = mean(outputData);
    stdOutput = std(outputData);
    xline(meanOutput, 'r--', sprintf('Mean: %.3f', meanOutput), 'LineWidth', 2);
    grid on;
    
    % Parameter correlation heatmap
    subplot(4, 4, 5);
    if isfield(uncertaintyResults, 'correlationAnalysis')
        correlationMatrix = uncertaintyResults.correlationAnalysis.correlationMatrix;
        imagesc(correlationMatrix);
        colorbar;
        colormap('hot');
        set(gca, 'XTickLabel', uncertaintyResults.parameterNames);
        set(gca, 'YTickLabel', uncertaintyResults.parameterNames);
        title('Parameter Correlation Matrix', 'FontSize', 12, 'FontWeight', 'bold');
        xtickangle(45);
    end
    
    % Scatter plots of most sensitive parameters
    subplot(4, 4, 6);
    [~, mostSensitiveIndex] = max(sobolFirstOrder);
    mostSensitiveParameter = uncertaintyResults.parameterSamples(:, mostSensitiveIndex);
    
    scatter(mostSensitiveParameter(validOutputs), outputData, 50, 'filled', 'alpha', 0.6);
    xlabel(sprintf('%s', uncertaintyResults.parameterNames{mostSensitiveIndex}), 'FontSize', 12);
    ylabel('Model Output', 'FontSize', 12);
    title('Most Sensitive Parameter vs Output', 'FontSize', 12, 'FontWeight', 'bold');
    
    % Add trend line
    p = polyfit(mostSensitiveParameter(validOutputs), outputData, 1);
    xFit = linspace(min(mostSensitiveParameter(validOutputs)), max(mostSensitiveParameter(validOutputs)), 100);
    yFit = polyval(p, xFit);
    hold on;
    plot(xFit, yFit, 'r-', 'LineWidth', 2);
    grid on;
    
    % Uncertainty propagation analysis
    subplot(4, 4, 7);
    if isfield(uncertaintyResults, 'uncertaintyPropagation')
        propagationData = uncertaintyResults.uncertaintyPropagation;
        uncertaintyContributions = propagationData.parameterContributions;
        
        pie(uncertaintyContributions, uncertaintyResults.parameterNames);
        title('Uncertainty Contributions', 'FontSize', 12, 'FontWeight', 'bold');
    end
    
    % Convergence analysis
    subplot(4, 4, 8);
    numberOfSamples = length(outputData);
    cumulativeMean = cumsum(outputData) ./ (1:numberOfSamples)';
    
    plot(1:numberOfSamples, cumulativeMean, 'b-', 'LineWidth', 2);
    hold on;
    yline(meanOutput, 'r--', 'Final Mean', 'LineWidth', 2);
    xlabel('Number of Samples', 'FontSize', 12);
    ylabel('Cumulative Mean', 'FontSize', 12);
    title('Monte Carlo Convergence', 'FontSize', 12, 'FontWeight', 'bold');
    grid on;
    
    % Execution time analysis
    subplot(4, 4, 9);
    validExecutionTimes = uncertaintyResults.executionTimes(~isnan(uncertaintyResults.executionTimes));
    histogram(validExecutionTimes * 1000, 20, 'FaceColor', [0.8, 0.6, 0.8], 'EdgeColor', 'black');
    xlabel('Execution Time (ms)', 'FontSize', 12);
    ylabel('Frequency', 'FontSize', 12);
    title('Model Execution Time Distribution', 'FontSize', 12, 'FontWeight', 'bold');
    grid on;
    
    % Parameter sample distribution for top parameters
    subplot(4, 4, 10);
    [~, topIndices] = sort(sobolFirstOrder, 'descend');
    topParameters = uncertaintyResults.parameterSamples(:, topIndices(1:3));
    
    boxplot(topParameters, 'Labels', uncertaintyResults.parameterNames(topIndices(1:3)));
    ylabel('Parameter Value', 'FontSize', 12);
    title('Top Parameter Distributions', 'FontSize', 12, 'FontWeight', 'bold');
    xtickangle(45);
    grid on;
    
    % Sensitivity vs interaction effects
    subplot(4, 4, 11);
    interactionEffects = uncertaintyResults.sobolIndices.interactionEffects;
    scatter(sobolFirstOrder, interactionEffects, 100, 'filled');
    xlabel('First-order Sensitivity', 'FontSize', 12);
    ylabel('Interaction Effects', 'FontSize', 12);
    title('Sensitivity vs Interaction', 'FontSize', 12, 'FontWeight', 'bold');
    
    % Add parameter labels
    for parameterIndex = 1:length(sobolFirstOrder)
        text(sobolFirstOrder(parameterIndex), interactionEffects(parameterIndex), ...
            sprintf('  %s', uncertaintyResults.parameterNames{parameterIndex}), 'FontSize', 8);
    end
    grid on;
    
    % Statistical summary
    subplot(4, 4, 12);
    axis off;
    
    summaryText = sprintf('Uncertainty Analysis Summary\n\n');
    summaryText = [summaryText, sprintf('Total Samples: %d\n', length(uncertaintyResults.modelOutputs))];
    summaryText = [summaryText, sprintf('Valid Samples: %d (%.1f%%)\n', sum(validOutputs), 100*sum(validOutputs)/length(validOutputs))];
    summaryText = [summaryText, sprintf('Output Mean: %.4f\n', meanOutput)];
    summaryText = [summaryText, sprintf('Output Std: %.4f\n', stdOutput)];
    summaryText = [summaryText, sprintf('Coefficient of Variation: %.2f%%\n', 100*stdOutput/meanOutput)];
    
    [~, mostSensitiveIndex] = max(sobolFirstOrder);
    summaryText = [summaryText, sprintf('\nMost Sensitive Parameter:\n%s (S? = %.3f)\n', ...
        uncertaintyResults.parameterNames{mostSensitiveIndex}, sobolFirstOrder(mostSensitiveIndex))];
    
    summaryText = [summaryText, sprintf('\nAverage Execution Time: %.1f ms\n', mean(validExecutionTimes) * 1000)];
    summaryText = [summaryText, sprintf('Analysis Date: %s', string(uncertaintyResults.timestamp))];
    
    text(0.05, 0.95, summaryText, 'FontSize', 11, 'VerticalAlignment', 'top', ...
        'HorizontalAlignment', 'left', 'Interpreter', 'none', 'FontWeight', 'bold');
    
    % Remaining subplots for additional analysis
    subplot(4, 4, 13);
    % Quantile-quantile plot for normality testing
    qqplot(outputData);
    title('Q-Q Plot (Normality Test)', 'FontSize', 12, 'FontWeight', 'bold');
    grid on;
    
    subplot(4, 4, 14);
    % Cumulative distribution function
    [f, x] = ecdf(outputData);
    plot(x, f, 'b-', 'LineWidth', 2);
    xlabel('Model Output', 'FontSize', 12);
    ylabel('Cumulative Probability', 'FontSize', 12);
    title('Empirical CDF', 'FontSize', 12, 'FontWeight', 'bold');
    grid on;
    
    subplot(4, 4, 15);
    % Parameter importance ranking
    [sortedSensitivity, sortOrder] = sort(sobolFirstOrder, 'descend');
    bar(sortedSensitivity, 'FaceColor', [0.7, 0.9, 0.7]);
    set(gca, 'XTickLabel', uncertaintyResults.parameterNames(sortOrder));
    ylabel('First-order Sobol Index', 'FontSize', 12);
    title('Parameter Importance Ranking', 'FontSize', 12, 'FontWeight', 'bold');
    xtickangle(45);
    grid on;
    
    subplot(4, 4, 16);
    % Success rate analysis
    successRate = sum(validOutputs) / length(validOutputs) * 100;
    failureRate = 100 - successRate;
    
    pie([successRate, failureRate], {'Successful Evaluations', 'Failed Evaluations'});
    title(sprintf('Evaluation Success Rate\n(%.1f%% successful)', successRate), ...
          'FontSize', 12, 'FontWeight', 'bold');
    
    % Save visualisation in multiple formats
    saveas(gcf, 'UncertaintyAnalysisResults.fig');
    saveas(gcf, 'UncertaintyAnalysisResults.eps', 'epsc');
    saveas(gcf, 'UncertaintyAnalysisResults.jpg');
    
    fprintf('Uncertainty analysis visualisation saved in multiple formats.\n');
end

function modelOutput = evaluateSystemModelWithUncertainty(systemModel, parameters, parameterNames)
    % Evaluate system model with uncertainty parameters
    
    % Create parameter structure
    parameterStruct = struct();
    for parameterIndex = 1:length(parameterNames)
        parameterStruct.(parameterNames{parameterIndex}) = parameters(parameterIndex);
    end
    
    % Evaluate model (simplified example)
    primaryMetric = 0.8 + 0.1 * sin(parameterStruct.parameter1 * pi) + ...
                   0.05 * cos(parameterStruct.parameter2 * 2 * pi) + ...
                   0.02 * randn; % Add noise
    
    % Ensure realistic bounds
    primaryMetric = max(0, min(1, primaryMetric));
    
    modelOutput = struct();
    modelOutput.primaryMetric = primaryMetric;
    modelOutput.parameters = parameterStruct;
end
