%% p4.m
% MATLABBook03_ChapterAIBHS_Problem04.m
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : p4
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function MATLABBook03_ChapterAIBHS_Problem04
% Purpose: pseudotime via PCA + MST. Author: Dr Leo Chen.
% R2024b + Statistics ML. v1.0 2025-06-01.
    rng(0); c=60; g=30; t=linspace(0,1,c)';
    latent=[[t sin(t*pi)];[t -sin(t*pi)]]+0.05*randn(2*c,2);
    X=latent*randn(2,g)+0.1*randn(2*c,g);
    [~,score]=pca(zscore(X)); red=score(:,1:2);
    tree=minspantree(graph(squareform(pdist(red)))); pt=distances(tree,1);
    fprintf('Cells: %d  Pseudotime range: %.2f to %.2f\n',2*c,min(pt),max(pt));
    figure; scatter(red(:,1),red(:,2),30,pt,'filled'); colorbar; grid on;
    xlabel('$\mathrm{PC1}$'); ylabel('$\mathrm{PC2}$');
end
