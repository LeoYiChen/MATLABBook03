%% p20.m
% MATLABBook03_ChapterAIBHS_Problem20.m
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : p20
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function MATLABBook03_ChapterAIBHS_Problem20
% Purpose: weighted conformer ensemble fitting a SAXS-like curve.
% Author: Dr Leo Chen. R2024b + Optimization Toolbox. v1.0 2025-06-01.
    rng(0); q=linspace(0.01,0.5,50)'; rgValues=linspace(15,35,10);
    profiles=exp(-(q.^2)*(rgValues.^2)/3);
    trueWeights=zeros(10,1); trueWeights([3 7])=[0.6 0.4];
    target=profiles*trueWeights+0.005*randn(size(q));
    weights=lsqnonneg(profiles,target); weights=weights/sum(weights);
    fprintf('Recovered ensemble Rg: %.1f Angstrom\n', rgValues*weights);
    fprintf('Dominant conformers: %s\n', mat2str(find(weights>0.1)'));
end
