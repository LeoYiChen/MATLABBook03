%% p16.m
% MATLABBook03_ChapterAIBHS_Problem16.m
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : p16
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function MATLABBook03_ChapterAIBHS_Problem16
% Purpose: resonant frequency of an acoustic-harvesting material.
% Author: Dr Leo Chen. R2024b (no toolbox). v1.0 2025-06-01.
    f=linspace(10,5000,1000); f0=1200; zeta=0.05;
    H=1./(1-(f/f0).^2+1i*2*zeta*(f/f0));
    [peakMag,idx]=max(abs(H));
    fprintf('Resonant frequency: %.0f Hz  Peak gain: %.1f\n', f(idx), peakMag);
    figure; plot(f,abs(H)); grid on;
    xlabel('$\mathrm{Frequency\ (Hz)}$'); ylabel('$\mathrm{|H(f)|}$');
end
