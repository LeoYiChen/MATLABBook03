%% chapter_AE_Problems_P3_AtmosphericGP.m
% Gaussian Process for atmospheric density prediction.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AE_Problems_P3_AtmosphericGP
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [predictedDensity, predictionUncertainty, gpModel] = atmosphericDensityGP(trainingData, testInputs, gpConfiguration)
    % Gaussian Process regression for atmospheric density prediction
    % Author: Dr Leo Chen  
    % Version: 2.0.0 - Enhanced with sparse GP methods
    % Date: 2024-11-14
    
    fprintf('Training Gaussian Process for atmospheric density prediction\n');
    fprintf('Training samples: %d, Test points: %d\n', size(trainingData.inputs, 1), size(testInputs, 1));
    
    % Extract training data
    trainInputs = trainingData.inputs;    % [altitude, solar_flux, geomag_index, local_time]
    trainOutputs = log(trainingData.density); % Log transform for better GP performance
    
    % Input preprocessing - standardisation
    inputMean = mean(trainInputs, 1);
    inputStd = std(trainInputs, 1);
    trainInputsNorm = (trainInputs - inputMean) ./ inputStd;
    testInputsNorm = (testInputs - inputMean) ./ inputStd;
    
    outputMean = mean(trainOutputs);
    outputStd = std(trainOutputs);
    trainOutputsNorm = (trainOutputs - outputMean) / outputStd;
    
    fprintf('Input preprocessing completed\n');
    fprintf('  Altitude range: %.0f - %.0f km\n', min(trainInputs(:,1)), max(trainInputs(:,1)));
    fprintf('  Solar flux range: %.0f - %.0f SFU\n', min(trainInputs(:,2)), max(trainInputs(:,2)));
    
    % Define composite covariance function
    % k(x,x') = k_altitude(x1,x1') * k_solar(x2,x2') + k_geomag(x3,x3') + k_time(x4,x4')
    hyperparameters = optimiseHyperparameters(trainInputsNorm, trainOutputsNorm, gpConfiguration);
    
    fprintf('Hyperparameter optimisation completed\n');
    fprintf('  Length scales: [%.3f, %.3f, %.3f, %.3f]\n', hyperparameters.lengthScales);
    fprintf('  Signal variance: %.6f\n', hyperparameters.signalVariance);
    fprintf('  Noise variance: %.6f\n', hyperparameters.noiseVariance);
    
    % Compute covariance matrices
    kernelFunction = @(x1, x2) computeAtmosphericKernel(x1, x2, hyperparameters);
    
    if size(trainInputsNorm, 1) > gpConfiguration.sparseThreshold
        % Use sparse GP for large datasets
        [predictedDensityNorm, predictionVariance, gpModel] = sparseGaussianProcess(...
            trainInputsNorm, trainOutputsNorm, testInputsNorm, kernelFunction, gpConfiguration);
        fprintf('Sparse GP used with %d inducing points\n', gpConfiguration.numInducingPoints);
    else
        % Full GP for smaller datasets
        [predictedDensityNorm, predictionVariance, gpModel] = fullGaussianProcess(...
            trainInputsNorm, trainOutputsNorm, testInputsNorm, kernelFunction);
        fprintf('Full GP computation completed\n');
    end
    
    % Transform predictions back to original scale
    predictedDensityLog = predictedDensityNorm * outputStd + outputMean;
    predictedDensity = exp(predictedDensityLog);
    
    % Uncertainty propagation through exponential transform
    predictionUncertaintyLog = sqrt(predictionVariance) * outputStd;
    predictionUncertainty = predictedDensity .* predictionUncertaintyLog; % Delta method approximation
    
    % Store model parameters
    gpModel.hyperparameters = hyperparameters;
    gpModel.inputNormalisation.mean = inputMean;
    gpModel.inputNormalisation.std = inputStd;
    gpModel.outputNormalisation.mean = outputMean;
    gpModel.outputNormalisation.std = outputStd;
    
    fprintf('Atmospheric density prediction completed\n');
    fprintf('  Prediction range: %.2e - %.2e kg/m?\n', min(predictedDensity), max(predictedDensity));
    fprintf('  Average relative uncertainty: %.1f%%\n', ...
            mean(predictionUncertainty ./ predictedDensity) * 100);
end

function hyperparameters = optimiseHyperparameters(trainInputs, trainOutputs, configuration)
    % Optimise GP hyperparameters using maximum likelihood
    
    % Initial hyperparameter guess
    initialLengthScales = ones(1, size(trainInputs, 2));
    initialSignalVariance = var(trainOutputs);
    initialNoiseVariance = 0.01 * initialSignalVariance;
    
    initialHyperparams = [log(initialLengthScales), log(initialSignalVariance), log(initialNoiseVariance)];
    
    % Objective function: negative log marginal likelihood
    objectiveFunction = @(params) negativeLogMarginalLikelihood(params, trainInputs, trainOutputs);
    
    % Optimisation options
    optimisationOptions = optimoptions('fminunc', 'Display', 'iter', 'MaxIterations', 500, ...
                                      'GradObj', 'on', 'Algorithm', 'quasi-newton');
    
    % Run optimisation
    fprintf('Optimising hyperparameters using L-BFGS...\n');
    [optimalParams, optimalValue] = fminunc(objectiveFunction, initialHyperparams, optimisationOptions);
    
    % Extract optimised hyperparameters
    numInputs = size(trainInputs, 2);
    hyperparameters.lengthScales = exp(optimalParams(1:numInputs));
    hyperparameters.signalVariance = exp(optimalParams(numInputs + 1));
    hyperparameters.noiseVariance = exp(optimalParams(numInputs + 2));
    
    fprintf('Optimisation completed: final log-likelihood = %.4f\n', -optimalValue);
end

function kernelValue = computeAtmosphericKernel(input1, input2, hyperparameters)
    % Composite kernel for atmospheric density modelling
    % Combines different kernels for different input dimensions
    
    lengthScales = hyperparameters.lengthScales;
    signalVariance = hyperparameters.signalVariance;
    
    % Squared exponential kernels for each dimension
    altitudeKernel = exp(-0.5 * ((input1(:,1) - input2(:,1)') / lengthScales(1)).^2);
    solarKernel = exp(-0.5 * ((input1(:,2) - input2(:,2)') / lengthScales(2)).^2);
    geomagKernel = exp(-0.5 * ((input1(:,3) - input2(:,3)') / lengthScales(3)).^2);
    
    % Periodic kernel for local time (24-hour cycle)
    timeDistance = abs(input1(:,4) - input2(:,4)');
    timeKernel = exp(-2 * sin(pi * timeDistance / 24).^2 / lengthScales(4)^2);
    
    % Composite kernel: altitude -- solar -- (geomag + time)
    kernelValue = signalVariance * altitudeKernel .* solarKernel .* (geomagKernel + timeKernel);
end
