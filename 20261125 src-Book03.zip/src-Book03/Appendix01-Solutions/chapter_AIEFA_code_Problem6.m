%% chapter_AIEFA_code_Problem6.m
% Insurance capital reserve stress testing (MATLABBook02_AIEFA_Problem6_InsuranceCapitalReserve.m).
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AIEFA_code_Problem6
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%=========================================================================
% FILE   : MATLABBook02_AIEFA_Problem6_InsuranceCapitalReserve.m
% DESCR. : Monte Carlo insurance capital reserve stress testing under a
%           Japan-inspired four-phase property market decline
% AUTHOR : Dr Yi Chen
% MATLAB : R2023b (compatible with R2019b and later)
% CREATED: July 2025   VERSION: 1.0
%=========================================================================
clear; clc; close all;
rng(42);  % reproducibility

%% -- 1. Portfolio Configuration --
numPolicies        = 200;
numSimulations     = 10000;
numMonths          = 120;        % 10-year horizon
initialIndexValue  = 100;

% Property values: GBP 80 000 - 120 000 (uniform)
propertyValues     = 80000 + 40000 * rand(numPolicies, 1);
% Loan-to-value ratios: 60% - 90% (uniform)
loanToValueRatios  = 0.60 + 0.30 * rand(numPolicies, 1);
mortgageOutstanding = loanToValueRatios .* propertyValues;
idiosyncraticVol   = 0.01;  % monthly

totalPortfolioValue = sum(propertyValues);
totalMortgageValue  = sum(mortgageOutstanding);
meanLTV             = mean(loanToValueRatios);
fprintf('Portfolio: %d policies, total value GBP %.2fM\n', ...
    numPolicies, totalPortfolioValue / 1e6);
fprintf('Total mortgages: GBP %.2fM, mean LTV: %.1f%%\n', ...
    totalMortgageValue / 1e6, meanLTV * 100);

%% -- 2. Japan-Inspired Four-Phase Regime Calibration --
%  Phase 1 (months 1-24):  Developer discounts, priced-but-unsold
%  Phase 2 (months 25-48): Foreclosure wave, economic deterioration
%  Phase 3 (months 49-72): Panic selling, sell-off spiral
%  Phase 4 (months 73-120): Tax-induced liquidation, 1-yen villas
phaseEndMonths   = [24, 48, 72, 120];
regimeDrift      = [-0.002; -0.005; -0.003; -0.001]; % monthly
regimeVolatility = [0.015;  0.025;  0.035;  0.020];  % monthly
phaseLabels      = {'Phase 1: Developer Discounts', ...
                    'Phase 2: Foreclosure Wave', ...
                    'Phase 3: Panic Selling', ...
                    'Phase 4: Tax-Induced Liquidation'};

% Normal (benign) market parameters
normalDrift      = 0.002;   % monthly
normalVolatility = 0.012;   % monthly

% Build monthly parameter vectors for stress scenario
stressDriftVec = zeros(numMonths, 1);
stressVolVec   = zeros(numMonths, 1);
phaseStartMonth = 1;
for phaseIdx = 1:4
    phaseEnd = phaseEndMonths(phaseIdx);
    stressDriftVec(phaseStartMonth:phaseEnd) = ...
        regimeDrift(phaseIdx);
    stressVolVec(phaseStartMonth:phaseEnd)   = ...
        regimeVolatility(phaseIdx);
    phaseStartMonth = phaseEnd + 1;
end

%% -- 3. Monte Carlo Index Path Simulation (Vectorised) --
% Systematic shocks: numMonths x numSimulations
systematicShocks = randn(numMonths, numSimulations);

% Stress scenario: regime-dependent GBM
stressLogReturns = (stressDriftVec - stressVolVec.^2 / 2) ...
    + stressVolVec .* systematicShocks;
stressCumLogReturn = cumsum(stressLogReturns, 1);
stressIndexPaths = initialIndexValue * ...
    exp([zeros(1, numSimulations); stressCumLogReturn]);
% stressIndexPaths is (numMonths+1) x numSimulations

% Normal scenario: constant GBM
normalLogReturns = (normalDrift - normalVolatility^2 / 2) ...
    + normalVolatility * systematicShocks;
normalCumLogReturn = cumsum(normalLogReturns, 1);
normalIndexPaths = initialIndexValue * ...
    exp([zeros(1, numSimulations); normalCumLogReturn]);

% Terminal index values (row vectors, 1 x numSimulations)
stressTerminalIndex = stressIndexPaths(end, :);
normalTerminalIndex = normalIndexPaths(end, :);

fprintf('\nStress terminal index: mean=%.2f, median=%.2f\n', ...
    mean(stressTerminalIndex), median(stressTerminalIndex));
fprintf('Normal terminal index: mean=%.2f, median=%.2f\n', ...
    mean(normalTerminalIndex), median(normalTerminalIndex));

%% -- 4. Aggregate Loss Computation --
% Idiosyncratic shocks: numPolicies x numSimulations
idiosyncraticShocks = randn(numPolicies, numSimulations);
totalIdioSigma = idiosyncraticVol * sqrt(numMonths);
idioMultiplier = exp(-totalIdioSigma^2 / 2 ...
    + totalIdioSigma * idiosyncraticShocks);

% Terminal property values: numPolicies x numSimulations
stressIndexRatio = stressTerminalIndex / initialIndexValue;
normalIndexRatio = normalTerminalIndex / initialIndexValue;
terminalValueStress = propertyValues * stressIndexRatio ...
    .* idioMultiplier;
terminalValueNormal = propertyValues * normalIndexRatio ...
    .* idioMultiplier;

% Policy-level losses (insurer pays the shortfall)
policyLossStress = max(0, ...
    mortgageOutstanding - terminalValueStress);
policyLossNormal = max(0, ...
    mortgageOutstanding - terminalValueNormal);

% Aggregate portfolio losses (column vectors)
aggregateLossStress = sum(policyLossStress, 1)';
aggregateLossNormal = sum(policyLossNormal, 1)';

fprintf('\nStress: mean loss = GBP %.0f, std = GBP %.0f\n', ...
    mean(aggregateLossStress), std(aggregateLossStress));
fprintf('Normal: mean loss = GBP %.0f, std = GBP %.0f\n', ...
    mean(aggregateLossNormal), std(aggregateLossNormal));

%% -- 5. VaR and Expected Shortfall --
sortedStressLoss = sort(aggregateLossStress);
sortedNormalLoss = sort(aggregateLossNormal);

confidenceLevels = [0.950; 0.990; 0.995; 0.999];
numLevels = length(confidenceLevels);
varStress = zeros(numLevels, 1);
varNormal = zeros(numLevels, 1);
esStress  = zeros(numLevels, 1);
esNormal  = zeros(numLevels, 1);

for levelIdx = 1:numLevels
    quantileIdx = ceil(confidenceLevels(levelIdx) ...
        * numSimulations);
    varStress(levelIdx) = sortedStressLoss(quantileIdx);
    varNormal(levelIdx) = sortedNormalLoss(quantileIdx);
    esStress(levelIdx)  = mean( ...
        sortedStressLoss(quantileIdx:end));
    esNormal(levelIdx)  = mean( ...
        sortedNormalLoss(quantileIdx:end));
end

% Capital adequacy gap at Solvency II level (99.5%)
solvencyIdx = find(abs(confidenceLevels - 0.995) < 1e-6, 1);
capitalGap  = varStress(solvencyIdx) - varNormal(solvencyIdx);
fprintf(['\nSolvency II capital gap (VaR 99.5%%): ' ...
    'GBP %.0f\n'], capitalGap);

%% -- 6. Phase-by-Phase Index Decline (Median Path) --
medianIndexPath = median(stressIndexPaths, 2);
fprintf('\n- Phase-by-Phase Median Index Decline -\n');
fprintf('%-38s  Start   End   Decline\n', 'Phase');
phaseStartVal = initialIndexValue;
for phaseIdx = 1:4
    phaseEndVal = medianIndexPath(phaseEndMonths(phaseIdx) + 1);
    pctChange   = (phaseEndVal - phaseStartVal) ...
        / phaseStartVal * 100;
    fprintf('%-38s %6.1f  %6.1f  %+.1f%%\n', ...
        phaseLabels{phaseIdx}, phaseStartVal, ...
        phaseEndVal, pctChange);
    phaseStartVal = phaseEndVal;
end

%% -- 7. Display Risk Metrics Table --
fprintf('\n- VaR and Expected Shortfall (GBP) -\n');
fprintf('%-12s  %12s %12s %12s %12s\n', ...
    'Confidence', 'VaR Stress', 'VaR Normal', ...
    'ES Stress', 'ES Normal');
for levelIdx = 1:numLevels
    fprintf('%-12.1f%%  %12.0f %12.0f %12.0f %12.0f\n', ...
        confidenceLevels(levelIdx) * 100, ...
        varStress(levelIdx), varNormal(levelIdx), ...
        esStress(levelIdx), esNormal(levelIdx));
end

%% -- 8. Plotting --
figure('Position', [40, 40, 1200, 750]);
timeAxis = (0:numMonths)';

% (a) Sample stress index paths with phase boundaries
subplot(2, 2, 1);
numPlotPaths = 50;
plot(timeAxis, stressIndexPaths(:, 1:numPlotPaths), ...
    'Color', [0.7 0.7 0.9], 'LineWidth', 0.3);
hold on;
plot(timeAxis, medianIndexPath, 'b-', 'LineWidth', 1.8);
for phaseIdx = 1:3
    xline(phaseEndMonths(phaseIdx), 'r--', 'LineWidth', 0.8);
end
xlabel('Month $t$', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Property Price Index', ...
    'Interpreter', 'latex', 'FontSize', 11);
title('Stress Scenario: Japan-Inspired Four-Phase Decline', ...
    'Interpreter', 'latex', 'FontSize', 11);
legend('Simulated Paths', 'Median Path', 'Phase Boundary', ...
    'Interpreter', 'latex', 'Location', 'southwest');
grid on;

% (b) Loss distribution comparison
subplot(2, 2, 2);
stressEdges = linspace(0, max(aggregateLossStress) * 1.05, 60);
histogram(aggregateLossStress, stressEdges, ...
    'FaceColor', [0.85 0.33 0.10], 'FaceAlpha', 0.7, ...
    'EdgeColor', 'none');
hold on;
xline(varStress(solvencyIdx), 'r-', 'LineWidth', 1.5);
xline(esStress(solvencyIdx), 'r--', 'LineWidth', 1.5);
xlabel('Aggregate Portfolio Loss (GBP)', ...
    'Interpreter', 'latex', 'FontSize', 11);
ylabel('Frequency', 'Interpreter', 'latex', 'FontSize', 11);
title('Stress Loss Distribution', ...
    'Interpreter', 'latex', 'FontSize', 11);
legend('Loss Distribution', '$\mathrm{VaR}_{99.5\%}$', ...
    '$\mathrm{ES}_{99.5\%}$', ...
    'Interpreter', 'latex', 'Location', 'northeast');
grid on;

% (c) VaR/ES bar chart comparison
subplot(2, 2, 3);
barData = [varStress, varNormal] / 1e6;
barHandle = bar(barData, 'grouped');
barHandle(1).FaceColor = [0.85 0.33 0.10];
barHandle(2).FaceColor = [0.00 0.45 0.74];
set(gca, 'XTickLabel', {'95\%', '99\%', '99.5\%', '99.9\%'});
xlabel('Confidence Level $\alpha$', ...
    'Interpreter', 'latex', 'FontSize', 11);
ylabel('VaR (GBP millions)', ...
    'Interpreter', 'latex', 'FontSize', 11);
title('VaR Comparison: Stress vs Normal', ...
    'Interpreter', 'latex', 'FontSize', 11);
legend('Stress (Japan)', 'Normal', ...
    'Interpreter', 'latex', 'Location', 'northwest');
grid on;

% (d) Median paths: stress vs normal
subplot(2, 2, 4);
medianNormalPath = median(normalIndexPaths, 2);
plot(timeAxis, medianIndexPath, 'r-', 'LineWidth', 1.5);
hold on;
plot(timeAxis, medianNormalPath, 'b-', 'LineWidth', 1.5);
for phaseIdx = 1:3
    xline(phaseEndMonths(phaseIdx), 'k:', 'LineWidth', 0.6);
end
xlabel('Month $t$', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Property Price Index', ...
    'Interpreter', 'latex', 'FontSize', 11);
title('Median Index Path: Stress vs Normal', ...
    'Interpreter', 'latex', 'FontSize', 11);
legend('Stress (Japan)', 'Normal', 'Phase Boundary', ...
    'Interpreter', 'latex', 'Location', 'east');
grid on;

fprintf('\n- Analysis Complete -\n');
% Computational Complexity:
% Generating M*T systematic shocks: O(M*T). Cumulative sum
% for index paths: O(M*T). Idiosyncratic shocks: O(N*M).
% Terminal value matrix (N x M): O(N*M). Aggregate loss:
% O(N*M). Sorting for VaR/ES: O(M*log(M)). For M=10000,
% T=120, N=200: dominant cost is the N*M = 2M-entry
% matrix operations, completing well under two seconds
% on modern hardware with vectorised MATLAB.
