%% css_mcda.m
% Weighted multi-criteria ranking of design options.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : css_mcda
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function rankingTable = rankDesignOptions(decisionMatrix, weights, optionNames)
% rankDesignOptions  Weighted-sum MCDA ranking.
%   rankingTable = rankDesignOptions(decisionMatrix, weights, optionNames)
%   Rows = alternatives, columns = criteria (higher is better).
%   Author: Dr Leo Chen | Version 1.0 | Base MATLAB (R2021b+)

    weights = weights(:)' / sum(weights);
    columnMax = max(decisionMatrix, [], 1);
    normalised = decisionMatrix ./ columnMax;

    score = normalised * weights';
    [sortedScore, order] = sort(score, 'descend');

    rankingTable = table(optionNames(order), sortedScore, ...
        'VariableNames', {'Option', 'Score'});
end
