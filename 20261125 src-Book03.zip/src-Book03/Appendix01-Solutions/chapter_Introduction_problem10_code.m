%% chapter_Introduction_problem10_code.m
% MATLAB integration with external tools.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_Introduction_problem10_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% MATLABBook03_Chapter01_Problem10.m
% MATLAB Integration with External Tools
% This script demonstrates how MATLAB can integrate with various external
% tools and platforms to support multidisciplinary workflows

%% Setup and Configuration
clear;
clc;
close all;
rng(42); % For reproducibility

% Create a logger to track the workflow execution
logFile = 'integration_workflow_log.txt';
if exist(logFile, 'file')
    delete(logFile);
end

% Initialize log
writeToLog(logFile, 'MATLAB Integration Workflow Started');
writeToLog(logFile, ['Execution Time: ', datestr(now)]);
writeToLog(logFile, '--------------');

%% 1. DATA IMPORT FROM EXTERNAL SOURCES
% In this section, we demonstrate how to import data from different external sources:
% 1. Web API (REST API)
% 2. Database (SQL)
% 3. External files (CSV, Excel, JSON)
% 4. Simulated hardware (for demonstration)

writeToLog(logFile, '1. EXTERNAL DATA IMPORT');

%% 1.1 Import from Web API (REST)
% For demonstration, we'll use a public API that doesn't require authentication
% In practice, you would use your own API endpoints with proper authentication

writeToLog(logFile, '1.1 Importing from Web API...');

% Define API endpoint
api_url = 'https://jsonplaceholder.typicode.com/posts';

try
    % Create web options with timeout
    options = weboptions('Timeout', 20, 'ContentType', 'json');
    
    % Send GET request to the API
    writeToLog(logFile, ['Sending GET request to: ', api_url]);
    api_data = webread(api_url, options);
    
    % Convert to table for easier manipulation
    api_table = struct2table(api_data);
    
    writeToLog(logFile, ['Successfully retrieved ', num2str(height(api_table)), ' records from API']);
    writeToLog(logFile, ['Fields: ', strjoin(api_table.Properties.VariableNames, ', ')]);
    
    % For demonstration, lets create and display a summary
    userId_counts = groupcounts(api_table, 'userId');
    
    % Plot user post counts
    figure('Name', 'Web API Data');
    subplot(2, 1, 1);
    bar(userId_counts.userId, userId_counts.GroupCount);
    title('Post Count by User');
    xlabel('User ID');
    ylabel('Number of Posts');
    grid on;
    
    % Word count analysis
    word_counts = zeros(height(api_table), 1);
    for i = 1:height(api_table)
        words = strsplit(api_table.body{i});
        word_counts(i) = length(words);
    end
    
    subplot(2, 1, 2);
    histogram(word_counts, 15);
    title('Distribution of Post Lengths');
    xlabel('Word Count');
    ylabel('Frequency');
    grid on;
    
    % Save the figure
    saveas(gcf, 'web_api_analysis.png');
    writeToLog(logFile, 'Generated web API data visualisation');
    
catch e
    writeToLog(logFile, ['ERROR importing from API: ', e.message]);
    % Create synthetic data for demonstration if API call fails
    writeToLog(logFile, 'Creating synthetic API data for demonstration...');
    
    % Create random post data
    n_users = 10;
    n_posts = 100;
    
    user_ids = randi(n_users, n_posts, 1);
    post_ids = (1:n_posts)';
    titles = arrayfun(@(x) ['Post Title ', num2str(x)], 1:n_posts, 'UniformOutput', false);
    bodies = arrayfun(@(x) ['This is the body of post ', num2str(x), '. It contains some text.'], ...
                     1:n_posts, 'UniformOutput', false);
    
    api_table = table(user_ids, post_ids, titles, bodies, ...
                    'VariableNames', {'userId', 'id', 'title', 'body'});
    
    writeToLog(logFile, ['Created synthetic API data with ', num2str(height(api_table)), ' records']);
end

%% 1.2 Import from Database
% For demonstration, we'll create a temporary SQLite database
% In practice, you would connect to your actual database

writeToLog(logFile, '1.2 Importing from Database...');

try
    % Create a temporary SQLite database
    database_file = 'temp_database.db';
    if exist(database_file, 'file')
        delete(database_file);
    end
    
    % Create connection
    writeToLog(logFile, ['Connecting to SQLite database: ', database_file]);
    conn = sqlite(database_file, 'create');
    
    % Create tables and insert sample data
    % Sensor data table
    createTableQuery = ['CREATE TABLE sensor_data (', ...
                      'timestamp TEXT, ', ...
                      'sensor_id INTEGER, ', ...
                      'temperature REAL, ', ...
                      'humidity REAL, ', ...
                      'pressure REAL)'];
    
    execute(conn, createTableQuery);
    writeToLog(logFile, 'Created sensor_data table in database');
    
    % Generate sample sensor data
    n_sensors = 5;
    n_readings_per_sensor = 24; % One reading per hour for a day
    
    % Initialize data arrays
    timestamps = cell(n_sensors * n_readings_per_sensor, 1);
    sensor_ids = zeros(n_sensors * n_readings_per_sensor, 1);
    temperatures = zeros(n_sensors * n_readings_per_sensor, 1);
    humidities = zeros(n_sensors * n_readings_per_sensor, 1);
    pressures = zeros(n_sensors * n_readings_per_sensor, 1);
    
    % Generate data
    base_time = datetime('now') - days(1);
    
    for i = 1:n_sensors
        for j = 1:n_readings_per_sensor
            idx = (i-1) * n_readings_per_sensor + j;
            
            % Create timestamp (one reading per hour)
            timestamp = base_time + hours(j-1);
            timestamps{idx} = char(timestamp);
            
            % Sensor ID
            sensor_ids(idx) = i;
            
            % Generate sensor readings with realistic patterns
            hour_of_day = hour(timestamp);
            
            % Temperature varies by time of day
            base_temp = 20 + 2 * sin(2 * pi * hour_of_day / 24);
            temperatures(idx) = base_temp + 0.5 * randn();
            
            % Humidity varies inversely with temperature
            base_humidity = 60 - 10 * sin(2 * pi * hour_of_day / 24);
            humidities(idx) = base_humidity + 2 * randn();
            
            % Pressure varies slowly throughout the day
            base_pressure = 1013 + 2 * sin(2 * pi * hour_of_day / 48);
            pressures(idx) = base_pressure + 0.5 * randn();
        end
    end
    
    % Insert data into the database
    for i = 1:length(timestamps)
        insertQuery = sprintf(['INSERT INTO sensor_data VALUES (', ...
                             '''%s'', %d, %.2f, %.2f, %.2f)'], ...
                            timestamps{i}, sensor_ids(i), temperatures(i), ...
                            humidities(i), pressures(i));
        execute(conn, insertQuery);
    end
    
    writeToLog(logFile, ['Inserted ', num2str(length(timestamps)), ' sensor readings into database']);
    
    % Query the data back
    query = ['SELECT sensor_id, strftime(''%H'', timestamp) as hour, ', ...
           'AVG(temperature) as avg_temp, AVG(humidity) as avg_humidity, ', ...
           'AVG(pressure) as avg_pressure ', ...
           'FROM sensor_data ', ...
           'GROUP BY sensor_id, hour ', ...
           'ORDER BY sensor_id, hour'];
    
    db_data = fetch(conn, query);
    writeToLog(logFile, ['Retrieved ', num2str(height(db_data)), ' aggregated records from database']);
    
    % Close the database connection
    close(conn);
    
    % Convert hour to numeric for plotting
    db_data.hour = str2double(db_data.hour);
    
    % Plot the data
    figure('Name', 'Database Data');
    
    % Temperature by hour and sensor
    subplot(3, 1, 1);
    sensors = unique(db_data.sensor_id);
    hold on;
    for i = 1:length(sensors)
        sensor_rows = db_data.sensor_id == sensors(i);
        plot(db_data.hour(sensor_rows), db_data.avg_temp(sensor_rows), 'o-', 'LineWidth', 1.5);
    end
    title('Average Temperature by Hour');
    xlabel('Hour of Day');
    ylabel('Temperature (--C)');
    grid on;
    legend(arrayfun(@(x) ['Sensor ', num2str(x)], sensors, 'UniformOutput', false), 'Location', 'best');
    
    % Humidity
    subplot(3, 1, 2);
    hold on;
    for i = 1:length(sensors)
        sensor_rows = db_data.sensor_id == sensors(i);
        plot(db_data.hour(sensor_rows), db_data.avg_humidity(sensor_rows), 'o-', 'LineWidth', 1.5);
    end
    title('Average Humidity by Hour');
    xlabel('Hour of Day');
    ylabel('Humidity (%)');
    grid on;
    
    % Pressure
    subplot(3, 1, 3);
    hold on;
    for i = 1:length(sensors)
        sensor_rows = db_data.sensor_id == sensors(i);
        plot(db_data.hour(sensor_rows), db_data.avg_pressure(sensor_rows), 'o-', 'LineWidth', 1.5);
    end
    title('Average Pressure by Hour');
    xlabel('Hour of Day');
    ylabel('Pressure (hPa)');
    grid on;
    
    % Save the figure
    saveas(gcf, 'database_analysis.png');
    writeToLog(logFile, 'Generated database data visualisation');
    
catch e
    writeToLog(logFile, ['ERROR working with database: ', e.message]);
    writeToLog(logFile, 'Database import demonstration skipped');
    
    % Create synthetic data for demonstration
    db_data = table();
end

%% 1.3 Import from Files (CSV, Excel, JSON)
% For demonstration, we'll create and then import sample files
% In practice, you would import from existing files

writeToLog(logFile, '1.3 Importing from External Files...');

try
    % 1.3.1 Create sample CSV file with sales data
    writeToLog(logFile, 'Creating and importing CSV file...');
    
    % Create sample sales data
    n_products = 5;
    n_months = 12;
    
    % Product information
    product_ids = (1:n_products)';
    product_names = {'Widget', 'Gadget', 'Doohickey', 'Thingamajig', 'Whatsit'};
    product_categories = {'Electronics', 'Household', 'Electronics', 'Tools', 'Household'};
    
    % Create a sales matrix (products x months)
    base_sales = [100, 150, 75, 200, 120]';  % Base monthly sales for each product
    monthly_factors = [0.8, 0.9, 1.0, 1.1, 1.2, 1.3, 1.4, 1.3, 1.2, 1.1, 1.0, 1.5];  % Seasonal factors
    
    sales_data = zeros(n_products, n_months);
    for i = 1:n_products
        for j = 1:n_months
            sales_data(i, j) = base_sales(i) * monthly_factors(j) * (1 + 0.1 * randn());
        end
    end
    
    % Create the CSV file
    csv_file = 'sales_data.csv';
    fid = fopen(csv_file, 'w');
    
    % Write header
    fprintf(fid, 'ProductID,ProductName,Category');
    for i = 1:n_months
        fprintf(fid, ',Month%d', i);
    end
    fprintf(fid, '\n');
    
    % Write data
    for i = 1:n_products
        fprintf(fid, '%d,%s,%s', product_ids(i), product_names{i}, product_categories{i});
        for j = 1:n_months
            fprintf(fid, ',%.2f', sales_data(i, j));
        end
        fprintf(fid, '\n');
    end
    
    fclose(fid);
    writeToLog(logFile, ['Created CSV file: ', csv_file]);
    
    % Import the CSV file
    csv_data = readtable(csv_file);
    writeToLog(logFile, ['Imported CSV data with ', num2str(height(csv_data)), ' rows and ', ...
                       num2str(width(csv_data)), ' columns']);
    
    % Analyze sales data
    figure('Name', 'CSV File Data');
    
    % Total sales by product
    subplot(2, 1, 1);
    product_totals = sum(table2array(csv_data(:, 4:end)), 2);
    bar(product_totals);
    title('Total Annual Sales by Product');
    xlabel('Product');
    xticklabels(csv_data.ProductName);
    xtickangle(45);
    ylabel('Sales');
    grid on;
    
    % Monthly sales trends
    subplot(2, 1, 2);
    monthly_totals = sum(table2array(csv_data(:, 4:end)));
    plot(1:n_months, monthly_totals, 'o-', 'LineWidth', 1.5);
    title('Monthly Sales Trend');
    xlabel('Month');
    ylabel('Total Sales');
    grid on;
    
    % Save the figure
    saveas(gcf, 'csv_analysis.png');
    writeToLog(logFile, 'Generated CSV data visualisation');
    
    % 1.3.2 Create sample Excel file with financial data
    writeToLog(logFile, 'Creating and importing Excel file...');
    
    % Create sample financial data
    n_companies = 4;
    n_years = 5;
    
    % Company information
    company_names = {'Alpha Corp', 'Beta Inc', 'Gamma LLC', 'Delta Co'};
    industries = {'Technology', 'Healthcare', 'Manufacturing', 'Retail'};
    
    % Financial metrics
    revenue = zeros(n_companies, n_years);
    profit = zeros(n_companies, n_years);
    assets = zeros(n_companies, n_years);
    liabilities = zeros(n_companies, n_years);
    
    % Generate financial data with realistic growth patterns
    for i = 1:n_companies
        % Initial values (millions $)
        initial_revenue = 100 + 900 * rand();  % $100M to $1B
        initial_profit_margin = 0.05 + 0.15 * rand();  % 5% to 20%
        initial_assets = initial_revenue * (1 + 2 * rand());  % 1x to 3x revenue
        initial_debt_ratio = 0.2 + 0.4 * rand();  % 20% to 60% debt to assets
        
        % Growth rates
        revenue_growth = 0.03 + 0.07 * rand();  % 3% to 10% annual growth
        
        % Generate time series
        for j = 1:n_years
            % Revenue growth with some random variation
            if j == 1
                revenue(i, j) = initial_revenue;
            else
                revenue(i, j) = revenue(i, j-1) * (1 + revenue_growth + 0.02 * randn());
            end
            
            % Profit as percentage of revenue (varies by year)
            profit_margin = initial_profit_margin + 0.01 * randn();
            profit(i, j) = revenue(i, j) * profit_margin;
            
            % Assets grow with revenue but at a different rate
            if j == 1
                assets(i, j) = initial_assets;
            else
                assets(i, j) = assets(i, j-1) * (1 + revenue_growth * (0.8 + 0.4 * rand()));
            end
            
            % Liabilities as percentage of assets
            debt_ratio = initial_debt_ratio + 0.02 * randn();
            liabilities(i, j) = assets(i, j) * debt_ratio;
        end
    end
    
    % Create the Excel file
    excel_file = 'financial_data.xlsx';
    
    % Company info sheet
    company_info = table(company_names', industries', 'VariableNames', {'Company', 'Industry'});
    writetable(company_info, excel_file, 'Sheet', 'Company Info');
    
    % Revenue sheet
    year_headers = cell(1, n_years);
    for i = 1:n_years
        year_headers{i} = ['Year', num2str(i)];
    end
    revenue_table = array2table(revenue, 'VariableNames', year_headers);
    revenue_table = [table(company_names', 'VariableNames', {'Company'}), revenue_table];
    writetable(revenue_table, excel_file, 'Sheet', 'Revenue');
    
    % Profit sheet
    profit_table = array2table(profit, 'VariableNames', year_headers);
    profit_table = [table(company_names', 'VariableNames', {'Company'}), profit_table];
    writetable(profit_table, excel_file, 'Sheet', 'Profit');
    
    % Balance Sheet
    assets_table = array2table(assets, 'VariableNames', year_headers);
    assets_table = [table(company_names', 'VariableNames', {'Company'}), assets_table];
    writetable(assets_table, excel_file, 'Sheet', 'Assets');
    
    liabilities_table = array2table(liabilities, 'VariableNames', year_headers);
    liabilities_table = [table(company_names', 'VariableNames', {'Company'}), liabilities_table];
    writetable(liabilities_table, excel_file, 'Sheet', 'Liabilities');
    
    writeToLog(logFile, ['Created Excel file: ', excel_file]);
    
    % Import the Excel file data
    company_info = readtable(excel_file, 'Sheet', 'Company Info');
    revenue_data = readtable(excel_file, 'Sheet', 'Revenue');
    profit_data = readtable(excel_file, 'Sheet', 'Profit');
    assets_data = readtable(excel_file, 'Sheet', 'Assets');
    liabilities_data = readtable(excel_file, 'Sheet', 'Liabilities');
    
    writeToLog(logFile, 'Imported financial data from Excel file');
    
    % Analyze financial data
    figure('Name', 'Excel File Data');
    
    % Revenue growth
    subplot(2, 2, 1);
    hold on;
    for i = 1:n_companies
        revenue_values = revenue_data{i, 2:end};
        plot(1:n_years, revenue_values, 'o-', 'LineWidth', 1.5);
    end
    title('Revenue Growth');
    xlabel('Year');
    ylabel('Revenue (millions $)');
    legend(company_names, 'Location', 'best');
    grid on;
    
    % Profit margins
    subplot(2, 2, 2);
    profit_margins = zeros(n_companies, n_years);
    hold on;
    for i = 1:n_companies
        profit_values = profit_data{i, 2:end};
        revenue_values = revenue_data{i, 2:end};
        profit_margins(i, :) = profit_values ./ revenue_values * 100;
        plot(1:n_years, profit_margins(i, :), 'o-', 'LineWidth', 1.5);
    end
    title('Profit Margin');
    xlabel('Year');
    ylabel('Profit Margin (%)');
    grid on;
    
    % Return on Assets
    subplot(2, 2, 3);
    roa = zeros(n_companies, n_years);
    hold on;
    for i = 1:n_companies
        profit_values = profit_data{i, 2:end};
        asset_values = assets_data{i, 2:end};
        roa(i, :) = profit_values ./ asset_values * 100;
        plot(1:n_years, roa(i, :), 'o-', 'LineWidth', 1.5);
    end
    title('Return on Assets');
    xlabel('Year');
    ylabel('ROA (%)');
    grid on;
    
    % Debt to Asset Ratio
    subplot(2, 2, 4);
    debt_ratio = zeros(n_companies, n_years);
    hold on;
    for i = 1:n_companies
        liability_values = liabilities_data{i, 2:end};
        asset_values = assets_data{i, 2:end};
        debt_ratio(i, :) = liability_values ./ asset_values * 100;
        plot(1:n_years, debt_ratio(i, :), 'o-', 'LineWidth', 1.5);
    end
    title('Debt to Asset Ratio');
    xlabel('Year');
    ylabel('Debt Ratio (%)');
    grid on;
    
    % Save the figure
    saveas(gcf, 'excel_analysis.png');
    writeToLog(logFile, 'Generated Excel data visualisation');
    
    % 1.3.3 Create sample JSON file with customer data
    writeToLog(logFile, 'Creating and importing JSON file...');
    
    % Create sample customer data
    n_customers = 50;
    
    % Customer information
    customer_ids = (1:n_customers)';
    first_names = {'John', 'Jane', 'Robert', 'Mary', 'William', 'Linda', 'Michael', 'Patricia', 'David', 'Elizabeth'};
    last_names = {'Smith', 'Johnson', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez', 'Wilson'};
    
    % Generate random customer data
    customers = struct();
    
    for i = 1:n_customers
        customer = struct();
        customer.id = customer_ids(i);
        customer.firstName = first_names{randi(length(first_names))};
        customer.lastName = last_names{randi(length(last_names))};
        customer.email = lower([customer.firstName, '.', customer.lastName, num2str(randi(100)), '@example.com']);
        customer.age = 20 + randi(50);
        customer.joinDate = datestr(now - randi(1000), 'yyyy-mm-dd');
        
        % Purchase history
        n_purchases = randi([2, 10]);
        purchases = struct();
        
        for j = 1:n_purchases
            purchase = struct();
            purchase.id = j;
            purchase.date = datestr(now - randi(365), 'yyyy-mm-dd');
            purchase.amount = 10 + 90 * rand();
            purchase.items = randi([1, 5]);
            
            purchases(j) = purchase;
        end
        
        customer.purchases = purchases;
        
        % Add to customer list
        customers(i) = customer;
    end
    
    % Create JSON data
    customer_data = struct('customers', customers);
    
    % Write to JSON file
    json_file = 'customer_data.json';
    json_str = jsonencode(customer_data, 'PrettyPrint', true);
    fid = fopen(json_file, 'w');
    fprintf(fid, '%s', json_str);
    fclose(fid);
    
    writeToLog(logFile, ['Created JSON file: ', json_file]);
    
    % Import the JSON file
    json_str = fileread(json_file);
    json_data = jsondecode(json_str);
    
    writeToLog(logFile, ['Imported JSON data with ', num2str(length(json_data.customers)), ' customers']);
    
    % Extract customer information for analysis
    customer_ages = zeros(n_customers, 1);
    total_spent = zeros(n_customers, 1);
    avg_order_value = zeros(n_customers, 1);
    n_orders = zeros(n_customers, 1);
    
    for i = 1:n_customers
        customer = json_data.customers(i);
        customer_ages(i) = customer.age;
        
        n_orders(i) = length(customer.purchases);
        customer_total = 0;
        
        for j = 1:length(customer.purchases)
            customer_total = customer_total + customer.purchases(j).amount;
        end
        
        total_spent(i) = customer_total;
        avg_order_value(i) = customer_total / n_orders(i);
    end
    
    % Analyze customer data
    figure('Name', 'JSON File Data');
    
    % Age distribution
    subplot(2, 2, 1);
    histogram(customer_ages, 10);
    title('Customer Age Distribution');
    xlabel('Age');
    ylabel('Count');
    grid on;
    
    % Total spent by age group
    subplot(2, 2, 2);
    age_bins = [20, 30, 40, 50, 60, 70];
    age_groups = discretize(customer_ages, age_bins);
    spent_by_age = accumarray(age_groups, total_spent, [length(age_bins)-1, 1], @mean);
    
    bar(spent_by_age);
    title('Average Total Spent by Age Group');
    xlabel('Age Group');
    xticklabels(arrayfun(@(i) sprintf('%d-%d', age_bins(i), age_bins(i+1)-1), 1:length(age_bins)-1, 'UniformOutput', false));
    ylabel('Average Spent ($)');
    grid on;
    
    % Orders vs. Average Order Value
    subplot(2, 2, 3);
    scatter(n_orders, avg_order_value, 50, total_spent, 'filled');
    title('Orders vs. Average Order Value');
    xlabel('Number of Orders');
    ylabel('Average Order Value ($)');
    colorbar;
    colormap('jet');
    grid on;
    
    % Distribution of order values
    subplot(2, 2, 4);
    % Extract all order values
    all_order_values = [];
    for i = 1:n_customers
        customer = json_data.customers(i);
        for j = 1:length(customer.purchases)
            all_order_values = [all_order_values; customer.purchases(j).amount];
        end
    end
    
    histogram(all_order_values, 15);
    title('Distribution of Order Values');
    xlabel('Order Value ($)');
    ylabel('Frequency');
    grid on;
    
    % Save the figure
    saveas(gcf, 'json_analysis.png');
    writeToLog(logFile, 'Generated JSON data visualisation');
    
catch e
    writeToLog(logFile, ['ERROR working with files: ', e.message]);
    writeToLog(logFile, 'File import demonstration skipped');
end

%% 1.4 Import from Simulated Hardware/Instruments
% For demonstration, we'll simulate data from hardware devices
% In practice, you would connect to real hardware using appropriate drivers/SDKs

writeToLog(logFile, '1.4 Importing from Simulated Hardware...');

try
    % Simulate a data acquisition system
    writeToLog(logFile, 'Simulating hardware data acquisition...');
    
    % Define simulation parameters
    sample_rate = 1000;  % Hz
    duration = 5;  % seconds
    n_samples = sample_rate * duration;
    time = linspace(0, duration, n_samples)';
    
    % Simulate different signals from multiple channels
    % Channel 1: Sine wave with noise (e.g., from a vibration sensor)
    freq1 = 50;  % Hz
    amplitude1 = 1.0;
    channel1 = amplitude1 * sin(2 * pi * freq1 * time) + 0.1 * randn(size(time));
    
    % Channel 2: Square wave with noise (e.g., from a digital sensor)
    freq2 = 10;  % Hz
    amplitude2 = 0.8;
    channel2 = amplitude2 * square(2 * pi * freq2 * time) + 0.05 * randn(size(time));
    
    % Channel 3: Ramp with noise (e.g., from a temperature sensor)
    channel3 = linspace(0, 1, n_samples)' + 0.02 * randn(n_samples, 1);
    
    % Channel 4: Random pulses (e.g., from a Geiger counter)
    channel4 = zeros(size(time));
    pulse_times = rand(50, 1) * duration;
    pulse_width = 0.01;  % seconds
    
    for i = 1:length(pulse_times)
        pulse_idx = abs(time - pulse_times(i)) < pulse_width;
        channel4(pulse_idx) = 1;
    end
    
    % Combine channels into a data acquisition object
    daq_data = [time, channel1, channel2, channel3, channel4];
    
    writeToLog(logFile, sprintf('Simulated %d samples from 4 channels at %d Hz', n_samples, sample_rate));
    
    % Analyze the hardware data
    figure('Name', 'Hardware Data');
    
    % Plot all channels
    subplot(4, 1, 1);
    plot(time, channel1);
    title('Channel 1: Vibration Sensor');
    xlabel('Time (s)');
    ylabel('Amplitude');
    xlim([0, 0.2]);  % Show only a portion for detail
    grid on;
    
    subplot(4, 1, 2);
    plot(time, channel2);
    title('Channel 2: Digital Sensor');
    xlabel('Time (s)');
    ylabel('State');
    xlim([0, 0.5]);  % Show only a portion for detail
    grid on;
    
    subplot(4, 1, 3);
    plot(time, channel3);
    title('Channel 3: Temperature Sensor');
    xlabel('Time (s)');
    ylabel('Temperature');
    grid on;
    
    subplot(4, 1, 4);
    plot(time, channel4);
    title('Channel 4: Pulse Detector');
    xlabel('Time (s)');
    ylabel('Pulse');
    grid on;
    
    % Save the figure
    saveas(gcf, 'hardware_data.png');
    writeToLog(logFile, 'Generated hardware data visualisation');
    
    % Frequency analysis of vibration data
    figure('Name', 'Hardware Data Frequency Analysis');
    
    % Compute FFT of channel 1
    L = length(channel1);
    Y = fft(channel1);
    P2 = abs(Y/L);
    P1 = P2(1:floor(L/2)+1);
    P1(2:end-1) = 2*P1(2:end-1);
    f = sample_rate*(0:(L/2))/L;
    
    % Plot frequency spectrum
    plot(f, P1);
    title('Frequency Spectrum of Vibration Data');
    xlabel('Frequency (Hz)');
    ylabel('Amplitude');
    xlim([0, 200]);  % Focus on relevant frequency range
    grid on;
    
    % Save the figure
    saveas(gcf, 'hardware_frequency_analysis.png');
    writeToLog(logFile, 'Generated hardware frequency analysis');
    
catch e
    writeToLog(logFile, ['ERROR simulating hardware: ', e.message]);
    writeToLog(logFile, 'Hardware simulation demonstration skipped');
end

%% 2. COMBINED DATA PROCESSING WITH MATLAB
% In this section, we integrate data from multiple sources and perform
% combined analysis that would be difficult to do in any single external tool

writeToLog(logFile, '2. COMBINED DATA PROCESSING');

try
    % 2.1 Create a combined dataset from our various sources
    writeToLog(logFile, 'Creating combined analysis of multiple data sources...');
    
    % Create a figure for integrated analysis
    figure('Name', 'Integrated Multi-Source Analysis', 'Position', [100, 100, 1000, 800]);
    
    % Let's integrate our datasets in a meaningful way
    % For this example, we'll create a simulated business intelligence dashboard
    % that combines:
    % - API data (posts) - customer engagement
    % - DB data (sensors) - operational conditions
    % - File data (sales, financial, customer) - business performance
    % - Hardware data - equipment status
    
    % Generate monthly business metrics for integrated analysis
    months = 1:12;
    
    % Sales trend (from CSV)
    monthly_sales = sum(table2array(csv_data(:, 4:end)));
    
    % Create customer engagement metrics (from API)
    % Generate monthly post counts
    if exist('api_table', 'var') && height(api_table) > 0
        % Use real API data if available
        post_dates = repmat(months, ceil(height(api_table)/12), 1);
        post_dates = post_dates(1:height(api_table));
        monthly_engagement = histcounts(post_dates, 0.5:12.5);
    else
        % Or generate synthetic data
        monthly_engagement = 100 + 50 * sin(2*pi*months/12) + 10 * randn(1, 12);
    end
    
    % Operational status (from DB/sensor data)
    % Average temperature by month (simulated)
    monthly_temp = 20 + 10 * sin(2*pi*(months-6)/12) + 1 * randn(1, 12);
    
    % Financial performance (from Excel)
    % Use revenue growth for latest company
    if exist('revenue_data', 'var') && height(revenue_data) > 0
        financial_perf = table2array(revenue_data(1, 2:end));
        % Extend or truncate to 12 months
        if length(financial_perf) < 12
            financial_perf = [financial_perf, ones(1, 12-length(financial_perf)) * financial_perf(end)];
        elseif length(financial_perf) > 12
            financial_perf = financial_perf(1:12);
        end
    else
        % Or generate synthetic data
        financial_perf = 100 * cumprod(1 + 0.01 * randn(1, 12));
    end
    
    % Equipment status (from hardware)
    % Use FFT peak as equipment health indicator
    if exist('P1', 'var') && exist('f', 'var')
        [peak_value, peak_idx] = max(P1);
        peak_freq = f(peak_idx);
        equipment_health = 0.8 + 0.2 * sin(2*pi*months/12) + 0.05 * randn(1, 12);
    else
        % Or generate synthetic data
        equipment_health = 0.8 + 0.2 * sin(2*pi*months/12) + 0.05 * randn(1, 12);
    end
    
    % Customer satisfaction (from JSON)
    % Use average order value as proxy for satisfaction
    if exist('avg_order_value', 'var') && length(avg_order_value) > 0
        % Map customers to months based on their ID
        customer_months = mod(1:length(avg_order_value), 12) + 1;
        satisfaction_by_month = zeros(1, 12);
        for i = 1:12
            month_customers = customer_months == i;
            if any(month_customers)
                satisfaction_by_month(i) = mean(avg_order_value(month_customers));
            else
                satisfaction_by_month(i) = NaN;
            end
        end
        % Fill any NaN values
        satisfaction_by_month = fillmissing(satisfaction_by_month, 'linear');
    else
        % Or generate synthetic data
        satisfaction_by_month = 60 + 20 * sin(2*pi*months/12) + 5 * randn(1, 12);
    end
    
    % Normalize all metrics to 0-100 scale for comparison
    norm_sales = 100 * (monthly_sales - min(monthly_sales)) / (max(monthly_sales) - min(monthly_sales));
    norm_engagement = 100 * (monthly_engagement - min(monthly_engagement)) / (max(monthly_engagement) - min(monthly_engagement));
    norm_temp = 100 * (1 - (monthly_temp - min(monthly_temp)) / (max(monthly_temp) - min(monthly_temp)));  % Invert temp (lower is better)
    norm_financial = 100 * (financial_perf - min(financial_perf)) / (max(financial_perf) - min(financial_perf));
    norm_equipment = 100 * equipment_health;
    norm_satisfaction = 100 * (satisfaction_by_month - min(satisfaction_by_month)) / (max(satisfaction_by_month) - min(satisfaction_by_month));
    
    % Overall business health score
    business_health = 0.25 * norm_sales + 0.15 * norm_engagement + 0.1 * norm_temp + ...
                      0.2 * norm_financial + 0.1 * norm_equipment + 0.2 * norm_satisfaction;
    
    % Plot the integrated dashboard
    % Main performance metric
    subplot(3, 3, [1, 2, 3]);
    plot(months, business_health, 'b-o', 'LineWidth', 2, 'MarkerSize', 8, 'MarkerFaceColor', 'b');
    hold on;
    
    % Add trend line
    p = polyfit(months, business_health, 1);
    trend = polyval(p, months);
    plot(months, trend, 'r--', 'LineWidth', 1.5);
    
    title('Overall Business Health Index');
    xlabel('Month');
    ylabel('Health Score (0-100)');
    grid on;
    ylim([0, 100]);
    
    % Add annotations
    overall_trend = (trend(end) - trend(1)) / trend(1) * 100;
    if overall_trend > 0
        trend_text = sprintf('Positive Trend: +%.1f%%', overall_trend);
        trend_color = 'g';
    else
        trend_text = sprintf('Negative Trend: %.1f%%', overall_trend);
        trend_color = 'r';
    end
    
    text(months(end), business_health(end), trend_text, 'Color', trend_color, ...
         'FontWeight', 'bold', 'HorizontalAlignment', 'right', 'VerticalAlignment', 'bottom');
    
    % Component metrics
    subplot(3, 3, 4);
    bar(norm_sales);
    title('Sales Performance');
    xlabel('Month');
    ylabel('Score (0-100)');
    ylim([0, 100]);
    grid on;
    
    subplot(3, 3, 5);
    bar(norm_engagement);
    title('Customer Engagement');
    xlabel('Month');
    ylabel('Score (0-100)');
    ylim([0, 100]);
    grid on;
    
    subplot(3, 3, 6);
    bar(norm_temp);
    title('Operational Status');
    xlabel('Month');
    ylabel('Score (0-100)');
    ylim([0, 100]);
    grid on;
    
    subplot(3, 3, 7);
    bar(norm_financial);
    title('Financial Performance');
    xlabel('Month');
    ylabel('Score (0-100)');
    ylim([0, 100]);
    grid on;
    
    subplot(3, 3, 8);
    bar(norm_equipment);
    title('Equipment Health');
    xlabel('Month');
    ylabel('Score (0-100)');
    ylim([0, 100]);
    grid on;
    
    subplot(3, 3, 9);
    bar(norm_satisfaction);
    title('Customer Satisfaction');
    xlabel('Month');
    ylabel('Score (0-100)');
    ylim([0, 100]);
    grid on;
    
    % Save the figure
    saveas(gcf, 'integrated_analysis.png');
    writeToLog(logFile, 'Generated integrated analysis visualisation');
    
    % 2.2 Create a predictive model using combined data
    
    % Create a dataset for prediction
    predictors = [norm_sales', norm_engagement', norm_temp', ...
                 norm_equipment', norm_satisfaction'];
    response = norm_financial';
    
    % Split into training and testing sets
    cv = cvpartition(length(response), 'HoldOut', 0.3);
    X_train = predictors(cv.training, :);
    y_train = response(cv.training);
    X_test = predictors(cv.test, :);
    y_test = response(cv.test);
    
    % Train a regression model
    mdl = fitlm(X_train, y_train);
    
    % Make predictions
    y_pred = predict(mdl, X_test);
    
    % Evaluate model performance
    rmse = sqrt(mean((y_test - y_pred).^2));
    r2 = 1 - sum((y_test - y_pred).^2) / sum((y_test - mean(y_test)).^2);
    
    % Plot model results
    figure('Name', 'Predictive Model Results');
    scatter(y_test, y_pred, 50, 'filled');
    hold on;
    plot([min(y_test), max(y_test)], [min(y_test), max(y_test)], 'r--');
    title(sprintf('Financial Performance Prediction (R? = %.2f, RMSE = %.2f)', r2, rmse));
    xlabel('Actual Performance');
    ylabel('Predicted Performance');
    grid on;
    
    % Add model formula
    coefficients = mdl.Coefficients.Estimate;
    formula_text = 'Financial = ';
    feature_names = {'Sales', 'Engagement', 'Operations', 'Equipment', 'Satisfaction'};
    
    for i = 2:length(coefficients)  % Skip intercept
        sign = '';
        if coefficients(i) > 0 && i > 2
            sign = '+';
        end
        formula_text = [formula_text, sign, sprintf('%.2f--%s ', coefficients(i), feature_names{i-1})];
    end
    
    % Add intercept
    if coefficients(1) > 0
        formula_text = [formula_text, sprintf('+ %.2f', coefficients(1))];
    else
        formula_text = [formula_text, sprintf('- %.2f', abs(coefficients(1)))];
    end
    
    text(min(y_test), max(y_pred), formula_text, 'FontSize', 10, 'VerticalAlignment', 'top');
    
    % Save the figure
    saveas(gcf, 'predictive_model.png');
    writeToLog(logFile, 'Created and evaluated predictive model');
    
catch e
    writeToLog(logFile, ['ERROR in combined data processing: ', e.message]);
    writeToLog(logFile, 'Combined analysis demonstration skipped');
end

%% 3. EXPORT DATA TO EXTERNAL FORMATS AND PLATFORMS
% In this section, we demonstrate how to export MATLAB results to various formats
% and platforms for sharing with stakeholders or integration with other systems

writeToLog(logFile, '3. EXPORT TO EXTERNAL FORMATS AND PLATFORMS');

try
    % 3.1 Export to Excel with formatting
    writeToLog(logFile, '3.1 Exporting to Excel with formatting...');
    
    % Create a comprehensive report worksheet
    export_excel_file = 'integrated_business_report.xlsx';
    
    % Create a table with business health metrics
    business_metrics = table();
    business_metrics.Month = (1:12)';
    business_metrics.Sales = norm_sales';
    business_metrics.Engagement = norm_engagement';
    business_metrics.Operations = norm_temp';
    business_metrics.Financial = norm_financial';
    business_metrics.Equipment = norm_equipment';
    business_metrics.Satisfaction = norm_satisfaction';
    business_metrics.OverallHealth = business_health';
    
    % Write to Excel file
    writetable(business_metrics, export_excel_file, 'Sheet', 'Business Metrics');
    
    % Add model results to a new sheet
    model_results = table();
    model_results.Coefficient = feature_names';
    model_results.Value = coefficients(2:end);
    model_results.PValue = mdl.Coefficients.pValue(2:end);
    model_results.Significant = mdl.Coefficients.pValue(2:end) < 0.05;
    
    model_summary = table();
    model_summary.Metric = {'RSquared'; 'RMSE'; 'Intercept'};
    model_summary.Value = [r2; rmse; coefficients(1)];
    
    writetable(model_results, export_excel_file, 'Sheet', 'Model Results', 'Range', 'A1');
    writetable(model_summary, export_excel_file, 'Sheet', 'Model Results', 'Range', 'E1');
    
    % Add analysis charts as images
    % In a full implementation, you would use Excel automation to add charts
    % For simplicity, we'll just note this in the log
    writeToLog(logFile, ['Created Excel report: ', export_excel_file]);
    writeToLog(logFile, 'Note: In a full implementation, Excel charts would be added');
    
    % 3.2 Export to JSON API (simulated)
    writeToLog(logFile, '3.2 Exporting to JSON API (simulated)...');
    
    % Create a structured data object for API export
    api_export = struct();
    api_export.timestamp = datestr(now, 'yyyy-mm-ddTHH:MM:SS');
    api_export.report_type = 'Business Intelligence Summary';
    api_export.overall_health = mean(business_health);
    api_export.trend = overall_trend;
    
    % Add monthly metrics
    monthly_data = struct();
    for i = 1:12
        month_data = struct();
        month_data.sales = norm_sales(i);
        month_data.engagement = norm_engagement(i);
        month_data.operations = norm_temp(i);
        month_data.financial = norm_financial(i);
        month_data.equipment = norm_equipment(i);
        month_data.satisfaction = norm_satisfaction(i);
        month_data.overall = business_health(i);
        
        monthly_data(i) = month_data;
    end
    
    api_export.monthly_metrics = monthly_data;
    
    % Add model information
    model_data = struct();
    model_data.r_squared = r2;
    model_data.rmse = rmse;
    model_data.coefficients = coefficients(2:end);
    model_data.feature_names = feature_names;
    model_data.intercept = coefficients(1);
    
    api_export.predictive_model = model_data;
    
    % Convert to JSON
    json_export = jsonencode(api_export, 'PrettyPrint', true);
    
    % In a real application, you would send this to an API
    % Here we'll just write it to a file for demonstration
    json_export_file = 'api_export.json';
    fid = fopen(json_export_file, 'w');
    fprintf(fid, '%s', json_export);
    fclose(fid);
    
    writeToLog(logFile, ['Created JSON export file: ', json_export_file]);
    writeToLog(logFile, 'Note: In a real application, this would be sent to an API endpoint');
    
    % 3.3 Create a formatted PDF report
    writeToLog(logFile, '3.3 Creating a PDF report...');
    
    % Create a figure for PDF export
    fig = figure('Name', 'Business Intelligence Report', 'Position', [100, 100, 800, 1000]);
    
    % Add title and header
    annotation('textbox', [0.1, 0.95, 0.8, 0.05], 'String', 'BUSINESS INTELLIGENCE REPORT', ...
               'FontSize', 16, 'FontWeight', 'bold', 'EdgeColor', 'none', ...
               'HorizontalAlignment', 'center');
    
    annotation('textbox', [0.1, 0.92, 0.8, 0.03], 'String', ['Generated: ', datestr(now)], ...
               'FontSize', 10, 'EdgeColor', 'none', ...
               'HorizontalAlignment', 'center');
    
    % Overall health plot
    subplot(3, 1, 1);
    plot(months, business_health, 'b-o', 'LineWidth', 2, 'MarkerSize', 8, 'MarkerFaceColor', 'b');
    hold on;
    plot(months, trend, 'r--', 'LineWidth', 1.5);
    title('Overall Business Health Index');
    xlabel('Month');
    ylabel('Health Score (0-100)');
    grid on;
    ylim([0, 100]);
    
    % Add annotations
    text(months(end), business_health(end), trend_text, 'Color', trend_color, ...
         'FontWeight', 'bold', 'HorizontalAlignment', 'right', 'VerticalAlignment', 'bottom');
    
    % Component metrics as radar chart
    subplot(3, 1, 2);
    % Calculate average metrics
    avg_metrics = [mean(norm_sales), mean(norm_engagement), mean(norm_temp), ...
                  mean(norm_financial), mean(norm_equipment), mean(norm_satisfaction)];
    
    % Create radar chart  
    labels = {'Sales', 'Engagement', 'Operations', 'Financial', 'Equipment', 'Satisfaction'};
    angles = linspace(0, 2*pi, length(labels)+1);
    
    % Close the polygon
    radar_metrics = [avg_metrics, avg_metrics(1)];
    
    polarplot(angles, radar_metrics, 'r-', 'LineWidth', 2, 'MarkerFaceColor', 'r');
    hold on;
    
    % Add reference circles
    for r = [25, 50, 75]
        polarplot(angles, r*ones(size(angles)), 'k:', 'LineWidth', 0.5);
    end
    
    title('Average Component Performance');
    thetaticks(rad2deg(angles(1:end-1)));
    thetaticklabels(labels);
    rticks([25, 50, 75, 100]);
    rlim([0, 100]);
    
    % Predictive model results
    subplot(3, 1, 3);
    
    % Model summary as a table
    uitable('Data', [model_results.Value, model_results.PValue, model_results.Significant], ...
            'RowName', model_results.Coefficient, ...
            'ColumnName', {'Coefficient', 'P-Value', 'Significant'}, ...
            'Units', 'normalized', ...
            'Position', [0.1, 0.05, 0.8, 0.25]);
    
    annotation('textbox', [0.1, 0.31, 0.8, 0.03], 'String', ...
               sprintf('Model Performance: R? = %.2f, RMSE = %.2f', r2, rmse), ...
               'FontSize', 10, 'EdgeColor', 'none', ...
               'HorizontalAlignment', 'center');
    
    title('Predictive Model Results');
    axis off;
    
    % Export as PDF
    pdf_file = 'business_intelligence_report.pdf';
    exportgraphics(fig, pdf_file, 'Resolution', 300);
    
    writeToLog(logFile, ['Created PDF report: ', pdf_file]);
    
    % 3.4 Create CSV files for database import
    writeToLog(logFile, '3.4 Creating CSV files for database import...');
    
    % Monthly metrics for database import
    db_export = business_metrics;
    
    % Add a proper date field
    start_date = datetime(2023, 1, 1);
    dates = start_date + calmonths(0:11);
    db_export.Date = dates';
    
    % Export to CSV
    db_export_file = 'monthly_metrics_for_db.csv';
    writetable(db_export, db_export_file);
    
    writeToLog(logFile, ['Created CSV file for database import: ', db_export_file]);
    
    % 3.5 Export to HTML with embedded JavaScript visualisation
    writeToLog(logFile, '3.5 Creating HTML report with embedded visualisation...');
    
    % Create an HTML file with embedded JavaScript visualisation
    html_file = 'business_report.html';
    
    % Convert data to JavaScript arrays
    months_js = sprintf('%s', mat2str(months));
    health_js = sprintf('%s', mat2str(business_health));
    sales_js = sprintf('%s', mat2str(norm_sales));
    engagement_js = sprintf('%s', mat2str(norm_engagement));
    financial_js = sprintf('%s', mat2str(norm_financial));
    
    % Create HTML content with embedded Chart.js visualisation
    html_content = [
        '<!DOCTYPE html>\n'
        '<html>\n'
        '<head>\n'
        '    <title>Business Intelligence Dashboard</title>\n'
        '    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>\n'
        '    <style>\n'
        '        body { font-family: Arial, sans-serif; margin: 20px; }\n'
        '        .chart-container { width: 80%; margin: 20px auto; }\n'
        '        h1, h2 { text-align: center; }\n'
        '        .summary { width: 80%; margin: 20px auto; padding: 10px; background-color: #f8f9fa; border-radius: 5px; }\n'
        '    </style>\n'
        '</head>\n'
        '<body>\n'
        '    <h1>Business Intelligence Dashboard</h1>\n'
        '    <p class="summary">This report provides an overview of key business metrics and performance indicators.</p>\n'
        '    \n'
        '    <div class="chart-container">\n'
        '        <canvas id="overallChart"></canvas>\n'
        '    </div>\n'
        '    \n'
        '    <div class="chart-container">\n'
        '        <canvas id="componentsChart"></canvas>\n'
        '    </div>\n'
        '    \n'
        '    <script>\n'
        '        // Data from MATLAB\n'
        '        const months = ' months_js ';\n'
        '        const healthData = ' health_js ';\n'
        '        const salesData = ' sales_js ';\n'
        '        const engagementData = ' engagement_js ';\n'
        '        const financialData = ' financial_js ';\n'
        '        \n'
        '        // Create overall health chart\n'
        '        const ctxOverall = document.getElementById(''overallChart'').getContext(''2d'');\n'
        '        const overallChart = new Chart(ctxOverall, {\n'
        '            type: ''line'',\n'
        '            data: {\n'
        '                labels: months,\n'
        '                datasets: [{\n'
        '                    label: ''Overall Business Health'',\n'
        '                    data: healthData,\n'
        '                    borderColor: ''blue'',\n'
        '                    backgroundColor: ''rgba(0, 0, 255, 0.1)'',\n'
        '                    fill: true,\n'
        '                    tension: 0.1\n'
        '                }]\n'
        '            },\n'
        '            options: {\n'
        '                responsive: true,\n'
        '                plugins: {\n'
        '                    title: {\n'
        '                        display: true,\n'
        '                        text: ''Overall Business Health Index'',\n'
        '                        font: { size: 16 }\n'
        '                    },\n'
        '                },\n'
        '                scales: {\n'
        '                    y: {\n'
        '                        min: 0,\n'
        '                        max: 100,\n'
        '                        title: {\n'
        '                            display: true,\n'
        '                            text: ''Health Score''\n'
        '                        }\n'
        '                    },\n'
        '                    x: {\n'
        '                        title: {\n'
        '                            display: true,\n'
        '                            text: ''Month''\n'
        '                        }\n'
        '                    }\n'
        '                }\n'
        '            }\n'
        '        });\n'
        '        \n'
        '        // Create component metrics chart\n'
        '        const ctxComponents = document.getElementById(''componentsChart'').getContext(''2d'');\n'
        '        const componentsChart = new Chart(ctxComponents, {\n'
        '            type: ''bar'',\n'
        '            data: {\n'
        '                labels: months,\n'
        '                datasets: [{\n'
        '                    label: ''Sales'',\n'
        '                    data: salesData,\n'
        '                    backgroundColor: ''rgba(255, 99, 132, 0.5)'',\n'
        '                }, {\n'
        '                    label: ''Engagement'',\n'
        '                    data: engagementData,\n'
        '                    backgroundColor: ''rgba(54, 162, 235, 0.5)'',\n'
        '                }, {\n'
        '                    label: ''Financial'',\n'
        '                    data: financialData,\n'
        '                    backgroundColor: ''rgba(75, 192, 192, 0.5)'',\n'
        '                }]\n'
        '            },\n'
        '            options: {\n'
        '                responsive: true,\n'
        '                plugins: {\n'
        '                    title: {\n'
        '                        display: true,\n'
        '                        text: ''Component Metrics'',\n'
        '                        font: { size: 16 }\n'
        '                    },\n'
        '                },\n'
        '                scales: {\n'
        '                    y: {\n'
        '                        min: 0,\n'
        '                        max: 100,\n'
        '                        title: {\n'
        '                            display: true,\n'
        '                            text: ''Score''\n'
        '                        }\n'
        '                    },\n'
        '                    x: {\n'
        '                        title: {\n'
        '                            display: true,\n'
        '                            text: ''Month''\n'
        '                        }\n'
        '                    }\n'
        '                }\n'
        '            }\n'
        '        });\n'
        '    </script>\n'
        '</body>\n'
        '</html>\n'
    ];
    
    % Write HTML to file
    fid = fopen(html_file, 'w');
    fprintf(fid, '%s', html_content);
    fclose(fid);
    
    writeToLog(logFile, ['Created HTML report with embedded visualisation: ', html_file]);
    
catch e
    writeToLog(logFile, ['ERROR exporting data: ', e.message]);
    writeToLog(logFile, 'Export demonstration skipped');
end

%% 4. WORKFLOW AUTOMATION
% In this section, we demonstrate how to automate the entire workflow
% for regular execution

writeToLog(logFile, '4. WORKFLOW AUTOMATION');

try
    % 4.1 Create a batch file to run this script automatically
    writeToLog(logFile, '4.1 Creating batch file for automated execution...');
    
    bat_file = 'run_matlab_integration.bat';
    
    % Get current MATLAB file path
    current_file = mfilename('fullpath');
    
    % Create batch file content
    bat_content = [
        '@echo off\n'
        'echo Running MATLAB Integration Workflow\n'
        'echo Started at %date% %time%\n'
        '\n'
        'REM Change to the working directory\n'
        'cd ' pwd '\n'
        '\n'
        'REM Run MATLAB script without GUI\n'
        'matlab -nosplash -nodesktop -r "try; run(''' mfilename '''); catch e; disp(getReport(e)); end; exit;"\n'
        '\n'
        'echo Completed at %date% %time%\n'
        'echo See integration_workflow_log.txt for details\n'
    ];
    
    % Write batch file
    fid = fopen(bat_file, 'w');
    fprintf(fid, '%s', bat_content);
    fclose(fid);
    
    writeToLog(logFile, ['Created batch file for automated execution: ', bat_file]);
    
    % 4.2 Create a scheduled task script
    writeToLog(logFile, '4.2 Creating scheduled task script...');
    
    % For Windows, we can create a PowerShell script to set up a scheduled task
    ps_file = 'schedule_integration_task.ps1';
    
    ps_content = [
        '# PowerShell script to create a scheduled task for the MATLAB integration workflow\n'
        '\n'
        '$taskName = "MATLAB_Integration_Workflow"\n'
        '$taskDescription = "Run MATLAB integration workflow daily to process data from multiple sources"\n'
        '$workingDir = "' pwd '"\n'
        '$scriptPath = "$workingDir\run_matlab_integration.bat"\n'
        '\n'
        '# Create a new scheduled task action\n'
        '$action = New-ScheduledTaskAction -Execute $scriptPath -WorkingDirectory $workingDir\n'
        '\n'
        '# Create a trigger (daily at 2 AM)\n'
        '$trigger = New-ScheduledTaskTrigger -Daily -At 2am\n'
        '\n'
        '# Set up principal (run whether user is logged on or not)\n'
        '$principal = New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" -LogonType S4U -RunLevel Highest\n'
        '\n'
        '# Set up settings\n'
        '$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -DontStopOnIdleEnd -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries\n'
        '\n'
        '# Register the task\n'
        'Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Description $taskDescription -Force\n'
        '\n'
        'Write-Host "Scheduled task created: $taskName"\n'
    ];
    
    % Write PowerShell script
    fid = fopen(ps_file, 'w');
    fprintf(fid, '%s', ps_content);
    fclose(fid);
    
    writeToLog(logFile, ['Created PowerShell script for scheduled task: ', ps_file]);
    writeToLog(logFile, 'Note: Run this script with administrator privileges to create the task');
    
    % 4.3 Design a centralized data management system
    % In a real application, you would implement a database schema, ETL processes, etc.
    % Here we'll just create a conceptual diagram of how this would work
    
    figure('Name', 'Automated Workflow System Architecture', 'Position', [150, 150, 800, 600]);
    
    % Create a simple architecture diagram
    hold on;
    
    % External data sources
    rectangle('Position', [100, 500, 150, 60], 'Curvature', [0.2, 0.2], ...
              'FaceColor', [0.8, 0.9, 1], 'EdgeColor', 'b');
    text(175, 530, 'Web APIs', 'HorizontalAlignment', 'center', 'FontWeight', 'bold');
    
    rectangle('Position', [300, 500, 150, 60], 'Curvature', [0.2, 0.2], ...
              'FaceColor', [0.8, 0.9, 1], 'EdgeColor', 'b');
    text(375, 530, 'Databases', 'HorizontalAlignment', 'center', 'FontWeight', 'bold');
    
    rectangle('Position', [500, 500, 150, 60], 'Curvature', [0.2, 0.2], ...
              'FaceColor', [0.8, 0.9, 1], 'EdgeColor', 'b');
    text(575, 530, 'Files', 'HorizontalAlignment', 'center', 'FontWeight', 'bold');
    
    rectangle('Position', [100, 400, 550, 60], 'Curvature', [0.2, 0.2], ...
              'FaceColor', [1, 0.9, 0.8], 'EdgeColor', 'r');
    text(375, 430, 'Data Import & ETL Layer', 'HorizontalAlignment', 'center', 'FontWeight', 'bold');
    
    % MATLAB processing
    rectangle('Position', [200, 300, 350, 60], 'Curvature', [0.2, 0.2], ...
              'FaceColor', [0.8, 1, 0.8], 'EdgeColor', 'g');
    text(375, 330, 'MATLAB Analytics & Processing', 'HorizontalAlignment', 'center', 'FontWeight', 'bold');
    
    % Export layer
    rectangle('Position', [100, 200, 550, 60], 'Curvature', [0.2, 0.2], ...
              'FaceColor', [0.9, 0.8, 1], 'EdgeColor', 'm');
    text(375, 230, 'Export & Reporting Layer', 'HorizontalAlignment', 'center', 'FontWeight', 'bold');
    
    % Output destinations
    rectangle('Position', [100, 100, 150, 60], 'Curvature', [0.2, 0.2], ...
              'FaceColor', [1, 1, 0.8], 'EdgeColor', 'y');
    text(175, 130, 'Dashboards', 'HorizontalAlignment', 'center', 'FontWeight', 'bold');
    
    rectangle('Position', [300, 100, 150, 60], 'Curvature', [0.2, 0.2], ...
              'FaceColor', [1, 1, 0.8], 'EdgeColor', 'y');
    text(375, 130, 'Reports', 'HorizontalAlignment', 'center', 'FontWeight', 'bold');
    
    rectangle('Position', [500, 100, 150, 60], 'Curvature', [0.2, 0.2], ...
              'FaceColor', [1, 1, 0.8], 'EdgeColor', 'y');
    text(575, 130, 'External Systems', 'HorizontalAlignment', 'center', 'FontWeight', 'bold');
    
    % Automation controller
    rectangle('Position', [600, 300, 100, 200], 'Curvature', [0.2, 0.2], ...
              'FaceColor', [0.9, 0.9, 0.9], 'EdgeColor', 'k');
    text(650, 400, {'Automation', 'Controller'}, 'HorizontalAlignment', 'center', 'FontWeight', 'bold');
    
    % Add flow arrows
    arrow([175, 500], [375, 400]);
    arrow([375, 500], [375, 400]);
    arrow([575, 500], [375, 400]);
    
    arrow([375, 400], [375, 300]);
    
    arrow([375, 300], [375, 200]);
    
    arrow([175, 200], [175, 100]);
    arrow([375, 200], [375, 100]);
    arrow([575, 200], [575, 100]);
    
    % Automation controller arrows
    arrow([650, 300], [450, 230]);
    arrow([650, 500], [450, 430]);
    
    % Add title
    title('Automated MATLAB Integration Workflow Architecture', 'FontSize', 14);
    
    % Set axis properties
    axis equal;
    axis([50, 750, 50, 580]);
    axis off;
    
    % Add annotations
    annotation('textbox', [0.1, 0.02, 0.8, 0.05], 'String', ...
               ['This architecture enables automated data collection, processing, analysis, and reporting across multiple systems. ' ...
                'The MATLAB integration workflow serves as the central analytics engine, handling data from diverse sources and ' ...
                'generating insights for multiple stakeholders.'], ...
               'EdgeColor', 'none', 'HorizontalAlignment', 'center');
    
    % Save the figure
    saveas(gcf, 'workflow_architecture.png');
    writeToLog(logFile, 'Created workflow architecture diagram');
    
catch e
    writeToLog(logFile, ['ERROR setting up automation: ', e.message]);
    writeToLog(logFile, 'Automation demonstration skipped');
end

%% 5. MULTIDISCIPLINARY APPLICATIONS
% In this section, we discuss the relevance of MATLAB integration capabilities
% to multidisciplinary applications

writeToLog(logFile, '5. MULTIDISCIPLINARY APPLICATIONS');

% Create a figure showcasing multidisciplinary applications
figure('Name', 'MATLAB Integration: Multidisciplinary Applications', 'Position', [200, 200, 1000, 600]);

% Create a grid layout for different disciplines
disciplines = {
    'Engineering', 'Data Science & AI', 'Finance', 'Healthcare', 'Environmental Science'
};

% External tools relevant to each discipline
external_tools = {
    {'CAD Software', 'PLM Systems', 'IoT Platforms', 'Simulation Tools', 'Hardware Systems'}, ...
    {'Python/R', 'Big Data Platforms', 'Cloud ML Services', 'visualisation Tools', 'Data Lakes'}, ...
    {'Trading Systems', 'ERP Software', 'Financial Databases', 'Risk Platforms', 'Regulatory Systems'}, ...
    {'Medical Devices', 'EMR Systems', 'Imaging Systems', 'Patient Monitors', 'Diagnostic Tools'}, ...
    {'GIS Systems', 'Sensor Networks', 'Climate Models', 'Remote Sensing', 'Monitoring Systems'}
};

% MATLAB's role in integration
matlab_roles = {
    {'Signal Processing', 'Control Systems', 'Modeling & Simulation', 'Test & Measurement', 'Digital Twins'}, ...
    {'Algorithm Development', 'Data Mining', 'Machine Learning', 'Image Processing', 'Statistical Analysis'}, ...
    {'Risk Modeling', 'Portfolio Optimization', 'Time Series Analysis', 'Trading Algorithms', 'Economic Modeling'}, ...
    {'Medical Image Analysis', 'Biomedical Signal Processing', 'Diagnostic Algorithms', 'Clinical Decision Support', 'Genomic Analysis'}, ...
    {'Environmental Modeling', 'Climate Data Analysis', 'Ecosystem Simulation', 'Resource Optimization', 'Impact Assessment'}
};

% Use subplots in a grid layout
for i = 1:length(disciplines)
    subplot(3, 5, i);
    text(0.5, 0.9, disciplines{i}, 'FontWeight', 'bold', 'HorizontalAlignment', 'center');
    axis off;
    
    subplot(3, 5, i+5);
    text(0.5, 0.9, 'External Tools:', 'FontWeight', 'bold', 'HorizontalAlignment', 'center');
    for j = 1:length(external_tools{i})
        text(0.5, 0.9-j*0.15, external_tools{i}{j}, 'HorizontalAlignment', 'center', 'FontSize', 8);
    end
    axis off;
    
    subplot(3, 5, i+10);
    text(0.5, 0.9, 'MATLAB Functions:', 'FontWeight', 'bold', 'HorizontalAlignment', 'center');
    for j = 1:length(matlab_roles{i})
        text(0.5, 0.9-j*0.15, matlab_roles{i}{j}, 'HorizontalAlignment', 'center', 'FontSize', 8);
    end
    axis off;
end

% Add central integration diagram
subplot(3, 5, [3, 8, 13]);
hold on;

% Draw MATLAB hub
rectangle('Position', [0.4, 0.4, 0.2, 0.2], 'Curvature', [1, 1], ...
          'FaceColor', [0.8, 0.8, 1], 'EdgeColor', 'b', 'LineWidth', 2);
text(0.5, 0.5, 'MATLAB', 'HorizontalAlignment', 'center', 'FontWeight', 'bold');

% Draw connection points around the circle
n_connections = 12;
angles = linspace(0, 2*pi, n_connections+1);
angles = angles(1:end-1);
radius = 0.35;

conn_x = 0.5 + radius * cos(angles);
conn_y = 0.5 + radius * sin(angles);

% System names
systems = {'Web APIs', 'Databases', 'Excel', 'Python', 'Hardware', 'CAD', ...
          'GIS', 'AI Services', 'Data Lakes', 'Reports', 'Dashboards', 'Models'};

% Draw connections and labels
for i = 1:n_connections
    % Draw connection point
    plot(conn_x(i), conn_y(i), 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r');
    
    % Draw line to center
    plot([0.5, conn_x(i)], [0.5, conn_y(i)], 'k-', 'LineWidth', 1);
    
    % Add label
    label_x = 0.5 + 1.2 * radius * cos(angles(i));
    label_y = 0.5 + 1.2 * radius * sin(angles(i));
    text(label_x, label_y, systems{i}, 'HorizontalAlignment', 'center', ...
         'FontSize', 8, 'FontWeight', 'bold');
end

axis equal;
axis off;

% Add title
annotation('textbox', [0.1, 0.95, 0.8, 0.05], 'String', 'MATLAB Integration Across Disciplines', ...
           'FontSize', 16, 'FontWeight', 'bold', 'EdgeColor', 'none', ...
           'HorizontalAlignment', 'center');

% Add explanation
annotation('textbox', [0.1, 0.02, 0.8, 0.08], 'String', ...
           ['MATLAB serves as a central integration hub for multidisciplinary applications, connecting ' ...
            'domain-specific tools and platforms while providing advanced analytics capabilities. ' ...
            'This integration enables specialists from different fields to collaborate effectively ' ...
            'and tackle complex problems that span traditional disciplinary boundaries.'], ...
           'EdgeColor', 'none', 'HorizontalAlignment', 'center');

% Save the figure
saveas(gcf, 'multidisciplinary_applications.png');
writeToLog(logFile, 'Created multidisciplinary applications diagram');

%% 6. CONCLUSION
% Conclude the workflow and summarize results

writeToLog(logFile, '6. CONCLUSION');
writeToLog(logFile, 'MATLAB Integration workflow completed successfully.');
writeToLog(logFile, ['Execution Time: ', datestr(now)]);
writeToLog(logFile, '--------------');

%% Clean up temporary files (optional)
% In a real application, you might want to keep these files
% Here we'll provide an option to clean up for demonstration purposes

% Uncomment these lines to clean up temporary files
% delete('temp_database.db');
% delete('sales_data.csv');
% delete('financial_data.xlsx');
% delete('customer_data.json');

%% Helper Functions

% Function to write to the log file
function writeToLog(logFile, message)
    % Get current timestamp
    timestamp = datestr(now, 'yyyy-mm-dd HH:MM:SS');
    
    % Open log file in append mode
    fid = fopen(logFile, 'a');
    
    % Write the timestamped message
    fprintf(fid, '[%s] %s\n', timestamp, message);
    
    % Close the file
    fclose(fid);
    
    % Also display to MATLAB console
    fprintf('[%s] %s\n', timestamp, message);
end

% Function to draw an arrow between two points
function arrow(p1, p2)
    % Draw a line with an arrow from p1 to p2
    
    % Line
    plot([p1(1), p2(1)], [p1(2), p2(2)], 'k-', 'LineWidth', 1.5);
    
    % Calculate arrow head
    len = 10;  % Arrow head length
    angle = atan2(p2(2) - p1(2), p2(1) - p1(1));
    
    % Arrow head points
    x1 = p2(1) - len * cos(angle - pi/6);
    y1 = p2(2) - len * sin(angle - pi/6);
    x2 = p2(1) - len * cos(angle + pi/6);
    y2 = p2(2) - len * sin(angle + pi/6);
    
    % Draw arrow head
    fill([p2(1), x1, x2], [p2(2), y1, y2], 'k');
end
