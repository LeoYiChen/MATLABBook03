%% chapter_AI_CV_problem10_counterfactual.m
% Counterfactual generation syntax.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AI_CV_problem10_counterfactual
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Generate counterfactual explanation
[counterfactual, perturbation] = generateCounterfactual(model, originalImage, ...
                                    targetClass, optimizationParams);

% Evaluate counterfactual quality
quality = evaluateCounterfactual(originalImage, counterfactual, model);
