%% chapter_AILMI_prob8_mfcc.m
% MFCC feature extraction with SpecAugment.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AILMI_prob8_mfcc
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [features, augmented] = extractMFCC(audioSignal, sampleRate, doAugment)
    % Extract MFCC features from audio signal
    % audioSignal: [numSamples x 1] time-domain waveform
    % sampleRate: typically 16000 Hz
    % doAugment: boolean for SpecAugment application
    
    % Parameters
    windowLength = round(0.025 * sampleRate); % 25ms window
    hopLength = round(0.010 * sampleRate);     % 10ms hop
    numCoeffs = 40;
    
    % Pre-emphasis filter (high-pass)
    preEmphasis = 0.97;
    emphasized = filter([1, -preEmphasis], 1, audioSignal);
    
    % Frame the signal
    numFrames = floor((length(emphasized) - windowLength) / hopLength) + 1;
    frames = zeros(numFrames, windowLength);
    for i = 1:numFrames
        startIdx = (i-1) * hopLength + 1;
        frames(i, :) = emphasized(startIdx : startIdx + windowLength - 1);
    end
    
    % Apply Hamming window
    hammingWin = hamming(windowLength);
    frames = frames .* hammingWin';
    
    % FFT and power spectrum
    nfft = 2^nextpow2(windowLength);
    powerSpectrum = abs(fft(frames', nfft)).^2;
    powerSpectrum = powerSpectrum(1:nfft/2+1, :)';
    
    % Mel filterbank
    numFilters = 40;
    melFilterbank = createMelFilterbank(numFilters, nfft, sampleRate);
    melSpectrum = powerSpectrum * melFilterbank';
    
    % Log and DCT to get MFCCs
    logMel = log(melSpectrum + eps);
    features = dct(logMel')';
    features = features(:, 1:numCoeffs);
    
    % SpecAugment (if augmenting)
    augmented = features;
    if doAugment
        % Time masking: Zero out random time frames
        numTimeMasks = 2;
        maxMaskLength = 10;
        for m = 1:numTimeMasks
            maskLen = randi([1, maxMaskLength]);
            maskStart = randi([1, size(features, 1) - maskLen]);
            augmented(maskStart:maskStart+maskLen-1, :) = 0;
        end
        
        % Frequency masking: Zero out random frequency channels
        numFreqMasks = 2;
        maxFreqMask = 8;
        for m = 1:numFreqMasks
            maskLen = randi([1, maxFreqMask]);
            maskStart = randi([1, numCoeffs - maskLen]);
            augmented(:, maskStart:maskStart+maskLen-1) = 0;
        end
    end
    
    % Normalisation (mean=0, std=1)
    augmented = (augmented - mean(augmented(:))) / std(augmented(:));
end

function melFilters = createMelFilterbank(numFilters, nfft, sampleRate)
    % Create triangular mel-spaced filterbank
    lowFreqMel = 0;
    highFreqMel = 2595 * log10(1 + (sampleRate/2) / 700); % Hz to Mel
    
    melPoints = linspace(lowFreqMel, highFreqMel, numFilters + 2);
    hzPoints = 700 * (10.^(melPoints / 2595) - 1); % Mel to Hz
    
    bin = floor((nfft + 1) * hzPoints / sampleRate);
    
    melFilters = zeros(numFilters, nfft/2 + 1);
    for m = 2:numFilters+1
        % Left slope
        for k = bin(m-1):bin(m)
            melFilters(m-1, k) = (k - bin(m-1)) / (bin(m) - bin(m-1));
        end
        % Right slope
        for k = bin(m):bin(m+1)
            melFilters(m-1, k) = (bin(m+1) - k) / (bin(m+1) - bin(m));
        end
    end
end
