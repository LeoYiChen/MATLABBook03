%% chapter_AICE_syntax_P01.m
% Timetable synchronisation syntax.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AICE_syntax_P01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
sensorTable = timetable(sensorTimes, sensorValues);
modelTable  = timetable(modelTimes, modelValues);
alignedData = synchronize(sensorTable, modelTable, ...
    "regular", "linear", "TimeStep", minutes(30));
% - Computational Complexity -
% synchronize sorts both input series at O(m log m + p log p)
% then performs O(q) linear interpolation onto q output steps.
% For typical structural-monitoring cadences this completes in
% well under one second for a full year of data.
