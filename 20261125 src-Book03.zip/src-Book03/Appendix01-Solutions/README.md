# Appendix01-Solutions - Supplementary MATLAB Source Code

| Field | Value |
| --- | --- |
| Book | MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications |
| Chapter | Solutions To Problems |
| Package version | 1.0.1 |
| Release stamp | 2026-11-10 |
| Source manuscript | `P03-20261111` |
| Source chapter file | `P0302main/Appendix01-Solutions/` (included by `P03_20261005.tex`) |
| Code files | 240 (240 `.m`, 0 `.f`) |
| Code lines relocated | 51,208 |

## Why this folder exists

The editor reported that a large volume of programming code was present in the
manuscript and requested that it be moved to a professional repository with the
links supplied as supplementary material. The printed book is subject to a
length target below 1100 pages and to the Springer hard-copy limit of fewer
than 950 print pages. Accordingly, every `lstlisting` (and every MATLAB
`verbatim`) environment in the chapter has been removed from the main body and
deposited here. Only the filename, the listing caption and a reference to this
folder remain in the printed text.

## Naming convention

A file is named after the `label` of the listing it came from:

```latex
\begin{lstlisting}[..., caption={Basic matrix operations ...},
                     label={chapter_Introduction_example_01}]
```

is saved as `chapter_Introduction_example_01.m`.

- Listings without a `label` receive a generated name `Appendix01-Solutions_code_NNN.m`.
- Code held in a `verbatim` environment receives `Appendix01-Solutions_verbatim_NN.m`
  (or `.f` for the single illustrative Fortran 77 block).
- Where two listings shared the same label, the later file carries a numeric
  suffix (`_02`, `_03`, ...) so nothing is overwritten. This is recorded in
  the table below.

Each file begins with a header comment giving the caption, the original label,
this folder, the version stamp and the public repository URL.

## Finding a file from the book

The main text now shows a one-line note of the form:

> **Source code 3.4:** `chapter_ICT_example_01.m` - *caption*
> (supplementary material: `src-Book03/Appendix01-Solutions/`)

The original listing numbers and all `\ref{...}` cross-references are
unchanged, so the in-text reference maps directly to a filename.

## Repository

```
https://github.com/LeoYiChen/MATLABBook03
```

Clone or download `src-Book03/` from this public repository, or use the
Springer supplementary archive. The same address is printed in the preface of
the book. Keep the `src-Book03/` folder name so that the in-text
`src-Book03/Appendix01-Solutions/` paths resolve.

## Companion documents

- `VERSION.md` - version, release stamp and release notes
- `USER-GUIDE.md` - how to download, locate and run the code
- `MANIFEST.sha256` - SHA-256 ledger of every file in this folder

## Files

| Filename | Source listing label | Caption |
| --- | --- | --- |
| `Appendix01-Solutions_code_073.m` | `(generated)` | MATLAB source code for this example. |
| `Appendix01-Solutions_code_074.m` | `(generated)` | MATLAB source code for this example. |
| `Appendix01-Solutions_code_075.m` | `(generated)` | MATLAB source code for this example. |
| `Appendix01-Solutions_code_076.m` | `(generated)` | MATLAB source code for this example. |
| `Appendix01-Solutions_code_077.m` | `(generated)` | MATLAB source code for this example. |
| `Appendix01-Solutions_code_078.m` | `(generated)` | MATLAB source code for this example. |
| `Appendix01-Solutions_code_079.m` | `(generated)` | MATLAB source code for this example. |
| `chapter_AE_Problems_P10_LunarCaveExploration.m` | `chapter_AE_Problems_P10_LunarCaveExploration` | Lunar cave exploration and habitat assessment system. |
| `chapter_AE_Problems_P11_MagneticReconnection.m` | `chapter_AE_Problems_P11_MagneticReconnection` | Magnetic reconnection spacecraft propulsion system. |
| `chapter_AE_Problems_P12_ElectrosprayLifetime.m` | `chapter_AE_Problems_P12_ElectrosprayLifetime` | Electrospray thruster lifetime and reliability analysis system. |
| `chapter_AE_Problems_P13_ChinaSpacePlan.m` | `chapter_AE_Problems_P13_ChinaSpacePlan` | China Space Science Development Plan implementation framework. |
| `chapter_AE_Problems_P14_PeregrineBiomimetic.m` | `chapter_AE_Problems_P14_PeregrineBiomimetic` | Peregrine falcon biomimetic design for B-2 enhancement system. |
| `chapter_AE_Problems_P15_IntegratedFirefighting.m` | `chapter_AE_Problems_P15_IntegratedFirefighting` | Integrated autonomous aerial firefighting system. |
| `chapter_AE_Problems_P16_MultiUAVCoordination.m` | `chapter_AE_Problems_P16_MultiUAVCoordination` | Multi-UAV distributed Kalman filtering coordination system. |
| `chapter_AE_Problems_P17_MarsLanding.m` | `chapter_AE_Problems_P17_MarsLanding` | Autonomous Mars landing navigation system. |
| `chapter_AE_Problems_P18_SpaceTimeCrystal.m` | `chapter_AE_Problems_P18_SpaceTimeCrystal` | Space-time crystal communication system design. |
| `chapter_AE_Problems_P19_HypersonicNavigation.m` | `chapter_AE_Problems_P19_HypersonicNavigation` | Advanced sensor fusion for hypersonic vehicle navigation. |
| `chapter_AE_Problems_P1_EKF.m` | `chapter_AE_Problems_P1_EKF` | Extended Kalman Filter for spacecraft docking navigation. |
| `chapter_AE_Problems_P2_RRTStar.m` | `chapter_AE_Problems_P2_RRTStar` | RRT* algorithm for UAV navigation with dynamic obstacles. |
| `chapter_AE_Problems_P3_AtmosphericGP.m` | `chapter_AE_Problems_P3_AtmosphericGP` | Gaussian Process for atmospheric density prediction. |
| `chapter_AE_Problems_P4_EvacuationModel.m` | `chapter_AE_Problems_P4_EvacuationModel` | Social force model for launch facility evacuation. |
| `chapter_AE_Problems_P5_DebrisRadar.m` | `chapter_AE_Problems_P5_DebrisRadar` | Matched filter for space debris radar detection. |
| `chapter_AE_Problems_P6_BlackHoleImaging.m` | `chapter_AE_Problems_P6_BlackHoleImaging` | AI-enhanced black hole image reconstruction system. |
| `chapter_AE_Problems_P7_FutureAstroAI.m` | `chapter_AE_Problems_P7_FutureAstroAI` | Future AI system for autonomous astronomical discovery. |
| `chapter_AE_Problems_P8_ElectricActuator.m` | `chapter_AE_Problems_P8_ElectricActuator` | Advanced electric actuator system with adaptive control. |
| `chapter_AE_Problems_P9_FuelSystemAI.m` | `chapter_AE_Problems_P9_FuelSystemAI` | AI-based fuel system design optimization framework. |
| `chapter_AICE_code_P01.m` | `chapter_AICE_code_P01` | Solution~1: timetable synchronisation and residual anomaly detection (MATLABBook02_Chapter13_section8_Problem01.m). |
| `chapter_AICE_code_P02.m` | `chapter_AICE_code_P02` | Solution~2: upgrading a digital shadow to a digital twin (MATLABBook02_Chapter13_section8_Problem02.m). |
| `chapter_AICE_code_P03.m` | `chapter_AICE_code_P03` | Solution~3: IFC spatial containment hierarchy and graph queries (MATLABBook02_Chapter13_section8_Problem03.m). |
| `chapter_AICE_code_P04.m` | `chapter_AICE_code_P04` | Solution~4: BIM service dependency and maintenance impact analysis (MATLABBook02_Chapter13_section8_Problem04.m). |
| `chapter_AICE_code_P05.m` | `chapter_AICE_code_P05` | Solution~5: building energy load forecasting with a regression tree ensemble (MATLABBook02_Chapter13_section8_Problem05.m). |
| `chapter_AICE_code_P06.m` | `chapter_AICE_code_P06` | Solution~6: indoor air quality monitoring and ventilation fault detection (MATLABBook02_Chapter13_section8_Problem06.m). |
| `chapter_AICE_code_P07.m` | `chapter_AICE_code_P07` | Solution~7: specification clause retrieval using TF-IDF (MATLABBook02_Chapter13_section8_Problem07.m). |
| `chapter_AICE_code_P08.m` | `chapter_AICE_code_P08` | Solution~8: evaluating retrieval quality for a RAG pipeline (MATLABBook02_Chapter13_section8_Problem08.m). |
| `chapter_AICE_code_P09.m` | `chapter_AICE_code_P09` | Solution~9: urban network link criticality ranking (MATLABBook02_Chapter13_section8_Problem09.m). |
| `chapter_AICE_code_P10.m` | `chapter_AICE_code_P10` | Solution~10: resilience loss integration under alternative recovery strategies (MATLABBook02_Chapter13_section8_Problem10.m). |
| `chapter_AICE_syntax_P01.m` | `chapter_AICE_syntax_P01` | Timetable synchronisation syntax. |
| `chapter_AICE_syntax_P02.m` | `chapter_AICE_syntax_P02` | Proportional feedback correction syntax. |
| `chapter_AICE_syntax_P03.m` | `chapter_AICE_syntax_P03` | Digraph and BFS syntax. |
| `chapter_AICE_syntax_P04.m` | `chapter_AICE_syntax_P04` | Directed graph successor query syntax. |
| `chapter_AICE_syntax_P05.m` | `chapter_AICE_syntax_P05` | Regression tree and ensemble syntax. |
| `chapter_AICE_syntax_P06.m` | `chapter_AICE_syntax_P06` | Tree prediction and residual thresholding syntax. |
| `chapter_AICE_syntax_P07.m` | `chapter_AICE_syntax_P07` | TF-IDF document retrieval syntax. |
| `chapter_AICE_syntax_P08.m` | `chapter_AICE_syntax_P08` | Rank-based evaluation syntax. |
| `chapter_AICE_syntax_P09.m` | `chapter_AICE_syntax_P09` | Graph shortest path and edge removal syntax. |
| `chapter_AICE_syntax_P10.m` | `chapter_AICE_syntax_P10` | Trapezoidal integration syntax. |
| `chapter_AICSS_problem10_benchmarking.m` | `chapter_AICSS_problem10_benchmarking` | Integrated benchmarking and performance evaluation framework. |
| `chapter_AICSS_problem1_integrated_anomaly.m` | `chapter_AICSS_problem1_integrated_anomaly` | Integrated anomaly detection system for industrial control systems. |
| `chapter_AICSS_problem2_roc_analysis.m` | `chapter_AICSS_problem2_roc_analysis` | Comprehensive ROC analysis for security-safety trade-offs. |
| `chapter_AICSS_problem3_reliability.m` | `chapter_AICSS_problem3_reliability` | Comprehensive reliability assessment framework. |
| `chapter_AICSS_problem4_hil_testing.m` | `chapter_AICSS_problem4_hil_testing` | Hardware-in-the-Loop testing framework for autonomous systems. |
| `chapter_AICSS_problem5_uncertainty.m` | `chapter_AICSS_problem5_uncertainty` | Comprehensive uncertainty quantification and sensitivity analysis framework. |
| `chapter_AICSS_problem6_adversarial.m` | `chapter_AICSS_problem6_adversarial` | Adversarial robustness evaluation framework for security-safety applications. |
| `chapter_AICSS_problem7_multiobjective.m` | `chapter_AICSS_problem7_multiobjective` | Multi-objective optimisation framework for integrated security-safety system design. |
| `chapter_AICSS_problem8_explainable_ai.m` | `chapter_AICSS_problem8_explainable_ai` | Explainable AI framework for critical decision support systems. |
| `chapter_AICSS_problem9_transfer_learning.m` | `chapter_AICSS_problem9_transfer_learning` | Cross-domain transfer learning framework for security-safety applications. |
| `chapter_AIEFA_code_Problem1.m` | `chapter_AIEFA_code_Problem1` | AR time series modelling and forecasting (MATLABBook02_AIEFA_Problem1_ARTimeSeries.m). |
| `chapter_AIEFA_code_Problem2.m` | `chapter_AIEFA_code_Problem2` | Markowitz mean-variance portfolio optimisation (MATLABBook02_AIEFA_Problem2_PortfolioOptimisation.m). |
| `chapter_AIEFA_code_Problem3.m` | `chapter_AIEFA_code_Problem3` | Monte Carlo European option pricing with antithetic variates (MATLABBook02_AIEFA_Problem3_MonteCarloOption.m). |
| `chapter_AIEFA_code_Problem4.m` | `chapter_AIEFA_code_Problem4` | Logistic regression for credit risk classification (MATLABBook02_AIEFA_Problem4_CreditRiskLogistic.m). |
| `chapter_AIEFA_code_Problem5.m` | `chapter_AIEFA_code_Problem5` | Structural break detection via Chow test and CUSUM analysis (MATLABBook02_AIEFA_Problem5_StructuralBreak.m). |
| `chapter_AIEFA_code_Problem6.m` | `chapter_AIEFA_code_Problem6` | Insurance capital reserve stress testing (MATLABBook02_AIEFA_Problem6_InsuranceCapitalReserve.m). |
| `chapter_AILMI_prob10_drift.m` | `chapter_AILMI_prob10_drift` | Drift detection using accuracy monitoring. |
| `chapter_AILMI_prob10_ewc.m` | `chapter_AILMI_prob10_ewc` | Elastic Weight Consolidation for continual learning. |
| `chapter_AILMI_prob1_baseline.m` | `chapter_AILMI_prob1_baseline` | Logistic regression baseline for domain adaptation. |
| `chapter_AILMI_prob1_code.m` | `chapter_AILMI_prob1_code` | Complete multi-domain text classification with transfer learning implementation. |
| `chapter_AILMI_prob1_finetune.m` | `chapter_AILMI_prob1_finetune` | Fine-tuning on target domain with lower learning rate. |
| `chapter_AILMI_prob2_debias.m` | `chapter_AILMI_prob2_debias` | Hard debiasing technique removing gender bias. |
| `chapter_AILMI_prob2_weat.m` | `chapter_AILMI_prob2_weat` | WEAT bias quantification implementation. |
| `chapter_AILMI_prob3_bahdanau.m` | `chapter_AILMI_prob3_bahdanau` | Bahdanau additive attention implementation. |
| `chapter_AILMI_prob3_code.m` | `chapter_AILMI_prob3_code` | Complete attention mechanism comparison for neural machine translation. |
| `chapter_AILMI_prob3_multihead.m` | `chapter_AILMI_prob3_multihead` | Multi-head self-attention (Transformer-style). |
| `chapter_AILMI_prob4_joint.m` | `chapter_AILMI_prob4_joint` | Joint multi-task learning for entities and relations. |
| `chapter_AILMI_prob4_ner.m` | `chapter_AILMI_prob4_ner` | BiLSTM-CRF for named entity recognition. |
| `chapter_AILMI_prob5_coverage.m` | `chapter_AILMI_prob5_coverage` | Coverage mechanism to prevent repetition. |
| `chapter_AILMI_prob5_pointer.m` | `chapter_AILMI_prob5_pointer` | Pointer-generator network with copy mechanism. |
| `chapter_AILMI_prob6_gnn.m` | `chapter_AILMI_prob6_gnn` | Graph neural network for multi-hop reasoning. |
| `chapter_AILMI_prob6_graph.m` | `chapter_AILMI_prob6_graph` | Entity graph construction for multi-hop reasoning. |
| `chapter_AILMI_prob7_adversarial.m` | `chapter_AILMI_prob7_adversarial` | Adversarial training for style-invariant content representation. |
| `chapter_AILMI_prob7_decoder.m` | `chapter_AILMI_prob7_decoder` | Conditional decoder with style control. |
| `chapter_AILMI_prob7_encoders.m` | `chapter_AILMI_prob7_encoders` | Disentangled content and style encoders. |
| `chapter_AILMI_prob8_adversarial.m` | `chapter_AILMI_prob8_adversarial` | Adversarial training for language-invariant features. |
| `chapter_AILMI_prob8_fewshot.m` | `chapter_AILMI_prob8_fewshot` | Prototypical networks for few-shot command recognition. |
| `chapter_AILMI_prob8_mfcc.m` | `chapter_AILMI_prob8_mfcc` | MFCC feature extraction with SpecAugment. |
| `chapter_AILMI_prob9_gnn.m` | `chapter_AILMI_prob9_gnn` | Graph neural network for relationship reasoning. |
| `chapter_AILMI_prob9_rpn.m` | `chapter_AILMI_prob9_rpn` | Region proposal network for dense captioning. |
| `chapter_AI_Archaeology_solution10_hetu.m` | `chapter_AI_Archaeology_solution10_hetu` | Hetu Luoshu Cosmological Pattern Analysis System. |
| `chapter_AI_Archaeology_solution11_yijing.m` | `chapter_AI_Archaeology_solution11_yijing` | I Ching Trigram System Comprehensive Analysis. |
| `chapter_AI_Archaeology_solution1_decipherment.m` | `chapter_AI_Archaeology_solution1_decipherment` | AI Script Decipherment System - Digital Rosetta Stone. |
| `chapter_AI_Archaeology_solution2_fresco.m` | `chapter_AI_Archaeology_solution2_fresco` | Automated Fresco Deterioration Analysis System. |
| `chapter_AI_Archaeology_solution3_maya.m` | `chapter_AI_Archaeology_solution3_maya` | Maya Settlement Discovery System Using LiDAR Analysis. |
| `chapter_AI_Archaeology_solution4_angkor.m` | `chapter_AI_Archaeology_solution4_angkor` | Angkor Wat Digital Twin and Predictive Conservation System. |
| `chapter_AI_Archaeology_solution5_alexandria.m` | `chapter_AI_Archaeology_solution5_alexandria` | Library of Alexandria Virtual Reality Reconstruction System. |
| `chapter_AI_Archaeology_solution6_ethics.m` | `chapter_AI_Archaeology_solution6_ethics` | Ethical AI Framework for Indigenous Sacred Sites. |
| `chapter_AI_Archaeology_solution7_quantum.m` | `chapter_AI_Archaeology_solution7_quantum` | Quantum-Enhanced Archaeological Analysis System for Emperor Qinshihuang's Tomb. |
| `chapter_AI_Archaeology_solution8_heritage.m` | `chapter_AI_Archaeology_solution8_heritage` | Integrated Digital Heritage Management System. |
| `chapter_AI_Archaeology_solution9_tangut.m` | `chapter_AI_Archaeology_solution9_tangut` | Comprehensive Tangut Script AI Analysis System. |
| `chapter_AI_CV_problem10_counterfactual.m` | `chapter_AI_CV_problem10_counterfactual` | Counterfactual generation syntax. |
| `chapter_AI_CV_problem11_microwave.m` | `chapter_AI_CV_problem11_microwave` | Microwave imaging syntax. |
| `chapter_AI_CV_problem12_multimodal.m` | `chapter_AI_CV_problem12_multimodal` | Multimodal medical AI syntax. |
| `chapter_AI_CV_problem1_complete.m` | `chapter_AI_CV_problem1_complete` | Advanced Temporal Cross-Validation Implementation. |
| `chapter_AI_CV_problem1_temporal_cv.m` | `chapter_AI_CV_problem1_temporal_cv` | Temporal cross-validation syntax. |
| `chapter_AI_CV_problem2_complete.m` | `chapter_AI_CV_problem2_complete` | Statistical Significance Testing Framework. |
| `chapter_AI_CV_problem2_stats.m` | `chapter_AI_CV_problem2_stats` | Statistical testing syntax. |
| `chapter_AI_CV_problem3_complete.m` | `chapter_AI_CV_problem3_complete` | Advanced GPU Memory Management System. |
| `chapter_AI_CV_problem3_gpu.m` | `chapter_AI_CV_problem3_gpu` | GPU memory management syntax. |
| `chapter_AI_CV_problem4_complete.m` | `chapter_AI_CV_problem4_complete` | Parallel Algorithm Design Framework. |
| `chapter_AI_CV_problem4_parallel.m` | `chapter_AI_CV_problem4_parallel` | Parallel processing syntax. |
| `chapter_AI_CV_problem5_complete.m` | `chapter_AI_CV_problem5_complete` | Quantum Feature Mapping Implementation. |
| `chapter_AI_CV_problem5_quantum.m` | `chapter_AI_CV_problem5_quantum` | Quantum feature mapping syntax. |
| `chapter_AI_CV_problem6_vqa.m` | `chapter_AI_CV_problem6_vqa` | Variational quantum algorithm syntax. |
| `chapter_AI_CV_problem7_snn.m` | `chapter_AI_CV_problem7_snn` | Spiking neural network syntax. |
| `chapter_AI_CV_problem8_stdp.m` | `chapter_AI_CV_problem8_stdp` | STDP learning syntax. |
| `chapter_AI_CV_problem9_gradients.m` | `chapter_AI_CV_problem9_gradients` | Gradient explanation syntax. |
| `chapter_AI_ICT_problem10_solution.m` | `chapter_AI_ICT_problem10_solution` | Neuromorphic Computing for Edge AI Implementation |
| `chapter_AI_ICT_problem1_solution.m` | `chapter_AI_ICT_problem1_solution` | Deep Learning Channel Estimation Implementation |
| `chapter_AI_ICT_problem2_solution.m` | `chapter_AI_ICT_problem2_solution` | Multi-Agent Reinforcement Learning for Spectrum Access |
| `chapter_AI_ICT_problem3_solution.m` | `chapter_AI_ICT_problem3_solution` | Quantum Error Correction Implementation |
| `chapter_AI_ICT_problem4_solution.m` | `chapter_AI_ICT_problem4_solution` | AI-Enhanced Network Slicing Implementation |
| `chapter_AI_ICT_problem5_solution.m` | `chapter_AI_ICT_problem5_solution` | Federated Learning for Channel Prediction |
| `chapter_AI_ICT_problem6_solution.m` | `chapter_AI_ICT_problem6_solution` | Digital Twin Predictive Maintenance Implementation |
| `chapter_AI_ICT_problem7_solution.m` | `chapter_AI_ICT_problem7_solution` | Adversarial Machine Learning Implementation |
| `chapter_AI_ICT_problem8_solution.m` | `chapter_AI_ICT_problem8_solution` | Multi-Objective Green Network Optimisation |
| `chapter_AI_ICT_problem9_solution.m` | `chapter_AI_ICT_problem9_solution` | Graph Neural Networks for Network Topology Optimisation |
| `chapter_AIinMOR_problem_1.m` | `chapter_AIinMOR_problem_1` | Multi-Objective Production Planning Solution. |
| `chapter_AIinMOR_problem_2.m` | `chapter_AIinMOR_problem_2` | Intelligent Supply Chain Network Design Solution. |
| `chapter_AIinMOR_problem_3.m` | `chapter_AIinMOR_problem_3` | Dynamic Workforce Scheduling Solution. |
| `chapter_AIinMOR_problem_4.m` | `chapter_AIinMOR_problem_4` | AI-Driven Portfolio Optimisation with ESG Constraints. |
| `chapter_AIinMOR_problem_5.m` | `chapter_AIinMOR_problem_5` | Integrated Smart City Resource Management System. |
| `chapter_AIinMOR_problem_6.m` | `chapter_AIinMOR_problem_6` | Digital Transformation Strategy Optimisation. |
| `chapter_Introduction_problem10_code.m` | `chapter_Introduction_problem10_code` | MATLAB integration with external tools. |
| `chapter_Introduction_problem1_code.m` | `chapter_Introduction_problem1_code` | Matrix operations across disciplines. |
| `chapter_Introduction_problem2_code.m` | `chapter_Introduction_problem2_code` | Multidisciplinary data visualisation. |
| `chapter_Introduction_problem3_code.m` | `chapter_Introduction_problem3_code` | Cross-domain data import and processing. |
| `chapter_Introduction_problem4_code.m` | `chapter_Introduction_problem4_code` | Simple systems simulation with multidisciplinary applications. |
| `chapter_Introduction_problem5_code.m` | `chapter_Introduction_problem5_code` | Basic machine learning workflow. |
| `chapter_Introduction_problem6_code.m` | `chapter_Introduction_problem6_code` | Signal processing across domains. |
| `chapter_Introduction_problem7_code.m` | `chapter_Introduction_problem7_code` | Interactive multidisciplinary dashboard creation. |
| `chapter_Introduction_problem8_code.m` | `chapter_Introduction_problem8_code` | Digital twin prototype implementation. |
| `chapter_Introduction_problem9_code.m` | `chapter_Introduction_problem9_code` | Multi-method data analysis for transportation systems. |
| `cnn_classification.m` | `cnn_classification` | CNN Image Classification |
| `css_bias.m` | `css_bias` | Group fairness diagnostics in base MATLAB. |
| `css_calib.m` | `css_calib` | Calibration reliability table in base MATLAB. |
| `css_chain.m` | `css_chain` | Reliability propagation along a system chain. |
| `css_degroot.m` | `css_degroot` | DeGroot opinion dynamics in base MATLAB. |
| `css_effect.m` | `css_effect` | Effect size and permutation test in base MATLAB. |
| `css_gap.m` | `css_gap` | Competency gap analysis in base MATLAB. |
| `css_hindex.m` | `css_hindex` | h-index computation in base MATLAB. |
| `css_hotspot.m` | `css_hotspot` | Crime hotspot detection with base MATLAB. |
| `css_leslie.m` | `css_leslie` | Leslie matrix population projection. |
| `css_match.m` | `css_match` | Ranking candidates by complementarity. |
| `css_mcda.m` | `css_mcda` | Weighted multi-criteria ranking of design options. |
| `css_rate.m` | `css_rate` | Per-capita crime-rate ranking in base MATLAB. |
| `css_reg.m` | `css_reg` | Least-squares regression via the backslash operator. |
| `css_robot.m` | `css_robot` | Online adaptation of a robot behaviour parameter. |
| `css_skillcorr.m` | `css_skillcorr` | Skill correlation matrix in base MATLAB. |
| `css_text.m` | `css_text` | Word-frequency analysis of focus-group text. |
| `evolutionary_fuzzy_weather_3d.m` | `evolutionary_fuzzy_weather_3d` | Evolutionary Fuzzy Weather Forecasting with 3D visualisation |
| `ga_feature_selection.m` | `ga_feature_selection` | Genetic Algorithm Feature Selection |
| `iris_classification.m` | `iris_classification` | Neural Network Classification Implementation |
| `kmeans_clustering.m` | `kmeans_clustering` | K-Means Customer Segmentation |
| `lst_sol01_code.m` | `lst:sol01_code` | Audio Feature Extraction and Visualisation (MATLABBook02_Chapter10_Problem01.m). |
| `lst_sol01_syntax_mfcc.m` | `lst:sol01_syntax_mfcc` | Basic audio read and MFCC computation. |
| `lst_sol02_code.m` | `lst:sol02_code` | Music Genre Classification with SVMs (MATLABBook02_Chapter10_Problem02.m). |
| `lst_sol02_syntax_svm.m` | `lst:sol02_syntax_svm` | Multi-class SVM training with fitcecoc(). |
| `lst_sol03_code.m` | `lst:sol03_code` | LSTM Melody Generation (MATLABBook02_Chapter10_Problem03.m). |
| `lst_sol03_syntax_lstm.m` | `lst:sol03_syntax_lstm` | LSTM network definition and training. |
| `lst_sol04_code.m` | `lst:sol04_code` | Neural Style Transfer (MATLABBook02_Chapter10_Problem04.m). |
| `lst_sol04_syntax_vgg.m` | `lst:sol04_syntax_vgg` | Extracting VGG-19 activations. |
| `lst_sol05_code.m` | `lst:sol05_code` | GAN for Visual Pattern Generation (MATLABBook02_Chapter10_Problem05.m). |
| `lst_sol05_syntax_gan.m` | `lst:sol05_syntax_gan` | GAN custom training step. |
| `lst_sol06_code.m` | `lst:sol06_code` | Content-Based Music Recommendation (MATLABBook02_Chapter10_Problem06.m). |
| `lst_sol06_syntax_pdist2.m` | `lst:sol06_syntax_pdist2` | Pairwise distance computation. |
| `lst_sol07_code.m` | `lst:sol07_code` | Sentiment Analysis of Song Lyrics (MATLABBook02_Chapter10_Problem07.m). |
| `lst_sol07_syntax_sentiment.m` | `lst:sol07_syntax_sentiment` | Text tokenisation and VADER sentiment. |
| `lst_sol08_code.m` | `lst:sol08_code` | Real-Time Spectrogram with Beat Detection (MATLABBook02_Chapter10_Problem08.m). |
| `lst_sol08_syntax_devicereader.m` | `lst:sol08_syntax_devicereader` | Real-time audio capture with audioDeviceReader. |
| `lst_sol09_code.m` | `lst:sol09_code` | Ethical Analysis Visualisation (MATLABBook02_Chapter10_Problem09.m). |
| `lst_sol09_syntax_table.m` | `lst:sol09_syntax_table` | Creating a formatted table in MATLAB. |
| `lst_sol10_code.m` | `lst:sol10_code` | Diffusion vs.\ GAN Comparison (MATLABBook02_Chapter10_Problem10.m). |
| `lst_sol10_syntax_bar.m` | `lst:sol10_syntax_bar` | Grouped bar chart for model comparison. |
| `lstm_forecasting.m` | `lstm_forecasting` | LSTM Time Series Forecasting |
| `p1.m` | `p1` | MATLABBook03_ChapterAIBHS_Problem01.m |
| `p10.m` | `p10` | MATLABBook03_ChapterAIBHS_Problem10.m |
| `p10s.m` | `p10s` | Boosted-ensemble syntax. |
| `p11.m` | `p11` | MATLABBook03_ChapterAIBHS_Problem11.m |
| `p11s.m` | `p11s` | Bit-to-base mapping syntax. |
| `p12.m` | `p12` | MATLABBook03_ChapterAIBHS_Problem12.m |
| `p12s.m` | `p12s` | Log-linear decay-fit syntax. |
| `p13.m` | `p13` | MATLABBook03_ChapterAIBHS_Problem13.m |
| `p13s.m` | `p13s` | SVM training syntax. |
| `p14.m` | `p14` | MATLABBook03_ChapterAIBHS_Problem14.m |
| `p14s.m` | `p14s` | Incremental-learning syntax. |
| `p15.m` | `p15` | MATLABBook03_ChapterAIBHS_Problem15.m |
| `p15s.m` | `p15s` | Half-life estimation syntax. |
| `p16.m` | `p16` | MATLABBook03_ChapterAIBHS_Problem16.m |
| `p16s.m` | `p16s` | Frequency-response syntax. |
| `p17.m` | `p17` | MATLABBook03_ChapterAIBHS_Problem17.m |
| `p17s.m` | `p17s` | Bayesian-optimisation syntax. |
| `p18.m` | `p18` | MATLABBook03_ChapterAIBHS_Problem18.m |
| `p18s.m` | `p18s` | Fork-stall Monte-Carlo syntax. |
| `p19.m` | `p19` | MATLABBook03_ChapterAIBHS_Problem19.m |
| `p19s.m` | `p19s` | Mixed-effects model syntax. |
| `p1s.m` | `p1s` | PWM normalisation syntax. |
| `p2.m` | `p2` | MATLABBook03_ChapterAIBHS_Problem02.m |
| `p20.m` | `p20` | MATLABBook03_ChapterAIBHS_Problem20.m |
| `p20s.m` | `p20s` | Non-negative least squares syntax. |
| `p21.m` | `p21` | MATLABBook03_ChapterAIBHS_Problem21.m |
| `p21s.m` | `p21s` | ode45 solver syntax. |
| `p22.m` | `p22` | MATLABBook03_ChapterAIBHS_Problem22.m |
| `p22s.m` | `p22s` | Context-drift update syntax. |
| `p23.m` | `p23` | MATLABBook03_ChapterAIBHS_Problem23.m |
| `p23s.m` | `p23s` | Otsu segmentation syntax. |
| `p24.m` | `p24` | MATLABBook03_ChapterAIBHS_Problem24.m |
| `p24s.m` | `p24s` | kNN classifier syntax. |
| `p2s.m` | `p2s` | BiLSTM layer syntax. |
| `p3.m` | `p3` | MATLABBook03_ChapterAIBHS_Problem03.m |
| `p3s.m` | `p3s` | DWT and decision-tree syntax. |
| `p4.m` | `p4` | MATLABBook03_ChapterAIBHS_Problem04.m |
| `p4s.m` | `p4s` | PCA and MST syntax. |
| `p5.m` | `p5` | MATLABBook03_ChapterAIBHS_Problem05.m |
| `p5s.m` | `p5s` | Random-walk-with-restart syntax. |
| `p6.m` | `p6` | MATLABBook03_ChapterAIBHS_Problem06.m |
| `p6s.m` | `p6s` | Random-forest syntax. |
| `p7.m` | `p7` | MATLABBook03_ChapterAIBHS_Problem07.m |
| `p7s.m` | `p7s` | U-Net construction syntax. |
| `p8.m` | `p8` | MATLABBook03_ChapterAIBHS_Problem08.m |
| `p8s.m` | `p8s` | Neighbour-joining syntax. |
| `p9.m` | `p9` | MATLABBook03_ChapterAIBHS_Problem09.m |
| `p9s.m` | `p9s` | Granger regression syntax. |
| `pca_analysis.m` | `pca_analysis` | PCA Dimensionality Reduction |
| `problem_1_weibull_analysis.m` | `problem_1_weibull_analysis` | Comprehensive Weibull Analysis for Offshore Wind Turbine Gearboxes |
| `problem_2_hydrogen_classification.m` | `problem_2_hydrogen_classification` | Multi-Class Hydrogen Environment Bearing Fault Classification |
| `problem_3_climate_lstm.m` | `problem_3_climate_lstm` | Climate-Adaptive LSTM for Infrastructure RUL Prediction |
| `problem_4_hydrogen_digital_twin.m` | `problem_4_hydrogen_digital_twin` | Digital Twin Development for Hydrogen Production Safety Systems |
| `problem_6_am_uncertainty.m` | `problem_6_am_uncertainty` | Bayesian Uncertainty Quantification for AM Quality Control |
| `qlearning_rl.m` | `qlearning_rl` | Q-Learning Reinforcement Learning |
| `random_forest_ensemble.m` | `random_forest_ensemble` | Random Forest Ensemble Learning |
| `svm_binary_classification.m` | `svm_binary_classification` | SVM Binary Classification Implementation |
| `yolo_detection.m` | `yolo_detection` | YOLO Object Detection Implementation |
