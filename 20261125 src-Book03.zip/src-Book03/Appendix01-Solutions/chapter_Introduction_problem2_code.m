%% chapter_Introduction_problem2_code.m
% Multidisciplinary data visualisation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_Introduction_problem2_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% MATLABBook03_Chapter01_Problem02.m
% Multidisciplinary Data visualisation
% This script demonstrates visualisation of weather data from multiple
% disciplinary perspectives

%% Generate synthetic weather dataset (one year of daily measurements)
% In practice, you would load real data from files
days = 1:365;
t = days/365 * 2*pi; % Convert to radians for seasonal pattern

% Temperature with seasonal pattern and noise (--C)
avg_temp = 15;  % Average annual temperature
temp_amplitude = 10;  % Seasonal variation
temperature = avg_temp + temp_amplitude * sin(t - pi/6) + 2*randn(size(t));

% Humidity with seasonal pattern and noise (%)
humidity = 70 + 15 * sin(t) + 5 * randn(size(t));
humidity = min(max(humidity, 30), 100); % Bound between 30% and 100%

% Precipitation with seasonal pattern and more variability (mm)
precip_prob = (0.3 + 0.2 * sin(t - pi/3));
precipitation = zeros(size(t));
rain_days = rand(size(t)) < precip_prob;
precipitation(rain_days) = exprnd(5, sum(rain_days), 1);

% Wind speed with seasonal and random components (m/s)
wind_speed = 3 + 2 * sin(t - pi/4) + 1.5 * randn(size(t));
wind_speed = max(wind_speed, 0); % Wind speed can't be negative

% Solar radiation with strong seasonal pattern (W/m?)
solar_radiation = 500 + 300 * sin(t - pi/6) + 100 * randn(size(t));
solar_radiation = max(solar_radiation, 0); % Can't have negative radiation

% Air pressure with small variations (hPa)
pressure = 1013 + 10 * sin(t - pi/2) + 3 * randn(size(t));

% Create a datetime array for the year 2023
dates = datetime(2023,1,1) + days - 1;

% Combine into a table
weather_data = table(dates', temperature', humidity', precipitation', ...
                    wind_speed', solar_radiation', pressure', ...
                    'VariableNames', {'Date', 'Temperature', 'Humidity', ...
                    'Precipitation', 'WindSpeed', 'SolarRadiation', 'Pressure'});

%% 1. Environmental Science Perspective
% Create figure with multiple subplots
figure('Name', 'Environmental Science Perspective', 'Position', [100, 100, 1200, 800]);

% Temperature and precipitation (climate patterns)
subplot(2, 2, 1);
yyaxis left
plot(weather_data.Date, weather_data.Temperature, 'b-');
ylabel('Temperature (--C)');
ylim([min(weather_data.Temperature)-5, max(weather_data.Temperature)+5]);

yyaxis right
bar(weather_data.Date, weather_data.Precipitation, 'FaceAlpha', 0.3);
ylabel('Precipitation (mm)');

title('Climate Pattern: Temperature and Precipitation');
grid on;
xlabel('Date');

% Temperature anomalies (deviation from seasonal norm)
subplot(2, 2, 2);
% Calculate expected seasonal temperature (smoothed)
seasonal_temp = avg_temp + temp_amplitude * sin(t - pi/6);
temp_anomaly = weather_data.Temperature - seasonal_temp';

plot(weather_data.Date, temp_anomaly, 'r-');
hold on;
yline(0, 'k--');
% Add 7-day moving average
plot(weather_data.Date, movmean(temp_anomaly, 7), 'b-', 'LineWidth', 2);
hold off;

title('Temperature Anomalies from Seasonal Norm');
xlabel('Date');
ylabel('Temperature Deviation (--C)');
legend('Daily Anomaly', 'Seasonal Norm', '7-Day Moving Avg', 'Location', 'best');
grid on;

% Humidity and pressure relationship (atmospheric conditions)
subplot(2, 2, 3);
scatter(weather_data.Pressure, weather_data.Humidity, 25, weather_data.Temperature, 'filled');
colormap jet;
colorbar;
title('Atmospheric Conditions: Humidity vs. Pressure');
xlabel('Pressure (hPa)');
ylabel('Humidity (%)');
grid on;

% Wind speed distribution by month (seasonal patterns)
subplot(2, 2, 4);
% Extract month from dates
months = month(weather_data.Date);
boxplot(weather_data.WindSpeed, months);
title('Wind Speed Distribution by Month');
xlabel('Month');
ylabel('Wind Speed (m/s)');
grid on;

%% 2. Energy Engineering Perspective
figure('Name', 'Energy Engineering Perspective', 'Position', [150, 150, 1200, 800]);

% Solar radiation over the year (solar energy potential)
subplot(2, 2, 1);
plot(weather_data.Date, weather_data.SolarRadiation, 'y-');
hold on;
plot(weather_data.Date, movmean(weather_data.SolarRadiation, 14), 'r-', 'LineWidth', 2);
hold off;
title('Solar Energy Potential Throughout the Year');
xlabel('Date');
ylabel('Solar Radiation (W/m?)');
legend('Daily Values', '14-Day Moving Avg', 'Location', 'best');
grid on;

% Wind speed distribution (wind energy potential)
subplot(2, 2, 2);
histogram(weather_data.WindSpeed, 20);
hold on;
% Add Weibull distribution fit (common for wind speed analysis)
x = linspace(0, max(weather_data.WindSpeed), 100);
pd = fitdist(weather_data.WindSpeed, 'Weibull');
y = pdf(pd, x) * sum(histogram(weather_data.WindSpeed).Values) * mean(diff(histogram(weather_data.WindSpeed).BinEdges));
plot(x, y, 'r-', 'LineWidth', 2);
hold off;
title('Wind Speed Distribution (Wind Energy Potential)');
xlabel('Wind Speed (m/s)');
ylabel('Frequency (days)');
legend('Observed', 'Weibull Fit', 'Location', 'best');
grid on;

% Temperature vs. solar radiation (heating/cooling demand)
subplot(2, 2, 3);
scatter(weather_data.Temperature, weather_data.SolarRadiation, 25, ...
        month(weather_data.Date), 'filled');
colormap hsv;
colorbar('Ticks', 1:12, 'TickLabels', {'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', ...
                                       'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'});
title('Temperature vs. Solar Radiation by Month');
xlabel('Temperature (--C)');
ylabel('Solar Radiation (W/m?)');
grid on;

% Heating and cooling degree days
subplot(2, 2, 4);
base_temp = 18; % Base temperature for HDD/CDD calculation (--C)
HDD = max(base_temp - weather_data.Temperature, 0);
CDD = max(weather_data.Temperature - base_temp, 0);

% Calculate cumulative values
cumulative_HDD = cumsum(HDD);
cumulative_CDD = cumsum(CDD);

% Plot
yyaxis left
plot(weather_data.Date, cumulative_HDD, 'b-', 'LineWidth', 2);
ylabel('Heating Degree Days (--C--days)');

yyaxis right
plot(weather_data.Date, cumulative_CDD, 'r-', 'LineWidth', 2);
ylabel('Cooling Degree Days (--C--days)');

title('Cumulative Heating and Cooling Degree Days');
xlabel('Date');
legend('HDD', 'CDD', 'Location', 'best');
grid on;

%% 3. Health Research Perspective
figure('Name', 'Health Research Perspective', 'Position', [200, 200, 1200, 800]);

% Heat index (temperature and humidity combined)
subplot(2, 2, 1);
% Simplified heat index calculation
heat_index = weather_data.Temperature + 0.05 * weather_data.Humidity .* (weather_data.Temperature - 25);

plot(weather_data.Date, heat_index, 'r-');
hold on;
% Highlight dangerous heat index levels
dangerous_days = heat_index > 30;
plot(weather_data.Date(dangerous_days), heat_index(dangerous_days), 'ro', 'MarkerFaceColor', 'r');
% Add a reference line for danger threshold
yline(30, 'k--', 'Heat Stress Risk');
hold off;

title('Heat Index (Temperature-Humidity Discomfort)');
xlabel('Date');
ylabel('Heat Index');
legend('Daily Heat Index', 'High Risk Days', 'Location', 'best');
grid on;

% Air quality proxy (simplified model based on temperature, humidity, wind)
subplot(2, 2, 2);
% Simple proxy model (not scientifically validated - just for demonstration)
air_quality_proxy = 50 + 0.5 * weather_data.Temperature - 0.2 * weather_data.Humidity - 5 * weather_data.WindSpeed;
air_quality_proxy = max(min(air_quality_proxy, 150), 0); % Bound between 0 and 150

plot(weather_data.Date, air_quality_proxy, 'g-');
hold on;
yline([50 100], 'k--');
hold off;

title('Air Quality Proxy Index');
xlabel('Date');
ylabel('Air Quality Index (proxy)');
ylim([0 150]);
yticks(0:25:150);
grid on;

% Pollen season proxy (based on temperature and humidity)
subplot(2, 2, 3);
% Simplified pollen proxy model (peaks in spring and fall)
spring_component = gaussmf(days, [30, 120]); % Spring peak around day 120
fall_component = gaussmf(days, [30, 260]);   % Fall peak around day 260
pollen_proxy = 10 * (spring_component + 0.7 * fall_component)';
% Modify based on weather conditions
pollen_proxy = pollen_proxy .* (1 + 0.01 * (weather_data.Temperature - 15)) .* (1 - 0.005 * (weather_data.Humidity - 60));
pollen_proxy = max(pollen_proxy, 0);

area(weather_data.Date, pollen_proxy, 'FaceColor', [0.5 0.8 0.2], 'FaceAlpha', 0.5);
title('Pollen Season Proxy Index');
xlabel('Date');
ylabel('Pollen Index (proxy)');
grid on;

% Temperature extremes and precipitation (vector-borne disease risk)
subplot(2, 2, 4);
% Calculate a simplified disease risk index based on temp and precipitation
% Higher when warm and wet (25-35--C with precipitation)
disease_risk = zeros(size(weather_data.Temperature));
for i = 1:length(disease_risk)
    temp_factor = max(0, 1 - abs(weather_data.Temperature(i) - 30)/10);
    precip_factor = min(1, weather_data.Precipitation(i)/10);
    disease_risk(i) = temp_factor * (0.5 + 0.5 * precip_factor);
end

% Moving sum over 14 days (incubation periods)
risk_14day = movsum(disease_risk, [0 13]);

plot(weather_data.Date, risk_14day, 'b-', 'LineWidth', 2);
title('Vector-Borne Disease Risk Proxy (14-day window)');
xlabel('Date');
ylabel('Risk Index (proxy)');
grid on;

%% 4. Combined Multidisciplinary Dashboard
figure('Name', 'Multidisciplinary Weather Data Dashboard', 'Position', [250, 50, 1200, 900]);

% Temperature, precipitation, and solar radiation (core variables)
subplot(3, 2, 1);
yyaxis left
plot(weather_data.Date, weather_data.Temperature, 'b-');
ylabel('Temperature (--C)');
ylim([min(weather_data.Temperature)-5, max(weather_data.Temperature)+5]);

yyaxis right
plot(weather_data.Date, weather_data.SolarRadiation, 'y-', 'LineWidth', 1);
ylabel('Solar Radiation (W/m?)');

title('Core Weather Variables: Temperature and Solar Radiation');
grid on;
xlabel('Date');
legend('Temperature', 'Solar Radiation', 'Location', 'best');

% Precipitation as a separate bar chart
subplot(3, 2, 2);
bar(weather_data.Date, weather_data.Precipitation, 'FaceColor', [0.3 0.5 0.9], 'FaceAlpha', 0.5);
title('Daily Precipitation');
xlabel('Date');
ylabel('Precipitation (mm)');
grid on;

% Combined health and energy indices
subplot(3, 2, 3);
plot(weather_data.Date, heat_index, 'r-', 'LineWidth', 1.5);
hold on;
plot(weather_data.Date, cumulative_HDD/max(cumulative_HDD)*max(heat_index), 'b-', 'LineWidth', 1.5);
plot(weather_data.Date, pollen_proxy/max(pollen_proxy)*max(heat_index), 'g-', 'LineWidth', 1.5);
hold off;
title('Health and Comfort Indices');
xlabel('Date');
ylabel('Index Value (normalized)');
legend('Heat Discomfort', 'Heating Need', 'Pollen Level', 'Location', 'best');
grid on;

% Wind and solar energy potential
subplot(3, 2, 4);
% Calculate simplified wind power potential (wind speed cubed, then scaled)
wind_power = weather_data.WindSpeed.^3 / 125; % Simple proxy for wind power
wind_power = min(wind_power, 1); % Cap for extreme values

area(weather_data.Date, [wind_power, weather_data.SolarRadiation/1000]);
title('Renewable Energy Potential');
xlabel('Date');
ylabel('Normalized Potential (0-1)');
legend('Wind Power', 'Solar Power', 'Location', 'best');
grid on;

% Monthly summary metrics
subplot(3, 2, [5,6]);
% Calculate monthly averages of key variables
monthly_data = varfun(@mean, weather_data, 'GroupingVariables', 'Date_Month', ...
                      'InputVariables', {'Temperature', 'WindSpeed', 'SolarRadiation', 'Humidity'});
monthly_data.Properties.VariableNames(2:end) = {'Month', 'AvgTemp', 'AvgWind', 'AvgSolar', 'AvgHumidity'};

% Create grouped bar chart
bar(monthly_data.Month, [monthly_data.AvgTemp, monthly_data.AvgWind*5, ...
                         monthly_data.AvgSolar/100, monthly_data.AvgHumidity/10]);
title('Monthly Average Conditions');
xlabel('Month');
ylabel('Value (scaled)');
legend('Temperature (--C)', 'Wind Speed (--5 m/s)', 'Solar Radiation (/100 W/m?)', ...
       'Humidity (/10 %)', 'Location', 'best');
grid on;
xticks(1:12);
xticklabels({'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'});

% Add annotation explaining the multidisciplinary value
annotation('textbox', [0.1, 0.01, 0.8, 0.05], ...
           'String', 'This dashboard integrates perspectives from environmental science, energy engineering, and health research to provide a comprehensive view of weather data relevance across disciplines.', ...
           'EdgeColor', 'none', ...
           'HorizontalAlignment', 'center');
