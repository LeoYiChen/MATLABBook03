%% chapter_AE_Problems_P2_RRTStar.m
% RRT* algorithm for UAV navigation with dynamic obstacles.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AE_Problems_P2_RRTStar
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [optimalPath, planningTree] = rrtStarDynamicObstacles(startConfig, goalConfig, obstacleList, windField, planningParams)
    % RRT* path planning for UAV with dynamic obstacles and wind
    % Author: Dr Leo Chen
    % Version: 1.5.0 - Added wind field integration
    % Date: 2024-11-14
    
    fprintf('Starting RRT* planning for UAV navigation\n');
    fprintf('Configuration space: %.1f x %.1f x %.1f km, Planning time: %.0f s\n', ...
            planningParams.spaceSize/1000, planningParams.maxPlanningTime);
    
    % Initialize tree with start configuration
    planningTree.nodes = [startConfig];
    planningTree.parents = [0];
    planningTree.costs = [0];
    planningTree.nodeCount = 1;
    
    % Planning parameters
    maxIterations = planningParams.maxIterations;
    stepSize = planningParams.stepSize;
    goalBias = planningParams.goalBias;
    rewireRadius = planningParams.rewireRadius;
    
    bestCost = inf;
    bestPath = [];
    
    for iterationIndex = 1:maxIterations
        % Sample random configuration with goal bias
        if rand() < goalBias
            randomConfig = goalConfig;
        else
            randomConfig = sampleRandomConfiguration(planningParams.spaceSize);
        end
        
        % Find nearest node in tree
        nearestNodeIndex = findNearestNode(planningTree, randomConfig);
        nearestNode = planningTree.nodes(nearestNodeIndex, :);
        
        % Generate new configuration considering UAV dynamics
        [newConfig, trajectoryValid] = generateNewConfiguration(nearestNode, randomConfig, ...
                                                               stepSize, windField, planningParams);
        
        if trajectoryValid
            % Check collision with dynamic obstacles
            collisionFree = checkDynamicCollisions(nearestNode, newConfig, obstacleList, planningParams);
            
            if collisionFree
                % Add new node to tree
                newNodeIndex = planningTree.nodeCount + 1;
                planningTree.nodes(newNodeIndex, :) = newConfig;
                planningTree.parents(newNodeIndex) = nearestNodeIndex;
                
                % Calculate cost including wind penalty
                trajectoryTime = newConfig(4) - nearestNode(4);
                windPenalty = calculateWindPenalty(nearestNode, newConfig, windField);
                edgeCost = norm(newConfig(1:3) - nearestNode(1:3)) + windPenalty;
                planningTree.costs(newNodeIndex) = planningTree.costs(nearestNodeIndex) + edgeCost;
                
                planningTree.nodeCount = newNodeIndex;
                
                % RRT* rewiring procedure
                nearNodeIndices = findNearNodes(planningTree, newConfig, rewireRadius);
                
                % Choose parent that minimizes cost
                bestParentIndex = nearestNodeIndex;
                bestCostToNew = planningTree.costs(newNodeIndex);
                
                for nearIndex = nearNodeIndices
                    nearNode = planningTree.nodes(nearIndex, :);
                    [tempConfig, tempValid] = generateNewConfiguration(nearNode, newConfig, ...
                                                                      norm(newConfig(1:3) - nearNode(1:3)), ...
                                                                      windField, planningParams);
                    
                    if tempValid && checkDynamicCollisions(nearNode, newConfig, obstacleList, planningParams)
                        tempWindPenalty = calculateWindPenalty(nearNode, newConfig, windField);
                        tempEdgeCost = norm(newConfig(1:3) - nearNode(1:3)) + tempWindPenalty;
                        tempCost = planningTree.costs(nearIndex) + tempEdgeCost;
                        
                        if tempCost < bestCostToNew
                            bestParentIndex = nearIndex;
                            bestCostToNew = tempCost;
                        end
                    end
                end
                
                % Update parent and cost
                planningTree.parents(newNodeIndex) = bestParentIndex;
                planningTree.costs(newNodeIndex) = bestCostToNew;
                
                % Rewire tree
                for nearIndex = nearNodeIndices
                    nearNode = planningTree.nodes(nearIndex, :);
                    [tempConfig, tempValid] = generateNewConfiguration(newConfig, nearNode, ...
                                                                      norm(nearNode(1:3) - newConfig(1:3)), ...
                                                                      windField, planningParams);
                    
                    if tempValid && checkDynamicCollisions(newConfig, nearNode, obstacleList, planningParams)
                        tempWindPenalty = calculateWindPenalty(newConfig, nearNode, windField);
                        tempEdgeCost = norm(nearNode(1:3) - newConfig(1:3)) + tempWindPenalty;
                        newCostToNear = planningTree.costs(newNodeIndex) + tempEdgeCost;
                        
                        if newCostToNear < planningTree.costs(nearIndex)
                            planningTree.parents(nearIndex) = newNodeIndex;
                            planningTree.costs(nearIndex) = newCostToNear;
                        end
                    end
                end
                
                % Check if goal is reached
                if norm(newConfig(1:3) - goalConfig(1:3)) < planningParams.goalTolerance
                    currentCost = planningTree.costs(newNodeIndex);
                    if currentCost < bestCost
                        bestCost = currentCost;
                        bestPath = extractPath(planningTree, newNodeIndex);
                        fprintf('New best path found: cost = %.2f, iteration = %d\n', bestCost, iterationIndex);
                    end
                end
            end
        end
        
        % Progress reporting
        if mod(iterationIndex, 1000) == 0
            fprintf('Progress: %d/%d iterations, nodes: %d, best cost: %.2f\n', ...
                    iterationIndex, maxIterations, planningTree.nodeCount, bestCost);
        end
    end
    
    % Smooth final path if found
    if ~isempty(bestPath)
        optimalPath = smoothPath(bestPath, windField, obstacleList, planningParams);
        fprintf('Path planning completed successfully\n');
        fprintf('Final path length: %.1f m, flight time: %.1f s\n', ...
                calculatePathLength(optimalPath), optimalPath(end, 4) - optimalPath(1, 4));
    else
        optimalPath = [];
        fprintf('No path found within iteration limit\n');
    end
end
