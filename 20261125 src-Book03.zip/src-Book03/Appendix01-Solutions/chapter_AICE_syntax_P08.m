%% chapter_AICE_syntax_P08.m
% Rank-based evaluation syntax.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AICE_syntax_P08
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
[~, rankedIndices] = sort(scores, 'descend');
relevantRank = find(rankedIndices == groundTruthIdx, 1);
reciprocalRank = 1 / relevantRank;
% - Computational Complexity -
% sort is O(d log d) for d clauses; find is O(d). With d in
% the tens or hundreds, evaluation is instantaneous.
