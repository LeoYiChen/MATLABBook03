%% css_hotspot.m
% Crime hotspot detection with base MATLAB.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : css_hotspot
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [densityGrid, numHotspots] = mapCrimeHotspots(xCoord, yCoord, gridSize)
% mapCrimeHotspots  Smoothed 2-D density and hotspot count.
%   [densityGrid, numHotspots] = mapCrimeHotspots(xCoord, yCoord, gridSize)
%   Author: Dr Leo Chen | Version 1.0 | Base MATLAB (R2021b+)

    xEdges = linspace(min(xCoord), max(xCoord), gridSize + 1);
    yEdges = linspace(min(yCoord), max(yCoord), gridSize + 1);
    counts = histcounts2(xCoord, yCoord, xEdges, yEdges);

    kernelRadius = 3; sigma = 1.5;
    [kx, ky] = meshgrid(-kernelRadius:kernelRadius, -kernelRadius:kernelRadius);
    kernel = exp(-(kx.^2 + ky.^2) / (2 * sigma^2));
    kernel = kernel / sum(kernel(:));

    densityGrid = conv2(counts, kernel, 'same');

    threshold = mean(densityGrid(:)) + 2 * std(densityGrid(:));
    numHotspots = nnz(densityGrid > threshold);

    imagesc(densityGrid); axis xy; colorbar;
    xlabel('$x\ \mathrm{grid}$', 'Interpreter', 'latex');
    ylabel('$y\ \mathrm{grid}$', 'Interpreter', 'latex');
    title('$\mathrm{Crime\ density\ estimate}$', 'Interpreter', 'latex');
end
