%% p24.m
% MATLABBook03_ChapterAIBHS_Problem24.m
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : p24
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function MATLABBook03_ChapterAIBHS_Problem24
% Purpose: kNN touch/pressure classification from soft-robot sensors.
% Author: Dr Leo Chen. R2024b + Statistics ML. v1.0 2025-06-01.
    rng(0); nPer=100; noContact=0.1*randn(nPer,3);
    light=0.5+0.1*randn(nPer,3); firm=1.5+0.2*randn(nPer,3);
    X=[noContact;light;firm];
    y=categorical([repmat("none",nPer,1);repmat("light",nPer,1);repmat("firm",nPer,1)]);
    cv=cvpartition(y,'HoldOut',0.3); tr=training(cv); te=test(cv);
    model=fitcknn(X(tr,:),y(tr),'NumNeighbors',5);
    fprintf('Touch-classification accuracy: %.3f\n', mean(predict(model,X(te,:))==y(te)));
end
