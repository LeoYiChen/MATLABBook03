%% chapter_AE_Problems_P19_HypersonicNavigation.m
% Advanced sensor fusion for hypersonic vehicle navigation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AE_Problems_P19_HypersonicNavigation
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [navigationResults, sensorPerformance, systemReliability] = hypersonicAdvancedSensorFusion(vehicleConfig, flightProfile, sensorSuite, navigationConfig)
    % Advanced sensor fusion for hypersonic vehicle navigation
    % Author: Dr Leo Chen
    % Version: 3.0.0 - AI-enhanced multi-modal sensor fusion
    % Date: 2024-11-14
    
    fprintf('Advanced Hypersonic Vehicle Navigation System\n');
    fprintf('Flight velocity: Mach %.1f-%.1f, Altitude: %.0f-%.0f km\n', ...
            flightProfile.minMach, flightProfile.maxMach, ...
            flightProfile.minAltitude / 1000, flightProfile.maxAltitude / 1000);
    fprintf('Peak acceleration: %.1f g, Peak temperature: %.0f--C\n', ...
            flightProfile.maxAcceleration / 9.81, flightProfile.maxTemperature);
    fprintf('GPS availability: %.0f%% of flight time\n', flightProfile.gpsAvailability * 100);
    
    %% Phase 1: Extreme Environment Sensor Suite Design
    
    % Design hardened inertial navigation system
    [hardenedINS, insSpecifications] = designHardenedINS(vehicleConfig, flightProfile, sensorSuite);
    
    # Terrain-aided navigation system
    [terrainAidedNav, tanSpecifications] = designTerrainAidedNavigation(vehicleConfig, flightProfile, sensorSuite);
    
    % Stellar navigation system for GPS-denied operation
    [stellarNavigation, stellarSpecifications] = designStellarNavigation(vehicleConfig, flightProfile, sensorSuite);
    
    # Synthetic aperture radar for all-weather navigation
    [syntheticApertureRadar, sarSpecifications] = designSyntheticApertureRadar(vehicleConfig, flightProfile, sensorSuite);
    
    % Environmental sensors for adaptive operation
    [environmentalSensors, envSpecifications] = designEnvironmentalSensors(vehicleConfig, flightProfile, sensorSuite);
    
    fprintf('Hypersonic sensor suite designed\n');
    fprintf('  Hardened sensors: %d systems, Total mass: %.1f kg\n', ...
            length(fieldnames(hardenedINS)), calculateTotalSensorMass(hardenedINS, terrainAidedNav, stellarNavigation));
    fprintf('  Operating temperature range: %.0f to %.0f--C\n', ...
            insSpecifications.minOperatingTemp, insSpecifications.maxOperatingTemp);
    
    %% Phase 2: Multi-Modal Sensor Fusion Architecture
    
    % Initialize advanced particle filter for nonlinear navigation
    [particleFilter, pfConfiguration] = initializeAdvancedParticleFilter(navigationConfig, flightProfile);
    
    # AI-enhanced sensor fusion using neural networks
    [neuralFusion, neuralNetworkConfig] = initializeNeuralSensorFusion(sensorSuite, navigationConfig);
    
    % Adaptive Kalman filtering with online parameter estimation
    [adaptiveKalman, adaptiveConfig] = initializeAdaptiveKalmanFilter(sensorSuite, flightProfile);
    
    # Fault-tolerant fusion architecture
    [faultTolerantFusion, redundancyConfig] = initializeFaultTolerantFusion(sensorSuite, navigationConfig);
    
    fprintf('Sensor fusion architecture initialized\n');
    fprintf('  Particle filter: %d particles, Neural network: %d-layer architecture\n', ...
            pfConfiguration.numParticles, length(neuralNetworkConfig.layerSizes));
    fprintf('  Fault tolerance: %.1f%% operation with %d sensor failures\n', ...
            redundancyConfig.operationalThreshold * 100, redundancyConfig.maxFailures);
    
    %% Phase 3: Hypersonic Flight Simulation
    
    % Flight profile discretization
    timeStep = navigationConfig.timeStep;
    totalFlightTime = flightProfile.flightDuration;
    timeVector = 0:timeStep:totalFlightTime;
    numTimeSteps = length(timeVector);
    
    # Initialize flight state
    flightState = struct();
    flightState.position = flightProfile.initialPosition;
    flightState.velocity = flightProfile.initialVelocity;
    flightState.attitude = flightProfile.initialAttitude;
    flightState.acceleration = [0; 0; 0];
    
    % Initialize navigation arrays
    trueTrajectory = zeros(6, numTimeSteps); % Position and velocity
    estimatedTrajectory = zeros(6, numTimeSteps);
    navigationErrors = zeros(6, numTimeSteps);
    sensorAvailability = zeros(length(fieldnames(sensorSuite)), numTimeSteps);
    
    # Environmental condition tracking
    thermalConditions = zeros(numTimeSteps, 1);
    accelerationHistory = zeros(3, numTimeSteps);
    gpsAvailabilityHistory = zeros(numTimeSteps, 1);
    
    fprintf('Starting hypersonic flight simulation...\n');
    fprintf('  Flight duration: %.1f minutes, Time steps: %d\n', totalFlightTime / 60, numTimeSteps);
    
    for timeIndex = 1:numTimeSteps
        currentTime = timeVector(timeIndex);
        
        %% Phase 3.1: Flight Dynamics Propagation
        
        # Update hypersonic flight dynamics
        [newFlightState, aerodynamicForces] = propagateHypersonicDynamics(flightState, vehicleConfig, timeStep);
        
        % Calculate environmental conditions
        [currentEnvironment, thermalEffects] = calculateEnvironmentalConditions(newFlightState, flightProfile);
        
        # Store true trajectory
        trueTrajectory(:, timeIndex) = [newFlightState.position; newFlightState.velocity];
        thermalConditions(timeIndex) = currentEnvironment.temperature;
        accelerationHistory(:, timeIndex) = newFlightState.acceleration;
        
        %% Phase 3.2: Sensor Measurements and Degradation
        
        % INS measurements with thermal degradation
        [insMeasurements, insHealth] = generateINSMeasurements(hardenedINS, newFlightState, currentEnvironment);
        
        # GPS measurements (limited availability)
        [gpsMeasurements, gpsAvailable] = generateGPSMeasurements(newFlightState, currentEnvironment, flightProfile);
        gpsAvailabilityHistory(timeIndex) = gpsAvailable;
        
        % Terrain-aided navigation measurements
        [tanMeasurements, tanQuality] = generateTANMeasurements(terrainAidedNav, newFlightState, currentEnvironment);
        
        # Stellar navigation measurements
        [stellarMeasurements, stellarQuality] = generateStellarMeasurements(stellarNavigation, newFlightState, currentEnvironment);
        
        % SAR measurements
        [sarMeasurements, sarQuality] = generateSARMeasurements(syntheticApertureRadar, newFlightState, currentEnvironment);
        
        # Store sensor availability
        sensorAvailability(:, timeIndex) = [insHealth.operationalPercentage; gpsAvailable; tanQuality.qualityScore; ...
                                           stellarQuality.qualityScore; sarQuality.qualityScore];
        
        %% Phase 3.3: Advanced Multi-Modal Sensor Fusion
        
        % Consolidate all sensor measurements
        allMeasurements = struct();
        allMeasurements.ins = insMeasurements;
        allMeasurements.gps = gpsMeasurements;
        allMeasurements.tan = tanMeasurements;
        allMeasurements.stellar = stellarMeasurements;
        allMeasurements.sar = sarMeasurements;
        allMeasurements.availability = sensorAvailability(:, timeIndex);
        
        # Particle filter update
        [pfEstimate, pfCovariance] = updateParticleFilter(particleFilter, allMeasurements, timeStep);
        
        % Neural network sensor fusion
        [neuralEstimate, neuralConfidence] = updateNeuralSensorFusion(neuralFusion, allMeasurements, timeStep);
        
        # Adaptive Kalman filter update
        [adaptiveEstimate, adaptiveCovariance] = updateAdaptiveKalmanFilter(adaptiveKalman, allMeasurements, timeStep);
        
        % Fault-tolerant fusion
        [faultTolerantEstimate, systemHealth] = updateFaultTolerantFusion(faultTolerantFusion, allMeasurements, ...
                                                                          [pfEstimate, neuralEstimate, adaptiveEstimate]);
        
        #% Meta-fusion of multiple estimators
        [finalEstimate, estimationCovariance] = performMetaFusion(pfEstimate, neuralEstimate, adaptiveEstimate, ...
                                                                  faultTolerantEstimate, navigationConfig);
        
        %% Phase 3.4: Navigation State Update and Error Analysis
        
        # Store estimated trajectory
        estimatedTrajectory(:, timeIndex) = finalEstimate.stateVector;
        navigationErrors(:, timeIndex) = finalEstimate.stateVector - trueTrajectory(:, timeIndex);
        
        % Update filter states for next iteration
        particleFilter = updateParticleFilterState(particleFilter, finalEstimate);
        neuralFusion = updateNeuralFusionState(neuralFusion, finalEstimate);
        adaptiveKalman = updateAdaptiveKalmanState(adaptiveKalman, finalEstimate);
        
        # State propagation for next time step
        flightState = newFlightState;
        
        % Progress reporting
        if mod(timeIndex, round(numTimeSteps/20)) == 0
            progress = timeIndex / numTimeSteps * 100;
            currentMach = norm(newFlightState.velocity) / 343; % Approximate speed of sound
            positionError = norm(navigationErrors(1:3, timeIndex));
            
            fprintf('  Progress: %.0f%%, Mach %.1f, Position error: %.1f m\n', ...
                    progress, currentMach, positionError);
        end
    end
    
    fprintf('Hypersonic flight simulation completed\n');
    
    %% Phase 4: Navigation Performance Analysis
    
    # Position and velocity accuracy assessment
    [positionAccuracy, velocityAccuracy] = analyzeNavigationAccuracy(navigationErrors, timeVector);
    
    % Sensor contribution analysis
    [sensorContributions, fusionEffectiveness] = analyzeSensorContributions(sensorAvailability, navigationErrors, timeVector);
    
    # Filter performance comparison
    [filterComparison, bestPerformingFilter] = compareFilterPerformance(pfEstimate, neuralEstimate, adaptiveEstimate, ...
                                                                        faultTolerantEstimate, navigationErrors);
    
    % Environmental impact analysis
    [environmentalImpacts, correlationAnalysis] = analyzeEnvironmentalImpacts(thermalConditions, accelerationHistory, ...
                                                                              navigationErrors, sensorAvailability);
    
    fprintf('Navigation performance analysis completed\n');
    fprintf('  Position accuracy (RMS): %.1f m\n', positionAccuracy.rmsError);
    fprintf('  Velocity accuracy (RMS): %.1f m/s\n', velocityAccuracy.rmsError);
    fprintf('  Best performing filter: %s\n', bestPerformingFilter.filterType);
    
    %% Phase 5: Sensor System Performance Evaluation
    
    # Individual sensor performance assessment
    [sensorPerformanceMetrics, sensorReliability] = evaluateIndividualSensorPerformance(hardenedINS, terrainAidedNav, ...
                                                                                         stellarNavigation, syntheticApertureRadar, ...
                                                                                         sensorAvailability, timeVector);
    
    % Sensor degradation modeling
    [degradationModels, lifetimeEstimates] = modelSensorDegradation(sensorPerformanceMetrics, thermalConditions, ...
                                                                   accelerationHistory, flightProfile);
    
    # Sensor fusion algorithm performance
    [fusionAlgorithmMetrics, algorithmEfficiency] = evaluateFusionAlgorithmPerformance(particleFilter, neuralFusion, ...
                                                                                       adaptiveKalman, faultTolerantFusion, ...
                                                                                       navigationErrors);
    
    % Real-time computational requirements
    [computationalMetrics, processingLoad] = analyzeComputationalRequirements(fusionAlgorithmMetrics, navigationConfig);
    
    fprintf('Sensor system evaluation completed\n');
    fprintf('  Sensor reliability: %.1f%% average availability\n', mean(sensorReliability.availabilityScores) * 100);
    fprintf('  Computational load: %.1f%% of available processing\n', processingLoad.averageUtilization * 100);
    
    %% Phase 6: Fault Tolerance and Robustness Analysis
    
    # Sensor failure scenarios
    [sensorFailureAnalysis, failureImpacts] = analyzeSensorFailureScenarios(sensorSuite, navigationErrors, sensorAvailability);
    
    % GPS blackout performance
    [gpsBlackoutAnalysis, autonomousCapability] = analyzeGPSBlackoutPerformance(gpsAvailabilityHistory, navigationErrors, timeVector);
    
    # Extreme environment robustness
    [extremeEnvironmentAnalysis, robustnessMetrics] = analyzeExtremeEnvironmentRobustness(thermalConditions, ...
                                                                                          accelerationHistory, ...
                                                                                          navigationErrors, flightProfile);
    
    % Communication system integration
    [communicationIntegration, dataLinkPerformance] = analyzeCommunicationIntegration(estimatedTrajectory, vehicleConfig, flightProfile);
    
    fprintf('Fault tolerance analysis completed\n');
    fprintf('  GPS blackout capability: %.1f%% navigation accuracy maintained\n', autonomousCapability.accuracyRetention * 100);
    fprintf('  Extreme environment robustness: %.1f%% operational capability\n', robustnessMetrics.operationalCapability * 100);
    
    %% Phase 7: Advanced AI Enhancement Analysis
    
    # Machine learning adaptation performance
    [mlAdaptationMetrics, learningEffectiveness] = analyzeMLAdaptation(neuralFusion, navigationErrors, sensorAvailability);
    
    % Predictive navigation using AI
    [predictiveNavigation, predictionAccuracy] = analyzePredictiveNavigation(neuralFusion, flightProfile, navigationErrors);
    
    # Anomaly detection and mitigation
    [anomalyDetection, mitigationEffectiveness] = analyzeAnomalyDetection(faultTolerantFusion, sensorAvailability, navigationErrors);
    
    % Adaptive algorithm optimization
    [adaptiveOptimization, optimizationGains] = analyzeAdaptiveOptimization(adaptiveKalman, environmentalImpacts, navigationErrors);
    
    fprintf('AI enhancement analysis completed\n');
    fprintf('  ML adaptation effectiveness: %.1f%% performance improvement\n', learningEffectiveness.performanceGain * 100);
    fprintf('  Predictive navigation accuracy: %.1f%% trajectory prediction\n', predictionAccuracy.overallAccuracy * 100);
    
    %% Phase 8: Results Compilation
    
    navigationResults = struct();
    navigationResults.trajectoryComparison = struct('true', trueTrajectory, 'estimated', estimatedTrajectory, 'errors', navigationErrors);
    navigationResults.accuracyMetrics = struct('position', positionAccuracy, 'velocity', velocityAccuracy);
    navigationResults.environmentalConditions = struct('thermal', thermalConditions, 'acceleration', accelerationHistory, ...
                                                       'gpsAvailability', gpsAvailabilityHistory);
    navigationResults.fusionPerformance = filterComparison;
    
    sensorPerformance = struct();
    sensorPerformance.individualMetrics = sensorPerformanceMetrics;
    sensorPerformance.availabilityHistory = sensorAvailability;
    sensorPerformance.degradationModels = degradationModels;
    sensorPerformance.fusionAlgorithmMetrics = fusionAlgorithmMetrics;
    sensorPerformance.computationalMetrics = computationalMetrics;
    
    systemReliability = struct();
    systemReliability.sensorFailureAnalysis = sensorFailureAnalysis;
    systemReliability.gpsBlackoutCapability = autonomousCapability;
    systemReliability.extremeEnvironmentRobustness = robustnessMetrics;
    systemReliability.aiEnhancementMetrics = struct('mlAdaptation', learningEffectiveness, 'predictiveNav', predictionAccuracy, ...
                                                    'anomalyDetection', mitigationEffectiveness);
    systemReliability.overallReliability = calculateOverallSystemReliability(sensorReliability, autonomousCapability, robustnessMetrics);
    
    %% Phase 9: Comprehensive visualisation
    
    fprintf('Creating comprehensive hypersonic navigation analysis...\n');
    
    # Create analysis figure
    figure('Name', 'Advanced Hypersonic Vehicle Navigation System', 'Position', [100, 100, 1600, 1200]);
    
    % 3D trajectory visualisation
    subplot(3,4,1);
    plot3(trueTrajectory(1,:)/1000, trueTrajectory(2,:)/1000, trueTrajectory(3,:)/1000, 'b-', 'LineWidth', 2);
    hold on;
    plot3(estimatedTrajectory(1,:)/1000, estimatedTrajectory(2,:)/1000, estimatedTrajectory(3,:)/1000, 'r--', 'LineWidth', 2);
    xlabel('X (km)'); ylabel('Y (km)'); zlabel('Z (km)'); title('Flight Trajectory');
    legend({'True', 'Estimated'}); grid on;
    
    # Navigation error evolution
    subplot(3,4,2);
    positionErrors = vecnorm(navigationErrors(1:3, :));
    plot(timeVector / 60, positionErrors, 'r-', 'LineWidth', 2);
    xlabel('Time (minutes)'); ylabel('Position Error (m)'); title('Navigation Accuracy');
    grid on;
    
    % Sensor availability heatmap
    subplot(3,4,3);
    imagesc(timeVector / 60, 1:size(sensorAvailability, 1), sensorAvailability);
    xlabel('Time (minutes)'); ylabel('Sensor Index'); title('Sensor Availability');
    colorbar; colormap('hot');
    
    # Environmental conditions
    subplot(3,4,4);
    yyaxis left;
    plot(timeVector / 60, thermalConditions, 'r-', 'LineWidth', 2);
    ylabel('Temperature (--C)');
    yyaxis right;
    plot(timeVector / 60, vecnorm(accelerationHistory) / 9.81, 'b-', 'LineWidth', 2);
    ylabel('Acceleration (g)');
    xlabel('Time (minutes)'); title('Environmental Conditions');
    grid on;
    
    % Filter performance comparison
    subplot(3,4,5);
    if isfield(filterComparison, 'filterAccuracies')
        filterNames = fieldnames(filterComparison.filterAccuracies);
        accuracies = cell2mat(struct2cell(filterComparison.filterAccuracies));
        
        bar(accuracies);
        set(gca, 'XTickLabel', filterNames);
        ylabel('RMS Error (m)'); title('Filter Performance Comparison');
        grid on;
    end
    
    # GPS availability impact
    subplot(3,4,6);
    plot(timeVector / 60, gpsAvailabilityHistory, 'g-', 'LineWidth', 2);
    hold on;
    plot(timeVector / 60, positionErrors / 100, 'r-', 'LineWidth', 2); % Scaled for comparison
    xlabel('Time (minutes)'); ylabel('Normalized Value'); title('GPS Availability vs Navigation Error');
    legend({'GPS Available', 'Position Error (--100)'}); grid on;
    
    % Sensor contribution analysis
    subplot(3,4,7);
    if isfield(sensorContributions, 'contributionPercentages')
        contributions = sensorContributions.contributionPercentages;
        sensorLabels = sensorContributions.sensorLabels;
        
        pie(contributions, sensorLabels);
        title('Sensor Contribution to Navigation Accuracy');
    end
    
    # AI enhancement effectiveness
    subplot(3,4,8);
    if isfield(learningEffectiveness, 'improvementTimeline')
        improvementTimeline = learningEffectiveness.improvementTimeline;
        plot(improvementTimeline.time / 60, improvementTimeline.performanceGain * 100, 'm-', 'LineWidth', 2);
        xlabel('Time (minutes)'); ylabel('Performance Improvement (%)'); title('AI Learning Effectiveness');
        grid on;
    end
    
    % Computational load analysis
    subplot(3,4,9);
    if isfield(processingLoad, 'loadHistory')
        loadHistory = processingLoad.loadHistory;
        plot(timeVector / 60, loadHistory * 100, 'c-', 'LineWidth', 2);
        xlabel('Time (minutes)'); ylabel('CPU Utilization (%)'); title('Real-Time Processing Load');
        grid on;
    end
    
    # Fault tolerance performance
    subprocess(3,4,10);
    faultScenarios = {'Single Sensor', 'Multiple Sensors', 'GPS Blackout', 'Extreme Environment'};
    toleranceRates = [sensorFailureAnalysis.singleSensorTolerance, sensorFailureAnalysis.multipleSensorTolerance, ...
                     autonomousCapability.accuracyRetention, robustnessMetrics.operationalCapability] * 100;
    
    bar(toleranceRates);
    set(gca, 'XTickLabel', faultScenarios);
    ylabel('Performance Retention (%)'); title('Fault Tolerance Analysis');
    ylim([0, 100]); grid on;
    
    % Mission phase performance
    subplot(3,4,11);
    if isfield(positionAccuracy, 'phaseAccuracies')
        phaseNames = fieldnames(positionAccuracy.phaseAccuracies);
        phaseAccuracies = cell2mat(struct2cell(positionAccuracy.phaseAccuracies));
        
        bar(phaseAccuracies);
        set(gca, 'XTickLabel', phaseNames);
        ylabel('RMS Error (m)'); title('Performance by Flight Phase');
        grid on;
    end
    
    # Overall system performance
    subplot(3,4,12);
    overallMetrics = [positionAccuracy.rmsError / 10, % Normalize for display
                     velocityAccuracy.rmsError, ...
                     systemReliability.overallReliability.navigationReliability * 100, ...
                     learningEffectiveness.performanceGain * 100];
    metricLabels = {'Position (--10m)', 'Velocity (m/s)', 'Reliability (%)', 'AI Gain (%)'};
    
    bar(overallMetrics, 'FaceColor', 'gold');
    set(gca, 'XTickLabel', metricLabels);
    ylabel('Performance Score'); title('Overall System Performance');
    grid on;
    
    sgtitle('Advanced Hypersonic Vehicle Navigation: Comprehensive Multi-Modal Sensor Fusion');
    
    fprintf('\nHypersonic navigation analysis completed successfully!\n');
    fprintf('System performance summary:\n');
    fprintf('  Navigation accuracy: %.1f m RMS position, %.1f m/s RMS velocity\n', ...
            positionAccuracy.rmsError, velocityAccuracy.rmsError);
    fprintf('  GPS-denied operation: %.1f%% accuracy retention\n', autonomousCapability.accuracyRetention * 100);
    fprintf('  Extreme environment capability: %.1f%% operational performance\n', robustnessMetrics.operationalCapability * 100);
    fprintf('  AI enhancement: %.1f%% performance improvement over baseline\n', learningEffectiveness.performanceGain * 100);
    fprintf('  System reliability: %.1f%% overall operational capability\n', systemReliability.overallReliability.navigationReliability * 100);
    
end

% Helper functions for hypersonic navigation

function [ins, specs] = designHardenedINS(vehicleConfig, flightProfile, sensorSuite)
    % Design hardened inertial navigation system for hypersonic conditions
    
    ins = struct();
    
    # High-g accelerometers with thermal compensation
    ins.accelerometers = struct();
    ins.accelerometers.type = 'MEMS_with_thermal_compensation';
    ins.accelerometers.range = [-20, 20] * 9.81; % --20g
    ins.accelerometers.accuracy = 0.01 * 9.81; % 0.01g
    ins.accelerometers.thermalStability = 0.001; % %/--C
    
    % High-temperature gyroscopes
    ins.gyroscopes = struct();
    ins.gyroscopes.type = 'fiber_optic_gyroscope';
    ins.gyroscopes.range = [-1000, 1000] * pi/180; % --1000--/s
    ins.gyroscopes.accuracy = 0.01 * pi/180; % 0.01--/s
    ins.gyroscopes.thermalStability = 0.0005; % %/--C
    
    # Specifications
    specs = struct();
    specs.maxOperatingTemp = 1200; % --C
    specs.minOperatingTemp = -200; % --C
    specs.maxAcceleration = 20 * 9.81; % m/s?
    specs.updateRate = 1000; % Hz
    specs.mass = 2.5; % kg
    specs.powerConsumption = 15; % W
    
    fprintf('Hardened INS designed: %.0f--C operation, --%.0fg acceleration\n', ...
            specs.maxOperatingTemp, specs.maxAcceleration / 9.81);
end
