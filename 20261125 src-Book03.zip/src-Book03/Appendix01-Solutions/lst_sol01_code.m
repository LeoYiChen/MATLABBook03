%% lst_sol01_code.m
% Audio Feature Extraction and Visualisation (MATLABBook02_Chapter10_Problem01.m).
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : lst:sol01_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% MATLABBook02_Chapter10_Problem01.m
%  Audio Feature Extraction and Visualisation
%  -------------------
%  Author       : Dr Leo Chen
%  Date         : 2024-01-20
%  Modified     : 2024-07-01
%  Version      : 1.2
%  MATLAB Ver.  : R2024a
%  Toolboxes    : Audio Toolbox, Signal Processing Toolbox
%  Description  :
%    Extracts MFCCs, chroma features, and spectral
%    centroid from an audio file. Generates a
%    three-panel visualisation.
%  Change Log   :
%    v1.0 - Initial release.
%    v1.1 - Added custom chroma computation.
%    v1.2 - Improved figure formatting with LaTeX labels.
%  -------------------

%% Initialisation
clc; clear; close all;

%% --- User Parameters ------------
audioFilePath  = 'sample_audio.wav';   % Input audio file
numMFCC        = 13;                   % Number of MFCCs
windowDuration = 0.030;                % Frame length (s)
hopDuration    = 0.010;                % Hop length   (s)

%% --- Load Audio ---------------
[audioSignal, sampleRate] = audioread(audioFilePath);

% Convert to mono if stereo
if size(audioSignal, 2) > 1
    audioSignal = mean(audioSignal, 2);
end

totalDuration = length(audioSignal) / sampleRate;
fprintf('File       : %s\n', audioFilePath);
fprintf('Duration   : %.2f s\n', totalDuration);
fprintf('Sample rate: %d Hz\n', sampleRate);

%% --- Compute MFCCs -------------
windowLength = round(windowDuration * sampleRate);
hopLength    = round(hopDuration    * sampleRate);

[mfccCoefficients, ~, ~, mfccTimeLocations] = ...
    mfcc(audioSignal, sampleRate, ...
         'NumCoeffs',    numMFCC, ...
         'WindowLength', windowLength, ...
         'OverlapLength', windowLength - hopLength);

fprintf('MFCC matrix size: %d frames x %d coeffs\n', ...
        size(mfccCoefficients, 1), ...
        size(mfccCoefficients, 2));

%% --- Compute Spectral Centroid ---------
[centroidValues, centroidTimeLocations] = ...
    spectralCentroid(audioSignal, sampleRate, ...
        'WindowLength',  windowLength, ...
        'OverlapLength', windowLength - hopLength);

%% --- Compute Chroma Features ---------
chromaMatrix = computeChromaFeatures( ...
    audioSignal, sampleRate, windowLength, hopLength);

chromaPitchLabels = {'C','C\#','D','D\#','E','F', ...
                     'F\#','G','G\#','A','A\#','B'};

%% --- Visualisation -------------
figure('Position', [100 100 900 750], ...
       'Color', 'w');

% - Subplot 1: MFCCs -
subplot(3, 1, 1);
imagesc(mfccTimeLocations, 1:numMFCC, ...
        mfccCoefficients.');
axis xy; colorbar;
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('MFCC Index', 'Interpreter', 'latex');
title('Mel-Frequency Cepstral Coefficients (MFCCs)', ...
      'Interpreter', 'latex');

% - Subplot 2: Chroma Features -
subplot(3, 1, 2);
chromaTimeAxis = linspace(0, totalDuration, ...
                          size(chromaMatrix, 2));
imagesc(chromaTimeAxis, 1:12, chromaMatrix);
axis xy; colorbar;
set(gca, 'YTick', 1:12, ...
         'YTickLabel', chromaPitchLabels);
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Pitch Class', 'Interpreter', 'latex');
title('Chroma Features', 'Interpreter', 'latex');

% - Subplot 3: Spectral Centroid -
subplot(3, 1, 3);
plot(centroidTimeLocations, centroidValues, ...
     'Color', [0.0 0.4 0.8], 'LineWidth', 1.2);
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Frequency (Hz)', 'Interpreter', 'latex');
title('Spectral Centroid', 'Interpreter', 'latex');
grid on;

sgtitle(['Audio Feature Extraction: \texttt{', ...
         audioFilePath, '}'], ...
        'Interpreter', 'latex', 'FontSize', 14);

%% --- Save figure --------------
exportgraphics(gcf, ...
    'MATLABBook02_Chapter10_Problem01_output.pdf', ...
    'ContentType', 'vector');
fprintf('Figure saved.\n');

%% =========================================================
%% LOCAL FUNCTION: computeChromaFeatures
%% =========================================================
function chromaMatrix = computeChromaFeatures( ...
        audioSignal, sampleRate, windowLength, hopLength)
%COMPUTECHROMAFEATURES  Map STFT magnitudes to 12 pitch
%   classes using a logarithmic frequency-to-chroma mapping.

    nfft            = 2^nextpow2(windowLength);
    referenceFreq   = 440.0;             % A4 in Hz
    numFrames       = floor( ...
        (length(audioSignal) - windowLength) / hopLength) + 1;
    chromaMatrix    = zeros(12, numFrames);
    analysisWindow  = hann(windowLength, 'periodic');

    frequencyBins = (0:nfft/2) * sampleRate / nfft;
    % Avoid log of zero
    frequencyBins(1) = frequencyBins(2) / 2;
    pitchClassBins = mod( ...
        round(12 * log2(frequencyBins / referenceFreq)), 12);

    for frameIndex = 1:numFrames
        startSample = (frameIndex - 1) * hopLength + 1;
        endSample   = startSample + windowLength - 1;
        frameData   = audioSignal(startSample:endSample) ...
                      .* analysisWindow;
        magnitudeSpectrum = abs(fft(frameData, nfft));
        magnitudeSpectrum = ...
            magnitudeSpectrum(1:nfft/2+1);

        for pitchClass = 0:11
            binMask = (pitchClassBins == pitchClass);
            chromaMatrix(pitchClass + 1, frameIndex) = ...
                sum(magnitudeSpectrum(binMask));
        end
    end

    % Normalise each frame to unit maximum
    maxValues = max(chromaMatrix, [], 1);
    maxValues(maxValues == 0) = 1;
    chromaMatrix = chromaMatrix ./ maxValues;
end
