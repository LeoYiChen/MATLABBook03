%% chapter_AI_CV_problem7_snn.m
% Spiking neural network syntax.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AI_CV_problem7_snn
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Create LIF neuron
neuron = createLIFNeuron(tau_membrane, threshold, reset);

% Process spike train
[outputSpikes, voltageTrace] = processSpikeTrain(neuron, inputSpikes);
