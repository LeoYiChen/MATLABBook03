%% chapter_AE_Problems_P8_ElectricActuator.m
% Advanced electric actuator system with adaptive control.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AE_Problems_P8_ElectricActuator
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [actuatorResponse, controllerState, performanceMetrics] = advancedElectricActuator(commandSignal, operatingConditions, actuatorConfig, controlConfig)
    % Advanced electric actuator system with adaptive control and health monitoring
    % Author: Dr Leo Chen
    % Version: 2.5.0 - Enhanced fault tolerance and smart material integration
    % Date: 2024-11-14
    
    fprintf('Advanced Electric Actuator System\n');
    fprintf('Actuator type: %s, Max force: %.1f kN\n', ...
            actuatorConfig.actuatorType, actuatorConfig.maxForce / 1000);
    fprintf('Operating temperature: %.1f--C, Supply voltage: %.1f V\n', ...
            operatingConditions.temperature, operatingConditions.supplyVoltage);
    fprintf('Control algorithm: %s\n', controlConfig.controllerType);
    
    % Initialize system state
    persistent actuatorState controllerState systemHealth isInitialized
    
    if isempty(isInitialized)
        % Initialize actuator physical model
        actuatorState = initializeActuatorState(actuatorConfig);
        
        % Initialize adaptive controller
        controllerState = initializeAdaptiveController(controlConfig);
        
        % Initialize health monitoring system
        systemHealth = initializeHealthMonitoring(actuatorConfig);
        
        isInitialized = true;
        fprintf('Electric actuator system initialized\n');
    end
    
    %% Phase 1: Environmental Adaptation and Compensation
    
    % Temperature compensation for motor parameters
    [temperatureCompensation, thermalState] = compensateTemperatureEffects(operatingConditions.temperature, actuatorConfig);
    
    % Voltage compensation for supply variations
    [voltageCompensation, powerState] = compensateVoltageVariations(operatingConditions.supplyVoltage, actuatorConfig);
    
    % Vibration and shock compensation
    [vibrationCompensation, mechanicalState] = compensateVibrationEffects(operatingConditions.vibration, actuatorConfig);
    
    fprintf('Environmental compensation applied\n');
    fprintf('  Temperature compensation: %.2f%% parameter adjustment\n', temperatureCompensation.parameterAdjustment * 100);
    fprintf('  Voltage compensation: %.2f%% power adjustment\n', voltageCompensation.powerAdjustment * 100);
    
    %% Phase 2: Advanced Motor Control
    
    % High-performance motor drive with field-oriented control
    [motorControl, motorState] = performFieldOrientedControl(commandSignal, actuatorState, temperatureCompensation, controlConfig);
    
    % Advanced PWM generation with harmonic minimization
    [pwmSignals, harmonicContent] = generateAdvancedPWM(motorControl, operatingConditions, controlConfig);
    
    % Electromagnetic interference mitigation
    [emiMitigation, emCompatibility] = mitigateEMI(pwmSignals, actuatorConfig.emiRequirements);
    
    fprintf('Motor control executed\n');
    fprintf('  Motor efficiency: %.1f%%, Harmonic distortion: %.2f%%\n', ...
            motorState.efficiency * 100, harmonicContent.totalHarmonicDistortion * 100);
    
    %% Phase 3: Adaptive Control Implementation
    
    % Model Reference Adaptive Control (MRAC)
    if strcmp(controlConfig.controllerType, 'MRAC')
        [adaptiveOutput, adaptationGains] = performMRAC(commandSignal, actuatorState.position, ...
                                                        controllerState, controlConfig);
        controllerState.adaptationGains = adaptationGains;
        
    % Model Predictive Control (MPC)
    elseif strcmp(controlConfig.controllerType, 'MPC')
        [adaptiveOutput, predictiveHorizon] = performMPC(commandSignal, actuatorState, ...
                                                        operatingConditions, controllerState, controlConfig);
        controllerState.predictiveHorizon = predictiveHorizon;
        
    % Sliding Mode Control with adaptive gains
    elseif strcmp(controlConfig.controllerType, 'SMC')
        [adaptiveOutput, slidingSurface] = performSlidingModeControl(commandSignal, actuatorState, ...
                                                                    controllerState, controlConfig);
        controllerState.slidingSurface = slidingSurface;
        
    % Neural Network Adaptive Control
    elseif strcmp(controlConfig.controllerType, 'NNAC')
        [adaptiveOutput, neuralWeights] = performNeuralNetworkControl(commandSignal, actuatorState, ...
                                                                     controllerState, controlConfig);
        controllerState.neuralWeights = neuralWeights;
    end
    
    fprintf('Adaptive control applied: %s\n', controlConfig.controllerType);
    fprintf('  Control effort: %.2f%% of maximum\n', norm(adaptiveOutput) / controlConfig.maxControlEffort * 100);
    
    %% Phase 4: Smart Material Integration
    
    % Shape Memory Alloy (SMA) actuator assistance
    if actuatorConfig.enableSMA
        [smaContribution, smaState] = applySMAAssistance(adaptiveOutput, operatingConditions.temperature, actuatorConfig.smaConfig);
        totalActuatorForce = adaptiveOutput + smaContribution;
        fprintf('SMA assistance: %.1f N additional force\n', norm(smaContribution));
    else
        totalActuatorForce = adaptiveOutput;
        smaState = [];
    end
    
    % Piezoelectric fine positioning
    if actuatorConfig.enablePiezo
        [piezoContribution, piezoState] = applyPiezoelectricFineControl(commandSignal, actuatorState.position, actuatorConfig.piezoConfig);
        totalActuatorForce = totalActuatorForce + piezoContribution;
        fprintf('Piezoelectric fine control: %.3f mm precision enhancement\n', norm(piezoContribution) * 1000);
    else
        piezoState = [];
    end
    
    %% Phase 5: Health Monitoring and Fault Detection
    
    % Sensor data acquisition and processing
    [sensorData, sensorHealth] = acquireSensorData(actuatorState, motorState, operatingConditions, actuatorConfig);
    
    % Fault detection using multiple techniques
    [faultDetection, faultProbabilities] = performFaultDetection(sensorData, systemHealth, actuatorConfig.faultDetection);
    
    % Health assessment using machine learning
    [healthAssessment, remainingUsefulLife] = assessActuatorHealth(sensorData, systemHealth, actuatorConfig.healthMonitoring);
    
    % Predictive maintenance recommendations
    [maintenanceRecommendations, maintenancePriority] = generateMaintenanceRecommendations(healthAssessment, faultDetection, actuatorConfig);
    
    fprintf('Health monitoring completed\n');
    fprintf('  System health: %.1f%%, Remaining useful life: %.0f hours\n', ...
            healthAssessment.overallHealth * 100, remainingUsefulLife);
    fprintf('  Fault probability: %.2f%%, Maintenance priority: %s\n', ...
            max(faultProbabilities) * 100, maintenancePriority);
    
    %% Phase 6: Fault Tolerance and Recovery
    
    % Implement fault tolerant control strategies
    if any(faultProbabilities > actuatorConfig.faultThreshold)
        fprintf('Fault detected - implementing recovery strategies\n');
        
        % Reconfigure control system for fault tolerance
        [faultTolerantControl, reconfigurationSuccess] = implementFaultTolerantControl(totalActuatorForce, faultDetection, controlConfig);
        
        % Graceful degradation if necessary
        if ~reconfigurationSuccess
            [degradedControl, degradationLevel] = implementGracefulDegradation(totalActuatorForce, faultDetection, controlConfig);
            finalActuatorOutput = degradedControl;
            fprintf('Graceful degradation applied: %.0f%% capability maintained\n', (1 - degradationLevel) * 100);
        else
            finalActuatorOutput = faultTolerantControl;
            fprintf('Fault-tolerant control successfully implemented\n');
        end
    else
        finalActuatorOutput = totalActuatorForce;
    end
    
    %% Phase 7: Actuator Dynamics and Response
    
    % High-fidelity actuator dynamics model
    [actuatorResponse, newActuatorState] = simulateActuatorDynamics(finalActuatorOutput, actuatorState, ...
                                                                   operatingConditions, actuatorConfig);
    
    % Update actuator state
    actuatorState = newActuatorState;
    
    % Update system health based on operation
    systemHealth = updateSystemHealth(systemHealth, sensorData, operatingConditions, actuatorConfig);
    
    fprintf('Actuator response calculated\n');
    fprintf('  Position achieved: %.3f mm, Velocity: %.2f mm/s\n', ...
            actuatorResponse.position * 1000, actuatorResponse.velocity * 1000);
    fprintf('  Force output: %.1f N, Power consumption: %.1f W\n', ...
            actuatorResponse.force, actuatorResponse.power);
    
    %% Phase 8: Performance Metrics Calculation
    
    % Calculate comprehensive performance metrics
    performanceMetrics = struct();
    
    % Control performance
    performanceMetrics.positionError = abs(commandSignal.position - actuatorResponse.position);
    performanceMetrics.settlingTime = calculateSettlingTime(actuatorResponse.positionHistory, commandSignal.position);
    performanceMetrics.overshoot = calculateOvershoot(actuatorResponse.positionHistory, commandSignal.position);
    
    % Energy efficiency
    performanceMetrics.energyEfficiency = actuatorResponse.mechanicalPower / actuatorResponse.electricalPower;
    performanceMetrics.powerDensity = actuatorResponse.force / actuatorResponse.power; % N/W
    
    % Reliability metrics
    performanceMetrics.systemReliability = calculateSystemReliability(systemHealth, faultProbabilities);
    performanceMetrics.mtbf = calculateMTBF(systemHealth, operatingConditions); % Mean Time Between Failures
    
    % Environmental performance
    performanceMetrics.thermalPerformance = evaluateThermalPerformance(thermalState, operatingConditions, actuatorConfig);
    performanceMetrics.emiCompliance = evaluateEMICompliance(emCompatibility, actuatorConfig.emiRequirements);
    
    fprintf('Performance metrics calculated\n');
    fprintf('  Position error: %.3f mm, Energy efficiency: %.1f%%\n', ...
            performanceMetrics.positionError * 1000, performanceMetrics.energyEfficiency * 100);
    fprintf('  System reliability: %.2f%%, MTBF: %.0f hours\n', ...
            performanceMetrics.systemReliability * 100, performanceMetrics.mtbf);
    
    %% Phase 9: Data Logging and Analysis
    
    % Log operational data for analysis
    operationalData = struct();
    operationalData.timestamp = datetime('now');
    operationalData.commandSignal = commandSignal;
    operationalData.actuatorResponse = actuatorResponse;
    operationalData.operatingConditions = operatingConditions;
    operationalData.performanceMetrics = performanceMetrics;
    operationalData.systemHealth = systemHealth;
    
    % Store data for trend analysis
    if ~isfield(controllerState, 'dataLog')
        controllerState.dataLog = operationalData;
    else
        controllerState.dataLog(end + 1) = operationalData;
    end
    
    % Perform trend analysis if sufficient data available
    if length(controllerState.dataLog) > 100
        [trendAnalysis, performanceTrends] = analyzeTrends(controllerState.dataLog);
        controllerState.trendAnalysis = trendAnalysis;
        
        fprintf('Trend analysis updated: %d data points analyzed\n', length(controllerState.dataLog));
        if ~isempty(performanceTrends.degradationDetected)
            fprintf('Performance degradation detected in: %s\n', strjoin(performanceTrends.degradationDetected, ', '));
        end
    end
    
    fprintf('\nAdvanced electric actuator operation completed successfully!\n');
    
end

% Helper functions for electric actuator control

function state = initializeActuatorState(config)
    % Initialize actuator physical state
    
    state = struct();
    state.position = 0;                    % Current position [m]
    state.velocity = 0;                    % Current velocity [m/s]
    state.acceleration = 0;                % Current acceleration [m/s?]
    state.force = 0;                       % Current force output [N]
    state.temperature = 20;                % Current temperature [--C]
    state.motorCurrent = 0;                % Motor current [A]
    state.motorVoltage = 0;                % Motor voltage [V]
    state.backEMF = 0;                     % Back EMF [V]
    
    % Physical parameters from configuration
    state.mass = config.movingMass;        % Moving mass [kg]
    state.damping = config.dampingCoeff;   % Damping coefficient [Ns/m]
    state.stiffness = config.stiffness;    % System stiffness [N/m]
    state.motorConstant = config.motorConstant; % Motor constant [N/A]
    state.backEMFConstant = config.backEMFConstant; % Back EMF constant [V?s/m]
    
    % Limits
    state.positionLimits = config.positionLimits; % [min, max] [m]
    state.velocityLimit = config.velocityLimit;   % Maximum velocity [m/s]
    state.forceLimit = config.forceLimit;         % Maximum force [N]
    state.currentLimit = config.currentLimit;     % Maximum current [A]
    
    fprintf('Actuator state initialized: Mass %.2f kg, Force limit %.1f N\n', ...
            state.mass, state.forceLimit);
end

function controllerState = initializeAdaptiveController(config)
    % Initialize adaptive controller state
    
    controllerState = struct();
    
    % Controller gains (will be adapted)
    controllerState.Kp = config.initialGains.Kp;  % Proportional gain
    controllerState.Ki = config.initialGains.Ki;  % Integral gain
    controllerState.Kd = config.initialGains.Kd;  % Derivative gain
    
    % Adaptive parameters
    controllerState.adaptationGain = config.adaptationGain;
    controllerState.adaptationRate = config.adaptationRate;
    
    % Error history for integral and derivative calculations
    controllerState.errorHistory = [];
    controllerState.timeHistory = [];
    
    % Reference model parameters
    if strcmp(config.controllerType, 'MRAC')
        controllerState.referenceModel = config.referenceModel;
    end
    
    % MPC parameters
    if strcmp(config.controllerType, 'MPC')
        controllerState.predictionHorizon = config.predictionHorizon;
        controllerState.controlHorizon = config.controlHorizon;
        controllerState.weights = config.weights;
    end
    
    % Neural network parameters
    if strcmp(config.controllerType, 'NNAC')
        controllerState.networkArchitecture = config.networkArchitecture;
        controllerState.neuralWeights = initializeNeuralWeights(config.networkArchitecture);
        controllerState.learningRate = config.learningRate;
    end
    
    fprintf('Adaptive controller initialized: %s\n', config.controllerType);
end

function [motorControl, motorState] = performFieldOrientedControl(commandSignal, actuatorState, compensation, config)
    % Implement field-oriented control for high-performance motor drive
    
    % Current motor state
    currentPosition = actuatorState.position;
    currentVelocity = actuatorState.velocity;
    currentCurrent = actuatorState.motorCurrent;
    
    % Position control loop
    positionError = commandSignal.position - currentPosition;
    
    % Velocity feedforward and feedback
    velocityCommand = commandSignal.velocity + config.positionGain * positionError;
    velocityError = velocityCommand - currentVelocity;
    
    % Current command from velocity controller
    currentCommand = config.velocityGain * velocityError + config.feedforwardGain * commandSignal.acceleration;
    
    % Apply temperature compensation
    compensatedCurrentCommand = currentCommand * compensation.currentCompensation;
    
    % Current control with field-oriented control
    % Simplified FOC implementation
    directCurrent = 0;  % For surface-mounted PMSM, set Id = 0
    quadratureCurrent = compensatedCurrentCommand;
    
    % Transform to three-phase currents (simplified)
    theta = mod(currentPosition * config.motorPoles / 2, 2*pi); % Electrical angle
    
    % Clarke and Park transformations
    alpha = quadratureCurrent * cos(theta);
    beta = quadratureCurrent * sin(theta);
    
    % Three-phase current commands
    ia = alpha;
    ib = -0.5 * alpha + sqrt(3)/2 * beta;
    ic = -0.5 * alpha - sqrt(3)/2 * beta;
    
    motorControl = struct();
    motorControl.currentCommands = [ia, ib, ic];
    motorControl.directCurrent = directCurrent;
    motorControl.quadratureCurrent = quadratureCurrent;
    motorControl.electricalAngle = theta;
    
    % Motor state update
    motorState = struct();
    motorState.torque = config.torqueConstant * quadratureCurrent;
    motorState.backEMF = config.backEMFConstant * currentVelocity;
    motorState.efficiency = calculateMotorEfficiency(quadratureCurrent, currentVelocity, config);
    motorState.losses = calculateMotorLosses(quadratureCurrent, config);
    motorState.temperature = actuatorState.temperature + motorState.losses * config.thermalResistance;
end

function efficiency = calculateMotorEfficiency(current, velocity, config)
    % Calculate motor efficiency considering various losses
    
    % Copper losses (I?R)
    copperLosses = current^2 * config.windingResistance;
    
    % Iron losses (velocity dependent)
    ironLosses = config.ironLossCoeff * velocity^2;
    
    % Mechanical losses (friction and windage)
    mechanicalLosses = config.frictionCoeff * velocity + config.windageCoeff * velocity^2;
    
    % Total losses
    totalLosses = copperLosses + ironLosses + mechanicalLosses;
    
    % Mechanical power output
    mechanicalPower = config.torqueConstant * current * velocity;
    
    % Electrical power input
    electricalPower = mechanicalPower + totalLosses;
    
    % Efficiency calculation
    if electricalPower > 0
        efficiency = mechanicalPower / electricalPower;
    else
        efficiency = 0;
    end
    
    % Ensure efficiency is between 0 and 1
    efficiency = min(max(efficiency, 0), 1);
end
