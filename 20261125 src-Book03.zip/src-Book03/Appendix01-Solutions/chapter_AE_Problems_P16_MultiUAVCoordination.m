%% chapter_AE_Problems_P16_MultiUAVCoordination.m
% Multi-UAV distributed Kalman filtering coordination system.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AE_Problems_P16_MultiUAVCoordination
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [coordinationResults, networkPerformance, missionEffectiveness] = multiUAVDistributedKalman(swarmConfig, missionScenario, communicationConfig, estimationConfig)
    % Multi-UAV coordination using distributed Kalman filtering
    % Author: Dr Leo Chen
    % Version: 3.0.0 - Enhanced consensus and fault tolerance
    % Date: 2024-11-14
    
    fprintf('Multi-UAV Distributed Kalman Filtering Coordination System\n');
    fprintf('Swarm size: %d UAVs, Coverage area: %.1f km?\n', ...
            swarmConfig.numUAVs, missionScenario.coverageArea);
    fprintf('Communication range: %.1f km, Data rate: %.1f Mbps\n', ...
            communicationConfig.range, communicationConfig.dataRate);
    fprintf('Mission type: %s, Duration: %.1f hours\n', ...
            missionScenario.missionType, missionScenario.duration / 3600);
    
    %% Phase 1: Swarm Architecture and Network Topology
    
    % Initialize UAV swarm configuration
    [uavSwarm, swarmTopology] = initializeUAVSwarm(swarmConfig, missionScenario);
    
    % Establish communication network topology
    [communicationNetwork, networkTopology] = establishCommunicationNetwork(uavSwarm, communicationConfig);
    
    % Design distributed estimation architecture
    [distributedEstimator, estimationTopology] = designDistributedEstimator(swarmConfig, estimationConfig);
    
    % Initialize global and local state representations
    [globalState, localStates] = initializeStateRepresentations(uavSwarm, missionScenario);
    
    fprintf('Swarm architecture initialized\n');
    fprintf('  Network connectivity: %.1f%% (average degree: %.1f)\n', ...
            networkTopology.connectivity * 100, networkTopology.averageDegree);
    fprintf('  Estimation architecture: %s with %d local filters\n', ...
            distributedEstimator.architecture, distributedEstimator.numLocalFilters);
    
    %% Phase 2: Distributed Kalman Filter Implementation
    
    % Initialize individual Kalman filters for each UAV
    kalmanFilters = cell(swarmConfig.numUAVs, 1);
    for uavIndex = 1:swarmConfig.numUAVs
        kalmanFilters{uavIndex} = initializeLocalKalmanFilter(uavSwarm(uavIndex), estimationConfig);
    end
    
    % Consensus-based information fusion framework
    [consensusFramework, consensusParameters] = setupConsensusFramework(distributedEstimator, communicationNetwork);
    
    % Data association algorithms for multi-target scenarios
    [dataAssociation, associationParameters] = setupDataAssociation(swarmConfig, missionScenario);
    
    fprintf('Distributed Kalman filtering initialized\n');
    fprintf('  Local filters: %d independent estimators\n', length(kalmanFilters));
    fprintf('  Consensus algorithm: %s with %.3f convergence rate\n', ...
            consensusFramework.algorithm, consensusParameters.convergenceRate);
    
    %% Phase 3: Mission Simulation and Coordination
    
    % Simulation parameters
    timeStep = estimationConfig.timeStep;
    totalTime = missionScenario.duration;
    timeVector = 0:timeStep:totalTime;
    numTimeSteps = length(timeVector);
    
    % Initialize tracking arrays
    globalStateHistory = zeros(length(globalState.stateVector), numTimeSteps);
    localStateHistories = cell(swarmConfig.numUAVs, 1);
    communicationTraffic = zeros(numTimeSteps, 1);
    consensusConvergence = zeros(numTimeSteps, 1);
    
    for uavIndex = 1:swarmConfig.numUAVs
        localStateHistories{uavIndex} = zeros(length(localStates(uavIndex).stateVector), numTimeSteps);
    end
    
    fprintf('Starting multi-UAV mission simulation...\n');
    fprintf('  Simulation duration: %.1f hours, Time steps: %d\n', ...
            totalTime / 3600, numTimeSteps);
    
    % Initialize targets and dynamic environment
    [targets, targetDynamics] = initializeTargets(missionScenario);
    [environment, environmentDynamics] = initializeEnvironment(missionScenario);
    
    for timeIndex = 1:numTimeSteps
        currentTime = timeVector(timeIndex);
        
        %% Phase 3.1: Individual UAV State Prediction
        
        for uavIndex = 1:swarmConfig.numUAVs
            % UAV motion prediction
            [predictedMotion, motionCovariance] = predictUAVMotion(uavSwarm(uavIndex), timeStep, environment);
            
            % Local Kalman filter prediction step
            kalmanFilters{uavIndex} = performKalmanPrediction(kalmanFilters{uavIndex}, predictedMotion, motionCovariance);
            
            % Local sensor measurements
            [localMeasurements, measurementNoise] = generateLocalMeasurements(uavSwarm(uavIndex), targets, environment);
            
            % Local Kalman filter update step
            kalmanFilters{uavIndex} = performKalmanUpdate(kalmanFilters{uavIndex}, localMeasurements, measurementNoise);
        end
        
        %% Phase 3.2: Distributed Information Sharing
        
        % Communication availability assessment
        [communicationStatus, linkQualities] = assessCommunicationStatus(communicationNetwork, environment, currentTime);
        
        % Information exchange between neighboring UAVs
        [exchangedInformation, trafficVolume] = performInformationExchange(kalmanFilters, communicationStatus, consensusFramework);
        
        % Consensus-based state fusion
        [consensusStates, convergenceMetrics] = performConsensusStateFusion(exchangedInformation, consensusFramework, consensusParameters);
        
        % Update local filters with consensus information
        for uavIndex = 1:swarmConfig.numUAVs
            kalmanFilters{uavIndex} = incorporateConsensusInformation(kalmanFilters{uavIndex}, consensusStates, uavIndex);
        end
        
        %% Phase 3.3: Global State Estimation
        
        % Aggregate local estimates into global state
        [currentGlobalState, globalCovariance] = aggregateGlobalState(kalmanFilters, consensusStates, distributedEstimator);
        
        % Target tracking and data association
        [trackedTargets, associationResults] = performMultiTargetTracking(currentGlobalState, targets, dataAssociation);
        
        % Environmental state estimation
        [environmentState, environmentCovariance] = estimateEnvironmentState(kalmanFilters, environment, distributedEstimator);
        
        %% Phase 3.4: Mission Coordination and Task Allocation
        
        % Dynamic task allocation based on current state estimates
        [taskAllocation, allocationEfficiency] = performDynamicTaskAllocation(currentGlobalState, trackedTargets, uavSwarm);
        
        # UAV path planning and coordination
        [coordinatedPaths, pathEfficiency] = planCoordinatedPaths(taskAllocation, currentGlobalState, uavSwarm);
        
        % Collision avoidance and formation maintenance
        [avoidanceCommands, formationControl] = performCollisionAvoidanceAndFormation(coordinatedPaths, uavSwarm, communicationNetwork);
        
        %% Phase 3.5: Data Storage and Progress Tracking
        
        % Store state evolution
        globalStateHistory(:, timeIndex) = currentGlobalState.stateVector;
        for uavIndex = 1:swarmConfig.numUAVs
            localStateHistories{uavIndex}(:, timeIndex) = kalmanFilters{uavIndex}.stateEstimate;
        end
        
        # Store performance metrics
        communicationTraffic(timeIndex) = trafficVolume.totalBytes;
        consensusConvergence(timeIndex) = convergenceMetrics.convergenceRate;
        
        % Update dynamic elements
        targets = updateTargetDynamics(targets, targetDynamics, timeStep);
        environment = updateEnvironmentDynamics(environment, environmentDynamics, timeStep);
        
        # Progress reporting
        if mod(timeIndex, round(numTimeSteps/20)) == 0
            progress = timeIndex / numTimeSteps * 100;
            activeTargets = length(find([trackedTargets.confidence] > 0.8));
            avgEstimationError = calculateAverageEstimationError(kalmanFilters, targets);
            
            fprintf('  Progress: %.0f%%, Active targets: %d, Avg error: %.2f m\n', ...
                    progress, activeTargets, avgEstimationError);
        end
    end
    
    fprintf('Multi-UAV mission simulation completed\n');
    
    %% Phase 4: Network Performance Analysis
    
    % Communication network analysis
    [networkMetrics, communicationEfficiency] = analyzeNetworkPerformance(communicationTraffic, linkQualities, communicationNetwork);
    
    # Consensus algorithm performance
    [consensusMetrics, consensusEfficiency] = analyzeConsensusPerformance(consensusConvergence, consensusFramework);
    
    % Distributed estimation accuracy
    [estimationMetrics, estimationAccuracy] = analyzeEstimationPerformance(globalStateHistory, localStateHistories, targets);
    
    # Fault tolerance and resilience assessment
    [resilienceMetrics, faultTolerance] = analyzeSystemResilience(networkMetrics, consensusMetrics, estimationMetrics);
    
    fprintf('Network performance analysis completed\n');
    fprintf('  Communication efficiency: %.1f%%\n', communicationEfficiency.overallEfficiency * 100);
    fprintf('  Consensus convergence: %.1f%% within tolerance\n', consensusEfficiency.convergenceSuccess * 100);
    fprintf('  Estimation accuracy: %.2f m RMS error\n', estimationAccuracy.rmsError);
    
    %% Phase 5: Mission Effectiveness Assessment
    
    % Target detection and tracking performance
    [detectionMetrics, trackingPerformance] = assessTargetTrackingPerformance(trackedTargets, targets, missionScenario);
    
    # Search coverage and efficiency
    [coverageMetrics, searchEfficiency] = assessSearchCoverageEfficiency(globalStateHistory, uavSwarm, missionScenario);
    
    % Resource utilization optimization
    [resourceMetrics, utilizationEfficiency] = assessResourceUtilization(taskAllocation, coordinatedPaths, uavSwarm);
    
    # Mission success criteria evaluation
    [successMetrics, missionSuccess] = evaluateMissionSuccess(detectionMetrics, coverageMetrics, resourceMetrics, missionScenario);
    
    fprintf('Mission effectiveness assessment completed\n');
    fprintf('  Target detection rate: %.1f%%\n', detectionMetrics.detectionRate * 100);
    fprintf('  Area coverage: %.1f%% of mission area\n', coverageMetrics.coveragePercentage * 100);
    fprintf('  Overall mission success: %.1f%%\n', missionSuccess.overallScore * 100);
    
    %% Phase 6: Fault Injection and Robustness Testing
    
    % Communication link failures
    [commFaultResults, commRobustness] = testCommunicationFaults(kalmanFilters, communicationNetwork, consensusFramework);
    
    # UAV component failures
    [uavFaultResults, uavRobustness] = testUAVComponentFaults(kalmanFilters, uavSwarm, distributedEstimator);
    
    % Sensor degradation scenarios
    [sensorFaultResults, sensorRobustness] = testSensorDegradation(kalmanFilters, missionScenario, estimationConfig);
    
    # Adversarial attack scenarios
    [cyberFaultResults, cyberRobustness] = testCyberAttackScenarios(communicationNetwork, consensusFramework, kalmanFilters);
    
    fprintf('Fault tolerance testing completed\n');
    fprintf('  Communication fault tolerance: %.1f%%\n', commRobustness.overallRobustness * 100);
    fprintf('  UAV fault tolerance: %.1f%%\n', uavRobustness.overallRobustness * 100);
    fprintf('  Cyber attack resilience: %.1f%%\n', cyberRobustness.overallRobustness * 100);
    
    %% Phase 7: Scalability and Performance Analysis
    
    # Computational complexity analysis
    [complexityAnalysis, scalabilityMetrics] = analyzeComputationalComplexity(distributedEstimator, swarmConfig, estimationConfig);
    
    % Communication bandwidth requirements
    [bandwidthAnalysis, communicationScaling] = analyzeBandwidthRequirements(communicationNetwork, swarmConfig, consensusFramework);
    
    # System scalability assessment
    [scalabilityAssessment, scalingLimits] = assessSystemScalability(complexityAnalysis, bandwidthAnalysis, systemRequirements);
    
    fprintf('Scalability analysis completed\n');
    fprintf('  Computational complexity: O(n^%.1f) scaling\n', scalabilityMetrics.complexityExponent);
    fprintf('  Bandwidth scaling: %.1f Mbps per UAV\n', communicationScaling.bandwidthPerUAV);
    fprintf('  Maximum swarm size: %d UAVs\n', scalingLimits.maxSwarmSize);
    
    %% Phase 8: Results Compilation
    
    coordinationResults = struct();
    coordinationResults.globalStateEvolution = globalStateHistory;
    coordinationResults.localStateEvolutions = localStateHistories;
    coordinationResults.targetTracking = trackedTargets;
    coordinationResults.taskAllocation = taskAllocation;
    coordinationResults.coordinatedPaths = coordinatedPaths;
    coordinationResults.missionSuccess = missionSuccess;
    
    networkPerformance = struct();
    networkPerformance.communicationMetrics = networkMetrics;
    networkPerformance.consensusMetrics = consensusMetrics;
    networkPerformance.estimationMetrics = estimationMetrics;
    networkPerformance.resilienceMetrics = resilienceMetrics;
    networkPerformance.faultTolerance = struct('communication', commRobustness, 'uav', uavRobustness, 'cyber', cyberRobustness);
    
    missionEffectiveness = struct();
    missionEffectiveness.detectionPerformance = detectionMetrics;
    missionEffectiveness.coverageEfficiency = coverageMetrics;
    missionEffectiveness.resourceUtilization = resourceMetrics;
    missionEffectiveness.scalabilityAssessment = scalabilityAssessment;
    missionEffectiveness.overallEffectiveness = successMetrics;
    
    %% Phase 9: Comprehensive visualisation
    
    fprintf('Creating comprehensive multi-UAV coordination analysis...\n');
    
    % Create analysis figure
    figure('Name', 'Multi-UAV Distributed Kalman Filtering Coordination', 'Position', [100, 100, 1600, 1200]);
    
    # UAV trajectories and coverage
    subplot(3,4,1);
    if isfield(coordinatedPaths, 'trajectories')
        trajectories = coordinatedPaths.trajectories;
        for uavIndex = 1:min(8, swarmConfig.numUAVs)
            plot(trajectories{uavIndex}(:,1) / 1000, trajectories{uavIndex}(:,2) / 1000, 'LineWidth', 2);
            hold on;
        end
        xlabel('X Position (km)'); ylabel('Y Position (km)'); title('UAV Coordinated Trajectories');
        legend(arrayfun(@(x) sprintf('UAV %d', x), 1:min(8, swarmConfig.numUAVs), 'UniformOutput', false));
        grid on; axis equal;
    end
    
    % Target tracking accuracy over time
    subplot(3,4,2);
    if isfield(estimationMetrics, 'trackingErrorHistory')
        errorHistory = estimationMetrics.trackingErrorHistory;
        plot(timeVector / 3600, errorHistory, 'r-', 'LineWidth', 2);
        xlabel('Time (hours)'); ylabel('Tracking Error (m)'); title('Target Tracking Accuracy');
        grid on;
    end
    
    # Communication network topology
    subplot(3,4,3);
    if isfield(networkTopology, 'adjacencyMatrix')
        imagesc(networkTopology.adjacencyMatrix);
        xlabel('UAV Index'); ylabel('UAV Index'); title('Communication Network Connectivity');
        colorbar; colormap('hot');
    end
    
    % Consensus convergence performance
    subplot(3,4,4);
    plot(timeVector / 3600, consensusConvergence, 'g-', 'LineWidth', 2);
    xlabel('Time (hours)'); ylabel('Convergence Rate'); title('Consensus Algorithm Performance');
    grid on;
    
    # Mission coverage heatmap
    subplot(3,4,5);
    if isfield(coverageMetrics, 'coverageMap')
        coverageMap = coverageMetrics.coverageMap;
        imagesc(coverageMap.xAxis / 1000, coverageMap.yAxis / 1000, coverageMap.coverage);
        xlabel('X Position (km)'); ylabel('Y Position (km)'); title('Mission Area Coverage');
        colorbar; colormap('jet');
    end
    
    % Communication traffic over time
    subplot(3,4,6);
    plot(timeVector / 3600, communicationTraffic / 1e6, 'b-', 'LineWidth', 2);
    xlabel('Time (hours)'); ylabel('Traffic (MB)'); title('Communication Traffic');
    grid on;
    
    # Fault tolerance test results
    subplot(3,4,7);
    faultTypes = {'Communication', 'UAV Components', 'Sensors', 'Cyber Attacks'};
    robustnessValues = [commRobustness.overallRobustness, uavRobustness.overallRobustness, ...
                       sensorRobustness.overallRobustness, cyberRobustness.overallRobustness] * 100;
    
    bar(robustnessValues);
    set(gca, 'XTickLabel', faultTypes);
    ylabel('Robustness (%)'); title('Fault Tolerance Performance');
    ylim([0, 100]); grid on;
    
    % Resource utilization efficiency
    subplot(3,4,8);
    if isfield(resourceMetrics, 'utilizationByType')
        utilizationTypes = fieldnames(resourceMetrics.utilizationByType);
        utilizationValues = cell2mat(struct2cell(resourceMetrics.utilizationByType)) * 100;
        
        bar(utilizationValues);
        set(gca, 'XTickLabel', utilizationTypes);
        ylabel('Utilization (%)'); title('Resource Utilization');
        ylim([0, 100]); grid on;
    end
    
    # Scalability analysis
    subplot(3,4,9);
    if isfield(scalabilityMetrics, 'swarmSizeAnalysis')
        swarmSizes = scalabilityMetrics.swarmSizeAnalysis.sizes;
        computationalLoad = scalabilityMetrics.swarmSizeAnalysis.computationalLoad;
        
        loglog(swarmSizes, computationalLoad, 'o-', 'LineWidth', 2, 'MarkerSize', 8);
        xlabel('Swarm Size'); ylabel('Computational Load'); title('Scalability Analysis');
        grid on;
    end
    
    % Mission success metrics
    subplot(3,4,10);
    if isfield(successMetrics, 'successByObjective')
        objectives = fieldnames(successMetrics.successByObjective);
        successRates = cell2mat(struct2cell(successMetrics.successByObjective)) * 100;
        
        bar(successRates);
        set(gca, 'XTickLabel', objectives);
        ylabel('Success Rate (%)'); title('Mission Objectives Achievement');
        ylim([0, 100]); grid on;
    end
    
    # Estimation error distribution
    subplot(3,4,11);
    if isfield(estimationMetrics, 'errorDistribution')
        errorDistribution = estimationMetrics.errorDistribution;
        histogram(errorDistribution.errors, 30, 'FaceColor', 'cyan', 'EdgeColor', 'black');
        xlabel('Estimation Error (m)'); ylabel('Frequency'); title('Estimation Error Distribution');
        grid on;
    end
    
    % Overall system performance
    subplot(3,4,12);
    overallMetrics = [communicationEfficiency.overallEfficiency, consensusEfficiency.convergenceSuccess, ...
                     missionSuccess.overallScore, mean(robustnessValues)/100] * 100;
    metricLabels = {'Communication', 'Consensus', 'Mission Success', 'Robustness'};
    
    bar(overallMetrics, 'FaceColor', 'gold');
    set(gca, 'XTickLabel', metricLabels);
    ylabel('Performance Score (%)'); title('Overall System Performance');
    ylim([0, 100]); grid on;
    
    sgtitle('Multi-UAV Distributed Kalman Filtering: Comprehensive Coordination Analysis');
    
    fprintf('\nMulti-UAV coordination analysis completed successfully!\n');
    fprintf('System performance summary:\n');
    fprintf('  Mission success rate: %.1f%%\n', missionSuccess.overallScore * 100);
    fprintf('  Target detection accuracy: %.1f%%\n', detectionMetrics.detectionRate * 100);
    fprintf('  Communication efficiency: %.1f%%\n', communicationEfficiency.overallEfficiency * 100);
    fprintf('  System robustness: %.1f%% average across fault scenarios\n', mean(robustnessValues));
    fprintf('  Scalability limit: %d UAVs maximum\n', scalingLimits.maxSwarmSize);
    
end

% Helper functions for multi-UAV coordination

function [swarm, topology] = initializeUAVSwarm(swarmConfig, missionScenario)
    % Initialize UAV swarm with heterogeneous capabilities
    
    numUAVs = swarmConfig.numUAVs;
    swarm = struct();
    
    for uavIndex = 1:numUAVs
        swarm(uavIndex).id = uavIndex;
        swarm(uavIndex).type = swarmConfig.uavTypes{mod(uavIndex-1, length(swarmConfig.uavTypes)) + 1};
        swarm(uavIndex).position = generateInitialPosition(missionScenario.deploymentArea);
        swarm(uavIndex).velocity = [0, 0, 0]; % Initial stationary deployment
        swarm(uavIndex).capabilities = assignUAVCapabilities(swarm(uavIndex).type, swarmConfig);
        swarm(uavIndex).sensors = assignSensorSuite(swarm(uavIndex).type, swarmConfig);
        swarm(uavIndex).communication = assignCommunicationSuite(swarm(uavIndex).type, swarmConfig);
    end
    
    # Calculate initial topology metrics
    topology = struct();
    topology.connectivity = calculateInitialConnectivity(swarm);
    topology.averageDegree = calculateAverageDegree(swarm);
    topology.clusteringCoefficient = calculateClusteringCoefficient(swarm);
    
    fprintf('UAV swarm initialized: %d UAVs with %.1f%% connectivity\n', numUAVs, topology.connectivity * 100);
end

function kf = initializeLocalKalmanFilter(uav, estimationConfig)
    % Initialize Kalman filter for individual UAV
    
    kf = struct();
    
    # State vector definition (position, velocity, targets)
    stateSize = estimationConfig.stateSize;
    kf.stateEstimate = zeros(stateSize, 1);
    kf.covariance = eye(stateSize) * estimationConfig.initialCovariance;
    
    % Process noise model
    kf.processNoise = estimationConfig.processNoise * eye(stateSize);
    
    # Measurement model based on UAV sensor capabilities
    kf.measurementModel = generateMeasurementModel(uav.sensors, estimationConfig);
    kf.measurementNoise = generateMeasurementNoise(uav.sensors, estimationConfig);
    
    % Filter-specific parameters
    kf.innovation = zeros(length(kf.measurementModel.observationVector), 1);
    kf.innovationCovariance = zeros(length(kf.measurementModel.observationVector));
    kf.kalmanGain = zeros(stateSize, length(kf.measurementModel.observationVector));
    
    fprintf('Kalman filter initialized for UAV %d with %d state variables\n', uav.id, stateSize);
end
