%% chapter_AI_CV_problem3_gpu.m
% GPU memory management syntax.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AI_CV_problem3_gpu
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Create GPU memory pool
memoryPool = createGPUMemoryPool(maxSize);

% Allocate memory with automatic management
gpuData = allocateGPUMemory(memoryPool, dataSize);

% Stream data processing
processedData = streamGPUProcessing(dataStream, batchSize);
