%% p22.m
% MATLABBook03_ChapterAIBHS_Problem22.m
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : p22
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function MATLABBook03_ChapterAIBHS_Problem22
% Purpose: simplified CMR simulation of emotional-memory advantage.
% Author: Dr Leo Chen. R2024b (no toolbox). v1.0 2025-06-01.
    rng(0); nItems=12; dim=20; items=randn(dim,nItems);
    recall=zeros(1,2); betas=[0.9 0.7];  % emotional (slow) vs neutral drift
    for cond=1:2
        beta=betas(cond); context=zeros(dim,1); assoc=zeros(dim,nItems);
        for i=1:nItems
            context=beta*context+(1-beta)*items(:,i);
            context=context/norm(context); assoc(:,i)=context;
        end
        scores=assoc'*context; recall(cond)=mean(scores>median(scores));
    end
    fprintf('Emotional recall: %.2f  Neutral recall: %.2f\n', recall(1), recall(2));
end
