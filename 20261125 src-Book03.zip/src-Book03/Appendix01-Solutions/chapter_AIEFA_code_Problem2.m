%% chapter_AIEFA_code_Problem2.m
% Markowitz mean-variance portfolio optimisation (MATLABBook02_AIEFA_Problem2_PortfolioOptimisation.m).
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AIEFA_code_Problem2
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%=========================================================================
% FILE   : MATLABBook02_AIEFA_Problem2_PortfolioOptimisation.m
% DESCR. : Analytical Markowitz portfolio optimisation
% AUTHOR : Dr Yi Chen
% MATLAB : R2023b (compatible with R2019b and later)
% CREATED: July 2025   VERSION: 1.0
%=========================================================================
clear; clc; close all;

%% -- 1. Asset Parameters --
numAssets    = 5;
expectedRet  = [0.08; 0.12; 0.10; 0.15; 0.06]; % annualised
stdDevs      = [0.15; 0.25; 0.20; 0.30; 0.10]; % annualised
riskFreeRate = 0.03;

corrMatrix = [1.00, 0.30, 0.25, 0.20, 0.10;
              0.30, 1.00, 0.40, 0.35, 0.15;
              0.25, 0.40, 1.00, 0.30, 0.20;
              0.20, 0.35, 0.30, 1.00, 0.10;
              0.10, 0.15, 0.20, 0.10, 1.00];

covMatrix = diag(stdDevs) * corrMatrix * diag(stdDevs);
onesVec   = ones(numAssets, 1);

%% -- 2. Analytical Markowitz Scalars --
invCov = inv(covMatrix);
scalarA = onesVec' * invCov * expectedRet;     % e'*Sigma^{-1}*mu
scalarB = expectedRet' * invCov * expectedRet;  % mu'*Sigma^{-1}*mu
scalarC = onesVec' * invCov * onesVec;          % e'*Sigma^{-1}*e
scalarD = scalarB * scalarC - scalarA^2;        % BC - A^2

fprintf('Markowitz scalars: A=%.4f, B=%.4f, C=%.4f, D=%.4f\n', ...
    scalarA, scalarB, scalarC, scalarD);

%% -- 3. Global Minimum-Variance Portfolio --
muMV    = scalarA / scalarC;
sigmaMV = sqrt(1 / scalarC);
wMV     = (invCov * onesVec) / scalarC;
sharpeMV = (muMV - riskFreeRate) / sigmaMV;
fprintf('\nGlobal Min-Variance: mu=%.4f, sigma=%.4f, Sharpe=%.4f\n', ...
    muMV, sigmaMV, sharpeMV);

%% -- 4. Tangency (Maximum Sharpe) Portfolio --
excessRet  = expectedRet - riskFreeRate * onesVec;
wTangency  = invCov * excessRet;
wTangency  = wTangency / sum(wTangency);  % normalise
muTangency = wTangency' * expectedRet;
sigmaTangency = sqrt(wTangency' * covMatrix * wTangency);
sharpeTangency = (muTangency - riskFreeRate) / sigmaTangency;
fprintf('Tangency Portfolio: mu=%.4f, sigma=%.4f, Sharpe=%.4f\n', ...
    muTangency, sigmaTangency, sharpeTangency);

%% -- 5. Efficient Frontier --
numPortfolios    = 200;
targetReturns    = linspace(muMV, max(expectedRet) + 0.02, ...
                            numPortfolios);
frontierSigma    = zeros(numPortfolios, 1);
frontierWeights  = zeros(numPortfolios, numAssets);

for portIdx = 1:numPortfolios
    muTarget = targetReturns(portIdx);
    lambda1  = (scalarC * muTarget - scalarA) / scalarD;
    lambda2  = (scalarB - scalarA * muTarget) / scalarD;
    wOpt     = invCov * (lambda1 * expectedRet + lambda2 * onesVec);
    frontierWeights(portIdx, :) = wOpt';
    frontierSigma(portIdx)      = sqrt(wOpt' * covMatrix * wOpt);
end

%% -- 6. Capital Market Line --
cmlSigma = linspace(0, max(frontierSigma) * 1.1, 100);
cmlMu    = riskFreeRate + sharpeTangency * cmlSigma;

%% -- 7. Plotting --
figure('Position', [80, 80, 900, 600]);
plot(frontierSigma, targetReturns, 'b-', 'LineWidth', 1.5);
hold on;
plot(cmlSigma, cmlMu, 'k--', 'LineWidth', 1.0);
plot(sigmaMV, muMV, 'gs', 'MarkerSize', 10, ...
    'MarkerFaceColor', 'g');
plot(sigmaTangency, muTangency, 'r^', 'MarkerSize', 10, ...
    'MarkerFaceColor', 'r');
for assetIdx = 1:numAssets
    plot(stdDevs(assetIdx), expectedRet(assetIdx), 'ko', ...
        'MarkerSize', 7, 'MarkerFaceColor', [0.6 0.6 0.6]);
    text(stdDevs(assetIdx) + 0.005, expectedRet(assetIdx), ...
        sprintf('Asset %d', assetIdx), 'FontSize', 9);
end
xlabel('Portfolio Risk $\sigma_p$', ...
    'Interpreter', 'latex', 'FontSize', 12);
ylabel('Expected Return $\mu_p$', ...
    'Interpreter', 'latex', 'FontSize', 12);
title('Markowitz Efficient Frontier and Capital Market Line', ...
    'Interpreter', 'latex', 'FontSize', 13);
legend('Efficient Frontier', 'Capital Market Line', ...
    'Min-Variance', 'Tangency', ...
    'Interpreter', 'latex', 'Location', 'southeast');
grid on; xlim([0, max(frontierSigma)*1.15]);

%% -- 8. Summary Table --
fprintf('\n- Representative Efficient Portfolios -\n');
fprintf('%-14s', 'Portfolio');
for assetIdx = 1:numAssets
    fprintf('  w_%d   ', assetIdx);
end
fprintf('  mu_p    sigma_p  Sharpe\n');
% Display min-variance, tangency, and a high-return portfolio
indices = [1, ...
    find(abs(targetReturns - muTangency) == ...
    min(abs(targetReturns - muTangency)), 1), ...
    numPortfolios];
labels = {'Min-Var', 'Tangency', 'High-Ret'};
for rowIdx = 1:3
    pIdx = indices(rowIdx);
    fprintf('%-14s', labels{rowIdx});
    for assetIdx = 1:numAssets
        fprintf('%7.3f ', frontierWeights(pIdx, assetIdx));
    end
    fprintf(' %6.4f   %6.4f  %6.4f\n', ...
        targetReturns(pIdx), frontierSigma(pIdx), ...
        (targetReturns(pIdx) - riskFreeRate) / ...
        frontierSigma(pIdx));
end
% Computational Complexity:
% Covariance matrix inverse: O(n^3) where n = number of
% assets. Efficient frontier construction: O(n^2 * N_p)
% for N_p target returns. For moderate portfolios (n <= 50,
% N_p = 200), computation completes in milliseconds.
% Scaling to n > 500 assets may require iterative solvers
% or shrinkage estimators for numerical stability.
