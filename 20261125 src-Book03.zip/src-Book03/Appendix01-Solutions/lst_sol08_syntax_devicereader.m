%% lst_sol08_syntax_devicereader.m
% Real-time audio capture with audioDeviceReader.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : lst:sol08_syntax_devicereader
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
deviceReader = audioDeviceReader( ...
    'SampleRate',       44100, ...
    'SamplesPerFrame',  1024);
while processingActive
    audioFrame = deviceReader();
    % Process frame ...
end
release(deviceReader);
