%% css_gap.m
% Competency gap analysis in base MATLAB.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : css_gap
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function gapTable = analyseSkillGap(currentLevel, requiredLevel, skillNames)
% analyseSkillGap  Prioritise training by competency gap.
%   gapTable = analyseSkillGap(currentLevel, requiredLevel, skillNames)
%   Author: Dr Leo Chen | Version 1.0 | Base MATLAB (R2021b+)

    gap = max(requiredLevel(:) - currentLevel(:), 0);
    [sortedGap, order] = sort(gap, 'descend');

    gapTable = table(string(skillNames(order)), sortedGap, ...
        'VariableNames', {'Skill', 'Gap'});
end
