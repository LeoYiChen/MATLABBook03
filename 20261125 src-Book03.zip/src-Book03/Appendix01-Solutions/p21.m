%% p21.m
% MATLABBook03_ChapterAIBHS_Problem21.m
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : p21
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function MATLABBook03_ChapterAIBHS_Problem21
% Purpose: oxygen-release kinetics from a wound-healing hydrogel.
% Author: Dr Leo Chen. R2024b (no toolbox). v1.0 2025-06-01.
    kRel=0.5; kCon=0.2; reservoir=1.0;
    [t,C]=ode45(@(t,C) kRel*(reservoir-C)-kCon*C,[0 24],0);
    therapeutic=0.3; aboveIdx=find(C>=therapeutic);
    fprintf('Steady-state O2: %.3f\n', C(end));
    fprintf('Time above therapeutic level: %.1f h\n', ...
        t(aboveIdx(end))-t(aboveIdx(1)));
    figure; plot(t,C); grid on;
    xlabel('$\mathrm{Time\ (h)}$'); ylabel('$\mathrm{Relative\ [O_2]}$');
end
