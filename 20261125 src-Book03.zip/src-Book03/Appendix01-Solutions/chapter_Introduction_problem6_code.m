%% chapter_Introduction_problem6_code.m
% Signal processing across domains.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_Introduction_problem6_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% MATLABBook03_Chapter01_Problem06.m
% Signal Processing Across Domains
% This script demonstrates how similar signal processing techniques
% can be applied across different disciplines

%% Setup and Configuration
clear;
clc;
close all;
rng(42); % For reproducibility

% Common parameters
fs_audio = 44100;     % Sampling frequency for audio (Hz)
fs_ecg = 500;         % Sampling frequency for ECG (Hz)
fs_financial = 1;     % Sampling frequency for financial data (1/day)

%% 1. GENERATE/LOAD SIGNALS FROM THREE DOMAINS

% 1.1 Audio Signal (Communication/Acoustics domain)
% Load audio sample (use a built-in audio file if available)
try
    [audio_signal, fs_audio_actual] = audioread('handel.wav');
    % Take first channel if stereo
    if size(audio_signal, 2) > 1
        audio_signal = audio_signal(:, 1);
    end
    % Trim to 5 seconds
    audio_signal = audio_signal(1:min(length(audio_signal), 5*fs_audio_actual));
    fs_audio = fs_audio_actual;
    disp('Loaded audio sample handel.wav');
catch
    % If file not found, generate synthetic audio signal
    disp('Audio file not found. Generating synthetic audio signal...');
    duration = 5; % seconds
    t_audio = (0:1/fs_audio:duration-1/fs_audio)';
    
    % Create a signal with multiple frequency components
    f1 = 440;  % A4 note
    f2 = 523.25; % C5 note
    f3 = 659.25; % E5 note
    
    % Simple melody with these notes
    audio_signal = zeros(size(t_audio));
    note_duration = 0.5; % seconds
    samples_per_note = note_duration * fs_audio;
    
    notes = [f1, f2, f3, f2, f1, f1, f2, f2, f3, f3, f2, f1];
    for i = 1:length(notes)
        start_idx = floor((i-1) * samples_per_note) + 1;
        end_idx = min(floor(i * samples_per_note), length(audio_signal));
        if start_idx > length(audio_signal)
            break;
        end
        
        % Create a note with exponential decay
        t_note = t_audio(start_idx:end_idx) - t_audio(start_idx);
        audio_signal(start_idx:end_idx) = sin(2*pi*notes(i)*t_note) .* exp(-3*t_note/note_duration);
    end
    
    % Add some noise
    audio_signal = audio_signal + 0.05 * randn(size(audio_signal));
end

% Normalize audio signal
audio_signal = audio_signal / max(abs(audio_signal));

% Calculate time vector for audio
t_audio = (0:length(audio_signal)-1)' / fs_audio;

% 1.2 ECG Signal (Biomedical domain)
% Generate synthetic ECG-like signal
duration_ecg = 10; % seconds
t_ecg = (0:1/fs_ecg:duration_ecg-1/fs_ecg)';

% Parameters for ECG synthesis
heart_rate = 75; % beats per minute
beat_interval = 60 / heart_rate; % seconds
qrs_duration = 0.1; % seconds
p_duration = 0.15; % seconds
t_duration = 0.2; % seconds

% Create ECG signal
ecg_signal = zeros(size(t_ecg));
beat_times = 0:beat_interval:duration_ecg;

for b = 1:length(beat_times)
    beat_center = beat_times(b);
    if beat_center > duration_ecg
        break;
    end
    
    % P wave (atrial depolarization)
    p_wave = -0.3 * exp(-((t_ecg - (beat_center-0.2)).^2)/(2*(p_duration/3)^2));
    
    % QRS complex (ventricular depolarization)
    q_wave = -0.2 * exp(-((t_ecg - (beat_center-0.05)).^2)/(2*(qrs_duration/12)^2));
    r_wave = 1.0 * exp(-((t_ecg - beat_center).^2)/(2*(qrs_duration/5)^2));
    s_wave = -0.4 * exp(-((t_ecg - (beat_center+0.05)).^2)/(2*(qrs_duration/10)^2));
    
    % T wave (ventricular repolarization)
    t_wave = 0.5 * exp(-((t_ecg - (beat_center+0.3)).^2)/(2*(t_duration/4)^2));
    
    % Combine components
    ecg_signal = ecg_signal + p_wave + q_wave + r_wave + s_wave + t_wave;
end

% Add some baseline wander (low-frequency noise)
baseline_wander = 0.1 * sin(2*pi*0.3*t_ecg) + 0.05 * sin(2*pi*0.1*t_ecg + 1);
% Add some high-frequency noise
hf_noise = 0.05 * randn(size(t_ecg));

% Complete ECG signal with noise
ecg_signal = ecg_signal + baseline_wander + hf_noise;

% 1.3 Financial Time Series (Economics domain)
% Generate synthetic stock price data
duration_financial = 500; % days
t_financial = (0:duration_financial-1)' / fs_financial;

% Create a financial time series with trend, seasonality, and noise
trend = 100 + 0.05 * (1:duration_financial)';
seasonality = 5 * sin(2*pi*t_financial/90 + 0.5); % ~quarterly cycle
cycles = 3 * sin(2*pi*t_financial/200 + 1.0); % longer business cycle

% Add market regime change
regime_change = zeros(size(t_financial));
regime_change_point = floor(duration_financial * 0.6);
regime_change(regime_change_point:end) = -10 * (1 - exp(-(t_financial(regime_change_point:end) - t_financial(regime_change_point))));

% Add random shocks (non-Gaussian, fat-tailed)
random_shocks = zeros(size(t_financial));
shock_probability = 0.03; % 3% chance of shock each day
shock_days = rand(size(t_financial)) < shock_probability;
shock_magnitude = 3 * randn(sum(shock_days), 1);
random_shocks(shock_days) = shock_magnitude;

% Day-to-day noise
daily_noise = 1.0 * randn(size(t_financial));

% Combine components
financial_signal = trend + seasonality + cycles + regime_change + random_shocks + daily_noise;
% Ensure no negative prices
financial_signal = max(financial_signal, 0.01);

%% 2. VISUALIZE RAW SIGNALS FROM THREE DOMAINS

figure('Name', 'Raw Signals Across Domains', 'Position', [100, 100, 1200, 800]);

% 2.1 Audio Signal
subplot(3,1,1);
plot(t_audio, audio_signal, 'b-');
title('Audio Signal (Acoustics/Communications Domain)');
xlabel('Time (seconds)');
ylabel('Amplitude');
xlim([0, min(5, max(t_audio))]);
grid on;

% 2.2 ECG Signal
subplot(3,1,2);
plot(t_ecg, ecg_signal, 'r-');
title('ECG Signal (Biomedical Domain)');
xlabel('Time (seconds)');
ylabel('Voltage (mV)');
xlim([0, min(5, max(t_ecg))]);
grid on;

% 2.3 Financial Signal
subplot(3,1,3);
plot(t_financial, financial_signal, 'g-');
title('Stock Price Data (Economics/Finance Domain)');
xlabel('Time (days)');
ylabel('Price');
grid on;

%% 3. SIGNAL FILTERING ACROSS DOMAINS

figure('Name', 'Signal Filtering Across Domains', 'Position', [150, 150, 1200, 800]);

% 3.1 Audio Signal Filtering
% Design filters for audio signal
[b_audio_lp, a_audio_lp] = butter(4, 1000/(fs_audio/2), 'low'); % Low-pass filter
[b_audio_bp, a_audio_bp] = butter(4, [500, 2000]/(fs_audio/2), 'bandpass'); % Band-pass filter

% Apply filters
audio_lp = filtfilt(b_audio_lp, a_audio_lp, audio_signal);
audio_bp = filtfilt(b_audio_bp, a_audio_bp, audio_signal);

% Plot audio filtering results
subplot(3,3,1);
plot(t_audio, audio_signal, 'b-', 'LineWidth', 1);
hold on;
plot(t_audio, audio_lp, 'r-', 'LineWidth', 1);
title('Audio: Low-Pass Filtering');
xlabel('Time (seconds)');
ylabel('Amplitude');
legend('Original', 'Low-Pass Filtered');
xlim([0, min(1, max(t_audio))]);
grid on;

subplot(3,3,2);
plot(t_audio, audio_signal, 'b-', 'LineWidth', 1);
hold on;
plot(t_audio, audio_bp, 'g-', 'LineWidth', 1);
title('Audio: Band-Pass Filtering');
xlabel('Time (seconds)');
ylabel('Amplitude');
legend('Original', 'Band-Pass Filtered');
xlim([0, min(1, max(t_audio))]);
grid on;

subplot(3,3,3);
% Compute moving average (different approach)
window_size = floor(0.01 * fs_audio); % 10ms window
audio_ma = movmean(audio_signal, window_size);
plot(t_audio, audio_signal, 'b-', 'LineWidth', 1);
hold on;
plot(t_audio, audio_ma, 'm-', 'LineWidth', 1);
title('Audio: Moving Average');
xlabel('Time (seconds)');
ylabel('Amplitude');
legend('Original', 'Moving Average');
xlim([0, min(1, max(t_audio))]);
grid on;

% 3.2 ECG Signal Filtering
% Design filters for ECG signal
[b_ecg_lp, a_ecg_lp] = butter(4, 40/(fs_ecg/2), 'low'); % Low-pass filter to remove high-frequency noise
[b_ecg_hp, a_ecg_hp] = butter(4, 0.5/(fs_ecg/2), 'high'); % High-pass filter to remove baseline wander

% Apply filters
ecg_lp = filtfilt(b_ecg_lp, a_ecg_lp, ecg_signal);
ecg_hp = filtfilt(b_ecg_hp, a_ecg_hp, ecg_signal);
ecg_filtered = filtfilt(b_ecg_hp, a_ecg_hp, ecg_lp); % Apply both filters

% Plot ECG filtering results
subplot(3,3,4);
plot(t_ecg, ecg_signal, 'b-', 'LineWidth', 1);
hold on;
plot(t_ecg, ecg_lp, 'r-', 'LineWidth', 1);
title('ECG: Low-Pass Filtering');
xlabel('Time (seconds)');
ylabel('Amplitude (mV)');
legend('Original', 'Low-Pass Filtered');
xlim([0, min(5, max(t_ecg))]);
grid on;

subplot(3,3,5);
plot(t_ecg, ecg_signal, 'b-', 'LineWidth', 1);
hold on;
plot(t_ecg, ecg_hp, 'g-', 'LineWidth', 1);
title('ECG: High-Pass Filtering');
xlabel('Time (seconds)');
ylabel('Amplitude (mV)');
legend('Original', 'High-Pass Filtered');
xlim([0, min(5, max(t_ecg))]);
grid on;

subplot(3,3,6);
plot(t_ecg, ecg_signal, 'b-', 'LineWidth', 1);
hold on;
plot(t_ecg, ecg_filtered, 'm-', 'LineWidth', 1);
title('ECG: Band-Pass Filtering');
xlabel('Time (seconds)');
ylabel('Amplitude (mV)');
legend('Original', 'Band-Pass Filtered');
xlim([0, min(5, max(t_ecg))]);
grid on;

% 3.3 Financial Signal Filtering
% For financial data, filtering has different meanings and applications
% Simple Moving Average - common in technical analysis
window_sizes = [5, 20, 50]; % Short, medium, and long-term moving averages
financial_ma = zeros(length(financial_signal), length(window_sizes));

for i = 1:length(window_sizes)
    financial_ma(:,i) = movmean(financial_signal, window_sizes(i));
end

% Exponential Moving Average - gives more weight to recent prices
alpha = 0.1; % Smoothing factor
financial_ema = zeros(size(financial_signal));
financial_ema(1) = financial_signal(1);
for i = 2:length(financial_signal)
    financial_ema(i) = alpha * financial_signal(i) + (1-alpha) * financial_ema(i-1);
end

% Kalman filter - more sophisticated approach for financial data
% Simple implementation
financial_kalman = zeros(size(financial_signal));
Q = 0.01; % Process noise
R = 1.0;  % Measurement noise
x_hat = financial_signal(1); % Initial estimate
P = 1.0;  % Initial error covariance

for i = 1:length(financial_signal)
    % Prediction
    P = P + Q;
    
    % Update
    K = P / (P + R); % Kalman gain
    x_hat = x_hat + K * (financial_signal(i) - x_hat);
    P = (1 - K) * P;
    
    financial_kalman(i) = x_hat;
end

% Plot financial filtering results
subplot(3,3,7);
plot(t_financial, financial_signal, 'b-', 'LineWidth', 1);
hold on;
plot(t_financial, financial_ma(:,1), 'r-', 'LineWidth', 1);
plot(t_financial, financial_ma(:,2), 'g-', 'LineWidth', 1);
plot(t_financial, financial_ma(:,3), 'm-', 'LineWidth', 1);
title('Financial: Moving Average Filters');
xlabel('Time (days)');
ylabel('Price');
legend('Original', [num2str(window_sizes(1)) '-day MA'], ...
                  [num2str(window_sizes(2)) '-day MA'], ...
                  [num2str(window_sizes(3)) '-day MA'], ...
                  'Location', 'northwest');
grid on;

subplot(3,3,8);
plot(t_financial, financial_signal, 'b-', 'LineWidth', 1);
hold on;
plot(t_financial, financial_ema, 'r-', 'LineWidth', 1.5);
title('Financial: Exponential Moving Average');
xlabel('Time (days)');
ylabel('Price');
legend('Original', 'EMA', 'Location', 'northwest');
grid on;

subplot(3,3,9);
plot(t_financial, financial_signal, 'b-', 'LineWidth', 1);
hold on;
plot(t_financial, financial_kalman, 'g-', 'LineWidth', 1.5);
title('Financial: Kalman Filter');
xlabel('Time (days)');
ylabel('Price');
legend('Original', 'Kalman Filtered', 'Location', 'northwest');
grid on;

%% 4. FREQUENCY ANALYSIS ACROSS DOMAINS

figure('Name', 'Frequency Analysis Across Domains', 'Position', [200, 200, 1200, 800]);

% 4.1 Audio Frequency Analysis
% Compute and plot spectrum
N_audio = length(audio_signal);
audio_spectrum = abs(fft(audio_signal))/N_audio;
audio_spectrum = audio_spectrum(1:floor(N_audio/2)+1);
audio_spectrum(2:end-1) = 2*audio_spectrum(2:end-1);
f_audio = fs_audio*(0:(N_audio/2))/N_audio;

subplot(3,2,1);
plot(f_audio, audio_spectrum);
title('Audio Signal: Frequency Spectrum');
xlabel('Frequency (Hz)');
ylabel('Amplitude');
xlim([0, 5000]); % Limit to 5 kHz for better visibility
grid on;

% Short-time Fourier transform (spectrogram)
subplot(3,2,2);
window_size = 1024;
overlap = 512;
spectrogram(audio_signal, hamming(window_size), overlap, window_size, fs_audio, 'yaxis');
title('Audio Signal: Spectrogram');
xlabel('Time (s)');
ylabel('Frequency (Hz)');
colorbar;

% 4.2 ECG Frequency Analysis
% Compute and plot spectrum
N_ecg = length(ecg_signal);
ecg_spectrum = abs(fft(ecg_filtered))/N_ecg;
ecg_spectrum = ecg_spectrum(1:floor(N_ecg/2)+1);
ecg_spectrum(2:end-1) = 2*ecg_spectrum(2:end-1);
f_ecg = fs_ecg*(0:(N_ecg/2))/N_ecg;

subplot(3,2,3);
plot(f_ecg, ecg_spectrum);
title('ECG Signal: Frequency Spectrum');
xlabel('Frequency (Hz)');
ylabel('Amplitude');
xlim([0, 40]); % ECG information mainly below 40 Hz
grid on;

% Power in different frequency bands
% Standard ECG bands: P wave (0.67-5 Hz), QRS complex (5-20 Hz), T wave (0.5-7 Hz)
p_band = [0.67, 5];
qrs_band = [5, 20];
t_band = [0.5, 7];

p_indices = f_ecg >= p_band(1) & f_ecg <= p_band(2);
qrs_indices = f_ecg >= qrs_band(1) & f_ecg <= qrs_band(2);
t_indices = f_ecg >= t_band(1) & f_ecg <= t_band(2);

p_power = sum(ecg_spectrum(p_indices).^2);
qrs_power = sum(ecg_spectrum(qrs_indices).^2);
t_power = sum(ecg_spectrum(t_indices).^2);
total_power = sum(ecg_spectrum.^2);

% Plot power distribution
subplot(3,2,4);
band_powers = [p_power, qrs_power, t_power, total_power-p_power-qrs_power-t_power];
bar(band_powers);
title('ECG Signal: Power in Frequency Bands');
xticklabels({'P wave', 'QRS complex', 'T wave', 'Other'});
ylabel('Power');
grid on;

% 4.3 Financial Frequency Analysis
% For financial data, we often look at different frequency structures
% Compute and plot spectrum
N_financial = length(financial_signal);
financial_spectrum = abs(fft(financial_signal - mean(financial_signal)))/N_financial;
financial_spectrum = financial_spectrum(1:floor(N_financial/2)+1);
financial_spectrum(2:end-1) = 2*financial_spectrum(2:end-1);
f_financial = fs_financial*(0:(N_financial/2))/N_financial;

subplot(3,2,5);
plot(f_financial, financial_spectrum);
title('Financial Signal: Frequency Spectrum');
xlabel('Frequency (cycles/day)');
ylabel('Amplitude');
xlim([0, 0.1]); % Focus on low-frequency components
grid on;

% Wavelet analysis (more common for financial data)
subplot(3,2,6);
% Simple wavelet scalogram
coeffs = cwt(financial_signal - mean(financial_signal), 1:64, 'morl');
imagesc(t_financial, 1:64, abs(coeffs));
title('Financial Signal: Wavelet Scalogram');
xlabel('Time (days)');
ylabel('Scale');
colormap('jet');
colorbar;
set(gca, 'YDir', 'normal');

%% 5. FEATURE EXTRACTION ACROSS DOMAINS

figure('Name', 'Feature Extraction Across Domains', 'Position', [250, 250, 1200, 800]);

% 5.1 Audio Feature Extraction
% Common audio features
% 1. Zero-crossing rate
frame_length = floor(0.02 * fs_audio); % 20ms frames
hop_length = floor(0.01 * fs_audio);   % 10ms hop
num_frames = floor((length(audio_signal) - frame_length) / hop_length) + 1;

zcr = zeros(num_frames, 1);
energy = zeros(num_frames, 1);
spectral_centroid = zeros(num_frames, 1);

for i = 1:num_frames
    start_idx = (i-1)*hop_length + 1;
    end_idx = min(start_idx + frame_length - 1, length(audio_signal));
    frame = audio_signal(start_idx:end_idx);
    
    % Zero crossing rate
    zcr(i) = sum(abs(diff(sign(frame)))) / (2 * length(frame));
    
    % Energy
    energy(i) = sum(frame.^2) / length(frame);
    
    % Spectral centroid
    frame_spectrum = abs(fft(frame));
    frame_spectrum = frame_spectrum(1:floor(length(frame)/2)+1);
    freq_bins = linspace(0, fs_audio/2, length(frame_spectrum));
    spectral_centroid(i) = sum(freq_bins .* frame_spectrum) / sum(frame_spectrum);
end

% Frame times
frame_times = (0:num_frames-1)' * hop_length / fs_audio;

% Plot audio features
subplot(3,3,1);
plot(frame_times, zcr);
title('Audio: Zero-Crossing Rate');
xlabel('Time (seconds)');
ylabel('ZCR');
grid on;

subplot(3,3,2);
plot(frame_times, energy);
title('Audio: Energy');
xlabel('Time (seconds)');
ylabel('Energy');
grid on;

subplot(3,3,3);
plot(frame_times, spectral_centroid);
title('Audio: Spectral Centroid');
xlabel('Time (seconds)');
ylabel('Frequency (Hz)');
grid on;

% 5.2 ECG Feature Extraction
% Common ECG features
% 1. R-peak detection
% Use a simple threshold-based approach for R-peak detection
[~, locs_R] = findpeaks(ecg_filtered, 'MinPeakHeight', 0.5*max(ecg_filtered), 'MinPeakDistance', 0.5*fs_ecg);
R_times = t_ecg(locs_R);

% 2. Heart rate calculation
RR_intervals = diff(R_times);
heart_rates = 60 ./ RR_intervals;

% 3. Heart rate variability (HRV)
hrv_time = R_times(1:end-1) + RR_intervals/2;
hrv_stdnn = std(RR_intervals); % Standard deviation of RR intervals (SDNN)
hrv_rmssd = sqrt(mean(diff(RR_intervals).^2)); % Root mean square of successive differences

% Plot ECG features
subplot(3,3,4);
plot(t_ecg, ecg_filtered, 'b-');
hold on;
plot(R_times, ecg_filtered(locs_R), 'ro', 'MarkerSize', 8);
title('ECG: R-Peak Detection');
xlabel('Time (seconds)');
ylabel('Amplitude (mV)');
legend('Filtered ECG', 'R-Peaks');
xlim([0, min(5, max(t_ecg))]);
grid on;

subplot(3,3,5);
plot(hrv_time, heart_rates, 'b-o');
title('ECG: Heart Rate');
xlabel('Time (seconds)');
ylabel('Heart Rate (BPM)');
grid on;

subplot(3,3,6);
bar([hrv_stdnn, hrv_rmssd]);
title('ECG: Heart Rate Variability Metrics');
xticklabels({'SDNN', 'RMSSD'});
ylabel('Time (seconds)');
grid on;

% 5.3 Financial Feature Extraction
% Common financial features
% 1. Returns calculation
returns = diff(financial_signal) ./ financial_signal(1:end-1);
log_returns = diff(log(financial_signal));
return_times = t_financial(2:end);

% 2. Volatility (rolling standard deviation of returns)
window_size = 20; % 20-day window
volatility = movstd(log_returns, window_size);

% 3. Technical indicators
% Moving Average Convergence Divergence (MACD)
ema_12 = zeros(size(financial_signal));
ema_26 = zeros(size(financial_signal));
ema_12(1) = financial_signal(1);
ema_26(1) = financial_signal(1);

for i = 2:length(financial_signal)
    ema_12(i) = financial_signal(i) * (2/(12+1)) + ema_12(i-1) * (1 - 2/(12+1));
    ema_26(i) = financial_signal(i) * (2/(26+1)) + ema_26(i-1) * (1 - 2/(26+1));
end

macd_line = ema_12 - ema_26;
signal_line = movmean(macd_line, 9);
macd_histogram = macd_line - signal_line;

% Plot financial features
subplot(3,3,7);
histogram(log_returns, 30, 'Normalization', 'pdf');
hold on;
x = linspace(min(log_returns), max(log_returns), 100);
pd = fitdist(log_returns, 'Normal');
y = pdf(pd, x);
plot(x, y, 'r-', 'LineWidth', 2);
title('Financial: Log Return Distribution');
xlabel('Log Returns');
ylabel('PDF');
legend('Empirical', 'Normal Fit');
grid on;

subplot(3,3,8);
plot(return_times, volatility, 'b-');
title('Financial: Rolling Volatility (20-day)');
xlabel('Time (days)');
ylabel('Volatility');
grid on;

subplot(3,3,9);
plot(t_financial, macd_line, 'b-', 'LineWidth', 1.5);
hold on;
plot(t_financial, signal_line, 'r-', 'LineWidth', 1.5);
bar(t_financial, macd_histogram, 0.5, 'FaceColor', [0.5 0.5 0.5], 'EdgeColor', 'none');
title('Financial: MACD Indicator');
xlabel('Time (days)');
ylabel('Value');
legend('MACD Line', 'Signal Line', 'Histogram');
grid on;

%% 6. CROSS-DOMAIN COMPARISON OF SIGNAL PROCESSING APPROACHES

figure('Name', 'Cross-Domain Signal Processing Comparison', 'Position', [300, 300, 1000, 800]);

% Create a table summarizing the differences and similarities
annotation('textbox', [0.1, 0.8, 0.8, 0.15], ...
           'String', {'CROSS-DOMAIN SIGNAL PROCESSING COMPARISON', ...
                     '', ...
                     'While the mathematical foundations of signal processing are universal, their applications and interpretations vary significantly across domains.'}, ...
           'EdgeColor', 'none', ...
           'HorizontalAlignment', 'center', ...
           'FontSize', 12, ...
           'FontWeight', 'bold');

% Comparison table structure
domain_names = {'Audio (Acoustics)', 'ECG (Biomedical)', 'Financial (Economics)'};
aspects = {'Time Scales', 'Filtering Purpose', 'Frequency Analysis', 'Key Features', 'Domain Challenges'};

time_scales = {'Milliseconds to seconds', 'Seconds to minutes', 'Days to years'};
filtering_purpose = {'Noise removal, enhancement', 'Artifact removal, waveform isolation', 'Trend extraction, noise smoothing'};
freq_analysis = {'Harmonic structure, formants', 'Physiological components', 'Cyclic patterns, seasonality'};
key_features = {'ZCR, energy, spectral shape', 'R-peaks, intervals, variability', 'Returns, volatility, indicators'};
domain_challenges = {'Perceptual relevance', 'Non-stationarity, artifacts', 'Non-Gaussian distributions, regime changes'};

% Create comparison table
comparison_data = {time_scales; filtering_purpose; freq_analysis; key_features; domain_challenges};

% Plot as a table
positions = {
    [0.1, 0.65, 0.8, 0.1],
    [0.1, 0.55, 0.8, 0.1],
    [0.1, 0.45, 0.8, 0.1],
    [0.1, 0.35, 0.8, 0.1],
    [0.1, 0.25, 0.8, 0.1]
};

for i = 1:length(aspects)
    annotation('textbox', positions{i}, ...
               'String', {['? ' aspects{i} ':'], ...
                         ['   - ' domain_names{1} ': ' comparison_data{i}{1}], ...
                         ['   - ' domain_names{2} ': ' comparison_data{i}{2}], ...
                         ['   - ' domain_names{3} ': ' comparison_data{i}{3}]}, ...
               'EdgeColor', 'none', ...
               'FitBoxToText', 'off');
end

% Add concluding remarks
annotation('textbox', [0.1, 0.05, 0.8, 0.15], ...
           'String', {'CONCLUSION:', ...
                     '', ...
                     'Signal processing provides a unified mathematical framework applicable across disciplines.', ...
                     'However, domain expertise remains essential for proper interpretation and application of these techniques.', ...
                     'The same algorithms may require different parameterizations and yield different interpretations depending on the domain context.'}, ...
           'EdgeColor', 'none', ...
           'HorizontalAlignment', 'center', ...
           'FontSize', 10);

fprintf('Signal processing analysis completed for audio, ECG, and financial domains.\n');
