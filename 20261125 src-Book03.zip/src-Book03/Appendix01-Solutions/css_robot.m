%% css_robot.m
% Online adaptation of a robot behaviour parameter.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : css_robot
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function trajectory = adaptRobotBehaviour(targetPreference, learningRate, numSteps)
% adaptRobotBehaviour  Exponential update towards an individual's preference.
%   trajectory = adaptRobotBehaviour(targetPreference, learningRate, numSteps)
%   Author: Dr Leo Chen | Version 1.0 | Base MATLAB (R2021b+)

    parameter = 0.5;
    trajectory = zeros(numSteps, 1);
    for step = 1:numSteps
        parameter = parameter + learningRate * (targetPreference - parameter);
        trajectory(step) = parameter;
    end

    plot(1:numSteps, trajectory, '-o'); grid on;
    xlabel('$\mathrm{Interaction\ index}$', 'Interpreter', 'latex');
    ylabel('$\mathrm{Behaviour\ parameter}$', 'Interpreter', 'latex');
    title('$\mathrm{Robot\ adaptation\ trajectory}$', 'Interpreter', 'latex');
end
