%% p13.m
% MATLABBook03_ChapterAIBHS_Problem13.m
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : p13
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function MATLABBook03_ChapterAIBHS_Problem13
% Purpose: SVM cyclic-peptide binding prediction (synthetic).
% Author: Dr Leo Chen. R2024b + Statistics ML. v1.0 2025-06-01.
    rng(0); n=200;
    binder=[randn(n/2,1)+1.5 randn(n/2,1)+1 randn(n/2,1)];
    nonbnd=[randn(n/2,1)-1 randn(n/2,1)-0.5 randn(n/2,1)];
    X=[binder;nonbnd]; y=[ones(n/2,1);zeros(n/2,1)];
    cv=cvpartition(y,'HoldOut',0.3); tr=training(cv); te=test(cv);
    svm=fitcsvm(X(tr,:),y(tr),'KernelFunction','rbf','Standardize',true);
    fprintf('Binding-prediction accuracy: %.3f\n', mean(predict(svm,X(te,:))==y(te)));
end
