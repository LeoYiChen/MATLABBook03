%% p5.m
% MATLABBook03_ChapterAIBHS_Problem05.m
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : p5
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function MATLABBook03_ChapterAIBHS_Problem05
% Purpose: drug repurposing by random walk with restart.
% Author: Dr Leo Chen. R2024b (no toolbox). v1.0 2025-06-01.
    rng(0); nD=6; nT=5; nX=3; N=nD+nT+nX; A=zeros(N);
    dr=1:nD; tg=nD+(1:nT); dx=nD+nT+(1:nX);
    A(dr,tg)=rand(nD,nT)>0.5; A(tg,dx)=rand(nT,nX)>0.5;
    A=A+A'; A(A>0)=1; W=A./max(sum(A,1),eps);
    seed=zeros(N,1); seed(dx(1))=1; p=seed; r=0.3;
    for it=1:100
        q=(1-r)*W*p+r*seed; if norm(q-p,1)<1e-8, break; end; p=q;
    end
    [sc,idx]=sort(p(dr),'descend');
    fprintf('Iterations: %d  Top drug: %d (%.4f)\n',it,idx(1),sc(1));
end
