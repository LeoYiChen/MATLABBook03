%% chapter_AICE_code_P05.m
% Solution~5: building energy load forecasting with a regression tree ensemble (MATLABBook02_Chapter13_section8_Problem05.m).
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AICE_code_P05
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% MATLABBook02_Chapter13_section8_Problem05.m
% Problem 5: Building Energy Load Forecasting with a Regression
%             Tree Ensemble
%
% Description : Trains single and ensemble regression trees on
%               synthetic building sensor data and compares their
%               forecasting accuracy.
% Author      : Dr Yi Chen
% Date        : 2025
% MATLAB      : R2024b or later
% Toolboxes   : Statistics and Machine Learning Toolbox
% Reference   : Chapter 13, Problem 5
% =================================================================

%% 1. Generate synthetic two-week building sensor log (hourly)
rng(42);
nHours     = 336;                          % 14 days
hourIndex  = (0:nHours-1)';
timeOfDay  = mod(hourIndex, 24);
dayOfWeek  = mod(floor(hourIndex / 24), 7);

% Outdoor temperature: daily sinusoid + noise
outdoorTemp = 20 + 10*sin(2*pi*(timeOfDay - 6)/24) ...
    + 2*randn(nHours, 1);

% Occupancy: nonzero during weekday office hours
isOccupied     = double(timeOfDay >= 8 & timeOfDay <= 18 ...
    & dayOfWeek <= 4);
occupancyCount = max(0, isOccupied .* (50 + 15*randn(nHours, 1)));

%% 2. Synthesise HVAC energy consumption (kWh)
baseLoad      = 40;
coolingLoad   = 2.5 * max(0, outdoorTemp - 24);
heatingLoad   = 2.0 * max(0, 18 - outdoorTemp);
occupancyLoad = 0.3 * occupancyCount;
totalEnergy   = baseLoad + coolingLoad + heatingLoad ...
    + occupancyLoad + 5*randn(nHours, 1);

%% 3. Split into training (10 days) and testing (4 days)
trainIdx = 1:240;
testIdx  = 241:nHours;
features = table(timeOfDay, dayOfWeek, outdoorTemp, ...
    occupancyCount);

%% 4. Train models
treeModel     = fitrtree(features(trainIdx, :), ...
    totalEnergy(trainIdx));
ensembleModel = fitrensemble(features(trainIdx, :), ...
    totalEnergy(trainIdx), ...
    'Method', 'Bag', 'NumLearningCycles', 50);

%% 5. Predict on the test set
treePrediction     = predict(treeModel, features(testIdx, :));
ensemblePrediction = predict(ensembleModel, features(testIdx, :));

%% 6. Compute RMSE
treeRMSE     = sqrt(mean((totalEnergy(testIdx) ...
    - treePrediction).^2));
ensembleRMSE = sqrt(mean((totalEnergy(testIdx) ...
    - ensemblePrediction).^2));
fprintf('Single tree RMSE  : %.2f kWh\n', treeRMSE);
fprintf('Ensemble RMSE     : %.2f kWh\n', ensembleRMSE);
fprintf('RMSE improvement  : %.1f%%\n', ...
    100*(treeRMSE - ensembleRMSE)/treeRMSE);

%% 7. Predictor importance
importance     = predictorImportance(ensembleModel);
featureNames   = features.Properties.VariableNames;
[~, bestIdx]   = max(importance);
fprintf('Most important predictor: %s (importance %.2f)\n', ...
    featureNames{bestIdx}, importance(bestIdx));

%% 8. Plot
figure;
subplot(2,1,1);
plot(testIdx, totalEnergy(testIdx), '.', ...
    'MarkerSize', 4, 'DisplayName', 'Measured');
hold on;
plot(testIdx, treePrediction, '-', ...
    'DisplayName', sprintf('Single tree (RMSE = %.1f)', treeRMSE));
plot(testIdx, ensemblePrediction, '--', ...
    'DisplayName', sprintf('Ensemble (RMSE = %.1f)', ensembleRMSE));
xlabel('Hour'); ylabel('Energy (kWh)');
legend('Location', 'best');
title('Building Energy: Single Tree vs.\ Bagged Ensemble');
grid on;

subplot(2,1,2);
bar(importance);
set(gca, 'XTickLabel', featureNames, 'XTickLabelRotation', 30);
ylabel('Predictor Importance');
title('Feature Importance from Bagged Ensemble');
grid on;
% - Computational Complexity -
% Training the single tree on N = 240 samples with d = 4
% features costs O(N d log N), here negligible. The ensemble
% trains T = 50 trees on bootstrapped samples at O(T N d log N),
% still completing in under one second. Prediction over the
% 96-hour test set is O(96 T log N) for the ensemble. The
% entire script executes in well under two seconds.
