%% chapter_AILMI_prob7_adversarial.m
% Adversarial training for style-invariant content representation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AILMI_prob7_adversarial
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [encLoss, discLoss] = adversarialLoss(contentVec, trueStyleLabel, ...
                                               discriminator, Wenc, Wdisc)
    % Adversarial training objective
    % contentVec: [contentDim x 1] style-invariant representation
    % trueStyleLabel: {0, 1} ground truth style
    
    % Discriminator predicts style from content (should fail)
    predictedStyle = sigmoid(discriminator' * contentVec);
    
    % Discriminator loss: Correctly classify style
    discLoss = -trueStyleLabel * log(predictedStyle) - ...
               (1 - trueStyleLabel) * log(1 - predictedStyle);
    
    % Encoder loss: Fool discriminator (reverse gradient)
    % Encoder wants discriminator to be uncertain (predict 0.5)
    targetUncertain = 0.5;
    encLoss = (predictedStyle - targetUncertain)^2;
end
