%% lst_sol05_syntax_gan.m
% GAN custom training step.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : lst:sol05_syntax_gan
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
[genLoss, disLoss, genGrad, disGrad] = dlfeval( ...
    @modelGradients, generatorNet, discriminatorNet, ...
    realBatch, latentDim);
generatorNet     = adamupdate(generatorNet, genGrad, ...
    genAvgGrad, genAvgGradSq, iteration, learnRate);
discriminatorNet = adamupdate(discriminatorNet, ...
    disGrad, disAvgGrad, disAvgGradSq, ...
    iteration, learnRate);
