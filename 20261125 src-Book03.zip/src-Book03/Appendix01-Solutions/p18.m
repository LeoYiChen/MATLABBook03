%% p18.m
% MATLABBook03_ChapterAIBHS_Problem18.m
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : p18
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function MATLABBook03_ChapterAIBHS_Problem18
% Purpose: stochastic replication-fork stalling with RNaseH2 rescue.
% Author: Dr Leo Chen. R2024b (no toolbox). v1.0 2025-06-01.
    rng(0); steps=500; numForks=200; rloopDensity=0.3;
    levels=[0 0.5 1.0]; meanVelocity=zeros(size(levels));
    for j=1:numel(levels)
        progress=zeros(numForks,1);
        for s=1:steps
            stalled=rand(numForks,1)<rloopDensity*(1-levels(j));
            progress=progress+~stalled;
        end
        meanVelocity(j)=mean(progress)/steps;
    end
    for j=1:numel(levels)
        fprintf('RNaseH2 level %.1f -> mean fork velocity %.3f\n', levels(j), meanVelocity(j));
    end
end
