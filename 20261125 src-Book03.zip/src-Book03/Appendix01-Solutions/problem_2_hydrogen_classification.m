%% problem_2_hydrogen_classification.m
% Multi-Class Hydrogen Environment Bearing Fault Classification
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : problem_2_hydrogen_classification
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function hydrogen_bearing_fault_classification()
% Multi-Class Fault Classification for Hydrogen-Environment Bearing Systems
% Author: Dr Leo Chen
% Version: 2024.1
% Focus: Hydrogen embrittlement detection and classification

    fprintf('Starting Hydrogen-Environment Bearing Fault Classification\n');
    fprintf('========================================================\n\n');
    
    % Load multi-modal bearing dataset with hydrogen exposure data
    [sensor_data, fault_labels, hydrogen_conditions] = load_hydrogen_bearing_dataset();
    
    % Advanced feature engineering for hydrogen-specific failure modes
    extracted_features = extract_hydrogen_specific_features(sensor_data, hydrogen_conditions);
    
    % Implement ensemble classification with uncertainty quantification
    [classification_model, performance_metrics] = train_ensemble_classifier(...
        extracted_features, fault_labels, hydrogen_conditions);
    
    % Generate comprehensive analysis and visualisation
    create_hydrogen_classification_visualisation(classification_model, performance_metrics, ...
                                                extracted_features, fault_labels);
    
    fprintf('Hydrogen bearing classification analysis completed!\n');
end
