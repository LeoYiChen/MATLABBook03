%% chapter_AI_CV_problem1_temporal_cv.m
% Temporal cross-validation syntax.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AI_CV_problem1_temporal_cv
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Create temporal cross-validation partitions
temporalCV = createTemporalCrossValidation(timeStamps, 'expanding', 5);

% Apply gap to prevent leakage
gappedCV = applyTemporalGap(temporalCV, gapSize);
