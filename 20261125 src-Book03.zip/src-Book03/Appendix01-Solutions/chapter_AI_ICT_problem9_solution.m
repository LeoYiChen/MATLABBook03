%% chapter_AI_ICT_problem9_solution.m
% Graph Neural Networks for Network Topology Optimisation
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AI_ICT_problem9_solution
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [gnn_results, topology_metrics] = graphNeuralNetworkTopology()
% Graph Neural Networks for Network Topology Optimisation
% Author: Dr Leo Chen
% Version: 1.0
% Date: 2024
%
% Implements GNN-based approaches for intelligent network topology optimisation
% including traffic prediction, fault detection, and adaptive routing

fprintf('=== Graph Neural Network Topology Optimisation Solution ===\n');

% Network topology configuration
network_config = struct();
network_config.num_nodes = 200; % Network nodes (routers/switches)
network_config.network_type = 'software_defined'; % SDN architecture
network_config.topology_type = 'small_world'; % Network topology model
network_config.average_degree = 6; % Average node connections
network_config.traffic_patterns = {'web', 'video', 'iot', 'enterprise'};

% GNN architecture configuration
gnn_config = struct();
gnn_config.node_feature_dim = 16; % Node feature dimensions
gnn_config.edge_feature_dim = 8; % Edge feature dimensions
gnn_config.hidden_dim = 64; % Hidden layer dimensions
gnn_config.num_layers = 4; % Number of GNN layers
gnn_config.attention_heads = 8; % Multi-head attention
gnn_config.dropout_rate = 0.2; % Dropout for regularisation

% Optimisation task configuration
task_config = struct();
task_config.traffic_prediction_horizon = 24; % Hours ahead prediction
task_config.fault_detection_threshold = 0.95; % Anomaly detection threshold
task_config.routing_optimisation_frequency = 300; % Seconds between updates
task_config.topology_adaptation_trigger = 0.8; % Performance degradation trigger

% Generate network topology and traffic data
fprintf('Generating network topology and traffic datasets...\n');
[network_topology, traffic_datasets] = generateNetworkTopologyData(network_config);

% Implement GNN architectures
fprintf('Implementing GNN architectures...\n');
gnn_models = implementGNNArchitectures(network_topology, gnn_config);

% Train traffic prediction models
fprintf('Training traffic prediction models...\n');
traffic_prediction_results = trainTrafficPredictionModels(gnn_models, traffic_datasets, task_config);

% Implement fault detection system
fprintf('Implementing fault detection system...\n');
fault_detection_results = implementFaultDetectionSystem(gnn_models, network_topology, task_config);

% Develop adaptive routing optimisation
fprintf('Developing adaptive routing optimisation...\n');
routing_optimisation_results = developAdaptiveRoutingOptimisation(gnn_models, network_topology, task_config);

% Execute topology optimisation analysis
fprintf('Executing topology optimisation analysis...\n');
topology_optimisation_results = executeTopologyOptimisation(gnn_models, ...
traffic_prediction_results, ...
fault_detection_results, ...
routing_optimisation_results);

% Evaluate GNN performance and scalability
fprintf('Evaluating GNN performance and scalability...\n');
performance_evaluation = evaluateGNNPerformance(topology_optimisation_results, network_config);

% Compile comprehensive results
gnn_results = struct();
gnn_results.traffic_prediction = traffic_prediction_results;
gnn_results.fault_detection = fault_detection_results;
gnn_results.routing_optimisation = routing_optimisation_results;
gnn_results.topology_optimisation = topology_optimisation_results;
gnn_results.performance_evaluation = performance_evaluation;

% Calculate topology improvement metrics
topology_metrics = calculateTopologyMetrics(gnn_results, network_config);

% Generate comprehensive visualisations
generateGNNTopologyVisualisations(gnn_results, topology_metrics, network_topology);

fprintf('Graph neural network topology optimisation completed successfully!\n');
end

function [network_topology, traffic_datasets] = generateNetworkTopologyData(config)
% Generate realistic network topology and traffic datasets

% Create network topology graph
fprintf(' Creating network topology graph...\n');
network_topology = createNetworkTopologyGraph(config);

% Generate node features
fprintf(' Generating node features...\n');
network_topology.node_features = generateNodeFeatures(network_topology, config);

% Generate edge features
fprintf(' Generating edge features...\n');
network_topology.edge_features = generateEdgeFeatures(network_topology, config);

% Generate traffic datasets
fprintf(' Generating traffic datasets...\n');
traffic_datasets = generateTrafficDatasets(network_topology, config);

fprintf(' Network topology and traffic data generated\n');
end

function network_topology = createNetworkTopologyGraph(config)
% Create realistic network topology graph

network_topology = struct();
num_nodes = config.num_nodes;

% Generate adjacency matrix based on topology type
switch lower(config.topology_type)
case 'small_world'
% Watts-Strogatz small-world network
adjacency_matrix = generateSmallWorldTopology(num_nodes, config.average_degree, 0.3);
case 'scale_free'
% Barab--si-Albert scale-free network
adjacency_matrix = generateScaleFreeTopology(num_nodes, config.average_degree);
case 'random'
% Erd?s-R--nyi random network
connection_probability = config.average_degree / (num_nodes - 1);
adjacency_matrix = generateRandomTopology(num_nodes, connection_probability);
otherwise
% Default to small-world
adjacency_matrix = generateSmallWorldTopology(num_nodes, config.average_degree, 0.3);
end

% Store topology information
network_topology.adjacency_matrix = adjacency_matrix;
network_topology.num_nodes = num_nodes;
network_topology.num_edges = sum(sum(adjacency_matrix)) / 2; % Undirected graph
network_topology.node_indices = 1:num_nodes;

% Calculate graph properties
network_topology.degree_distribution = sum(adjacency_matrix, 2);
network_topology.clustering_coefficient = calculateClusteringCoefficient(adjacency_matrix);
network_topology.average_path_length = calculateAveragePathLength(adjacency_matrix);

fprintf(' Network topology created: %d nodes, %d edges\n', num_nodes, network_topology.num_edges);
end

function gnn_models = implementGNNArchitectures(network_topology, gnn_config)
% Implement comprehensive GNN architectures

gnn_models = struct();

% Graph Convolutional Network (GCN)
fprintf(' Implementing Graph Convolutional Network...\n');
gnn_models.gcn = implementGCNArchitecture(network_topology, gnn_config);

% Graph Attention Network (GAT)
fprintf(' Implementing Graph Attention Network...\n');
gnn_models.gat = implementGATArchitecture(network_topology, gnn_config);

% GraphSAGE
fprintf(' Implementing GraphSAGE...\n');
gnn_models.graphsage = implementGraphSAGEArchitecture(network_topology, gnn_config);

% Graph Transformer
fprintf(' Implementing Graph Transformer...\n');
gnn_models.graph_transformer = implementGraphTransformerArchitecture(network_topology, gnn_config);

fprintf(' GNN architectures implemented: %d model types\n', length(fieldnames(gnn_models)));
end

function gcn_model = implementGCNArchitecture(network_topology, gnn_config)
% Implement Graph Convolutional Network architecture

gcn_model = struct();
gcn_model.architecture_type = 'graph_convolutional_network';

% Graph convolution layers
gcn_layers = cell(gnn_config.num_layers, 1);

for layer_idx = 1:gnn_config.num_layers
if layer_idx == 1
input_dim = gnn_config.node_feature_dim;
else
input_dim = gnn_config.hidden_dim;
end
 
if layer_idx == gnn_config.num_layers
    output_dim = gnn_config.hidden_dim; % Final representation dimension
else
    output_dim = gnn_config.hidden_dim;
end

% Graph convolution layer
gcn_layer = struct();
gcn_layer.weight_matrix = randn(input_dim, output_dim) * sqrt(2 / input_dim);
gcn_layer.bias_vector = zeros(output_dim, 1);
gcn_layer.activation = 'relu';
gcn_layer.dropout_rate = gnn_config.dropout_rate;

gcn_layers{layer_idx} = gcn_layer;
end

gcn_model.layers = gcn_layers;

% Adjacency matrix with self-loops
adjacency_with_self_loops = network_topology.adjacency_matrix + eye(network_topology.num_nodes);

% Symmetric normalisation of adjacency matrix
degree_matrix = diag(sum(adjacency_with_self_loops, 2));
degree_sqrt_inv = diag(1 ./ sqrt(diag(degree_matrix) + eps));
normalised_adjacency = degree_sqrt_inv * adjacency_with_self_loops * degree_sqrt_inv;

gcn_model.normalised_adjacency = normalised_adjacency;

% Forward propagation function
gcn_model.forward = @(node_features) forwardGCN(node_features, gcn_model);

% Training configuration
gcn_model.training_config = struct();
gcn_model.training_config.learning_rate = 1e-3;
gcn_model.training_config.num_epochs = 200;
gcn_model.training_config.batch_size = 32;

fprintf(' GCN model implemented with %d layers\n', gnn_config.num_layers);
end

function gat_model = implementGATArchitecture(network_topology, gnn_config)
% Implement Graph Attention Network architecture

gat_model = struct();
gat_model.architecture_type = 'graph_attention_network';

% Multi-head attention layers
gat_layers = cell(gnn_config.num_layers, 1);

for layer_idx = 1:gnn_config.num_layers
if layer_idx == 1
input_dim = gnn_config.node_feature_dim;
else
input_dim = gnn_config.hidden_dim * gnn_config.attention_heads;
end

 
% Multi-head attention layer
attention_layer = struct();
attention_layer.num_heads = gnn_config.attention_heads;
attention_layer.head_dim = gnn_config.hidden_dim;
attention_layer.attention_heads = cell(gnn_config.attention_heads, 1);

for head_idx = 1:gnn_config.attention_heads
    attention_head = struct();
    attention_head.weight_matrix = randn(input_dim, gnn_config.hidden_dim) * sqrt(2 / input_dim);
    attention_head.attention_weight = randn(2 * gnn_config.hidden_dim, 1) * 0.1;
    attention_head.bias_vector = zeros(gnn_config.hidden_dim, 1);
    
    attention_layer.attention_heads{head_idx} = attention_head;
end

attention_layer.activation = 'elu';
attention_layer.dropout_rate = gnn_config.dropout_rate;
attention_layer.alpha = 0.2; % LeakyReLU negative slope

gat_layers{layer_idx} = attention_layer;
end

gat_model.layers = gat_layers;
gat_model.adjacency_matrix = network_topology.adjacency_matrix;

% Forward propagation function
gat_model.forward = @(node_features) forwardGAT(node_features, gat_model);

% Training configuration
gat_model.training_config = struct();
gat_model.training_config.learning_rate = 5e-4;
gat_model.training_config.num_epochs = 300;
gat_model.training_config.batch_size = 16;

fprintf(' GAT model implemented with %d layers and %d attention heads\n', ...
gnn_config.num_layers, gnn_config.attention_heads);
end

function traffic_prediction_results = trainTrafficPredictionModels(gnn_models, traffic_datasets, task_config)
% Train GNN models for traffic prediction

traffic_prediction_results = struct();
model_names = fieldnames(gnn_models);

for model_idx = 1:length(model_names)
model_name = model_names{model_idx};
model = gnn_models.(model_name);

 
fprintf('  Training %s for traffic prediction...\n', upper(model_name));

% Prepare training data
[training_features, training_targets] = prepareTrafficPredictionData(traffic_datasets, task_config);

% Train model
trained_model = trainGNNModel(model, training_features, training_targets);

% Evaluate model performance
[test_features, test_targets] = prepareTestData(traffic_datasets, task_config);
prediction_performance = evaluateTrafficPrediction(trained_model, test_features, test_targets);

% Store results
traffic_prediction_results.(model_name) = struct();
traffic_prediction_results.(model_name).trained_model = trained_model;
traffic_prediction_results.(model_name).performance = prediction_performance;
end

fprintf(' Traffic prediction models trained: %d models\n', length(model_names));
end
