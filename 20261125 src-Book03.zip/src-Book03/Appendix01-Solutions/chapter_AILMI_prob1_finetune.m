%% chapter_AILMI_prob1_finetune.m
% Fine-tuning on target domain with lower learning rate.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AILMI_prob1_finetune
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Load source-trained network
load('sourceTrainedNet.mat', 'net');

% Configure fine-tuning with lower learning rate
options = trainingOptions('adam', ...
    'MaxEpochs', 10, ...
    'InitialLearnRate', 1e-4, ... % Lower than training (1e-3)
    'MiniBatchSize', 16, ...
    'ValidationData', {XValTarget, YValTarget}, ...
    'ValidationPatience', 3, ... % Early stopping
    'Verbose', false);

% Fine-tune on small target dataset
fineTunedNet = trainNetwork(XTrainTarget, YTrainTarget, ...
    net.Layers, options);
