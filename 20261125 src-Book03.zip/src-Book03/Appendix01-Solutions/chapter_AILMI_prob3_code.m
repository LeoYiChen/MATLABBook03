%% chapter_AILMI_prob3_code.m
% Complete attention mechanism comparison for neural machine translation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AILMI_prob3_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% ========================================================================
%% Attention Mechanism Variants for Neural Machine Translation
%% Problem 3: AI in Linguistics and Media Innovation
%% ========================================================================
%% Author: Dr Leo Chen
%% Affiliation: Newcastle University
%% Date: December 2024
%% MATLAB Version: R2023b or later
%% Description: Implements and compares Bahdanau, Luong, and multi-head
%%              attention mechanisms for English-French translation
%% ========================================================================

clear all; close all; clc;
rng(2024, 'twister');

fprintf('========================================================================\n');
fprintf('Problem 3: Attention Mechanism Variants for NMT\n');
fprintf('========================================================================\n\n');

%% Generate Synthetic English-French Parallel Corpus
fprintf('Generating English-French parallel corpus...\n');

% English sentences with varying lengths
englishShort = [
    "The cat sleeps.";
    "I love music.";
    "She reads books.";
    "Birds fly high.";
    "Water is cold."
];

englishMedium = [
    "The quick brown fox jumps over the lazy dog.";
    "She enjoys reading mystery novels in the evening.";
    "The scientist discovered a new species of butterfly.";
    "Students learn mathematics through practical exercises.";
    "The restaurant serves delicious Italian cuisine daily."
];

englishLong = [
    "The talented musician who performed at the concert last night received a standing ovation from the audience.";
    "Despite the challenging weather conditions, the experienced pilot successfully landed the aircraft at the designated airport.";
    "The historical monument, which was constructed during the medieval period, attracts thousands of tourists every year.";
    "The comprehensive research study examined the effects of climate change on marine ecosystems around the world.";
    "The innovative technology company announced the development of a revolutionary artificial intelligence system."
];

% Corresponding French translations
frenchShort = [
    "Le chat dort.";
    "J'aime la musique.";
    "Elle lit des livres.";
    "Les oiseaux volent haut.";
    "L'eau est froide."
];

frenchMedium = [
    "Le rapide renard brun saute par-dessus le chien paresseux.";
    "Elle aime lire des romans policiers le soir.";
    "Le scientifique a d--couvert une nouvelle esp--ce de papillon.";
    "Les --tudiants apprennent les math--matiques par des exercices pratiques.";
    "Le restaurant sert une d--licieuse cuisine italienne tous les jours."
];

frenchLong = [
    "Le musicien talentueux qui s'est produit au concert hier soir a re?u une ovation debout du public.";
    "Malgr-- les conditions m--t--orologiques difficiles, le pilote exp--riment-- a r--ussi -- atterrir l'avion -- l'a--roport d--sign--.";
    "Le monument historique, qui a --t-- construit pendant la p--riode m--di--vale, attire des milliers de touristes chaque ann--e.";
    "L'--tude de recherche compl--te a examin-- les effets du changement climatique sur les --cosyst--mes marins dans le monde entier.";
    "L'entreprise technologique innovante a annonc-- le d--veloppement d'un syst--me d'intelligence artificielle r--volutionnaire."
];

% Combine datasets
englishAll = [englishShort; englishMedium; englishLong];
frenchAll = [frenchShort; frenchMedium; frenchLong];

% Expand dataset through repetition with variation
numSamples = 300;
englishCorpus = [];
frenchCorpus = [];
sentenceLengths = [];

for i = 1:numSamples
    idx = randi(length(englishAll));
    englishCorpus = [englishCorpus; englishAll(idx)];
    frenchCorpus = [frenchCorpus; frenchAll(idx)];
    
    % Categorise sentence length
    wordCount = length(split(englishAll(idx)));
    if wordCount <= 5
        sentenceLengths = [sentenceLengths; 1]; % Short
    elseif wordCount <= 12
        sentenceLengths = [sentenceLengths; 2]; % Medium
    else
        sentenceLengths = [sentenceLengths; 3]; % Long
    end
end

fprintf('Corpus statistics:\n');
fprintf('  Total sentence pairs: %d\n', length(englishCorpus));
fprintf('  Short sentences: %d\n', sum(sentenceLengths == 1));
fprintf('  Medium sentences: %d\n', sum(sentenceLengths == 2));
fprintf('  Long sentences: %d\n\n', sum(sentenceLengths == 3));

%% Simplified Feature Extraction (Word-Level)
fprintf('Extracting word-level features...\n');

% Tokenise
englishDocs = tokenizedDocument(lower(englishCorpus));
frenchDocs = tokenizedDocument(lower(frenchCorpus));

% Build vocabularies
englishVocab = wordCloud(englishDocs);
frenchVocab = wordCloud(frenchDocs);

% Limit vocabulary size
maxVocabSize = 500;
englishWords = englishVocab.Word(1:min(maxVocabSize, length(englishVocab.Word)));
frenchWords = frenchVocab.Word(1:min(maxVocabSize, length(frenchVocab.Word)));

fprintf('Vocabulary sizes:\n');
fprintf('  English: %d words\n', length(englishWords));
fprintf('  French: %d words\n\n', length(frenchWords));

%% Simulate Attention Mechanisms (Simplified)
fprintf('Simulating attention mechanism behaviours...\n\n');

% For demonstration, we'll simulate attention patterns rather than
% training full neural networks (computationally intensive)

%% Mechanism 1: No Attention (Baseline)
fprintf('Mechanism 1: No Attention (Baseline)...\n');

% Simulate performance degradation with sentence length
bleuNoAttention = struct();
bleuNoAttention.short = 0.65 + 0.05 * randn();
bleuNoAttention.medium = 0.48 + 0.04 * randn();
bleuNoAttention.long = 0.28 + 0.03 * randn();
bleuNoAttention.overall = mean([bleuNoAttention.short, bleuNoAttention.medium, bleuNoAttention.long]);

fprintf('  BLEU Scores:\n');
fprintf('    Short sentences: %.3f\n', bleuNoAttention.short);
fprintf('    Medium sentences: %.3f\n', bleuNoAttention.medium);
fprintf('    Long sentences: %.3f\n', bleuNoAttention.long);
fprintf('    Overall: %.3f\n\n', bleuNoAttention.overall);

%% Mechanism 2: Bahdanau Attention
fprintf('Mechanism 2: Bahdanau (Additive) Attention...\n');

bleuBahdanau = struct();
bleuBahdanau.short = 0.68 + 0.04 * randn();
bleuBahdanau.medium = 0.61 + 0.03 * randn();
bleuBahdanau.long = 0.52 + 0.04 * randn();
bleuBahdanau.overall = mean([bleuBahdanau.short, bleuBahdanau.medium, bleuBahdanau.long]);

% Simulate attention alignment error
alignmentErrorBahdanau = 0.18 + 0.02 * randn();

fprintf('  BLEU Scores:\n');
fprintf('    Short sentences: %.3f\n', bleuBahdanau.short);
fprintf('    Medium sentences: %.3f\n', bleuBahdanau.medium);
fprintf('    Long sentences: %.3f\n', bleuBahdanau.long);
fprintf('    Overall: %.3f\n', bleuBahdanau.overall);
fprintf('  Alignment Error: %.3f\n\n', alignmentErrorBahdanau);

%% Mechanism 3: Luong Attention
fprintf('Mechanism 3: Luong (Multiplicative) Attention...\n');

bleuLuong = struct();
bleuLuong.short = 0.67 + 0.04 * randn();
bleuLuong.medium = 0.60 + 0.03 * randn();
bleuLuong.long = 0.51 + 0.04 * randn();
bleuLuong.overall = mean([bleuLuong.short, bleuLuong.medium, bleuLuong.long]);

alignmentErrorLuong = 0.19 + 0.02 * randn();

fprintf('  BLEU Scores:\n');
fprintf('    Short sentences: %.3f\n', bleuLuong.short);
fprintf('    Medium sentences: %.3f\n', bleuLuong.medium);
fprintf('    Long sentences: %.3f\n', bleuLuong.long);
fprintf('    Overall: %.3f\n', bleuLuong.overall);
fprintf('  Alignment Error: %.3f\n\n', alignmentErrorLuong);

%% Mechanism 4: Multi-Head Self-Attention
fprintf('Mechanism 4: Multi-Head Self-Attention (Transformer)...\n');

bleuMultiHead = struct();
bleuMultiHead.short = 0.71 + 0.03 * randn();
bleuMultiHead.medium = 0.67 + 0.03 * randn();
bleuMultiHead.long = 0.61 + 0.04 * randn();
bleuMultiHead.overall = mean([bleuMultiHead.short, bleuMultiHead.medium, bleuMultiHead.long]);

alignmentErrorMultiHead = 0.14 + 0.02 * randn();

fprintf('  BLEU Scores:\n');
fprintf('    Short sentences: %.3f\n', bleuMultiHead.short);
fprintf('    Medium sentences: %.3f\n', bleuMultiHead.medium);
fprintf('    Long sentences: %.3f\n', bleuMultiHead.long);
fprintf('    Overall: %.3f\n', bleuMultiHead.overall);
fprintf('  Alignment Error: %.3f\n\n', alignmentErrorMultiHead);

%% Generate Attention Visualisation (Simulated)
fprintf('Generating attention visualisation...\n');

% Example sentence: "The cat sleeps on the mat" -> "Le chat dort sur le tapis"
sourceWords = ["The", "cat", "sleeps", "on", "the", "mat"];
targetWords = ["Le", "chat", "dort", "sur", "le", "tapis"];

% Simulate attention weights (Bahdanau)
attentionBahdanau = [
    0.45, 0.35, 0.05, 0.05, 0.05, 0.05;  % Le -> The
    0.05, 0.80, 0.05, 0.05, 0.03, 0.02;  % chat -> cat
    0.02, 0.03, 0.85, 0.05, 0.03, 0.02;  % dort -> sleeps
    0.03, 0.02, 0.05, 0.75, 0.10, 0.05;  % sur -> on
    0.40, 0.05, 0.05, 0.05, 0.40, 0.05;  % le -> the
    0.02, 0.03, 0.02, 0.05, 0.05, 0.83   % tapis -> mat
];

% Simulate multi-head attention (head 1: lexical, head 2: positional)
attentionMultiHead1 = [
    0.50, 0.30, 0.05, 0.05, 0.05, 0.05;
    0.03, 0.85, 0.04, 0.04, 0.02, 0.02;
    0.02, 0.02, 0.90, 0.03, 0.02, 0.01;
    0.02, 0.02, 0.03, 0.85, 0.05, 0.03;
    0.35, 0.05, 0.05, 0.05, 0.45, 0.05;
    0.02, 0.02, 0.02, 0.03, 0.03, 0.88
];

attentionMultiHead2 = [
    0.70, 0.10, 0.05, 0.05, 0.05, 0.05;
    0.10, 0.60, 0.10, 0.10, 0.05, 0.05;
    0.05, 0.10, 0.60, 0.15, 0.05, 0.05;
    0.05, 0.05, 0.15, 0.55, 0.15, 0.05;
    0.05, 0.05, 0.05, 0.15, 0.60, 0.10;
    0.05, 0.05, 0.05, 0.05, 0.10, 0.70
];

%% Results Comparison
fprintf('========================================================================\n');
fprintf('RESULTS SUMMARY\n');
fprintf('========================================================================\n\n');

fprintf('Attention Mechanism Comparison:\n');
fprintf('------------------------\n');
fprintf('Mechanism            Overall BLEU    Long BLEU    Improvement    Align Err\n');
fprintf('------------------------\n');
fprintf('No Attention         %.3f           %.3f        Baseline       N/A\n', ...
    bleuNoAttention.overall, bleuNoAttention.long);
fprintf('Bahdanau            %.3f           %.3f        +%.3f         %.3f\n', ...
    bleuBahdanau.overall, bleuBahdanau.long, ...
    bleuBahdanau.overall - bleuNoAttention.overall, alignmentErrorBahdanau);
fprintf('Luong               %.3f           %.3f        +%.3f         %.3f\n', ...
    bleuLuong.overall, bleuLuong.long, ...
    bleuLuong.overall - bleuNoAttention.overall, alignmentErrorLuong);
fprintf('Multi-Head          %.3f           %.3f        +%.3f         %.3f\n', ...
    bleuMultiHead.overall, bleuMultiHead.long, ...
    bleuMultiHead.overall - bleuNoAttention.overall, alignmentErrorMultiHead);
fprintf('------------------------\n');

%% Visualisation
figure('Position', [100, 100, 1400, 900], 'Color', 'white');

% BLEU score comparison by sentence length
subplot(2, 3, 1);
lengthCategories = {'Short', 'Medium', 'Long'};
bleuData = [
    bleuNoAttention.short, bleuNoAttention.medium, bleuNoAttention.long;
    bleuBahdanau.short, bleuBahdanau.medium, bleuBahdanau.long;
    bleuLuong.short, bleuLuong.medium, bleuLuong.long;
    bleuMultiHead.short, bleuMultiHead.medium, bleuMultiHead.long
];
bar(bleuData');
set(gca, 'XTickLabel', lengthCategories, 'TickLabelInterpreter', 'latex');
ylabel('BLEU Score', 'Interpreter', 'latex');
title('\textbf{BLEU by Sentence Length}', 'Interpreter', 'latex');
legend({'No Attn', 'Bahdanau', 'Luong', 'Multi-Head'}, ...
    'Interpreter', 'latex', 'Location', 'best');
grid on;

% Overall BLEU comparison
subplot(2, 3, 2);
overallBLEU = [bleuNoAttention.overall, bleuBahdanau.overall, ...
    bleuLuong.overall, bleuMultiHead.overall];
bar(overallBLEU, 'FaceColor', [0.3 0.6 0.8]);
set(gca, 'XTickLabel', {'None', 'Bahdanau', 'Luong', 'Multi-Head'}, ...
    'TickLabelInterpreter', 'latex');
ylabel('Overall BLEU', 'Interpreter', 'latex');
title('\textbf{Overall Performance}', 'Interpreter', 'latex');
ylim([0, 1]);
grid on;

% Alignment error comparison
subplot(2, 3, 3);
alignErrors = [alignmentErrorBahdanau, alignmentErrorLuong, alignmentErrorMultiHead];
bar(alignErrors, 'FaceColor', [0.8 0.4 0.2]);
set(gca, 'XTickLabel', {'Bahdanau', 'Luong', 'Multi-Head'}, ...
    'TickLabelInterpreter', 'latex');
ylabel('Alignment Error', 'Interpreter', 'latex');
title('\textbf{Attention Alignment Accuracy}', 'Interpreter', 'latex');
grid on;

% Bahdanau attention heatmap
subplot(2, 3, 4);
imagesc(attentionBahdanau);
colormap(hot);
colorbar;
set(gca, 'XTick', 1:length(sourceWords), 'XTickLabel', sourceWords, ...
    'YTick', 1:length(targetWords), 'YTickLabel', targetWords, ...
    'TickLabelInterpreter', 'latex');
xlabel('Source (English)', 'Interpreter', 'latex');
ylabel('Target (French)', 'Interpreter', 'latex');
title('\textbf{Bahdanau Attention Weights}', 'Interpreter', 'latex');

% Multi-head attention (head 1)
subplot(2, 3, 5);
imagesc(attentionMultiHead1);
colormap(hot);
colorbar;
set(gca, 'XTick', 1:length(sourceWords), 'XTickLabel', sourceWords, ...
    'YTick', 1:length(targetWords), 'YTickLabel', targetWords, ...
    'TickLabelInterpreter', 'latex');
xlabel('Source (English)', 'Interpreter', 'latex');
ylabel('Target (French)', 'Interpreter', 'latex');
title('\textbf{Multi-Head: Head 1 (Lexical)}', 'Interpreter', 'latex');

% Multi-head attention (head 2)
subplot(2, 3, 6);
imagesc(attentionMultiHead2);
colormap(hot);
colorbar;
set(gca, 'XTick', 1:length(sourceWords), 'XTickLabel', sourceWords, ...
    'YTick', 1:length(targetWords), 'YTickLabel', targetWords, ...
    'TickLabelInterpreter', 'latex');
xlabel('Source (English)', 'Interpreter', 'latex');
ylabel('Target (French)', 'Interpreter', 'latex');
title('\textbf{Multi-Head: Head 2 (Positional)}', 'Interpreter', 'latex');

saveas(gcf, 'Problem3_AttentionMechanisms.png');
fprintf('\nSaved: Problem3_AttentionMechanisms.png\n');

fprintf('\n========================================================================\n');
fprintf('Analysis Complete!\n');
fprintf('========================================================================\n');
