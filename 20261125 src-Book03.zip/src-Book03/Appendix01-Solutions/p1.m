%% p1.m
% MATLABBook03_ChapterAIBHS_Problem01.m
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : p1
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function MATLABBook03_ChapterAIBHS_Problem01
% Purpose: PWM, information content, motif scoring. Author: Dr Leo Chen.
% MATLAB R2024b (no toolbox). v1.0 2025-06-01.
    rng(0); set(groot,'defaultTextInterpreter','latex');
    consensus = 'GGACATGCCC'; bases = 'ACGT'; numSites = 40;
    sites = repmat(consensus,numSites,1);
    mask = rand(size(sites)) < 0.15;
    sites(mask) = bases(randi(4,sum(mask(:)),1));
    counts = zeros(4,numel(consensus));
    for p = 1:numel(consensus)
        for b = 1:4, counts(b,p) = sum(sites(:,p)==bases(b)); end
    end
    frequency   = (counts+1)./sum(counts+1,1);
    infoContent = 2 + sum(frequency.*log2(frequency),1);
    fprintf('Total information: %.2f bits\n', sum(infoContent));
    figure; bar(infoContent); grid on;
    xlabel('$\mathrm{Position}$'); ylabel('$\mathrm{Bits}$');
end
