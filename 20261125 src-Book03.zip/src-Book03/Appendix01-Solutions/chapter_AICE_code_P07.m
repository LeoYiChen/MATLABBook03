%% chapter_AICE_code_P07.m
% Solution~7: specification clause retrieval using TF-IDF (MATLABBook02_Chapter13_section8_Problem07.m).
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AICE_code_P07
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% MATLABBook02_Chapter13_section8_Problem07.m
% Problem 7: Specification Clause Retrieval Using TF-IDF
%
% Description : Indexes a corpus of 8 specification clauses
%               with TF-IDF and retrieves the best match for
%               three natural-language engineering queries.
% Author      : Dr Yi Chen
% Date        : 2025
% MATLAB      : R2024b or later
% Toolboxes   : Text Analytics Toolbox
% Reference   : Chapter 13, Problem 7
% =================================================================

%% 1. Define the specification corpus
clauseTexts = [
    "Concrete for foundations shall achieve a characteristic " + ...
    "cube strength of 40 N/mm2 at 28 days."
    "Structural steelwork shall receive intumescent coating " + ...
    "providing 90 minutes fire resistance."
    "Air handling units shall be inspected quarterly and " + ...
    "filters replaced at 2500 hours of operation."
    "Bridge bearings shall be inspected for displacement " + ...
    "exceeding 15 mm from the neutral position."
    "Waterproofing membranes below ground level shall " + ...
    "comply with BS 8102 Grade 3."
    "All electrical installations shall conform to BS 7671 " + ...
    "and be tested before handover."
    "External glazing units shall achieve a U-value not " + ...
    "exceeding 1.2 W/m2K."
    "Acoustic partitions between dwellings shall provide " + ...
    "a minimum airborne sound insulation of 45 dB."];

%% 2. Tokenise and build TF-IDF index
clauseDocuments = tokenizedDocument(clauseTexts);
bagModel        = bagOfWords(clauseDocuments);
tfidfMatrix     = tfidf(bagModel);

%% 3. Define engineering queries
queries = [
    "What is the required concrete strength for foundations?"
    "How often must the air handling unit filters be replaced?"
    "What sound insulation is required between apartments?"];

%% 4. Retrieve and rank for each query
nQueries = numel(queries);
for queryIndex = 1:nQueries
    queryDoc   = tokenizedDocument(queries(queryIndex));
    queryVec   = tfidf(bagModel, queryDoc);
    scores     = cosineSimilarity(tfidfMatrix, queryVec);
    [bestScore, bestIdx] = max(scores);
    fprintf('Query %d: "%s"\n', queryIndex, queries(queryIndex));
    fprintf('  Best match (score %.3f): Clause %d\n', ...
        bestScore, bestIdx);
    fprintf('  "%s"\n\n', clauseTexts(bestIdx));
end

%% 5. Visualise similarity scores for the last query
figure;
bar(scores);
xlabel('Clause Index');
ylabel('Cosine Similarity');
title(sprintf('TF-IDF Retrieval: "%s"', queries(nQueries)));
grid on;
% - Computational Complexity -
% With d = 8 clauses and a vocabulary of v terms, indexing
% costs O(nnz) in the sparse d-by-v matrix. Each query costs
% O(nnz) for TF-IDF encoding and O(d) for the cosine
% similarity sweep plus O(d) for the maximum. Retrieval thus
% scales linearly with corpus size; even corpora of several
% thousand clauses respond in well under one second.
