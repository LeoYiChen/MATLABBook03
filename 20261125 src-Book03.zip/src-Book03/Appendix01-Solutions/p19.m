%% p19.m
% MATLABBook03_ChapterAIBHS_Problem19.m
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : p19
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function MATLABBook03_ChapterAIBHS_Problem19
% Purpose: mixed-effects model of momentary well-being.
% Author: Dr Leo Chen. R2024b + Statistics ML. v1.0 2025-06-01.
    rng(0); nPerson=30; nReport=20; rows=nPerson*nReport;
    person=repelem((1:nPerson)',nReport); outdoors=double(rand(rows,1)>0.5);
    baseline=repelem(randn(nPerson,1)*5,nReport);
    happiness=60+baseline+8*outdoors+3*randn(rows,1);
    tbl=table(happiness,outdoors,categorical(person), ...
        'VariableNames',{'happiness','outdoors','person'});
    lme=fitlme(tbl,'happiness ~ outdoors + (1|person)');
    fprintf('Estimated outdoor effect: %.2f happiness points\n', ...
        lme.Coefficients.Estimate(2));
end
