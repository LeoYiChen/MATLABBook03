%% chapter_AI_CV_problem2_complete.m
% Statistical Significance Testing Framework.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AI_CV_problem2_complete
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% Statistical Significance Testing Framework
% Author: Dr Leo Chen
% Created: January 2025
% MATLAB Version: R2024a or later

function testingResults = statisticalSignificanceTesting()
    fprintf('Statistical Significance Testing Framework\n');
    
    % Generate model performance data
    modelPerformance = generateModelPerformanceData();
    
    % Perform statistical tests
    testResults = performStatisticalTests(modelPerformance);
    
    % Visualise results
    visualiseStatisticalResults(testResults);
    
    testingResults = testResults;
end

function performance = generateModelPerformanceData()
    numModels = 6;
    numFolds = 10;
    numMetrics = 4;
    
    performance = struct();
    performance.modelNames = {'CNN-Basic', 'ResNet-50', 'VGG-16', 'DenseNet', 'EfficientNet', 'ViT'};
    performance.metricNames = {'Accuracy', 'Precision', 'Recall', 'F1-Score'};
    performance.scores = zeros(numModels, numFolds, numMetrics);
    
    basePerformances = [0.82, 0.89, 0.85, 0.91, 0.93, 0.88];
    
    for modelIndex = 1:numModels
        basePerf = basePerformances(modelIndex);
        
        for foldIndex = 1:numFolds
            for metricIndex = 1:numMetrics
                noise = randn() * 0.02;
                metricAdjustment = (metricIndex - 2.5) * 0.01;
                
                score = basePerf + metricAdjustment + noise;
                score = max(0, min(1, score));
                
                performance.scores(modelIndex, foldIndex, metricIndex) = score;
            end
        end
    end
end

function results = performStatisticalTests(performance)
    results = struct();
    
    % Pairwise comparisons
    results.pairwiseTests = performPairwiseComparisons(performance);
    
    % Multiple comparison corrections
    results.multipleComparisons = applyMultipleComparisonCorrections(results.pairwiseTests);
    
    % Effect size calculations
    results.effectSizes = calculateEffectSizes(performance);
    
    % Bootstrap confidence intervals
    results.bootstrapCI = computeBootstrapConfidenceIntervals(performance);
end

function pairwise = performPairwiseComparisons(performance)
    numModels = size(performance.scores, 1);
    numMetrics = size(performance.scores, 3);
    
    pairwise = struct();
    pairwise.numComparisons = nchoosek(numModels, 2);
    pairwise.comparisons = nchoosek(1:numModels, 2);
    
    pairwise.tTestPValues = zeros(pairwise.numComparisons, numMetrics);
    pairwise.wilcoxonPValues = zeros(pairwise.numComparisons, numMetrics);
    pairwise.meanDifferences = zeros(pairwise.numComparisons, numMetrics);
    
    for compIndex = 1:pairwise.numComparisons
        model1 = pairwise.comparisons(compIndex, 1);
        model2 = pairwise.comparisons(compIndex, 2);
        
        for metricIndex = 1:numMetrics
            scores1 = squeeze(performance.scores(model1, :, metricIndex));
            scores2 = squeeze(performance.scores(model2, :, metricIndex));
            
            % Paired t-test
            [~, pairwise.tTestPValues(compIndex, metricIndex)] = ttest(scores1, scores2);
            
            % Wilcoxon signed-rank test
            pairwise.wilcoxonPValues(compIndex, metricIndex) = signrank(scores1, scores2);
            
            % Mean difference
            pairwise.meanDifferences(compIndex, metricIndex) = mean(scores1) - mean(scores2);
        end
    end
end

function corrected = applyMultipleComparisonCorrections(pairwiseResults)
    corrected = struct();
    
    for metricIndex = 1:size(pairwiseResults.tTestPValues, 2)
        originalPValues = pairwiseResults.tTestPValues(:, metricIndex);
        
        % Bonferroni correction
        corrected.bonferroni(:, metricIndex) = min(originalPValues * length(originalPValues), 1);
        
        % Holm correction
        corrected.holm(:, metricIndex) = applyHolmCorrection(originalPValues);
        
        % False Discovery Rate
        corrected.fdr(:, metricIndex) = applyFDRCorrection(originalPValues);
    end
    
    corrected.original = pairwiseResults.tTestPValues;
end

function holmPValues = applyHolmCorrection(pValues)
    [sortedP, sortIdx] = sort(pValues);
    numTests = length(pValues);
    holmPValues = zeros(size(pValues));
    
    for testIndex = 1:numTests
        adjustment = numTests - testIndex + 1;
        correctedP = sortedP(testIndex) * adjustment;
        
        if testIndex > 1
            correctedP = max(correctedP, holmPValues(sortIdx(testIndex - 1)));
        end
        
        holmPValues(sortIdx(testIndex)) = min(correctedP, 1);
    end
end

function fdrPValues = applyFDRCorrection(pValues)
    [sortedP, sortIdx] = sort(pValues);
    numTests = length(pValues);
    fdrPValues = zeros(size(pValues));
    
    for testIndex = numTests:-1:1
        adjustment = numTests / testIndex;
        correctedP = sortedP(testIndex) * adjustment;
        
        if testIndex < numTests
            correctedP = min(correctedP, fdrPValues(sortIdx(testIndex + 1)));
        end
        
        fdrPValues(sortIdx(testIndex)) = min(correctedP, 1);
    end
end

function effectSizes = calculateEffectSizes(performance)
    numModels = size(performance.scores, 1);
    numMetrics = size(performance.scores, 3);
    numComparisons = nchoosek(numModels, 2);
    comparisons = nchoosek(1:numModels, 2);
    
    effectSizes = struct();
    effectSizes.cohensD = zeros(numComparisons, numMetrics);
    
    for compIndex = 1:numComparisons
        model1 = comparisons(compIndex, 1);
        model2 = comparisons(compIndex, 2);
        
        for metricIndex = 1:numMetrics
            scores1 = squeeze(performance.scores(model1, :, metricIndex));
            scores2 = squeeze(performance.scores(model2, :, metricIndex));
            
            mean1 = mean(scores1);
            mean2 = mean(scores2);
            std1 = std(scores1);
            std2 = std(scores2);
            n1 = length(scores1);
            n2 = length(scores2);
            
            pooledSD = sqrt(((n1 - 1) * std1^2 + (n2 - 1) * std2^2) / (n1 + n2 - 2));
            effectSizes.cohensD(compIndex, metricIndex) = (mean1 - mean2) / pooledSD;
        end
    end
end

function bootstrapCI = computeBootstrapConfidenceIntervals(performance)
    numBootstrap = 1000;
    numModels = size(performance.scores, 1);
    numMetrics = size(performance.scores, 3);
    
    bootstrapCI = struct();
    bootstrapCI.lowerBound = zeros(numModels, numMetrics);
    bootstrapCI.upperBound = zeros(numModels, numMetrics);
    
    for modelIndex = 1:numModels
        for metricIndex = 1:numMetrics
            originalScores = squeeze(performance.scores(modelIndex, :, metricIndex));
            numSamples = length(originalScores);
            
            bootstrapMeans = zeros(numBootstrap, 1);
            
            for bootIndex = 1:numBootstrap
                bootIdx = randi(numSamples, numSamples, 1);
                bootSample = originalScores(bootIdx);
                bootstrapMeans(bootIndex) = mean(bootSample);
            end
            
            bootstrapCI.lowerBound(modelIndex, metricIndex) = prctile(bootstrapMeans, 2.5);
            bootstrapCI.upperBound(modelIndex, metricIndex) = prctile(bootstrapMeans, 97.5);
        end
    end
end

function visualiseStatisticalResults(results)
    figure('Position', [100, 100, 1200, 800]);
    
    % P-value heatmap
    subplot(2, 2, 1);
    imagesc(results.pairwiseTests.tTestPValues);
    colorbar;
    title('Pairwise t-test p-values');
    xlabel('Metric');
    ylabel('Model Comparison');
    
    % Effect sizes
    subplot(2, 2, 2);
    bar(results.effectSizes.cohensD);
    xlabel('Model Comparison');
    ylabel('Cohen''s d');
    title('Effect Sizes');
    
    % Bootstrap confidence intervals
    subplot(2, 2, 3);
    errorbar(1:size(results.bootstrapCI.lowerBound, 1), ...
            mean(results.bootstrapCI.lowerBound, 2), ...
            mean(results.bootstrapCI.lowerBound, 2) - mean(results.bootstrapCI.lowerBound, 2), ...
            mean(results.bootstrapCI.upperBound, 2) - mean(results.bootstrapCI.lowerBound, 2), ...
            'o-');
    xlabel('Model');
    ylabel('Performance');
    title('Bootstrap Confidence Intervals');
    
    % Multiple comparison corrections
    subplot(2, 2, 4);
    metricIndex = 1;
    originalP = results.multipleComparisons.original(:, metricIndex);
    bonferroniP = results.multipleComparisons.bonferroni(:, metricIndex);
    
    scatter(originalP, bonferroniP);
    xlabel('Original p-value');
    ylabel('Bonferroni corrected p-value');
    title('Multiple Comparison Correction');
    line([0, 1], [0, 1], 'Color', 'red', 'LineStyle', '--');
    
    sgtitle('Statistical Significance Testing Results');
end

% Execute main function
testingResults = statisticalSignificanceTesting();
