%% p15.m
% MATLABBook03_ChapterAIBHS_Problem15.m
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : p15
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function MATLABBook03_ChapterAIBHS_Problem15
% Purpose: exponential model of rumination reduction under CBT.
% Author: Dr Leo Chen. R2024b (no toolbox). v1.0 2025-06-01.
    rng(0); week=(0:11)'; trueRate=0.20;
    score=50*exp(-trueRate*week)+2*randn(size(week));
    coeff=polyfit(week,log(max(score,1)),1); rate=-coeff(1);
    fprintf('Reduction rate: %.3f /week  Half-life: %.1f weeks\n', rate, log(2)/rate);
    figure; plot(week,score,'o'); hold on;
    plot(week,exp(coeff(2))*exp(coeff(1)*week),'-'); grid on;
    xlabel('$\mathrm{Week}$'); ylabel('$\mathrm{Rumination\ score}$');
end
