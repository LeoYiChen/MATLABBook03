%% chapter_AICSS_problem1_integrated_anomaly.m
% Integrated anomaly detection system for industrial control systems.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AICSS_problem1_integrated_anomaly
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function anomalyResults = detectIntegratedAnomalies(sensorData, controlData, networkData, baselineModel)
    % Comprehensive anomaly detection across multiple domains
    % Author: Dr Leo Chen
    % Version: 1.0 - Initial implementation
    % Date: December 2024
    
    fprintf('Executing integrated anomaly detection analysis...\n');
    
    % Initialize results structure
    anomalyResults = struct();
    anomalyResults.timestamp = datetime('now');
    
    % Process domain anomaly detection
    processFeatures = extractProcessFeatures(sensorData);
    processAnomalyScore = detectProcessAnomalies(processFeatures, baselineModel.process);
    
    % Control domain anomaly detection  
    controlFeatures = extractControlFeatures(controlData);
    controlAnomalyScore = detectControlAnomalies(controlFeatures, baselineModel.control);
    
    % Network domain anomaly detection
    networkFeatures = extractNetworkFeatures(networkData);
    networkAnomalyScore = detectNetworkAnomalies(networkFeatures, baselineModel.network);
    
    % Multi-domain fusion
    fusedAnomalyScore = fuseAnomalyScores(processAnomalyScore, controlAnomalyScore, networkAnomalyScore);
    
    % Classification and decision making
    [anomalyClassification, confidenceLevel] = classifyAnomaly(fusedAnomalyScore, baselineModel.classifier);
    
    % Store results
    anomalyResults.processScore = processAnomalyScore;
    anomalyResults.controlScore = controlAnomalyScore;
    anomalyResults.networkScore = networkAnomalyScore;
    anomalyResults.fusedScore = fusedAnomalyScore;
    anomalyResults.classification = anomalyClassification;
    anomalyResults.confidence = confidenceLevel;
    
    % Generate visualisation
    generateAnomalyvisualisation(anomalyResults, sensorData);
    
    % Save results
    saveAnomalyResults(anomalyResults);
    
    fprintf('Integrated anomaly detection completed. Overall anomaly score: %.3f\n', fusedAnomalyScore);
end

function processFeatures = extractProcessFeatures(sensorData)
    % Extract comprehensive features from process sensor data
    processFeatures = struct();
    
    % Statistical features
    processFeatures.mean = mean(sensorData, 1);
    processFeatures.std = std(sensorData, 0, 1);
    processFeatures.skewness = skewness(sensorData, 0, 1);
    processFeatures.kurtosis = kurtosis(sensorData, 0, 1);
    
    % Temporal features
    processFeatures.trend = calculateTrend(sensorData);
    processFeatures.periodicity = detectPeriodicity(sensorData);
    
    % Cross-correlation features
    processFeatures.crossCorrelation = calculateCrossCorrelations(sensorData);
end

function generateAnomalyvisualisation(results, sensorData)
    % Generate comprehensive visualisation of anomaly detection results
    
    figure('Position', [100, 100, 1400, 800]);
    
    % Time series plot with anomaly scores
    subplot(2, 3, 1);
    timeVector = 1:size(sensorData, 1);
    plot(timeVector, sensorData(:, 1), 'b-', 'LineWidth', 1.5);
    hold on;
    anomalyIndices = results.fusedScore > 0.7;
    plot(timeVector(anomalyIndices), sensorData(anomalyIndices, 1), 'ro', 'MarkerSize', 8);
    xlabel('Time (samples)');
    ylabel('Process Variable 1');
    title('Process Data with Detected Anomalies');
    legend({'Normal Data', 'Detected Anomalies'}, 'Location', 'best');
    grid on;
    
    % Anomaly score evolution
    subplot(2, 3, 2);
    plot(timeVector, [results.processScore, results.controlScore, results.networkScore], 'LineWidth', 2);
    xlabel('Time (samples)');
    ylabel('Anomaly Score');
    title('Multi-Domain Anomaly Scores');
    legend({'Process', 'Control', 'Network'}, 'Location', 'best');
    grid on;
    
    % Fused anomaly score
    subplot(2, 3, 3);
    plot(timeVector, results.fusedScore, 'r-', 'LineWidth', 2);
    hold on;
    yline(0.7, 'k--', 'Threshold', 'LineWidth', 1.5);
    xlabel('Time (samples)');
    ylabel('Fused Anomaly Score');
    title('Integrated Anomaly Detection');
    grid on;
    
    % Feature correlation heatmap
    subplot(2, 3, 4);
    correlationMatrix = corrcoef([results.processScore(:), results.controlScore(:), results.networkScore(:)]);
    imagesc(correlationMatrix);
    colorbar;
    set(gca, 'XTickLabel', {'Process', 'Control', 'Network'});
    set(gca, 'YTickLabel', {'Process', 'Control', 'Network'});
    title('Domain Correlation Matrix');
    
    % Classification results
    subplot(2, 3, 5);
    classificationCounts = [sum(results.classification == 0), sum(results.classification == 1), sum(results.classification == 2)];
    bar(classificationCounts);
    set(gca, 'XTickLabel', {'Normal', 'Process Anomaly', 'Cyber Threat'});
    ylabel('Count');
    title('Classification Results');
    grid on;
    
    % Confidence distribution
    subplot(2, 3, 6);
    histogram(results.confidence, 20);
    xlabel('Confidence Level');
    ylabel('Frequency');
    title('Classification Confidence Distribution');
    grid on;
    
    % Save visualisation in multiple formats
    saveas(gcf, 'AnomalyDetectionResults.fig');
    saveas(gcf, 'AnomalyDetectionResults.eps', 'epsc');
    saveas(gcf, 'AnomalyDetectionResults.jpg');
    
    fprintf('Anomaly detection visualisation saved in multiple formats.\n');
end
