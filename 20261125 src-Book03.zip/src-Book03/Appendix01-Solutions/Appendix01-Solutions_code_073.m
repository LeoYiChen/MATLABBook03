%% Appendix01-Solutions_code_073.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Load preprocessed tweet dataset
load('twitter_sentiment_2024.mat'); % Contains: texts, labels, timestamps

% Inject artificial drift points
drift_points = [5000, 15000, 25000]; % Tweet indices where drift occurs
for dp = drift_points
    % Simulate drift: swap positive/negative labels with probability 0.3
    idx = dp:dp+2000;
    swap_mask = rand(length(idx),1) < 0.3;
    labels(idx(swap_mask)) = -labels(idx(swap_mask));
    
    % Inject new slang words
    new_slang = {'lit', 'goat', 'cap', 'bussin', 'W', 'L'};
    for i = idx
        if rand < 0.2
            texts{i} = [texts{i}, ' ', new_slang{randi(6)}];
        end
    end
end

% Stream simulator
stream_rate = 100; % tweets per second (simulated)
for t = 1:length(texts)
    current_tweet = texts{t};
    current_label = labels(t);
    current_time = timestamps(t);
    
    % Process tweet (call sentiment classifier)
    processTweet(current_tweet, current_label, current_time);
    
    % Simulate time delay
    pause(1/stream_rate);
end
