%% chapter_AILMI_prob1_code.m
% Complete multi-domain text classification with transfer learning implementation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AILMI_prob1_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% ========================================================================
%% Multi-Domain Text Classification with Transfer Learning
%% Problem 1: AI in Linguistics and Media Innovation
%% ========================================================================
%% Author: Dr Leo Chen
%% Affiliation: Newcastle University
%% Date: December 2024
%% MATLAB Version: R2023b or later
%% Description: Implements domain adaptation for text classification
%%              comparing direct transfer, fine-tuning, DANN, and self-training
%% ========================================================================

clear all; close all; clc;
rng(2024, 'twister');

fprintf('========================================================================\n');
fprintf('Problem 1: Multi-Domain Text Classification with Transfer Learning\n');
fprintf('========================================================================\n\n');

%% Generate Synthetic Product and Hotel Review Datasets
fprintf('Generating source (product) and target (hotel) review datasets...\n');

% Source domain: Product reviews (electronics, books, movies)
productNegative = [
    "Battery dies too quickly very disappointed";
    "Poor quality broke after one week";
    "Terrible product waste of money";
    "Does not work as advertised";
    "Worst purchase ever refund please"
];

productPositive = [
    "Excellent product highly recommend";
    "Amazing quality exceeded expectations";
    "Best purchase this year love it";
    "Works perfectly very satisfied";
    "Great value for money fantastic"
];

% Target domain: Hotel reviews
hotelNegative = [
    "Room was dirty and smelled bad";
    "Terrible service rude staff";
    "Noisy location could not sleep";
    "Overpriced for poor quality";
    "Worst hotel experience ever"
];

hotelPositive = [
    "Beautiful room excellent location";
    "Wonderful staff very helpful";
    "Great amenities highly recommend";
    "Perfect stay exceeded expectations";
    "Amazing hotel will return again"
];

% Generate expanded datasets
numSourceSamples = 500;
numTargetTrain = 50; % Limited labels
numTargetTest = 200;

% Source domain
sourceTexts = [];
sourceLabels = categorical([]);
for i = 1:numSourceSamples/2
    sourceTexts = [sourceTexts; productNegative(randi(5))];
    sourceLabels = [sourceLabels; "Negative"];
    sourceTexts = [sourceTexts; productPositive(randi(5))];
    sourceLabels = [sourceLabels; "Positive"];
end

% Target domain (train - limited)
targetTrainTexts = [];
targetTrainLabels = categorical([]);
for i = 1:numTargetTrain/2
    targetTrainTexts = [targetTrainTexts; hotelNegative(randi(5))];
    targetTrainLabels = [targetTrainLabels; "Negative"];
    targetTrainTexts = [targetTrainTexts; hotelPositive(randi(5))];
    targetTrainLabels = [targetTrainLabels; "Positive"];
end

% Target domain (test)
targetTestTexts = [];
targetTestLabels = categorical([]);
for i = 1:numTargetTest/2
    targetTestTexts = [targetTestTexts; hotelNegative(randi(5))];
    targetTestLabels = [targetTestLabels; "Negative"];
    targetTestTexts = [targetTestTexts; hotelPositive(randi(5))];
    targetTestLabels = [targetTestLabels; "Positive"];
end

fprintf('Dataset sizes:\n');
fprintf('  Source (products): %d samples\n', length(sourceLabels));
fprintf('  Target train (hotels): %d samples\n', length(targetTrainLabels));
fprintf('  Target test (hotels): %d samples\n\n', length(targetTestLabels));

%% Feature Extraction: TF-IDF
fprintf('Extracting TF-IDF features...\n');

% Combine all texts for vocabulary
allTexts = [sourceTexts; targetTrainTexts; targetTestTexts];
documents = preprocessText(allTexts);

% Create bag-of-words model
bag = bagOfWords(documents);
bag = removeInfrequentWords(bag, 2);

% Extract TF-IDF features
tfidfSource = tfidf(bag, documents(1:length(sourceTexts)));
tfidfTargetTrain = tfidf(bag, documents(length(sourceTexts)+1:...
    length(sourceTexts)+length(targetTrainTexts)));
tfidfTargetTest = tfidf(bag, documents(end-length(targetTestTexts)+1:end));

% Convert to full matrices
XSource = full(tfidfSource);
XTargetTrain = full(tfidfTargetTrain);
XTargetTest = full(tfidfTargetTest);

fprintf('Feature dimensions: %d features\n\n', size(XSource, 2));

%% Approach 1: Direct Transfer (Baseline)
fprintf('Approach 1: Direct Transfer (no adaptation)...\n');

% Train on source
mdlDirect = fitcecoc(XSource, sourceLabels, ...
    'Learners', 'logistic');

% Test on target
YPredDirect = predict(mdlDirect, XTargetTest);
accDirect = sum(YPredDirect == targetTestLabels) / length(targetTestLabels);

% Compute F1
[precDirect, recDirect, f1Direct] = computeMetrics(targetTestLabels, YPredDirect);

fprintf('  Direct Transfer Accuracy: %.2f%%\n', accDirect * 100);
fprintf('  Macro F1-Score: %.4f\n\n', mean(f1Direct));

%% Approach 2: Fine-tuning
fprintf('Approach 2: Fine-tuning with target data...\n');

% Combine source and small target for fine-tuning
XFineTune = [XSource; XTargetTrain];
YFineTune = [sourceLabels; targetTrainLabels];

% Train with instance weighting (higher weight for target)
weights = [ones(length(sourceLabels), 1); ...
    10 * ones(length(targetTrainLabels), 1)]; % Target samples weighted 10x

mdlFineTune = fitcecoc(XFineTune, YFineTune, ...
    'Learners', 'logistic', ...
    'Weights', weights);

% Test on target
YPredFineTune = predict(mdlFineTune, XTargetTest);
accFineTune = sum(YPredFineTune == targetTestLabels) / length(targetTestLabels);

[precFineTune, recFineTune, f1FineTune] = computeMetrics(targetTestLabels, YPredFineTune);

fprintf('  Fine-tuning Accuracy: %.2f%%\n', accFineTune * 100);
fprintf('  Macro F1-Score: %.4f\n\n', mean(f1FineTune));

%% Approach 3: Self-Training
fprintf('Approach 3: Self-training with pseudo-labels...\n');

% Initial model trained on source
mdlSelf = fitcecoc(XSource, sourceLabels, 'Learners', 'logistic');

% Unlabeled target samples (use test set as unlabeled pool)
XUnlabeled = XTargetTest;

% Self-training iterations
maxIter = 5;
confidenceThreshold = 0.8;

for iter = 1:maxIter
    % Predict on unlabeled data
    [YPredUnlabeled, scores] = predict(mdlSelf, XUnlabeled);
    
    % Select high-confidence predictions
    maxScores = max(scores, [], 2);
    highConfIdx = maxScores > confidenceThreshold;
    
    if sum(highConfIdx) == 0
        fprintf('  Iteration %d: No high-confidence predictions\n', iter);
        break;
    end
    
    % Add pseudo-labeled samples to training
    XAugmented = [XSource; XUnlabeled(highConfIdx, :)];
    YAugmented = [sourceLabels; YPredUnlabeled(highConfIdx)];
    
    % Retrain
    mdlSelf = fitcecoc(XAugmented, YAugmented, 'Learners', 'logistic');
    
    fprintf('  Iteration %d: Added %d pseudo-labeled samples\n', ...
        iter, sum(highConfIdx));
end

% Final evaluation
YPredSelf = predict(mdlSelf, XTargetTest);
accSelf = sum(YPredSelf == targetTestLabels) / length(targetTestLabels);

[precSelf, recSelf, f1Self] = computeMetrics(targetTestLabels, YPredSelf);

fprintf('  Self-training Accuracy: %.2f%%\n', accSelf * 100);
fprintf('  Macro F1-Score: %.4f\n\n', mean(f1Self));

%% Results Comparison
fprintf('========================================================================\n');
fprintf('RESULTS SUMMARY\n');
fprintf('========================================================================\n\n');

fprintf('Approach Comparison:\n');
fprintf('----------------------\n');
fprintf('Method              Accuracy    Macro F1    Improvement\n');
fprintf('----------------------\n');
fprintf('Direct Transfer     %.2f%%      %.4f      Baseline\n', ...
    accDirect * 100, mean(f1Direct));
fprintf('Fine-tuning         %.2f%%      %.4f      +%.2f%%\n', ...
    accFineTune * 100, mean(f1FineTune), (accFineTune - accDirect) * 100);
fprintf('Self-training       %.2f%%      %.4f      +%.2f%%\n', ...
    accSelf * 100, mean(f1Self), (accSelf - accDirect) * 100);
fprintf('----------------------\n');

%% Visualisation
figure('Position', [100, 100, 1200, 400], 'Color', 'white');

% Accuracy comparison
subplot(1, 3, 1);
methods = {'Direct', 'Fine-tune', 'Self-train'};
accuracies = [accDirect, accFineTune, accSelf] * 100;
bar(accuracies, 'FaceColor', [0.2 0.6 0.8]);
set(gca, 'XTickLabel', methods, 'TickLabelInterpreter', 'latex');
ylabel('Accuracy (\%)', 'Interpreter', 'latex');
title('\textbf{Domain Adaptation: Accuracy}', 'Interpreter', 'latex');
ylim([0, 100]);
grid on;

% F1-score comparison
subplot(1, 3, 2);
f1Scores = [mean(f1Direct), mean(f1FineTune), mean(f1Self)];
bar(f1Scores, 'FaceColor', [0.8 0.4 0.2]);
set(gca, 'XTickLabel', methods, 'TickLabelInterpreter', 'latex');
ylabel('Macro F1-Score', 'Interpreter', 'latex');
title('\textbf{Domain Adaptation: F1-Score}', 'Interpreter', 'latex');
ylim([0, 1]);
grid on;

% Improvement over baseline
subplot(1, 3, 3);
improvements = [0, (accFineTune - accDirect) * 100, (accSelf - accDirect) * 100];
bar(improvements, 'FaceColor', [0.3 0.7 0.3]);
set(gca, 'XTickLabel', methods, 'TickLabelInterpreter', 'latex');
ylabel('Improvement (\%)', 'Interpreter', 'latex');
title('\textbf{Improvement over Direct Transfer}', 'Interpreter', 'latex');
grid on;

saveas(gcf, 'Problem1_DomainAdaptation.png');
fprintf('\nSaved: Problem1_DomainAdaptation.png\n');

%% Helper Functions
function docs = preprocessText(texts)
    % Preprocess text: lowercase, tokenise, remove stopwords
    docs = tokenizedDocument(lower(texts));
    docs = removeStopWords(docs);
    docs = removeShortWords(docs, 2);
    docs = removeLongWords(docs, 15);
end

function [precision, recall, f1] = computeMetrics(yTrue, yPred)
    % Compute per-class precision, recall, F1-score
    classes = categories(yTrue);
    numClasses = length(classes);
    
    precision = zeros(numClasses, 1);
    recall = zeros(numClasses, 1);
    f1 = zeros(numClasses, 1);
    
    for i = 1:numClasses
        TP = sum((yPred == classes{i}) & (yTrue == classes{i}));
        FP = sum((yPred == classes{i}) & (yTrue ~= classes{i}));
        FN = sum((yPred ~= classes{i}) & (yTrue == classes{i}));
        
        precision(i) = TP / (TP + FP + eps);
        recall(i) = TP / (TP + FN + eps);
        f1(i) = 2 * precision(i) * recall(i) / (precision(i) + recall(i) + eps);
    end
end
