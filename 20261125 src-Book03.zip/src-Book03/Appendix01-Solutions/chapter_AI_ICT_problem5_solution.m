%% chapter_AI_ICT_problem5_solution.m
% Federated Learning for Channel Prediction
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AI_ICT_problem5_solution
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [federated_results, convergence_analysis] = federatedChannelPrediction()
% Federated Learning for Distributed Channel Prediction
% Author: Dr Leo Chen
% Version: 1.0
% Date: 2024
%
% Implements federated learning framework for collaborative channel prediction
% across heterogeneous base station networks with privacy preservation

fprintf('=== Federated Channel Prediction Solution ===\n');

% Federated learning configuration
federated_config = struct();
federated_config.num_base_stations = 15; % Participating base stations
federated_config.num_rounds = 100; % Federated learning rounds
federated_config.local_epochs = 5; % Local training epochs
federated_config.learning_rate = 1e-3; % Learning rate
federated_config.aggregation_method = 'fedavg'; % Aggregation algorithm
federated_config.privacy_budget = 1.0; % Differential privacy budget

% Network heterogeneity configuration
heterogeneity_config = struct();
heterogeneity_config.data_distribution = 'non_iid'; % Data distribution type
heterogeneity_config.computation_heterogeneity = true; % Varying compute capabilities
heterogeneity_config.communication_constraints = true; % Limited bandwidth
heterogeneity_config.byzantine_nodes = 2; % Number of Byzantine participants

% Channel prediction task configuration
prediction_config = struct();
prediction_config.prediction_horizon = 10; % Prediction steps ahead
prediction_config.input_features = 20; % Input feature dimension
prediction_config.hidden_units = 64; % Neural network hidden units
prediction_config.output_dimension = 4; % MIMO channel outputs

% Initialise federated learning environment
fprintf('Initialising federated learning environment...\n');
federated_environment = initialiseFederatedEnvironment(federated_config, ...
heterogeneity_config, ...
prediction_config);

% Create distributed channel datasets
fprintf('Creating distributed channel datasets...\n');
distributed_datasets = createDistributedChannelDatasets(federated_environment);

% Implement federated learning algorithms
fprintf('Implementing federated learning algorithms...\n');
federated_algorithms = implementFederatedAlgorithms(federated_config, prediction_config);

% Execute federated training process
fprintf('Executing federated training process...\n');
[global_model, training_history] = executeFederatedTraining(federated_algorithms, ...
distributed_datasets, ...
federated_environment);

% Evaluate federated learning performance
fprintf('Evaluating federated learning performance...\n');
federated_results = evaluateFederatedPerformance(global_model, distributed_datasets, ...
federated_environment);

% Analyse convergence behaviour and communication efficiency
convergence_analysis = analyseConvergenceBehaviour(training_history, federated_config);

% Generate comprehensive visualisations
generateFederatedLearningVisualisations(federated_results, convergence_analysis, training_history);

fprintf('Federated channel prediction analysis completed successfully!\n');
end

function federated_environment = initialiseFederatedEnvironment(fed_config, het_config, pred_config)
% Initialise comprehensive federated learning environment

federated_environment = struct();
federated_environment.config = fed_config;
federated_environment.heterogeneity = het_config;
federated_environment.prediction_task = pred_config;

% Base station characteristics
federated_environment.base_stations = initialiseBaseStationCharacteristics(fed_config, het_config);

% Communication network topology
federated_environment.communication_topology = createCommunicationTopology(fed_config);

% Privacy and security framework
federated_environment.privacy_framework = initialisePrivacyFramework(fed_config);

% Performance monitoring system
federated_environment.monitoring_system = initialiseMonitoringSystem(fed_config);

fprintf(' Federated environment initialised with %d base stations\n', fed_config.num_base_stations);
end

function distributed_datasets = createDistributedChannelDatasets(environment)
% Create heterogeneous channel datasets across base stations

distributed_datasets = cell(environment.config.num_base_stations, 1);
base_stations = environment.base_stations;

for bs_idx = 1:length(base_stations)
bs_characteristics = base_stations{bs_idx};

 
fprintf('  Creating dataset for base station %d...\n', bs_idx);

% Generate channel data based on base station characteristics
dataset = generateBaseStationChannelData(bs_characteristics, environment);

% Apply data heterogeneity patterns
heterogeneous_dataset = applyDataHeterogeneity(dataset, environment.heterogeneity, bs_idx);

% Add privacy noise if required
if environment.privacy_framework.differential_privacy_enabled
    privacy_dataset = addDifferentialPrivacyNoise(heterogeneous_dataset, environment.privacy_framework);
    distributed_datasets{bs_idx} = privacy_dataset;
else
    distributed_datasets{bs_idx} = heterogeneous_dataset;
end
end

fprintf(' Distributed datasets created for %d base stations\n', length(distributed_datasets));
end

function federated_algorithms = implementFederatedAlgorithms(fed_config, pred_config)
% Implement comprehensive federated learning algorithms

federated_algorithms = struct();

% FedAvg algorithm implementation
federated_algorithms.fedavg = implementFedAvgAlgorithm(fed_config, pred_config);

% FedProx algorithm for heterogeneous environments
federated_algorithms.fedprox = implementFedProxAlgorithm(fed_config, pred_config);

% Adaptive aggregation algorithm
federated_algorithms.adaptive_agg = implementAdaptiveAggregation(fed_config, pred_config);

% Byzantine-robust aggregation
federated_algorithms.byzantine_robust = implementByzantineRobustAggregation(fed_config, pred_config);

% Communication-efficient algorithms
federated_algorithms.communication_efficient = implementCommunicationEfficientAlgorithms(fed_config, pred_config);

fprintf(' Federated algorithms implemented: %d variants\n', length(fieldnames(federated_algorithms)));
end

function fedavg_algorithm = implementFedAvgAlgorithm(fed_config, pred_config)
% Implement FedAvg algorithm for federated learning

fedavg_algorithm = struct();
fedavg_algorithm.name = 'Federated Averaging';

% Global model initialisation
fedavg_algorithm.global_model = initialiseGlobalModel(pred_config);

% Client selection strategy
fedavg_algorithm.client_selection = @(round, clients) selectRandomClients(round, clients, fed_config.participation_rate);

% Local training function
fedavg_algorithm.local_training = @(model, dataset, config) performLocalTraining(model, dataset, config);

% Model aggregation function
fedavg_algorithm.aggregation = @(local_models, client_weights) aggregateModelsWeighted(local_models, client_weights);

% Convergence criteria
fedavg_algorithm.convergence_check = @(round, performance_history) checkFedAvgConvergence(round, performance_history);

fprintf(' FedAvg algorithm configured\n');
end

function [global_model, training_history] = executeFederatedTraining(algorithms, datasets, environment)
% Execute comprehensive federated training process

training_history = struct();
training_history.rounds = [];
training_history.global_loss = [];
training_history.local_losses = [];
training_history.communication_costs = [];
training_history.privacy_costs = [];

% Select primary algorithm for execution
primary_algorithm = algorithms.fedavg; % Can be configured
global_model = primary_algorithm.global_model;

fprintf(' Starting federated training with %s algorithm...\n', primary_algorithm.name);

for round = 1:environment.config.num_rounds
fprintf(' Round %d/%d...\n', round, environment.config.num_rounds);

 
% Select participating clients
selected_clients = primary_algorithm.client_selection(round, environment.base_stations);

% Distribute global model to selected clients
communication_cost = distributeGlobalModel(global_model, selected_clients, environment);

% Perform local training at selected clients
local_models = cell(length(selected_clients), 1);
local_losses = zeros(length(selected_clients), 1);

for client_idx = 1:length(selected_clients)
    client_id = selected_clients(client_idx);
    client_dataset = datasets{client_id};
    
    [local_models{client_idx}, local_losses(client_idx)] = primary_algorithm.local_training(global_model, ...
                                                                                           client_dataset, ...
                                                                                           environment.config);
end

% Calculate client weights based on dataset sizes
client_weights = calculateClientWeights(selected_clients, datasets);

% Aggregate local models
global_model = primary_algorithm.aggregation(local_models, client_weights);

% Evaluate global model performance
global_loss = evaluateGlobalModelPerformance(global_model, datasets);

% Update training history
training_history.rounds(end+1) = round;
training_history.global_loss(end+1) = global_loss;
training_history.local_losses{end+1} = local_losses;
training_history.communication_costs(end+1) = communication_cost;

% Check convergence
if primary_algorithm.convergence_check(round, training_history)
    fprintf('    Federated training converged at round %d\n', round);
    break;
end
end

fprintf(' Federated training completed after %d rounds\n', length(training_history.rounds));
end
