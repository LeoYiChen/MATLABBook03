%% css_calib.m
% Calibration reliability table in base MATLAB.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : css_calib
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function reliabilityTable = assessCalibration(predictedProb, trueLabel, numBins)
% assessCalibration  Reliability table for probabilistic predictions.
%   reliabilityTable = assessCalibration(predictedProb, trueLabel, numBins)
%   Author: Dr Leo Chen | Version 1.0 | Base MATLAB (R2021b+)

    if nargin < 3, numBins = 5; end
    edges  = linspace(0, 1, numBins + 1);
    binId  = discretize(predictedProb(:), edges);
    trueLabel = trueLabel(:);

    meanPredicted = accumarray(binId, predictedProb(:), [numBins 1], @mean, NaN);
    observedFreq  = accumarray(binId, trueLabel,        [numBins 1], @mean, NaN);
    binCount      = accumarray(binId, 1,                [numBins 1], @sum, 0);

    reliabilityTable = table((1:numBins)', meanPredicted, observedFreq, binCount, ...
        'VariableNames', {'Bin', 'MeanPredicted', 'ObservedFreq', 'Count'});
end
