%% chapter_AICE_syntax_P10.m
% Trapezoidal integration syntax.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AICE_syntax_P10
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
timeGrid       = linspace(t0, t1, nPoints);
lossIntegrand  = 100 - functionalityCurve;
resilienceLoss = trapz(timeGrid, lossIntegrand);
% - Computational Complexity -
% trapz is O(n) for n grid points. With n = 1000, the
% trapezoidal rule yields accuracy far exceeding the
% uncertainty in any real recovery-curve estimate.
