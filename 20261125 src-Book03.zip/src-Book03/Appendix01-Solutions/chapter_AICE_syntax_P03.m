%% chapter_AICE_syntax_P03.m
% Digraph and BFS syntax.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AICE_syntax_P03
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
containmentGraph = digraph(parentNodes, childNodes);
descendantIdx    = bfsearch(containmentGraph, queryNode);
descendantNames  = containmentGraph.Nodes.Name(descendantIdx);
% - Computational Complexity -
% digraph construction is O(V + E). bfsearch traverses every
% reachable node and edge once, costing O(V + E). For the
% sparse trees typical of IFC spatial structures, both
% operations are effectively instantaneous.
