%% css_match.m
% Ranking candidates by complementarity.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : css_match
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function matchTable = rankComplementarity(candidateProfiles, teamCoverage, names)
% rankComplementarity  Rank candidates by low overlap with team coverage.
%   matchTable = rankComplementarity(candidateProfiles, teamCoverage, names)
%   Rows of candidateProfiles = candidates, columns = specialisms.
%   Author: Dr Leo Chen | Version 1.0 | Base MATLAB (R2021b+)

    numCandidates = size(candidateProfiles, 1);
    overlap = zeros(numCandidates, 1);

    for candidateIndex = 1:numCandidates
        r = corrcoef(candidateProfiles(candidateIndex, :), teamCoverage(:)');
        overlap(candidateIndex) = r(1, 2);
    end

    [sortedOverlap, order] = sort(overlap, 'ascend');
    matchTable = table(string(names(order)), sortedOverlap, ...
        'VariableNames', {'Candidate', 'Overlap'});
end
