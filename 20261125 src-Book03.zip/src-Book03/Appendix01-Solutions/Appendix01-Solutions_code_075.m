%% Appendix01-Solutions_code_075.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
classdef OnlineLogisticRegression
    properties
        weights
        learning_rate
        t % time step for adaptive learning rate
    end
    
    methods
        function obj = OnlineLogisticRegression(n_features)
            obj.weights = randn(n_features, 3); % 3 classes
            obj.learning_rate = 0.01;
            obj.t = 1;
        end
        
        function probs = predict_proba(obj, X)
            scores = X * obj.weights;
            probs = exp(scores) ./ sum(exp(scores), 2);
        end
        
        function obj = partial_fit(obj, X, y)
            % Online gradient descent update
            probs = obj.predict_proba(X);
            y_onehot = zeros(length(y), 3);
            y_onehot(sub2ind(size(y_onehot), (1:length(y))', y+2)) = 1;
            
            gradient = X' * (probs - y_onehot);
            
            % Adaptive learning rate
            eta_t = obj.learning_rate / sqrt(obj.t);
            obj.weights = obj.weights - eta_t * gradient;
            obj.t = obj.t + 1;
        end
    end
end
