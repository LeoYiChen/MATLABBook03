%% lst_sol07_code.m
% Sentiment Analysis of Song Lyrics (MATLABBook02_Chapter10_Problem07.m).
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : lst:sol07_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% MATLABBook02_Chapter10_Problem07.m
%  Sentiment Analysis of Song Lyrics
%  -------------------
%  Author       : Dr Leo Chen
%  Date         : 2024-01-20
%  Modified     : 2024-07-01
%  Version      : 1.2
%  MATLAB Ver.  : R2024a
%  Toolboxes    : Text Analytics Toolbox
%  Description  :
%    Analyses sentiment in song lyrics using VADER and
%    correlates with audio-derived emotion labels.
%  Change Log   :
%    v1.0 - Initial release.
%    v1.1 - Added lemmatisation.
%    v1.2 - Added word cloud and scatter plot.
%  -------------------

%% Initialisation
clc; clear; close all;

%% --- Load Lyrics Corpus -----------
lyricsTable = readtable('song_lyrics_corpus.csv', ...
    'TextType', 'string');
fprintf('Corpus size: %d songs\n', height(lyricsTable));

rawLyrics       = lyricsTable.Lyrics;
songTitles      = lyricsTable.Title;
audioEmotionRaw = lyricsTable.AudioEmotionScore;

%% --- Pre-Process Text -------------
documents = tokenizedDocument(rawLyrics);
documents = removeStopWords(documents);
documents = erasePunctuation(documents);
documents = normalizeWords(documents, ...
    'Style', 'lemma');

%% --- Compute Sentiment Scores ---------
sentimentScores = vaderSentimentScores(documents);

% Classify polarity
numSongs         = numel(sentimentScores);
sentimentLabels  = strings(numSongs, 1);
for songIndex = 1:numSongs
    if sentimentScores(songIndex) > 0.05
        sentimentLabels(songIndex) = "Positive";
    elseif sentimentScores(songIndex) < -0.05
        sentimentLabels(songIndex) = "Negative";
    else
        sentimentLabels(songIndex) = "Neutral";
    end
end
sentimentLabels = categorical(sentimentLabels);

%% --- Summary Statistics -----------
categoryCounts = countcats(sentimentLabels);
categoryNames  = categories(sentimentLabels);
fprintf('\nSentiment Distribution:\n');
for catIndex = 1:numel(categoryNames)
    fprintf('  %-10s : %d songs\n', ...
            categoryNames{catIndex}, ...
            categoryCounts(catIndex));
end

%% --- Correlate with Audio Emotion ---------
[rhoValue, pValue] = corr(sentimentScores, ...
                           audioEmotionRaw);
fprintf(['\nPearson correlation (lyrics vs audio): ' ...
         'r = %.3f  (p = %.4f)\n'], rhoValue, pValue);

figure('Color', 'w', 'Position', [100 100 600 450]);
scatter(sentimentScores, audioEmotionRaw, 30, ...
        sentimentLabels, 'filled');
xlabel('Lyrical Sentiment (VADER)', ...
       'Interpreter', 'latex');
ylabel('Audio Emotion Score', ...
       'Interpreter', 'latex');
title(sprintf(['Lyrics vs.\ Audio Emotion ' ...
       '($r = %.3f$)'], rhoValue), ...
      'Interpreter', 'latex', 'FontSize', 14);
colorbar; grid on;
exportgraphics(gcf, ...
    'MATLABBook02_Chapter10_Problem07_scatter.pdf', ...
    'ContentType', 'vector');

%% --- Word Cloud for Each Category ---------
figure('Color', 'w', 'Position', [100 100 1000 350]);
for catIndex = 1:numel(categoryNames)
    subplot(1, numel(categoryNames), catIndex);
    catMask = sentimentLabels == categoryNames{catIndex};
    catDocs = documents(catMask);
    wordcloud(catDocs);
    title(categoryNames{catIndex}, ...
          'Interpreter', 'latex');
end
sgtitle('Word Clouds by Sentiment Category', ...
        'Interpreter', 'latex', 'FontSize', 14);
exportgraphics(gcf, ...
    'MATLABBook02_Chapter10_Problem07_wordclouds.pdf',...
    'ContentType', 'vector');
