%% css_reg.m
% Least-squares regression via the backslash operator.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : css_reg
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [coefficients, rSquared] = fitGrowthModel(predictors, growth)
% fitGrowthModel  Ordinary least squares with base MATLAB backslash.
%   [coefficients, rSquared] = fitGrowthModel(predictors, growth)
%   predictors : n-by-p matrix, growth : n-by-1 vector.
%   Author: Dr Leo Chen | Version 1.0 | Base MATLAB (R2021b+)

    numObs = size(predictors, 1);
    designMatrix = [ones(numObs, 1), predictors];

    coefficients = designMatrix \ growth;
    fitted   = designMatrix * coefficients;
    residual = growth - fitted;

    ssResidual = sum(residual.^2);
    ssTotal    = sum((growth - mean(growth)).^2);
    rSquared   = 1 - ssResidual / ssTotal;
end
