%% Appendix01-Solutions_code_076.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
classdef PageHinkleyDriftDetector
    properties
        min_instances
        delta
        lambda
        x_mean
        sum
        t
        drift_detected
    end
    
    methods
        function obj = PageHinkleyDriftDetector(delta, lambda, min_instances)
            obj.delta = delta;
            obj.lambda = lambda;
            obj.min_instances = min_instances;
            obj.reset();
        end
        
        function obj = reset(obj)
            obj.x_mean = 0;
            obj.sum = 0;
            obj.t = 0;
            obj.drift_detected = false;
        end
        
        function obj = add_element(obj, error)
            obj.t = obj.t + 1;
            obj.x_mean = obj.x_mean + (error - obj.x_mean) / obj.t;
            
            obj.sum = max(0, obj.sum + error - obj.x_mean - obj.delta);
            
            if obj.t > obj.min_instances && obj.sum > obj.lambda
                obj.drift_detected = true;
            end
        end
    end
end
