%% css_bias.m
% Group fairness diagnostics in base MATLAB.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : css_bias
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function fairnessTable = detectGroupBias(predictedLabels, protectedGroup)
% detectGroupBias  Statistical parity and disparate impact by group.
%   fairnessTable = detectGroupBias(predictedLabels, protectedGroup)
%   predictedLabels : 0-1 vector, 1 = favourable outcome.
%   Author: Dr Leo Chen | Version 1.0 | Base MATLAB (R2021b+)

    predictedLabels = double(predictedLabels(:));
    protectedGroup  = categorical(protectedGroup(:));

    groups = categories(protectedGroup);
    positiveRate = zeros(numel(groups), 1);
    for groupIndex = 1:numel(groups)
        inGroup = protectedGroup == groups{groupIndex};
        positiveRate(groupIndex) = mean(predictedLabels(inGroup));
    end

    statisticalParityDifference = max(positiveRate) - min(positiveRate);
    disparateImpactRatio        = min(positiveRate) / max(positiveRate);

    fairnessTable = table(string(groups), positiveRate, ...
        'VariableNames', {'Group', 'PositiveRate'});

    fprintf('Statistical parity difference: %.3f\n', statisticalParityDifference);
    fprintf('Disparate impact ratio: %.3f (flag if < 0.80)\n', disparateImpactRatio);
end
