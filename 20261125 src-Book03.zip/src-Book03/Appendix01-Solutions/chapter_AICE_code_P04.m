%% chapter_AICE_code_P04.m
% Solution~4: BIM service dependency and maintenance impact analysis (MATLABBook02_Chapter13_section8_Problem04.m).
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AICE_code_P04
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% MATLABBook02_Chapter13_section8_Problem04.m
% Problem 4: BIM Service Dependency and Maintenance Impact Analysis
%
% Description : Extends the IFC containment graph with service
%               relationships and identifies spaces affected by
%               single and simultaneous service failures.
% Author      : Dr Yi Chen
% Date        : 2025
% MATLAB      : R2024b or later
% Toolboxes   : None (base MATLAB)
% Reference   : Chapter 13, Problem 4
% =================================================================

%% 1. Containment edges (from Problem 3, extended)
containParent = ["Project","Site", ...
    "Building","Building","Building", ...
    "GroundFloor","GroundFloor","GroundFloor", ...
    "FirstFloor","FirstFloor","FirstFloor", ...
    "SecondFloor","SecondFloor", ...
    "PlantRoom","PlantRoom"];
containChild  = ["Site","Building", ...
    "GroundFloor","FirstFloor","SecondFloor", ...
    "Reception","Pharmacy","Emergency", ...
    "WardA","WardB","OperatingTheatre", ...
    "PlantRoom","ServerRoom", ...
    "HVACUnit","ElectricalPanel"];

%% 2. Service edges (serves relationships)
serviceSource = ["HVACUnit","HVACUnit","HVACUnit","HVACUnit", ...
    "ElectricalPanel","ElectricalPanel","ElectricalPanel", ...
    "ElectricalPanel","ElectricalPanel"];
serviceTarget = ["WardA","WardB","OperatingTheatre","Emergency", ...
    "Reception","Pharmacy","Emergency", ...
    "ServerRoom","OperatingTheatre"];

%% 3. Build combined directed graph
allSource     = [containParent, serviceSource];
allTarget     = [containChild, serviceTarget];
combinedGraph = digraph(allSource, allTarget);

%% 4. Identify spaces affected by HVAC failure
hvacAffected = successors(combinedGraph, "HVACUnit");
fprintf('Spaces affected by HVAC failure:\n');
for spaceIndex = 1:numel(hvacAffected)
    fprintf('  %s\n', hvacAffected{spaceIndex});
end

%% 5. Identify spaces affected by electrical failure
elecAffected = successors(combinedGraph, "ElectricalPanel");
fprintf('\nSpaces affected by electrical failure:\n');
for spaceIndex = 1:numel(elecAffected)
    fprintf('  %s\n', elecAffected{spaceIndex});
end

%% 6. Spaces losing both services simultaneously
duallyAffected = intersect(hvacAffected, elecAffected);
fprintf('\nSpaces losing BOTH services:\n');
for spaceIndex = 1:numel(duallyAffected)
    fprintf('  %s\n', duallyAffected{spaceIndex});
end

%% 7. Visualise with service edges in a distinct colour
figure;
graphPlot = plot(combinedGraph, 'Layout', 'layered', ...
    'NodeLabel', combinedGraph.Nodes.Name, ...
    'NodeFontSize', 8, 'ArrowSize', 8);
% Colour service edges red
nContainEdges = numel(containParent);
nTotalEdges   = numedges(combinedGraph);
serviceIdx    = (nContainEdges + 1) : nTotalEdges;
highlight(graphPlot, 'Edges', serviceIdx, ...
    'EdgeColor', 'r', 'LineWidth', 1.5);
title('BIM Containment (black) and Service (red) Graph');
% - Computational Complexity -
% Graph construction is O(V + E) for V = 15 nodes and
% E = 24 edges. Each successors call is O(degree), here at
% most 5. intersect is O(n log n) on small arrays. The full
% analysis is therefore instantaneous and scales linearly to
% real BIM models with thousands of service relationships.
