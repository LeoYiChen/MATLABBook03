%% chapter_AILMI_prob9_rpn.m
% Region proposal network for dense captioning.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AILMI_prob9_rpn
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [proposals, objectnessScores] = regionProposalNetwork(featureMap, ...
                                                               anchors, rpnWeights)
    % Generate region proposals from CNN feature map
    % featureMap: [H x W x C] convolutional features
    % anchors: [numAnchors x 4] anchor boxes (9 per location)
    
    [H, W, C] = size(featureMap);
    numAnchors = size(anchors, 1);
    
    % Convolutional layer for objectness and bbox regression
    % In practice: 1x1 conv with numAnchors*5 outputs per location
    % (1 objectness + 4 bbox offsets per anchor)
    
    proposals = [];
    objectnessScores = [];
    
    for h = 1:H
        for w = 1:W
            locationFeature = squeeze(featureMap(h, w, :));
            
            % Objectness classification for each anchor
            objectness = sigmoid(rpnWeights.cls' * locationFeature);
            
            % Bounding box regression (dx, dy, dw, dh)
            bboxOffsets = rpnWeights.bbox' * locationFeature;
            bboxOffsets = reshape(bboxOffsets, [4, numAnchors]);
            
            % Apply offsets to anchors
            for a = 1:numAnchors
                if objectness(a) > 0.5  % Objectness threshold
                    anchor = anchors(a, :);
                    offsets = bboxOffsets(:, a);
                    
                    % Decode bounding box
                    % Format: [xmin, ymin, xmax, ymax]
                    centerX = (anchor(1) + anchor(3)) / 2 + offsets(1);
                    centerY = (anchor(2) + anchor(4)) / 2 + offsets(2);
                    width = (anchor(3) - anchor(1)) * exp(offsets(3));
                    height = (anchor(4) - anchor(2)) * exp(offsets(4));
                    
                    bbox = [centerX - width/2, centerY - height/2, ...
                            centerX + width/2, centerY + height/2];
                    
                    proposals = [proposals; bbox];
                    objectnessScores = [objectnessScores; objectness(a)];
                end
            end
        end
    end
    
    % Non-maximum suppression
    [proposals, objectnessScores] = nonMaximumSuppression(proposals, ...
                                        objectnessScores, 0.7);
    
    % Keep top 300 proposals
    [objectnessScores, idx] = sort(objectnessScores, 'descend');
    proposals = proposals(idx(1:min(300, length(idx))), :);
    objectnessScores = objectnessScores(1:min(300, length(idx)));
end
