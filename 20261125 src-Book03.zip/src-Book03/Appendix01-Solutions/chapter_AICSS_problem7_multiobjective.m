%% chapter_AICSS_problem7_multiobjective.m
% Multi-objective optimisation framework for integrated security-safety system design.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AICSS_problem7_multiobjective
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function optimisationResults = executeMultiObjectiveOptimisation(problemDefinition, algorithmConfiguration, optimisationOptions)
    % Comprehensive multi-objective optimisation for security-safety systems
    % Author: Dr Leo Chen
    % Version: 1.0 - Initial implementation
    % Date: December 2024
    
    fprintf('Executing multi-objective optimisation for integrated security-safety system design...\n');
    
    % Initialize results structure
    optimisationResults = struct();
    optimisationResults.timestamp = datetime('now');
    optimisationResults.problemDefinition = problemDefinition;
    optimisationResults.algorithmConfiguration = algorithmConfiguration;
    
    % Extract problem parameters
    numberOfObjectives = problemDefinition.numberOfObjectives;
    numberOfVariables = problemDefinition.numberOfVariables;
    variableBounds = problemDefinition.variableBounds;
    constraints = problemDefinition.constraints;
    
    fprintf('Problem configuration: %d objectives, %d variables\n', numberOfObjectives, numberOfVariables);
    
    % Initialize multi-objective genetic algorithm (NSGA-II implementation)
    populationSize = algorithmConfiguration.populationSize;
    maxGenerations = algorithmConfiguration.maxGenerations;
    crossoverFraction = algorithmConfiguration.crossoverFraction;
    mutationRate = algorithmConfiguration.mutationRate;
    
    % Set up optimisation options for MATLAB's multiobjective solver
    moOptions = optimoptions('gamultiobj', ...
        'PopulationSize', populationSize, ...
        'MaxGenerations', maxGenerations, ...
        'CrossoverFraction', crossoverFraction, ...
        'MutationFcn', {@mutationadaptfeasible, mutationRate}, ...
        'Display', 'iter', ...
        'PlotFcn', @gaplotpareto, ...
        'UseParallel', optimisationOptions.useParallel);
    
    % Define objective function handle
    objectiveFunctionHandle = @(x) evaluateMultiObjectiveFunction(x, problemDefinition);
    
    % Define constraint function handle if constraints exist
    if ~isempty(constraints)
        constraintFunctionHandle = @(x) evaluateConstraints(x, constraints);
    else
        constraintFunctionHandle = [];
    end
    
    % Execute multi-objective optimisation
    fprintf('Starting multi-objective optimisation...\n');
    optimisationStartTime = tic;
    
    [paretoOptimalSolutions, paretoObjectiveValues, exitFlag, output] = gamultiobj(...
        objectiveFunctionHandle, numberOfVariables, [], [], [], [], ...
        variableBounds(:, 1), variableBounds(:, 2), constraintFunctionHandle, moOptions);
    
    optimisationExecutionTime = toc(optimisationStartTime);
    
    % Store optimisation results
    optimisationResults.paretoOptimalSolutions = paretoOptimalSolutions;
    optimisationResults.paretoObjectiveValues = paretoObjectiveValues;
    optimisationResults.exitFlag = exitFlag;
    optimisationResults.algorithmOutput = output;
    optimisationResults.executionTime = optimisationExecutionTime;
    
    fprintf('Optimisation completed in %.2f seconds\n', optimisationExecutionTime);
    fprintf('Found %d Pareto-optimal solutions\n', size(paretoOptimalSolutions, 1));
    
    % Analyse Pareto front characteristics
    paretoAnalysis = analyseParetoFront(paretoObjectiveValues, problemDefinition);
    optimisationResults.paretoAnalysis = paretoAnalysis;
    
    % Perform sensitivity analysis on Pareto solutions
    sensitivityAnalysis = performParetoSensitivityAnalysis(paretoOptimalSolutions, problemDefinition);
    optimisationResults.sensitivityAnalysis = sensitivityAnalysis;
    
    % Generate decision support metrics
    decisionSupport = generateDecisionSupportMetrics(paretoOptimalSolutions, paretoObjectiveValues, problemDefinition);
    optimisationResults.decisionSupport = decisionSupport;
    
    % Compare with single-objective solutions
    singleObjectiveComparison = compareSingleObjectiveSolutions(paretoOptimalSolutions, paretoObjectiveValues, problemDefinition);
    optimisationResults.singleObjectiveComparison = singleObjectiveComparison;
    
    % Generate comprehensive visualisation
    generateMultiObjectivevisualisation(optimisationResults, optimisationOptions);
    
    % Save optimisation results
    saveOptimisationResults(optimisationResults);
    
    fprintf('Multi-objective optimisation analysis completed.\n');
end

function objectiveValues = evaluateMultiObjectiveFunction(designVariables, problemDefinition)
    % Evaluate multiple objectives for integrated security-safety system design
    
    % Extract design variables
    detectionThreshold = designVariables(1);
    responseTime = designVariables(2);
    redundancyLevel = designVariables(3);
    computationalResources = designVariables(4);
    securityLevel = designVariables(5);
    
    % Objective 1: Security Effectiveness (to be maximised, so minimise negative)
    securityEffectiveness = calculateSecurityEffectiveness(detectionThreshold, securityLevel, computationalResources);
    objective1 = -securityEffectiveness; % Minimise negative for maximisation
    
    % Objective 2: Safety Reliability (to be maximised, so minimise negative)
    safetyReliability = calculateSafetyReliability(redundancyLevel, responseTime, computationalResources);
    objective2 = -safetyReliability; % Minimise negative for maximisation
    
    % Objective 3: Operational Efficiency (to be maximised, so minimise negative)
    operationalEfficiency = calculateOperationalEfficiency(responseTime, computationalResources, redundancyLevel);
    objective3 = -operationalEfficiency; % Minimise negative for maximisation
    
    % Objective 4: Total Cost (to be minimised)
    totalCost = calculateTotalCost(computationalResources, redundancyLevel, securityLevel);
    objective4 = totalCost;
    
    % Objective 5: Energy Consumption (to be minimised)
    energyConsumption = calculateEnergyConsumption(computationalResources, securityLevel, responseTime);
    objective5 = energyConsumption;
    
    objectiveValues = [objective1, objective2, objective3, objective4, objective5];
end

function securityEffectiveness = calculateSecurityEffectiveness(detectionThreshold, securityLevel, computationalResources)
    % Calculate security effectiveness based on system parameters
    
    % Base effectiveness from detection threshold (optimal around 0.7)
    thresholdEffectiveness = 1 - abs(detectionThreshold - 0.7) / 0.7;
    
    % Security level contribution (linear relationship)
    securityLevelContribution = securityLevel / 10; % Normalised to [0,1]
    
    % Computational resources contribution (logarithmic relationship)
    computationalContribution = log10(1 + computationalResources) / log10(11); % Normalised
    
    % Combined effectiveness with diminishing returns
    securityEffectiveness = 0.4 * thresholdEffectiveness + ...
                           0.35 * securityLevelContribution + ...
                           0.25 * computationalContribution;
    
    % Add realistic noise and bounds
    securityEffectiveness = min(1, max(0, securityEffectiveness + 0.02 * randn));
end

function safetyReliability = calculateSafetyReliability(redundancyLevel, responseTime, computationalResources)
    % Calculate safety reliability based on system parameters
    
    % Redundancy contribution (logarithmic with diminishing returns)
    redundancyContribution = 1 - exp(-redundancyLevel / 2);
    
    % Response time contribution (inverse relationship)
    responseTimeContribution = 1 / (1 + responseTime);
    
    % Computational resources for error checking
    computationalContribution = min(1, computationalResources / 8);
    
    % Combined reliability calculation
    safetyReliability = 0.5 * redundancyContribution + ...
                       0.3 * responseTimeContribution + ...
                       0.2 * computationalContribution;
    
    % Add realistic bounds and variation
    safetyReliability = min(0.999, max(0.8, safetyReliability + 0.01 * randn));
end

function operationalEfficiency = calculateOperationalEfficiency(responseTime, computationalResources, redundancyLevel)
    % Calculate operational efficiency considering multiple factors
    
    % Response time efficiency (faster is better)
    responseEfficiency = exp(-responseTime / 2);
    
    % Resource utilisation efficiency (optimal around 70%)
    resourceUtilisation = computationalResources / 10;
    resourceEfficiency = 1 - abs(resourceUtilisation - 0.7) / 0.7;
    
    % Redundancy overhead (more redundancy reduces efficiency)
    redundancyOverhead = exp(-redundancyLevel / 3);
    
    % Combined efficiency calculation
    operationalEfficiency = 0.4 * responseEfficiency + ...
                           0.35 * resourceEfficiency + ...
                           0.25 * redundancyOverhead;
    
    % Add realistic bounds
    operationalEfficiency = min(1, max(0.1, operationalEfficiency + 0.02 * randn));
end

function totalCost = calculateTotalCost(computationalResources, redundancyLevel, securityLevel)
    % Calculate total system cost including all components
    
    % Hardware cost (computational resources)
    hardwareCost = computationalResources^1.2 * 10000; % Non-linear cost scaling
    
    % Redundancy cost (additional hardware and maintenance)
    redundancyCost = redundancyLevel * 5000 + (redundancyLevel^2) * 1000;
    
    % Security infrastructure cost
    securityCost = securityLevel * 3000 + (securityLevel^1.5) * 500;
    
    % Operational and maintenance costs
    operationalCost = (computationalResources + redundancyLevel + securityLevel) * 1000;
    
    % Total cost calculation
    totalCost = hardwareCost + redundancyCost + securityCost + operationalCost;
    
    % Normalise to typical range [0, 100000]
    totalCost = min(100000, max(5000, totalCost));
end

function energyConsumption = calculateEnergyConsumption(computationalResources, securityLevel, responseTime)
    % Calculate energy consumption based on system configuration
    
    % Base power consumption from computational resources
    basePower = computationalResources * 50; % Watts
    
    % Security processing overhead
    securityPower = securityLevel * 10; % Additional watts for security
    
    % Response time pressure (faster response requires more power)
    responsePower = 100 / (responseTime + 0.1); % Inverse relationship
    
    % Total power consumption
    totalPower = basePower + securityPower + responsePower;
    
    % Convert to annual energy consumption (kWh/year)
    hoursPerYear = 8760;
    energyConsumption = totalPower * hoursPerYear / 1000;
    
    % Add realistic bounds
    energyConsumption = min(50000, max(1000, energyConsumption));
end

function [constraintViolation, ceq] = evaluateConstraints(designVariables, constraints)
    % Evaluate constraint violations for the optimisation problem
    
    % Extract design variables
    detectionThreshold = designVariables(1);
    responseTime = designVariables(2);
    redundancyLevel = designVariables(3);
    computationalResources = designVariables(4);
    securityLevel = designVariables(5);
    
    % Inequality constraints (g(x) <= 0)
    constraintViolation = [];
    
    % Minimum performance requirements
    minSecurityEffectiveness = calculateSecurityEffectiveness(detectionThreshold, securityLevel, computationalResources);
    constraintViolation(1) = constraints.minSecurityEffectiveness - minSecurityEffectiveness;
    
    minSafetyReliability = calculateSafetyReliability(redundancyLevel, responseTime, computationalResources);
    constraintViolation(2) = constraints.minSafetyReliability - minSafetyReliability;
    
    % Maximum resource constraints
    maxTotalResources = computationalResources + redundancyLevel + securityLevel;
    constraintViolation(3) = maxTotalResources - constraints.maxTotalResources;
    
    % Response time constraint
    constraintViolation(4) = responseTime - constraints.maxResponseTime;
    
    % Budget constraint
    totalCost = calculateTotalCost(computationalResources, redundancyLevel, securityLevel);
    constraintViolation(5) = totalCost - constraints.maxBudget;
    
    % Equality constraints (h(x) = 0) - none in this problem
    ceq = [];
end

function paretoAnalysis = analyseParetoFront(paretoObjectiveValues, problemDefinition)
    % Analyse characteristics of the Pareto front
    
    paretoAnalysis = struct();
    
    % Convert minimisation objectives back to original form for analysis
    adjustedObjectives = paretoObjectiveValues;
    adjustedObjectives(:, 1:3) = -adjustedObjectives(:, 1:3); % Security, Safety, Efficiency (originally maximised)
    
    % Calculate Pareto front metrics
    paretoAnalysis.numberOfSolutions = size(paretoObjectiveValues, 1);
    paretoAnalysis.objectiveRanges = [min(adjustedObjectives, [], 1); max(adjustedObjectives, [], 1)];
    paretoAnalysis.objectiveStandardDeviations = std(adjustedObjectives, 0, 1);
    
    % Hypervolume calculation (simplified 2D approximation)
    if size(adjustedObjectives, 2) >= 2
        % Use first two objectives for hypervolume calculation
        referencePoint = min(adjustedObjectives(:, 1:2), [], 1) - 0.1;
        paretoAnalysis.approximateHypervolume = calculateHypervolume2D(adjustedObjectives(:, 1:2), referencePoint);
    end
    
    % Diversity metrics
    paretoAnalysis.averageDistance = calculateAverageDistance(adjustedObjectives);
    paretoAnalysis.distributionUniformity = calculateDistributionUniformity(adjustedObjectives);
    
    % Identify knee points (solutions with good trade-offs)
    kneePoints = identifyKneePoints(adjustedObjectives);
    paretoAnalysis.kneePoints = kneePoints;
    
    % Objective correlations
    paretoAnalysis.objectiveCorrelations = corrcoef(adjustedObjectives);
    
    % Extreme solutions
    [~, bestSecurityIndex] = max(adjustedObjectives(:, 1));
    [~, bestSafetyIndex] = max(adjustedObjectives(:, 2));
    [~, bestEfficiencyIndex] = max(adjustedObjectives(:, 3));
    [~, lowestCostIndex] = min(adjustedObjectives(:, 4));
    [~, lowestEnergyIndex] = min(adjustedObjectives(:, 5));
    
    paretoAnalysis.extremeSolutions = struct(...
        'bestSecurity', bestSecurityIndex, ...
        'bestSafety', bestSafetyIndex, ...
        'bestEfficiency', bestEfficiencyIndex, ...
        'lowestCost', lowestCostIndex, ...
        'lowestEnergy', lowestEnergyIndex);
end

function generateMultiObjectivevisualisation(optimisationResults, options)
    % Generate comprehensive multi-objective optimisation visualisation
    
    figure('Position', [100, 100, 1800, 1400]);
    
    % Extract data for visualisation
    paretoObjectives = optimisationResults.paretoObjectiveValues;
    adjustedObjectives = paretoObjectives;
    adjustedObjectives(:, 1:3) = -adjustedObjectives(:, 1:3); % Convert back to original form
    
    objectiveLabels = {'Security Effectiveness', 'Safety Reliability', 'Operational Efficiency', 'Total Cost', 'Energy Consumption'};
    
    % 3D Pareto front (first three objectives)
    subplot(3, 4, [1, 2]);
    scatter3(adjustedObjectives(:, 1), adjustedObjectives(:, 2), adjustedObjectives(:, 3), ...
        100, adjustedObjectives(:, 4), 'filled');
    xlabel(objectiveLabels{1}, 'FontSize', 12);
    ylabel(objectiveLabels{2}, 'FontSize', 12);
    zlabel(objectiveLabels{3}, 'FontSize', 12);
    title('3D Pareto Front (Coloured by Cost)', 'FontSize', 14, 'FontWeight', 'bold');
    colorbar;
    colormap('hot');
    grid on;
    
    % 2D projections of Pareto front
    subplot(3, 4, 3);
    scatter(adjustedObjectives(:, 1), adjustedObjectives(:, 2), 100, adjustedObjectives(:, 4), 'filled');
    xlabel(objectiveLabels{1}, 'FontSize', 12);
    ylabel(objectiveLabels{2}, 'FontSize', 12);
    title('Security vs Safety', 'FontSize', 12, 'FontWeight', 'bold');
    colorbar;
    grid on;
    
    subplot(3, 4, 4);
    scatter(adjustedObjectives(:, 1), adjustedObjectives(:, 4), 100, adjustedObjectives(:, 2), 'filled');
    xlabel(objectiveLabels{1}, 'FontSize', 12);
    ylabel(objectiveLabels{4}, 'FontSize', 12);
    title('Security vs Cost', 'FontSize', 12, 'FontWeight', 'bold');
    colorbar;
    grid on;
    
    % Parallel coordinates plot
    subplot(3, 4, 5);
    % Normalise objectives for parallel coordinates
    normalisedObjectives = (adjustedObjectives - min(adjustedObjectives, [], 1)) ./ ...
                          (max(adjustedObjectives, [], 1) - min(adjustedObjectives, [], 1));
    
    parallelplot(normalisedObjectives, 'LineWidth', 1.5, 'LineAlpha', 0.6);
    xticklabels(objectiveLabels);
    title('Parallel Coordinates Plot', 'FontSize', 12, 'FontWeight', 'bold');
    xtickangle(45);
    grid on;
    
    % Objective correlations heatmap
    subplot(3, 4, 6);
    if isfield(optimisationResults, 'paretoAnalysis')
        correlationMatrix = optimisationResults.paretoAnalysis.objectiveCorrelations;
        imagesc(correlationMatrix);
        colorbar;
        colormap(gca, 'RdBu');
        set(gca, 'XTickLabel', objectiveLabels);
        set(gca, 'YTickLabel', objectiveLabels);
        title('Objective Correlations', 'FontSize', 12, 'FontWeight', 'bold');
        xtickangle(45);
    end
    
    % Decision variable analysis
    subplot(3, 4, 7);
    designVariables = optimisationResults.paretoOptimalSolutions;
    variableLabels = {'Detection Threshold', 'Response Time', 'Redundancy Level', 'Computational Resources', 'Security Level'};
    
    boxplot(designVariables, 'Labels', variableLabels);
    ylabel('Variable Value', 'FontSize', 12);
    title('Design Variable Distributions', 'FontSize', 12, 'FontWeight', 'bold');
    xtickangle(45);
    grid on;
    
    % Knee points identification
    subplot(3, 4, 8);
    if isfield(optimisationResults.paretoAnalysis, 'kneePoints')
        kneeIndices = optimisationResults.paretoAnalysis.kneePoints;
        
        scatter(adjustedObjectives(:, 1), adjustedObjectives(:, 2), 100, 'b', 'filled', 'alpha', 0.6);
        hold on;
        scatter(adjustedObjectives(kneeIndices, 1), adjustedObjectives(kneeIndices, 2), 150, 'r', 'filled');
        xlabel(objectiveLabels{1}, 'FontSize', 12);
        ylabel(objectiveLabels{2}, 'FontSize', 12);
        title('Knee Points in Pareto Front', 'FontSize', 12, 'FontWeight', 'bold');
        legend({'Pareto Solutions', 'Knee Points'}, 'Location', 'best');
        grid on;
    end
    
    % Cost vs Performance trade-off
    subplot(3, 4, 9);
    performanceIndex = (adjustedObjectives(:, 1) + adjustedObjectives(:, 2) + adjustedObjectives(:, 3)) / 3;
    scatter(adjustedObjectives(:, 4), performanceIndex, 100, adjustedObjectives(:, 5), 'filled');
    xlabel('Total Cost', 'FontSize', 12);
    ylabel('Average Performance', 'FontSize', 12);
    title('Cost vs Performance Trade-off', 'FontSize', 12, 'FontWeight', 'bold');
    colorbar;
    grid on;
    
    % Energy efficiency analysis
    subplot(3, 4, 10);
    energyEfficiency = performanceIndex ./ adjustedObjectives(:, 5);
    bar(sort(energyEfficiency, 'descend'), 'FaceColor', [0.6, 0.9, 0.6]);
    xlabel('Solution Index (Sorted)', 'FontSize', 12);
    ylabel('Performance/Energy Ratio', 'FontSize', 12);
    title('Energy Efficiency Ranking', 'FontSize', 12, 'FontWeight', 'bold');
    grid on;
    
    % Algorithm convergence analysis
    subplot(3, 4, 11);
    if isfield(optimisationResults, 'algorithmOutput') && isfield(optimisationResults.algorithmOutput, 'averagedistance')
        generations = 1:length(optimisationResults.algorithmOutput.averagedistance);
        plot(generations, optimisationResults.algorithmOutput.averagedistance, 'b-', 'LineWidth', 2);
        xlabel('Generation', 'FontSize', 12);
        ylabel('Average Distance', 'FontSize', 12);
        title('Algorithm Convergence', 'FontSize', 12, 'FontWeight', 'bold');
        grid on;
    end
    
    % Summary statistics and recommendations
    subplot(3, 4, 12);
    axis off;
    
    summaryText = sprintf('Multi-Objective Optimisation Summary\n\n');
    summaryText = [summaryText, sprintf('Pareto Solutions Found: %d\n', size(adjustedObjectives, 1))];
    summaryText = [summaryText, sprintf('Execution Time: %.1f seconds\n', optimisationResults.executionTime)];
    
    if isfield(optimisationResults, 'paretoAnalysis')
        summaryText = [summaryText, sprintf('Hypervolume: %.4f\n', optimisationResults.paretoAnalysis.approximateHypervolume)];
        summaryText = [summaryText, sprintf('Average Distance: %.4f\n', optimisationResults.paretoAnalysis.averageDistance)];
        
        % Recommend best compromise solutions
        extremeSolutions = optimisationResults.paretoAnalysis.extremeSolutions;
        summaryText = [summaryText, sprintf('\nRecommended Solutions:\n')];
        summaryText = [summaryText, sprintf('Best Security: Solution %d\n', extremeSolutions.bestSecurity)];
        summaryText = [summaryText, sprintf('Best Safety: Solution %d\n', extremeSolutions.bestSafety)];
        summaryText = [summaryText, sprintf('Lowest Cost: Solution %d\n', extremeSolutions.lowestCost)];
        
        if isfield(optimisationResults.paretoAnalysis, 'kneePoints')
            summaryText = [summaryText, sprintf('Best Compromise: Solution %d\n', optimisationResults.paretoAnalysis.kneePoints(1))];
        end
    end
    
    summaryText = [summaryText, sprintf('\nOptimisation Date: %s', string(optimisationResults.timestamp))];
    
    text(0.05, 0.95, summaryText, 'FontSize', 11, 'VerticalAlignment', 'top', ...
        'HorizontalAlignment', 'left', 'Interpreter', 'none', 'FontWeight', 'bold');
    
    % Save visualisation in multiple formats
    saveas(gcf, 'MultiObjectiveOptimisationResults.fig');
    saveas(gcf, 'MultiObjectiveOptimisationResults.eps', 'epsc');
    saveas(gcf, 'MultiObjectiveOptimisationResults.jpg');
    
    fprintf('Multi-objective optimisation visualisation saved in multiple formats.\n');
end

function kneePoints = identifyKneePoints(objectiveValues)
    % Identify knee points in the Pareto front (simplified method)
    
    % For simplicity, use the first two objectives
    if size(objectiveValues, 2) < 2
        kneePoints = [];
        return;
    end
    
    obj1 = objectiveValues(:, 1);
    obj2 = objectiveValues(:, 2);
    
    % Normalise objectives
    obj1_norm = (obj1 - min(obj1)) / (max(obj1) - min(obj1));
    obj2_norm = (obj2 - min(obj2)) / (max(obj2) - min(obj2));
    
    % Calculate distances from utopia point (1,1)
    distances = sqrt((1 - obj1_norm).^2 + (1 - obj2_norm).^2);
    
    % Find solutions with minimum distance (knee points)
    [~, sortedIndices] = sort(distances);
    numberOfKneePoints = min(3, length(sortedIndices)); % Select top 3 knee points
    kneePoints = sortedIndices(1:numberOfKneePoints);
end

function hypervolume = calculateHypervolume2D(paretoPoints, referencePoint)
    % Calculate 2D hypervolume (simplified implementation)
    
    % Sort points by first objective
    [~, sortOrder] = sort(paretoPoints(:, 1));
    sortedPoints = paretoPoints(sortOrder, :);
    
    hypervolume = 0;
    prevX = referencePoint(1);
    
    for pointIndex = 1:size(sortedPoints, 1)
        currentPoint = sortedPoints(pointIndex, :);
        width = currentPoint(1) - prevX;
        height = currentPoint(2) - referencePoint(2);
        
        if width > 0 && height > 0
            hypervolume = hypervolume + width * height;
        end
        
        prevX = currentPoint(1);
    end
end
