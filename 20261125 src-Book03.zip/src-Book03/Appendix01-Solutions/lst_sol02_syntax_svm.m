%% lst_sol02_syntax_svm.m
% Multi-class SVM training with fitcecoc().
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : lst:sol02_syntax_svm
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
svmTemplate = templateSVM( ...
    'KernelFunction', 'rbf', ...
    'KernelScale',    'auto');
trainedModel = fitcecoc( ...
    trainingFeatures, trainingLabels, ...
    'Learners', svmTemplate);
predictions  = predict(trainedModel, testFeatures);
