%% css_text.m
% Word-frequency analysis of focus-group text.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : css_text
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function frequencyTable = analyseFocusText(transcript, topN)
% analyseFocusText  Rank the most frequent words in free text.
%   frequencyTable = analyseFocusText(transcript, topN)
%   Author: Dr Leo Chen | Version 1.0 | Base MATLAB (R2021b+)

    if nargin < 2, topN = 10; end

    cleaned = lower(transcript);
    cleaned = regexprep(cleaned, '[^a-z\s]', ' ');
    words   = split(strtrim(cleaned));
    words(strlength(words) < 3) = [];

    [uniqueWords, ~, wordIndex] = unique(words);
    counts = accumarray(wordIndex, 1);

    [sortedCounts, order] = sort(counts, 'descend');
    keep = 1:min(topN, numel(order));

    frequencyTable = table(uniqueWords(order(keep)), sortedCounts(keep), ...
        'VariableNames', {'Word', 'Count'});
end
