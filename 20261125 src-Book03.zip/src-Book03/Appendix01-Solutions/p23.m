%% p23.m
% MATLABBook03_ChapterAIBHS_Problem23.m
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : p23
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function MATLABBook03_ChapterAIBHS_Problem23
% Purpose: fetal-head segmentation from a synthetic MRI slice.
% Author: Dr Leo Chen. R2024b + Image Processing. v1.0 2025-06-01.
    rng(0); S=128; [xg,yg]=meshgrid(1:S,1:S);
    head=(xg-64).^2+(yg-64).^2<=28^2; slice=0.3*double(head)+0.1*randn(S);
    mask=imopen(slice>graythresh(mat2gray(slice)),strel('disk',3));
    stats=regionprops(mask,'MajorAxisLength','Area'); [~,big]=max([stats.Area]);
    fprintf('Estimated head diameter: %.1f pixels\n', stats(big).MajorAxisLength);
    figure; imshowpair(mat2gray(slice),mask,'montage');
end
