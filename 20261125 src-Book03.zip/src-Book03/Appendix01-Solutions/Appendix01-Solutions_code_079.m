%% Appendix01-Solutions_code_079.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function createSentimentDashboard()
    % Create figure with subplots
    fig = figure('Position', [100, 100, 1200, 800]);
    
    % Subplot 1: Real-time sentiment stream
    ax1 = subplot(3,2,1:2);
    h_sentiment = animatedline('Color', 'b', 'LineWidth', 1.5);
    xlabel('Time'); ylabel('Avg Sentiment');
    title('Real-Time Sentiment Trend');
    grid on;
    
    % Subplot 2: Sentiment distribution (pie chart)
    ax2 = subplot(3,2,3);
    h_pie = pie([0,0,0]);
    title('Sentiment Distribution');
    legend({'Negative', 'Neutral', 'Positive'});
    
    % Subplot 3: Drift detection indicator
    ax3 = subplot(3,2,4);
    h_drift = scatter([], [], 'filled');
    xlabel('Time'); ylabel('Drift Metric');
    title('Concept Drift Detection');
    
    % Subplot 4: Event detection timeline
    ax4 = subplot(3,2,5);
    h_events = stem([], []);
    xlabel('Time'); ylabel('Event Magnitude');
    title('Detected Events');
    
    % Subplot 5: Model performance
    ax5 = subplot(3,2,6);
    h_accuracy = animatedline('Color', 'g', 'LineWidth', 1.5);
    xlabel('Time'); ylabel('Accuracy');
    title('Model Performance (Rolling)');
    ylim([0, 1]);
    
    % Store handles in UserData
    setappdata(fig, 'handles', struct('sentiment', h_sentiment, ...
        'pie', h_pie, 'drift', h_drift, 'events', h_events, ...
        'accuracy', h_accuracy, 'axes', {ax1, ax2, ax3, ax4, ax5}));
end

function updateDashboard(fig, timestamp, sentiment, sentiment_dist, ...
                         drift_score, event_flag, accuracy)
    handles = getappdata(fig, 'handles');
    
    % Update sentiment trend
    addpoints(handles.sentiment, timestamp, sentiment);
    
    % Update sentiment distribution
    delete(handles.pie);
    axes(handles.axes{2});
    handles.pie = pie(sentiment_dist);
    
    % Update drift indicator
    addpoints(handles.drift, timestamp, drift_score);
    
    % Mark events
    if event_flag
        addpoints(handles.events, timestamp, 1);
    end
    
    % Update accuracy
    addpoints(handles.accuracy, timestamp, accuracy);
    
    drawnow;
end
