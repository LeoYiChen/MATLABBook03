%% lst_sol04_code.m
% Neural Style Transfer (MATLABBook02_Chapter10_Problem04.m).
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : lst:sol04_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% MATLABBook02_Chapter10_Problem04.m
%  Neural Style Transfer with VGG-19
%  -------------------
%  Author       : Dr Leo Chen
%  Date         : 2024-01-20
%  Modified     : 2024-07-01
%  Version      : 1.2
%  MATLAB Ver.  : R2024a
%  Toolboxes    : Deep Learning Toolbox
%  Description  :
%    Implements Gatys et al. (2015) neural style transfer
%    using VGG-19. Varies the content-to-style ratio.
%  Change Log   :
%    v1.0 - Initial release.
%    v1.1 - Added multi-ratio comparison montage.
%    v1.2 - Replaced fminunc with Adam for stability.
%  -------------------

%% Initialisation
clc; clear; close all;

%% --- User Parameters ------------
contentImagePath = 'content_photo.jpg';
styleImagePath   = 'style_painting.jpg';
imageSize        = [224 224];
numIterations    = 300;
learningRate     = 2.0;
contentLayerName = 'conv4_2';
styleLayerNames  = {'conv1_1', 'conv2_1', ...
                    'conv3_1', 'conv4_1', 'conv5_1'};
alphaValues      = [1e-3, 1e-2, 1e-1];  % Content weight
betaValue        = 1.0;                  % Style weight

%% --- Load VGG-19 and Images -----------
vggNet = vgg19;
fprintf('VGG-19 loaded successfully.\n');

contentImage = imresize( ...
    im2single(imread(contentImagePath)), imageSize);
styleImage   = imresize( ...
    im2single(imread(styleImagePath)),   imageSize);

%% --- Extract Target Activations ---------
contentTarget = activations(vggNet, ...
    contentImage, contentLayerName);

styleTargets = cell(numel(styleLayerNames), 1);
for layerIdx = 1:numel(styleLayerNames)
    featureMap = activations(vggNet, ...
        styleImage, styleLayerNames{layerIdx});
    [h, w, c]  = size(featureMap);
    reshapedMap = reshape(featureMap, h*w, c);
    styleTargets{layerIdx} = ...
        (reshapedMap.' * reshapedMap) / (h * w);
end

%% --- Style Transfer for Each Alpha --------
resultImages = cell(1, numel(alphaValues));

for ratioIdx = 1:numel(alphaValues)
    alphaWeight = alphaValues(ratioIdx);
    fprintf(['\n- Alpha = %.0e, ', ...
             'Beta = %.0e -\n'], ...
            alphaWeight, betaValue);

    % Initialise transfer image as dlarray
    transferImage = dlarray( ...
        single(contentImage), 'SSC');

    % Adam optimiser state
    avgGrad    = [];
    avgGradSq  = [];

    for iterIdx = 1:numIterations
        [totalLoss, gradients] = dlfeval( ...
            @computeStyleTransferLoss, ...
            transferImage, vggNet, ...
            contentTarget, styleTargets, ...
            contentLayerName, styleLayerNames, ...
            alphaWeight, betaValue);

        [transferImage, avgGrad, avgGradSq] = ...
            adamupdate(transferImage, gradients, ...
            avgGrad, avgGradSq, iterIdx, ...
            learningRate);

        % Clamp pixel values to [0, 1]
        transferImage = dlarray( ...
            min(max(extractdata(transferImage), ...
            0), 1), 'SSC');

        if mod(iterIdx, 50) == 0
            fprintf('  Iter %3d  Loss: %.4f\n', ...
                    iterIdx, double(totalLoss));
        end
    end

    resultImages{ratioIdx} = ...
        extractdata(transferImage);
end

%% --- Display Comparison Montage ---------
figure('Color', 'w', ...
       'Position', [50 50 1200 350]);
subplot(1, numel(alphaValues) + 2, 1);
imshow(contentImage);
title('Content', 'Interpreter', 'latex');

subplot(1, numel(alphaValues) + 2, 2);
imshow(styleImage);
title('Style', 'Interpreter', 'latex');

for ratioIdx = 1:numel(alphaValues)
    subplot(1, numel(alphaValues) + 2, ratioIdx + 2);
    imshow(resultImages{ratioIdx});
    title(sprintf('$\\alpha = %.0e$', ...
          alphaValues(ratioIdx)), ...
          'Interpreter', 'latex');
end

sgtitle('Neural Style Transfer - Ratio Comparison', ...
        'Interpreter', 'latex', 'FontSize', 14);
exportgraphics(gcf, ...
    'MATLABBook02_Chapter10_Problem04_output.pdf', ...
    'ContentType', 'vector');

%% =========================================================
%% LOCAL FUNCTION: computeStyleTransferLoss
%% =========================================================
function [totalLoss, gradients] = ...
        computeStyleTransferLoss(transferImage, ...
        vggNet, contentTarget, styleTargets, ...
        contentLayerName, styleLayerNames, ...
        alphaWeight, betaWeight)

    % Content loss
    contentAct  = activations(vggNet, ...
        transferImage, contentLayerName);
    contentLoss = mean((contentAct(:) - ...
                        contentTarget(:)).^2);

    % Style loss (sum over layers)
    styleLoss = dlarray(single(0));
    for layerIdx = 1:numel(styleLayerNames)
        featureMap = activations(vggNet, ...
            transferImage, styleLayerNames{layerIdx});
        [h, w, c]  = size(featureMap);
        reshapedMap = reshape(featureMap, h*w, c);
        gramMatrix  = (reshapedMap.' * reshapedMap) / ...
                      (h * w);
        styleLoss   = styleLoss + ...
            mean((gramMatrix(:) - ...
                  styleTargets{layerIdx}(:)).^2);
    end
    styleLoss = styleLoss / numel(styleLayerNames);

    totalLoss = alphaWeight * contentLoss + ...
                betaWeight  * styleLoss;
    gradients = dlgradient(totalLoss, transferImage);
end
