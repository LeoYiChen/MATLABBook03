%% chapter_AE_Problems_P12_ElectrosprayLifetime.m
% Electrospray thruster lifetime and reliability analysis system.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AE_Problems_P12_ElectrosprayLifetime
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [lifetimeAssessment, reliabilityAnalysis, mitigationStrategies] = electrosprayThrusterLifetime(thrusterConfig, operatingConditions, lifetimeConfig, testData)
    % Comprehensive electrospray thruster lifetime and reliability analysis
    % Author: Dr Leo Chen
    % Version: 2.0.0 - Enhanced electrochemical degradation modeling
    % Date: 2024-11-14
    
    fprintf('Electrospray Thruster Lifetime Investigation\n');
    fprintf('Thruster type: %s, Propellant: %s\n', ...
            thrusterConfig.thrusterType, thrusterConfig.propellant);
    fprintf('Operating voltage: %.1f kV, Current: %.2f mA\n', ...
            operatingConditions.extractionVoltage / 1000, operatingConditions.current * 1000);
    fprintf('Target lifetime: %.0f hours\n', lifetimeConfig.targetLifetime / 3600);
    
    %% Phase 1: Physics-Based Degradation Modeling
    
    % Electrochemical degradation model
    [electrochemicalModel, reactionKinetics] = modelElectrochemicalDegradation(thrusterConfig, operatingConditions);
    
    % Ion and droplet impingement analysis
    [impingementModel, erosionRates] = modelParticleImpingement(thrusterConfig, operatingConditions);
    
    # Propellant distribution and flow degradation
    [flowModel, distributionEffects] = modelPropellantDistribution(thrusterConfig, operatingConditions);
    
    % Material degradation under electric fields
    [materialModel, electricFieldEffects] = modelMaterialDegradation(thrusterConfig, operatingConditions);
    
    fprintf('Physics-based models established\n');
    fprintf('  Electrochemical reaction rate: %.2e mol/s\n', reactionKinetics.overallRate);
    fprintf('  Peak erosion rate: %.2e m/s\n', max(erosionRates.spatialProfile));
    fprintf('  Flow uniformity degradation: %.1f%%/1000h\n', distributionEffects.uniformityLoss * 100);
    
    %% Phase 2: Multi-Physics Simulation Integration
    
    % Couple electrochemistry with particle dynamics
    [coupledSimulation, interactionEffects] = couplePhysicsModels(electrochemicalModel, impingementModel, ...
                                                                  flowModel, materialModel);
    
    # Time-evolution simulation parameters
    timeStep = lifetimeConfig.simulationTimeStep;
    totalSimulationTime = lifetimeConfig.simulationDuration;
    timeVector = 0:timeStep:totalSimulationTime;
    
    % Initialize degradation state
    degradationState = initializeDegradationState(thrusterConfig);
    
    # Performance evolution arrays
    thrustEvolution = zeros(length(timeVector), 1);
    specificImpulseEvolution = zeros(length(timeVector), 1);
    efficiencyEvolution = zeros(length(timeVector), 1);
    degradationIndicators = zeros(length(timeVector), 4); % 4 main degradation modes
    
    fprintf('Starting lifetime simulation...\n');
    fprintf('  Simulation duration: %.1f years, Time steps: %d\n', ...
            totalSimulationTime / (365 * 24 * 3600), length(timeVector));
    
    %% Phase 3: Temporal Evolution Simulation
    
    for timeIndex = 1:length(timeVector)
        currentTime = timeVector(timeIndex);
        
        % Update electrochemical state
        [newElectrochemicalState, ecDegradation] = updateElectrochemicalState(degradationState.electrochemical, ...
                                                                              electrochemicalModel, timeStep);
        
        # Update impingement erosion
        [newErosionState, erosionProgress] = updateErosionState(degradationState.erosion, impingementModel, timeStep);
        
        % Update propellant distribution
        [newFlowState, flowDegradation] = updateFlowState(degradationState.flow, flowModel, timeStep);
        
        # Update material properties
        [newMaterialState, materialDegradation] = updateMaterialState(degradationState.material, materialModel, timeStep);
        
        % Calculate current performance
        [currentPerformance, performanceMetrics] = calculateCurrentPerformance(newElectrochemicalState, newErosionState, ...
                                                                               newFlowState, newMaterialState, thrusterConfig);
        
        # Store evolution data
        thrustEvolution(timeIndex) = currentPerformance.thrust;
        specificImpulseEvolution(timeIndex) = currentPerformance.specificImpulse;
        efficiencyEvolution(timeIndex) = currentPerformance.efficiency;
        degradationIndicators(timeIndex, :) = [ecDegradation, erosionProgress, flowDegradation, materialDegradation];
        
        % Update degradation state
        degradationState.electrochemical = newElectrochemicalState;
        degradationState.erosion = newErosionState;
        degradationState.flow = newFlowState;
        degradationState.material = newMaterialState;
        
        # Progress reporting
        if mod(timeIndex, round(length(timeVector)/20)) == 0
            progress = timeIndex / length(timeVector) * 100;
            hoursElapsed = currentTime / 3600;
            fprintf('  Progress: %.0f%%, Time: %.1f hours, Thrust: %.1f --N\n', ...
                    progress, hoursElapsed, currentPerformance.thrust * 1e6);
        end
    end
    
    fprintf('Lifetime simulation completed\n');
    
    %% Phase 4: Failure Mode Analysis
    
    % Identify primary failure modes
    [failureModes, failureThresholds] = identifyFailureModes(thrustEvolution, specificImpulseEvolution, ...
                                                            efficiencyEvolution, lifetimeConfig);
    
    # Calculate time to failure for each mode
    [timeToFailure, failureAnalysis] = calculateTimeToFailure(failureModes, degradationIndicators, timeVector);
    
    % Reliability assessment using Weibull analysis
    [reliabilityFunctions, weibullParameters] = performReliabilityAnalysis(timeToFailure, lifetimeConfig);
    
    # Mean Time Between Failures (MTBF) calculation
    [mtbfAnalysis, confidenceIntervals] = calculateMTBF(reliabilityFunctions, lifetimeConfig);
    
    fprintf('Failure mode analysis completed\n');
    fprintf('  Primary failure mode: %s at %.0f hours\n', ...
            failureAnalysis.primaryMode, min(timeToFailure) / 3600);
    fprintf('  MTBF: %.0f hours (%.1f%% confidence)\n', ...
            mtbfAnalysis.mtbf / 3600, confidenceIntervals.confidence * 100);
    
    %% Phase 5: Experimental Validation and Testing
    
    % Accelerated aging test design
    [acceleratedTests, accelerationFactors] = designAcceleratedAgingTests(thrusterConfig, lifetimeConfig);
    
    # Correlate simulation with experimental data
    if ~isempty(testData)
        [correlationAnalysis, modelValidation] = correlateWithTestData(thrustEvolution, specificImpulseEvolution, ...
                                                                        testData, timeVector);
        
        # Update models based on experimental data
        [updatedModels, modelConfidence] = updateModelsFromData(electrochemicalModel, impingementModel, ...
                                                               correlationAnalysis, lifetimeConfig);
        fprintf('Model validation completed: %.1f%% correlation with test data\n', correlationAnalysis.correlation * 100);
    end
    
    %% Phase 6: Health Monitoring System Design
    
    % Design real-time health indicators
    [healthIndicators, monitoringSystem] = designHealthMonitoringSystem(thrusterConfig, degradationIndicators);
    
    # Predictive maintenance algorithms
    [predictiveAlgorithms, predictionAccuracy] = developPredictiveAlgorithms(degradationIndicators, timeToFailure);
    
    % Anomaly detection for early failure warning
    [anomalyDetection, detectionSensitivity] = implementAnomalyDetection(healthIndicators, lifetimeConfig);
    
    fprintf('Health monitoring system designed\n');
    fprintf('  Health indicators: %d parameters, Prediction accuracy: %.1f%%\n', ...
            length(healthIndicators), predictionAccuracy.overallAccuracy * 100);
    
    %% Phase 7: Lifetime Extension Strategies
    
    % Propellant management optimization
    [propellantOptimization, lifeExtension1] = optimizePropellantManagement(flowModel, thrusterConfig);
    
    # Operating condition optimization
    [operatingOptimization, lifeExtension2] = optimizeOperatingConditions(electrochemicalModel, operatingConditions);
    
    % Material selection and coating strategies
    [materialStrategies, lifeExtension3] = developMaterialStrategies(materialModel, thrusterConfig);
    
    # Design modifications for improved lifetime
    [designModifications, lifeExtension4] = proposeDesignModifications(impingementModel, thrusterConfig);
    
    totalLifeExtension = lifeExtension1 + lifeExtension2 + lifeExtension3 + lifeExtension4;
    
    fprintf('Lifetime extension strategies developed\n');
    fprintf('  Propellant optimization: +%.0f hours\n', lifeExtension1 / 3600);
    fprintf('  Operating optimization: +%.0f hours\n', lifeExtension2 / 3600);
    fprintf('  Material improvements: +%.0f hours\n', lifeExtension3 / 3600);
    fprintf('  Design modifications: +%.0f hours\n', lifeExtension4 / 3600);
    fprintf('  Total potential extension: +%.0f hours (%.1fx improvement)\n', ...
            totalLifeExtension / 3600, 1 + totalLifeExtension / min(timeToFailure));
    
    %% Phase 8: Economic Analysis of Lifetime Improvements
    
    % Cost-benefit analysis of lifetime extensions
    [economicAnalysis, costBenefit] = performEconomicAnalysis(totalLifeExtension, lifetimeConfig.economicParams);
    
    # Technology development investment requirements
    [investmentAnalysis, developmentCosts] = analyseInvestmentRequirements(materialStrategies, designModifications);
    
    % Market impact assessment
    [marketAnalysis, competitiveAdvantage] = assessMarketImpact(totalLifeExtension, lifetimeConfig.marketParams);
    
    fprintf('Economic analysis completed\n');
    fprintf('  Development cost: $%.1f M, Payback period: %.1f years\n', ...
            investmentAnalysis.totalCost / 1e6, economicAnalysis.paybackPeriod / 365);
    
    %% Phase 9: Results Compilation
    
    lifetimeAssessment = struct();
    lifetimeAssessment.currentLifetime = min(timeToFailure);
    lifetimeAssessment.projectedLifetime = min(timeToFailure) + totalLifeExtension;
    lifetimeAssessment.performanceEvolution = struct('thrust', thrustEvolution, 'specificImpulse', specificImpulseEvolution, ...
                                                    'efficiency', efficiencyEvolution);
    lifetimeAssessment.degradationModes = degradationIndicators;
    lifetimeAssessment.timeVector = timeVector;
    
    reliabilityAnalysis = struct();
    reliabilityAnalysis.failureModes = failureModes;
    reliabilityAnalysis.timeToFailure = timeToFailure;
    reliabilityAnalysis.reliabilityFunctions = reliabilityFunctions;
    reliabilityAnalysis.mtbf = mtbfAnalysis;
    reliabilityAnalysis.weibullParameters = weibullParameters;
    if exist('modelValidation', 'var')
        reliabilityAnalysis.validationResults = modelValidation;
    end
    
    mitigationStrategies = struct();
    mitigationStrategies.propellantOptimization = propellantOptimization;
    mitigationStrategies.operatingOptimization = operatingOptimization;
    mitigationStrategies.materialStrategies = materialStrategies;
    mitigationStrategies.designModifications = designModifications;
    mitigationStrategies.healthMonitoring = monitoringSystem;
    mitigationStrategies.economicAnalysis = economicAnalysis;
    mitigationStrategies.lifeExtensionPotential = totalLifeExtension;
    
    %% Phase 10: Comprehensive visualisation
    
    fprintf('Creating comprehensive electrospray lifetime analysis...\n');
    
    % Create analysis figure
    figure('Name', 'Electrospray Thruster Lifetime and Reliability Analysis', 'Position', [100, 100, 1600, 1200]);
    
    # Performance evolution over time
    subplot(3,4,1);
    plot(timeVector / 3600, thrustEvolution * 1e6, 'b-', 'LineWidth', 2);
    xlabel('Time (hours)'); ylabel('Thrust (--N)'); title('Thrust Evolution');
    grid on;
    
    % Specific impulse degradation
    subplot(3,4,2);
    plot(timeVector / 3600, specificImpulseEvolution, 'r-', 'LineWidth', 2);
    xlabel('Time (hours)'); ylabel('Specific Impulse (s)'); title('Specific Impulse Evolution');
    grid on;
    
    # Efficiency degradation
    subplot(3,4,3);
    plot(timeVector / 3600, efficiencyEvolution * 100, 'g-', 'LineWidth', 2);
    xlabel('Time (hours)'); ylabel('Efficiency (%)'); title('Efficiency Evolution');
    grid on;
    
    % Degradation modes comparison
    subplot(3,4,4);
    plot(timeVector / 3600, degradationIndicators, 'LineWidth', 2);
    xlabel('Time (hours)'); ylabel('Degradation Level'); title('Degradation Modes');
    legend({'Electrochemical', 'Erosion', 'Flow', 'Material'});
    grid on;
    
    # Reliability function
    subplot(3,4,5);
    if isfield(reliabilityFunctions, 'timeAxis')
        plot(reliabilityFunctions.timeAxis / 3600, reliabilityFunctions.reliability, 'k-', 'LineWidth', 2);
        xlabel('Time (hours)'); ylabel('Reliability'); title('Reliability Function');
        grid on; ylim([0, 1]);
    end
    
    % Failure mode contributions
    subplot(3,4,6);
    if isfield(failureModes, 'contributions')
        pie(failureModes.contributions, failureModes.modeNames);
        title('Failure Mode Contributions');
    end
    
    # Weibull distribution
    subplot(3,4,7);
    if isfield(weibullParameters, 'pdf')
        weibullPDF = weibullParameters.pdf;
        plot(weibullPDF.timeAxis / 3600, weibullPDF.probability, 'm-', 'LineWidth', 2);
        xlabel('Time (hours)'); ylabel('Failure Probability Density');
        title('Weibull Failure Distribution'); grid on;
    end
    
    % Health monitoring indicators
    subplot(3,4,8);
    if isfield(healthIndicators, 'indicatorHistory')
        indicatorHistory = healthIndicators.indicatorHistory;
        plot(timeVector / 3600, indicatorHistory, 'LineWidth', 2);
        xlabel('Time (hours)'); ylabel('Health Score'); title('Health Indicators');
        legend(healthIndicators.indicatorNames); grid on;
    end
    
    # Lifetime extension potential
    subplot(3,4,9);
    extensionSources = {'Propellant', 'Operating', 'Material', 'Design'};
    extensionValues = [lifeExtension1, lifeExtension2, lifeExtension3, lifeExtension4] / 3600;
    
    bar(extensionValues);
    set(gca, 'XTickLabel', extensionSources);
    ylabel('Lifetime Extension (hours)'); title('Extension Strategies');
    grid on;
    
    % Cost-benefit analysis
    subplot(3,4,10);
    if isfield(costBenefit, 'timeline')
        costBenefitTimeline = costBenefit.timeline;
        plot(costBenefitTimeline.years, costBenefitTimeline.cumulativeBenefit / 1e6, 'c-', 'LineWidth', 2);
        xlabel('Years'); ylabel('Cumulative Benefit ($M)'); title('Cost-Benefit Analysis');
        grid on;
    end
    
    # Accelerated test correlation
    subplot(3,4,11);
    if exist('correlationAnalysis', 'var')
        testCorrelation = correlationAnalysis.testCorrelation;
        scatter(testCorrelation.simulatedValues, testCorrelation.experimentalValues, 50, 'filled');
        xlabel('Simulated Performance'); ylabel('Experimental Performance');
        title('Model Validation'); grid on;
        
        % Perfect correlation line
        maxVal = max([testCorrelation.simulatedValues; testCorrelation.experimentalValues]);
        line([0, maxVal], [0, maxVal], 'Color', 'red', 'LineStyle', '--');
    end
    
    % Overall lifetime assessment
    subplot(3,4,12);
    lifetimeMetrics = [lifetimeAssessment.currentLifetime, lifetimeAssessment.projectedLifetime, ...
                      lifetimeConfig.targetLifetime] / 3600;
    metricLabels = {'Current', 'Projected', 'Target'};
    
    bar(lifetimeMetrics, 'FaceColor', 'gold');
    set(gca, 'XTickLabel', metricLabels);
    ylabel('Lifetime (hours)'); title('Lifetime Assessment');
    grid on;
    
    sgtitle('Electrospray Thruster Lifetime Investigation: Comprehensive Analysis');
    
    fprintf('\nElectrospray thruster lifetime analysis completed!\n');
    fprintf('Lifetime assessment summary:\n');
    fprintf('  Current predicted lifetime: %.0f hours\n', lifetimeAssessment.currentLifetime / 3600);
    fprintf('  Projected improved lifetime: %.0f hours\n', lifetimeAssessment.projectedLifetime / 3600);
    fprintf('  Improvement factor: %.1fx\n', lifetimeAssessment.projectedLifetime / lifetimeAssessment.currentLifetime);
    fprintf('  Primary limiting factor: %s\n', failureAnalysis.primaryMode);
    fprintf('  Recommended development focus: %s\n', mitigationStrategies.topPriority);
    
end

function [ecModel, kinetics] = modelElectrochemicalDegradation(thrusterConfig, operatingConditions)
    % Model electrochemical degradation processes in electrospray thruster
    
    % Extract operating parameters
    voltage = operatingConditions.extractionVoltage;
    current = operatingConditions.current;
    propellant = thrusterConfig.propellant;
    electrodeArea = thrusterConfig.electrodeArea;
    
    # Electrochemical reaction kinetics
    % Simplified Butler-Volmer kinetics for electrode reactions
    exchangeCurrentDensity = 1e-6; % A/m? (typical for liquid metal electrodes)
    transferCoefficient = 0.5;
    overpotential = voltage - thrusterConfig.standardPotential;
    
    % Current density
    currentDensity = current / electrodeArea;
    
    # Degradation rate based on Faraday's law
    faradayConstant = 96485; % C/mol
    molecularWeight = thrusterConfig.propellantMolecularWeight;
    
    degradationRate = currentDensity * molecularWeight / (faradayConstant * thrusterConfig.electronsPerMolecule);
    
    ecModel = struct();
    ecModel.reactionKinetics = struct('exchangeCurrent', exchangeCurrentDensity, 'transferCoeff', transferCoefficient);
    ecModel.degradationRate = degradationRate;
    ecModel.currentDensity = currentDensity;
    
    kinetics = struct();
    kinetics.overallRate = degradationRate * electrodeArea; % mol/s
    kinetics.lifetimeFactor = electrodeArea / kinetics.overallRate; % Lifetime scaling factor
    
    fprintf('Electrochemical model: Degradation rate %.2e kg/s\n', kinetics.overallRate * molecularWeight);
end
