%% chapter_AILMI_prob8_fewshot.m
% Prototypical networks for few-shot command recognition.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AILMI_prob8_fewshot
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [accuracy, predictions] = prototypicalNetworkInference(...
    supportSet, supportLabels, querySet, queryLabels, encoder)
    % Few-shot classification using prototypical networks
    % supportSet: [numShot x numClasses x timeSteps x mfccDim]
    % supportLabels: [numShot x numClasses]
    % querySet: [numQuery x timeSteps x mfccDim]
    
    numClasses = size(supportSet, 2);
    numShot = size(supportSet, 1);
    numQuery = size(querySet, 1);
    
    % Compute class prototypes (mean of support examples)
    prototypes = zeros(numClasses, 128); % Assuming 128-dim features
    
    for c = 1:numClasses
        classFeatures = zeros(numShot, 128);
        for s = 1:numShot
            classFeatures(s, :) = encoder(squeeze(supportSet(s, c, :, :)));
        end
        % Prototype = mean of support examples for this class
        prototypes(c, :) = mean(classFeatures, 1);
    end
    
    % Classify query examples by nearest prototype
    predictions = zeros(numQuery, 1);
    queryFeatures = zeros(numQuery, 128);
    
    for q = 1:numQuery
        queryFeatures(q, :) = encoder(squeeze(querySet(q, :, :)));
        
        % Compute Euclidean distance to each prototype
        distances = zeros(numClasses, 1);
        for c = 1:numClasses
            distances(c) = norm(queryFeatures(q, :) - prototypes(c, :));
        end
        
        % Predict class with minimum distance
        [~, predictions(q)] = min(distances);
        predictions(q) = predictions(q) - 1; % 0-indexed
    end
    
    % Compute accuracy
    accuracy = sum(predictions == queryLabels) / numQuery;
end
