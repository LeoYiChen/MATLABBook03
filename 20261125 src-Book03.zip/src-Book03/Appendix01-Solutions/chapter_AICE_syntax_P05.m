%% chapter_AICE_syntax_P05.m
% Regression tree and ensemble syntax.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AICE_syntax_P05
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
treeModel     = fitrtree(featureTable, targetValues);
ensembleModel = fitrensemble(featureTable, targetValues, ...
    'Method', 'Bag', 'NumLearningCycles', 50);
predicted     = predict(ensembleModel, newFeatures);
importance    = predictorImportance(ensembleModel);
% - Computational Complexity -
% fitrtree evaluates O(N d) candidate splits per node for N
% samples and d features, with depth O(log N), yielding
% O(N d log N) training cost. fitrensemble trains T trees,
% scaling to O(T N d log N). Prediction traverses one path
% per tree per query: O(T log N) per sample.
