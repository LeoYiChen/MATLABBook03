%% yolo_detection.m
% YOLO Object Detection Implementation
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : yolo_detection
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% YOLO Object Detection Implementation
% Author: Dr Leo Chen
% Version: R2023b
% Date: November 2024

function yolo_object_detection()
% Create synthetic dataset for demonstration
rng(789); % Ensure reproducibility

% Generate synthetic images with simple geometric objects
num_images = 100;
image_size = [224, 224, 3];

% Create imageDatastore for training
[training_images, ground_truth_data] = create_synthetic_dataset(...
    num_images, image_size);

% Define object classes
class_names = {'circle', 'rectangle', 'triangle'};

% Create ground truth table
ground_truth_table = table(training_images, ground_truth_data, ...
    'VariableNames', {'imageFilename', 'groundTruth'});

% Split data for training and validation
train_ratio = 0.8;
num_train = floor(train_ratio * height(ground_truth_table));

train_data = ground_truth_table(1:num_train, :);
validation_data = ground_truth_table(num_train+1:end, :);

% Load pre-trained ResNet-18 as feature extractor
base_network = resnet18;
feature_layer = 'res4b_relu';

% Configure YOLO v2 detector
anchor_boxes = [60, 60; 80, 80; 100, 100]; % Simple anchor boxes

% Define YOLO v2 network layers
yolo_layers = yolov2Layers(image_size(1:2), class_names, ...
    anchor_boxes, base_network, feature_layer);

% Configure training options
training_options = trainingOptions('sgdm', ...
    'MiniBatchSize', 16, ...
    'InitialLearnRate', 1e-3, ...
    'MaxEpochs', 20, ...
    'CheckpointPath', tempdir, ...
    'ValidationData', validation_data, ...
    'ValidationFrequency', 50, ...
    'Plots', 'training-progress', ...
    'Verbose', false);

% Data augmentation
augmenter = imageDataAugmenter('RandXReflection', true, ...
    'RandYReflection', true, ...
    'RandRotation', [-10, 10]);

augmented_train_data = transform(train_data, @(data) ...
    augment_detection_data(data, augmenter, image_size(1:2)));

% Train YOLO v2 detector
fprintf('Training YOLO v2 detector...\\n');
[trained_detector, training_info] = trainYOLOv2ObjectDetector(...
    augmented_train_data, yolo_layers, training_options);

% Evaluate detector performance
[average_precision, recall, precision] = evaluateDetectionPrecision(...
    trained_detector, validation_data);

% Test detection on validation images
test_image_idx = 1;
test_image = readimage(validation_data, test_image_idx);

% Perform detection
[detected_bboxes, detection_scores, detected_labels] = ...
    detect(trained_detector, test_image, 'Threshold', 0.5);

% Visualise detection results
figure('Name', 'YOLO Detection Results');

subplot(2, 2, 1);
imshow(test_image);
if ~isempty(detected_bboxes)
    showShape('rectangle', detected_bboxes, 'Color', 'red', 'LineWidth', 2);
    for detection_idx = 1:size(detected_bboxes, 1)
        label_text = sprintf('%s: %.2f', ...
            char(detected_labels(detection_idx)), ...
            detection_scores(detection_idx));
        text(detected_bboxes(detection_idx, 1), ...
            detected_bboxes(detection_idx, 2) - 10, ...
            label_text, 'Color', 'red', 'FontSize', 12, 'FontWeight', 'bold');
    end
end
title('Object Detection Results', 'Interpreter', 'latex');

subplot(2, 2, 2);
plot(training_info.TrainingLoss, 'b-', 'LineWidth', 2);
xlabel('Iteration', 'Interpreter', 'latex');
ylabel('Training Loss', 'Interpreter', 'latex');
title('Training Loss Convergence', 'Interpreter', 'latex');
grid on;

subplot(2, 2, 3);
bar(average_precision);
set(gca, 'XTickLabel', class_names);
xlabel('Object Class', 'Interpreter', 'latex');
ylabel('Average Precision', 'Interpreter', 'latex');
title('Per-Class Detection Performance', 'Interpreter', 'latex');

subplot(2, 2, 4);
plot(recall, precision, 'ro-', 'LineWidth', 2);
xlabel('Recall', 'Interpreter', 'latex');
ylabel('Precision', 'Interpreter', 'latex');
title('Precision-Recall Curve', 'Interpreter', 'latex');
grid on;

% Display performance metrics
mean_ap = mean(average_precision);
fprintf('\\n\\textbf{Detection Performance}:\\n');
fprintf('Mean Average Precision (mAP): %.4f\\n', mean_ap);
fprintf('Number of Detections: %d\\n', size(detected_bboxes, 1));

for class_idx = 1:length(class_names)
    fprintf('%s AP: %.4f\\n', class_names{class_idx}, ...
        average_precision(class_idx));
end

end

function [image_files, bbox_data] = create_synthetic_dataset(num_images, image_size)
% Create synthetic dataset with geometric shapes
image_files = cell(num_images, 1);
bbox_data = cell(num_images, 1);

for img_idx = 1:num_images
    % Create blank image
    synthetic_image = uint8(255 * rand(image_size));
    
    % Add random geometric shapes
    num_objects = randi([1, 3]);
    bboxes = [];
    labels = {};
    
    for obj_idx = 1:num_objects
        shape_type = randi([1, 3]);
        
        % Random position and size
        obj_width = randi([30, 80]);
        obj_height = randi([30, 80]);
        obj_x = randi([1, image_size(2) - obj_width]);
        obj_y = randi([1, image_size(1) - obj_height]);
        
        bbox = [obj_x, obj_y, obj_width, obj_height];
        
        switch shape_type
            case 1 % Circle
                synthetic_image = insertShape(synthetic_image, 'Circle', ...
                    [obj_x + obj_width/2, obj_y + obj_height/2, obj_width/2], ...
                    'Color', 'red', 'LineWidth', 3);
                labels{end+1} = 'circle';
            case 2 % Rectangle
                synthetic_image = insertShape(synthetic_image, 'Rectangle', ...
                    bbox, 'Color', 'blue', 'LineWidth', 3);
                labels{end+1} = 'rectangle';
            case 3 % Triangle (approximated as polygon)
                triangle_points = [obj_x + obj_width/2, obj_y; ...
                    obj_x, obj_y + obj_height; ...
                    obj_x + obj_width, obj_y + obj_height];
                synthetic_image = insertShape(synthetic_image, 'Polygon', ...
                    triangle_points, 'Color', 'green', 'LineWidth', 3);
                labels{end+1} = 'triangle';
        end
        
        bboxes = [bboxes; bbox];
    end
    
    % Save synthetic image
    img_filename = sprintf('synthetic_img_%03d.jpg', img_idx);
    img_filepath = fullfile(tempdir, img_filename);
    imwrite(synthetic_image, img_filepath);
    
    image_files{img_idx} = img_filepath;
    
    % Store bounding box data
    if ~isempty(bboxes)
        bbox_data{img_idx} = table(bboxes, labels', ...
            'VariableNames', {'BoundingBox', 'Label'});
    else
        bbox_data{img_idx} = table.empty(0, 2);
    end
end

end

function augmented_data = augment_detection_data(data, augmenter, target_size)
% Apply data augmentation to detection data
augmented_data = data;

for idx = 1:height(data)
    % Read and augment image
    original_image = imread(data.imageFilename{idx});
    augmented_image = augment(augmenter, original_image);
    
    % Resize to target size
    augmented_image = imresize(augmented_image, target_size);
    
    % Update data structure
    augmented_data.imageFilename{idx} = original_image;
end

end
