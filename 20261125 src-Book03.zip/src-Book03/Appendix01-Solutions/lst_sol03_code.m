%% lst_sol03_code.m
% LSTM Melody Generation (MATLABBook02_Chapter10_Problem03.m).
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : lst:sol03_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% MATLABBook02_Chapter10_Problem03.m
%  LSTM Melody Generation
%  -------------------
%  Author       : Dr Leo Chen
%  Date         : 2024-01-20
%  Modified     : 2024-07-01
%  Version      : 1.2
%  MATLAB Ver.  : R2024a
%  Toolboxes    : Deep Learning Toolbox
%  Description  :
%    Trains an LSTM network on MIDI note sequences and
%    generates a short melody auto-regressively.
%  Change Log   :
%    v1.0 - Initial release.
%    v1.1 - Added temperature-based sampling.
%    v1.2 - Improved visualisation of generated melody.
%  -------------------

%% Initialisation
clc; clear; close all;

%% --- User Parameters ------------
dataFilePath     = 'midi_note_data.mat'; % Contains noteSeq
sequenceLength   = 20;      % Input subsequence length
hiddenUnits      = 128;     % LSTM hidden units
maxEpochs        = 100;
miniBatchSize    = 64;
initialLearnRate = 0.005;
generationLength = 50;      % Notes to generate
samplingTemp     = 0.8;     % Sampling temperature

%% --- Load Note Sequence -----------
loadedData   = load(dataFilePath);
noteSequence = loadedData.noteSequence;  % 1-D vector
uniqueNotes  = unique(noteSequence);
numClasses   = numel(uniqueNotes);
fprintf('Unique notes: %d\n', numClasses);
fprintf('Sequence length: %d\n', numel(noteSequence));

%% --- Prepare Training Subsequences --------
numSubsequences = numel(noteSequence) - sequenceLength;
inputCells      = cell(numSubsequences, 1);
targetLabels    = categorical( ...
    zeros(numSubsequences, 1));

for subIndex = 1:numSubsequences
    startPos = subIndex;
    endPos   = subIndex + sequenceLength - 1;
    inputCells{subIndex} = noteSequence(startPos:endPos).';
    targetLabels(subIndex) = categorical( ...
        noteSequence(endPos + 1));
end

fprintf('Training subsequences: %d\n', numSubsequences);

%% --- Define LSTM Network ------------
networkLayers = [
    sequenceInputLayer(1)
    lstmLayer(hiddenUnits, 'OutputMode', 'last')
    dropoutLayer(0.2)
    fullyConnectedLayer(numClasses)
    softmaxLayer
    classificationLayer];

trainingOpts = trainingOptions('adam', ...
    'MaxEpochs',          maxEpochs, ...
    'MiniBatchSize',      miniBatchSize, ...
    'InitialLearnRate',   initialLearnRate, ...
    'GradientThreshold',  1, ...
    'Shuffle',            'every-epoch', ...
    'Verbose',            true, ...
    'Plots',              'training-progress');

%% --- Train Network --------------
trainedNet = trainNetwork( ...
    inputCells, targetLabels, ...
    networkLayers, trainingOpts);

%% --- Generate Melody ------------
seedSequence  = noteSequence(1:sequenceLength).';
generatedNotes = zeros(1, generationLength);

currentInput = seedSequence;
for noteIndex = 1:generationLength
    probabilities = predict(trainedNet, ...
        {currentInput});
    probabilities = double(probabilities);

    % Apply temperature scaling
    logProbs = log(probabilities + 1e-8) / samplingTemp;
    scaledProbs = exp(logProbs) / sum(exp(logProbs));

    % Sample from distribution
    cumulativeProb = cumsum(scaledProbs);
    randomDraw = rand();
    selectedIdx = find(cumulativeProb >= randomDraw, ...
                       1, 'first');
    generatedNotes(noteIndex) = uniqueNotes(selectedIdx);

    % Shift input window
    currentInput = [currentInput(2:end), ...
                    generatedNotes(noteIndex)];
end

%% --- Visualise Generated Melody ---------
figure('Color', 'w', 'Position', [100 100 900 350]);
stem(1:generationLength, generatedNotes, ...
     'filled', 'MarkerSize', 4, ...
     'Color', [0.2 0.4 0.8]);
xlabel('Note Index', 'Interpreter', 'latex');
ylabel('MIDI Note Number', 'Interpreter', 'latex');
title('LSTM-Generated Melody', ...
      'Interpreter', 'latex', 'FontSize', 14);
grid on;
exportgraphics(gcf, ...
    'MATLABBook02_Chapter10_Problem03_output.pdf', ...
    'ContentType', 'vector');

fprintf('Generated %d notes.\n', generationLength);
fprintf('First 10 notes: %s\n', ...
        num2str(generatedNotes(1:10)));
