%% lst_sol10_code.m
% Diffusion vs.\ GAN Comparison (MATLABBook02_Chapter10_Problem10.m).
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : lst:sol10_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% MATLABBook02_Chapter10_Problem10.m
%  Diffusion Models vs. GANs: A Comparative Study
%  -------------------
%  Author       : Dr Leo Chen
%  Date         : 2024-01-20
%  Modified     : 2024-07-01
%  Version      : 1.2
%  MATLAB Ver.  : R2024a
%  Toolboxes    : (none required)
%  Description  :
%    Generates comparison charts and tables for
%    diffusion-model vs. GAN-based generative systems,
%    using published benchmark data.
%  Change Log   :
%    v1.0 - Initial release.
%    v1.1 - Added radar chart.
%    v1.2 - Expanded to four systems.
%  -------------------

%% Initialisation
clc; clear; close all;

%% --- Define Systems and Metrics ---------
systemNames = {'StyleGAN3', 'BigGAN', ...
               'Stable Diffusion', 'DALL-E 2'};
systemTypes = {'GAN', 'GAN', 'Diffusion', 'Diffusion'};

% Quantitative metrics (representative values from
% published papers)
fidScores       = [3.49, 6.95, 8.59, 10.39];
inceptionScores = [9.80, 7.40, 8.10, 7.85];
inferenceTimeS  = [0.05, 0.08, 2.50, 4.80];
trainingGPUDays = [25,   64,   150,  300];

%% --- Summary Table --------------
summaryTable = table( ...
    systemNames.', categorical(systemTypes.'), ...
    fidScores.', inceptionScores.', ...
    inferenceTimeS.', trainingGPUDays.', ...
    'VariableNames', {'System', 'Type', 'FID', 'IS', ...
                      'InferenceTime_s', ...
                      'TrainingGPUDays'});
fprintf('===== Model Comparison =====\n\n');
disp(summaryTable);

%% --- Grouped Bar Chart: FID and IS --------
figure('Color', 'w', 'Position', [100 100 800 400]);

subplot(1, 2, 1);
barData = [fidScores; inceptionScores].';
barHandle = bar(barData);
set(gca, 'XTickLabel', systemNames, ...
         'XTickLabelRotation', 25);
ylabel('Score', 'Interpreter', 'latex');
title('FID and IS Comparison', ...
      'Interpreter', 'latex', 'FontSize', 13);
legend({'FID ($\downarrow$ better)', ...
        'IS ($\uparrow$ better)'}, ...
       'Interpreter', 'latex', ...
       'Location', 'northwest');
grid on;

subplot(1, 2, 2);
barColours = [0.2 0.6 0.9; 0.2 0.6 0.9; ...
              0.9 0.4 0.2; 0.9 0.4 0.2];
barHandle2 = bar(inferenceTimeS);
set(gca, 'XTickLabel', systemNames, ...
         'XTickLabelRotation', 25);
ylabel('Time (s)', 'Interpreter', 'latex');
title('Inference Time per Sample', ...
      'Interpreter', 'latex', 'FontSize', 13);
grid on;

sgtitle('Diffusion Models vs.\ GANs', ...
        'Interpreter', 'latex', 'FontSize', 15);
exportgraphics(gcf, ...
    'MATLABBook02_Chapter10_Problem10_bars.pdf', ...
    'ContentType', 'vector');

%% --- Radar Chart: Qualitative Criteria ------
% Criteria: Diversity, Fidelity, Speed, Stability,
%           Controllability
% Scores: 1 (poor) to 5 (excellent) �?aggregated
criteriaNames = {'Diversity', 'Fidelity', 'Speed', ...
                 'Stability', 'Controllability'};
ganAvgScores       = [3, 4.5, 5, 2.5, 3];
diffusionAvgScores = [5, 4,   2, 4.5, 4];

figure('Color', 'w', 'Position', [100 100 550 500]);
numCriteria = numel(criteriaNames);
angles = linspace(0, 2*pi, numCriteria + 1);

polarplot(angles, [ganAvgScores, ganAvgScores(1)], ...
    '-o', 'LineWidth', 2, 'Color', [0.2 0.5 0.9]);
hold on;
polarplot(angles, ...
    [diffusionAvgScores, diffusionAvgScores(1)], ...
    '-s', 'LineWidth', 2, 'Color', [0.9 0.3 0.2]);
thetaticks(rad2deg(angles(1:end-1)));
thetaticklabels(criteriaNames);
rlim([0 5]);
legend({'GAN (average)', 'Diffusion (average)'}, ...
       'Interpreter', 'latex', ...
       'Location', 'southoutside');
title('Qualitative Comparison Radar', ...
      'Interpreter', 'latex', 'FontSize', 14);
exportgraphics(gcf, ...
    'MATLABBook02_Chapter10_Problem10_radar.pdf', ...
    'ContentType', 'vector');

fprintf('Figures exported.\n');
