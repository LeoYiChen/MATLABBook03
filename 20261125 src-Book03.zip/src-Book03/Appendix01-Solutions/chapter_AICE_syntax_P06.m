%% chapter_AICE_syntax_P06.m
% Tree prediction and residual thresholding syntax.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AICE_syntax_P06
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
treeModel  = fitrtree(trainFeatures, trainTarget);
prediction = predict(treeModel, allFeatures);
residual   = measured - prediction;
threshold  = 3 * std(residual(trainIdx));
anomalyFlag = abs(residual) > threshold;
% - Computational Complexity -
% Training is O(N d log N) for N samples and d features.
% Prediction over all samples is O(M log N) for M total
% samples. Residual computation and thresholding are each O(M).
