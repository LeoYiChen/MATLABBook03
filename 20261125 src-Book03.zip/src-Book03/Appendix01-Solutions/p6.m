%% p6.m
% MATLABBook03_ChapterAIBHS_Problem06.m
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : p6
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function MATLABBook03_ChapterAIBHS_Problem06
% Purpose: random-forest variant pathogenicity + AUC.
% Author: Dr Leo Chen. R2024b + Statistics ML. v1.0 2025-06-01.
    rng(0); n=400;
    F=[[randn(n/2,1)+2;randn(n/2,1)],[randn(n/2,1)+1.5;randn(n/2,1)-0.5], ...
       [abs(randn(n/2,1))*0.01;abs(randn(n/2,1))*0.2]];
    y=[ones(n/2,1);zeros(n/2,1)]; cv=cvpartition(y,'HoldOut',0.3);
    tr=training(cv); te=test(cv);
    forest=TreeBagger(100,F(tr,:),y(tr),'Method','classification');
    [lab,sc]=predict(forest,F(te,:)); p=str2double(lab);
    C=confusionmat(y(te),p); [~,~,~,auc]=perfcurve(y(te),sc(:,2),1);
    fprintf('Sens: %.3f  Spec: %.3f  AUC: %.3f\n', ...
        C(2,2)/sum(C(2,:)), C(1,1)/sum(C(1,:)), auc);
end
