%% svm_binary_classification.m
% SVM Binary Classification Implementation
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : svm_binary_classification
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Support Vector Machine Binary Classification
% Author: Dr Leo Chen
% Version: R2023b
% Date: November 2024

function svm_binary_classification()
% Generate synthetic binary classification dataset
rng(42); % Ensure reproducibility
num_samples = 200;


% Class 1: Gaussian distribution
class1_mean = [2, 2];
class1_covariance = [1, 0.5; 0.5, 1];
class1_data = mvnrnd(class1_mean, class1_covariance, num_samples/2);
class1_labels = ones(num_samples/2, 1);

% Class 2: Gaussian distribution
class2_mean = [-1, -1];
class2_covariance = [1, -0.3; -0.3, 1];
class2_data = mvnrnd(class2_mean, class2_covariance, num_samples/2);
class2_labels = -ones(num_samples/2, 1);

% Combine datasets
feature_matrix = [class1_data; class2_data];
class_labels = [class1_labels; class2_labels];

% Train SVM with RBF kernel
svm_model = fitcsvm(feature_matrix, class_labels, ...
    'KernelFunction', 'rbf', ...
    'BoxConstraint', 1, ...
    'KernelScale', 'auto', ...
    'Standardize', true);

% Perform cross-validation
cv_model = crossval(svm_model, 'KFold', 5);
classification_error = kfoldLoss(cv_model);
accuracy_percentage = (1 - classification_error) * 100;

% Generate decision boundary visualisation
[x1_grid, x2_grid] = meshgrid(linspace(-4, 5, 100), ...
    linspace(-4, 5, 100));
grid_points = [x1_grid(:), x2_grid(:)];

% Predict on grid
[predicted_labels, decision_scores] = predict(svm_model, grid_points);
decision_surface = reshape(decision_scores(:, 2), size(x1_grid));

% Visualisation
figure('Name', 'SVM Classification Results');
contour(x1_grid, x2_grid, decision_surface, [0, 0], 'k-', 'LineWidth', 2);
hold on;

% Plot data points
scatter(feature_matrix(class_labels == 1, 1), ...
    feature_matrix(class_labels == 1, 2), ...
    'ro', 'MarkerFaceColor', 'r', 'DisplayName', 'Class 1');
scatter(feature_matrix(class_labels == -1, 1), ...
    feature_matrix(class_labels == -1, 2), ...
    'bo', 'MarkerFaceColor', 'b', 'DisplayName', 'Class 2');

% Highlight support vectors
support_vector_indices = svm_model.IsSupportVector;
scatter(feature_matrix(support_vector_indices, 1), ...
    feature_matrix(support_vector_indices, 2), ...
    100, 'k', 'LineWidth', 2, 'DisplayName', 'Support Vectors');

xlabel('Feature 1', 'Interpreter', 'latex');
ylabel('Feature 2', 'Interpreter', 'latex');
title('SVM Binary Classification with RBF Kernel', 'Interpreter', 'latex');
legend('Location', 'best');
grid on;

fprintf('\\textbf{Cross-Validation Accuracy}: %.2f%%\\n', accuracy_percentage);
fprintf('\\textbf{Number of Support Vectors}: %d\\n', sum(support_vector_indices));

end
