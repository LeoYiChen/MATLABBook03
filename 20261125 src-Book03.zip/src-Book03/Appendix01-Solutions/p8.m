%% p8.m
% MATLABBook03_ChapterAIBHS_Problem08.m
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : p8
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function MATLABBook03_ChapterAIBHS_Problem08
% Purpose: neighbour-joining phylogeny (synthetic).
% Author: Dr Leo Chen. R2024b + Bioinformatics. v1.0 2025-06-01.
    rng(0); anc=repmat('ACGT',1,25); bases='ACGT'; T=6;
    rates=linspace(0.02,0.20,T); seqs=cell(T,1); names=cell(T,1);
    for k=1:T
        s=anc; m=rand(1,numel(s))<rates(k); s(m)=bases(randi(4,sum(m),1));
        seqs{k}=s; names{k}=sprintf('Taxon_%d',k);
    end
    d=seqpdist(seqs,'Method','p-distance'); tree=seqneighjoin(d,'equivar',names);
    fprintf('Taxa: %d  Max p-distance: %.3f\n',T,max(squareform(d),[],'all'));
    figure; plot(tree);
end
