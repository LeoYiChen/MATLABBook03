%% chapter_AI_ICT_problem4_solution.m
% AI-Enhanced Network Slicing Implementation
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AI_ICT_problem4_solution
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [slicing_results, optimisation_metrics] = aiNetworkSlicingOptimisation()
% AI-Enhanced Network Slicing Optimisation for 5G Systems
% Author: Dr Leo Chen
% Version: 1.0
% Date: 2024
%
% Implements intelligent network slicing with deep reinforcement learning
% for dynamic resource allocation across heterogeneous service requirements

fprintf('=== AI-Enhanced Network Slicing Solution ===\n');

% Network infrastructure configuration
network_config = struct();
network_config.num_base_stations = 20; % Network base stations
network_config.num_users = 1000; % Total network users
network_config.total_bandwidth_mhz = 1000; % Available spectrum
network_config.total_compute_units = 5000; % Processing capacity
network_config.total_storage_gb = 10000; % Storage capacity

% Service slice definitions
slice_config = struct();
slice_config.embb = defineEMBBSlice(); % Enhanced mobile broadband
slice_config.urllc = defineURLLCSlice(); % Ultra-reliable low latency
slice_config.mmtc = defineMTCSlice(); % Massive machine type

% AI optimisation configuration
ai_config = struct();
ai_config.algorithm = 'deep_deterministic_policy_gradient';
ai_config.num_episodes = 2000; % Training episodes
ai_config.learning_rate_actor = 1e-4; % Actor network learning rate
ai_config.learning_rate_critic = 1e-3; % Critic network learning rate
ai_config.discount_factor = 0.99; % Reward discount factor
ai_config.exploration_noise = 0.1; % Action exploration noise

% Initialise network slicing environment
fprintf('Initialising network slicing environment...\n');
slicing_environment = initialiseNetworkSlicingEnvironment(network_config, slice_config);

% Create AI-based slice orchestrator
fprintf('Creating AI-based slice orchestrator...\n');
slice_orchestrator = createSliceOrchestrator(slicing_environment, ai_config);

% Train intelligent resource allocation policies
fprintf('Training intelligent resource allocation policies...\n');
[trained_orchestrator, training_history] = trainSliceOrchestrator(slice_orchestrator, ...
slicing_environment, ...
ai_config);

% Evaluate network slicing performance
fprintf('Evaluating network slicing performance...\n');
slicing_results = evaluateNetworkSlicingPerformance(trained_orchestrator, ...
slicing_environment, ...
network_config);

% Analyse optimisation convergence and efficiency
optimisation_metrics = analyseOptimisationMetrics(training_history, ai_config);

% Generate comprehensive performance visualisations
generateSlicingVisualisations(slicing_results, optimisation_metrics, training_history);

fprintf('Network slicing optimisation analysis completed successfully!\n');
end

function slicing_environment = initialiseNetworkSlicingEnvironment(network_config, slice_config)
% Initialise comprehensive network slicing environment

slicing_environment = struct();
slicing_environment.network_config = network_config;
slicing_environment.slice_config = slice_config;

% Resource pool definition
slicing_environment.resources = struct();
slicing_environment.resources.spectrum = network_config.total_bandwidth_mhz;
slicing_environment.resources.compute = network_config.total_compute_units;
slicing_environment.resources.storage = network_config.total_storage_gb;

% Base station resource distribution
slicing_environment.base_stations = initialiseBaseStations(network_config);

% User distribution and service requirements
slicing_environment.users = initialiseNetworkUsers(network_config, slice_config);

% Traffic pattern models
slicing_environment.traffic_models = createTrafficModels(slice_config);

% Quality of service requirements
slicing_environment.qos_requirements = defineQoSRequirements(slice_config);

% Resource allocation state space
slicing_environment.state_space = defineStateSpace(slicing_environment);

% Action space for resource allocation
slicing_environment.action_space = defineActionSpace(slicing_environment);

% Reward function for multi-objective optimisation
slicing_environment.reward_function = defineRewardFunction(slicing_environment);

fprintf(' Network slicing environment initialised\n');
end

function slice_orchestrator = createSliceOrchestrator(environment, ai_config)
% Create AI-based network slice orchestrator

slice_orchestrator = struct();
slice_orchestrator.algorithm_type = ai_config.algorithm;

% State and action dimensions
state_dimension = length(environment.state_space.features);
action_dimension = length(environment.action_space.allocation_vector);

% Actor network (policy network)
slice_orchestrator.actor_network = createActorNetwork(state_dimension, action_dimension, ai_config);

% Critic network (value network)
slice_orchestrator.critic_network = createCriticNetwork(state_dimension, action_dimension, ai_config);

% Experience replay buffer
slice_orchestrator.replay_buffer = struct();
slice_orchestrator.replay_buffer.capacity = 100000;
slice_orchestrator.replay_buffer.states = [];
slice_orchestrator.replay_buffer.actions = [];
slice_orchestrator.replay_buffer.rewards = [];
slice_orchestrator.replay_buffer.next_states = [];
slice_orchestrator.replay_buffer.dones = [];

% Target networks for stable learning
slice_orchestrator.target_actor = slice_orchestrator.actor_network;
slice_orchestrator.target_critic = slice_orchestrator.critic_network;

% Optimisation parameters
slice_orchestrator.tau = 0.005; % Soft update parameter
slice_orchestrator.batch_size = 64; % Training batch size
slice_orchestrator.update_frequency = 4; % Network update frequency

fprintf(' Slice orchestrator created with DDPG algorithm\n');
end

function actor_network = createActorNetwork(state_dim, action_dim, ai_config)
% Create actor network for continuous action space

layers = [
featureInputLayer(state_dim, 'Name', 'state_input')

 
fullyConnectedLayer(256, 'Name', 'actor_fc1')
reluLayer('Name', 'actor_relu1')

fullyConnectedLayer(512, 'Name', 'actor_fc2')
reluLayer('Name', 'actor_relu2')

fullyConnectedLayer(256, 'Name', 'actor_fc3')
reluLayer('Name', 'actor_relu3')

fullyConnectedLayer(action_dim, 'Name', 'actor_output')
tanhLayer('Name', 'actor_tanh') % Bounded actions
];

% Training options
training_options = trainingOptions('adam', ...
'MaxEpochs', 1, ...
'MiniBatchSize', 1, ...
'InitialLearnRate', ai_config.learning_rate_actor, ...
'Shuffle', 'never', ...
'Verbose', false, ...
'Plots', 'none');

actor_network = struct();
actor_network.layers = layers;
actor_network.options = training_options;

fprintf(' Actor network created with %d layers\n', length(layers));
end

function critic_network = createCriticNetwork(state_dim, action_dim, ai_config)
% Create critic network for Q-value estimation

% State pathway
state_input = featureInputLayer(state_dim, 'Name', 'state_input');
state_fc1 = fullyConnectedLayer(256, 'Name', 'state_fc1');
state_relu1 = reluLayer('Name', 'state_relu1');

% Action pathway
action_input = featureInputLayer(action_dim, 'Name', 'action_input');
action_fc1 = fullyConnectedLayer(256, 'Name', 'action_fc1');

% Combined pathway
combined_layer = additionLayer(2, 'Name', 'state_action_combine');
combined_fc1 = fullyConnectedLayer(512, 'Name', 'combined_fc1');
combined_relu1 = reluLayer('Name', 'combined_relu1');
combined_fc2 = fullyConnectedLayer(256, 'Name', 'combined_fc2');
combined_relu2 = reluLayer('Name', 'combined_relu2');
q_value_output = fullyConnectedLayer(1, 'Name', 'q_value');

% Create layer graph
critic_graph = layerGraph();
critic_graph = addLayers(critic_graph, [state_input; state_fc1; state_relu1]);
critic_graph = addLayers(critic_graph, [action_input; action_fc1]);
critic_graph = addLayers(critic_graph, [combined_layer; combined_fc1; combined_relu1; ...
combined_fc2; combined_relu2; q_value_output]);

% Connect pathways
critic_graph = connectLayers(critic_graph, 'state_relu1', 'state_action_combine/in1');
critic_graph = connectLayers(critic_graph, 'action_fc1', 'state_action_combine/in2');

% Training options
training_options = trainingOptions('adam', ...
'MaxEpochs', 1, ...
'MiniBatchSize', 1, ...
'InitialLearnRate', ai_config.learning_rate_critic, ...
'Shuffle', 'never', ...
'Verbose', false, ...
'Plots', 'none');

critic_network = struct();
critic_network.graph = critic_graph;
critic_network.options = training_options;

fprintf(' Critic network created with dual input pathways\n');
end
