%% lst_sol02_code.m
% Music Genre Classification with SVMs (MATLABBook02_Chapter10_Problem02.m).
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : lst:sol02_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% MATLABBook02_Chapter10_Problem02.m
%  Music Genre Classification with SVMs
%  -------------------
%  Author       : Dr Leo Chen
%  Date         : 2024-01-20
%  Modified     : 2024-07-01
%  Version      : 1.2
%  MATLAB Ver.  : R2024a
%  Toolboxes    : Audio Toolbox, Statistics and Machine
%                 Learning Toolbox
%  Description  :
%    Classifies music tracks into genres using SVMs with
%    different kernel functions.  Reports accuracy,
%    precision, recall, and F1-score.
%  Change Log   :
%    v1.0 - Initial release.
%    v1.1 - Added polynomial kernel comparison.
%    v1.2 - Improved metric reporting with LaTeX table.
%  -------------------

%% Initialisation
clc; clear; close all;

%% --- User Parameters ------------
dataRootFolder  = 'genre_dataset';  % Subfolders per genre
testFraction    = 0.30;
randomSeed      = 42;
numMFCC         = 13;

%% --- Build File List and Extract Features -----
genreFolders = dir(dataRootFolder);
genreFolders = genreFolders([genreFolders.isdir]);
genreFolders = genreFolders(~ismember( ...
    {genreFolders.name}, {'.', '..'}));

featureMatrix = [];
genreLabels   = {};

for folderIndex = 1:numel(genreFolders)
    currentGenre = genreFolders(folderIndex).name;
    audioFiles   = dir(fullfile(dataRootFolder, ...
                       currentGenre, '*.wav'));

    for fileIndex = 1:numel(audioFiles)
        filePath = fullfile(audioFiles(fileIndex).folder,...
                            audioFiles(fileIndex).name);
        [signal, sampleRate] = audioread(filePath);
        if size(signal, 2) > 1
            signal = mean(signal, 2);
        end

        % - Extract features -
        mfccCoeffs    = mfcc(signal, sampleRate, ...
                             'NumCoeffs', numMFCC);
        centroidVals  = spectralCentroid( ...
                            signal, sampleRate);
        zeroCrossVals = zerocrossrate(signal);

        featureVector = [mean(mfccCoeffs, 1, ...
                              'omitnan'), ...
                         std(mfccCoeffs, 0, 1, ...
                             'omitnan'), ...
                         mean(centroidVals, ...
                              'omitnan'), ...
                         std(centroidVals, ...
                             'omitnan'), ...
                         mean(zeroCrossVals, ...
                              'omitnan')];

        featureMatrix = [featureMatrix; featureVector];
        genreLabels   = [genreLabels; currentGenre];
    end
end

genreLabels = categorical(genreLabels);
fprintf('Total tracks: %d\n', numel(genreLabels));
fprintf('Feature dimension: %d\n', ...
        size(featureMatrix, 2));

%% --- Partition Data -------------
rng(randomSeed);
partitionObj = cvpartition(genreLabels, ...
    'HoldOut', testFraction);
trainIdx = training(partitionObj);
testIdx  = test(partitionObj);

trainingFeatures = featureMatrix(trainIdx, :);
trainingLabels   = genreLabels(trainIdx);
testFeatures     = featureMatrix(testIdx, :);
testLabels       = genreLabels(testIdx);

%% --- Train SVMs with Different Kernels ------
kernelNames = {'linear', 'polynomial', 'rbf'};
numKernels  = numel(kernelNames);

accuracyValues  = zeros(1, numKernels);
precisionValues = zeros(1, numKernels);
recallValues    = zeros(1, numKernels);
f1ScoreValues   = zeros(1, numKernels);

for kernelIndex = 1:numKernels
    svmTemplate = templateSVM( ...
        'KernelFunction', kernelNames{kernelIndex}, ...
        'KernelScale',    'auto', ...
        'Standardize',    true);

    trainedModel = fitcecoc( ...
        trainingFeatures, trainingLabels, ...
        'Learners', svmTemplate);

    predictions = predict(trainedModel, testFeatures);

    % - Confusion matrix and metrics -
    confMat = confusionmat(testLabels, predictions);
    numClasses = size(confMat, 1);

    perClassPrecision = zeros(numClasses, 1);
    perClassRecall    = zeros(numClasses, 1);
    for classIndex = 1:numClasses
        truePos  = confMat(classIndex, classIndex);
        predPos  = sum(confMat(:, classIndex));
        actualPos = sum(confMat(classIndex, :));
        if predPos  > 0
            perClassPrecision(classIndex) = ...
                truePos / predPos;
        end
        if actualPos > 0
            perClassRecall(classIndex) = ...
                truePos / actualPos;
        end
    end

    accuracyValues(kernelIndex)  = ...
        sum(diag(confMat)) / sum(confMat(:));
    precisionValues(kernelIndex) = ...
        mean(perClassPrecision);
    recallValues(kernelIndex)    = ...
        mean(perClassRecall);

    pTemp = precisionValues(kernelIndex);
    rTemp = recallValues(kernelIndex);
    if (pTemp + rTemp) > 0
        f1ScoreValues(kernelIndex) = ...
            2 * pTemp * rTemp / (pTemp + rTemp);
    end
end

%% --- Display Results ------------
fprintf('\n%-12s  %8s  %9s  %8s  %8s\n', ...
    'Kernel', 'Accuracy', 'Precision', ...
    'Recall', 'F1');
fprintf('%s\n', repmat('-', 1, 55));
for kernelIndex = 1:numKernels
    fprintf('%-12s  %8.2f%%  %8.2f%%  %8.2f%%  %8.2f%%\n',...
        kernelNames{kernelIndex}, ...
        accuracyValues(kernelIndex)  * 100, ...
        precisionValues(kernelIndex) * 100, ...
        recallValues(kernelIndex)    * 100, ...
        f1ScoreValues(kernelIndex)   * 100);
end

%% --- Confusion Chart for Best Kernel --------
[~, bestKernelIdx] = max(f1ScoreValues);
svmBestTemplate = templateSVM( ...
    'KernelFunction', kernelNames{bestKernelIdx}, ...
    'KernelScale',    'auto', ...
    'Standardize',    true);
bestModel       = fitcecoc(trainingFeatures, ...
                           trainingLabels, ...
                           'Learners', svmBestTemplate);
bestPredictions = predict(bestModel, testFeatures);

figure('Color', 'w');
confusionchart(testLabels, bestPredictions);
title(['Confusion Matrix - ', ...
       kernelNames{bestKernelIdx}, ' kernel'], ...
      'Interpreter', 'latex');
exportgraphics(gcf, ...
    'MATLABBook02_Chapter10_Problem02_output.pdf', ...
    'ContentType', 'vector');
fprintf('\nBest kernel: %s\n', ...
        kernelNames{bestKernelIdx});
