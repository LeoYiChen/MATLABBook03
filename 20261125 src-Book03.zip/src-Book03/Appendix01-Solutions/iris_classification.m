%% iris_classification.m
% Neural Network Classification Implementation
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : iris_classification
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Neural Network Classification for Iris Dataset
% Author: Dr Leo Chen
% Version: R2023b
% Date: November 2024

function iris_classification_network()
% Load the Iris dataset
load fisheriris;
input_features = meas'; % Transpose for MATLAB neural network format

% Convert species names to numerical targets
target_classes = zeros(3, length(species));
unique_species = unique(species);

for species_index = 1:length(species)
    class_index = strcmp(species{species_index}, unique_species);
    target_classes(class_index, species_index) = 1;
end

% Create pattern recognition network
hidden_neurons = 10;
neural_network = patternnet(hidden_neurons);

% Configure training parameters
neural_network.trainParam.epochs = 1000;
neural_network.trainParam.lr = 0.01;
neural_network.trainParam.goal = 1e-6;

% Train the network
[trained_network, training_record] = train(neural_network, ...
    input_features, target_classes);

% Generate predictions
network_outputs = trained_network(input_features);
predicted_classes = vec2ind(network_outputs);
actual_classes = vec2ind(target_classes);

% Calculate performance metrics
accuracy_percentage = sum(predicted_classes == actual_classes) / ...
    length(actual_classes) * 100;

% Display results
fprintf('\\textbf{Classification Accuracy}: %.2f%%\\n', accuracy_percentage);

% Generate confusion matrix
confusion_matrix = confusionmat(actual_classes, predicted_classes);

% Visualise training performance
figure('Name', 'Training Performance');
plotperform(training_record);
title('Neural Network Training Performance', 'Interpreter', 'latex');
xlabel('Training Epochs', 'Interpreter', 'latex');
ylabel('Mean Squared Error', 'Interpreter', 'latex');

% Display confusion matrix
figure('Name', 'Confusion Matrix');
confusionchart(actual_classes, predicted_classes, ...
    'ColumnSummary', 'column-normalized', ...
    'RowSummary', 'row-normalized');
title('Classification Confusion Matrix', 'Interpreter', 'latex');

end
