%% css_degroot.m
% DeGroot opinion dynamics in base MATLAB.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : css_degroot
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function opinionTrace = simulateOpinionDynamics(influence, initial, numSteps)
% simulateOpinionDynamics  DeGroot averaging model of social influence.
%   opinionTrace = simulateOpinionDynamics(influence, initial, numSteps)
%   influence : row-stochastic n-by-n matrix.
%   Author: Dr Leo Chen | Version 1.0 | Base MATLAB (R2021b+)

    numAgents = numel(initial);
    opinionTrace = zeros(numSteps + 1, numAgents);
    opinionTrace(1, :) = initial(:)';

    for step = 1:numSteps
        opinionTrace(step + 1, :) = (influence * opinionTrace(step, :)')';
    end

    plot(0:numSteps, opinionTrace, '-o'); grid on;
    xlabel('$\mathrm{Iteration}$', 'Interpreter', 'latex');
    ylabel('$\mathrm{Opinion}$', 'Interpreter', 'latex');
    title('$\mathrm{DeGroot\ consensus\ dynamics}$', 'Interpreter', 'latex');
end
