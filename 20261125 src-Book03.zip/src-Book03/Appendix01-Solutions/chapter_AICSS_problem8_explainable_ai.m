%% chapter_AICSS_problem8_explainable_ai.m
% Explainable AI framework for critical decision support systems.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AICSS_problem8_explainable_ai
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function explainabilityResults = implementExplainableAIFramework(aiModel, testData, explainabilityConfiguration, userRequirements)
    % Comprehensive explainable AI framework for critical decision support
    % Author: Dr Leo Chen
    % Version: 1.0 - Initial implementation
    % Date: December 2024
    
    fprintf('Implementing explainable AI framework for critical decision support...\n');
    
    % Initialize results structure
    explainabilityResults = struct();
    explainabilityResults.timestamp = datetime('now');
    explainabilityResults.explainabilityConfiguration = explainabilityConfiguration;
    explainabilityResults.userRequirements = userRequirements;
    
    % Extract test data
    testInputs = testData.inputs;
    testLabels = testData.labels;
    numberOfSamples = size(testInputs, 1);
    
    fprintf('Processing %d test samples for explainability analysis...\n', numberOfSamples);
    
    % Generate model predictions
    modelPredictions = predict(aiModel, testInputs);
    explainabilityResults.modelPredictions = modelPredictions;
    
    % Implement multiple explanation methods
    explanationMethods = explainabilityConfiguration.methods;
    explanations = struct();
    
    for methodIndex = 1:length(explanationMethods)
        explanationMethod = explanationMethods{methodIndex};
        fprintf('Generating explanations using %s method...\n', explanationMethod);
        
        switch explanationMethod
            case 'LIME'
                limeExplanations = generateLIMEExplanations(aiModel, testInputs, explainabilityConfiguration.lime);
                explanations.LIME = limeExplanations;
                
            case 'SHAP'
                shapExplanations = generateSHAPExplanations(aiModel, testInputs, explainabilityConfiguration.shap);
                explanations.SHAP = shapExplanations;
                
            case 'GradientBased'
                gradientExplanations = generateGradientBasedExplanations(aiModel, testInputs, explainabilityConfiguration.gradient);
                explanations.GradientBased = gradientExplanations;
                
            case 'AttentionMaps'
                if isfield(aiModel, 'attentionWeights')
                    attentionExplanations = extractAttentionExplanations(aiModel, testInputs);
                    explanations.AttentionMaps = attentionExplanations;
                end
                
            case 'RuleExtraction'
                ruleExplanations = extractDecisionRules(aiModel, testInputs, explainabilityConfiguration.rules);
                explanations.RuleExtraction = ruleExplanations;
                
            case 'CounterfactualExplanations'
                counterfactualExplanations = generateCounterfactualExplanations(aiModel, testInputs, explainabilityConfiguration.counterfactual);
                explanations.CounterfactualExplanations = counterfactualExplanations;
                
            otherwise
                fprintf('Warning: Unknown explanation method %s\n', explanationMethod);
        end
    end
    
    explainabilityResults.explanations = explanations;
    
    % Evaluate explanation quality
    explanationQuality = evaluateExplanationQuality(explanations, testData, userRequirements);
    explainabilityResults.explanationQuality = explanationQuality;
    
    % Generate user-specific explanation formats
    userSpecificExplanations = generateUserSpecificExplanations(explanations, userRequirements);
    explainabilityResults.userSpecificExplanations = userSpecificExplanations;
    
    % Assess explanation consistency across methods
    consistencyAnalysis = assessExplanationConsistency(explanations);
    explainabilityResults.consistencyAnalysis = consistencyAnalysis;
    
    % Validate explanations against ground truth
    explanationValidation = validateExplanationsAgainstGroundTruth(explanations, testData);
    explainabilityResults.explanationValidation = explanationValidation;
    
    % Generate trust and confidence metrics
    trustMetrics = calculateTrustAndConfidenceMetrics(explanations, modelPredictions, testData);
    explainabilityResults.trustMetrics = trustMetrics;
    
    % Create interactive explanation interface
    interactiveInterface = createInteractiveExplanationInterface(explanations, modelPredictions, testData);
    explainabilityResults.interactiveInterface = interactiveInterface;
    
    % Generate comprehensive visualisation
    generateExplainabilityvisualisation(explainabilityResults, testData);
    
    % Assess regulatory compliance
    regulatoryCompliance = assessRegulatoryCompliance(explainabilityResults, userRequirements.regulations);
    explainabilityResults.regulatoryCompliance = regulatoryCompliance;
    
    % Save explainability results
    saveExplainabilityResults(explainabilityResults);
    
    fprintf('Explainable AI framework implementation completed.\n');
end

function limeExplanations = generateLIMEExplanations(model, inputs, limeConfig)
    % Generate LIME (Local Interpretable Model-agnostic Explanations)
    
    numberOfSamples = size(inputs, 1);
    numberOfFeatures = size(inputs, 2);
    limeExplanations = struct();
    
    % LIME parameters
    numberOfPerturbations = limeConfig.numberOfPerturbations;
    proximityFunction = limeConfig.proximityFunction;
    
    featureImportances = zeros(numberOfSamples, numberOfFeatures);
    localModelAccuracies = zeros(numberOfSamples, 1);
    
    for sampleIndex = 1:numberOfSamples
        originalInput = inputs(sampleIndex, :);
        originalPrediction = predict(model, originalInput);
        
        % Generate perturbations around the original input
        perturbations = generateInputPerturbations(originalInput, numberOfPerturbations, limeConfig);
        
        % Get predictions for perturbations
        perturbationPredictions = zeros(numberOfPerturbations, 1);
        for perturbationIndex = 1:numberOfPerturbations
            perturbationPredictions(perturbationIndex) = predict(model, perturbations(perturbationIndex, :));
        end
        
        % Calculate proximities (weights for local model)
        proximities = calculateProximities(originalInput, perturbations, proximityFunction);
        
        % Fit local linear model
        [localModel, localAccuracy] = fitLocalLinearModel(perturbations, perturbationPredictions, proximities);
        
        % Extract feature importance
        featureImportances(sampleIndex, :) = localModel.Coefficients.Estimate(2:end)'; % Exclude intercept
        localModelAccuracies(sampleIndex) = localAccuracy;
    end
    
    limeExplanations.featureImportances = featureImportances;
    limeExplanations.localModelAccuracies = localModelAccuracies;
    limeExplanations.averageLocalAccuracy = mean(localModelAccuracies);
end

function shapExplanations = generateSHAPExplanations(model, inputs, shapConfig)
    % Generate SHAP (SHapley Additive exPlanations) values
    
    numberOfSamples = size(inputs, 1);
    numberOfFeatures = size(inputs, 2);
    
    % Simplified SHAP implementation using sampling approach
    numberOfCoalitions = shapConfig.numberOfCoalitions;
    shapValues = zeros(numberOfSamples, numberOfFeatures);
    
    for sampleIndex = 1:numberOfSamples
        currentInput = inputs(sampleIndex, :);
        
        % Calculate baseline (prediction with all features removed/baseline values)
        baselineInput = shapConfig.baselineValues;
        baselinePrediction = predict(model, baselineInput);
        
        % Calculate SHAP values for each feature
        for featureIndex = 1:numberOfFeatures
            shapValue = 0;
            
            % Sample coalitions
            for coalitionIndex = 1:numberOfCoalitions
                % Generate random coalition excluding current feature
                coalitionMask = rand(1, numberOfFeatures) > 0.5;
                coalitionMask(featureIndex) = false;
                
                % Create input with coalition features
                coalitionInput = baselineInput;
                coalitionInput(coalitionMask) = currentInput(coalitionMask);
                
                % Create input with coalition + current feature
                coalitionPlusInput = coalitionInput;
                coalitionPlusInput(featureIndex) = currentInput(featureIndex);
                
                % Calculate marginal contribution
                coalitionPrediction = predict(model, coalitionInput);
                coalitionPlusPrediction = predict(model, coalitionPlusInput);
                
                marginalContribution = coalitionPlusPrediction - coalitionPrediction;
                shapValue = shapValue + marginalContribution;
            end
            
            shapValues(sampleIndex, featureIndex) = shapValue / numberOfCoalitions;
        end
    end
    
    shapExplanations.shapValues = shapValues;
    shapExplanations.baselinePrediction = baselinePrediction;
    
    % Verify SHAP efficiency property (values sum to prediction difference)
    for sampleIndex = 1:numberOfSamples
        actualPrediction = predict(model, inputs(sampleIndex, :));
        predictedSum = baselinePrediction + sum(shapValues(sampleIndex, :));
        shapExplanations.efficiencyError(sampleIndex) = abs(actualPrediction - predictedSum);
    end
end

function counterfactualExplanations = generateCounterfactualExplanations(model, inputs, counterfactualConfig)
    % Generate counterfactual explanations showing minimal changes for different predictions
    
    numberOfSamples = size(inputs, 1);
    numberOfFeatures = size(inputs, 2);
    
    counterfactualExplanations = struct();
    counterfactuals = cell(numberOfSamples, 1);
    distances = zeros(numberOfSamples, 1);
    
    for sampleIndex = 1:numberOfSamples
        originalInput = inputs(sampleIndex, :);
        originalPrediction = predict(model, originalInput);
        originalClass = round(originalPrediction);
        
        % Find counterfactual with different prediction
        targetClass = 1 - originalClass; % Binary classification assumption
        
        % Optimisation to find minimal perturbation
        objectiveFunction = @(x) calculateCounterfactualObjective(x, originalInput, model, targetClass);
        
        % Use pattern search for optimisation (global optimisation alternative)
        options = optimoptions('patternsearch', 'Display', 'off', 'MaxIterations', 100);
        
        % Set bounds (allow --20% change in each feature)
        lowerBounds = originalInput * 0.8;
        upperBounds = originalInput * 1.2;
        
        try
            [counterfactualInput, minDistance] = patternsearch(objectiveFunction, originalInput, ...
                [], [], [], [], lowerBounds, upperBounds, [], options);
            
            % Verify that counterfactual has different prediction
            counterfactualPrediction = predict(model, counterfactualInput);
            counterfactualClass = round(counterfactualPrediction);
            
            if counterfactualClass == targetClass
                counterfactuals{sampleIndex} = counterfactualInput;
                distances(sampleIndex) = norm(counterfactualInput - originalInput);
            else
                counterfactuals{sampleIndex} = [];
                distances(sampleIndex) = Inf;
            end
            
        catch optimisationError
            fprintf('Warning: Counterfactual generation failed for sample %d: %s\n', ...
                sampleIndex, optimisationError.message);
            counterfactuals{sampleIndex} = [];
            distances(sampleIndex) = Inf;
        end
    end
    
    counterfactualExplanations.counterfactuals = counterfactuals;
    counterfactualExplanations.distances = distances;
    counterfactualExplanations.successRate = sum(~isinf(distances)) / numberOfSamples;
    counterfactualExplanations.averageDistance = mean(distances(~isinf(distances)));
end

function objective = calculateCounterfactualObjective(candidateInput, originalInput, model, targetClass)
    % Objective function for counterfactual generation
    
    % Distance penalty (L2 norm)
    distancePenalty = norm(candidateInput - originalInput);
    
    % Prediction penalty (how far from target class)
    prediction = predict(model, candidateInput);
    predictionPenalty = abs(prediction - targetClass);
    
    % Combined objective (minimise distance while achieving target prediction)
    objective = distancePenalty + 10 * predictionPenalty;
end

function generateExplainabilityvisualisation(explainabilityResults, testData)
    % Generate comprehensive explainability visualisation
    
    figure('Position', [100, 100, 1800, 1400]);
    
    explanations = explainabilityResults.explanations;
    explanationMethods = fieldnames(explanations);
    
    % Feature importance comparison across methods
    subplot(3, 4, [1, 2]);
    if isfield(explanations, 'LIME') && isfield(explanations, 'SHAP')
        limeImportances = mean(abs(explanations.LIME.featureImportances), 1);
        shapImportances = mean(abs(explanations.SHAP.shapValues), 1);
        
        featureIndices = 1:length(limeImportances);
        barWidth = 0.35;
        
        bar(featureIndices - barWidth/2, limeImportances, barWidth, 'FaceColor', [0.3, 0.6, 0.9], 'DisplayName', 'LIME');
        hold on;
        bar(featureIndices + barWidth/2, shapImportances, barWidth, 'FaceColor', [0.9, 0.6, 0.3], 'DisplayName', 'SHAP');
        
        xlabel('Feature Index', 'FontSize', 12);
        ylabel('Average Importance', 'FontSize', 12);
        title('Feature Importance Comparison', 'FontSize', 14, 'FontWeight', 'bold');
        legend('show', 'Location', 'best');
        grid on;
    end
    
    % Explanation quality metrics
    subplot(3, 4, 3);
    if isfield(explainabilityResults, 'explanationQuality')
        qualityMetrics = explainabilityResults.explanationQuality;
        qualityMethods = fieldnames(qualityMetrics);
        qualityScores = zeros(length(qualityMethods), 1);
        
        for methodIndex = 1:length(qualityMethods)
            qualityScores(methodIndex) = qualityMetrics.(qualityMethods{methodIndex}).overallQuality;
        end
        
        bar(qualityScores, 'FaceColor', [0.6, 0.8, 0.6], 'EdgeColor', 'darkgreen');
        set(gca, 'XTickLabel', qualityMethods);
        ylabel('Quality Score', 'FontSize', 12);
        title('Explanation Quality Assessment', 'FontSize', 12, 'FontWeight', 'bold');
        xtickangle(45);
        ylim([0, 1]);
        grid on;
    end
    
    % Trust and confidence metrics
    subplot(3, 4, 4);
    if isfield(explainabilityResults, 'trustMetrics')
        trustData = explainabilityResults.trustMetrics;
        trustCategories = {'Consistency', 'Fidelity', 'Stability', 'Comprehensibility'};
        trustScores = [trustData.consistency, trustData.fidelity, trustData.stability, trustData.comprehensibility];
        
        bar(trustScores, 'FaceColor', [0.8, 0.6, 0.8], 'EdgeColor', 'darkmagenta');
        set(gca, 'XTickLabel', trustCategories);
        ylabel('Trust Score', 'FontSize', 12);
        title('Trust and Confidence Metrics', 'FontSize', 12, 'FontWeight', 'bold');
        xtickangle(45);
        ylim([0, 1]);
        grid on;
    end
    
    % LIME explanation example for first sample
    if isfield(explanations, 'LIME')
        subplot(3, 4, 5);
        limeImportances = explanations.LIME.featureImportances(1, :);
        [sortedImportances, sortOrder] = sort(abs(limeImportances), 'descend');
        
        barColours = zeros(length(limeImportances), 3);
        barColours(limeImportances(sortOrder) > 0, :) = repmat([0.2, 0.8, 0.2], sum(limeImportances(sortOrder) > 0), 1);
        barColours(limeImportances(sortOrder) < 0, :) = repmat([0.8, 0.2, 0.2], sum(limeImportances(sortOrder) < 0), 1);
        
        bar(limeImportances(sortOrder), 'FaceColor', 'flat', 'CData', barColours);
        xlabel('Feature Index (Sorted)', 'FontSize', 12);
        ylabel('LIME Importance', 'FontSize', 12);
        title('LIME Explanation (Sample 1)', 'FontSize', 12, 'FontWeight', 'bold');
        grid on;
    end
    
    % SHAP explanation example for first sample
    if isfield(explanations, 'SHAP')
        subplot(3, 4, 6);
        shapValues = explanations.SHAP.shapValues(1, :);
        [sortedValues, sortOrder] = sort(abs(shapValues), 'descend');
        
        barColours = zeros(length(shapValues), 3);
        barColours(shapValues(sortOrder) > 0, :) = repmat([0.2, 0.8, 0.2], sum(shapValues(sortOrder) > 0), 1);
        barColours(shapValues(sortOrder) < 0, :) = repmat([0.8, 0.2, 0.2], sum(shapValues(sortOrder) < 0), 1);
        
        bar(shapValues(sortOrder), 'FaceColor', 'flat', 'CData', barColours);
        xlabel('Feature Index (Sorted)', 'FontSize', 12);
        ylabel('SHAP Value', 'FontSize', 12);
        title('SHAP Explanation (Sample 1)', 'FontSize', 12, 'FontWeight', 'bold');
        grid on;
    end
    
    % Consistency analysis between explanation methods
    subplot(3, 4, 7);
    if isfield(explainabilityResults, 'consistencyAnalysis')
        consistencyData = explainabilityResults.consistencyAnalysis;
        consistencyMatrix = consistencyData.correlationMatrix;
        
        imagesc(consistencyMatrix);
        colorbar;
        colormap('hot');
        set(gca, 'XTickLabel', explanationMethods);
        set(gca, 'YTickLabel', explanationMethods);
        title('Method Consistency Matrix', 'FontSize', 12, 'FontWeight', 'bold');
        xtickangle(45);
    end
    
    % Counterfactual explanation analysis
    if isfield(explanations, 'CounterfactualExplanations')
        subplot(3, 4, 8);
        counterfactualData = explanations.CounterfactualExplanations;
        
        histogram(counterfactualData.distances(~isinf(counterfactualData.distances)), 20, ...
            'FaceColor', [0.7, 0.7, 0.9], 'EdgeColor', 'black');
        xlabel('Counterfactual Distance', 'FontSize', 12);
        ylabel('Frequency', 'FontSize', 12);
        title(sprintf('Counterfactual Distances\n(Success Rate: %.1f%%)', counterfactualData.successRate * 100), ...
              'FontSize', 12, 'FontWeight', 'bold');
        grid on;
    end
    
    % Regulatory compliance assessment
    subplot(3, 4, 9);
    if isfield(explainabilityResults, 'regulatoryCompliance')
        complianceData = explainabilityResults.regulatoryCompliance;
        complianceStandards = fieldnames(complianceData);
        complianceScores = zeros(length(complianceStandards), 1);
        
        for standardIndex = 1:length(complianceStandards)
            complianceScores(standardIndex) = complianceData.(complianceStandards{standardIndex}).complianceScore;
        end
        
        bar(complianceScores, 'FaceColor', [0.9, 0.7, 0.5], 'EdgeColor', 'darkorange');
        set(gca, 'XTickLabel', complianceStandards);
        ylabel('Compliance Score', 'FontSize', 12);
        title('Regulatory Compliance', 'FontSize', 12, 'FontWeight', 'bold');
        xtickangle(45);
        ylim([0, 1]);
        grid on;
    end
    
    % User-specific explanation preferences
    subplot(3, 4, 10);
    if isfield(explainabilityResults, 'userSpecificExplanations')
        userPreferences = explainabilityResults.userSpecificExplanations;
        userTypes = fieldnames(userPreferences);
        preferenceScores = zeros(length(userTypes), 1);
        
        for userIndex = 1:length(userTypes)
            preferenceScores(userIndex) = userPreferences.(userTypes{userIndex}).satisfactionScore;
        end
        
        bar(preferenceScores, 'FaceColor', [0.6, 0.9, 0.8], 'EdgeColor', 'darkgreen');
        set(gca, 'XTickLabel', userTypes);
        ylabel('Satisfaction Score', 'FontSize', 12);
        title('User-Specific Explanations', 'FontSize', 12, 'FontWeight', 'bold');
        xtickangle(45);
        ylim([0, 1]);
        grid on;
    end
    
    % Explanation validation results
    subplot(3, 4, 11);
    if isfield(explainabilityResults, 'explanationValidation')
        validationData = explainabilityResults.explanationValidation;
        validationMetrics = {'Accuracy', 'Precision', 'Recall', 'F1-Score'};
        validationScores = [validationData.accuracy, validationData.precision, ...
                           validationData.recall, validationData.f1Score];
        
        bar(validationScores, 'FaceColor', [0.8, 0.8, 0.4], 'EdgeColor', 'darkolivegreen');
        set(gca, 'XTickLabel', validationMetrics);
        ylabel('Validation Score', 'FontSize', 12);
        title('Explanation Validation', 'FontSize', 12, 'FontWeight', 'bold');
        ylim([0, 1]);
        grid on;
    end
    
    % Summary and recommendations
    subplot(3, 4, 12);
    axis off;
    
    summaryText = sprintf('Explainable AI Summary\n\n');
    summaryText = [summaryText, sprintf('Explanation Methods: %d\n', length(explanationMethods))];
    summaryText = [summaryText, sprintf('Test Samples: %d\n', size(testData.inputs, 1))];
    
    if isfield(explainabilityResults, 'explanationQuality')
        averageQuality = mean(cellfun(@(x) x.overallQuality, struct2cell(explainabilityResults.explanationQuality)));
        summaryText = [summaryText, sprintf('Average Quality: %.3f\n', averageQuality)];
    end
    
    if isfield(explainabilityResults, 'trustMetrics')
        trustData = explainabilityResults.trustMetrics;
        averageTrust = mean([trustData.consistency, trustData.fidelity, trustData.stability, trustData.comprehensibility]);
        summaryText = [summaryText, sprintf('Average Trust: %.3f\n', averageTrust)];
    end
    
    if isfield(explanations, 'CounterfactualExplanations')
        summaryText = [summaryText, sprintf('Counterfactual Success: %.1f%%\n', ...
            explanations.CounterfactualExplanations.successRate * 100)];
    end
    
    summaryText = [summaryText, sprintf('\nRecommended Method:\n')];
    if isfield(explainabilityResults, 'explanationQuality')
        [~, bestMethodIndex] = max(cellfun(@(x) x.overallQuality, struct2cell(explainabilityResults.explanationQuality)));
        bestMethod = qualityMethods{bestMethodIndex};
        summaryText = [summaryText, sprintf('%s\n', bestMethod)];
    end
    
    summaryText = [summaryText, sprintf('\nAnalysis Date: %s', string(explainabilityResults.timestamp))];
    
    text(0.05, 0.95, summaryText, 'FontSize', 11, 'VerticalAlignment', 'top', ...
        'HorizontalAlignment', 'left', 'Interpreter', 'none', 'FontWeight', 'bold');
    
    % Save visualisation in multiple formats
    saveas(gcf, 'ExplainableAIResults.fig');
    saveas(gcf, 'ExplainableAIResults.eps', 'epsc');
    saveas(gcf, 'ExplainableAIResults.jpg');
    
    fprintf('Explainable AI visualisation saved in multiple formats.\n');
end
