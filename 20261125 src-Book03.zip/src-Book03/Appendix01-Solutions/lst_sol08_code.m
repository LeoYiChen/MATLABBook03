%% lst_sol08_code.m
% Real-Time Spectrogram with Beat Detection (MATLABBook02_Chapter10_Problem08.m).
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : lst:sol08_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% MATLABBook02_Chapter10_Problem08.m
%  Real-Time Audio Spectrogram with Beat Detection
%  -------------------
%  Author       : Dr Leo Chen
%  Date         : 2024-01-20
%  Modified     : 2024-07-01
%  Version      : 1.2
%  MATLAB Ver.  : R2024a
%  Toolboxes    : Audio Toolbox, Signal Processing Toolbox
%  Description  :
%    Captures live audio, displays a scrolling spectrogram,
%    and detects beats using spectral flux.
%  Change Log   :
%    v1.0 - Initial release.
%    v1.1 - Added dynamic threshold for beat detection.
%    v1.2 - Improved scrolling buffer efficiency.
%  -------------------

%% Initialisation
clc; clear; close all;

%% --- User Parameters ------------
sampleRate       = 44100;
samplesPerFrame  = 1024;
nfftSize         = 2048;
displaySeconds   = 5;
thresholdMultiplier = 1.5;
totalRunSeconds  = 30;      % Duration of capture

%% --- Derived Constants ------------
numDisplayFrames = ceil( ...
    displaySeconds * sampleRate / samplesPerFrame);
freqAxis = linspace(0, sampleRate/2, nfftSize/2+1);

%% --- Set Up Audio Device ------------
deviceReader = audioDeviceReader( ...
    'SampleRate',      sampleRate, ...
    'SamplesPerFrame', samplesPerFrame);

%% --- Set Up Figure --------------
spectrogramBuffer = zeros(nfftSize/2+1, ...
                          numDisplayFrames);
figHandle = figure('Color', 'k', ...
    'Position', [100 100 900 500]);
imgHandle = imagesc( ...
    [0 displaySeconds], [0 sampleRate/2], ...
    10*log10(spectrogramBuffer + eps));
axis xy; colorbar; colormap('jet');
xlabel('Time (s)', 'Interpreter', 'latex', ...
       'Color', 'w');
ylabel('Frequency (Hz)', 'Interpreter', 'latex', ...
       'Color', 'w');
titleHandle = title( ...
    'Real-Time Spectrogram - No Beat', ...
    'Interpreter', 'latex', 'Color', 'w', ...
    'FontSize', 14);
set(gca, 'Color', 'k', 'XColor', 'w', ...
         'YColor', 'w');

%% --- Processing Loop ------------
prevMagnitude    = zeros(nfftSize/2+1, 1);
fluxHistory      = zeros(1, 50);
fluxWriteIndex   = 0;
frameCounter     = 0;
beatCount        = 0;
totalFrames      = ceil(totalRunSeconds * sampleRate ...
                        / samplesPerFrame);

analysisWindow = hann(samplesPerFrame, 'periodic');

for frameIdx = 1:totalFrames
    audioFrame = deviceReader();
    if size(audioFrame, 2) > 1
        audioFrame = mean(audioFrame, 2);
    end

    % Apply window and compute FFT
    windowedFrame = audioFrame .* analysisWindow;
    magnitudeSpectrum = abs( ...
        fft(windowedFrame, nfftSize));
    magnitudeSpectrum = ...
        magnitudeSpectrum(1:nfftSize/2+1);

    % Spectral flux (half-wave rectified)
    fluxValue = sum(max( ...
        magnitudeSpectrum - prevMagnitude, 0));
    prevMagnitude = magnitudeSpectrum;

    % Update flux history
    fluxWriteIndex = mod(fluxWriteIndex, 50) + 1;
    fluxHistory(fluxWriteIndex) = fluxValue;
    dynamicThreshold = mean(fluxHistory) * ...
                       thresholdMultiplier;

    % Beat detection
    isBeat = fluxValue > dynamicThreshold;
    if isBeat
        beatCount = beatCount + 1;
    end

    % Update scrolling buffer
    spectrogramBuffer = circshift( ...
        spectrogramBuffer, -1, 2);
    spectrogramBuffer(:, end) = magnitudeSpectrum;

    % Refresh display every 5 frames
    if mod(frameIdx, 5) == 0
        set(imgHandle, 'CData', ...
            10*log10(spectrogramBuffer + eps));

        if isBeat
            titleHandle.String = sprintf( ...
                'Real-Time Spectrogram - BEAT %d', ...
                beatCount);
            titleHandle.Color = [1 0.2 0.2];
        else
            titleHandle.String = ...
                'Real-Time Spectrogram - No Beat';
            titleHandle.Color = [1 1 1];
        end
        drawnow limitrate;
    end
end

%% --- Clean Up ---------------
release(deviceReader);
fprintf('Capture complete.\n');
fprintf('Total beats detected: %d\n', beatCount);
fprintf('Approx. tempo: %.1f BPM\n', ...
        beatCount / totalRunSeconds * 60);
