%% cnn_classification.m
% CNN Image Classification
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : cnn_classification
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Convolutional Neural Network for Image Classification
% Author: Dr Leo Chen
% Version: R2023b
% Date: November 2024

function cnn_image_classification()
% Set random seed for reproducibility
rng(404);

% Create synthetic image dataset
image_size = [64, 64, 3];
num_classes = 5;
samples_per_class = 200;
total_samples = num_classes * samples_per_class;

fprintf('Generating synthetic image dataset...\\n');
[image_data, image_labels] = create_synthetic_images(...
    image_size, num_classes, samples_per_class);

% Create imageDatastore and corresponding labels
image_datastore = arrayDatastore(image_data, 'IterationDimension', 4);
label_datastore = arrayDatastore(categorical(image_labels));

% Combine into a single datastore
combined_datastore = combine(image_datastore, label_datastore);

% Split data into training, validation, and test sets
train_ratio = 0.7;
validation_ratio = 0.15;
test_ratio = 0.15;

[train_ds, remaining_ds] = splitEachLabel(combined_datastore, train_ratio);
[validation_ds, test_ds] = splitEachLabel(remaining_ds, ...
    validation_ratio / (validation_ratio + test_ratio));

% Define CNN architecture
cnn_layers = [
    imageInputLayer(image_size, 'Name', 'input')
    
    % First convolutional block
    convolution2dLayer(5, 32, 'Padding', 'same', 'Name', 'conv1')
    batchNormalizationLayer('Name', 'bn1')
    reluLayer('Name', 'relu1')
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool1')
    
    % Second convolutional block
    convolution2dLayer(3, 64, 'Padding', 'same', 'Name', 'conv2')
    batchNormalizationLayer('Name', 'bn2')
    reluLayer('Name', 'relu2')
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool2')
    
    % Third convolutional block
    convolution2dLayer(3, 128, 'Padding', 'same', 'Name', 'conv3')
    batchNormalizationLayer('Name', 'bn3')
    reluLayer('Name', 'relu3')
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool3')
    
    % Fully connected layers
    fullyConnectedLayer(256, 'Name', 'fc1')
    reluLayer('Name', 'relu4')
    dropoutLayer(0.5, 'Name', 'dropout1')
    
    fullyConnectedLayer(128, 'Name', 'fc2')
    reluLayer('Name', 'relu5')
    dropoutLayer(0.3, 'Name', 'dropout2')
    
    fullyConnectedLayer(num_classes, 'Name', 'fc3')
    softmaxLayer('Name', 'softmax')
    classificationLayer('Name', 'output')
];

% Data augmentation
augmenter = imageDataAugmenter(...
    'RandRotation', [-20, 20], ...
    'RandXTranslation', [-5, 5], ...
    'RandYTranslation', [-5, 5], ...
    'RandXScale', [0.9, 1.1], ...
    'RandYScale', [0.9, 1.1], ...
    'RandXReflection', true);

% Apply augmentation to training data
augmented_train_ds = transform(train_ds, @(data) augment_image_data(data, augmenter));

% Configure training options
training_options = trainingOptions('adam', ...
    'InitialLearnRate', 0.001, ...
    'MaxEpochs', 50, ...
    'MiniBatchSize', 32, ...
    'ValidationData', validation_ds, ...
    'ValidationFrequency', 30, ...
    'ValidationPatience', 10, ...
    'Shuffle', 'every-epoch', ...
    'Plots', 'training-progress', ...
    'Verbose', false, ...
    'L2Regularization', 0.0001);

% Train the CNN
fprintf('Training CNN...\\n');
[trained_cnn, training_info] = trainNetwork(augmented_train_ds, ...
    cnn_layers, training_options);

% Evaluate on test set
fprintf('Evaluating CNN performance...\\n');
test_predictions = classify(trained_cnn, test_ds);

% Extract true labels from test datastore
test_labels_cell = readall(test_ds);
test_true_labels = categorical(cellfun(@(x) x{2}, test_labels_cell));

% Calculate performance metrics
test_accuracy = sum(test_predictions == test_true_labels) / ...
    length(test_true_labels) * 100;

% Confusion matrix and per-class metrics
confusion_matrix = confusionmat(test_true_labels, test_predictions);

% Calculate precision, recall, and F1-score for each class
num_test_classes = length(categories(test_true_labels));
precision_scores = zeros(num_test_classes, 1);
recall_scores = zeros(num_test_classes, 1);
f1_scores = zeros(num_test_classes, 1);

for class_idx = 1:num_test_classes
    tp = confusion_matrix(class_idx, class_idx);
    fp = sum(confusion_matrix(:, class_idx)) - tp;
    fn = sum(confusion_matrix(class_idx, :)) - tp;
    
    precision_scores(class_idx) = tp / (tp + fp);
    recall_scores(class_idx) = tp / (tp + fn);
    f1_scores(class_idx) = 2 * precision_scores(class_idx) * ...
        recall_scores(class_idx) / (precision_scores(class_idx) + ...
        recall_scores(class_idx));
end

% Feature visualisation - extract feature maps
sample_image = image_data(:, :, :, 1);
feature_maps_conv1 = activations(trained_cnn, sample_image, 'conv1');
feature_maps_conv2 = activations(trained_cnn, sample_image, 'conv2');
feature_maps_conv3 = activations(trained_cnn, sample_image, 'conv3');

% Visualisation
figure('Name', 'CNN Training and Performance Results');

% Training progress
subplot(2, 4, 1);
plot(training_info.TrainingAccuracy, 'b-', 'LineWidth', 2);
hold on;
if isfield(training_info, 'ValidationAccuracy')
    plot(training_info.ValidationAccuracy, 'r-', 'LineWidth', 2);
    legend('Training', 'Validation', 'Location', 'best');
end
xlabel('Epoch', 'Interpreter', 'latex');
ylabel('Accuracy', 'Interpreter', 'latex');
title('Training Progress', 'Interpreter', 'latex');
grid on;

% Training loss
subplot(2, 4, 2);
plot(training_info.TrainingLoss, 'b-', 'LineWidth', 2);
hold on;
if isfield(training_info, 'ValidationLoss')
    plot(training_info.ValidationLoss, 'r-', 'LineWidth', 2);
    legend('Training', 'Validation', 'Location', 'best');
end
xlabel('Epoch', 'Interpreter', 'latex');
ylabel('Loss', 'Interpreter', 'latex');
title('Training Loss', 'Interpreter', 'latex');
grid on;

% Confusion matrix
subplot(2, 4, 3);
imagesc(confusion_matrix);
colorbar;
xlabel('Predicted Class', 'Interpreter', 'latex');
ylabel('True Class', 'Interpreter', 'latex');
title('Confusion Matrix', 'Interpreter', 'latex');

% Add numerical values to confusion matrix
for row = 1:size(confusion_matrix, 1)
    for col = 1:size(confusion_matrix, 2)
        text(col, row, num2str(confusion_matrix(row, col)), ...
            'HorizontalAlignment', 'center', 'Color', 'white', ...
            'FontWeight', 'bold');
    end
end

% Per-class performance
subplot(2, 4, 4);
class_metrics = [precision_scores, recall_scores, f1_scores];
bar(class_metrics);
xlabel('Class', 'Interpreter', 'latex');
ylabel('Score', 'Interpreter', 'latex');
title('Per-Class Performance', 'Interpreter', 'latex');
legend('Precision', 'Recall', 'F1-Score', 'Location', 'best');
ylim([0, 1]);

% Feature maps visualisation
subplot(2, 4, 5);
imshow(sample_image);
title('Original Image', 'Interpreter', 'latex');

subplot(2, 4, 6);
montage(feature_maps_conv1(:, :, 1:16), 'Size', [4, 4]);
title('Conv1 Feature Maps', 'Interpreter', 'latex');

subplot(2, 4, 7);
montage(feature_maps_conv2(:, :, 1:16), 'Size', [4, 4]);
title('Conv2 Feature Maps', 'Interpreter', 'latex');

subplot(2, 4, 8);
montage(feature_maps_conv3(:, :, 1:16), 'Size', [4, 4]);
title('Conv3 Feature Maps', 'Interpreter', 'latex');

% Model analysis
layer_info = analyzeNetwork(trained_cnn);
num_parameters = sum([layer_info.Learnable.Parameters]);

% Display comprehensive results
fprintf('\\n\\textbf{CNN Classification Results}:\\n');
fprintf('Test Accuracy: %.2f%%\\n', test_accuracy);
fprintf('Number of Parameters: %d\\n', num_parameters);
fprintf('Training Epochs: %d\\n', length(training_info.TrainingAccuracy));
fprintf('Final Training Accuracy: %.2f%%\\n', training_info.TrainingAccuracy(end));

if isfield(training_info, 'ValidationAccuracy')
    fprintf('Final Validation Accuracy: %.2f%%\\n', ...
        training_info.ValidationAccuracy(end));
end

fprintf('\\n\\textbf{Per-Class Performance}:\\n');
class_names = categories(test_true_labels);
for class_idx = 1:num_test_classes
    fprintf('Class %s - Precision: %.3f, Recall: %.3f, F1: %.3f\\n', ...
        class_names{class_idx}, precision_scores(class_idx), ...
        recall_scores(class_idx), f1_scores(class_idx));
end

% Calculate macro and weighted averages
macro_precision = mean(precision_scores);
macro_recall = mean(recall_scores);
macro_f1 = mean(f1_scores);

class_counts = sum(confusion_matrix, 2);
weighted_precision = sum(precision_scores .* class_counts) / sum(class_counts);
weighted_recall = sum(recall_scores .* class_counts) / sum(class_counts);
weighted_f1 = sum(f1_scores .* class_counts) / sum(class_counts);

fprintf('\\n\\textbf{Overall Performance}:\\n');
fprintf('Macro Precision: %.3f\\n', macro_precision);
fprintf('Macro Recall: %.3f\\n', macro_recall);
fprintf('Macro F1-Score: %.3f\\n', macro_f1);
fprintf('Weighted Precision: %.3f\\n', weighted_precision);
fprintf('Weighted Recall: %.3f\\n', weighted_recall);
fprintf('Weighted F1-Score: %.3f\\n', weighted_f1);

end

function [images, labels] = create_synthetic_images(image_size, num_classes, samples_per_class)
% Create synthetic image dataset with different patterns

total_samples = num_classes * samples_per_class;
images = zeros([image_size, total_samples]);
labels = zeros(total_samples, 1);

sample_idx = 1;

for class_idx = 1:num_classes
    for sample = 1:samples_per_class
        % Create base image with noise
        current_image = 0.1 * randn(image_size);
        
        switch class_idx
            case 1 % Circular patterns
                [x, y] = meshgrid(1:image_size(2), 1:image_size(1));
                center_x = image_size(2)/2 + 10*randn();
                center_y = image_size(1)/2 + 10*randn();
                radius = 15 + 5*randn();
                circle_mask = (x - center_x).^2 + (y - center_y).^2 < radius^2;
                current_image(circle_mask) = current_image(circle_mask) + 0.8;
                
            case 2 % Square patterns
                square_size = 20 + randi(10);
                start_x = randi(image_size(2) - square_size);
                start_y = randi(image_size(1) - square_size);
                current_image(start_y:start_y+square_size, start_x:start_x+square_size, :) = ...
                    current_image(start_y:start_y+square_size, start_x:start_x+square_size, :) + 0.8;
                
            case 3 % Line patterns
                for line = 1:3
                    start_point = [randi(image_size(1)), randi(image_size(2))];
                    end_point = [randi(image_size(1)), randi(image_size(2))];
                    current_image = insertShape(current_image, 'Line', ...
                        [start_point, end_point], 'Color', 'white', 'LineWidth', 3);
                end
                
            case 4 % Diagonal patterns
                for diag = 1:image_size(1)
                    if mod(diag, 8) < 4
                        current_image(diag, :, :) = current_image(diag, :, :) + 0.5;
                    end
                end
                
            case 5 % Random blob patterns
                num_blobs = 3 + randi(3);
                for blob = 1:num_blobs
                    blob_center = [randi(image_size(1)), randi(image_size(2))];
                    blob_size = 5 + randi(10);
                    [x, y] = meshgrid(1:image_size(2), 1:image_size(1));
                    blob_mask = (x - blob_center(2)).^2 + (y - blob_center(1)).^2 < blob_size^2;
                    current_image(blob_mask) = current_image(blob_mask) + 0.6;
                end
        end
        
        % Normalise and add to dataset
        current_image = mat2gray(current_image);
        images(:, :, :, sample_idx) = current_image;
        labels(sample_idx) = class_idx;
        sample_idx = sample_idx + 1;
    end
end

end

function augmented_data = augment_image_data(data, augmenter)
% Apply data augmentation to image data
image = data{1};
label = data{2};

augmented_image = augment(augmenter, image);
augmented_data = {augmented_image, label};

end
