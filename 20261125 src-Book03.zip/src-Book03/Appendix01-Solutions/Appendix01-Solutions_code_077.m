%% Appendix01-Solutions_code_077.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [query_indices, uncertainties] = selectUncertainInstances(predictions, budget)
    % predictions: N x 3 matrix of class probabilities
    % budget: number of instances to query
    
    % Calculate entropy-based uncertainty
    epsilon = 1e-10; % Avoid log(0)
    entropies = -sum(predictions .* log(predictions + epsilon), 2);
    
    % Select top uncertain instances
    [~, sorted_idx] = sort(entropies, 'descend');
    query_indices = sorted_idx(1:min(budget, length(sorted_idx)));
    uncertainties = entropies(query_indices);
end
