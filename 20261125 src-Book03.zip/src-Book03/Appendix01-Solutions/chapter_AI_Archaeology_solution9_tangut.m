%% chapter_AI_Archaeology_solution9_tangut.m
% Comprehensive Tangut Script AI Analysis System.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AI_Archaeology_solution9_tangut
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [tangutAnalysis, culturalInsights] = analyseTangutScript(manuscriptPath, dictionaryPath, outputDir)
%% Comprehensive Tangut Script AI Analysis System
% Author: Dr Leo Chen
% Version: 2.3.0
% Date: January 2025
% Purpose: AI-enhanced analysis of Tangut script and Western Xia culture
% Input: Tangut manuscript images, character dictionary, output directory
% Output: Script analysis results and cultural insights

fprintf('\\textbf{Tangut Script AI Analysis System}\\n');
fprintf('Western Xia Dynasty (1038-1227 CE), Northwestern China\\n');
fprintf('Archaeological Sites: Khara-Khoto, Dunhuang, Heishui City\\n');
fprintf('Discovery: Aurel Stein expedition (1907), Kozlov expedition (1908)\\n\\n');

%% Load Tangut Manuscript Collections
manuscriptDS = imageDatastore(manuscriptPath, 'IncludeSubfolders', true, ...
    'FileExtensions', {'.jpg', '.tif', '.png'});
numManuscripts = length(manuscriptDS.Files);

fprintf('Loaded Tangut manuscript collection: %d digitised documents\\n', numManuscripts);

%% Load Tangut Character Dictionary and Reference Materials
tangutDictionary = readtable(dictionaryPath);
knownCharacters = height(tangutDictionary);

% Load comparative Buddhist text corpora
chineseBuddhistCorpus = loadBuddhistTextCorpus('chinese_tripitaka.txt');
tibetanBuddhistCorpus = loadBuddhistTextCorpus('tibetan_kangyur.txt');

fprintf('Reference materials loaded: %d known Tangut characters\\n', knownCharacters);
fprintf('Comparative corpora: Chinese and Tibetan Buddhist canons\\n');

%% Advanced Character Recognition Using Deep Learning
fprintf('\\textbf{Performing Deep Learning Character Recognition}\\n');

% Preprocess manuscript images
preprocessedImages = cell(numManuscripts, 1);
for imgIdx = 1:numManuscripts
    originalImage = readimage(manuscriptDS, imgIdx);
    
    % Image enhancement for character visibility
    if size(originalImage, 3) == 3
        greyImage = rgb2gray(originalImage);
    else
        greyImage = originalImage;
    end
    
    % Adaptive histogram equalisation
    enhancedImage = adapthisteq(greyImage, 'ClipLimit', 0.02);
    
    % Noise reduction while preserving character details
    filteredImage = medfilt2(enhancedImage, [3, 3]);
    
    preprocessedImages{imgIdx} = filteredImage;
end

% Character segmentation and recognition
recognisedCharacters = cell(numManuscripts, 1);
characterConfidences = cell(numManuscripts, 1);

for imgIdx = 1:numManuscripts
    % Segment individual characters using connected component analysis
    characterRegions = segmentTangutCharacters(preprocessedImages{imgIdx});
    
    % Recognise each character using trained CNN
    [charRecognition, charConfidence] = recogniseCharacters(characterRegions, tangutDictionary);
    
    recognisedCharacters{imgIdx} = charRecognition;
    characterConfidences{imgIdx} = charConfidence;
end

fprintf('Character recognition complete: Average confidence %.2f\\n', mean(cell2mat(characterConfidences)));

%% Linguistic Pattern Analysis
fprintf('\\textbf{Analysing Tangut Linguistic Patterns}\\n');

% Combine all recognised text for corpus analysis
combinedTangutCorpus = [];
for imgIdx = 1:numManuscripts
    combinedTangutCorpus = [combinedTangutCorpus; recognisedCharacters{imgIdx}];
end

% Character frequency analysis
characterFrequencies = calculateCharacterFrequencies(combinedTangutCorpus);
[frequentCharacters, frequencyOrder] = sort(characterFrequencies, 'descend');

% Identify potential grammatical particles and function words
functionWords = identifyFunctionWords(characterFrequencies, tangutDictionary);

% Analyse character combination patterns
bigramAnalysis = analyseBigramPatterns(combinedTangutCorpus);
trigramAnalysis = analyseTrigramPatterns(combinedTangutCorpus);

% Phonological analysis using comparative linguistics
phoneticPatterns = inferPhonologicalPatterns(combinedTangutCorpus, chineseBuddhistCorpus, tibetanBuddhistCorpus);

fprintf('Linguistic analysis: %d unique characters, %d function words identified\\n', ...
    length(unique(combinedTangutCorpus)), length(functionWords));

%% Buddhist Text Analysis and Cross-Linguistic Comparison
fprintf('\\textbf{Comparing with Buddhist Source Texts}\\n');

% Identify Buddhist terminology in Tangut corpus
buddhistTerminology = identifyBuddhistTerms(combinedTangutCorpus, chineseBuddhistCorpus, tibetanBuddhistCorpus);

% Analyse translation patterns between languages
translationPatterns = analyseTranslationPatterns(buddhistTerminology);

% Identify unique Tangut Buddhist concepts
uniqueTangutConcepts = identifyUniqueConcepts(buddhistTerminology, translationPatterns);

% Cultural adaptation analysis
culturalAdaptations = analyseCulturalAdaptations(uniqueTangutConcepts, translationPatterns);

fprintf('Buddhist analysis: %d Buddhist terms identified, %d unique Tangut adaptations\\n', ...
    length(buddhistTerminology), length(uniqueTangutConcepts));

%% Character Dictionary Expansion Using AI
fprintf('\\textbf{Expanding Character Dictionary Through AI Analysis}\\n');

% Identify unrecognised character variants
unrecognisedVariants = identifyCharacterVariants(recognisedCharacters, characterConfidences, tangutDictionary);

% Cluster similar characters for variant analysis
characterClusters = clusterSimilarCharacters(unrecognisedVariants);

% Generate new character entries using pattern recognition
newCharacterEntries = generateNewDictionaryEntries(characterClusters, phoneticPatterns);

% Validate new entries through contextual analysis
validatedEntries = validateNewEntries(newCharacterEntries, combinedTangutCorpus);

expandedDictionary = [tangutDictionary; validatedEntries];

fprintf('Dictionary expansion: %d new character variants identified and validated\\n', height(validatedEntries));

%% Silk Road Cultural Exchange Analysis
fprintf('\\textbf{Analysing Silk Road Cultural Exchange Patterns}\\n');

% Identify loanwords and foreign cultural concepts
loanwordAnalysis = identifyLoanwords(combinedTangutCorpus, chineseBuddhistCorpus, tibetanBuddhistCorpus);

% Analyse cultural terminology evolution
culturalTerminology = analyseCulturalTerminology(loanwordAnalysis, translationPatterns);

% Map cultural influence networks
culturalInfluenceNetworks = mapCulturalInfluence(culturalTerminology, culturalAdaptations);

% Temporal analysis of cultural exchange
temporalExchange = analyseTemporalCulturalExchange(culturalInfluenceNetworks);

fprintf('Cultural exchange analysis: %d loanwords, %d cultural adaptation patterns\\n', ...
    length(loanwordAnalysis), length(culturalAdaptations));

%% Comprehensive Visualisation and Analysis
figure('Position', [50, 50, 1800, 1200]);

% Character frequency distribution
subplot(2, 4, 1);
loglog(1:min(100, length(frequentCharacters)), frequentCharacters(1:min(100, length(frequentCharacters))));
xlabel('Character Rank');
ylabel('Frequency (log scale)');
title('\\textbf{Tangut Character Frequency Distribution}');
grid on;

% Recognition confidence distribution
subplot(2, 4, 2);
allConfidences = cell2mat(characterConfidences);
histogram(allConfidences, 30, 'FaceAlpha', 0.7);
xlabel('Recognition Confidence');
ylabel('Number of Characters');
title('\\textbf{Character Recognition Confidence}');
xline(0.8, 'r--', 'High Confidence Threshold', 'LineWidth', 2);
grid on;

% Buddhist terminology analysis
subplot(2, 4, 3);
buddhistCategories = {'Doctrinal', 'Ritual', 'Monastic', 'Philosophical'};
categoryCounts = [length(buddhistTerminology)*0.4, length(buddhistTerminology)*0.3, ...
                 length(buddhistTerminology)*0.2, length(buddhistTerminology)*0.1];
pie(categoryCounts, buddhistCategories);
title('\\textbf{Buddhist Terminology Categories}');

% Character variant clustering
subplot(2, 4, 4);
if ~isempty(characterClusters)
    scatter(characterClusters.x, characterClusters.y, 50, characterClusters.cluster, 'filled');
    xlabel('Visual Similarity Dimension 1');
    ylabel('Visual Similarity Dimension 2');
    title('\\textbf{Character Variant Clustering}');
    colormap('lines');
    colorbar;
end
grid on;

% Cultural exchange network
subplot(2, 4, 5);
if ~isempty(culturalInfluenceNetworks)
    plotCulturalInfluenceNetwork(culturalInfluenceNetworks);
end
title('\\textbf{Silk Road Cultural Exchange Network}');

% Dictionary expansion timeline
subplot(2, 4, 6);
expansionStages = {'Original Dictionary', 'Variant Recognition', 'AI Enhancement', 'Validation'};
dictionarySizes = [knownCharacters, knownCharacters + length(unrecognisedVariants)*0.7, ...
                  knownCharacters + length(newCharacterEntries), height(expandedDictionary)];
bar(dictionarySizes);
set(gca, 'XTickLabel', expansionStages, 'XTickLabelRotation', 45);
ylabel('Dictionary Size');
title('\\textbf{Dictionary Expansion Progress}');
grid on;

% Phonological pattern analysis
subplot(2, 4, 7);
if ~isempty(phoneticPatterns)
    phoneticCategories = fieldnames(phoneticPatterns);
    phoneticCounts = zeros(1, length(phoneticCategories));
    for i = 1:length(phoneticCategories)
        phoneticCounts(i) = length(phoneticPatterns.(phoneticCategories{i}));
    end
    bar(phoneticCounts);
    set(gca, 'XTickLabel', phoneticCategories, 'XTickLabelRotation', 45);
    ylabel('Pattern Count');
    title('\\textbf{Phonological Pattern Analysis}');
end
grid on;

% Analysis summary
subplot(2, 4, 8);
text(0.1, 0.9, '\\textbf{Tangut Analysis Summary}', 'Units', 'normalized', 'FontSize', 12, 'FontWeight', 'bold');
text(0.1, 0.8, sprintf('Manuscripts processed: %d', numManuscripts), 'Units', 'normalized');
text(0.1, 0.7, sprintf('Characters recognised: %d unique', length(unique(combinedTangutCorpus))), 'Units', 'normalized');
text(0.1, 0.6, sprintf('Dictionary expansion: +%d entries', height(validatedEntries)), 'Units', 'normalized');
text(0.1, 0.5, sprintf('Buddhist terms: %d identified', length(buddhistTerminology)), 'Units', 'normalized');
text(0.1, 0.4, sprintf('Cultural adaptations: %d patterns', length(culturalAdaptations)), 'Units', 'normalized');
text(0.1, 0.3, sprintf('Average recognition: %.1f\\%% confidence', mean(allConfidences)*100), 'Units', 'normalized');
text(0.1, 0.2, 'Status: Advanced analysis complete', 'Units', 'normalized', 'Color', 'green');
axis off;

%% Compile Analysis Results
tangutAnalysis = struct();
tangutAnalysis.characterRecognition = struct();
tangutAnalysis.characterRecognition.recognised = recognisedCharacters;
tangutAnalysis.characterRecognition.confidences = characterConfidences;
tangutAnalysis.characterRecognition.frequencies = characterFrequencies;

tangutAnalysis.linguisticAnalysis = struct();
tangutAnalysis.linguisticAnalysis.functionWords = functionWords;
tangutAnalysis.linguisticAnalysis.phoneticPatterns = phoneticPatterns;
tangutAnalysis.linguisticAnalysis.bigramAnalysis = bigramAnalysis;

tangutAnalysis.dictionaryExpansion = struct();
tangutAnalysis.dictionaryExpansion.originalSize = knownCharacters;
tangutAnalysis.dictionaryExpansion.expandedDictionary = expandedDictionary;
tangutAnalysis.dictionaryExpansion.newEntries = validatedEntries;

culturalInsights = struct();
culturalInsights.buddhistAnalysis = struct();
culturalInsights.buddhistAnalysis.terminology = buddhistTerminology;
culturalInsights.buddhistAnalysis.uniqueConcepts = uniqueTangutConcepts;
culturalInsights.buddhistAnalysis.culturalAdaptations = culturalAdaptations;

culturalInsights.silkRoadExchange = struct();
culturalInsights.silkRoadExchange.loanwords = loanwordAnalysis;
culturalInsights.silkRoadExchange.culturalNetworks = culturalInfluenceNetworks;
culturalInsights.silkRoadExchange.temporalPatterns = temporalExchange;

%% Generate Comprehensive Research Report
if nargin > 2 && ~isempty(outputDir)
    % Save analysis results
    resultsFile = fullfile(outputDir, 'tangut_script_analysis.mat');
    save(resultsFile, 'tangutAnalysis', 'culturalInsights');
    
    % Generate scholarly research report
    researchReport = fullfile(outputDir, 'tangut_research_report.pdf');
    generateTangutResearchReport(tangutAnalysis, culturalInsights, researchReport);
    
    % Export expanded dictionary
    dictionaryFile = fullfile(outputDir, 'expanded_tangut_dictionary.csv');
    writetable(expandedDictionary, dictionaryFile);
    
    fprintf('Analysis results saved to: %s\\n', resultsFile);
    fprintf('Research report generated: %s\\n', researchReport);
    fprintf('Expanded dictionary exported: %s\\n', dictionaryFile);
end

fprintf('\\n\\textbf{Tangut Script AI Analysis Complete}\\n');
fprintf('Western Xia cultural heritage: %d manuscripts analysed\\n', numManuscripts);
fprintf('Character recognition: %.1f\\%% average confidence\\n', mean(allConfidences)*100);
fprintf('Dictionary enhancement: %d new validated entries\\n', height(validatedEntries));
fprintf('Buddhist scholarship: Advanced comparative analysis completed\\n');

%% Helper Functions for Tangut Script Analysis
    function regions = segmentTangutCharacters(image)
        % Segment individual Tangut characters from manuscript images
        binaryImage = imbinarize(image, 'adaptive');
        regions = bwconncomp(~binaryImage, 8);
        regions = regionprops(regions, 'BoundingBox', 'Area');
        % Filter by size to remove noise and select character-sized regions
        minArea = 100; maxArea = 2000;
        validRegions = [regions.Area] >= minArea & [regions.Area] <= maxArea;
        regions = regions(validRegions);
    end

    function [recognition, confidence] = recogniseCharacters(regions, dictionary)
        % Recognise Tangut characters using trained CNN model
        numRegions = length(regions);
        recognition = cell(numRegions, 1);
        confidence = zeros(numRegions, 1);
        
        for i = 1:numRegions
            % Simplified recognition - in practice would use trained CNN
            recognition{i} = dictionary.Character{randi(height(dictionary))};
            confidence(i) = 0.7 + 0.3 * rand(); % Simulated confidence
        end
    end

    function frequencies = calculateCharacterFrequencies(corpus)
        % Calculate frequency distribution of Tangut characters
        [uniqueChars, ~, indices] = unique(corpus);
        frequencies = accumarray(indices, 1);
        [frequencies, sortOrder] = sort(frequencies, 'descend');
        uniqueChars = uniqueChars(sortOrder);
    end

    function functionWords = identifyFunctionWords(frequencies, dictionary)
        % Identify potential function words based on frequency patterns
        highFreqThreshold = prctile(frequencies, 90);
        functionWords = dictionary.Character(frequencies > highFreqThreshold);
    end

    function terms = identifyBuddhistTerms(corpus, chineseCorpus, tibetanCorpus)
        % Identify Buddhist terminology through cross-linguistic comparison
        terms = cell(100, 1); % Simplified - would use sophisticated matching
        for i = 1:100
            terms{i} = sprintf('Buddhist_term_%d', i);
        end
    end

    function corpus = loadBuddhistTextCorpus(filename)
        % Load Buddhist text corpus for comparative analysis
        corpus = struct('texts', {{'text1', 'text2'}}, 'terms', {{'term1', 'term2'}});
    end

    function plotCulturalInfluenceNetwork(networks)
        % Plot cultural influence network diagram
        % Simplified visualisation
        x = rand(10, 1);
        y = rand(10, 1);
        scatter(x, y, 100, 'filled');
        for i = 1:5
            line([x(i), x(i+5)], [y(i), y(i+5)], 'LineWidth', 2);
        end
        xlabel('Cultural Dimension 1');
        ylabel('Cultural Dimension 2');
    end

    function generateTangutResearchReport(analysis, insights, filename)
        % Generate comprehensive Tangut research report
        fprintf('Generating Tangut research report: %s\\n', filename);
    end

end
