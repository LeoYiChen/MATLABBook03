%% chapter_AICSS_problem3_reliability.m
% Comprehensive reliability assessment framework.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AICSS_problem3_reliability
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function reliabilityResults = assessSystemReliability(failureData, operationalTime, requirements, analysisOptions)
    % Comprehensive reliability assessment using advanced statistical methods
    % Author: Dr Leo Chen
    % Version: 1.0 - Initial implementation
    % Date: December 2024
    
    fprintf('Executing comprehensive reliability assessment...\n');
    
    % Initialize results structure
    reliabilityResults = struct();
    reliabilityResults.timestamp = datetime('now');
    reliabilityResults.analysisOptions = analysisOptions;
    reliabilityResults.requirements = requirements;
    
    % Probability of Failure on Demand (PFD) calculation
    pfdResults = calculatePFDWithConfidenceIntervals(failureData, analysisOptions);
    reliabilityResults.pfd = pfdResults;
    
    % Mean Time Between Failures (MTBF) calculation
    mtbfResults = calculateMTBFWithStatisticalAnalysis(failureData, analysisOptions);
    reliabilityResults.mtbf = mtbfResults;
    
    % Mean Time To Repair (MTTR) if repair data available
    if isfield(failureData, 'repairTimes') && ~isempty(failureData.repairTimes)
        mttrResults = calculateMTTRWithAnalysis(failureData.repairTimes, analysisOptions);
        reliabilityResults.mttr = mttrResults;
        
        % Availability calculation
        availabilityResults = calculateSystemAvailability(mtbfResults.mtbfEstimate, mttrResults.mttrEstimate);
        reliabilityResults.availability = availabilityResults;
    end
    
    % Weibull distribution analysis
    weibullResults = performWeibullAnalysis(failureData, analysisOptions);
    reliabilityResults.weibull = weibullResults;
    
    % Reliability function calculation
    reliabilityFunction = calculateReliabilityFunction(weibullResults, operationalTime);
    reliabilityResults.reliabilityFunction = reliabilityFunction;
    
    % Compliance assessment against requirements
    complianceResults = assessReliabilityCompliance(reliabilityResults, requirements);
    reliabilityResults.compliance = complianceResults;
    
    % Generate comprehensive visualisation
    generateReliabilityvisualisation(reliabilityResults, analysisOptions);
    
    % Uncertainty quantification
    uncertaintyResults = quantifyReliabilityUncertainty(reliabilityResults, analysisOptions);
    reliabilityResults.uncertainty = uncertaintyResults;
    
    % Save results
    saveReliabilityResults(reliabilityResults);
    
    fprintf('Reliability assessment completed.\n');
    fprintf('PFD: %.2e, MTBF: %.1f hours\n', pfdResults.estimatedPFD, mtbfResults.mtbfEstimate);
end

function pfdResults = calculatePFDWithConfidenceIntervals(failureData, options)
    % Calculate PFD with statistical confidence intervals
    
    pfdResults = struct();
    
    if isfield(failureData, 'totalDemands') && isfield(failureData, 'failuresOnDemand')
        totalDemands = sum(failureData.totalDemands);
        totalFailures = sum(failureData.failuresOnDemand);
        
        % Calculate observed PFD
        pfdResults.estimatedPFD = totalFailures / totalDemands;
        
        % Calculate confidence interval using binomial distribution
        confidenceLevel = options.confidenceLevel;
        [pfdLower, pfdUpper] = binofit(totalFailures, totalDemands, 1-confidenceLevel);
        pfdResults.confidenceInterval = [pfdLower, pfdUpper];
        pfdResults.confidenceLevel = confidenceLevel;
        
        % Bayesian PFD estimation with prior
        if isfield(options, 'bayesianPrior') && options.bayesianPrior
            bayesianResults = calculateBayesianPFD(totalFailures, totalDemands, options);
            pfdResults.bayesian = bayesianResults;
        end
        
    else
        fprintf('Warning: Insufficient demand-based failure data for PFD calculation\n');
        pfdResults.estimatedPFD = NaN;
        pfdResults.confidenceInterval = [NaN, NaN];
    end
    
    pfdResults.calculationMethod = 'binomial_confidence_interval';
    pfdResults.calculationTimestamp = datetime('now');
end

function mtbfResults = calculateMTBFWithStatisticalAnalysis(failureData, options)
    % Calculate MTBF with comprehensive statistical analysis
    
    mtbfResults = struct();
    
    if isfield(failureData, 'failureTimes') && length(failureData.failureTimes) > 1
        failureTimes = sort(failureData.failureTimes);
        timeBetweenFailures = diff(failureTimes);
        
        % Calculate basic MTBF statistics
        mtbfResults.mtbfEstimate = mean(timeBetweenFailures);
        mtbfResults.mtbfStandardDeviation = std(timeBetweenFailures);
        mtbfResults.numberOfIntervals = length(timeBetweenFailures);
        
        % Calculate confidence interval using t-distribution
        confidenceLevel = options.confidenceLevel;
        alpha = 1 - confidenceLevel;
        degreesOfFreedom = length(timeBetweenFailures) - 1;
        tCritical = tinv(1 - alpha/2, degreesOfFreedom);
        marginOfError = tCritical * mtbfResults.mtbfStandardDeviation / sqrt(length(timeBetweenFailures));
        
        mtbfResults.confidenceInterval = [mtbfResults.mtbfEstimate - marginOfError, ...
                                         mtbfResults.mtbfEstimate + marginOfError];
        
        % Failure rate calculation
        mtbfResults.failureRate = 1 / mtbfResults.mtbfEstimate;
        mtbfResults.failureRateConfidenceInterval = [1/mtbfResults.confidenceInterval(2), ...
                                                    1/mtbfResults.confidenceInterval(1)];
        
        % Test for exponential distribution assumption
        exponentialityTest = performExponentialityTest(timeBetweenFailures);
        mtbfResults.exponentialityTest = exponentialityTest;
        
    else
        fprintf('Warning: Insufficient failure time data for MTBF calculation\n');
        mtbfResults.mtbfEstimate = NaN;
        mtbfResults.confidenceInterval = [NaN, NaN];
    end
    
    mtbfResults.calculationMethod = 't_distribution_confidence_interval';
    mtbfResults.calculationTimestamp = datetime('now');
end

function weibullResults = performWeibullAnalysis(failureData, options)
    % Perform comprehensive Weibull distribution analysis
    
    weibullResults = struct();
    
    if isfield(failureData, 'failureTimes') && length(failureData.failureTimes) > 5
        failureTimesData = sort(failureData.failureTimes);
        
        try
            % Fit Weibull distribution using MATLAB's fitdist function
            weibullDistribution = fitdist(failureTimesData, 'Weibull');
            
            % Extract distribution parameters
            weibullResults.scaleParameter = weibullDistribution.A;
            weibullResults.shapeParameter = weibullDistribution.B;
            weibullResults.distributionObject = weibullDistribution;
            
            % Parameter confidence intervals
            parameterCI = paramci(weibullDistribution);
            weibullResults.parameterConfidenceIntervals = parameterCI;
            
            % Goodness of fit assessment using Kolmogorov-Smirnov test
            [kolmogorovSmirnovTest, kolmogorovSmirnovPValue] = kstest(failureTimesData, ...
                'CDF', weibullDistribution);
            weibullResults.kolmogorovSmirnovTest = kolmogorovSmirnovTest;
            weibullResults.kolmogorovSmirnovPValue = kolmogorovSmirnovPValue;
            
            % Anderson-Darling test for better fit assessment
            andersonDarlingTest = performAndersonDarlingTest(failureTimesData, weibullDistribution);
            weibullResults.andersonDarlingTest = andersonDarlingTest;
            
            % Calculate reliability metrics
            weibullResults.characteristicLife = weibullResults.scaleParameter;
            weibullResults.meanTimeToFailure = weibullResults.scaleParameter * ...
                gamma(1 + 1/weibullResults.shapeParameter);
            
            % Reliability function
            timePoints = linspace(0, max(failureTimesData), 100);
            reliabilityFunction = 1 - cdf(weibullDistribution, timePoints);
            weibullResults.timePoints = timePoints;
            weibullResults.reliabilityFunction = reliabilityFunction;
            
            % Hazard function
            hazardFunction = pdf(weibullDistribution, timePoints) ./ reliabilityFunction;
            weibullResults.hazardFunction = hazardFunction;
            
        catch distributionFittingError
            fprintf('Warning: Weibull distribution fitting failed: %s\n', distributionFittingError.message);
            weibullResults.scaleParameter = NaN;
            weibullResults.shapeParameter = NaN;
            weibullResults.fittingStatus = 'failed';
        end
        
    else
        weibullResults.scaleParameter = NaN;
        weibullResults.shapeParameter = NaN;
        weibullResults.fittingStatus = 'insufficient_data';
    end
    
    weibullResults.analysisTimestamp = datetime('now');
end

function generateReliabilityvisualisation(results, options)
    % Generate comprehensive reliability analysis visualisation
    
    figure('Position', [100, 100, 1600, 1200]);
    
    % Reliability function plot
    subplot(3, 4, 1);
    if isfield(results, 'weibull') && isfield(results.weibull, 'reliabilityFunction')
        plot(results.weibull.timePoints, results.weibull.reliabilityFunction, 'b-', 'LineWidth', 3);
        xlabel('Time (hours)', 'FontSize', 12);
        ylabel('Reliability R(t)', 'FontSize', 12);
        title('Reliability Function', 'FontSize', 14, 'FontWeight', 'bold');
        grid on;
        xlim([0, max(results.weibull.timePoints)]);
        ylim([0, 1]);
    end
    
    % Hazard function plot
    subplot(3, 4, 2);
    if isfield(results, 'weibull') && isfield(results.weibull, 'hazardFunction')
        plot(results.weibull.timePoints, results.weibull.hazardFunction, 'r-', 'LineWidth', 3);
        xlabel('Time (hours)', 'FontSize', 12);
        ylabel('Hazard Rate h(t)', 'FontSize', 12);
        title('Hazard Function', 'FontSize', 14, 'FontWeight', 'bold');
        grid on;
    end
    
    % PFD confidence interval
    subplot(3, 4, 3);
    if isfield(results, 'pfd') && ~isnan(results.pfd.estimatedPFD)
        bar(1, results.pfd.estimatedPFD, 'FaceColor', [0.3, 0.6, 0.9]);
        hold on;
        errorbar(1, results.pfd.estimatedPFD, ...
            results.pfd.estimatedPFD - results.pfd.confidenceInterval(1), ...
            results.pfd.confidenceInterval(2) - results.pfd.estimatedPFD, ...
            'k', 'LineWidth', 2, 'CapSize', 10);
        ylabel('PFD', 'FontSize', 12);
        title('Probability of Failure on Demand', 'FontSize', 14, 'FontWeight', 'bold');
        set(gca, 'XTickLabel', {'PFD'});
        grid on;
    end
    
    % MTBF confidence interval
    subplot(3, 4, 4);
    if isfield(results, 'mtbf') && ~isnan(results.mtbf.mtbfEstimate)
        bar(1, results.mtbf.mtbfEstimate, 'FaceColor', [0.6, 0.8, 0.4]);
        hold on;
        errorbar(1, results.mtbf.mtbfEstimate, ...
            results.mtbf.mtbfEstimate - results.mtbf.confidenceInterval(1), ...
            results.mtbf.confidenceInterval(2) - results.mtbf.mtbfEstimate, ...
            'k', 'LineWidth', 2, 'CapSize', 10);
        ylabel('MTBF (hours)', 'FontSize', 12);
        title('Mean Time Between Failures', 'FontSize', 14, 'FontWeight', 'bold');
        set(gca, 'XTickLabel', {'MTBF'});
        grid on;
    end
    
    % Weibull parameters
    subplot(3, 4, 5);
    if isfield(results, 'weibull') && ~isnan(results.weibull.shapeParameter)
        parameters = [results.weibull.shapeParameter, results.weibull.scaleParameter/1000]; % Scale for visualisation
        bar(parameters, 'FaceColor', [0.8, 0.6, 0.4]);
        set(gca, 'XTickLabel', {'Shape (--)', 'Scale (--/1000)'});
        ylabel('Parameter Value', 'FontSize', 12);
        title('Weibull Distribution Parameters', 'FontSize', 14, 'FontWeight', 'bold');
        grid on;
    end
    
    % Goodness of fit results
    subplot(3, 4, 6);
    if isfield(results, 'weibull') && isfield(results.weibull, 'kolmogorovSmirnovPValue')
        pValue = results.weibull.kolmogorovSmirnovPValue;
        bar(1, pValue, 'FaceColor', [0.9, 0.7, 0.3]);
        hold on;
        yline(0.05, 'r--', 'Significance Level', 'LineWidth', 2);
        ylabel('p-value', 'FontSize', 12);
        title('Kolmogorov-Smirnov Test', 'FontSize', 14, 'FontWeight', 'bold');
        set(gca, 'XTickLabel', {'K-S Test'});
        ylim([0, max(1, pValue + 0.1)]);
        grid on;
    end
    
    % Availability if MTTR data available
    subplot(3, 4, 7);
    if isfield(results, 'availability')
        availability = results.availability.systemAvailability;
        bar(1, availability, 'FaceColor', [0.7, 0.9, 0.7]);
        ylabel('Availability', 'FontSize', 12);
        title('System Availability', 'FontSize', 14, 'FontWeight', 'bold');
        set(gca, 'XTickLabel', {'Availability'});
        ylim([0.9, 1]);
        grid on;
    end
    
    % Compliance assessment
    subplot(3, 4, 8);
    if isfield(results, 'compliance')
        complianceScores = [results.compliance.pfdCompliance, results.compliance.mtbfCompliance, ...
                           results.compliance.availabilityCompliance];
        bar(complianceScores, 'FaceColor', [0.8, 0.8, 0.8]);
        set(gca, 'XTickLabel', {'PFD', 'MTBF', 'Availability'});
        ylabel('Compliance Score', 'FontSize', 12);
        title('Requirements Compliance', 'FontSize', 14, 'FontWeight', 'bold');
        ylim([0, 1]);
        grid on;
    end
    
    % Failure time histogram
    subplot(3, 4, 9);
    if isfield(results, 'weibull') && isfield(results.weibull, 'timePoints')
        % Generate synthetic failure times for visualisation
        syntheticFailureTimes = wblrnd(results.weibull.scaleParameter, results.weibull.shapeParameter, 100, 1);
        histogram(syntheticFailureTimes, 20, 'FaceColor', [0.6, 0.6, 0.9], 'EdgeColor', 'black');
        xlabel('Failure Time (hours)', 'FontSize', 12);
        ylabel('Frequency', 'FontSize', 12);
        title('Failure Time Distribution', 'FontSize', 14, 'FontWeight', 'bold');
        grid on;
    end
    
    % Reliability metrics comparison
    subplot(3, 4, 10);
    if ~isnan(results.pfd.estimatedPFD) && ~isnan(results.mtbf.mtbfEstimate)
        metricsLabels = {'PFD--10?', 'MTBF/1000', 'Availability--100'};
        metricsValues = [results.pfd.estimatedPFD * 1e6, results.mtbf.mtbfEstimate / 1000];
        if isfield(results, 'availability')
            metricsValues = [metricsValues, results.availability.systemAvailability * 100];
        else
            metricsValues = [metricsValues, 99.9]; % Default value
        end
        
        bar(metricsValues, 'FaceColor', [0.5, 0.8, 0.9]);
        set(gca, 'XTickLabel', metricsLabels);
        ylabel('Scaled Metric Value', 'FontSize', 12);
        title('Reliability Metrics Summary', 'FontSize', 14, 'FontWeight', 'bold');
        grid on;
    end
    
    % Uncertainty quantification
    subplot(3, 4, 11);
    if isfield(results, 'uncertainty')
        uncertaintyLabels = {'PFD', 'MTBF', 'Weibull --', 'Weibull --'};
        uncertaintyValues = [results.uncertainty.pfdUncertainty, results.uncertainty.mtbfUncertainty, ...
                           results.uncertainty.weibullShapeUncertainty, results.uncertainty.weibullScaleUncertainty];
        bar(uncertaintyValues, 'FaceColor', [0.9, 0.6, 0.6]);
        set(gca, 'XTickLabel', uncertaintyLabels);
        ylabel('Relative Uncertainty', 'FontSize', 12);
        title('Uncertainty Quantification', 'FontSize', 14, 'FontWeight', 'bold');
        grid on;
    end
    
    % Summary statistics
    subplot(3, 4, 12);
    axis off;
    summaryText = sprintf('Reliability Assessment Summary\n\n');
    if ~isnan(results.pfd.estimatedPFD)
        summaryText = [summaryText, sprintf('PFD: %.2e\n', results.pfd.estimatedPFD)];
        summaryText = [summaryText, sprintf('PFD 95%% CI: [%.2e, %.2e]\n', ...
            results.pfd.confidenceInterval(1), results.pfd.confidenceInterval(2))];
    end
    if ~isnan(results.mtbf.mtbfEstimate)
        summaryText = [summaryText, sprintf('MTBF: %.1f hours\n', results.mtbf.mtbfEstimate)];
        summaryText = [summaryText, sprintf('MTBF 95%% CI: [%.1f, %.1f]\n', ...
            results.mtbf.confidenceInterval(1), results.mtbf.confidenceInterval(2))];
    end
    if isfield(results, 'weibull') && ~isnan(results.weibull.shapeParameter)
        summaryText = [summaryText, sprintf('Weibull --: %.2f\n', results.weibull.shapeParameter)];
        summaryText = [summaryText, sprintf('Weibull --: %.1f\n', results.weibull.scaleParameter)];
    end
    summaryText = [summaryText, sprintf('\nAnalysis Date: %s', string(results.timestamp))];
    
    text(0.05, 0.95, summaryText, 'FontSize', 11, 'VerticalAlignment', 'top', ...
        'HorizontalAlignment', 'left', 'Interpreter', 'none', 'FontWeight', 'bold');
    
    % Save visualisation in multiple formats
    saveas(gcf, 'ReliabilityAssessmentResults.fig');
    saveas(gcf, 'ReliabilityAssessmentResults.eps', 'epsc');
    saveas(gcf, 'ReliabilityAssessmentResults.jpg');
    
    fprintf('Reliability assessment visualisation saved in multiple formats.\n');
end
