%% problem_3_climate_lstm.m
% Climate-Adaptive LSTM for Infrastructure RUL Prediction
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : problem_3_climate_lstm
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function climate_adaptive_infrastructure_rul_prediction()
% Climate-Adaptive LSTM for Infrastructure RUL Prediction
% Author: Dr Leo Chen
% Version: 2024.1
% Purpose: IMPACT-RISE project infrastructure resilience under climate change
%
% This function demonstrates:
% - Non-stationary time series analysis for climate-affected infrastructure
% - Hierarchical LSTM with climate-aware attention mechanisms
% - Bayesian uncertainty quantification for climate-related variability
% - Multi-horizon RUL prediction with confidence intervals
% - Transfer learning for adaptation to novel climate conditions

    fprintf('Starting Climate-Adaptive Infrastructure RUL Prediction\n');
    fprintf('=====================================================\n\n');
    
    % Step 1: Load comprehensive infrastructure and climate dataset
    [infrastructure_data, climate_data, degradation_labels] = load_climate_infrastructure_dataset();
    
    fprintf('Dataset Summary:\n');
    fprintf('Monitoring period: %d years\n', infrastructure_data.monitoring_years);
    fprintf('Sensor measurements: %d channels\n', size(infrastructure_data.sensor_data, 2));
    fprintf('Climate variables: %d parameters\n', size(climate_data.variables, 2));
    fprintf('Infrastructure components: %d systems\n', length(unique(infrastructure_data.component_ids)));
    
    % Step 2: Climate trend analysis and non-stationarity detection
    climate_analysis = perform_climate_trend_analysis(climate_data);
    
    % Step 3: Multi-scale feature engineering with climate integration
    integrated_features = extract_climate_aware_features(infrastructure_data, climate_data, climate_analysis);
    
    % Step 4: Hierarchical LSTM architecture with climate attention
    lstm_architecture = design_climate_adaptive_lstm_architecture(integrated_features);
    
    % Step 5: Bayesian training for uncertainty quantification
    [trained_model, training_metrics] = train_bayesian_climate_lstm(...
        integrated_features, degradation_labels, lstm_architecture);
    
    % Step 6: Multi-horizon RUL prediction with uncertainty bounds
    rul_predictions = generate_multi_horizon_rul_predictions(trained_model, integrated_features);
    
    % Step 7: Transfer learning for future climate scenarios
    transfer_analysis = implement_climate_transfer_learning(trained_model, climate_analysis);
    
    % Step 8: Decision support system integration
    decision_support = create_infrastructure_decision_support_system(...
        rul_predictions, climate_analysis, transfer_analysis);
    
    % Step 9: Comprehensive visualisation with climate context
    create_climate_infrastructure_visualisation(trained_model, rul_predictions, ...
                                               climate_analysis, decision_support, ...
                                               infrastructure_data, climate_data);
    
    % Step 10: Generate climate adaptation report
    generate_climate_adaptation_report(rul_predictions, climate_analysis, ...
                                      transfer_analysis, decision_support);
    
    % Save results with climate projection scenarios
    save_climate_rul_analysis_results(trained_model, rul_predictions, climate_analysis, ...
                                     transfer_analysis, decision_support);
    
    fprintf('\nClimate-adaptive infrastructure RUL prediction completed!\n');
    fprintf('Results include projections for multiple climate scenarios.\n');
end

function [infra_data, climate_data, degradation_labels] = load_climate_infrastructure_dataset()
    % Load comprehensive dataset integrating infrastructure monitoring and climate data
    
    fprintf('Loading climate-integrated infrastructure dataset...\n');
    
    % Infrastructure monitoring parameters
    monitoring_years = 15;
    n_sensors = 50;
    measurements_per_day = 24; % Hourly measurements
    total_measurements = monitoring_years * 365 * measurements_per_day;
    
    % Generate realistic infrastructure sensor data
    infra_data = struct();
    infra_data.monitoring_years = monitoring_years;
    infra_data.timestamps = datetime(2008,1,1):hours(1):datetime(2023,12,31,23,0,0);
    infra_data.timestamps = infra_data.timestamps(1:total_measurements);
    
    % Sensor channel definitions
    sensor_channels = {
        'Strain_Gauge_Main_Beam_1', 'Strain_Gauge_Main_Beam_2', 'Strain_Gauge_Main_Beam_3', ...
        'Strain_Gauge_Support_1', 'Strain_Gauge_Support_2', 'Strain_Gauge_Support_3', ...
        'Accelerometer_X_Deck', 'Accelerometer_Y_Deck', 'Accelerometer_Z_Deck', ...
        'Accelerometer_X_Tower_1', 'Accelerometer_Y_Tower_1', 'Accelerometer_Z_Tower_1', ...
        'Accelerometer_X_Tower_2', 'Accelerometer_Y_Tower_2', 'Accelerometer_Z_Tower_2', ...
        'Temperature_Deck_North', 'Temperature_Deck_South', 'Temperature_Deck_East', 'Temperature_Deck_West', ...
        'Temperature_Structure_1', 'Temperature_Structure_2', 'Temperature_Structure_3', ...
        'Displacement_Expansion_Joint_1', 'Displacement_Expansion_Joint_2', ...
        'Rotation_Support_A', 'Rotation_Support_B', 'Rotation_Support_C', ...
        'Tilt_Sensor_X', 'Tilt_Sensor_Y', 'Settlement_Monitor_Pier_1', 'Settlement_Monitor_Pier_2', ...
        'Settlement_Monitor_Pier_3', 'Settlement_Monitor_Pier_4', ...
        'Cable_Tension_1', 'Cable_Tension_2', 'Cable_Tension_3', 'Cable_Tension_4', ...
        'Crack_Width_Monitor_1', 'Crack_Width_Monitor_2', 'Crack_Width_Monitor_3', ...
        'Corrosion_Potential_1', 'Corrosion_Potential_2', 'Corrosion_Potential_3', ...
        'Concrete_Moisture_1', 'Concrete_Moisture_2', 'Concrete_Moisture_3', ...
        'Chloride_Concentration_1', 'Chloride_Concentration_2', 'Chloride_Concentration_3', ...
        'Traffic_Load_Counter', 'Wind_Speed_Structure', 'Wind_Direction_Structure'
    };
    
    infra_data.sensor_channels = sensor_channels(1:n_sensors);
    
    % Generate realistic sensor data with climate-driven degradation
    rng(2023); % For reproducible results
    infra_data.sensor_data = generate_climate_driven_infrastructure_data(...
        total_measurements, n_sensors, infra_data.timestamps);
    
    % Component identification for multi-component analysis
    infra_data.component_ids = generate_component_identification(n_sensors);
    
    % Generate climate data with realistic trends and variability
    climate_data = generate_comprehensive_climate_data(infra_data.timestamps);
    
    % Generate degradation labels with climate acceleration effects
    degradation_labels = generate_climate_accelerated_degradation_labels(...
        infra_data.sensor_data, climate_data, infra_data.timestamps);
    
    fprintf('Dataset loaded successfully:\n');
    fprintf('  Infrastructure sensors: %d channels\n', n_sensors);
    fprintf('  Monitoring period: %d years (%d measurements)\n', monitoring_years, total_measurements);
    fprintf('  Climate variables: %d parameters\n', size(climate_data.variables, 2));
end

function sensor_data = generate_climate_driven_infrastructure_data(n_measurements, n_sensors, timestamps)
    % Generate realistic infrastructure sensor data with climate-driven degradation patterns
    
    sensor_data = zeros(n_measurements, n_sensors);
    
    % Time vector for degradation modelling
    time_years = years(timestamps - timestamps(1));
    
    % Climate change acceleration factors
    temperature_trend = 0.05 * time_years; % 0.05--C per year warming
    precipitation_intensity_factor = 1 + 0.02 * time_years; % 2% per year increase in intensity
    freeze_thaw_factor = 1 + 0.03 * time_years; % 3% per year increase in freeze-thaw cycles
    
    for sensor_idx = 1:n_sensors
        % Base degradation pattern (without climate effects)
        base_degradation = generate_base_degradation_pattern(time_years, sensor_idx);
        
        # Climate-accelerated degradation components
        thermal_degradation = generate_thermal_degradation_component(...
            time_years, temperature_trend, sensor_idx);
        
        moisture_degradation = generate_moisture_degradation_component(...
            time_years, precipitation_intensity_factor, sensor_idx);
        
        freeze_thaw_degradation = generate_freeze_thaw_degradation_component(...
            time_years, freeze_thaw_factor, sensor_idx);
        
        # Extreme weather event impacts
        extreme_weather_impacts = generate_extreme_weather_impacts(timestamps, sensor_idx);
        
        # Seasonal variations
        seasonal_component = generate_seasonal_variations(timestamps, sensor_idx);
        
        # Random measurement noise
        measurement_noise = generate_measurement_noise(n_measurements, sensor_idx);
        
        # Combine all components
        sensor_data(:, sensor_idx) = base_degradation + thermal_degradation + ...
                                   moisture_degradation + freeze_thaw_degradation + ...
                                   extreme_weather_impacts + seasonal_component + ...
                                   measurement_noise;
    end
    
    % Ensure realistic sensor ranges and apply physical constraints
    sensor_data = apply_sensor_physical_constraints(sensor_data);
end

function base_degradation = generate_base_degradation_pattern(time_years, sensor_idx)
    % Generate base infrastructure degradation without climate acceleration
    
    switch mod(sensor_idx, 10)
        case {1, 2, 3} % Strain gauges - gradual increase due to structural fatigue
            degradation_rate = 0.02 + 0.01 * rand(); % 2-3% per year
            base_degradation = degradation_rate * time_years + ...
                             0.005 * time_years.^1.5; % Non-linear fatigue component
            
        case {4, 5, 6} % Accelerometers - slight increase in vibration
            degradation_rate = 0.01 + 0.005 * rand(); % 1-1.5% per year
            base_degradation = degradation_rate * time_years;
            
        case {7, 8, 9} % Temperature sensors - minimal drift
            degradation_rate = 0.001 + 0.0005 * rand(); % 0.1-0.15% per year
            base_degradation = degradation_rate * time_years;
            
        case 0 % Displacement/settlement sensors - gradual settlement
            degradation_rate = 0.03 + 0.02 * rand(); % 3-5% per year
            base_degradation = degradation_rate * time_years + ...
                             0.01 * time_years.^1.2; # Non-linear settlement
    end
end

function thermal_degradation = generate_thermal_degradation_component(time_years, temp_trend, sensor_idx)
    % Generate thermal degradation acceleration due to climate warming
    
    # Thermal expansion/contraction effects
    thermal_stress_factor = 0.1 + 0.05 * rand(); % Material-dependent
    
    # Cumulative thermal damage
    cumulative_thermal_exposure = cumtrapz(time_years, temp_trend);
    
    switch mod(sensor_idx, 10)
        case {1, 2, 3} % Strain gauges - thermal stress effects
            thermal_degradation = thermal_stress_factor * cumulative_thermal_exposure;
            
        case {4, 5, 6} % Accelerometers - thermal expansion effects
            thermal_degradation = 0.5 * thermal_stress_factor * cumulative_thermal_exposure;
            
        case {7, 8, 9} % Temperature sensors - calibration drift
            thermal_degradation = 0.1 * thermal_stress_factor * cumulative_thermal_exposure;
            
        case 0 % Displacement sensors - thermal movement
            thermal_degradation = 2.0 * thermal_stress_factor * cumulative_thermal_exposure;
    end
end

function moisture_degradation = generate_moisture_degradation_component(time_years, precip_factor, sensor_idx)
    % Generate moisture-related degradation acceleration
    
    # Moisture penetration and corrosion effects
    moisture_susceptibility = 0.05 + 0.03 * rand(); % Material-dependent susceptibility
    
    # Cumulative moisture exposure
    cumulative_moisture_exposure = cumtrapz(time_years, precip_factor - 1);
    
    switch mod(sensor_idx, 10)
        case {1, 2, 3} % Strain gauges - corrosion effects
            moisture_degradation = moisture_susceptibility * cumulative_moisture_exposure;
            
        case {4, 5, 6} % Accelerometers - moisture ingress
            moisture_degradation = 0.3 * moisture_susceptibility * cumulative_moisture_exposure;
            
        case {7, 8, 9} % Temperature sensors - humidity effects
            moisture_degradation = 0.2 * moisture_susceptibility * cumulative_moisture_exposure;
            
        case 0 # Displacement sensors - moisture-induced swelling
            moisture_degradation = 1.5 * moisture_susceptibility * cumulative_moisture_exposure;
    end
end

function freeze_thaw_degradation = generate_freeze_thaw_degradation_component(time_years, ft_factor, sensor_idx)
    % Generate freeze-thaw cycle degradation
    
    # Freeze-thaw damage susceptibility
    ft_susceptibility = 0.08 + 0.04 * rand();
    
    # Cumulative freeze-thaw exposure
    cumulative_ft_exposure = cumtrapz(time_years, ft_factor - 1);
    
    switch mod(sensor_idx, 10)
        case {1, 2, 3} % Strain gauges - concrete cracking
            freeze_thaw_degradation = ft_susceptibility * cumulative_ft_exposure;
            
        case {4, 5, 6} % Accelerometers - structural loosening
            freeze_thaw_degradation = 0.7 * ft_susceptibility * cumulative_ft_exposure;
            
        case {7, 8, 9} % Temperature sensors - minimal effect
            freeze_thaw_degradation = 0.1 * ft_susceptibility * cumulative_ft_exposure;
            
        case 0 % Displacement sensors - joint degradation
            freeze_thaw_degradation = 2.0 * ft_susceptibility * cumulative_ft_exposure;
    end
end

function extreme_impacts = generate_extreme_weather_impacts(timestamps, sensor_idx)
    % Generate discrete extreme weather event impacts
    
    n_measurements = length(timestamps);
    extreme_impacts = zeros(n_measurements, 1);
    
    # Define extreme events based on historical patterns with climate change
    event_probabilities = [
        0.02,   % Annual hurricane/severe storm probability
        0.05,   % Annual flooding probability  
        0.10,   % Annual extreme heat event probability
        0.08,   % Annual severe winter storm probability
        0.03    % Annual tornado/severe wind probability
    ];
    
    # Increase event frequency over time (climate change effect)
    time_years = years(timestamps - timestamps(1));
    climate_multiplier = 1 + 0.02 * time_years; % 2% per year increase
    
    for year_idx = 1:ceil(max(time_years))
        current_year_mask = (time_years >= year_idx-1) & (time_years < year_idx);
        current_probabilities = event_probabilities * climate_multiplier(year_idx);
        
        for event_type = 1:length(event_probabilities)
            if rand() < current_probabilities(event_type)
                # Generate event impact
                event_impact = generate_single_extreme_event_impact(sensor_idx, event_type);
                
                # Random timing within year
                year_indices = find(current_year_mask);
                if ~isempty(year_indices)
                    event_start = year_indices(randi(length(year_indices)));
                    event_duration = randi([24, 168]); % 1-7 days
                    event_end = min(event_start + event_duration, n_measurements);
                    
                    # Apply event impact with exponential decay
                    impact_indices = event_start:event_end;
                    decay_factor = exp(-0.1 * (0:length(impact_indices)-1));
                    extreme_impacts(impact_indices) = extreme_impacts(impact_indices) + ...
                                                     event_impact * decay_factor';
                end
            end
        end
    end
end

function event_impact = generate_single_extreme_event_impact(sensor_idx, event_type)
    % Generate impact magnitude for specific extreme weather event
    
    base_impact = 0.1 + 0.2 * rand(); % Base impact magnitude
    
    # Event-specific and sensor-specific multipliers
    event_multipliers = [2.0, 1.5, 1.2, 1.8, 2.5]; % Hurricane, flood, heat, winter, tornado
    
    sensor_type_multipliers = [
        1.5, 1.5, 1.5,   % Strain gauges - structural loading
        2.0, 2.0, 2.0,   % Accelerometers - vibration/shaking
        0.8, 0.8, 0.8,   % Temperature sensors - less affected
        1.0               % Displacement sensors - moderate effect
    ];
    
    sensor_multiplier = sensor_type_multipliers(mod(sensor_idx-1, 10) + 1);
    event_multiplier = event_multipliers(event_type);
    
    event_impact = base_impact * sensor_multiplier * event_multiplier;
end

function seasonal_component = generate_seasonal_variations(timestamps, sensor_idx)
    % Generate realistic seasonal variations in sensor measurements
    
    # Convert timestamps to day of year
    day_of_year = day(timestamps, 'dayofyear');
    
    # Seasonal amplitude based on sensor type
    seasonal_amplitudes = [
        0.05, 0.05, 0.05,  % Strain gauges - thermal expansion
        0.02, 0.02, 0.02,  % Accelerometers - minimal seasonal effect
        0.20, 0.20, 0.20,  % Temperature sensors - large seasonal variation
        0.08               % Displacement sensors - thermal movement
    ];
    
    amplitude = seasonal_amplitudes(mod(sensor_idx-1, 10) + 1);
    
    # Generate multi-harmonic seasonal pattern
    seasonal_component = amplitude * sin(2 * pi * day_of_year / 365) + ...
                        0.3 * amplitude * sin(4 * pi * day_of_year / 365) + ...
                        0.1 * amplitude * sin(6 * pi * day_of_year / 365);
end

function noise = generate_measurement_noise(n_measurements, sensor_idx)
    % Generate realistic measurement noise with temporal correlation
    
    # Noise levels based on sensor type and quality
    noise_levels = [
        0.01, 0.01, 0.01,  % Strain gauges - low noise
        0.02, 0.02, 0.02,  % Accelerometers - moderate noise
        0.005, 0.005, 0.005, % Temperature sensors - very low noise
        0.015              % Displacement sensors - low-moderate noise
    ];
    
    noise_level = noise_levels(mod(sensor_idx-1, 10) + 1);
    
    # Generate temporally correlated noise using AR(1) process
    correlation_coefficient = 0.3; % Moderate temporal correlation
    white_noise = noise_level * randn(n_measurements, 1);
    
    noise = zeros(n_measurements, 1);
    noise(1) = white_noise(1);
    
    for time_idx = 2:n_measurements
        noise(time_idx) = correlation_coefficient * noise(time_idx-1) + ...
                         sqrt(1 - correlation_coefficient^2) * white_noise(time_idx);
    end
end

function constrained_data = apply_sensor_physical_constraints(sensor_data)
    % Apply realistic physical constraints to sensor measurements
    
    [n_measurements, n_sensors] = size(sensor_data);
    constrained_data = sensor_data;
    
    for sensor_idx = 1:n_sensors
        switch mod(sensor_idx, 10)
            case {1, 2, 3} % Strain gauges - limit to realistic strain ranges
                constrained_data(:, sensor_idx) = max(-2000, min(2000, sensor_data(:, sensor_idx))); % microstrain
                
            case {4, 5, 6} % Accelerometers - limit to reasonable acceleration
                constrained_data(:, sensor_idx) = max(-5, min(5, sensor_data(:, sensor_idx))); % g
                
            case {7, 8, 9} % Temperature sensors - realistic temperature range
                constrained_data(:, sensor_idx) = max(-40, min(60, sensor_data(:, sensor_idx))); % --C
                
            case 0 % Displacement sensors - limit displacement range
                constrained_data(:, sensor_idx) = max(-50, min(50, sensor_data(:, sensor_idx))); % mm
        end
    end
end

function component_ids = generate_component_identification(n_sensors)
    % Generate component identification for multi-component reliability analysis
    
    # Define infrastructure components
    components = {
        'Main_Structural_Elements',
        'Support_Systems', 
        'Expansion_Joints',
        'Foundation_Systems',
        'Monitoring_Infrastructure'
    };
    
    # Assign sensors to components
    sensors_per_component = floor(n_sensors / length(components));
    component_ids = {};
    
    for comp_idx = 1:length(components)
        start_sensor = (comp_idx - 1) * sensors_per_component + 1;
        if comp_idx == length(components)
            end_sensor = n_sensors; % Assign remaining sensors to last component
        else
            end_sensor = comp_idx * sensors_per_component;
        end
        
        for sensor_idx = start_sensor:end_sensor
            component_ids{sensor_idx} = components{comp_idx};
        end
    end
end

function climate_data = generate_comprehensive_climate_data(timestamps)
    % Generate comprehensive climate dataset with realistic trends and variability
    
    fprintf('Generating comprehensive climate dataset...\n');
    
    n_measurements = length(timestamps);
    climate_data = struct();
    climate_data.timestamps = timestamps;
    
    # Time vectors for trend analysis
    time_years = years(timestamps - timestamps(1));
    time_days = days(timestamps - timestamps(1));
    
    # Generate climate variables with realistic trends
    climate_variables = generate_climate_variables(time_years, time_days, n_measurements);
    
    climate_data.variables = climate_variables;
    climate_data.variable_names = {
        'Air_Temperature', 'Relative_Humidity', 'Precipitation_Rate', 'Wind_Speed', ...
        'Wind_Direction', 'Atmospheric_Pressure', 'Solar_Radiation', 'Dew_Point', ...
        'Heat_Index', 'Wind_Chill', 'UV_Index', 'Cloud_Cover', ...
        'Precipitation_Intensity', 'Temperature_Range', 'Humidity_Range'
    };
    climate_data.units = {
        '--C', '%', 'mm/hr', 'm/s', 'degrees', 'hPa', 'W/m?', '--C', ...
        '--C', '--C', 'index', '%', 'mm/hr', '--C', '%'
    };
    
    # Calculate derived climate indices
    climate_data.indices = calculate_climate_indices(climate_variables, timestamps);
    
    fprintf('Generated %d climate variables over %d measurements\n', ...
            size(climate_variables, 2), n_measurements);
end

function climate_vars = generate_climate_variables(time_years, time_days, n_measurements)
    % Generate realistic climate variables with trends and variability
    
    # Initialize climate variable matrix
    n_climate_vars = 15;
    climate_vars = zeros(n_measurements, n_climate_vars);
    
    # Day of year for seasonal patterns
    day_of_year = mod(time_days, 365) + 1;
    
    # Climate change trends (per year)
    temperature_trend = 0.05; % 0.05--C per year
    precipitation_trend = 0.02; % 2% per year increase in intensity
    
    # 1. Air Temperature with warming trend and seasonal variation
    base_temp = 15; % Base temperature (--C)
    seasonal_temp = 10 * sin(2 * pi * day_of_year / 365 - pi/2); % Seasonal variation
    warming_trend = temperature_trend * time_years;
    temp_noise = 3 * randn(n_measurements, 1);
    climate_vars(:, 1) = base_temp + seasonal_temp + warming_trend + temp_noise;
    
    # 2. Relative Humidity
    base_humidity = 60; % Base humidity (%)
    seasonal_humidity = 15 * sin(2 * pi * day_of_year / 365 + pi/4);
    humidity_noise = 10 * randn(n_measurements, 1);
    climate_vars(:, 2) = max(0, min(100, base_humidity + seasonal_humidity + humidity_noise));
    
    # 3. Precipitation Rate with increasing intensity
    precipitation_frequency = 0.15; % 15% chance of precipitation
    precipitation_events = rand(n_measurements, 1) < precipitation_frequency;
    base_intensity = 2; % mm/hr
    intensity_trend = base_intensity * precipitation_trend * time_years;
    climate_vars(:, 3) = precipitation_events .* ...
                        (base_intensity + intensity_trend + abs(randn(n_measurements, 1)));
    
    # 4. Wind Speed
    base_wind = 5; % m/s
    wind_variability = 3 * abs(randn(n_measurements, 1));
    seasonal_wind = 2 * sin(2 * pi * day_of_year / 365 + pi);
    climate_vars(:, 4) = max(0, base_wind + wind_variability + seasonal_wind);
    
    # 5. Wind Direction
    climate_vars(:, 5) = 360 * rand(n_measurements, 1); % Random direction
    
    # 6. Atmospheric Pressure
    base_pressure = 1013; % hPa
    pressure_variation = 20 * randn(n_measurements, 1);
    seasonal_pressure = 5 * sin(2 * pi * day_of_year / 365);
    climate_vars(:, 6) = base_pressure + pressure_variation + seasonal_pressure;
    
    # 7. Solar Radiation
    max_radiation = 1000; % W/m?
    solar_angle = sin(max(0, sin(2 * pi * day_of_year / 365 - pi/2)));
    cloud_factor = 1 - 0.7 * rand(n_measurements, 1); % Cloud attenuation
    climate_vars(:, 7) = max(0, max_radiation * solar_angle .* cloud_factor);
    
    # 8. Dew Point (derived from temperature and humidity)
    temperature = climate_vars(:, 1);
    humidity = climate_vars(:, 2);
    climate_vars(:, 8) = temperature - (100 - humidity) / 5; % Simplified dew point
    
    # 9. Heat Index (combination of temperature and humidity)
    climate_vars(:, 9) = calculate_heat_index(temperature, humidity);
    
    # 10. Wind Chill (combination of temperature and wind speed)
    wind_speed = climate_vars(:, 4);
    climate_vars(:, 10) = calculate_wind_chill(temperature, wind_speed);
    
    # 11. UV Index
    climate_vars(:, 11) = max(0, min(11, climate_vars(:, 7) / 100 + randn(n_measurements, 1)));
    
    # 12. Cloud Cover (%)
    climate_vars(:, 12) = max(0, min(100, 50 + 30 * randn(n_measurements, 1)));
    
    # 13. Precipitation Intensity (derived)
    climate_vars(:, 13) = climate_vars(:, 3); % Same as precipitation rate
    
    # 14. Daily Temperature Range
    climate_vars(:, 14) = abs(5 + 3 * randn(n_measurements, 1));
    
    # 15. Daily Humidity Range
    climate_vars(:, 15) = abs(10 + 5 * randn(n_measurements, 1));
end

function heat_index = calculate_heat_index(temperature, humidity)
    % Calculate heat index from temperature and humidity
    
    # Simplified heat index calculation
    heat_index = temperature;
    
    # Apply heat index correction for high temperature and humidity
    high_temp_mask = temperature > 26.7; % 80--F
    if any(high_temp_mask)
        T = temperature(high_temp_mask);
        H = humidity(high_temp_mask);
        
        # Simplified heat index formula
        HI = T + 0.5 * (T + 61.0 + ((T - 68.0) * 1.2) + (H * 0.094));
        heat_index(high_temp_mask) = HI;
    end
end

function wind_chill = calculate_wind_chill(temperature, wind_speed)
    % Calculate wind chill from temperature and wind speed
    
    wind_chill = temperature;
    
    # Apply wind chill correction for low temperatures and high wind
    cold_mask = temperature < 10 & wind_speed > 3;
    if any(cold_mask)
        T = temperature(cold_mask);
        V = wind_speed(cold_mask);
        
        # Simplified wind chill formula
        WC = 13.12 + 0.6215 * T - 11.37 * (V.^0.16) + 0.3965 * T .* (V.^0.16);
        wind_chill(cold_mask) = WC;
    end
end

function climate_indices = calculate_climate_indices(climate_vars, timestamps)
    % Calculate derived climate indices for infrastructure impact assessment
    
    climate_indices = struct();
    
    # Extract individual variables
    temperature = climate_vars(:, 1);
    humidity = climate_vars(:, 2);
    precipitation = climate_vars(:, 3);
    
    # Calculate cooling degree days (CDD) and heating degree days (HDD)
    base_temp = 18; % --C
    climate_indices.cooling_degree_days = max(0, temperature - base_temp);
    climate_indices.heating_degree_days = max(0, base_temp - temperature);
    
    # Calculate freeze-thaw cycles
    climate_indices.freeze_thaw_cycles = calculate_freeze_thaw_cycles(temperature, timestamps);
    
    # Calculate wet-dry cycles  
    climate_indices.wet_dry_cycles = calculate_wet_dry_cycles(precipitation, timestamps);
    
    # Calculate extreme event indicators
    climate_indices.extreme_heat_events = temperature > prctile(temperature, 95);
    climate_indices.extreme_precipitation_events = precipitation > prctile(precipitation(precipitation > 0), 95);
    
    # Calculate cumulative climate exposure
    climate_indices.cumulative_heat_exposure = cumsum(climate_indices.cooling_degree_days);
    climate_indices.cumulative_moisture_exposure = cumsum(precipitation);
    
    fprintf('Calculated %d climate indices\n', length(fieldnames(climate_indices)));
end

function ft_cycles = calculate_freeze_thaw_cycles(temperature, timestamps)
    % Calculate freeze-thaw cycles from temperature data
    
    # Daily temperature processing
    daily_temps = accumarray(day(timestamps, 'dayofyear'), temperature, [], @(x) {x});
    
    ft_cycles = zeros(size(temperature));
    current_cycle_count = 0;
    
    for day_idx = 1:length(daily_temps)
        if ~isempty(daily_temps{day_idx})
            day_temps = daily_temps{day_idx};
            
            # Count freeze-thaw transitions
            below_freezing = day_temps < 0;
            transitions = diff(below_freezing);
            daily_ft_cycles = sum(transitions ~= 0) / 2; # Each complete cycle requires freeze AND thaw
            
            current_cycle_count = current_cycle_count + daily_ft_cycles;
            
            # Assign cycle count to all measurements in this day
            day_mask = day(timestamps, 'dayofyear') == day_idx;
            ft_cycles(day_mask) = current_cycle_count;
        end
    end
end

function wd_cycles = calculate_wet_dry_cycles(precipitation, timestamps)
    % Calculate wet-dry cycles from precipitation data
    
    # Define wet/dry threshold
    wet_threshold = 0.1; % mm/hr
    
    # Identify wet periods
    wet_periods = precipitation > wet_threshold;
    
    # Count transitions
    transitions = diff(wet_periods);
    wet_dry_transitions = cumsum(transitions ~= 0) / 2;
    
    wd_cycles = [0; wet_dry_transitions];
end

function degradation_labels = generate_climate_accelerated_degradation_labels(sensor_data, climate_data, timestamps)
    % Generate realistic degradation labels with climate acceleration effects
    
    fprintf('Generating climate-accelerated degradation labels...\n');
    
    [n_measurements, n_sensors] = size(sensor_data);
    degradation_labels = struct();
    
    # Time vector for degradation progression
    time_years = years(timestamps - timestamps(1));
    
    # Calculate composite climate stress index
    climate_stress_index = calculate_composite_climate_stress_index(climate_data);
    
    # Generate component-level RUL with climate effects
    degradation_labels.component_rul = zeros(n_measurements, n_sensors);
    degradation_labels.health_index = zeros(n_measurements, n_sensors);
    degradation_labels.degradation_rate = zeros(n_measurements, n_sensors);
    
    for sensor_idx = 1:n_sensors
        # Base degradation parameters
        base_lifetime = 50 + 20 * rand(); % 50-70 years base lifetime
        
        # Climate acceleration factor
        climate_acceleration = 1 + climate_stress_index * (0.5 + 0.3 * rand());
        
        # Calculate time-varying degradation rate
        degradation_rate = (1 / base_lifetime) * climate_acceleration;
        degradation_labels.degradation_rate(:, sensor_idx) = degradation_rate;
        
        # Calculate cumulative degradation (health index)
        cumulative_degradation = cumtrapz(time_years, degradation_rate);
        health_index = max(0, 1 - cumulative_degradation);
        degradation_labels.health_index(:, sensor_idx) = health_index;
        
        # Calculate remaining useful life
        current_degradation = cumulative_degradation;
        remaining_degradation = 1 - current_degradation;
        current_rate = degradation_rate;
        
        # Estimate RUL assuming current degradation rate continues
        estimated_rul = remaining_degradation ./ (current_rate + eps);
        degradation_labels.component_rul(:, sensor_idx) = max(0, estimated_rul);
    end
    
    # Generate system-level RUL (minimum of all components)
    degradation_labels.system_rul = min(degradation_labels.component_rul, [], 2);
    degradation_labels.system_health_index = min(degradation_labels.health_index, [], 2);
    
    # Add uncertainty to labels
    degradation_labels = add_label_uncertainty(degradation_labels);
    
    fprintf('Generated degradation labels for %d sensors over %d time points\n', ...
            n_sensors, n_measurements);
end

function climate_stress_index = calculate_composite_climate_stress_index(climate_data)
    % Calculate composite climate stress index from multiple variables
    
    climate_vars = climate_data.variables;
    climate_indices = climate_data.indices;
    
    # Normalise individual stress components
    temperature_stress = normalize_stress_component(climate_vars(:, 1), 'temperature');
    precipitation_stress = normalize_stress_component(climate_vars(:, 3), 'precipitation');
    wind_stress = normalize_stress_component(climate_vars(:, 4), 'wind');
    
    # Include derived indices
    ft_stress = normalize_stress_component(climate_indices.freeze_thaw_cycles, 'freeze_thaw');
    wd_stress = normalize_stress_component(climate_indices.wet_dry_cycles, 'wet_dry');
    
    # Combine stress components with weights
    stress_weights = [0.3, 0.2, 0.1, 0.25, 0.15]; % Temperature, precipitation, wind, FT, WD
    
    climate_stress_index = stress_weights(1) * temperature_stress + ...
                          stress_weights(2) * precipitation_stress + ...
                          stress_weights(3) * wind_stress + ...
                          stress_weights(4) * ft_stress + ...
                          stress_weights(5) * wd_stress;
    
    # Smooth the stress index to remove high-frequency noise
    window_size = 24 * 7; % One week smoothing
    climate_stress_index = movmean(climate_stress_index, window_size);
end

function normalized_stress = normalize_stress_component(variable, variable_type)
    % Normalise individual stress components to [0, 1] range
    
    switch variable_type
        case 'temperature'
            # Temperature stress increases above/below comfort range
            comfort_range = [10, 25]; % --C
            stress = max(0, variable - comfort_range(2)) + max(0, comfort_range(1) - variable);
            normalized_stress = min(1, stress / 15); % Normalise by extreme deviation
            
        case 'precipitation'
            # Precipitation stress from intensity
            normalized_stress = min(1, variable / 10); # Normalise by heavy rain threshold
            
        case 'wind'
            # Wind stress from high speeds
            normalized_stress = min(1, max(0, variable - 5) / 20); # Stress above 5 m/s
            
        case 'freeze_thaw'
            # Freeze-thaw stress from cycle frequency
            annual_cycles = 50; # Typical annual cycles
            normalized_stress = min(1, variable / annual_cycles);
            
        case 'wet_dry'
            # Wet-dry stress from cycle frequency
            annual_cycles = 30; # Typical annual cycles
            normalized_stress = min(1, variable / annual_cycles);
            
        otherwise
            # Default normalisation
            normalized_stress = (variable - min(variable)) / (max(variable) - min(variable) + eps);
    end
end

function degradation_labels = add_label_uncertainty(degradation_labels)
    % Add realistic uncertainty to degradation labels
    
    # RUL uncertainty (increasing with time horizon)
    rul_uncertainty_factor = 0.1; # 10% base uncertainty
    rul_noise = rul_uncertainty_factor * degradation_labels.component_rul .* randn(size(degradation_labels.component_rul));
    degradation_labels.component_rul = max(0, degradation_labels.component_rul + rul_noise);
    
    # Health index uncertainty
    health_uncertainty_factor = 0.05; # 5% uncertainty
    health_noise = health_uncertainty_factor * randn(size(degradation_labels.health_index));
    degradation_labels.health_index = max(0, min(1, degradation_labels.health_index + health_noise));
    
    # Recalculate system-level metrics with uncertainty
    degradation_labels.system_rul = min(degradation_labels.component_rul, [], 2);
    degradation_labels.system_health_index = min(degradation_labels.health_index, [], 2);
end

function climate_analysis = perform_climate_trend_analysis(climate_data)
    % Comprehensive climate trend analysis for non-stationarity detection
    
    fprintf('Performing comprehensive climate trend analysis...\n');
    
    climate_analysis = struct();
    
    # Extract time series and variables
    timestamps = climate_data.timestamps;
    climate_vars = climate_data.variables;
    time_years = years(timestamps - timestamps(1));
    
    # Trend analysis for each climate variable
    n_vars = size(climate_vars, 2);
    climate_analysis.trends = struct();
    
    for var_idx = 1:n_vars
        var_name = climate_data.variable_names{var_idx};
        var_data = climate_vars(:, var_idx);
        
        # Linear trend analysis
        [trend_coeffs, trend_stats] = analyse_linear_trend(time_years, var_data);
        
        # Change point detection
        change_points = detect_change_points(var_data, timestamps);
        
        # Seasonal decomposition
        seasonal_components = decompose_seasonal_components(var_data, timestamps);
        
        # Non-stationarity tests
        stationarity_tests = perform_stationarity_tests(var_data);
        
        # Store results
        climate_analysis.trends.(var_name) = struct();
        climate_analysis.trends.(var_name).linear_trend = trend_coeffs;
        climate_analysis.trends.(var_name).trend_significance = trend_stats.p_value;
        climate_analysis.trends.(var_name).change_points = change_points;
        climate_analysis.trends.(var_name).seasonal = seasonal_components;
        climate_analysis.trends.(var_name).stationarity = stationarity_tests;
    end
    
    # Composite climate change indicators
    climate_analysis.composite_indicators = calculate_composite_climate_indicators(climate_data);
    
    # Future projection scenarios
    climate_analysis.projections = generate_climate_projections(climate_data, climate_analysis.trends);
    
    fprintf('Climate trend analysis completed for %d variables\n', n_vars);
end

function [trend_coeffs, trend_stats] = analyse_linear_trend(time_years, variable_data)
    % Analyse linear trend in time series data
    
    # Fit linear regression
    X = [ones(length(time_years), 1), time_years];
    [coeffs, ~, residuals, ~, stats] = regress(variable_data, X);
    
    trend_coeffs = coeffs(2); % Slope coefficient
    trend_stats = struct();
    trend_stats.r_squared = stats(1);
    trend_stats.f_statistic = stats(2);
    trend_stats.p_value = stats(3);
    trend_stats.error_variance = stats(4);
end

function change_points = detect_change_points(data, timestamps)
    % Detect change points in time series using statistical methods
    
    # Simplified change point detection using variance changes
    n_points = length(data);
    window_size = min(365 * 24, floor(n_points / 10)); # Window size for analysis
    
    change_point_scores = zeros(n_points - 2*window_size, 1);
    
    for test_point = window_size:(n_points - window_size)
        # Calculate variance before and after test point
        before_data = data((test_point - window_size + 1):test_point);
        after_data = data((test_point + 1):(test_point + window_size));
        
        var_before = var(before_data);
        var_after = var(after_data);
        
        # Change point score based on variance ratio
        change_point_scores(test_point - window_size + 1) = abs(log(var_after / (var_before + eps)));
    end
    
    # Identify significant change points
    threshold = prctile(change_point_scores, 95); # Top 5% as change points
    significant_points = find(change_point_scores > threshold) + window_size - 1;
    
    change_points = struct();
    change_points.indices = significant_points;
    change_points.timestamps = timestamps(significant_points);
    change_points.scores = change_point_scores(change_point_scores > threshold);
end

function seasonal_components = decompose_seasonal_components(data, timestamps)
    % Decompose time series into seasonal components
    
    # Extract temporal features
    hour_of_day = hour(timestamps);
    day_of_year = day(timestamps, 'dayofyear');
    
    # Fit seasonal models
    # Daily cycle
    daily_cycle = fit_fourier_series(hour_of_day, data, 1); # 1 harmonic for daily cycle
    
    # Annual cycle
    annual_cycle = fit_fourier_series(day_of_year, data, 3); # 3 harmonics for annual cycle
    
    # Calculate trend component (residual after removing seasonal)
    seasonal_total = daily_cycle.fitted + annual_cycle.fitted;
    trend_component = data - seasonal_total;
    
    seasonal_components = struct();
    seasonal_components.daily = daily_cycle;
    seasonal_components.annual = annual_cycle;
    seasonal_components.trend = trend_component;
    seasonal_components.residual = data - seasonal_total - trend_component;
end

function fourier_fit = fit_fourier_series(time_variable, data, n_harmonics)
    % Fit Fourier series to capture periodic components
    
    period = max(time_variable) - min(time_variable) + 1;
    omega = 2 * pi / period;
    
    # Create design matrix for Fourier series
    n_points = length(time_variable);
    X = ones(n_points, 1); # Constant term
    
    for harmonic = 1:n_harmonics
        X = [X, sin(harmonic * omega * time_variable), cos(harmonic * omega * time_variable)];
    end
    
    # Fit coefficients
    coefficients = X \ data;
    fitted_values = X * coefficients;
    
    fourier_fit = struct();
    fourier_fit.coefficients = coefficients;
    fourier_fit.fitted = fitted_values;
    fourier_fit.n_harmonics = n_harmonics;
    fourier_fit.period = period;
end

function stationarity_tests = perform_stationarity_tests(data)
    % Perform statistical tests for stationarity
    
    stationarity_tests = struct();
    
    # Augmented Dickey-Fuller test (simplified implementation)
    adf_result = simplified_adf_test(data);
    stationarity_tests.adf_statistic = adf_result.statistic;
    stationarity_tests.adf_p_value = adf_result.p_value;
    stationarity_tests.is_stationary = adf_result.p_value < 0.05;
    
    # KPSS test (simplified implementation)
    kpss_result = simplified_kpss_test(data);
    stationarity_tests.kpss_statistic = kpss_result.statistic;
    stationarity_tests.kpss_p_value = kpss_result.p_value;
    
    # Overall stationarity assessment
    stationarity_tests.overall_assessment = assess_overall_stationarity(adf_result, kpss_result);
end

function adf_result = simplified_adf_test(data)
    % Simplified Augmented Dickey-Fuller test
    
    n = length(data);
    y = data(2:end);
    x = data(1:end-1);
    
    # Simple AR(1) model: --y_t = --y_{t-1} + --_t
    delta_y = diff(data);
    lagged_y = data(1:end-1);
    
    # Regression
    [coeffs, ~, ~, ~, stats] = regress(delta_y, [ones(length(lagged_y), 1), lagged_y]);
    
    adf_result = struct();
    adf_result.statistic = coeffs(2) / sqrt(stats(4) * inv(lagged_y' * lagged_y));
    adf_result.p_value = stats(3);
end

function kpss_result = simplified_kpss_test(data)
    % Simplified KPSS test for trend stationarity
    
    n = length(data);
    
    # Fit linear trend
    time_trend = (1:n)';
    trend_coeffs = [ones(n, 1), time_trend] \ data;
    trend_residuals = data - [ones(n, 1), time_trend] * trend_coeffs;
    
    # Calculate KPSS statistic
    cumulative_residuals = cumsum(trend_residuals);
    kpss_statistic = sum(cumulative_residuals.^2) / (n^2 * var(trend_residuals));
    
    kpss_result = struct();
    kpss_result.statistic = kpss_statistic;
    kpss_result.p_value = exp(-kpss_statistic); # Simplified p-value approximation
end

function assessment = assess_overall_stationarity(adf_result, kpss_result)
    % Assess overall stationarity based on multiple tests
    
    if adf_result.p_value < 0.05 && kpss_result.p_value > 0.05
        assessment = 'stationary';
    elseif adf_result.p_value > 0.05 && kpss_result.p_value < 0.05
        assessment = 'non_stationary_with_unit_root';
    elseif adf_result.p_value > 0.05 && kpss_result.p_value > 0.05
        assessment = 'non_stationary_trend_stationary';
    else
        assessment = 'inconclusive';
    end
end

function composite_indicators = calculate_composite_climate_indicators(climate_data)
    % Calculate composite indicators of climate change impact
    
    composite_indicators = struct();
    
    climate_vars = climate_data.variables;
    timestamps = climate_data.timestamps;
    time_years = years(timestamps - timestamps(1));
    
    # Temperature-based indicators
    temperature = climate_vars(:, 1);
    composite_indicators.warming_rate = calculate_warming_rate(temperature, time_years);
    composite_indicators.extreme_heat_frequency = calculate_extreme_heat_frequency(temperature, timestamps);
    
    # Precipitation-based indicators
    precipitation = climate_vars(:, 3);
    composite_indicators.precipitation_intensity_change = calculate_precipitation_intensity_change(...
        precipitation, time_years);
    composite_indicators.extreme_precipitation_frequency = calculate_extreme_precipitation_frequency(...
        precipitation, timestamps);
    
    # Combined stress indicator
    composite_indicators.climate_stress_acceleration = calculate_climate_stress_acceleration(...
        climate_data, time_years);
end

function warming_rate = calculate_warming_rate(temperature, time_years)
    % Calculate rate of temperature increase
    
    # Annual average temperatures
    annual_years = unique(floor(time_years));
    annual_temps = zeros(length(annual_years), 1);
    
    for year_idx = 1:length(annual_years)
        year_mask = floor(time_years) == annual_years(year_idx);
        annual_temps(year_idx) = mean(temperature(year_mask));
    end
    
    # Linear trend in annual temperatures
    [trend_coeffs, ~] = analyse_linear_trend(annual_years, annual_temps);
    warming_rate = trend_coeffs; % --C per year
end

function extreme_frequency = calculate_extreme_heat_frequency(temperature, timestamps)
    % Calculate frequency of extreme heat events
    
    # Define extreme heat threshold (95th percentile)
    extreme_threshold = prctile(temperature, 95);
    
    # Calculate annual frequency
    years_data = year(timestamps);
    unique_years = unique(years_data);
    annual_extreme_days = zeros(length(unique_years), 1);
    
    for year_idx = 1:length(unique_years)
        year_mask = years_data == unique_years(year_idx);
        year_temperatures = temperature(year_mask);
        
        # Count days above threshold
        extreme_days = sum(year_temperatures > extreme_threshold);
        annual_extreme_days(year_idx) = extreme_days;
    end
    
    extreme_frequency = struct();
    extreme_frequency.annual_extreme_days = annual_extreme_days;
    extreme_frequency.trend = analyse_linear_trend(unique_years - min(unique_years), annual_extreme_days);
end

function intensity_change = calculate_precipitation_intensity_change(precipitation, time_years)
    % Calculate change in precipitation intensity over time
    
    # Focus on precipitation events only
    precipitation_events = precipitation(precipitation > 0);
    time_events = time_years(precipitation > 0);
    
    if length(precipitation_events) > 100 # Sufficient data
        # Calculate trend in precipitation intensity
        [trend_coeffs, ~] = analyse_linear_trend(time_events, precipitation_events);
        intensity_change = trend_coeffs; % mm/hr per year
    else
        intensity_change = 0;
    end
end

function extreme_precip_freq = calculate_extreme_precipitation_frequency(precipitation, timestamps)
    % Calculate frequency of extreme precipitation events
    
    # Define extreme precipitation threshold
    precipitation_events = precipitation(precipitation > 0);
    if length(precipitation_events) > 10
        extreme_threshold = prctile(precipitation_events, 95);
    else
        extreme_threshold = 10; % Default threshold
    end
    
    # Calculate annual frequency
    years_data = year(timestamps);
    unique_years = unique(years_data);
    annual_extreme_events = zeros(length(unique_years), 1);
    
    for year_idx = 1:length(unique_years)
        year_mask = years_data == unique_years(year_idx);
        year_precipitation = precipitation(year_mask);
        
        # Count extreme events
        extreme_events = sum(year_precipitation > extreme_threshold);
        annual_extreme_events(year_idx) = extreme_events;
    end
    
    extreme_precip_freq = struct();
    extreme_precip_freq.annual_extreme_events = annual_extreme_events;
    extreme_precip_freq.trend = analyse_linear_trend(unique_years - min(unique_years), annual_extreme_events);
end

function stress_acceleration = calculate_climate_stress_acceleration(climate_data, time_years)
    % Calculate acceleration in climate stress over time
    
    # Calculate composite stress index
    climate_stress = calculate_composite_climate_stress_index(climate_data);
    
    # Fit quadratic trend to detect acceleration
    X = [ones(length(time_years), 1), time_years, time_years.^2];
    coefficients = X \ climate_stress;
    
    stress_acceleration = struct();
    stress_acceleration.linear_term = coefficients(2);
    stress_acceleration.quadratic_term = coefficients(3); # Acceleration term
    stress_acceleration.acceleration_significance = assess_acceleration_significance(coefficients(3), climate_stress, X);
end

function significance = assess_acceleration_significance(acceleration_coeff, data, design_matrix)
    % Assess statistical significance of acceleration term
    
    # Simple t-test for acceleration coefficient
    fitted_values = design_matrix * [0; 0; acceleration_coeff];
    residuals = data - fitted_values;
    
    # Standard error estimation (simplified)
    mse = mean(residuals.^2);
    se_acceleration = sqrt(mse * inv(design_matrix' * design_matrix)(3,3));
    
    t_statistic = acceleration_coeff / se_acceleration;
    significance = abs(t_statistic) > 1.96; # Approximately p < 0.05
end

function projections = generate_climate_projections(climate_data, trends)
    % Generate future climate projections based on observed trends
    
    projections = struct();
    
    # Projection time horizon
    projection_years = 30; # 30-year projections
    
    # Extract key variables for projection
    variable_names = climate_data.variable_names;
    
    for var_idx = 1:length(variable_names)
        var_name = variable_names{var_idx};
        
        if isfield(trends, var_name)
            var_trends = trends.(var_name);
            
            # Project based on linear trend
            projected_change = var_trends.linear_trend * projection_years;
            
            # Add uncertainty bounds based on trend significance
            if var_trends.trend_significance < 0.05
                uncertainty_factor = 0.2; # 20% uncertainty for significant trends
            else
                uncertainty_factor = 0.5; # 50% uncertainty for non-significant trends
            end
            
            projections.(var_name) = struct();
            projections.(var_name).projected_change = projected_change;
            projections.(var_name).uncertainty_lower = projected_change * (1 - uncertainty_factor);
            projections.(var_name).uncertainty_upper = projected_change * (1 + uncertainty_factor);
            projections.(var_name).confidence = 1 - var_trends.trend_significance;
        end
    end
    
    projections.projection_horizon_years = projection_years;
    projections.base_period = [min(climate_data.timestamps), max(climate_data.timestamps)];
end

function integrated_features = extract_climate_aware_features(infra_data, climate_data, climate_analysis)
    % Extract comprehensive features integrating infrastructure and climate data
    
    fprintf('Extracting climate-aware features for LSTM training...\n');
    
    integrated_features = struct();
    
    # Infrastructure sensor features
    infra_features = extract_infrastructure_sensor_features(infra_data);
    
    # Climate variable features
    climate_features = extract_climate_variable_features(climate_data, climate_analysis);
    
    # Climate-infrastructure interaction features
    interaction_features = extract_climate_infrastructure_interactions(infra_data, climate_data);
    
    # Temporal features capturing non-stationary trends
    temporal_features = extract_temporal_trend_features(infra_data.timestamps, climate_analysis);
    
    # Multi-scale features across different time horizons
    multiscale_features = extract_multiscale_temporal_features(infra_features, climate_features);
    
    # Combine all feature sets
    integrated_features.infrastructure = infra_features;
    integrated_features.climate = climate_features;
    integrated_features.interactions = interaction_features;
    integrated_features.temporal = temporal_features;
    integrated_features.multiscale = multiscale_features;
    
    # Create unified feature matrix for LSTM training
    integrated_features.combined_matrix = combine_feature_matrices(integrated_features);
    
    # Feature metadata for interpretability
    integrated_features.feature_names = generate_integrated_feature_names(integrated_features);
    integrated_features.feature_importance_weights = calculate_feature_importance_weights(integrated_features);
    
    fprintf('Generated %d integrated features combining infrastructure and climate data\n', ...
            size(integrated_features.combined_matrix, 2));
end

function infra_features = extract_infrastructure_sensor_features(infra_data)
    % Extract comprehensive features from infrastructure sensor data
    
    sensor_data = infra_data.sensor_data;
    [n_measurements, n_sensors] = size(sensor_data);
    
    # Time-domain features
    infra_features = struct();
    
    # Statistical moments
    infra_features.mean = mean(sensor_data, 1);
    infra_features.std = std(sensor_data, 0, 1);
    infra_features.skewness = skewness(sensor_data, 0, 1);
    infra_features.kurtosis = kurtosis(sensor_data, 0, 1);
    
    # Trend features using moving windows
    window_size = 24 * 7; # Weekly windows
    n_windows = floor(n_measurements / window_size);
    
    trend_features = zeros(n_windows, n_sensors);
    for window_idx = 1:n_windows
        start_idx = (window_idx - 1) * window_size + 1;
        end_idx = min(window_idx * window_size, n_measurements);
        
        window_data = sensor_data(start_idx:end_idx, :);
        window_time = (1:size(window_data, 1))';
        
        # Calculate linear trends within each window
        for sensor_idx = 1:n_sensors
            trend_coeffs = polyfit(window_time, window_data(:, sensor_idx), 1);
            trend_features(window_idx, sensor_idx) = trend_coeffs(1); # Slope
        end
    end
    
    infra_features.trend_coefficients = trend_features;
    
    # Cross-correlation features between sensors
    n_pairs = n_sensors * (n_sensors - 1) / 2;
    cross_correlations = zeros(1, n_pairs);
    pair_idx = 1;
    
    for sensor1 = 1:n_sensors
        for sensor2 = (sensor1 + 1):n_sensors
            correlation_matrix = corrcoef(sensor_data(:, sensor1), sensor_data(:, sensor2));
            cross_correlations(pair_idx) = correlation_matrix(1, 2);
            pair_idx = pair_idx + 1;
        end
    end
    
    infra_features.cross_correlations = cross_correlations;
    
    # Frequency domain features (simplified)
    frequency_features = extract_frequency_domain_features(sensor_data);
    infra_features.frequency = frequency_features;
end

function frequency_features = extract_frequency_domain_features(sensor_data)
    % Extract frequency domain features from sensor data
    
    [n_measurements, n_sensors] = size(sensor_data);
    
    # FFT-based features
    frequency_features = struct();
    
    # Power spectral density features
    frequency_features.spectral_centroid = zeros(1, n_sensors);
    frequency_features.spectral_bandwidth = zeros(1, n_sensors);
    frequency_features.spectral_energy = zeros(1, n_sensors);
    
    for sensor_idx = 1:n_sensors
        sensor_signal = sensor_data(:, sensor_idx);
        
        # Remove mean and apply window
        windowed_signal = (sensor_signal - mean(sensor_signal)) .* hamming(n_measurements);
        
        # FFT
        signal_fft = fft(windowed_signal);
        magnitude_spectrum = abs(signal_fft(1:floor(n_measurements/2)));
        frequency_vector = (0:length(magnitude_spectrum)-1) / n_measurements;
        
        # Normalise spectrum
        magnitude_spectrum = magnitude_spectrum / sum(magnitude_spectrum);
        
        # Spectral centroid
        frequency_features.spectral_centroid(sensor_idx) = ...
            sum(frequency_vector .* magnitude_spectrum') / sum(magnitude_spectrum);
        
        # Spectral bandwidth
        centroid = frequency_features.spectral_centroid(sensor_idx);
        frequency_features.spectral_bandwidth(sensor_idx) = ...
            sqrt(sum(((frequency_vector - centroid).^2) .* magnitude_spectrum') / sum(magnitude_spectrum));
        
        # Total spectral energy
        frequency_features.spectral_energy(sensor_idx) = sum(magnitude_spectrum.^2);
    end
end

function climate_features = extract_climate_variable_features(climate_data, climate_analysis)
    % Extract features from climate variables and trends
    
    climate_vars = climate_data.variables;
    climate_indices = climate_data.indices;
    
    climate_features = struct();
    
    # Raw climate variables
    climate_features.variables = climate_vars;
    
    # Climate indices
    index_names = fieldnames(climate_indices);
    climate_features.indices = [];
    for idx = 1:length(index_names)
        index_data = climate_indices.(index_names{idx});
        if isnumeric(index_data) && size(index_data, 1) == size(climate_vars, 1)
            climate_features.indices = [climate_features.indices, index_data];
        end
    end
    
    # Trend features from climate analysis
    climate_features.trend_indicators = extract_trend_indicators_from_analysis(climate_analysis);
    
    # Climate change acceleration features
    climate_features.acceleration_indicators = extract_acceleration_indicators(climate_data, climate_analysis);
end

function trend_indicators = extract_trend_indicators_from_analysis(climate_analysis)
    % Extract trend indicators from climate analysis
    
    trend_names = fieldnames(climate_analysis.trends);
    n_vars = length(trend_names);
    
    trend_indicators = zeros(1, n_vars * 3); # Linear trend, significance, change points
    
    for var_idx = 1:n_vars
        var_trends = climate_analysis.trends.(trend_names{var_idx});
        
        base_idx = (var_idx - 1) * 3;
        trend_indicators(base_idx + 1) = var_trends.linear_trend;
        trend_indicators(base_idx + 2) = var_trends.trend_significance;
        trend_indicators(base_idx + 3) = length(var_trends.change_points.indices);
    end
end

function acceleration_indicators = extract_acceleration_indicators(climate_data, climate_analysis)
    % Extract climate change acceleration indicators
    
    if isfield(climate_analysis, 'composite_indicators')
        composite = climate_analysis.composite_indicators;
        
        acceleration_indicators = [
            composite.warming_rate, ...
            composite.extreme_heat_frequency.trend, ...
            composite.precipitation_intensity_change, ...
            composite.extreme_precipitation_frequency.trend, ...
            composite.climate_stress_acceleration.quadratic_term
        ];
    else
        acceleration_indicators = zeros(1, 5);
    end
end

function interaction_features = extract_climate_infrastructure_interactions(infra_data, climate_data)
    % Extract features capturing climate-infrastructure interactions
    
    sensor_data = infra_data.sensor_data;
    climate_vars = climate_data.variables;
    
    [n_measurements, n_sensors] = size(sensor_data);
    [~, n_climate_vars] = size(climate_vars);
    
    interaction_features = struct();
    
    # Direct correlation between infrastructure and climate
    interaction_correlations = zeros(n_sensors, n_climate_vars);
    
    for sensor_idx = 1:n_sensors
        for climate_idx = 1:n_climate_vars
            correlation_matrix = corrcoef(sensor_data(:, sensor_idx), climate_vars(:, climate_idx));
            interaction_correlations(sensor_idx, climate_idx) = correlation_matrix(1, 2);
        end
    end
    
    interaction_features.correlations = interaction_correlations;
    
    # Time-lagged correlations
    max_lag = 24 * 7; # One week maximum lag
    lag_correlations = calculate_lagged_correlations(sensor_data, climate_vars, max_lag);
    interaction_features.lagged_correlations = lag_correlations;
    
    # Climate-conditioned infrastructure statistics
    climate_conditional_features = calculate_climate_conditional_features(sensor_data, climate_vars);
    interaction_features.conditional_statistics = climate_conditional_features;
end

function lag_correlations = calculate_lagged_correlations(sensor_data, climate_vars, max_lag)
    % Calculate time-lagged correlations between infrastructure and climate
    
    [n_measurements, n_sensors] = size(sensor_data);
    [~, n_climate_vars] = size(climate_vars);
    
    # Test lags from 0 to max_lag
    lag_steps = [0, 6, 12, 24, 48, 96, 168]; # Hours: 0, 6h, 12h, 1d, 2d, 4d, 1w
    lag_steps = lag_steps(lag_steps <= max_lag);
    
    lag_correlations = zeros(n_sensors, n_climate_vars, length(lag_steps));
    
    for sensor_idx = 1:n_sensors
        for climate_idx = 1:n_climate_vars
            for lag_idx = 1:length(lag_steps)
                lag = lag_steps(lag_idx);
                
                if lag == 0
                    # No lag
                    correlation_matrix = corrcoef(sensor_data(:, sensor_idx), climate_vars(:, climate_idx));
                    lag_correlations(sensor_idx, climate_idx, lag_idx) = correlation_matrix(1, 2);
                else
                    # Apply lag to climate data
                    end_idx = n_measurements - lag;
                    if end_idx > 100 # Sufficient data points
                        lagged_climate = climate_vars(1:end_idx, climate_idx);
                        future_sensor = sensor_data((lag+1):n_measurements, sensor_idx);
                        
                        correlation_matrix = corrcoef(lagged_climate, future_sensor);
                        lag_correlations(sensor_idx, climate_idx, lag_idx) = correlation_matrix(1, 2);
                    end
                end
            end
        end
    end
end

function conditional_features = calculate_climate_conditional_features(sensor_data, climate_vars)
    % Calculate infrastructure sensor statistics conditioned on climate states
    
    [n_measurements, n_sensors] = size(sensor_data);
    
    # Define climate conditions based on temperature and precipitation
    temperature = climate_vars(:, 1);
    precipitation = climate_vars(:, 3);
    
    # Climate state definitions
    temp_thresholds = prctile(temperature, [33.33, 66.67]); # Terciles
    precip_threshold = prctile(precipitation(precipitation > 0), 50); # Median of non-zero
    
    # Define climate states
    hot_dry = (temperature > temp_thresholds(2)) & (precipitation <= precip_threshold);
    hot_wet = (temperature > temp_thresholds(2)) & (precipitation > precip_threshold);
    moderate_dry = (temperature >= temp_thresholds(1) & temperature <= temp_thresholds(2)) & ...
                   (precipitation <= precip_threshold);
    moderate_wet = (temperature >= temp_thresholds(1) & temperature <= temp_thresholds(2)) & ...
                   (precipitation > precip_threshold);
    cold_dry = (temperature < temp_thresholds(1)) & (precipitation <= precip_threshold);
    cold_wet = (temperature < temp_thresholds(1)) & (precipitation > precip_threshold);
    
    climate_states = {hot_dry, hot_wet, moderate_dry, moderate_wet, cold_dry, cold_wet};
    state_names = {'hot_dry', 'hot_wet', 'moderate_dry', 'moderate_wet', 'cold_dry', 'cold_wet'};
    
    # Calculate sensor statistics for each climate state
    conditional_features = struct();
    
    for state_idx = 1:length(climate_states)
        state_mask = climate_states{state_idx};
        state_name = state_names{state_idx};
        
        if sum(state_mask) > 10 # Sufficient observations
            state_sensor_data = sensor_data(state_mask, :);
            
            conditional_features.(state_name) = struct();
            conditional_features.(state_name).mean = mean(state_sensor_data, 1);
            conditional_features.(state_name).std = std(state_sensor_data, 0, 1);
            conditional_features.(state_name).count = sum(state_mask);
        end
    end
end

function temporal_features = extract_temporal_trend_features(timestamps, climate_analysis)
    % Extract temporal features capturing non-stationary trends
    
    temporal_features = struct();
    
    # Time-based features
    time_years = years(timestamps - timestamps(1));
    day_of_year = day(timestamps, 'dayofyear');
    hour_of_day = hour(timestamps);
    
    temporal_features.time_years = time_years;
    temporal_features.day_of_year = day_of_year;
    temporal_features.hour_of_day = hour_of_day;
    
    # Cyclical encoding for temporal features
    temporal_features.day_of_year_sin = sin(2 * pi * day_of_year / 365);
    temporal_features.day_of_year_cos = cos(2 * pi * day_of_year / 365);
    temporal_features.hour_of_day_sin = sin(2 * pi * hour_of_day / 24);
    temporal_features.hour_of_day_cos = cos(2 * pi * hour_of_day / 24);
    
    # Climate change progress indicators
    if isfield(climate_analysis, 'composite_indicators')
        # Cumulative climate change exposure
        warming_rate = climate_analysis.composite_indicators.warming_rate;
        temporal_features.cumulative_warming = warming_rate * time_years;
        
        # Acceleration indicators
        if isfield(climate_analysis.composite_indicators, 'climate_stress_acceleration')
            acceleration = climate_analysis.composite_indicators.climate_stress_acceleration.quadratic_term;
            temporal_features.climate_acceleration_exposure = acceleration * time_years.^2;
        end
    end
    
    # Change point indicators
    temporal_features.change_point_proximity = calculate_change_point_proximity(timestamps, climate_analysis);
end

function proximity_features = calculate_change_point_proximity(timestamps, climate_analysis)
    % Calculate proximity to detected change points in climate data
    
    proximity_features = zeros(length(timestamps), 1);
    
    # Aggregate change points from all climate variables
    all_change_points = [];
    
    if isfield(climate_analysis, 'trends')
        trend_names = fieldnames(climate_analysis.trends);
        
        for var_idx = 1:length(trend_names)
            var_trends = climate_analysis.trends.(trend_names{var_idx});
            if isfield(var_trends, 'change_points') && ~isempty(var_trends.change_points.timestamps)
                all_change_points = [all_change_points; var_trends.change_points.timestamps];
            end
        end
    end
    
    # Calculate distance to nearest change point for each timestamp
    if ~isempty(all_change_points)
        for time_idx = 1:length(timestamps)
            current_time = timestamps(time_idx);
            distances = abs(days(all_change_points - current_time));
            min_distance = min(distances);
            
            # Convert to proximity feature (closer = higher value)
            proximity_features(time_idx) = exp(-min_distance / 365); # Decay over one year
        end
    end
end

function multiscale_features = extract_multiscale_temporal_features(infra_features, climate_features)
    % Extract features across multiple temporal scales
    
    multiscale_features = struct();
    
    # Define temporal scales
    scales = [1, 6, 24, 168, 730]; # 1h, 6h, 1d, 1w, 1month (hours)
    scale_names = {'hourly', 'six_hourly', 'daily', 'weekly', 'monthly'};
    
    # Infrastructure data multiscale features
    if isfield(infra_features, 'mean')
        infra_mean = infra_features.mean;
        n_sensors = length(infra_mean);
        
        for scale_idx = 1:length(scales)
            scale_name = scale_names{scale_idx};
            window_size = scales(scale_idx);
            
            # Calculate moving averages and variability at each scale
            if size(infra_features.mean, 1) == 1
                # Static features - create time series for multiscale analysis
                multiscale_features.infrastructure.(scale_name) = infra_mean;
            else
                # Dynamic features - apply multiscale analysis
                multiscale_features.infrastructure.(scale_name) = ...
                    calculate_multiscale_statistics(infra_features.mean, window_size);
            end
        end
    end
    
    # Climate data multiscale features
    if isfield(climate_features, 'variables')
        climate_vars = climate_features.variables;
        
        for scale_idx = 1:length(scales)
            scale_name = scale_names{scale_idx};
            window_size = scales(scale_idx);
            
            multiscale_climate = calculate_multiscale_statistics(climate_vars, window_size);
            multiscale_features.climate.(scale_name) = multiscale_climate;
        end
    end
end

function multiscale_stats = calculate_multiscale_statistics(data, window_size)
    % Calculate statistics over specified time window
    
    if size(data, 1) < window_size
        # Insufficient data for this scale
        multiscale_stats = struct();
        multiscale_stats.mean = mean(data, 1);
        multiscale_stats.std = std(data, 0, 1);
        return;
    end
    
    # Calculate moving statistics
    moving_mean = movmean(data, window_size, 1);
    moving_std = movstd(data, window_size, 0, 1);
    
    multiscale_stats = struct();
    multiscale_stats.mean = moving_mean;
    multiscale_stats.std = moving_std;
    multiscale_stats.trend = calculate_moving_trends(data, window_size);
end

function moving_trends = calculate_moving_trends(data, window_size)
    % Calculate moving trends using local linear regression
    
    [n_points, n_vars] = size(data);
    moving_trends = zeros(n_points, n_vars);
    
    for var_idx = 1:n_vars
        for point_idx = window_size:n_points
            start_idx = point_idx - window_size + 1;
            end_idx = point_idx;
            
            window_data = data(start_idx:end_idx, var_idx);
            window_time = (1:window_size)';
            
            # Linear trend coefficient
            trend_coeff = polyfit(window_time, window_data, 1);
            moving_trends(point_idx, var_idx) = trend_coeff(1);
        end
    end
end

function combined_matrix = combine_feature_matrices(integrated_features)
    % Combine all feature sets into unified matrix for LSTM training
    
    feature_matrices = {};
    
    # Infrastructure features
    if isfield(integrated_features, 'infrastructure')
        infra_features = integrated_features.infrastructure;
        
        # Convert structure to matrix
        infra_matrix = [];
        if isfield(infra_features, 'mean')
            infra_matrix = [infra_matrix, infra_features.mean];
        end
        if isfield(infra_features, 'std')
            infra_matrix = [infra_matrix, infra_features.std];
        end
        if isfield(infra_features, 'cross_correlations')
            infra_matrix = [infra_matrix, infra_features.cross_correlations];
        end
        
        if ~isempty(infra_matrix)
            feature_matrices{end+1} = infra_matrix;
        end
    end
    
    # Climate features
    if isfield(integrated_features, 'climate')
        climate_features = integrated_features.climate;
        
        if isfield(climate_features, 'variables')
            feature_matrices{end+1} = climate_features.variables;
        end
        if isfield(climate_features, 'indices') && ~isempty(climate_features.indices)
            feature_matrices{end+1} = climate_features.indices;
        end
    end
    
    # Temporal features
    if isfield(integrated_features, 'temporal')
        temporal_features = integrated_features.temporal;
        
        temporal_matrix = [];
        temp_fields = fieldnames(temporal_features);
        for field_idx = 1:length(temp_fields)
            field_data = temporal_features.(temp_fields{field_idx});
            if isnumeric(field_data) && length(field_data) > 1
                temporal_matrix = [temporal_matrix, field_data(:)];
            end
        end
        
        if ~isempty(temporal_matrix)
            feature_matrices{end+1} = temporal_matrix;
        end
    end
    
    # Combine all matrices
    if ~isempty(feature_matrices)
        # Ensure all matrices have same number of rows
        n_rows = size(feature_matrices{1}, 1);
        for matrix_idx = 2:length(feature_matrices)
            if size(feature_matrices{matrix_idx}, 1) ~= n_rows
                # Resample or truncate to match
                current_matrix = feature_matrices{matrix_idx};
                if size(current_matrix, 1) > n_rows
                    feature_matrices{matrix_idx} = current_matrix(1:n_rows, :);
                else
                    # Interpolate to match length
                    old_indices = linspace(1, n_rows, size(current_matrix, 1));
                    new_indices = 1:n_rows;
                    interpolated_matrix = zeros(n_rows, size(current_matrix, 2));
                    
                    for col_idx = 1:size(current_matrix, 2)
                        interpolated_matrix(:, col_idx) = interp1(old_indices, ...
                                                                current_matrix(:, col_idx), ...
                                                                new_indices, 'linear', 'extrap');
                    end
                    feature_matrices{matrix_idx} = interpolated_matrix;
                end
            end
        end
        
        combined_matrix = horzcat(feature_matrices{:});
    else
        combined_matrix = [];
    end
end

function feature_names = generate_integrated_feature_names(integrated_features)
    % Generate descriptive names for all integrated features
    
    feature_names = {};
    
    # Infrastructure feature names
    if isfield(integrated_features, 'infrastructure')
        infra_features = integrated_features.infrastructure;
        
        if isfield(infra_features, 'mean')
            n_sensors = length(infra_features.mean);
            for sensor_idx = 1:n_sensors
                feature_names{end+1} = sprintf('Infra_Sensor_%d_Mean', sensor_idx);
            end
        end
        
        if isfield(infra_features, 'std')
            n_sensors = length(infra_features.std);
            for sensor_idx = 1:n_sensors
                feature_names{end+1} = sprintf('Infra_Sensor_%d_Std', sensor_idx);
            end
        end
        
        if isfield(infra_features, 'cross_correlations')
            n_correlations = length(infra_features.cross_correlations);
            for corr_idx = 1:n_correlations
                feature_names{end+1} = sprintf('Infra_CrossCorr_%d', corr_idx);
            end
        end
    end
    
    # Climate feature names
    if isfield(integrated_features, 'climate')
        climate_features = integrated_features.climate;
        
        if isfield(climate_features, 'variables')
            climate_var_names = {'Temperature', 'Humidity', 'Precipitation', 'WindSpeed', ...
                               'WindDirection', 'Pressure', 'SolarRadiation', 'DewPoint', ...
                               'HeatIndex', 'WindChill', 'UVIndex', 'CloudCover', ...
                               'PrecipIntensity', 'TempRange', 'HumidityRange'};
            
            n_climate_vars = size(climate_features.variables, 2);
            for var_idx = 1:min(n_climate_vars, length(climate_var_names))
                feature_names{end+1} = sprintf('Climate_%s', climate_var_names{var_idx});
            end
        end
    end
    
    # Temporal feature names
    if isfield(integrated_features, 'temporal')
        temporal_features = integrated_features.temporal;
        temporal_field_names = fieldnames(temporal_features);
        
        for field_idx = 1:length(temporal_field_names)
            field_name = temporal_field_names{field_idx};
            feature_names{end+1} = sprintf('Temporal_%s', field_name);
        end
    end
end

function importance_weights = calculate_feature_importance_weights(integrated_features)
    % Calculate initial importance weights for different feature categories
    
    importance_weights = struct();
    
    # Infrastructure features - high importance for structural health
    importance_weights.infrastructure = 0.4;
    
    # Climate features - moderate importance for degradation acceleration
    importance_weights.climate = 0.3;
    
    # Interaction features - high importance for climate-infrastructure coupling
    importance_weights.interactions = 0.2;
    
    # Temporal features - moderate importance for trend capture
    importance_weights.temporal = 0.1;
    
    # Normalize to sum to 1
    total_weight = sum(struct2array(importance_weights));
    importance_fields = fieldnames(importance_weights);
    
    for field_idx = 1:length(importance_fields)
        field_name = importance_fields{field_idx};
        importance_weights.(field_name) = importance_weights.(field_name) / total_weight;
    end
end

function lstm_architecture = design_climate_adaptive_lstm_architecture(integrated_features)
    % Design hierarchical LSTM architecture with climate-aware attention mechanisms
    
    fprintf('Designing climate-adaptive LSTM architecture...\n');
    
    lstm_architecture = struct();
    
    # Input dimensions
    if isfield(integrated_features, 'combined_matrix')
        n_features = size(integrated_features.combined_matrix, 2);
    else
        n_features = 50; # Default feature dimension
    end
    
    # Sequence parameters
    lstm_architecture.sequence_length = 168; # One week lookback (hours)
    lstm_architecture.n_features = n_features;
    lstm_architecture.n_outputs = 1; # RUL prediction
    
    # Hierarchical LSTM design
    # Level 1: Short-term patterns (hourly to daily)
    lstm_architecture.level1 = struct();
    lstm_architecture.level1.lstm_units = 64;
    lstm_architecture.level1.dropout_rate = 0.2;
    lstm_architecture.level1.sequence_length = 24; # Daily patterns
    
    # Level 2: Medium-term patterns (daily to weekly)
    lstm_architecture.level2 = struct();
    lstm_architecture.level2.lstm_units = 128;
    lstm_architecture.level2.dropout_rate = 0.3;
    lstm_architecture.level2.sequence_length = 168; # Weekly patterns
    
    # Level 3: Long-term patterns (weekly to seasonal)
    lstm_architecture.level3 = struct();
    lstm_architecture.level3.lstm_units = 256;
    lstm_architecture.level3.dropout_rate = 0.4;
    lstm_architecture.level3.sequence_length = 720; # Monthly patterns (30 days)
    
    # Climate-aware attention mechanism
    lstm_architecture.attention = struct();
    lstm_architecture.attention.mechanism = 'multi_head_attention';
    lstm_architecture.attention.n_heads = 8;
    lstm_architecture.attention.key_dim = 64;
    lstm_architecture.attention.climate_weight = 0.3; # Weight for climate features
    
    # Output layers
    lstm_architecture.dense_layers = [128, 64, 32, 1];
    lstm_architecture.activation_functions = {'relu', 'relu', 'relu', 'linear'};
    
    # Regularization
    lstm_architecture.l2_regularization = 0.01;
    lstm_architecture.batch_normalization = true;
    
    # Training parameters
    lstm_architecture.training = struct();
    lstm_architecture.training.batch_size = 32;
    lstm_architecture.training.epochs = 100;
    lstm_architecture.training.learning_rate = 0.001;
    lstm_architecture.training.patience = 15; # Early stopping
    
    fprintf('LSTM architecture designed with %d input features and hierarchical structure\n', n_features);
end

% Continue with remaining functions for the complete implementation...
% [Additional functions would continue here following the same pattern]

function [trained_model, training_metrics] = train_bayesian_climate_lstm(integrated_features, degradation_labels, lstm_architecture)
    % Train Bayesian LSTM with uncertainty quantification
    
    fprintf('Training Bayesian LSTM for climate-adaptive RUL prediction...\n');
    
    # Prepare training data
    [X_train, y_train, X_val, y_val, X_test, y_test] = prepare_lstm_training_data(...
        integrated_features, degradation_labels, lstm_architecture);
    
    # Initialize ensemble of LSTM networks for Bayesian approximation
    n_ensemble = 10;
    ensemble_models = cell(n_ensemble, 1);
    training_histories = cell(n_ensemble, 1);
    
    for ensemble_idx = 1:n_ensemble
        fprintf('Training ensemble member %d/%d\n', ensemble_idx, n_ensemble);
        
        # Train individual LSTM with dropout for uncertainty
        [ensemble_models{ensemble_idx}, training_histories{ensemble_idx}] = ...
            train_single_lstm_model(X_train, y_train, X_val, y_val, lstm_architecture);
    end
    
    # Create Bayesian ensemble model
    trained_model = struct();
    trained_model.ensemble = ensemble_models;
    trained_model.architecture = lstm_architecture;
    trained_model.n_ensemble = n_ensemble;
    
    # Evaluate ensemble performance
    training_metrics = evaluate_ensemble_performance(trained_model, X_test, y_test);
    
    fprintf('Bayesian LSTM training completed with ensemble of %d models\n', n_ensemble);
end

% [Additional function implementations would continue...]

function generate_climate_adaptation_report(rul_predictions, climate_analysis, transfer_analysis, decision_support)
    % Generate comprehensive climate adaptation report
    
    fprintf('\n=== CLIMATE-ADAPTIVE INFRASTRUCTURE RUL PREDICTION REPORT ===\n');
    fprintf('=============================================================\n\n');
    
    fprintf('EXECUTIVE SUMMARY\n');
    fprintf('-------\n');
    fprintf('This analysis presents climate-adaptive RUL predictions for critical infrastructure\n');
    fprintf('under accelerating climate change conditions. The LSTM-based approach incorporates\n');
    fprintf('non-stationary climate trends and provides uncertainty-quantified predictions.\n\n');
    
    # Report generation continues with detailed analysis...
    
    fprintf('=== END OF CLIMATE ADAPTATION REPORT ===\n\n');
end

% Save results function and other supporting functions would continue...
