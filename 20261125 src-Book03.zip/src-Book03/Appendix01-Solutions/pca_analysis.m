%% pca_analysis.m
% PCA Dimensionality Reduction
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : pca_analysis
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Principal Component Analysis for Dimensionality Reduction
% Author: Dr Leo Chen
% Version: R2023b
% Date: November 2024

function pca_dimensionality_reduction()
% Generate high-dimensional correlated dataset
rng(101); % Ensure reproducibility
num_samples = 300;
num_features = 50;

% Create correlation structure
base_signal = randn(num_samples, 5);
correlated_features = zeros(num_samples, num_features);

% Generate correlated features with different noise levels
for feature_idx = 1:num_features
    signal_weight = rand(1, 5);
    noise_level = 0.1 + 0.4 * rand();
    
    correlated_features(:, feature_idx) = ...
        base_signal * signal_weight' + noise_level * randn(num_samples, 1);
end

% Add some independent features
independent_features = 0.5 * randn(num_samples, 10);
full_dataset = [correlated_features, independent_features];

% Standardise the dataset
standardised_data = zscore(full_dataset);

% Perform PCA analysis
[principal_components, transformed_data, eigenvalues, ~, ...
    variance_explained] = pca(standardised_data);

% Calculate cumulative variance explained
cumulative_variance = cumsum(variance_explained);

% Determine number of components for 95% variance
variance_threshold = 95;
optimal_components = find(cumulative_variance >= variance_threshold, 1);

% Project data onto reduced dimensional space
reduced_data = transformed_data(:, 1:optimal_components);

% Reconstruct data from reduced representation
reconstructed_data = reduced_data * principal_components(:, 1:optimal_components)';

% Calculate reconstruction error
reconstruction_error = norm(standardised_data - reconstructed_data, 'fro') / ...
    norm(standardised_data, 'fro');

% Visualisation
figure('Name', 'PCA Analysis Results');

% Variance explained plot
subplot(2, 3, 1);
bar(1:20, variance_explained(1:20));
xlabel('Principal Component', 'Interpreter', 'latex');
ylabel('Variance Explained (\%)', 'Interpreter', 'latex');
title('Individual Component Variance', 'Interpreter', 'latex');
grid on;

% Cumulative variance plot
subplot(2, 3, 2);
plot(1:length(cumulative_variance), cumulative_variance, 'bo-', 'LineWidth', 2);
hold on;
plot([1, length(cumulative_variance)], [variance_threshold, variance_threshold], ...
    'r--', 'LineWidth', 2);
plot(optimal_components, variance_threshold, 'ro', 'MarkerSize', 10, ...
    'MarkerFaceColor', 'red');
xlabel('Number of Components', 'Interpreter', 'latex');
ylabel('Cumulative Variance Explained (\%)', 'Interpreter', 'latex');
title('Cumulative Variance Analysis', 'Interpreter', 'latex');
legend('Cumulative Variance', '95\% Threshold', 'Optimal Point', ...
    'Location', 'southeast');
grid on;

% Principal component weights heatmap
subplot(2, 3, 3);
imagesc(principal_components(:, 1:10)');
colorbar;
xlabel('Original Features', 'Interpreter', 'latex');
ylabel('Principal Components', 'Interpreter', 'latex');
title('PC Loadings Heatmap', 'Interpreter', 'latex');

% 2D projection of data
subplot(2, 3, 4);
scatter(transformed_data(:, 1), transformed_data(:, 2), 50, ...
    1:num_samples, 'filled');
xlabel('First Principal Component', 'Interpreter', 'latex');
ylabel('Second Principal Component', 'Interpreter', 'latex');
title('Data Projection (PC1 vs PC2)', 'Interpreter', 'latex');
colorbar;

% 3D projection of data
subplot(2, 3, 5);
scatter3(transformed_data(:, 1), transformed_data(:, 2), ...
    transformed_data(:, 3), 50, 1:num_samples, 'filled');
xlabel('PC1', 'Interpreter', 'latex');
ylabel('PC2', 'Interpreter', 'latex');
zlabel('PC3', 'Interpreter', 'latex');
title('3D Data Projection', 'Interpreter', 'latex');

% Reconstruction quality comparison
subplot(2, 3, 6);
sample_idx = 1:10;
plot(sample_idx, standardised_data(sample_idx, 1), 'bo-', ...
    'LineWidth', 2, 'DisplayName', 'Original');
hold on;
plot(sample_idx, reconstructed_data(sample_idx, 1), 'ro--', ...
    'LineWidth', 2, 'DisplayName', 'Reconstructed');
xlabel('Sample Index', 'Interpreter', 'latex');
ylabel('Feature Value', 'Interpreter', 'latex');
title('Reconstruction Quality (Feature 1)', 'Interpreter', 'latex');
legend('Location', 'best');
grid on;

% Display analysis results
fprintf('\\textbf{PCA Analysis Results}:\\n');
fprintf('Original Dimensions: %d\\n', size(full_dataset, 2));
fprintf('Reduced Dimensions: %d\\n', optimal_components);
fprintf('Variance Explained: %.2f%%\\n', cumulative_variance(optimal_components));
fprintf('Reconstruction Error: %.4f\\n', reconstruction_error);
fprintf('Dimensionality Reduction Ratio: %.2f%%\\n', ...
    (1 - optimal_components / size(full_dataset, 2)) * 100);

% Feature importance analysis
[~, feature_importance_indices] = sort(sum(abs(principal_components(:, 1:3)), 2), ...
    'descend');

fprintf('\\n\\textbf{Most Important Features (Top 5)}:\\n');
for rank = 1:5
    feature_idx = feature_importance_indices(rank);
    importance_score = sum(abs(principal_components(feature_idx, 1:3)));
    fprintf('Feature %d: %.4f\\n', feature_idx, importance_score);
end

% Perform k-means clustering on reduced data
optimal_clusters = 3;
[cluster_indices, cluster_centroids] = kmeans(reduced_data, optimal_clusters);

% Visualise clustering in reduced space
figure('Name', 'Clustering in PCA Space');
scatter(transformed_data(:, 1), transformed_data(:, 2), 50, ...
    cluster_indices, 'filled');
hold on;
scatter(cluster_centroids(:, 1), cluster_centroids(:, 2), 200, ...
    'kx', 'LineWidth', 3, 'MarkerSize', 15);
xlabel('First Principal Component', 'Interpreter', 'latex');
ylabel('Second Principal Component', 'Interpreter', 'latex');
title('K-Means Clustering in PCA Space', 'Interpreter', 'latex');
colormap(lines(optimal_clusters));

% Calculate silhouette score for clustering
silhouette_values = silhouette(reduced_data, cluster_indices);
average_silhouette = mean(silhouette_values);

fprintf('\\n\\textbf{Clustering Performance in Reduced Space}:\\n');
fprintf('Number of Clusters: %d\\n', optimal_clusters);
fprintf('Average Silhouette Score: %.4f\\n', average_silhouette);

end
