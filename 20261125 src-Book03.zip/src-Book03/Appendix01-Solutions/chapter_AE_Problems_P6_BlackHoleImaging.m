%% chapter_AE_Problems_P6_BlackHoleImaging.m
% AI-enhanced black hole image reconstruction system.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AE_Problems_P6_BlackHoleImaging
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [reconstructedImage, uncertaintyMap, performanceMetrics] = aiBlackHoleImaging(visibilityData, uvCoverage, aiConfig, physicsConstraints)
    % AI-enhanced black hole image reconstruction using deep learning
    % Author: Dr Leo Chen
    % Version: 3.0.0 - Physics-informed neural networks implementation
    % Date: 2024-11-14
    
    fprintf('AI-Enhanced Black Hole Image Reconstruction\n');
    fprintf('Visibility measurements: %d, Baseline coverage: %.1f%%\n', ...
            length(visibilityData.amplitude), uvCoverage.completeness * 100);
    fprintf('Neural network architecture: %s\n', aiConfig.networkType);
    
    % Data preprocessing and augmentation
    [processedVisibilities, dataAugmentation] = preprocessVLBIData(visibilityData, uvCoverage, aiConfig);
    
    % Load or train deep learning model
    if aiConfig.usePretrainedModel
        fprintf('Loading pre-trained model: %s\n', aiConfig.modelPath);
        neuralNetwork = loadTrainedModel(aiConfig.modelPath);
    else
        fprintf('Training new neural network model...\n');
        [neuralNetwork, trainingResults] = trainBlackHoleReconstructionNetwork(processedVisibilities, aiConfig, physicsConstraints);
        
        fprintf('Training completed:\n');
        fprintf('  Epochs: %d, Final loss: %.6f\n', trainingResults.epochs, trainingResults.finalLoss);
        fprintf('  Training time: %.1f minutes\n', trainingResults.trainingTime / 60);
    end
    
    %% Phase 1: Primary Image Reconstruction
    
    % Initial reconstruction using traditional methods for comparison
    traditionalReconstruction = performTraditionalReconstruction(processedVisibilities, uvCoverage, 'CLEAN');
    
    % AI-based reconstruction
    fprintf('Performing AI-based image reconstruction...\n');
    [aiReconstruction, latentFeatures] = performAIReconstruction(neuralNetwork, processedVisibilities, aiConfig);
    
    % Physics-informed post-processing
    physicsConstrainedImage = applyPhysicsConstraints(aiReconstruction, physicsConstraints);
    
    fprintf('Primary reconstruction completed\n');
    fprintf('  Image resolution: %d x %d pixels\n', size(physicsConstrainedImage));
    fprintf('  Dynamic range achieved: %.1f dB\n', calculateDynamicRange(physicsConstrainedImage));
    
    %% Phase 2: Super-Resolution Enhancement
    
    % Apply super-resolution neural network
    if aiConfig.enableSuperResolution
        fprintf('Applying super-resolution enhancement...\n');
        [superResImage, enhancementFactors] = applySuperResolution(physicsConstrainedImage, aiConfig.superResModel);
        reconstructedImage = superResImage;
        
        fprintf('Super-resolution applied: %dx enhancement\n', enhancementFactors.spatialFactor);
    else
        reconstructedImage = physicsConstrainedImage;
    end
    
    %% Phase 3: Uncertainty Quantification
    
    % Bayesian neural network inference for uncertainty estimation
    fprintf('Calculating reconstruction uncertainty...\n');
    [uncertaintyMap, confidenceIntervals] = calculateBayesianUncertainty(neuralNetwork, processedVisibilities, aiConfig);
    
    % Monte Carlo dropout for additional uncertainty estimation
    [mcUncertainty, ensemblePredictions] = performMonteCarloDropout(neuralNetwork, processedVisibilities, aiConfig);
    
    % Combine uncertainty estimates
    combinedUncertainty = combineUncertaintyEstimates(uncertaintyMap, mcUncertainty, aiConfig);
    
    fprintf('Uncertainty quantification completed\n');
    fprintf('  Mean uncertainty: %.2f%% of peak intensity\n', mean(combinedUncertainty(:)) * 100);
    fprintf('  Confidence interval coverage: %.1f%%\n', confidenceIntervals.coverage * 100);
    
    %% Phase 4: Feature Detection and Analysis
    
    % Detect black hole features using AI
    [detectedFeatures, featureConfidence] = detectBlackHoleFeatures(reconstructedImage, aiConfig.featureDetector);
    
    % Photon ring analysis
    [photonRingParameters, ringUncertainty] = analysePhotonRing(reconstructedImage, uncertaintyMap, physicsConstraints);
    
    % Shadow diameter measurement
    [shadowDiameter, shadowUncertainty] = measureBlackHoleShadow(reconstructedImage, uncertaintyMap, physicsConstraints);
    
    fprintf('Feature analysis completed\n');
    fprintf('  Photon ring detected: %s (confidence: %.1f%%)\n', ...
            detectedFeatures.photonRing ? 'Yes' : 'No', featureConfidence.photonRing * 100);
    fprintf('  Shadow diameter: %.1f -- %.1f --as\n', shadowDiameter.value, shadowUncertainty.sigma);
    
    %% Phase 5: Physical Parameter Estimation
    
    % Estimate black hole parameters using AI-assisted methods
    [blackHoleParameters, parameterUncertainties] = estimateBlackHoleParameters(reconstructedImage, uncertaintyMap, physicsConstraints);
    
    % Validate against general relativity predictions
    grValidation = validateAgainstGR(blackHoleParameters, physicsConstraints.expectedValues);
    
    fprintf('Physical parameter estimation completed\n');
    fprintf('  Estimated mass: %.2e -- %.2e solar masses\n', ...
            blackHoleParameters.mass.value, parameterUncertainties.mass.sigma);
    fprintf('  Estimated spin: %.3f -- %.3f\n', ...
            blackHoleParameters.spin.value, parameterUncertainties.spin.sigma);
    
    %% Phase 6: Comparative Analysis and Validation
    
    % Compare with traditional reconstruction methods
    comparisonResults = compareReconstructionMethods(reconstructedImage, traditionalReconstruction, visibilityData);
    
    % Validate against synthetic data if available
    if isfield(aiConfig, 'groundTruthImage')
        validationMetrics = validateAgainstGroundTruth(reconstructedImage, aiConfig.groundTruthImage);
        fprintf('Ground truth validation:\n');
        fprintf('  SSIM: %.4f, PSNR: %.2f dB\n', validationMetrics.ssim, validationMetrics.psnr);
    end
    
    %% Phase 7: Results Compilation
    
    performanceMetrics = struct();
    performanceMetrics.reconstructionQuality = comparisonResults;
    performanceMetrics.uncertaintyAnalysis = struct('uncertaintyMap', combinedUncertainty, 'confidenceIntervals', confidenceIntervals);
    performanceMetrics.featureDetection = detectedFeatures;
    performanceMetrics.physicalParameters = blackHoleParameters;
    performanceMetrics.parameterUncertainties = parameterUncertainties;
    performanceMetrics.grValidation = grValidation;
    
    if isfield(aiConfig, 'groundTruthImage')
        performanceMetrics.validationMetrics = validationMetrics;
    end
    
    %% Phase 8: Comprehensive visualisation
    
    fprintf('Creating comprehensive black hole imaging analysis...\n');
    
    % Create visualisation figure
    figure('Name', 'AI-Enhanced Black Hole Image Reconstruction', 'Position', [100, 100, 1600, 1200]);
    
    % Original reconstructed image
    subplot(3,4,1);
    imagesc(reconstructedImage);
    axis equal; axis tight; colormap hot; colorbar;
    title('AI-Reconstructed Image');
    xlabel('RA (--as)'); ylabel('Dec (--as)');
    
    % Traditional reconstruction comparison
    subplot(3,4,2);
    imagesc(traditionalReconstruction);
    axis equal; axis tight; colormap hot; colorbar;
    title('Traditional Reconstruction (CLEAN)');
    xlabel('RA (--as)'); ylabel('Dec (--as)');
    
    % Uncertainty map
    subplot(3,4,3);
    imagesc(uncertaintyMap);
    axis equal; axis tight; colormap gray; colorbar;
    title('Reconstruction Uncertainty');
    xlabel('RA (--as)'); ylabel('Dec (--as)');
    
    % UV coverage
    subplot(3,4,4);
    scatter(uvCoverage.u, uvCoverage.v, 10, 'filled');
    axis equal; xlabel('u (M--)'); ylabel('v (M--)');
    title('UV Coverage');
    grid on;
    
    % Radial intensity profile
    subplot(3,4,5);
    radialProfile = calculateRadialProfile(reconstructedImage);
    plot(radialProfile.radius, radialProfile.intensity, 'b-', 'LineWidth', 2);
    xlabel('Radius (--as)'); ylabel('Normalized Intensity');
    title('Radial Intensity Profile'); grid on;
    
    % Feature detection overlay
    subplot(3,4,6);
    overlayImage = overlayDetectedFeatures(reconstructedImage, detectedFeatures);
    imagesc(overlayImage);
    axis equal; axis tight; colorbar;
    title('Detected Features Overlay');
    
    % Comparison metrics
    subplot(3,4,7);
    metrics = [comparisonResults.ssim, comparisonResults.imageQuality, comparisonResults.featureFidelity] * 100;
    metricLabels = {'SSIM', 'Quality', 'Features'};
    bar(metrics);
    set(gca, 'XTickLabel', metricLabels);
    ylabel('Score (%)'); title('Reconstruction Quality');
    ylim([0, 100]); grid on;
    
    % Parameter estimation results
    subplot(3,4,8);
    if ~isempty(blackHoleParameters)
        paramValues = [blackHoleParameters.mass.normalized, blackHoleParameters.spin.value, ...
                      blackHoleParameters.inclination.value] * 100;
        paramLabels = {'Mass', 'Spin', 'Inclination'};
        
        bar(paramValues);
        set(gca, 'XTickLabel', paramLabels);
        ylabel('Normalized Value (%)'); title('Physical Parameters');
        grid on;
    end
    
    % Training convergence (if available)
    subplot(3,4,9);
    if exist('trainingResults', 'var')
        plot(trainingResults.epochHistory, trainingResults.lossHistory, 'r-', 'LineWidth', 2);
        xlabel('Epoch'); ylabel('Loss'); title('Training Convergence');
        grid on; set(gca, 'YScale', 'log');
    end
    
    % Uncertainty distribution
    subplot(3,4,10);
    histogram(uncertaintyMap(:), 30, 'FaceColor', 'blue', 'EdgeColor', 'black');
    xlabel('Uncertainty Level'); ylabel('Pixel Count'); title('Uncertainty Distribution');
    grid on;
    
    % Visibility amplitude comparison
    subplot(3,4,11);
    if isfield(comparisonResults, 'visibilityComparison')
        visComp = comparisonResults.visibilityComparison;
        scatter(visComp.observedAmplitude, visComp.modelAmplitude, 20, 'filled');
        xlabel('Observed Amplitude'); ylabel('Model Amplitude');
        title('Visibility Amplitude Fit'); grid on;
        
        % Perfect fit line
        maxAmp = max([visComp.observedAmplitude; visComp.modelAmplitude]);
        line([0, maxAmp], [0, maxAmp], 'Color', 'red', 'LineStyle', '--');
    end
    
    % Overall performance summary
    subplot(3,4,12);
    overallScores = [performanceMetrics.reconstructionQuality.overallScore, ...
                    performanceMetrics.uncertaintyAnalysis.reliability, ...
                    performanceMetrics.featureDetection.overallConfidence] * 100;
    scoreLabels = {'Reconstruction', 'Uncertainty', 'Features'};
    
    bar(overallScores, 'FaceColor', 'gold');
    set(gca, 'XTickLabel', scoreLabels);
    ylabel('Performance Score (%)'); title('Overall Performance');
    ylim([0, 100]); grid on;
    
    sgtitle('AI-Enhanced Black Hole Image Reconstruction: Comprehensive Analysis');
    
    fprintf('\nAI-enhanced black hole imaging completed successfully!\n');
    fprintf('Summary of results:\n');
    fprintf('  Image quality improvement: %.1fx over traditional methods\n', comparisonResults.improvementFactor);
    fprintf('  Feature detection confidence: %.1f%%\n', mean(cell2mat(struct2cell(featureConfidence))) * 100);
    fprintf('  Physical parameter accuracy: %.1f%% (validated against GR)\n', grValidation.overallAccuracy * 100);
    fprintf('  Reconstruction uncertainty: %.1f%% average\n', mean(uncertaintyMap(:)) * 100);
    
end

% Helper functions for AI black hole imaging

function [processedData, augmentation] = preprocessVLBIData(visibilityData, uvCoverage, config)
    % Preprocess VLBI data for neural network input
    
    % Normalize visibility amplitudes
    maxAmplitude = max(visibilityData.amplitude);
    normalizedAmplitudes = visibilityData.amplitude / maxAmplitude;
    
    % Handle missing UV data through interpolation
    [interpolatedUV, interpolationMask] = interpolateMissingUV(uvCoverage, config);
    
    % Data augmentation through rotation and noise addition
    augmentation = struct();
    if config.enableAugmentation
        augmentation.rotationAngles = 0:15:345;  % Every 15 degrees
        augmentation.noiseLevel = config.augmentationNoise;
        augmentation.enabled = true;
    else
        augmentation.enabled = false;
    end
    
    processedData = struct();
    processedData.amplitudes = normalizedAmplitudes;
    processedData.phases = visibilityData.phase;
    processedData.uvCoordinates = interpolatedUV;
    processedData.weights = visibilityData.weights;
    processedData.normalizationFactor = maxAmplitude;
    
    fprintf('Data preprocessing completed\n');
    fprintf('  Visibility points: %d, UV coverage: %.1f%%\n', ...
            length(normalizedAmplitudes), sum(interpolationMask) / length(interpolationMask) * 100);
end

function [trainedNetwork, results] = trainBlackHoleReconstructionNetwork(trainingData, config, constraints)
    % Train deep neural network for black hole image reconstruction
    
    % Define network architecture
    switch config.networkType
        case 'CNN'
            network = createCNNArchitecture(config.networkParams);
        case 'GAN'
            network = createGANArchitecture(config.networkParams);
        case 'Transformer'
            network = createTransformerArchitecture(config.networkParams);
        case 'PhysicsInformed'
            network = createPhysicsInformedNetwork(config.networkParams, constraints);
    end
    
    % Training parameters
    maxEpochs = config.training.maxEpochs;
    learningRate = config.training.learningRate;
    batchSize = config.training.batchSize;
    
    % Loss function including physics constraints
    lossFunction = @(predicted, target) calculatePhysicsInformedLoss(predicted, target, constraints, config);
    
    results = struct();
    results.epochHistory = [];
    results.lossHistory = [];
    
    fprintf('Starting neural network training...\n');
    startTime = tic;
    
    % Training loop (simplified representation)
    for epoch = 1:maxEpochs
        epochLoss = 0;
        numBatches = ceil(size(trainingData.inputs, 1) / batchSize);
        
        for batch = 1:numBatches
            % Extract batch data
            startIdx = (batch - 1) * batchSize + 1;
            endIdx = min(batch * batchSize, size(trainingData.inputs, 1));
            
            batchInputs = trainingData.inputs(startIdx:endIdx, :);
            batchTargets = trainingData.targets(startIdx:endIdx, :);
            
            % Forward pass (simplified)
            predictions = networkForward(network, batchInputs);
            
            % Calculate loss
            batchLoss = lossFunction(predictions, batchTargets);
            epochLoss = epochLoss + batchLoss;
            
            % Backward pass and parameter update (simplified)
            network = updateNetworkParameters(network, batchLoss, learningRate);
        end
        
        avgEpochLoss = epochLoss / numBatches;
        results.epochHistory(end + 1) = epoch;
        results.lossHistory(end + 1) = avgEpochLoss;
        
        if mod(epoch, 50) == 0
            fprintf('  Epoch %d/%d: Loss = %.6f\n', epoch, maxEpochs, avgEpochLoss);
        end
    end
    
    trainingTime = toc(startTime);
    results.trainingTime = trainingTime;
    results.finalLoss = results.lossHistory(end);
    results.epochs = maxEpochs;
    
    trainedNetwork = network;
    
    fprintf('Neural network training completed in %.1f minutes\n', trainingTime / 60);
end
