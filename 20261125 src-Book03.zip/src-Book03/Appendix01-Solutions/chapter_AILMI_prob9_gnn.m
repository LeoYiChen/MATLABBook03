%% chapter_AILMI_prob9_gnn.m
% Graph neural network for relationship reasoning.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AILMI_prob9_gnn
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function refinedFeatures = relationshipGNN(regionFeatures, spatialGraph, ...
                                           edgeFeatures, gnnWeights, numLayers)
    % Apply GNN to reason about object relationships
    % regionFeatures: [numRegions x featureDim]
    % spatialGraph: [numRegions x numRegions] adjacency matrix
    % edgeFeatures: [numEdges x edgeDim] spatial relationship features
    
    numRegions = size(regionFeatures, 1);
    featureDim = size(regionFeatures, 2);
    
    h = regionFeatures; % Current node representations
    
    % Multi-layer message passing
    for layer = 1:numLayers
        hNew = zeros(numRegions, featureDim);
        
        for i = 1:numRegions
            % Find neighbours
            neighbours = find(spatialGraph(i, :));
            
            if isempty(neighbours)
                hNew(i, :) = h(i, :);
                continue;
            end
            
            % Aggregate messages from neighbours
            messages = zeros(length(neighbours), featureDim);
            for k = 1:length(neighbours)
                j = neighbours(k);
                
                % Get edge features
                edgeIdx = findEdgeIndex(i, j, spatialGraph);
                e_ij = edgeFeatures(edgeIdx, :);
                
                % Compute message
                combined = [h(i, :), h(j, :), e_ij];
                messages(k, :) = relu(gnnWeights.edge{layer} * combined')';
            end
            
            % Aggregate (sum pooling)
            aggregated = sum(messages, 1);
            
            % Update node representation
            combined = [h(i, :), aggregated];
            hNew(i, :) = relu(gnnWeights.node{layer} * combined')';
        end
        
        h = hNew;
    end
    
    refinedFeatures = h;
end

function relu(x)
    relu = max(0, x);
end
