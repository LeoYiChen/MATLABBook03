%% lst_sol04_syntax_vgg.m
% Extracting VGG-19 activations.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : lst:sol04_syntax_vgg
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
vggNet = vgg19;
contentActivations = activations(vggNet, ...
    contentImage, contentLayerName);
styleActivations   = activations(vggNet, ...
    styleImage, styleLayerName);
