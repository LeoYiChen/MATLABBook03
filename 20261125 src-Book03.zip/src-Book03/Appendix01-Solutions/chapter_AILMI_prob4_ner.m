%% chapter_AILMI_prob4_ner.m
% BiLSTM-CRF for named entity recognition.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AILMI_prob4_ner
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [entityTags, score] = viterbiDecode(emissions, transitions, seqLength)
    % Viterbi algorithm for CRF decoding
    % emissions: [seqLength x numTags] log probabilities
    % transitions: [numTags x numTags] transition scores
    
    numTags = size(emissions, 2);
    
    % Forward pass: compute max scores
    delta = zeros(seqLength, numTags);
    psi = zeros(seqLength, numTags);
    
    % Initialisation
    delta(1, :) = emissions(1, :);
    
    % Recursion
    for t = 2:seqLength
        for j = 1:numTags
            [maxScore, maxIdx] = max(delta(t-1, :) + transitions(:, j)');
            delta(t, j) = maxScore + emissions(t, j);
            psi(t, j) = maxIdx;
        end
    end
    
    % Backward pass: traceback best path
    entityTags = zeros(seqLength, 1);
    [score, entityTags(seqLength)] = max(delta(seqLength, :));
    
    for t = seqLength-1:-1:1
        entityTags(t) = psi(t+1, entityTags(t+1));
    end
end
