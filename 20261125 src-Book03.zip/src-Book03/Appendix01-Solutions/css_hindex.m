%% css_hindex.m
% h-index computation in base MATLAB.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : css_hindex
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [hIndex, totalCitations] = computeHIndex(citationCounts)
% computeHIndex  h-index from a vector of per-paper citation counts.
%   [hIndex, totalCitations] = computeHIndex(citationCounts)
%   Author: Dr Leo Chen | Version 1.0 | Base MATLAB (R2021b+)

    sortedCitations = sort(citationCounts(:), 'descend');
    ranks = (1:numel(sortedCitations))';
    hIndex = max([0; ranks(sortedCitations >= ranks)]);
    totalCitations = sum(citationCounts);

    fprintf('h-index = %d | total citations = %d\n', hIndex, totalCitations);
end
