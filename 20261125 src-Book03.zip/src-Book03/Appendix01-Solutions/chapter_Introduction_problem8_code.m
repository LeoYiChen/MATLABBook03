%% chapter_Introduction_problem8_code.m
% Digital twin prototype implementation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_Introduction_problem8_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% MATLABBook03_Chapter01_Problem08.m
% Digital Twin Prototype
% This script implements a simplified digital twin for a water tank system
% and demonstrates principles applicable across domains

%% Setup and Configuration
clear;
clc;
close all;
rng(42); % For reproducibility

% Simulation parameters
sim_time = 1000;        % Total simulation time (seconds)
dt = 0.1;               % Time step (seconds)
time_vec = 0:dt:sim_time;  % Time vector
n_steps = length(time_vec); % Number of time steps

% visualisation options
vis_interval = 10;      % Visualize every X time steps
plot_interval = 100;    % Plot data every X time steps

%% 1. PHYSICAL SYSTEM MODEL - Water Tank with Inflow and Outflow
% The system consists of a water tank with:
% - Controlled inflow (can be adjusted)
% - Outflow through a valve (depends on water level)
% - Temperature (affected by inflow temperature and ambient temperature)
% - Concentration of a dissolved substance (affected by inflow concentration and mixing)

% Define the system class
classdef WaterTankSystem < handle
    properties
        % Tank properties
        TankHeight      % Maximum height of water in tank (m)
        TankRadius      % Radius of the tank (m)
        TankArea        % Cross-sectional area of the tank (m^2)
        TankVolume      % Maximum volume of the tank (m^3)
        
        % State variables
        WaterLevel      % Current water level (m)
        Temperature     % Current water temperature (--C)
        Concentration   % Current concentration of dissolved substance (g/L)
        
        % Control inputs
        InflowRate      % Rate of water flowing in (m^3/s)
        ValveOpening    % Outflow valve opening (0-1, where 1 is fully open)
        InflowTemp      % Temperature of inflowing water (--C)
        InflowConc      % Concentration in inflowing water (g/L)
        
        % Environmental variables
        AmbientTemp     % Ambient temperature (--C)
        
        % Physical constants
        Gravity         % Acceleration due to gravity (m/s^2)
        OutflowCoeff    % Outflow coefficient for the valve
        HeatTransferCoeff % Heat transfer coefficient with ambient (W/m^2--K)
        MixingCoeff     % Mixing coefficient for concentration
        
        % History tracking
        TimeHistory
        StateHistory
        ControlHistory
        EnvironmentHistory
    end
    
    methods
        % Constructor
        function obj = WaterTankSystem(tankHeight, tankRadius)
            % Set tank properties
            obj.TankHeight = tankHeight;
            obj.TankRadius = tankRadius;
            obj.TankArea = pi * tankRadius^2;
            obj.TankVolume = obj.TankArea * tankHeight;
            
            % Initialize state variables
            obj.WaterLevel = 0;
            obj.Temperature = 20;
            obj.Concentration = 0;
            
            % Initialize control inputs
            obj.InflowRate = 0;
            obj.ValveOpening = 0;
            obj.InflowTemp = 20;
            obj.InflowConc = 0;
            
            % Initialize environmental variables
            obj.AmbientTemp = 20;
            
            % Set physical constants
            obj.Gravity = 9.81;
            obj.OutflowCoeff = 0.6;
            obj.HeatTransferCoeff = 10;
            obj.MixingCoeff = 0.8;
            
            % Initialize history tracking
            obj.TimeHistory = 0;
            obj.StateHistory = [obj.WaterLevel; obj.Temperature; obj.Concentration];
            obj.ControlHistory = [obj.InflowRate; obj.ValveOpening; obj.InflowTemp; obj.InflowConc];
            obj.EnvironmentHistory = obj.AmbientTemp;
        end
        
        % Update the system state based on dynamics
        function update(obj, dt, time)
            % Calculate outflow rate based on water level and valve opening
            if obj.WaterLevel > 0
                outflowRate = obj.ValveOpening * obj.OutflowCoeff * ...
                              obj.TankArea * sqrt(2 * obj.Gravity * obj.WaterLevel);
            else
                outflowRate = 0;
            end
            
            % Update water level
            waterLevelChange = (obj.InflowRate - outflowRate) * dt / obj.TankArea;
            newWaterLevel = obj.WaterLevel + waterLevelChange;
            
            % Ensure water level stays within bounds (0 to tank height)
            newWaterLevel = max(0, min(newWaterLevel, obj.TankHeight));
            
            % Calculate current volume
            currentVolume = obj.TankArea * obj.WaterLevel;
            newVolume = obj.TankArea * newWaterLevel;
            
            % Update temperature
            % Temperature change due to inflow
            if obj.InflowRate > 0 && currentVolume > 0
                inflow_temp_change = (obj.InflowRate * dt / currentVolume) * ...
                                   (obj.InflowTemp - obj.Temperature);
            else
                inflow_temp_change = 0;
            end
            
            % Temperature change due to ambient heat transfer
            surface_area = obj.TankArea + 2 * pi * obj.TankRadius * obj.WaterLevel;
            ambient_temp_change = obj.HeatTransferCoeff * surface_area * ...
                                (obj.AmbientTemp - obj.Temperature) * dt / ...
                                (4184 * 1000 * currentVolume + 1e-10); % Water heat capacity * density
            
            newTemperature = obj.Temperature + inflow_temp_change + ambient_temp_change;
            
            % Update concentration
            % Concentration change due to inflow
            if obj.InflowRate > 0 && currentVolume > 0
                mass_in = obj.InflowRate * dt * obj.InflowConc;
                mass_out = outflowRate * dt * obj.Concentration;
                new_mass = currentVolume * obj.Concentration + mass_in - mass_out;
                newConcentration = new_mass / (newVolume + 1e-10);
            else
                newConcentration = obj.Concentration;
            end
            
            % Apply mixing (incomplete mixing model)
            newConcentration = obj.MixingCoeff * newConcentration + ...
                             (1 - obj.MixingCoeff) * obj.Concentration;
            
            % Update state variables
            obj.WaterLevel = newWaterLevel;
            obj.Temperature = newTemperature;
            obj.Concentration = newConcentration;
            
            % Update history
            obj.TimeHistory = [obj.TimeHistory, time];
            obj.StateHistory = [obj.StateHistory, [obj.WaterLevel; obj.Temperature; obj.Concentration]];
            obj.ControlHistory = [obj.ControlHistory, [obj.InflowRate; obj.ValveOpening; obj.InflowTemp; obj.InflowConc]];
            obj.EnvironmentHistory = [obj.EnvironmentHistory, obj.AmbientTemp];
        end
        
        % Get current state vector
        function state = getState(obj)
            state = [obj.WaterLevel; obj.Temperature; obj.Concentration];
        end
        
        % Set control inputs
        function setControls(obj, inflowRate, valveOpening, inflowTemp, inflowConc)
            obj.InflowRate = inflowRate;
            obj.ValveOpening = valveOpening;
            obj.InflowTemp = inflowTemp;
            obj.InflowConc = inflowConc;
        end
        
        % Set ambient temperature
        function setAmbientTemp(obj, ambientTemp)
            obj.AmbientTemp = ambientTemp;
        end
    end
end

%% 2. SENSOR MODEL - Generate Measurements with Realistic Noise
% The sensor model simulates measurements from the physical system with 
% realistic noise characteristics

classdef SensorModel < handle
    properties
        % Reference to the physical system
        PhysicalSystem
        
        % Sensor characteristics
        LevelSensorNoise      % Standard deviation of level sensor noise (m)
        TempSensorNoise       % Standard deviation of temperature sensor noise (--C)
        ConcSensorNoise       % Standard deviation of concentration sensor noise (g/L)
        
        % Sensor biases
        LevelSensorBias       % Bias in level sensor (m)
        TempSensorBias        % Bias in temperature sensor (--C)
        ConcSensorBias        % Bias in concentration sensor (g/L)
        
        % Sensor failures
        LevelSensorFailureProb  % Probability of level sensor failure per time step
        TempSensorFailureProb   % Probability of temperature sensor failure per time step
        ConcSensorFailureProb   % Probability of concentration sensor failure per time step
        
        % Current sensor status (0 = failed, 1 = working)
        LevelSensorStatus
        TempSensorStatus
        ConcSensorStatus
        
        % Measurement history
        TimeHistory
        MeasurementHistory
    end
    
    methods
        % Constructor
        function obj = SensorModel(physicalSystem)
            obj.PhysicalSystem = physicalSystem;
            
            % Set sensor noise characteristics
            obj.LevelSensorNoise = 0.01;   % 1 cm noise
            obj.TempSensorNoise = 0.2;     % 0.2--C noise
            obj.ConcSensorNoise = 0.05;    % 0.05 g/L noise
            
            % Set sensor biases
            obj.LevelSensorBias = 0.005;   % 0.5 cm bias
            obj.TempSensorBias = -0.1;     % -0.1--C bias
            obj.ConcSensorBias = 0.02;     % 0.02 g/L bias
            
            % Set sensor failure probabilities
            obj.LevelSensorFailureProb = 0.001;  % 0.1% chance of failure per time step
            obj.TempSensorFailureProb = 0.0005;  % 0.05% chance of failure per time step
            obj.ConcSensorFailureProb = 0.002;   % 0.2% chance of failure per time step
            
            % Initialize sensor status (all working)
            obj.LevelSensorStatus = 1;
            obj.TempSensorStatus = 1;
            obj.ConcSensorStatus = 1;
            
            % Initialize measurement history
            obj.TimeHistory = 0;
            obj.MeasurementHistory = [NaN; NaN; NaN];  % NaN for no measurement initially
        end
        
        % Get measurements from sensors
        function [measurements, valid] = getMeasurements(obj, time)
            % Get true state from physical system
            trueState = obj.PhysicalSystem.getState();
            
            % Update sensor status (random failures)
            if rand() < obj.LevelSensorFailureProb
                obj.LevelSensorStatus = 0;  % Sensor fails
            elseif rand() < 0.1 && obj.LevelSensorStatus == 0
                obj.LevelSensorStatus = 1;  % Sensor recovers
            end
            
            if rand() < obj.TempSensorFailureProb
                obj.TempSensorStatus = 0;  % Sensor fails
            elseif rand() < 0.1 && obj.TempSensorStatus == 0
                obj.TempSensorStatus = 1;  % Sensor recovers
            end
            
            if rand() < obj.ConcSensorFailureProb
                obj.ConcSensorStatus = 0;  % Sensor fails
            elseif rand() < 0.1 && obj.ConcSensorStatus == 0
                obj.ConcSensorStatus = 1;  % Sensor recovers
            end
            
            % Initialize measurements and valid flags
            measurements = zeros(3, 1);
            valid = [obj.LevelSensorStatus; obj.TempSensorStatus; obj.ConcSensorStatus];
            
            % Generate measurements with noise and bias
            if obj.LevelSensorStatus
                measurements(1) = trueState(1) + obj.LevelSensorBias + ...
                                 obj.LevelSensorNoise * randn();
            else
                measurements(1) = NaN;  % No measurement if sensor failed
            end
            
            if obj.TempSensorStatus
                measurements(2) = trueState(2) + obj.TempSensorBias + ...
                                 obj.TempSensorNoise * randn();
            else
                measurements(2) = NaN;  % No measurement if sensor failed
            end
            
            if obj.ConcSensorStatus
                measurements(3) = trueState(3) + obj.ConcSensorBias + ...
                                 obj.ConcSensorNoise * randn();
            else
                measurements(3) = NaN;  % No measurement if sensor failed
            end
            
            % Update measurement history
            obj.TimeHistory = [obj.TimeHistory, time];
            obj.MeasurementHistory = [obj.MeasurementHistory, measurements];
        end
    end
end

%% 3. DIGITAL TWIN MODEL - Virtual Representation with State Estimation
% The digital twin tracks the physical system, uses sensor data to update
% its state estimate, and provides predictions and anomaly detection

classdef DigitalTwin < handle
    properties
        % Reference to the physical system and sensor model
        PhysicalSystem
        SensorModel
        
        % State estimation variables
        StateEstimate       % Current estimated state [level; temperature; concentration]
        StateCovariance     % Covariance matrix for state estimate
        
        % System model matrices
        A                   % State transition matrix
        B                   % Control input matrix
        C                   % Measurement matrix
        Q                   % Process noise covariance
        R                   % Measurement noise covariance
        
        % Control inputs
        ControlInputs       % Current control inputs
        
        % Prediction horizon (number of time steps)
        PredictionHorizon
        
        % Anomaly detection thresholds
        LevelThreshold      % Threshold for level anomalies (m)
        TempThreshold       % Threshold for temperature anomalies (--C)
        ConcThreshold       % Threshold for concentration anomalies (g/L)
        
        % History tracking
        TimeHistory
        EstimatedStateHistory
        PredictedStateHistory
        AnomalyHistory
    end
    
    methods
        % Constructor
        function obj = DigitalTwin(physicalSystem, sensorModel)
            obj.PhysicalSystem = physicalSystem;
            obj.SensorModel = sensorModel;
            
            % Initialize state estimate with some uncertainty
            initialState = physicalSystem.getState();
            obj.StateEstimate = initialState;
            obj.StateCovariance = diag([0.02^2, 0.5^2, 0.1^2]);  % Initial uncertainty
            
            % Initialize system model matrices (simplified linear model)
            obj.A = eye(3);  % State transition (will be updated dynamically)
            obj.B = zeros(3, 4);  % Control input effect (will be updated dynamically)
            obj.C = eye(3);  % Measurement matrix (direct state measurements)
            
            % Process noise (uncertainty in system dynamics)
            obj.Q = diag([0.001^2, 0.05^2, 0.01^2]);
            
            % Measurement noise (from sensor characteristics)
            obj.R = diag([sensorModel.LevelSensorNoise^2, ...
                        sensorModel.TempSensorNoise^2, ...
                        sensorModel.ConcSensorNoise^2]);
            
            % Initialize control inputs
            obj.ControlInputs = [0; 0; 20; 0];  % [inflow; valve; inflow_temp; inflow_conc]
            
            % Set prediction horizon
            obj.PredictionHorizon = 100;  % Predict 100 time steps ahead
            
            % Set anomaly detection thresholds
            obj.LevelThreshold = 0.1;     % 10 cm difference is anomalous
            obj.TempThreshold = 2.0;      % 2--C difference is anomalous
            obj.ConcThreshold = 0.2;      % 0.2 g/L difference is anomalous
            
            % Initialize history tracking
            obj.TimeHistory = 0;
            obj.EstimatedStateHistory = initialState;
            obj.PredictedStateHistory = []; % Will be initialized at first prediction
            obj.AnomalyHistory = [0; 0; 0];  % No anomalies initially
        end
        
        % Update the system model matrices based on current state
        function updateSystemModel(obj, dt)
            % Get current state estimate
            level = obj.StateEstimate(1);
            temp = obj.StateEstimate(2);
            conc = obj.StateEstimate(3);
            
            % Get current control inputs
            inflow = obj.ControlInputs(1);
            valve = obj.ControlInputs(2);
            inflow_temp = obj.ControlInputs(3);
            inflow_conc = obj.ControlInputs(4);
            
            % Get physical parameters
            tank_area = obj.PhysicalSystem.TankArea;
            gravity = obj.PhysicalSystem.Gravity;
            outflow_coeff = obj.PhysicalSystem.OutflowCoeff;
            heat_transfer = obj.PhysicalSystem.HeatTransferCoeff;
            mixing_coeff = obj.PhysicalSystem.MixingCoeff;
            ambient_temp = obj.PhysicalSystem.AmbientTemp;
            
            % Update state transition matrix (linearized around current state)
            obj.A = eye(3);
            
            % Effect of water level on rate of change (outflow depends on level)
            if level > 0
                outflow_derivative = valve * outflow_coeff * tank_area * ...
                                   gravity / sqrt(2 * gravity * level);
                obj.A(1, 1) = 1 - dt * outflow_derivative / tank_area;
            end
            
            % Effect of temperature on heat transfer (higher temp = faster cooling)
            current_volume = tank_area * level + 1e-10;  % Avoid division by zero
            surface_area = tank_area + 2 * pi * obj.PhysicalSystem.TankRadius * level;
            obj.A(2, 2) = 1 - dt * heat_transfer * surface_area / (4184 * 1000 * current_volume);
            
            % Effect of concentration on outflow (higher conc = more mass leaving)
            if level > 0 && valve > 0
                outflow_rate = valve * outflow_coeff * tank_area * sqrt(2 * gravity * level);
                obj.A(3, 3) = 1 - dt * outflow_rate / current_volume;
            end
            
            % Update control input matrix
            obj.B = zeros(3, 4);
            
            % Effect of inflow on water level
            obj.B(1, 1) = dt / tank_area;
            
            % Effect of valve opening on water level
            if level > 0
                obj.B(1, 2) = -dt * outflow_coeff * tank_area * sqrt(2 * gravity * level) / tank_area;
            end
            
            % Effect of inflow rate and temperature on water temperature
            if current_volume > 0
                obj.B(2, 1) = dt * (inflow_temp - temp) / current_volume;
                obj.B(2, 3) = dt * inflow / current_volume;
            end
            
            % Effect of inflow rate and concentration on water concentration
            if current_volume > 0
                obj.B(3, 1) = dt * (inflow_conc - conc) / current_volume;
                obj.B(3, 4) = dt * inflow / current_volume;
            end
        end
        
        % Update state estimate using Kalman filter
        function updateStateEstimate(obj, measurements, valid, dt, time)
            % Update system model
            obj.updateSystemModel(dt);
            
            % Prediction step
            predicted_state = obj.A * obj.StateEstimate + obj.B * obj.ControlInputs;
            predicted_covariance = obj.A * obj.StateCovariance * obj.A' + obj.Q;
            
            % Update step (only for valid measurements)
            if any(valid)
                % Create measurement matrix for valid measurements only
                C_valid = obj.C(valid, :);
                R_valid = obj.R(valid, valid);
                z_valid = measurements(valid);
                
                % Kalman gain
                K = predicted_covariance * C_valid' / (C_valid * predicted_covariance * C_valid' + R_valid);
                
                % Update state estimate
                innovation = z_valid - C_valid * predicted_state;
                obj.StateEstimate = predicted_state + K * innovation;
                
                % Update covariance
                obj.StateCovariance = (eye(3) - K * C_valid) * predicted_covariance;
            else
                % No valid measurements, just use prediction
                obj.StateEstimate = predicted_state;
                obj.StateCovariance = predicted_covariance;
            end
            
            % Make sure estimates are physically valid
            obj.StateEstimate(1) = max(0, min(obj.StateEstimate(1), obj.PhysicalSystem.TankHeight));
            obj.StateEstimate(3) = max(0, obj.StateEstimate(3));
            
            % Update history
            obj.TimeHistory = [obj.TimeHistory, time];
            obj.EstimatedStateHistory = [obj.EstimatedStateHistory, obj.StateEstimate];
        end
        
        % Generate predictions for future states
        function [predicted_states, prediction_times] = predictFutureStates(obj, dt, horizon)
            if nargin < 3
                horizon = obj.PredictionHorizon;
            end
            
            % Initialize predictions
            predicted_states = zeros(3, horizon+1);
            predicted_states(:, 1) = obj.StateEstimate;
            
            prediction_times = obj.TimeHistory(end) + (0:horizon)*dt;
            
            % Simple forward simulation using current model
            current_state = obj.StateEstimate;
            
            % Update system model to current state
            obj.updateSystemModel(dt);
            
            % Predict future states
            for i = 1:horizon
                % Simple prediction using current model and inputs
                current_state = obj.A * current_state + obj.B * obj.ControlInputs;
                
                % Ensure predictions are physically valid
                current_state(1) = max(0, min(current_state(1), obj.PhysicalSystem.TankHeight));
                current_state(3) = max(0, current_state(3));
                
                predicted_states(:, i+1) = current_state;
            end
            
            % Update prediction history
            obj.PredictedStateHistory = predicted_states;
        end
        
        % Detect anomalies between estimated and measured state
        function anomalies = detectAnomalies(obj, measurements, valid)
            % Initialize anomaly flags (0 = normal, 1 = anomaly)
            anomalies = [0; 0; 0];
            
            % Check each state variable if measurement is valid
            if valid(1) && ~isnan(measurements(1))
                anomalies(1) = abs(measurements(1) - obj.StateEstimate(1)) > obj.LevelThreshold;
            end
            
            if valid(2) && ~isnan(measurements(2))
                anomalies(2) = abs(measurements(2) - obj.StateEstimate(2)) > obj.TempThreshold;
            end
            
            if valid(3) && ~isnan(measurements(3))
                anomalies(3) = abs(measurements(3) - obj.StateEstimate(3)) > obj.ConcThreshold;
            end
            
            % Update anomaly history
            obj.AnomalyHistory = [obj.AnomalyHistory, anomalies];
        end
        
        % Set control inputs for the digital twin
        function setControlInputs(obj, inflow, valve, inflow_temp, inflow_conc)
            obj.ControlInputs = [inflow; valve; inflow_temp; inflow_conc];
        end
    end
end

%% 4. SIMULATION SCENARIO
% Define a simulation scenario to demonstrate the digital twin

% Create the physical system (water tank)
tank = WaterTankSystem(2.0, 1.0);  % 2m high, 1m radius

% Create the sensor model
sensors = SensorModel(tank);

% Create the digital twin
twin = DigitalTwin(tank, sensors);

% Initialize arrays to store results
level_real = zeros(1, n_steps);
temp_real = zeros(1, n_steps);
conc_real = zeros(1, n_steps);

level_measured = nan(1, n_steps);
temp_measured = nan(1, n_steps);
conc_measured = nan(1, n_steps);

level_estimated = zeros(1, n_steps);
temp_estimated = zeros(1, n_steps);
conc_estimated = zeros(1, n_steps);

level_anomaly = zeros(1, n_steps);
temp_anomaly = zeros(1, n_steps);
conc_anomaly = zeros(1, n_steps);

% Control inputs over time
inflow_rate = zeros(1, n_steps);
valve_opening = zeros(1, n_steps);
inflow_temp = zeros(1, n_steps);
inflow_conc = zeros(1, n_steps);
ambient_temp = zeros(1, n_steps);

% Create control pattern (inflow rate varies over time)
for i = 1:n_steps
    t = time_vec(i);
    
    % Inflow rate pattern (m^3/s)
    if t < 200
        inflow_rate(i) = 0.02;  % Constant inflow
    elseif t < 400
        inflow_rate(i) = 0.01;  % Reduced inflow
    elseif t < 600
        inflow_rate(i) = 0.03;  % Increased inflow
    elseif t < 800
        inflow_rate(i) = 0.02 + 0.01 * sin(0.1 * t);  % Oscillating inflow
    else
        inflow_rate(i) = 0.02;  % Constant inflow
    end
    
    % Valve opening pattern (0-1)
    if t < 300
        valve_opening(i) = 0.3;  % Constant outflow
    elseif t < 500
        valve_opening(i) = 0.5;  % Increased outflow
    elseif t < 700
        valve_opening(i) = 0.2;  % Reduced outflow
    elseif t < 900
        valve_opening(i) = 0.4 + 0.2 * sin(0.05 * t);  % Oscillating outflow
    else
        valve_opening(i) = 0.3;  % Constant outflow
    end
    
    % Inflow temperature pattern (--C)
    if t < 250
        inflow_temp(i) = 15;  % Cool inflow
    elseif t < 450
        inflow_temp(i) = 25;  % Warm inflow
    elseif t < 650
        inflow_temp(i) = 20;  % Moderate inflow
    elseif t < 850
        inflow_temp(i) = 15 + 10 * sin(0.02 * t);  % Oscillating temperature
    else
        inflow_temp(i) = 20;  % Moderate inflow
    end
    
    % Inflow concentration pattern (g/L)
    if t < 350
        inflow_conc(i) = 0.5;  % Low concentration
    elseif t < 550
        inflow_conc(i) = 2.0;  % High concentration
    elseif t < 750
        inflow_conc(i) = 1.0;  % Medium concentration
    elseif t < 950
        inflow_conc(i) = 0.5 + 1.5 * sin(0.01 * t);  % Oscillating concentration
    else
        inflow_conc(i) = 1.0;  % Medium concentration
    end
    
    % Ambient temperature pattern (--C)
    ambient_temp(i) = 20 + 5 * sin(0.005 * t);  % Slowly oscillating ambient temperature
end

% Create a figure for real-time visualisation
figure('Position', [100, 100, 1200, 800], 'Name', 'Digital Twin Demonstration');

% Create visualisation function
function visualizeTankSystem(tank, sensors, twin, step, time)
    % Create layout
    subplot(2, 3, [1, 4]);
    
    % Visualize the tank
    tank_height = tank.TankHeight;
    tank_radius = tank.TankRadius;
    water_level = tank.WaterLevel;
    
    % Draw tank outline
    rectangle('Position', [-tank_radius, 0, 2*tank_radius, tank_height], ...
              'Curvature', [0, 0], 'LineWidth', 2, 'EdgeColor', 'k');
    
    % Draw water in tank
    rectangle('Position', [-tank_radius, 0, 2*tank_radius, water_level], ...
              'Curvature', [0, 0], 'FaceColor', [0.3, 0.5, 0.8, 0.7], 'EdgeColor', 'none');
    
    % Draw inflow pipe
    line([-tank_radius-0.5, -tank_radius], [tank_height*0.8, tank_height*0.8], ...
         'Color', 'b', 'LineWidth', 2);
    
    % Draw outflow pipe
    line([tank_radius, tank_radius+0.5], [0.1, 0.1], ...
         'Color', 'b', 'LineWidth', 2);
    
    % Draw valve
    rectangle('Position', [tank_radius, 0.05, 0.2, 0.1], ...
              'Curvature', [1, 1], 'FaceColor', 'r', 'EdgeColor', 'k');
    
    % Add flow indicators
    if tank.InflowRate > 0
        quiver(-tank_radius-0.3, tank_height*0.8, 0.2, 0, 'b', 'LineWidth', 1.5, 'MaxHeadSize', 1);
    end
    
    if tank.ValveOpening > 0 && tank.WaterLevel > 0
        quiver(tank_radius+0.1, 0.1, 0.2, 0, 'b', 'LineWidth', 1.5, 'MaxHeadSize', 1);
    end
    
    % Add text information
    text(-tank_radius-1.2, tank_height*0.9, sprintf('Inflow: %.2f m?/s', tank.InflowRate), ...
         'FontSize', 10);
    text(tank_radius+0.3, 0.2, sprintf('Valve: %.0f%%', tank.ValveOpening*100), ...
         'FontSize', 10);
    text(0, tank_height+0.1, sprintf('Water Level: %.2f m', water_level), ...
         'FontSize', 10, 'HorizontalAlignment', 'center');
    text(0, -0.2, sprintf('Temperature: %.1f--C', tank.Temperature), ...
         'FontSize', 10, 'HorizontalAlignment', 'center');
    text(0, -0.4, sprintf('Concentration: %.2f g/L', tank.Concentration), ...
         'FontSize', 10, 'HorizontalAlignment', 'center');
    
    % Set axis limits
    axis equal;
    xlim([-tank_radius-1.5, tank_radius+1.5]);
    ylim([-0.5, tank_height+0.5]);
    title(sprintf('Physical System (t = %.1f s)', time));
    
    % Remove axis ticks
    set(gca, 'XTick', [], 'YTick', []);
    
    % Digital Twin visualisation
    subplot(2, 3, [2, 5]);
    
    % Get estimated state
    est_water_level = twin.StateEstimate(1);
    est_temperature = twin.StateEstimate(2);
    est_concentration = twin.StateEstimate(3);
    
    % Draw digital twin outline (with slightly different style)
    rectangle('Position', [-tank_radius, 0, 2*tank_radius, tank_height], ...
              'Curvature', [0, 0], 'LineWidth', 2, 'EdgeColor', [0.5, 0.5, 0.5], ...
              'LineStyle', '--');
    
    % Draw estimated water level
    rectangle('Position', [-tank_radius, 0, 2*tank_radius, est_water_level], ...
              'Curvature', [0, 0], 'FaceColor', [0.2, 0.7, 0.9, 0.5], 'EdgeColor', 'none');
    
    % Add text information for digital twin
    text(-tank_radius-1.2, tank_height*0.9, sprintf('Est. Level: %.2f m', est_water_level), ...
         'FontSize', 10);
    text(-tank_radius-1.2, tank_height*0.8, sprintf('Est. Temp: %.1f--C', est_temperature), ...
         'FontSize', 10);
    text(-tank_radius-1.2, tank_height*0.7, sprintf('Est. Conc: %.2f g/L', est_concentration), ...
         'FontSize', 10);
    
    % Get and visualize future predictions if available
    if ~isempty(twin.PredictedStateHistory)
        pred_levels = twin.PredictedStateHistory(1, :);
        
        % Visualize predicted water level
        x_pred = linspace(-tank_radius+0.1, tank_radius-0.1, length(pred_levels));
        plot(x_pred, pred_levels, 'g--', 'LineWidth', 1.5);
        
        % Add text for prediction
        text(0, tank_height+0.1, sprintf('Predicted Level in 10s: %.2f m', pred_levels(end)), ...
             'FontSize', 10, 'HorizontalAlignment', 'center', 'Color', 'g');
    end
    
    % Check for anomalies and visualize them
    if any(twin.AnomalyHistory(:, end))
        anomalies = twin.AnomalyHistory(:, end);
        
        if anomalies(1) % Level anomaly
            text(0, est_water_level + 0.1, '!', 'Color', 'r', 'FontSize', 16, ...
                 'FontWeight', 'bold', 'HorizontalAlignment', 'center');
        end
        
        if anomalies(2) % Temperature anomaly
            text(-tank_radius/2, est_water_level/2, '!', 'Color', 'r', 'FontSize', 16, ...
                 'FontWeight', 'bold', 'HorizontalAlignment', 'center');
        end
        
        if anomalies(3) % Concentration anomaly
            text(tank_radius/2, est_water_level/2, '!', 'Color', 'r', 'FontSize', 16, ...
                 'FontWeight', 'bold', 'HorizontalAlignment', 'center');
        end
        
        text(0, -0.2, 'ANOMALY DETECTED', 'Color', 'r', 'FontSize', 12, ...
             'FontWeight', 'bold', 'HorizontalAlignment', 'center');
    end
    
    % Set axis limits (same as physical system)
    axis equal;
    xlim([-tank_radius-1.5, tank_radius+1.5]);
    ylim([-0.5, tank_height+0.5]);
    title('Digital Twin with Predictions');
    
    % Remove axis ticks
    set(gca, 'XTick', [], 'YTick', []);
    
    % Plot time series of water level
    subplot(2, 3, 3);
    plot(tank.TimeHistory, tank.StateHistory(1, :), 'b-', 'LineWidth', 1.5);
    hold on;
    
    % Plot measurements (with potential gaps for sensor failures)
    valid_measurements = ~isnan(sensors.MeasurementHistory(1, :));
    plot(sensors.TimeHistory(valid_measurements), ...
         sensors.MeasurementHistory(1, valid_measurements), 'rx', 'MarkerSize', 4);
    
    % Plot estimated water level
    plot(twin.TimeHistory, twin.EstimatedStateHistory(1, :), 'g-', 'LineWidth', 1.5);
    
    % Add current time marker
    plot([time, time], ylim, 'k--');
    
    title('Water Level Time Series');
    xlabel('Time (s)');
    ylabel('Water Level (m)');
    legend('True', 'Measured', 'Estimated', 'Location', 'best');
    grid on;
    hold off;
    
    % Plot time series of temperature
    subplot(2, 3, 6);
    plot(tank.TimeHistory, tank.StateHistory(2, :), 'b-', 'LineWidth', 1.5);
    hold on;
    
    % Plot measurements (with potential gaps for sensor failures)
    valid_measurements = ~isnan(sensors.MeasurementHistory(2, :));
    plot(sensors.TimeHistory(valid_measurements), ...
         sensors.MeasurementHistory(2, valid_measurements), 'rx', 'MarkerSize', 4);
    
    % Plot estimated temperature
    plot(twin.TimeHistory, twin.EstimatedStateHistory(2, :), 'g-', 'LineWidth', 1.5);
    
    % Add current time marker
    plot([time, time], ylim, 'k--');
    
    title('Temperature Time Series');
    xlabel('Time (s)');
    ylabel('Temperature (--C)');
    legend('True', 'Measured', 'Estimated', 'Location', 'best');
    grid on;
    hold off;
end

%% 5. RUN SIMULATION
for i = 1:n_steps
    % Current time
    t = time_vec(i);
    
    % Set control inputs for physical system
    tank.setControls(inflow_rate(i), valve_opening(i), inflow_temp(i), inflow_conc(i));
    tank.setAmbientTemp(ambient_temp(i));
    
    % Update physical system
    tank.update(dt, t);
    
    % Get measurements from sensors
    [measurements, valid] = sensors.getMeasurements(t);
    
    % Set control inputs for digital twin (same as physical system)
    twin.setControlInputs(inflow_rate(i), valve_opening(i), inflow_temp(i), inflow_conc(i));
    
    % Update digital twin state estimate
    twin.updateStateEstimate(measurements, valid, dt, t);
    
    % Detect anomalies
    anomalies = twin.detectAnomalies(measurements, valid);
    
    % Make predictions periodically
    if mod(i, 10) == 0
        [~, ~] = twin.predictFutureStates(dt);
    end
    
    % Store results
    level_real(i) = tank.WaterLevel;
    temp_real(i) = tank.Temperature;
    conc_real(i) = tank.Concentration;
    
    level_measured(i) = measurements(1);
    temp_measured(i) = measurements(2);
    conc_measured(i) = measurements(3);
    
    level_estimated(i) = twin.StateEstimate(1);
    temp_estimated(i) = twin.StateEstimate(2);
    conc_estimated(i) = twin.StateEstimate(3);
    
    level_anomaly(i) = anomalies(1);
    temp_anomaly(i) = anomalies(2);
    conc_anomaly(i) = anomalies(3);
    
    % Visualize every vis_interval steps
    if mod(i, vis_interval) == 0 || i == n_steps
        visualizeTankSystem(tank, sensors, twin, i, t);
        drawnow;
        pause(0.01);
    end
end

%% 6. ANALYSIS AND RESULTS
% Create analysis plots
figure('Position', [150, 150, 1200, 800], 'Name', 'Digital Twin Performance Analysis');

% Water level tracking
subplot(3, 2, 1);
plot(time_vec, level_real, 'b-', 'LineWidth', 1.5);
hold on;
plot(time_vec, level_measured, 'rx', 'MarkerSize', 3);
plot(time_vec, level_estimated, 'g-', 'LineWidth', 1.5);
title('Water Level Tracking');
xlabel('Time (s)');
ylabel('Water Level (m)');
legend('True', 'Measured', 'Estimated', 'Location', 'best');
grid on;

% Temperature tracking
subplot(3, 2, 2);
plot(time_vec, temp_real, 'b-', 'LineWidth', 1.5);
hold on;
plot(time_vec, temp_measured, 'rx', 'MarkerSize', 3);
plot(time_vec, temp_estimated, 'g-', 'LineWidth', 1.5);
plot(time_vec, ambient_temp, 'k--', 'LineWidth', 1);
title('Temperature Tracking');
xlabel('Time (s)');
ylabel('Temperature (--C)');
legend('True', 'Measured', 'Estimated', 'Ambient', 'Location', 'best');
grid on;

% Concentration tracking
subplot(3, 2, 3);
plot(time_vec, conc_real, 'b-', 'LineWidth', 1.5);
hold on;
plot(time_vec, conc_measured, 'rx', 'MarkerSize', 3);
plot(time_vec, conc_estimated, 'g-', 'LineWidth', 1.5);
title('Concentration Tracking');
xlabel('Time (s)');
ylabel('Concentration (g/L)');
legend('True', 'Measured', 'Estimated', 'Location', 'best');
grid on;

% Estimation error
subplot(3, 2, 4);
level_error = abs(level_real - level_estimated);
temp_error = abs(temp_real - temp_estimated);
conc_error = abs(conc_real - conc_estimated);

plot(time_vec, level_error, 'b-', 'LineWidth', 1.5);
hold on;
plot(time_vec, temp_error, 'r-', 'LineWidth', 1.5);
plot(time_vec, conc_error, 'g-', 'LineWidth', 1.5);
title('Estimation Error');
xlabel('Time (s)');
ylabel('Absolute Error');
legend('Level Error (m)', 'Temperature Error (--C)', 'Concentration Error (g/L)', 'Location', 'best');
grid on;

% Control inputs
subplot(3, 2, 5);
plot(time_vec, inflow_rate, 'b-', 'LineWidth', 1.5);
hold on;
plot(time_vec, valve_opening, 'r-', 'LineWidth', 1.5);
title('Control Inputs');
xlabel('Time (s)');
ylabel('Value');
legend('Inflow Rate (m?/s)', 'Valve Opening', 'Location', 'best');
grid on;

% Anomaly detection
subplot(3, 2, 6);
stem(time_vec, level_anomaly, 'b', 'LineWidth', 1.5);
hold on;
stem(time_vec, temp_anomaly, 'r', 'LineWidth', 1.5);
stem(time_vec, conc_anomaly, 'g', 'LineWidth', 1.5);
title('Anomaly Detection');
xlabel('Time (s)');
ylabel('Anomaly Detected (0=No, 1=Yes)');
legend('Level Anomaly', 'Temperature Anomaly', 'Concentration Anomaly', 'Location', 'best');
grid on;
ylim([-0.1, 1.1]);

%% 7. MULTIDISCIPLINARY APPLICATIONS OF DIGITAL TWINS
% Create a figure showing how the same approach applies to multiple domains
figure('Position', [200, 200, 1000, 600], 'Name', 'Digital Twin Applications Across Disciplines');

% Define the domains to show
domains = {'Engineering', 'Healthcare', 'Urban Planning'};
n_domains = length(domains);

% Create panels for each domain
for i = 1:n_domains
    subplot(1, n_domains, i);
    axis off;
    
    % Draw domain title
    text(0.5, 0.95, domains{i}, 'FontSize', 14, 'FontWeight', 'bold', ...
         'HorizontalAlignment', 'center');
    
    % Draw physical system box
    rectangle('Position', [0.1, 0.7, 0.3, 0.2], 'FaceColor', [0.8, 0.9, 1], ...
              'EdgeColor', 'k', 'LineWidth', 1.5);
    text(0.25, 0.8, 'Physical System', 'HorizontalAlignment', 'center');
    
    % Draw sensor box
    rectangle('Position', [0.1, 0.5, 0.3, 0.1], 'FaceColor', [1, 0.9, 0.8], ...
              'EdgeColor', 'k', 'LineWidth', 1.5);
    text(0.25, 0.55, 'Sensors', 'HorizontalAlignment', 'center');
    
    % Draw digital twin box
    rectangle('Position', [0.6, 0.7, 0.3, 0.2], 'FaceColor', [0.9, 0.8, 1], ...
              'EdgeColor', 'k', 'LineWidth', 1.5);
    text(0.75, 0.8, 'Digital Twin', 'HorizontalAlignment', 'center');
    
    % Draw connections
    annotation('arrow', [0.25 + 0.3*(i-1)/n_domains, 0.6 + 0.3*(i-1)/n_domains], ...
                       [0.8, 0.8], 'LineWidth', 1.5);
    annotation('arrow', [0.25 + 0.3*(i-1)/n_domains, 0.25 + 0.3*(i-1)/n_domains], ...
                       [0.7, 0.6], 'LineWidth', 1.5);
    annotation('arrow', [0.25 + 0.3*(i-1)/n_domains, 0.6 + 0.3*(i-1)/n_domains], ...
                       [0.55, 0.75], 'LineWidth', 1.5);
    
    % Draw domain-specific examples
    switch domains{i}
        case 'Engineering'
            examples = {
                'Physical System:', 
                '- Manufacturing equipment',
                '- Aircraft engine',
                '- Power plant',
                '',
                'State Variables:',
                '- Temperature',
                '- Pressure',
                '- Vibration',
                '- Flow rates',
                '',
                'Applications:',
                '- Predictive maintenance',
                '- Performance optimization',
                '- Fault diagnosis',
                '- Virtual testing'
            };
        case 'Healthcare'
            examples = {
                'Physical System:', 
                '- Patient',
                '- Medical device',
                '- Hospital system',
                '',
                'State Variables:',
                '- Vital signs',
                '- Blood chemistry',
                '- Medication levels',
                '- Diagnostic images',
                '',
                'Applications:',
                '- Personalized treatment',
                '- Disease progression modeling',
                '- Treatment response prediction',
                '- Resource optimization'
            };
        case 'Urban Planning'
            examples = {
                'Physical System:', 
                '- Transportation network',
                '- Energy grid',
                '- Water supply system',
                '- Building complex',
                '',
                'State Variables:',
                '- Traffic flow',
                '- Energy consumption',
                '- Water pressure/quality',
                '- Occupancy patterns',
                '',
                'Applications:',
                '- Smart city management',
                '- Resource distribution',
                '- Emergency response planning',
                '- Sustainability optimization'
            };
    end
    
    % Add example text
    text(0.1, 0.45, examples, 'VerticalAlignment', 'top', 'FontSize', 9);
end

% Add overall title
sgtitle('Digital Twin Paradigm Across Disciplines', 'FontSize', 16);

% Add common principles
annotation('textbox', [0.1, 0.02, 0.8, 0.05], 'String', ...
           ['Common Principles: State Estimation ? Predictive Modeling ? ' ...
            'Anomaly Detection ? Real-time Updating ? Virtual Testing ? Optimization'], ...
           'HorizontalAlignment', 'center', 'EdgeColor', 'none', 'FontSize', 12, ...
           'FontWeight', 'bold');

fprintf('Digital twin simulation and visualisation completed.\n');
fprintf('The same core principles apply across multiple disciplines.\n');
