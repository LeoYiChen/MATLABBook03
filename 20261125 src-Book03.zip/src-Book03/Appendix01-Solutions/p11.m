%% p11.m
% MATLABBook03_ChapterAIBHS_Problem11.m
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : p11
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function MATLABBook03_ChapterAIBHS_Problem11
% Purpose: encode/decode binary data in DNA with a parity base.
% Author: Dr Leo Chen. R2024b (no toolbox). v1.0 2025-06-01.
    rng(0); bases='ACGT'; message=logical([1 0 1 1 0 0 1 0]);
    pairs=reshape(message,2,[])'; idx=pairs(:,1)*2+pairs(:,2);
    strand=bases(idx+1); parity=mod(sum(idx),4);
    strand=[strand bases(parity+1)];
    fprintf('Encoded strand: %s\n', strand);
    received=strand; received(2)=bases(mod(idx(2)+1,4)+1);  % inject 1 error
    dataIdx=arrayfun(@(ch) find(bases==ch)-1, received(1:end-1));
    ok = mod(sum(dataIdx),4)==(find(bases==received(end))-1);
    fprintf('Parity check passed: %d (0 = error detected)\n', ok);
end
