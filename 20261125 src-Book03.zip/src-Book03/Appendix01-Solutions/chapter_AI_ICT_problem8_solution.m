%% chapter_AI_ICT_problem8_solution.m
% Multi-Objective Green Network Optimisation
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AI_ICT_problem8_solution
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [optimisation_results, pareto_analysis] = multiObjectiveGreenNetworks()
% Multi-Objective Optimisation for Green Communication Networks
% Author: Dr Leo Chen
% Version: 1.0
% Date: 2024
%
% Implements comprehensive multi-objective optimisation for sustainable
% communication network design with energy efficiency and QoS considerations

fprintf('=== Multi-Objective Green Network Optimisation Solution ===\n');

% Network design configuration
network_config = struct();
network_config.coverage_area_km2 = 500; % Metropolitan area coverage
network_config.target_users = 100000; % Peak concurrent users
network_config.base_station_types = {'macro', 'micro', 'pico', 'femto'};
network_config.renewable_sources = {'solar', 'wind', 'hybrid'};
network_config.service_classes = {'voice', 'data', 'video', 'iot'};

% Multi-objective configuration
objectives_config = struct();
objectives_config.energy_efficiency = true; % Minimise energy consumption
objectives_config.quality_of_service = true; % Maximise QoS metrics
objectives_config.network_coverage = true; % Maximise coverage
objectives_config.capital_expenditure = true; % Minimise CAPEX
objectives_config.operational_expenditure = true; % Minimise OPEX

% Evolutionary algorithm configuration
evolution_config = struct();
evolution_config.algorithm = 'nsga2'; % NSGA-II algorithm
evolution_config.population_size = 100; % Population size
evolution_config.num_generations = 500; % Maximum generations
evolution_config.crossover_probability = 0.9; % Crossover rate
evolution_config.mutation_probability = 0.1; % Mutation rate
evolution_config.pareto_fraction = 0.35; % Pareto frontier fraction

% Sustainability constraints
sustainability_config = struct();
sustainability_config.carbon_emission_limit = 1000; % tonnes CO2/year
sustainability_config.renewable_energy_target = 0.6; % 60% renewable target
sustainability_config.energy_efficiency_target = 0.8; % 80% efficiency target
sustainability_config.waste_reduction_target = 0.4; % 40% waste reduction

% Initialise green network optimisation framework
fprintf('Initialising green network optimisation framework...\n');
optimisation_framework = initialiseGreenOptimisationFramework(network_config, ...
objectives_config, ...
sustainability_config);

% Define multi-objective functions
fprintf('Defining multi-objective functions...\n');
objective_functions = defineMultiObjectiveFunctions(optimisation_framework);

% Implement constraint handling
fprintf('Implementing constraint handling...\n');
constraint_handlers = implementConstraintHandling(optimisation_framework);

% Execute multi-objective evolutionary algorithms
fprintf('Executing multi-objective evolutionary algorithms...\n');
[pareto_solutions, evolution_history] = executeMultiObjectiveEvolution(objective_functions, ...
constraint_handlers, ...
evolution_config);

% Analyse Pareto frontier characteristics
fprintf('Analysing Pareto frontier characteristics...\n');
pareto_analysis = analyseParetoFrontier(pareto_solutions, objective_functions);

% Perform decision-making analysis
fprintf('Performing decision-making analysis...\n');
decision_analysis = performDecisionMaking(pareto_solutions, pareto_analysis, optimisation_framework);

% Evaluate solution robustness
fprintf('Evaluating solution robustness...\n');
robustness_analysis = evaluateSolutionRobustness(pareto_solutions, optimisation_framework);

% Compile comprehensive results
optimisation_results = struct();
optimisation_results.pareto_solutions = pareto_solutions;
optimisation_results.evolution_history = evolution_history;
optimisation_results.decision_analysis = decision_analysis;
optimisation_results.robustness_analysis = robustness_analysis;

% Generate comprehensive visualisations
generateMultiObjectiveVisualisations(optimisation_results, pareto_analysis);

fprintf('Multi-objective green network optimisation completed successfully!\n');
end

function optimisation_framework = initialiseGreenOptimisationFramework(network_config, objectives_config, sustainability_config)
% Initialise comprehensive green network optimisation framework

optimisation_framework = struct();
optimisation_framework.network = network_config;
optimisation_framework.objectives = objectives_config;
optimisation_framework.sustainability = sustainability_config;

% Define decision variables
fprintf(' Defining decision variables...\n');
optimisation_framework.decision_variables = defineDecisionVariables(network_config);

% Create network topology model
fprintf(' Creating network topology model...\n');
optimisation_framework.topology_model = createNetworkTopologyModel(network_config);

% Implement energy consumption models
fprintf(' Implementing energy models...\n');
optimisation_framework.energy_models = implementEnergyModels(network_config);

% Define QoS models
fprintf(' Defining QoS models...\n');
optimisation_framework.qos_models = defineQoSModels(network_config);

% Create cost models
fprintf(' Creating cost models...\n');
optimisation_framework.cost_models = createCostModels(network_config);

% Implement environmental impact models
fprintf(' Implementing environmental models...\n');
optimisation_framework.environmental_models = implementEnvironmentalModels(sustainability_config);

fprintf(' Green optimisation framework initialised\n');
end

function decision_variables = defineDecisionVariables(network_config)
% Define comprehensive decision variables for network optimisation

decision_variables = struct();

% Base station placement variables
decision_variables.base_station_locations = struct();
decision_variables.base_station_locations.macro_bs = []; % [x, y] coordinates
decision_variables.base_station_locations.micro_bs = [];
decision_variables.base_station_locations.pico_bs = [];
decision_variables.base_station_locations.femto_bs = [];

% Base station configuration variables
decision_variables.base_station_config = struct();
decision_variables.base_station_config.transmit_power = []; % Power levels
decision_variables.base_station_config.antenna_tilt = []; % Antenna tilt angles
decision_variables.base_station_config.frequency_allocation = []; % Spectrum allocation

% Renewable energy system variables
decision_variables.renewable_energy = struct();
decision_variables.renewable_energy.solar_panel_capacity = []; % Solar capacity per site
decision_variables.renewable_energy.wind_turbine_capacity = []; % Wind capacity per site
decision_variables.renewable_energy.battery_storage_capacity = []; % Storage capacity

% Network resource allocation variables
decision_variables.resource_allocation = struct();
decision_variables.resource_allocation.bandwidth_allocation = []; % Bandwidth per service class
decision_variables.resource_allocation.user_association = []; % User-BS associations
decision_variables.resource_allocation.load_balancing = []; % Traffic distribution

% Infrastructure sharing variables
decision_variables.infrastructure_sharing = struct();
decision_variables.infrastructure_sharing.site_sharing = []; % Shared sites
decision_variables.infrastructure_sharing.spectrum_sharing = []; % Dynamic spectrum sharing
decision_variables.infrastructure_sharing.backhaul_sharing = []; % Shared backhaul

fprintf(' Decision variables defined: %d variable categories\n', length(fieldnames(decision_variables)));
end

function objective_functions = defineMultiObjectiveFunctions(framework)
% Define comprehensive multi-objective functions

objective_functions = struct();

% Objective 1: Minimise total energy consumption
objective_functions.energy_consumption = @(x) calculateTotalEnergyConsumption(x, framework);

% Objective 2: Maximise quality of service
objective_functions.quality_of_service = @(x) calculateQualityOfService(x, framework);

% Objective 3: Maximise network coverage
objective_functions.network_coverage = @(x) calculateNetworkCoverage(x, framework);

% Objective 4: Minimise capital expenditure
objective_functions.capital_expenditure = @(x) calculateCapitalExpenditure(x, framework);

% Objective 5: Minimise operational expenditure
objective_functions.operational_expenditure = @(x) calculateOperationalExpenditure(x, framework);

% Objective 6: Minimise carbon footprint
objective_functions.carbon_footprint = @(x) calculateCarbonFootprint(x, framework);

% Multi-objective evaluation function
objective_functions.evaluate_all = @(x) evaluateAllObjectives(x, objective_functions);

fprintf(' Multi-objective functions defined: %d objectives\n', length(fieldnames(objective_functions)) - 1);
end

function total_energy = calculateTotalEnergyConsumption(decision_vector, framework)
% Calculate total network energy consumption

% Extract decision variables
base_station_locations = extractBaseStationLocations(decision_vector);
power_configuration = extractPowerConfiguration(decision_vector);
renewable_energy_config = extractRenewableEnergyConfig(decision_vector);

% Calculate base station energy consumption
bs_energy_consumption = 0;
for bs_type_idx = 1:length(framework.network.base_station_types)
bs_type = framework.network.base_station_types{bs_type_idx};
bs_locations = base_station_locations.(bs_type);

 
if ~isempty(bs_locations)
    % Energy consumption per base station type
    power_per_bs = framework.energy_models.(bs_type).idle_power + ...
                  framework.energy_models.(bs_type).traffic_dependent_power * ...
                  calculateAverageTrafficLoad(bs_locations, framework);
    
    bs_energy_consumption = bs_energy_consumption + size(bs_locations, 1) * power_per_bs;
end
end

% Calculate backhaul energy consumption
backhaul_energy = calculateBackhaulEnergyConsumption(base_station_locations, framework);

% Calculate renewable energy generation
renewable_energy_generation = calculateRenewableEnergyGeneration(renewable_energy_config, framework);

% Total net energy consumption
total_energy = bs_energy_consumption + backhaul_energy - renewable_energy_generation;

% Ensure positive energy consumption
total_energy = max(total_energy, 0);
end

function qos_score = calculateQualityOfService(decision_vector, framework)
% Calculate comprehensive quality of service metrics

% Extract network configuration
base_station_locations = extractBaseStationLocations(decision_vector);
resource_allocation = extractResourceAllocation(decision_vector);

% Calculate coverage-based QoS
coverage_qos = calculateCoverageQoS(base_station_locations, framework);

% Calculate capacity-based QoS
capacity_qos = calculateCapacityQoS(base_station_locations, resource_allocation, framework);

% Calculate latency-based QoS
latency_qos = calculateLatencyQoS(base_station_locations, framework);

% Calculate reliability-based QoS
reliability_qos = calculateReliabilityQoS(base_station_locations, framework);

% Aggregate QoS metrics with weights
qos_weights = [0.3, 0.3, 0.2, 0.2]; % Coverage, capacity, latency, reliability
qos_score = qos_weights(1) * coverage_qos + ...
qos_weights(2) * capacity_qos + ...
qos_weights(3) * latency_qos + ...
qos_weights(4) * reliability_qos;

% Normalise to [0, 1] range
qos_score = min(max(qos_score, 0), 1);
end

function [pareto_solutions, evolution_history] = executeMultiObjectiveEvolution(objective_functions, constraint_handlers, evolution_config)
% Execute multi-objective evolutionary algorithm

% Initialise algorithm parameters
population_size = evolution_config.population_size;
num_generations = evolution_config.num_generations;
num_objectives = length(fieldnames(objective_functions)) - 1; % Exclude evaluate_all

% Initialise population
fprintf(' Initialising population...\n');
population = initialisePopulation(population_size, constraint_handlers);

% Evaluate initial population
initial_fitness = evaluatePopulationFitness(population, objective_functions);

% Initialise evolution history
evolution_history = struct();
evolution_history.generation = [];
evolution_history.best_fitness = [];
evolution_history.average_fitness = [];
evolution_history.pareto_front_size = [];
evolution_history.hypervolume = [];

% NSGA-II main evolution loop
fprintf(' Executing NSGA-II evolution...\n');
current_population = population;
current_fitness = initial_fitness;

for generation = 1:num_generations
if mod(generation, 50) == 0
fprintf(' Generation %d/%d...\n', generation, num_generations);
end

 
% Generate offspring through crossover and mutation
offspring_population = generateOffspring(current_population, evolution_config);

% Evaluate offspring fitness
offspring_fitness = evaluatePopulationFitness(offspring_population, objective_functions);

% Combine parent and offspring populations
combined_population = [current_population; offspring_population];
combined_fitness = [current_fitness; offspring_fitness];

% Non-dominated sorting
[fronts, domination_ranks] = performNonDominatedSorting(combined_fitness);

% Calculate crowding distances
crowding_distances = calculateCrowdingDistances(combined_fitness, fronts);

% Environmental selection
[current_population, current_fitness] = environmentalSelection(combined_population, ...
                                                              combined_fitness, ...
                                                              fronts, ...
                                                              crowding_distances, ...
                                                              population_size);

% Update evolution history
evolution_history.generation(end+1) = generation;
evolution_history.best_fitness{end+1} = current_fitness(fronts{1}, :);
evolution_history.average_fitness(end+1, :) = mean(current_fitness);
evolution_history.pareto_front_size(end+1) = length(fronts{1});
evolution_history.hypervolume(end+1) = calculateHypervolume(current_fitness(fronts{1}, :));

% Check convergence criteria
if checkConvergence(evolution_history, generation)
    fprintf('    Convergence achieved at generation %d\n', generation);
    break;
end
end

% Extract Pareto solutions
pareto_indices = fronts{1};
pareto_solutions = struct();
pareto_solutions.decision_vectors = current_population(pareto_indices, :);
pareto_solutions.objective_values = current_fitness(pareto_indices, :);
pareto_solutions.num_solutions = length(pareto_indices);

fprintf(' Multi-objective evolution completed: %d Pareto solutions found\n', pareto_solutions.num_solutions);
end
