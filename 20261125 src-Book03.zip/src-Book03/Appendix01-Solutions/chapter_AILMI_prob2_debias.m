%% chapter_AILMI_prob2_debias.m
% Hard debiasing technique removing gender bias.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AILMI_prob2_debias
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function debias

edEmbeddings = hardDebias(embeddings, genderPairs, neutralWords)
    % Identify gender direction via PCA on gender pair differences
    diffVectors = [];
    for i = 1:size(genderPairs, 1)
        male = embeddings(genderPairs{i, 1}, :);
        female = embeddings(genderPairs{i, 2}, :);
        diffVectors = [diffVectors; male - female];
    end
    
    % PCA: gender direction is first principal component
    [coeff, ~, ~] = pca(diffVectors);
    genderDir = coeff(:, 1)';
    genderDir = genderDir / norm(genderDir); % Normalise
    
    % Neutralise gender-neutral words
    debiasedEmbeddings = embeddings;
    for i = 1:length(neutralWords)
        word = neutralWords{i};
        vec = embeddings(word, :);
        
        % Remove gender component
        genderComponent = dot(vec, genderDir) * genderDir;
        debiasedEmbeddings(word, :) = vec - genderComponent;
    end
end
