%% Appendix01-Solutions_code_078.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
classdef CUSUMEventDetector
    properties
        baseline_mean
        slack
        threshold
        cusum_pos
        cusum_neg
    end
    
    methods
        function obj = CUSUMEventDetector(baseline, slack, threshold)
            obj.baseline_mean = baseline;
            obj.slack = slack;
            obj.threshold = threshold;
            obj.cusum_pos = 0;
            obj.cusum_neg = 0;
        end
        
        function [pos_event, neg_event] = check_event(obj, current_sentiment)
            % Positive drift (sentiment increase)
            obj.cusum_pos = max(0, obj.cusum_pos + current_sentiment - ...
                                obj.baseline_mean - obj.slack);
            
            % Negative drift (sentiment decrease)
            obj.cusum_neg = max(0, obj.cusum_neg - current_sentiment + ...
                                obj.baseline_mean - obj.slack);
            
            pos_event = obj.cusum_pos > obj.threshold;
            neg_event = obj.cusum_neg > obj.threshold;
            
            % Reset after event
            if pos_event, obj.cusum_pos = 0; end
            if neg_event, obj.cusum_neg = 0; end
        end
    end
end
