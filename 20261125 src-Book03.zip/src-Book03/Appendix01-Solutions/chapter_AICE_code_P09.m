%% chapter_AICE_code_P09.m
% Solution~9: urban network link criticality ranking (MATLABBook02_Chapter13_section8_Problem09.m).
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AICE_code_P09
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% MATLABBook02_Chapter13_section8_Problem09.m
% Problem 9: Urban Network Link Criticality Ranking
%
% Description : Builds an urban road network, computes baseline
%               shortest paths, and ranks every link by the
%               access-time degradation its removal causes.
% Author      : Dr Yi Chen
% Date        : 2025
% MATLAB      : R2024b or later
% Toolboxes   : None (base MATLAB)
% Reference   : Chapter 13, Problem 9
% =================================================================

%% 1. Define the six-node road network
sourceNodes = ["Suburb","Suburb","Market","Market", ...
    "Bridge","Riverside","Riverside","Station","Station"];
targetNodes = ["Market","Riverside","Bridge","Station", ...
    "Hospital","Bridge","Hospital","Hospital","Riverside"];
travelTimes = [6, 9, 4, 5, 3, 5, 14, 7, 4];

roadNetwork = graph(sourceNodes, targetNodes, travelTimes);

%% 2. Baseline shortest path
originNode      = "Suburb";
destinationNode = "Hospital";
[baselinePath, baselineTime] = shortestpath(roadNetwork, ...
    originNode, destinationNode);
fprintf('Baseline: %.0f min via %s\n', baselineTime, ...
    strjoin(baselinePath, ' -> '));

%% 3. Systematically remove each edge and measure degradation
nEdges      = numedges(roadNetwork);
edgeTable   = roadNetwork.Edges;
degradation = zeros(nEdges, 1);
newTimes    = zeros(nEdges, 1);

for edgeIndex = 1:nEdges
    reducedNetwork = rmedge(roadNetwork, edgeIndex);
    [~, newTime]   = shortestpath(reducedNetwork, ...
        originNode, destinationNode);
    newTimes(edgeIndex)    = newTime;
    degradation(edgeIndex) = newTime - baselineTime;
end

%% 4. Build criticality table and sort
percentDeg = 100 * degradation / baselineTime;
edgeLabels = strcat(string(edgeTable.EndNodes(:,1)), ...
    " -- ", string(edgeTable.EndNodes(:,2)));
critTable  = table(edgeLabels, travelTimes', ...
    newTimes, degradation, percentDeg, ...
    'VariableNames', {'Edge','Weight','NewTime', ...
    'Degradation','DegradationPct'});
critTable  = sortrows(critTable, 'Degradation', 'descend');
disp(critTable);

%% 5. Identify the most critical link
fprintf('\nMost critical link: %s (+%.0f min, +%.0f%%)\n', ...
    critTable.Edge(1), critTable.Degradation(1), ...
    critTable.DegradationPct(1));

%% 6. Visualise
figure;
graphPlot = plot(roadNetwork, 'EdgeLabel', ...
    roadNetwork.Edges.Weight, 'LineWidth', 1.5, ...
    'NodeFontSize', 10);
highlight(graphPlot, baselinePath, 'EdgeColor', 'g', ...
    'LineWidth', 3);
title(sprintf('Urban Network (baseline = %d min)', ...
    baselineTime));
% - Computational Complexity -
% Each shortestpath call costs O(E + V log V); rmedge is O(E).
% The loop runs E times, giving O(E(E + V log V)) overall.
% For this 6-node, 9-edge network the computation is trivial.
% For a city-scale network of V = 10^5 nodes and E = 3*10^5
% edges, the full criticality ranking would take minutes,
% which remains tractable for offline planning.
