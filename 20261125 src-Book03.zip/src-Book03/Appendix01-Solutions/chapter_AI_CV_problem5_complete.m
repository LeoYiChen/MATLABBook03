%% chapter_AI_CV_problem5_complete.m
% Quantum Feature Mapping Implementation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AI_CV_problem5_complete
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% Quantum Feature Mapping for Classical Images
% Author: Dr Leo Chen
% Created: January 2025
% MATLAB Version: R2024a or later

function quantumResults = quantumFeatureMapping()
    fprintf('Quantum Feature Mapping Framework\n');
    
    % Initialize quantum simulation framework
    quantumFramework = initializeQuantumFramework();
    
    % Perform quantum feature mapping tests
    quantumResults = performQuantumMappingTests(quantumFramework);
    
    % Visualise results
    visualiseQuantumResults(quantumResults);
end

function framework = initializeQuantumFramework()
    framework = struct();
    framework.maxQubits = 10; % Practical limit for classical simulation
    framework.gateLibrary = createQuantumGateLibrary();
    framework.encodingSchemes = {'amplitude', 'angle', 'product'};
    
    fprintf('Quantum framework initialized with %d qubits\n', framework.maxQubits);
end

function gates = createQuantumGateLibrary()
    gates = struct();
    
    % Pauli gates
    gates.I = eye(2);
    gates.X = [0, 1; 1, 0];
    gates.Y = [0, -1i; 1i, 0];
    gates.Z = [1, 0; 0, -1];
    
    % Hadamard gate
    gates.H = [1, 1; 1, -1] / sqrt(2);
    
    % Phase gates
    gates.S = [1, 0; 0, 1i];
    gates.T = [1, 0; 0, exp(1i * pi / 4)];
    
    % Parametric rotation gates
    gates.RX = @(theta) [cos(theta/2), -1i*sin(theta/2); -1i*sin(theta/2), cos(theta/2)];
    gates.RY = @(theta) [cos(theta/2), -sin(theta/2); sin(theta/2), cos(theta/2)];
    gates.RZ = @(theta) [exp(-1i*theta/2), 0; 0, exp(1i*theta/2)];
    
    % Two-qubit gates
    gates.CNOT = [1, 0, 0, 0; 0, 1, 0, 0; 0, 0, 0, 1; 0, 0, 1, 0];
    gates.CZ = [1, 0, 0, 0; 0, 1, 0, 0; 0, 0, 1, 0; 0, 0, 0, -1];
end

function results = performQuantumMappingTests(framework)
    results = struct();
    
    % Generate test dataset
    [images, labels] = generateTestDataset();
    
    % Test different encoding schemes
    results.amplitudeEncoding = testAmplitudeEncoding(images, labels, framework);
    results.angleEncoding = testAngleEncoding(images, labels, framework);
    results.productEncoding = testProductEncoding(images, labels, framework);
    
    % Quantum kernel methods
    results.quantumKernels = testQuantumKernels(images, labels, framework);
    
    % Variational quantum classification
    results.variationalClassifier = testVariationalQuantumClassifier(images, labels, framework);
    
    fprintf('Quantum mapping tests completed\n');
end

function [images, labels] = generateTestDataset()
    numImages = 50;
    imageSize = [8, 8]; % Small images for quantum simulation
    
    images = zeros([imageSize, numImages]);
    labels = zeros(numImages, 1);
    
    for imageIndex = 1:numImages
        % Generate different pattern types
        patternType = mod(imageIndex - 1, 3) + 1;
        labels(imageIndex) = patternType;
        
        switch patternType
            case 1 % Horizontal stripes
                pattern = repmat([1, 0], imageSize(1)/2, imageSize(2)/2);
                
            case 2 % Vertical stripes
                pattern = repmat([1; 0], imageSize(1)/2, imageSize(2)/2);
                
            case 3 % Checkerboard
                [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
                pattern = mod(X + Y, 2);
        end
        
        % Add noise
        noise = randn(imageSize) * 0.1;
        noisyPattern = pattern + noise;
        
        % Normalise
        noisyPattern = (noisyPattern - min(noisyPattern(:))) / ...
                      (max(noisyPattern(:)) - min(noisyPattern(:)) + eps);
        
        images(:, :, imageIndex) = noisyPattern;
    end
    
    fprintf('Generated %d test images (%dx%d)\n', numImages, imageSize(1), imageSize(2));
end

function result = testAmplitudeEncoding(images, labels, framework)
    fprintf('Testing amplitude encoding...\n');
    
    result = struct();
    result.encodingType = 'Amplitude';
    
    [height, width, numImages] = size(images);
    numPixels = height * width;
    numQubits = ceil(log2(numPixels));
    
    if numQubits > framework.maxQubits
        fprintf('Warning: Image too large for quantum simulation, reducing size\n');
        numQubits = framework.maxQubits;
        numPixels = 2^numQubits;
    end
    
    result.numQubits = numQubits;
    result.quantumStates = cell(numImages, 1);
    result.encodingFidelity = zeros(numImages, 1);
    
    for imageIndex = 1:numImages
        image = images(:, :, imageIndex);
        
        % Encode image as quantum state
        quantumState = encodeImageAmplitudes(image, numQubits);
        result.quantumStates{imageIndex} = quantumState;
        
        % Measure encoding fidelity
        result.encodingFidelity(imageIndex) = computeEncodingFidelity(image, quantumState, numPixels);
    end
    
    result.averageFidelity = mean(result.encodingFidelity);
    result.quantumDimension = 2^numQubits;
    result.classicalDimension = numPixels;
    result.dimensionExpansion = result.quantumDimension / result.classicalDimension;
end

function quantumState = encodeImageAmplitudes(image, numQubits)
    % Encode image pixels as quantum state amplitudes
    
    imageVector = image(:);
    stateSize = 2^numQubits;
    
    % Truncate or pad to match quantum state size
    if length(imageVector) > stateSize
        imageVector = imageVector(1:stateSize);
    else
        imageVector = [imageVector; zeros(stateSize - length(imageVector), 1)];
    end
    
    % Normalise to create valid quantum state
    norm = sqrt(sum(imageVector.^2));
    if norm > 0
        quantumState = imageVector / norm;
    else
        quantumState = zeros(stateSize, 1);
        quantumState(1) = 1; % Default to |0...0? state
    end
end

function fidelity = computeEncodingFidelity(originalImage, quantumState, numPixels)
    % Compute fidelity between original image and quantum encoding
    
    % Extract amplitudes from quantum state
    amplitudes = abs(quantumState);
    
    % Truncate to match original image size
    if length(amplitudes) > numPixels
        amplitudes = amplitudes(1:numPixels);
    end
    
    % Normalise original image
    imageVector = originalImage(:);
    if length(imageVector) > length(amplitudes)
        imageVector = imageVector(1:length(amplitudes));
    end
    
    imageNorm = sqrt(sum(imageVector.^2));
    if imageNorm > 0
        normalisedImage = imageVector / imageNorm;
    else
        normalisedImage = zeros(size(imageVector));
    end
    
    % Compute fidelity as overlap
    fidelity = abs(dot(normalisedImage, amplitudes))^2;
end

function result = testAngleEncoding(images, labels, framework)
    fprintf('Testing angle encoding...\n');
    
    result = struct();
    result.encodingType = 'Angle';
    
    [height, width, numImages] = size(images);
    numPixels = height * width;
    numQubits = min(numPixels, framework.maxQubits);
    
    result.numQubits = numQubits;
    result.quantumStates = cell(numImages, 1);
    result.encodingAccuracy = zeros(numImages, 1);
    
    for imageIndex = 1:numImages
        image = images(:, :, imageIndex);
        
        % Encode image using rotation gates
        quantumState = encodeImageAngles(image, numQubits, framework);
        result.quantumStates{imageIndex} = quantumState;
        
        % Measure encoding accuracy
        result.encodingAccuracy(imageIndex) = computeAngleEncodingAccuracy(image, quantumState, numQubits);
    end
    
    result.averageAccuracy = mean(result.encodingAccuracy);
end

function quantumState = encodeImageAngles(image, numQubits, framework)
    % Encode image pixels as rotation angles
    
    imageVector = image(:);
    
    % Initialize quantum state to |0...0?
    quantumState = zeros(2^numQubits, 1);
    quantumState(1) = 1;
    
    % Apply rotation gates based on pixel values
    for qubitIndex = 1:min(numQubits, length(imageVector))
        pixelValue = imageVector(qubitIndex);
        angle = pixelValue * pi; % Scale to [0, --]
        
        % Apply RY rotation to specific qubit
        rotationGate = framework.gateLibrary.RY(angle);
        fullGate = createTensorProductGate(rotationGate, qubitIndex, numQubits);
        quantumState = fullGate * quantumState;
    end
end

function fullGate = createTensorProductGate(singleGate, targetQubit, numQubits)
    % Create full quantum gate for multi-qubit system
    
    if targetQubit == 1
        fullGate = singleGate;
    else
        fullGate = eye(2^(targetQubit-1));
    end
    
    if targetQubit < numQubits
        fullGate = kron(fullGate, eye(2^(numQubits-targetQubit)));
    end
    
    if targetQubit > 1
        leftIdentity = eye(2^(targetQubit-1));
        rightIdentity = eye(2^(numQubits-targetQubit));
        fullGate = kron(leftIdentity, kron(singleGate, rightIdentity));
    end
end

function accuracy = computeAngleEncodingAccuracy(image, quantumState, numQubits)
    % Compute accuracy of angle encoding
    
    imageVector = image(:);
    
    % Extract rotation angles from quantum state (simplified)
    measuredProbabilities = abs(quantumState).^2;
    
    % Estimate original angles from probabilities
    estimatedAngles = acos(sqrt(measuredProbabilities(1:min(numQubits, length(imageVector)))));
    estimatedPixels = estimatedAngles / pi;
    
    % Compare with original pixels
    originalPixels = imageVector(1:length(estimatedPixels));
    accuracy = 1 - mean(abs(originalPixels - estimatedPixels));
end

function result = testProductEncoding(images, labels, framework)
    fprintf('Testing product encoding...\n');
    
    result = struct();
    result.encodingType = 'Product';
    
    [height, width, numImages] = size(images);
    numPixels = min(height * width, framework.maxQubits);
    
    result.numQubits = numPixels;
    result.quantumStates = cell(numImages, 1);
    result.entanglementMeasure = zeros(numImages, 1);
    
    for imageIndex = 1:numImages
        image = images(:, :, imageIndex);
        
        % Encode image using product state
        quantumState = encodeImageProduct(image, numPixels, framework);
        result.quantumStates{imageIndex} = quantumState;
        
        % Measure entanglement
        result.entanglementMeasure(imageIndex) = computeEntanglementMeasure(quantumState, numPixels);
    end
    
    result.averageEntanglement = mean(result.entanglementMeasure);
end

function quantumState = encodeImageProduct(image, numQubits, framework)
    % Encode image as product of single-qubit states
    
    imageVector = image(:);
    
    % Create product state
    quantumState = 1;
    
    for qubitIndex = 1:min(numQubits, length(imageVector))
        pixelValue = imageVector(qubitIndex);
        
        % Create single-qubit state
        singleQubitState = [cos(pixelValue * pi / 2); sin(pixelValue * pi / 2)];
        
        % Tensor product
        quantumState = kron(quantumState, singleQubitState);
    end
    
    % Ensure proper normalisation
    quantumState = quantumState / norm(quantumState);
end

function entanglement = computeEntanglementMeasure(quantumState, numQubits)
    % Compute entanglement measure (simplified)
    
    % For pure states, use entropy-based measure
    stateSize = length(quantumState);
    
    if numQubits <= 1
        entanglement = 0;
        return;
    end
    
    % Partial trace over first qubit (simplified calculation)
    subsystemSize = 2^(numQubits - 1);
    reducedDensityMatrix = zeros(subsystemSize, subsystemSize);
    
    for basisIndex = 1:subsystemSize
        for basisJndex = 1:subsystemSize
            amplitude = 0;
            for firstQubitState = 0:1
                fullIndex1 = firstQubitState * subsystemSize + basisIndex;
                fullIndex2 = firstQubitState * subsystemSize + basisJndex;
                
                if fullIndex1 <= stateSize && fullIndex2 <= stateSize
                    amplitude = amplitude + conj(quantumState(fullIndex1)) * quantumState(fullIndex2);
                end
            end
            reducedDensityMatrix(basisIndex, basisJndex) = amplitude;
        end
    end
    
    % Compute von Neumann entropy
    eigenvalues = eig(reducedDensityMatrix);
    eigenvalues = eigenvalues(eigenvalues > 1e-12); % Remove numerical zeros
    
    if isempty(eigenvalues)
        entanglement = 0;
    else
        entanglement = -sum(eigenvalues .* log2(eigenvalues + eps));
    end
end

function result = testQuantumKernels(images, labels, framework)
    fprintf('Testing quantum kernels...\n');
    
    result = struct();
    result.kernelType = 'Quantum';
    
    numImages = size(images, 3);
    numSamples = min(numImages, 20); % Limit for computational efficiency
    
    % Encode images as quantum states
    quantumStates = cell(numSamples, 1);
    for imageIndex = 1:numSamples
        image = images(:, :, imageIndex);
        quantumStates{imageIndex} = encodeImageAmplitudes(image, 6); % 6 qubits
    end
    
    % Compute quantum kernel matrix
    kernelMatrix = zeros(numSamples, numSamples);
    
    for stateIndex1 = 1:numSamples
        for stateIndex2 = 1:numSamples
            % Quantum kernel as overlap between quantum states
            overlap = abs(dot(quantumStates{stateIndex1}, quantumStates{stateIndex2}))^2;
            kernelMatrix(stateIndex1, stateIndex2) = overlap;
        end
    end
    
    result.kernelMatrix = kernelMatrix;
    result.numSamples = numSamples;
    result.kernelRank = rank(kernelMatrix);
    result.kernelTrace = trace(kernelMatrix);
    
    % Compare with classical RBF kernel
    classicalKernel = computeClassicalKernel(images(:, :, 1:numSamples));
    result.classicalComparison = norm(kernelMatrix - classicalKernel, 'fro');
end

function classicalKernel = computeClassicalKernel(images)
    % Compute classical RBF kernel for comparison
    
    numImages = size(images, 3);
    imageVectors = zeros(numel(images(:, :, 1)), numImages);
    
    for imageIndex = 1:numImages
        imageVectors(:, imageIndex) = images(:, :, imageIndex)(:);
    end
    
    classicalKernel = zeros(numImages, numImages);
    sigma = 1.0; % RBF kernel parameter
    
    for imageIndex1 = 1:numImages
        for imageIndex2 = 1:numImages
            distance = norm(imageVectors(:, imageIndex1) - imageVectors(:, imageIndex2))^2;
            classicalKernel(imageIndex1, imageIndex2) = exp(-distance / (2 * sigma^2));
        end
    end
end

function result = testVariationalQuantumClassifier(images, labels, framework)
    fprintf('Testing variational quantum classifier...\n');
    
    result = struct();
    result.classifierType = 'Variational Quantum';
    
    numImages = size(images, 3);
    numTraining = floor(0.8 * numImages);
    
    % Split data
    trainImages = images(:, :, 1:numTraining);
    trainLabels = labels(1:numTraining);
    testImages = images(:, :, (numTraining+1):end);
    testLabels = labels((numTraining+1):end);
    
    % Initialize quantum classifier
    numQubits = 6;
    numLayers = 3;
    numParams = numQubits * numLayers * 3; % 3 rotations per qubit per layer
    
    % Random initialization of parameters
    initialParams = rand(numParams, 1) * 2 * pi;
    
    % Training (simplified - would use gradient descent in practice)
    trainedParams = optimiseQuantumClassifier(trainImages, trainLabels, initialParams, numQubits, framework);
    
    % Testing
    testAccuracy = evaluateQuantumClassifier(testImages, testLabels, trainedParams, numQubits, framework);
    
    result.numQubits = numQubits;
    result.numLayers = numLayers;
    result.numParams = numParams;
    result.trainedParams = trainedParams;
    result.testAccuracy = testAccuracy;
    result.numTraining = numTraining;
    result.numTesting = length(testLabels);
end

function optimisedParams = optimiseQuantumClassifier(images, labels, initialParams, numQubits, framework)
    % Simplified optimisation (would use proper gradient descent)
    
    optimisedParams = initialParams;
    bestAccuracy = 0;
    
    % Simple random search for demonstration
    for iteration = 1:50
        perturbation = randn(size(initialParams)) * 0.1;
        candidateParams = initialParams + perturbation;
        
        accuracy = evaluateQuantumClassifier(images, labels, candidateParams, numQubits, framework);
        
        if accuracy > bestAccuracy
            bestAccuracy = accuracy;
            optimisedParams = candidateParams;
        end
    end
end

function accuracy = evaluateQuantumClassifier(images, labels, params, numQubits, framework)
    % Evaluate quantum classifier accuracy
    
    numImages = size(images, 3);
    predictions = zeros(numImages, 1);
    
    for imageIndex = 1:numImages
        image = images(:, :, imageIndex);
        
        % Encode image
        quantumState = encodeImageAmplitudes(image, numQubits);
        
        % Apply variational circuit
        finalState = applyVariationalCircuit(quantumState, params, numQubits, framework);
        
        % Measurement and classification
        measurementProb = abs(finalState(1))^2; % Probability of measuring |0...0?
        
        % Simple classification rule
        if measurementProb > 0.5
            predictions(imageIndex) = 1;
        elseif measurementProb > 0.33
            predictions(imageIndex) = 2;
        else
            predictions(imageIndex) = 3;
        end
    end
    
    accuracy = mean(predictions == labels);
end

function finalState = applyVariationalCircuit(initialState, params, numQubits, framework)
    % Apply variational quantum circuit
    
    finalState = initialState;
    numLayers = 3;
    paramIndex = 1;
    
    for layer = 1:numLayers
        % Rotation layer
        for qubit = 1:numQubits
            for rotation = 1:3
                if paramIndex <= length(params)
                    angle = params(paramIndex);
                    paramIndex = paramIndex + 1;
                    
                    switch rotation
                        case 1
                            gate = framework.gateLibrary.RX(angle);
                        case 2
                            gate = framework.gateLibrary.RY(angle);
                        case 3
                            gate = framework.gateLibrary.RZ(angle);
                    end
                    
                    fullGate = createTensorProductGate(gate, qubit, numQubits);
                    finalState = fullGate * finalState;
                end
            end
        end
        
        % Entangling layer (simplified)
        for qubit = 1:(numQubits-1)
            cnotGate = createControlledGate(framework.gateLibrary.X, qubit, qubit+1, numQubits);
            finalState = cnotGate * finalState;
        end
    end
end

function controlledGate = createControlledGate(gate, controlQubit, targetQubit, numQubits)
    % Create controlled quantum gate (simplified implementation)
    
    controlledGate = eye(2^numQubits);
    
    % This is a simplified implementation
    % In practice, would need proper tensor product construction
    
    return;
end

function visualiseQuantumResults(results)
    figure('Position', [100, 100, 1400, 1000]);
    
    % Encoding comparison
    subplot(2, 3, 1);
    encodingTypes = {'Amplitude', 'Angle', 'Product'};
    if isfield(results, 'amplitudeEncoding') && isfield(results, 'angleEncoding')
        accuracies = [results.amplitudeEncoding.averageFidelity, ...
                     results.angleEncoding.averageAccuracy, ...
                     results.productEncoding.averageEntanglement];
        
        bar(accuracies);
        set(gca, 'XTickLabel', encodingTypes);
        ylabel('Quality Metric');
        title('Encoding Scheme Comparison');
    end
    
    % Quantum kernel visualisation
    if isfield(results, 'quantumKernels')
        subplot(2, 3, 2);
        imagesc(results.quantumKernels.kernelMatrix);
        colorbar;
        title('Quantum Kernel Matrix');
        xlabel('Sample Index');
        ylabel('Sample Index');
    end
    
    % Dimensional expansion
    if isfield(results, 'amplitudeEncoding')
        subplot(2, 3, 3);
        ae = results.amplitudeEncoding;
        dimensions = [ae.classicalDimension, ae.quantumDimension];
        
        bar(log10(dimensions));
        set(gca, 'XTickLabel', {'Classical', 'Quantum'});
        ylabel('log_{10}(Dimension)');
        title('Feature Space Dimensionality');
    end
    
    % Variational classifier performance
    if isfield(results, 'variationalClassifier')
        subplot(2, 3, 4);
        vc = results.variationalClassifier;
        
        performance = [vc.testAccuracy, 1 - vc.testAccuracy];
        labels = {'Correct', 'Incorrect'};
        
        pie(performance, labels);
        title(sprintf('Quantum Classifier Accuracy: %.1f%%', vc.testAccuracy * 100));
    end
    
    % Entanglement analysis
    if isfield(results, 'productEncoding')
        subplot(2, 3, 5);
        histogram(results.productEncoding.entanglementMeasure, 10);
        xlabel('Entanglement Measure');
        ylabel('Frequency');
        title('Entanglement Distribution');
    end
    
    % Quantum advantage metrics
    subplot(2, 3, 6);
    if isfield(results, 'amplitudeEncoding') && isfield(results, 'variationalClassifier')
        metrics = [results.amplitudeEncoding.dimensionExpansion, ...
                  results.variationalClassifier.testAccuracy * 10, ...
                  results.quantumKernels.kernelRank / results.quantumKernels.numSamples];
        
        metricNames = {'Dimension Ratio', 'Accuracy--10', 'Kernel Rank Ratio'};
        
        bar(metrics);
        set(gca, 'XTickLabel', metricNames);
        xtickangle(45);
        ylabel('Metric Value');
        title('Quantum Advantage Metrics');
    end
    
    sgtitle('Quantum Feature Mapping Analysis Results');
end

% Execute main function
quantumResults = quantumFeatureMapping();
