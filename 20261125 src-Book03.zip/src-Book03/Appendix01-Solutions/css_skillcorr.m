%% css_skillcorr.m
% Skill correlation matrix in base MATLAB.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : css_skillcorr
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function correlationMatrix = analyseSkillStructure(skillMatrix, skillNames)
% analyseSkillStructure  Pearson correlations between competencies.
%   correlationMatrix = analyseSkillStructure(skillMatrix, skillNames)
%   Rows = learners, columns = skills.
%   Author: Dr Leo Chen | Version 1.0 | Base MATLAB (R2021b+)

    correlationMatrix = corrcoef(skillMatrix);

    imagesc(correlationMatrix); colorbar; axis square;
    set(gca, 'XTick', 1:numel(skillNames), 'XTickLabel', skillNames);
    set(gca, 'YTick', 1:numel(skillNames), 'YTickLabel', skillNames);
    title('$\mathrm{Skill\ correlation\ matrix}$', 'Interpreter', 'latex');
end
