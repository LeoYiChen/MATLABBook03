%% chapter_AILMI_prob3_multihead.m
% Multi-head self-attention (Transformer-style).
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AILMI_prob3_multihead
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function output = multiHeadAttention(Q, K, V, Wq, Wk, Wv, Wo, numHeads, dModel)
    % Q, K, V: [batchSize x seqLen x dModel]
    % Wq, Wk, Wv: Cell arrays of head-specific projection matrices
    % Wo: Output projection matrix
    
    batchSize = size(Q, 1);
    seqLen = size(Q, 2);
    dHead = dModel / numHeads;
    
    % Store outputs from each head
    headOutputs = cell(numHeads, 1);
    
    for h = 1:numHeads
        % Project Q, K, V for this head
        Qh = reshape(Q, [], dModel) * Wq{h}; % [batch*seq x dHead]
        Kh = reshape(K, [], dModel) * Wk{h};
        Vh = reshape(V, [], dModel) * Wv{h};
        
        Qh = reshape(Qh, batchSize, seqLen, dHead);
        Kh = reshape(Kh, batchSize, seqLen, dHead);
        Vh = reshape(Vh, batchSize, seqLen, dHead);
        
        % Scaled dot-product attention
        scores = zeros(batchSize, seqLen, seqLen);
        for i = 1:batchSize
            scores(i, :, :) = squeeze(Qh(i, :, :)) * squeeze(Kh(i, :, :))' / sqrt(dHead);
        end
        
        % Softmax over key dimension
        attention = softmax(scores, 3); % [batch x seqLen x seqLen]
        
        % Apply attention to values
        headOutput = zeros(batchSize, seqLen, dHead);
        for i = 1:batchSize
            headOutput(i, :, :) = squeeze(attention(i, :, :)) * squeeze(Vh(i, :, :));
        end
        
        headOutputs{h} = headOutput;
    end
    
    % Concatenate all heads
    concatenated = cat(3, headOutputs{:}); % [batch x seqLen x dModel]
    
    % Final linear projection
    output = zeros(batchSize, seqLen, dModel);
    for i = 1:batchSize
        for j = 1:seqLen
            output(i, j, :) = squeeze(concatenated(i, j, :))' * Wo;
        end
    end
end
