%% chapter_AI_ICT_problem2_solution.m
% Multi-Agent Reinforcement Learning for Spectrum Access
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AI_ICT_problem2_solution
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [spectrum_results, learning_metrics] = multiAgentSpectrumAccess()
% Multi-Agent Reinforcement Learning for Dynamic Spectrum Access
% Author: Dr Leo Chen
% Version: 1.0
% Date: 2024
%
% Implements multi-agent RL algorithms for cognitive radio networks
% with dynamic spectrum access and interference management

fprintf('=== Multi-Agent Spectrum Access Solution ===\n');

% Cognitive radio network configuration
network_config = struct();
network_config.num_secondary_users = 5; % Secondary users
network_config.num_channels = 8; % Available spectrum channels
network_config.channel_bandwidth_mhz = 20; % Channel bandwidth
network_config.primary_user_activity = 0.3; % PU activity probability
network_config.interference_threshold_db = -10; % Interference limit
network_config.transmission_power_dbm = 20; % Secondary user power

% Learning algorithm configuration
learning_config = struct();
learning_config.algorithm_type = 'deep_q_learning'; % RL algorithm
learning_config.num_episodes = 1000; % Training episodes
learning_config.epsilon_start = 1.0; % Exploration rate
learning_config.epsilon_end = 0.01; % Final exploration rate
learning_config.epsilon_decay = 0.995; % Exploration decay
learning_config.learning_rate = 1e-3; % Neural network learning rate
learning_config.discount_factor = 0.95; % Future reward discount

% Initialise multi-agent environment
fprintf('Initialising cognitive radio environment...\n');
cr_environment = initialiseCognitiveRadioEnvironment(network_config);

% Create multi-agent learning system
fprintf('Creating multi-agent learning system...\n');
agent_system = createMultiAgentSystem(network_config, learning_config);

% Train agents using multi-agent reinforcement learning
fprintf('Training multi-agent spectrum access policies...\n');
[trained_agents, training_history] = trainMultiAgentSpectrumAccess(agent_system, ...
cr_environment, ...
learning_config);

% Evaluate spectrum access performance
fprintf('Evaluating spectrum access performance...\n');
spectrum_results = evaluateSpectrumAccessPerformance(trained_agents, cr_environment, network_config);

% Analyse learning convergence and stability
learning_metrics = analyseLearningMetrics(training_history, learning_config);

% Generate comprehensive visualisations
generateSpectrumAccessVisualisations(spectrum_results, learning_metrics, training_history);

fprintf('Multi-agent spectrum access analysis completed successfully!\n');
end

function cr_environment = initialiseCognitiveRadioEnvironment(config)
% Initialise comprehensive cognitive radio network environment

cr_environment = struct();
cr_environment.config = config;

% Channel state model
cr_environment.channel_states = struct();
cr_environment.channel_states.availability = zeros(config.num_channels, 1);
cr_environment.channel_states.interference_levels = zeros(config.num_channels, 1);
cr_environment.channel_states.primary_user_activity = zeros(config.num_channels, 1);

% Initialise primary user activity patterns
cr_environment.primary_users = initialisePrimaryUserModel(config);

% Channel propagation model
cr_environment.propagation_model = initialiseChannelPropagationModel(config);

% Interference calculation framework
cr_environment.interference_calculator = initialiseInterferenceCalculator(config);

% Performance metrics tracking
cr_environment.metrics = initialisePerformanceMetrics(config);

fprintf(' Cognitive radio environment initialised\n');
end

function agent_system = createMultiAgentSystem(network_config, learning_config)
% Create multi-agent reinforcement learning system

agent_system = struct();
agent_system.agents = cell(network_config.num_secondary_users, 1);

% State space definition (channel observations + interference levels)
state_dimension = 2 * network_config.num_channels + network_config.num_secondary_users;

% Action space definition (channel selection + power level)
num_actions = network_config.num_channels + 1; % +1 for idle action

for agent_idx = 1:network_config.num_secondary_users
fprintf(' Creating agent %d...\n', agent_idx);

 
% Create Deep Q-Network for each agent
agent_network = createAgentDQNetwork(state_dimension, num_actions, learning_config);

% Configure agent parameters
agent_config = struct();
agent_config.agent_id = agent_idx;
agent_config.state_dimension = state_dimension;
agent_config.num_actions = num_actions;
agent_config.network = agent_network;
agent_config.experience_buffer = [];
agent_config.epsilon = learning_config.epsilon_start;

agent_system.agents{agent_idx} = agent_config;
end

% Multi-agent coordination mechanism
agent_system.coordination = struct();
agent_system.coordination.message_passing = true;
agent_system.coordination.collision_detection = true;
agent_system.coordination.fairness_mechanism = 'proportional_fair';

fprintf(' Multi-agent system created with %d agents\n', network_config.num_secondary_users);
end

function agent_network = createAgentDQNetwork(state_dim, num_actions, learning_config)
% Create Deep Q-Network architecture for spectrum access agent

layers = [
featureInputLayer(state_dim, 'Name', 'state_input')

 
fullyConnectedLayer(128, 'Name', 'hidden1')
reluLayer('Name', 'relu1')

fullyConnectedLayer(256, 'Name', 'hidden2')
reluLayer('Name', 'relu2')

fullyConnectedLayer(128, 'Name', 'hidden3')
reluLayer('Name', 'relu3')

fullyConnectedLayer(num_actions, 'Name', 'q_values')
regressionLayer('Name', 'output')
];

% Training options for DQN
training_options = trainingOptions('adam', ...
'MaxEpochs', 1, ...
'MiniBatchSize', 32, ...
'InitialLearnRate', learning_config.learning_rate, ...
'Shuffle', 'every-epoch', ...
'Verbose', false, ...
'Plots', 'none');

% Create network
agent_network = struct();
agent_network.layers = layers;
agent_network.options = training_options;
agent_network.target_network = layers; % Target network for stable learning

fprintf(' Agent DQN created with %d layers\n', length(layers));
end
