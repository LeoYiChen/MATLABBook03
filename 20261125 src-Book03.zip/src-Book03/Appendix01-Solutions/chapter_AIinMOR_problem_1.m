%% chapter_AIinMOR_problem_1.m
% Multi-Objective Production Planning Solution.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AIinMOR_problem_1
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [optimisationResults] = solveMultiObjectiveProductionPlanning()
% Multi-Objective Production Planning Optimisation
% Author: Dr Leo Chen
% Version: 1.0
% Date: 2025
% Description: Solves production planning with profit, environmental, and service objectives

fprintf('\\textbf{Multi-Objective Production Planning Optimisation}\n');
fprintf('======================================================\n\n');

% Define problem parameters
problemParameters = defineProductionPlanningProblem();

% Solve using multiple approaches
weightedSumResults = solveUsingWeightedSum(problemParameters);
epsilonConstraintResults = solveUsingEpsilonConstraint(problemParameters);

% Generate Pareto frontier
paretoFrontier = generateParetoFrontier(problemParameters);

% Multi-criteria decision analysis
finalSolution = performMultiCriteriaDecisionAnalysis(paretoFrontier, problemParameters);

% Consolidate results
optimisationResults = consolidateMultiObjectiveResults(problemParameters, weightedSumResults, ...
    epsilonConstraintResults, paretoFrontier, finalSolution);

% Generate comprehensive visualisations
generateMultiObjectiveVisualisations(optimisationResults);

% Display strategic recommendations
displayProductionPlanningRecommendations(optimisationResults);

end

function problemParams = defineProductionPlanningProblem()
% Define comprehensive production planning problem

problemParams = struct();

% Products: Smartphones, Tablets, Laptops
problemParams.products = {'Smartphones', 'Tablets', 'Laptops'};
problemParams.numProducts = 3;

% Facilities: Factory A, Factory B
problemParams.facilities = {'Factory A', 'Factory B'};
problemParams.numFacilities = 2;

% Profit margins per unit (?)
problemParams.profitMargins = [
    [120, 200, 350];  % Factory A: Smartphones, Tablets, Laptops
    [100, 180, 320]   % Factory B: Smartphones, Tablets, Laptops
];

% Environmental impact per unit (carbon footprint in kg CO2)
problemParams.environmentalImpact = [
    [15, 25, 45];     % Factory A
    [18, 30, 50]      % Factory B (less efficient)
];

% Labour hours required per unit
problemParams.labourRequirements = [
    [2.5, 4.0, 6.5];  % Factory A
    [3.0, 4.5, 7.0]   % Factory B
];

% Material costs per unit (?)
problemParams.materialCosts = [
    [80, 120, 200];   % Factory A
    [85, 125, 210]    % Factory B
];

% Facility capacities (labour hours available per month)
problemParams.labourCapacities = [8000, 6000]; % Factory A, Factory B

% Material budget constraints (? per month)
problemParams.materialBudgets = [500000, 400000];

% Demand requirements (minimum units to produce)
problemParams.minimumDemand = [800, 400, 200]; % Smartphones, Tablets, Laptops

% Maximum market demand
problemParams.maximumDemand = [2000, 1000, 500];

% Environmental targets (maximum CO2 emissions in kg)
problemParams.environmentalTarget = 100000; % kg CO2 per month

fprintf('Production planning problem defined:\n');
fprintf('Products: %d, Facilities: %d\n', problemParams.numProducts, problemParams.numFacilities);
fprintf('Total labour capacity: %d hours\n', sum(problemParams.labourCapacities));
fprintf('Total material budget: ?%d\n', sum(problemParams.materialBudgets));
fprintf('Environmental target: %d kg CO2\n\n', problemParams.environmentalTarget);

end

function weightedResults = solveUsingWeightedSum(problemParams)
% Solve multi-objective problem using weighted sum method

weightedResults = struct();

fprintf('\\textbf{Solving using Weighted Sum Method:}\n');

% Define weight combinations for different preference scenarios
weightScenarios = [
    [0.6, 0.3, 0.1];  % Profit-focused
    [0.4, 0.4, 0.2];  % Balanced
    [0.2, 0.5, 0.3];  % Environment-focused
    [0.3, 0.2, 0.5]   % Service-focused
];

scenarioNames = {'Profit-Focused', 'Balanced', 'Environment-Focused', 'Service-Focused'};

weightedResults.scenarios = cell(size(weightScenarios, 1), 1);

for scenarioIdx = 1:size(weightScenarios, 1)
    weights = weightScenarios(scenarioIdx, :);
    scenarioName = scenarioNames{scenarioIdx};
    
    fprintf('Solving scenario: %s\n', scenarioName);
    
    % Formulate weighted objective function
    [objectiveCoefficients, constraintMatrix, constraintRHS, bounds] = ...
        formulateWeightedProblem(problemParams, weights);
    
    % Solve optimisation problem
    optimisationOptions = optimoptions('linprog', 'Display', 'off', 'Algorithm', 'interior-point');
    
    [optimalSolution, optimalValue, exitFlag] = linprog(objectiveCoefficients, ...
        constraintMatrix, constraintRHS, [], [], bounds.lower, bounds.upper, optimisationOptions);
    
    if exitFlag == 1
        % Extract production schedule
        productionSchedule = reshape(optimalSolution, problemParams.numFacilities, problemParams.numProducts);
        
        % Calculate individual objective values
        objectives = calculateObjectiveValues(productionSchedule, problemParams);
        
        % Store scenario results
        scenarioResult = struct();
        scenarioResult.name = scenarioName;
        scenarioResult.weights = weights;
        scenarioResult.productionSchedule = productionSchedule;
        scenarioResult.objectives = objectives;
        scenarioResult.weightedObjective = -optimalValue; % Convert back from minimisation
        scenarioResult.feasible = true;
        
        weightedResults.scenarios{scenarioIdx} = scenarioResult;
        
        fprintf('  Profit: ?%.0f, Environmental Impact: %.0f kg CO2, Service Level: %.2f\n', ...
            objectives.profit, objectives.environmentalImpact, objectives.serviceLevel);
    else
        scenarioResult = struct();
        scenarioResult.name = scenarioName;
        scenarioResult.feasible = false;
        weightedResults.scenarios{scenarioIdx} = scenarioResult;
        
        fprintf('  Scenario infeasible\n');
    end
end

fprintf('Weighted sum method completed\n\n');

end

function [c, A, b, bounds] = formulateWeightedProblem(problemParams, weights)
% Formulate weighted sum optimisation problem

numProducts = problemParams.numProducts;
numFacilities = problemParams.numFacilities;
numVariables = numProducts * numFacilities;

% Decision variables: x(i,j) = production of product j at facility i
% Objective coefficients for weighted sum (convert to minimisation)
profitCoeffs = -reshape(problemParams.profitMargins', numVariables, 1); % Negative for maximisation
envCoeffs = reshape(problemParams.environmentalImpact', numVariables, 1);

% Normalise environmental coefficients (approximate)
maxEnvImpact = max(problemParams.environmentalImpact(:));
envCoeffs = envCoeffs / maxEnvImpact;

% Service level coefficient (penalty for not meeting demand)
serviceCoeffs = ones(numVariables, 1); % Simplified service representation

% Weighted objective
c = weights(1) * profitCoeffs + weights(2) * envCoeffs + weights(3) * serviceCoeffs;

% Constraint matrix
constraintCount = 0;

% Labour capacity constraints
A_labour = zeros(numFacilities, numVariables);
b_labour = problemParams.labourCapacities';

for facilityIdx = 1:numFacilities
    for productIdx = 1:numProducts
        variableIdx = (facilityIdx - 1) * numProducts + productIdx;
        A_labour(facilityIdx, variableIdx) = problemParams.labourRequirements(facilityIdx, productIdx);
    end
end

% Material budget constraints
A_material = zeros(numFacilities, numVariables);
b_material = problemParams.materialBudgets';

for facilityIdx = 1:numFacilities
    for productIdx = 1:numProducts
        variableIdx = (facilityIdx - 1) * numProducts + productIdx;
        A_material(facilityIdx, variableIdx) = problemParams.materialCosts(facilityIdx, productIdx);
    end
end

% Environmental constraint
A_env = zeros(1, numVariables);
b_env = problemParams.environmentalTarget;

for facilityIdx = 1:numFacilities
    for productIdx = 1:numProducts
        variableIdx = (facilityIdx - 1) * numProducts + productIdx;
        A_env(1, variableIdx) = problemParams.environmentalImpact(facilityIdx, productIdx);
    end
end

% Minimum demand constraints (converted to <= format)
A_demand_min = zeros(numProducts, numVariables);
b_demand_min = -problemParams.minimumDemand';

for productIdx = 1:numProducts
    for facilityIdx = 1:numFacilities
        variableIdx = (facilityIdx - 1) * numProducts + productIdx;
        A_demand_min(productIdx, variableIdx) = -1; % Negative for >= constraint
    end
end

% Maximum demand constraints
A_demand_max = zeros(numProducts, numVariables);
b_demand_max = problemParams.maximumDemand';

for productIdx = 1:numProducts
    for facilityIdx = 1:numFacilities
        variableIdx = (facilityIdx - 1) * numProducts + productIdx;
        A_demand_max(productIdx, variableIdx) = 1;
    end
end

% Combine all constraints
A = [A_labour; A_material; A_env; A_demand_min; A_demand_max];
b = [b_labour; b_material; b_env; b_demand_min; b_demand_max];

% Variable bounds (non-negativity)
bounds = struct();
bounds.lower = zeros(numVariables, 1);
bounds.upper = inf(numVariables, 1);

end

function objectives = calculateObjectiveValues(productionSchedule, problemParams)
% Calculate individual objective values

objectives = struct();

% Profit calculation
totalProfit = sum(sum(productionSchedule .* problemParams.profitMargins));
objectives.profit = totalProfit;

% Environmental impact calculation
totalEnvironmentalImpact = sum(sum(productionSchedule .* problemParams.environmentalImpact));
objectives.environmentalImpact = totalEnvironmentalImpact;

% Service level calculation (demand satisfaction)
totalProduction = sum(productionSchedule, 1); % Sum across facilities
demandSatisfaction = min(totalProduction ./ problemParams.maximumDemand, 1);
objectives.serviceLevel = mean(demandSatisfaction);

end

function epsilonResults = solveUsingEpsilonConstraint(problemParams)
% Solve using epsilon-constraint method

epsilonResults = struct();

fprintf('\\textbf{Solving using Epsilon-Constraint Method:}\n');

% Use profit as primary objective, environmental impact and service as constraints
numEpsilonPoints = 5;

% Define epsilon values for environmental impact
maxPossibleEnvImpact = sum(problemParams.maximumDemand .* max(problemParams.environmentalImpact, [], 1));
minPossibleEnvImpact = sum(problemParams.minimumDemand .* min(problemParams.environmentalImpact, [], 1));

epsilonEnvValues = linspace(minPossibleEnvImpact, maxPossibleEnvImpact * 0.8, numEpsilonPoints);

epsilonResults.solutions = cell(numEpsilonPoints, 1);

for epsilonIdx = 1:numEpsilonPoints
    epsilonEnv = epsilonEnvValues(epsilonIdx);
    
    fprintf('Solving with environmental limit: %.0f kg CO2\n', epsilonEnv);
    
    % Formulate epsilon-constraint problem
    [objectiveCoefficients, constraintMatrix, constraintRHS, bounds] = ...
        formulateEpsilonConstraintProblem(problemParams, epsilonEnv);
    
    % Solve optimisation problem
    optimisationOptions = optimoptions('linprog', 'Display', 'off', 'Algorithm', 'interior-point');
    
    [optimalSolution, optimalValue, exitFlag] = linprog(objectiveCoefficients, ...
        constraintMatrix, constraintRHS, [], [], bounds.lower, bounds.upper, optimisationOptions);
    
    if exitFlag == 1
        % Extract production schedule
        productionSchedule = reshape(optimalSolution, problemParams.numFacilities, problemParams.numProducts);
        
        % Calculate objective values
        objectives = calculateObjectiveValues(productionSchedule, problemParams);
        
        % Store solution
        solution = struct();
        solution.epsilonEnv = epsilonEnv;
        solution.productionSchedule = productionSchedule;
        solution.objectives = objectives;
        solution.feasible = true;
        
        epsilonResults.solutions{epsilonIdx} = solution;
        
        fprintf('  Solution found: Profit = ?%.0f\n', objectives.profit);
    else
        solution = struct();
        solution.epsilonEnv = epsilonEnv;
        solution.feasible = false;
        epsilonResults.solutions{epsilonIdx} = solution;
        
        fprintf('  No feasible solution\n');
    end
end

fprintf('Epsilon-constraint method completed\n\n');

end

function [c, A, b, bounds] = formulateEpsilonConstraintProblem(problemParams, epsilonEnv)
% Formulate epsilon-constraint optimisation problem

numProducts = problemParams.numProducts;
numFacilities = problemParams.numFacilities;
numVariables = numProducts * numFacilities;

% Objective: maximise profit (convert to minimisation)
c = -reshape(problemParams.profitMargins', numVariables, 1);

% Use same constraint formulation as weighted sum but with modified environmental constraint
[~, A_base, b_base, bounds] = formulateWeightedProblem(problemParams, [1, 0, 0]);

% Modify environmental constraint
envConstraintRow = numFacilities * 2 + 1; % Position of environmental constraint
b_base(envConstraintRow) = epsilonEnv;

A = A_base;
b = b_base;

end

function paretoFrontier = generateParetoFrontier(problemParams)
% Generate Pareto frontier through systematic exploration

paretoFrontier = struct();

fprintf('\\textbf{Generating Pareto Frontier:}\n');

% Generate solutions with varying weights
numParetoPoints = 20;
paretoSolutions = cell(numParetoPoints, 1);

% Systematic weight variation
weightCombinations = generateWeightCombinations(numParetoPoints);

validSolutionCount = 0;

for pointIdx = 1:numParetoPoints
    weights = weightCombinations(pointIdx, :);
    
    % Solve weighted sum problem
    [objectiveCoefficients, constraintMatrix, constraintRHS, bounds] = ...
        formulateWeightedProblem(problemParams, weights);
    
    optimisationOptions = optimoptions('linprog', 'Display', 'off', 'Algorithm', 'interior-point');
    
    [optimalSolution, optimalValue, exitFlag] = linprog(objectiveCoefficients, ...
        constraintMatrix, constraintRHS, [], [], bounds.lower, bounds.upper, optimisationOptions);
    
    if exitFlag == 1
        validSolutionCount = validSolutionCount + 1;
        
        % Extract and store solution
        productionSchedule = reshape(optimalSolution, problemParams.numFacilities, problemParams.numProducts);
        objectives = calculateObjectiveValues(productionSchedule, problemParams);
        
        solution = struct();
        solution.weights = weights;
        solution.productionSchedule = productionSchedule;
        solution.objectives = objectives;
        solution.point = [objectives.profit, objectives.environmentalImpact, objectives.serviceLevel];
        
        paretoSolutions{validSolutionCount} = solution;
    end
end

% Store valid solutions
paretoFrontier.solutions = paretoSolutions(1:validSolutionCount);
paretoFrontier.numSolutions = validSolutionCount;

% Filter for Pareto optimality
paretoFrontier.paretoOptimalSolutions = filterParetoOptimalSolutions(paretoFrontier.solutions);

fprintf('Pareto frontier generated: %d solutions, %d Pareto-optimal\n\n', ...
    validSolutionCount, length(paretoFrontier.paretoOptimalSolutions));

end

function weightCombinations = generateWeightCombinations(numPoints)
% Generate systematic weight combinations for three objectives

weightCombinations = zeros(numPoints, 3);

% Use uniform sampling in simplex
for pointIdx = 1:numPoints
    % Generate random weights
    randomWeights = rand(1, 3);
    
    % Normalise to sum to 1
    normalizedWeights = randomWeights / sum(randomWeights);
    
    weightCombinations(pointIdx, :) = normalizedWeights;
end

end

function paretoOptimalSolutions = filterParetoOptimalSolutions(allSolutions)
% Filter solutions to identify Pareto-optimal ones

numSolutions = length(allSolutions);
isParetoOptimal = true(numSolutions, 1);

for solutionIdx = 1:numSolutions
    currentSolution = allSolutions{solutionIdx};
    currentPoint = currentSolution.point;
    
    for compareIdx = 1:numSolutions
        if solutionIdx ~= compareIdx
            compareSolution = allSolutions{compareIdx};
            comparePoint = compareSolution.point;
            
            % Check dominance (maximise profit and service, minimise environmental impact)
            profitDominates = comparePoint(1) >= currentPoint(1);
            envDominates = comparePoint(2) <= currentPoint(2);
            serviceDominates = comparePoint(3) >= currentPoint(3);
            
            strictlyBetter = (comparePoint(1) > currentPoint(1)) || ...
                           (comparePoint(2) < currentPoint(2)) || ...
                           (comparePoint(3) > currentPoint(3));
            
            if profitDominates && envDominates && serviceDominates && strictlyBetter
                isParetoOptimal(solutionIdx) = false;
                break;
            end
        end
    end
end

paretoOptimalSolutions = allSolutions(isParetoOptimal);

end

function finalSolution = performMultiCriteriaDecisionAnalysis(paretoFrontier, problemParams)
% Perform TOPSIS-based multi-criteria decision analysis

finalSolution = struct();

fprintf('\\textbf{Performing Multi-Criteria Decision Analysis:}\n');

paretoSolutions = paretoFrontier.paretoOptimalSolutions;

if isempty(paretoSolutions)
    fprintf('No Pareto-optimal solutions available\n');
    finalSolution.selected = [];
    return;
end

% Extract decision matrix
numSolutions = length(paretoSolutions);
decisionMatrix = zeros(numSolutions, 3);

for solutionIdx = 1:numSolutions
    solution = paretoSolutions{solutionIdx};
    decisionMatrix(solutionIdx, :) = solution.point;
end

% Apply TOPSIS method
criteria = struct();
criteria.names = {'Profit', 'Environmental Impact', 'Service Level'};
criteria.weights = [0.4, 0.3, 0.3]; % Decision maker preferences
criteria.beneficial = [true, false, true]; % Profit and service beneficial, environmental impact detrimental

topsisResults = applyTOPSISMethod(decisionMatrix, criteria);

% Select best solution based on TOPSIS scores
[~, bestSolutionIdx] = max(topsisResults.scores);

finalSolution.selected = paretoSolutions{bestSolutionIdx};
finalSolution.topsisScores = topsisResults.scores;
finalSolution.ranking = topsisResults.ranking;

fprintf('TOPSIS analysis completed\n');
fprintf('Selected solution: Profit = ?%.0f, Environmental = %.0f kg CO2, Service = %.2f\n', ...
    finalSolution.selected.point(1), finalSolution.selected.point(2), finalSolution.selected.point(3));
fprintf('TOPSIS score: %.4f\n\n', max(topsisResults.scores));

end

function topsisResults = applyTOPSISMethod(decisionMatrix, criteria)
% Apply TOPSIS (Technique for Order Preference by Similarity to Ideal Solution)

topsisResults = struct();

% Step 1: Normalise decision matrix
normalisedMatrix = decisionMatrix ./ sqrt(sum(decisionMatrix.^2, 1));

% Step 2: Apply weights
weightedMatrix = normalisedMatrix .* criteria.weights;

% Step 3: Identify ideal and negative-ideal solutions
idealSolution = zeros(1, size(weightedMatrix, 2));
negativeIdealSolution = zeros(1, size(weightedMatrix, 2));

for criterionIdx = 1:length(criteria.beneficial)
    if criteria.beneficial(criterionIdx)
        % Beneficial criterion: ideal is maximum
        idealSolution(criterionIdx) = max(weightedMatrix(:, criterionIdx));
        negativeIdealSolution(criterionIdx) = min(weightedMatrix(:, criterionIdx));
    else
        % Non-beneficial criterion: ideal is minimum
        idealSolution(criterionIdx) = min(weightedMatrix(:, criterionIdx));
        negativeIdealSolution(criterionIdx) = max(weightedMatrix(:, criterionIdx));
    end
end

% Step 4: Calculate distances to ideal solutions
numAlternatives = size(weightedMatrix, 1);
distancesToIdeal = zeros(numAlternatives, 1);
distancesToNegativeIdeal = zeros(numAlternatives, 1);

for alternativeIdx = 1:numAlternatives
    alternative = weightedMatrix(alternativeIdx, :);
    
    distancesToIdeal(alternativeIdx) = sqrt(sum((alternative - idealSolution).^2));
    distancesToNegativeIdeal(alternativeIdx) = sqrt(sum((alternative - negativeIdealSolution).^2));
end

% Step 5: Calculate relative closeness to ideal solution
topsisScores = distancesToNegativeIdeal ./ (distancesToIdeal + distancesToNegativeIdeal);

% Step 6: Rank alternatives
[~, ranking] = sort(topsisScores, 'descend');

topsisResults.scores = topsisScores;
topsisResults.ranking = ranking;
topsisResults.idealSolution = idealSolution;
topsisResults.negativeIdealSolution = negativeIdealSolution;

end

function results = consolidateMultiObjectiveResults(problemParams, weightedResults, ...
    epsilonResults, paretoFrontier, finalSolution)
% Consolidate all multi-objective optimisation results

results = struct();

% Store all components
results.problemParameters = problemParams;
results.weightedSumResults = weightedResults;
results.epsilonConstraintResults = epsilonResults;
results.paretoFrontier = paretoFrontier;
results.finalSolution = finalSolution;

% Generate summary statistics
results.summary = struct();

if ~isempty(finalSolution.selected)
    selectedSolution = finalSolution.selected;
    results.summary.recommendedProduction = selectedSolution.productionSchedule;
    results.summary.expectedProfit = selectedSolution.objectives.profit;
    results.summary.environmentalImpact = selectedSolution.objectives.environmentalImpact;
    results.summary.serviceLevel = selectedSolution.objectives.serviceLevel;
    
    % Calculate resource utilisation
    labourUtilisation = calculateLabourUtilisation(selectedSolution.productionSchedule, problemParams);
    materialUtilisation = calculateMaterialUtilisation(selectedSolution.productionSchedule, problemParams);
    
    results.summary.labourUtilisation = labourUtilisation;
    results.summary.materialUtilisation = materialUtilisation;
    
    results.summary.feasible = true;
else
    results.summary.feasible = false;
end

% Trade-off analysis
if paretoFrontier.numSolutions > 1
    results.tradeOffAnalysis = analyseObjectiveTradeOffs(paretoFrontier.paretoOptimalSolutions);
else
    results.tradeOffAnalysis = struct('available', false);
end

end

function labourUtilisation = calculateLabourUtilisation(productionSchedule, problemParams)
% Calculate labour utilisation across facilities

labourUtilisation = zeros(problemParams.numFacilities, 1);

for facilityIdx = 1:problemParams.numFacilities
    totalLabourUsed = sum(productionSchedule(facilityIdx, :) .* ...
                         problemParams.labourRequirements(facilityIdx, :));
    
    labourUtilisation(facilityIdx) = totalLabourUsed / problemParams.labourCapacities(facilityIdx);
end

end

function materialUtilisation = calculateMaterialUtilisation(productionSchedule, problemParams)
% Calculate material utilisation across facilities

materialUtilisation = zeros(problemParams.numFacilities, 1);

for facilityIdx = 1:problemParams.numFacilities
    totalMaterialCost = sum(productionSchedule(facilityIdx, :) .* ...
                           problemParams.materialCosts(facilityIdx, :));
    
    materialUtilisation(facilityIdx) = totalMaterialCost / problemParams.materialBudgets(facilityIdx);
end

end

function tradeOffAnalysis = analyseObjectiveTradeOffs(paretoSolutions)
% Analyse trade-offs between objectives

tradeOffAnalysis = struct();

numSolutions = length(paretoSolutions);
objectiveMatrix = zeros(numSolutions, 3);

for solutionIdx = 1:numSolutions
    objectiveMatrix(solutionIdx, :) = paretoSolutions{solutionIdx}.point;
end

% Calculate correlation coefficients between objectives
correlationMatrix = corrcoef(objectiveMatrix);

tradeOffAnalysis.correlations = correlationMatrix;
tradeOffAnalysis.objectiveRanges = [min(objectiveMatrix); max(objectiveMatrix)];
tradeOffAnalysis.available = true;

% Identify extreme solutions
[~, maxProfitIdx] = max(objectiveMatrix(:, 1));
[~, minEnvIdx] = min(objectiveMatrix(:, 2));
[~, maxServiceIdx] = max(objectiveMatrix(:, 3));

tradeOffAnalysis.extremeSolutions = struct();
tradeOffAnalysis.extremeSolutions.maxProfit = paretoSolutions{maxProfitIdx};
tradeOffAnalysis.extremeSolutions.minEnvironmental = paretoSolutions{minEnvIdx};
tradeOffAnalysis.extremeSolutions.maxService = paretoSolutions{maxServiceIdx};

end

function generateMultiObjectiveVisualisations(results)
% Generate comprehensive visualisations

figure('Position', [100, 100, 1500, 1000], 'Name', 'Multi-Objective Production Planning Results');

% Subplot 1: Production schedule
subplot(2, 3, 1);
if results.summary.feasible
    productionData = results.summary.recommendedProduction;
    
    bar(productionData');
    xlabel('Products');
    ylabel('Production Quantity');
    title('\\textbf{Recommended Production Schedule}');
    set(gca, 'XTickLabel', results.problemParameters.products);
    legend(results.problemParameters.facilities, 'Location', 'best');
    grid on;
end

% Subplot 2: Objective trade-offs
subplot(2, 3, 2);
if results.paretoFrontier.numSolutions > 0
    paretoSolutions = results.paretoFrontier.paretoOptimalSolutions;
    profits = cellfun(@(x) x.point(1), paretoSolutions);
    envImpacts = cellfun(@(x) x.point(2), paretoSolutions);
    
    scatter(profits, envImpacts, 100, 'filled');
    xlabel('Profit (?)');
    ylabel('Environmental Impact (kg CO_2)');
    title('\\textbf{Profit vs Environmental Trade-off}');
    grid on;
    
    % Highlight selected solution
    if results.summary.feasible
        hold on;
        scatter(results.summary.expectedProfit, results.summary.environmentalImpact, ...
                150, 'r', 'filled', 'MarkerEdgeColor', 'k', 'LineWidth', 2);
        legend({'Pareto Solutions', 'Selected Solution'}, 'Location', 'best');
    end
end

% Subplot 3: Resource utilisation
subplot(2, 3, 3);
if results.summary.feasible
    labourUtil = results.summary.labourUtilisation * 100;
    materialUtil = results.summary.materialUtilisation * 100;
    
    utilData = [labourUtil, materialUtil];
    bar(utilData);
    xlabel('Facilities');
    ylabel('Utilisation (%)');
    title('\\textbf{Resource Utilisation}');
    set(gca, 'XTickLabel', results.problemParameters.facilities);
    legend({'Labour', 'Materials'}, 'Location', 'best');
    ylim([0, 100]);
    grid on;
end

% Subplot 4: Weighted sum scenarios
subplot(2, 3, 4);
weightedScenarios = results.weightedSumResults.scenarios;
scenarioNames = {};
scenarioProfits = [];
scenarioEnvImpacts = [];

for scenarioIdx = 1:length(weightedScenarios)
    scenario = weightedScenarios{scenarioIdx};
    if scenario.feasible
        scenarioNames{end+1} = scenario.name;
        scenarioProfits(end+1) = scenario.objectives.profit;
        scenarioEnvImpacts(end+1) = scenario.objectives.environmentalImpact;
    end
end

if ~isempty(scenarioProfits)
    scatter(scenarioProfits, scenarioEnvImpacts, 120, 'filled', 's');
    xlabel('Profit (?)');
    ylabel('Environmental Impact (kg CO_2)');
    title('\\textbf{Weighted Sum Scenarios}');
    
    % Add labels
    for labelIdx = 1:length(scenarioNames)
        text(scenarioProfits(labelIdx), scenarioEnvImpacts(labelIdx), ...
             ['  ' scenarioNames{labelIdx}], 'FontSize', 8);
    end
    grid on;
end

% Subplot 5: TOPSIS scores
subplot(2, 3, 5);
if results.summary.feasible && isfield(results.finalSolution, 'topsisScores')
    topsisScores = results.finalSolution.topsisScores;
    ranking = results.finalSolution.ranking;
    
    bar(topsisScores(ranking));
    xlabel('Solution Rank');
    ylabel('TOPSIS Score');
    title('\\textbf{TOPSIS Decision Analysis}');
    grid on;
end

% Subplot 6: Objective summary
subplot(2, 3, 6);
if results.summary.feasible
    objectives = [results.summary.expectedProfit / 1000, ...  % Scale to thousands
                  results.summary.environmentalImpact / 1000, ...  % Scale to thousands
                  results.summary.serviceLevel * 100];  % Convert to percentage
    
    objectiveLabels = {'Profit (?k)', 'Env Impact (k kg CO_2)', 'Service Level (%)'};
    
    bar(objectives);
    set(gca, 'XTickLabel', objectiveLabels);
    ylabel('Objective Value');
    title('\\textbf{Final Solution Objectives}');
    xtickangle(45);
    grid on;
end

end

function displayProductionPlanningRecommendations(results)
% Display comprehensive production planning recommendations

fprintf('\\textbf{MULTI-OBJECTIVE PRODUCTION PLANNING RECOMMENDATIONS}\n');
fprintf('===========================================================\n\n');

if ~results.summary.feasible
    fprintf('No feasible solution found - problem constraints may be too restrictive\n');
    return;
end

% Executive Summary
fprintf('\\textbf{Executive Summary:}\n');
fprintf('Expected Monthly Profit: ?%.0f\n', results.summary.expectedProfit);
fprintf('Environmental Impact: %.0f kg CO2\n', results.summary.environmentalImpact);
fprintf('Service Level Achievement: %.1f%%\n', results.summary.serviceLevel * 100);

% Production Recommendations
fprintf('\n\\textbf{Recommended Production Schedule:}\n');
productionSchedule = results.summary.recommendedProduction;
products = results.problemParameters.products;
facilities = results.problemParameters.facilities;

for facilityIdx = 1:length(facilities)
    fprintf('%s:\n', facilities{facilityIdx});
    for productIdx = 1:length(products)
        quantity = productionSchedule(facilityIdx, productIdx);
        fprintf('  %s: %.0f units\n', products{productIdx}, quantity);
    end
end

% Resource Management
fprintf('\n\\textbf{Resource Utilisation Analysis:}\n');
labourUtil = results.summary.labourUtilisation;
materialUtil = results.summary.materialUtilisation;

for facilityIdx = 1:length(facilities)
    fprintf('%s:\n', facilities{facilityIdx});
    fprintf('  Labour Utilisation: %.1f%%\n', labourUtil(facilityIdx) * 100);
    fprintf('  Material Budget Utilisation: %.1f%%\n', materialUtil(facilityIdx) * 100);
end

% Strategic Insights
fprintf('\n\\textbf{Strategic Insights:}\n');

if results.tradeOffAnalysis.available
    correlations = results.tradeOffAnalysis.correlations;
    
    if correlations(1, 2) < -0.5
        fprintf('1. Strong trade-off exists between profit and environmental impact\n');
    else
        fprintf('1. Profit and environmental objectives show moderate alignment\n');
    end
    
    if correlations(1, 3) > 0.3
        fprintf('2. Service level improvements support profit maximisation\n');
    else
        fprintf('2. Service level and profit objectives require careful balancing\n');
    end
end

% Operational Recommendations
fprintf('\n\\textbf{Operational Recommendations:}\n');

if any(labourUtil > 0.9)
    fprintf('1. High labour utilisation detected - consider capacity expansion\n');
else
    fprintf('1. Labour capacity is adequate for current production plan\n');
end

if any(materialUtil > 0.85)
    fprintf('2. Material budget constraints are binding - negotiate better rates\n');
else
    fprintf('2. Material budget provides adequate flexibility\n');
end

if results.summary.environmentalImpact > results.problemParameters.environmentalTarget * 0.8
    fprintf('3. Environmental impact is near target - monitor closely\n');
else
    fprintf('3. Environmental performance has room for production increases\n');
end

% Implementation Guidelines
fprintf('\n\\textbf{Implementation Guidelines:}\n');
fprintf('1. Begin implementation with highest-margin products\n');
fprintf('2. Monitor environmental impact metrics weekly\n');
fprintf('3. Establish contingency plans for demand variations\n');
fprintf('4. Review and update objectives quarterly\n');
fprintf('5. Consider automation investments for high-volume products\n');

end
