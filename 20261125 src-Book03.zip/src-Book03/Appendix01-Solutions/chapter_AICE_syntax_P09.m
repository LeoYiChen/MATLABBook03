%% chapter_AICE_syntax_P09.m
% Graph shortest path and edge removal syntax.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AICE_syntax_P09
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
roadNetwork = graph(sourceNodes, targetNodes, edgeWeights);
[pathNodes, pathLength] = shortestpath(roadNetwork, ...
    originNode, destinationNode);
reducedNetwork = rmedge(roadNetwork, edgeIndex);
% - Computational Complexity -
% shortestpath uses Dijkstra's algorithm at O(E + V log V) for
% V nodes and E edges. rmedge is O(E). Urban road networks are
% sparse, so even city-scale graphs with hundreds of thousands
% of edges are queried in fractions of a second.
