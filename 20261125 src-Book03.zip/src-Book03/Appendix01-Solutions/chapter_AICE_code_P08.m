%% chapter_AICE_code_P08.m
% Solution~8: evaluating retrieval quality for a RAG pipeline (MATLABBook02_Chapter13_section8_Problem08.m).
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AICE_code_P08
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% MATLABBook02_Chapter13_section8_Problem08.m
% Problem 8: Evaluating Retrieval Quality for a RAG Pipeline
%
% Description : Computes Precision@1 and Mean Reciprocal Rank
%               for the TF-IDF retrieval system of Problem 7
%               against ground-truth relevance labels.
% Author      : Dr Yi Chen
% Date        : 2025
% MATLAB      : R2024b or later
% Toolboxes   : Text Analytics Toolbox
% Reference   : Chapter 13, Problem 8
% =================================================================

%% 1. Reuse corpus and queries from Problem 7
clauseTexts = [
    "Concrete for foundations shall achieve a characteristic " + ...
    "cube strength of 40 N/mm2 at 28 days."
    "Structural steelwork shall receive intumescent coating " + ...
    "providing 90 minutes fire resistance."
    "Air handling units shall be inspected quarterly and " + ...
    "filters replaced at 2500 hours of operation."
    "Bridge bearings shall be inspected for displacement " + ...
    "exceeding 15 mm from the neutral position."
    "Waterproofing membranes below ground level shall " + ...
    "comply with BS 8102 Grade 3."
    "All electrical installations shall conform to BS 7671 " + ...
    "and be tested before handover."
    "External glazing units shall achieve a U-value not " + ...
    "exceeding 1.2 W/m2K."
    "Acoustic partitions between dwellings shall provide " + ...
    "a minimum airborne sound insulation of 45 dB."];

queries = [
    "What is the required concrete strength for foundations?"
    "How often must the air handling unit filters be replaced?"
    "What sound insulation is required between apartments?"];

clauseDocuments = tokenizedDocument(clauseTexts);
bagModel        = bagOfWords(clauseDocuments);
tfidfMatrix     = tfidf(bagModel);

%% 2. Define ground-truth relevant clause for each query
groundTruth = [1, 3, 8];

%% 3. Evaluate retrieval quality
nQueries        = numel(queries);
precisionAt1    = 0;
reciprocalRanks = zeros(nQueries, 1);

for queryIndex = 1:nQueries
    queryDoc = tokenizedDocument(queries(queryIndex));
    queryVec = tfidf(bagModel, queryDoc);
    scores   = cosineSimilarity(tfidfMatrix, queryVec);

    [~, rankedIndices] = sort(scores, 'descend');

    % Precision@1
    if rankedIndices(1) == groundTruth(queryIndex)
        precisionAt1 = precisionAt1 + 1;
    end

    % Reciprocal rank
    relevantRank = find(rankedIndices == ...
        groundTruth(queryIndex), 1);
    reciprocalRanks(queryIndex) = 1 / relevantRank;

    fprintf('Query %d: ground truth = Clause %d, ' + ...
        'retrieved rank = %d, RR = %.3f\n', ...
        queryIndex, groundTruth(queryIndex), ...
        relevantRank, reciprocalRanks(queryIndex));
end

precisionAt1 = precisionAt1 / nQueries;
meanReciprocalRank = mean(reciprocalRanks);

fprintf('\nPrecision@1 : %.3f\n', precisionAt1);
fprintf('MRR         : %.3f\n', meanReciprocalRank);

%% 4. Discussion
fprintf(['\nInterpretation: P@1 = %.1f%% means the retrieval ' ...
    'layer returns the\ncorrect clause as its top pick for ' ...
    '%.0f%% of queries. MRR = %.3f\nindicates the average ' ...
    'position of the correct clause.\n'], ...
    100*precisionAt1, 100*precisionAt1, meanReciprocalRank);
% - Computational Complexity -
% Each query requires O(d log d) for sorting d = 8 similarity
% scores and O(d) for finding the ground-truth rank. Over
% q = 3 queries the total evaluation cost is O(q d log d),
% negligible for any practical corpus size. The retrieval
% itself, from Problem 7, dominates at O(nnz) per query.
