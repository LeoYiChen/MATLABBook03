%% p9.m
% MATLABBook03_ChapterAIBHS_Problem09.m
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : p9
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function MATLABBook03_ChapterAIBHS_Problem09
% Purpose: Granger-causality GRN inference. Author: Dr Leo Chen.
% R2024b (no toolbox). v1.0 2025-06-01.
    rng(0); T=200; G=3; E=zeros(T,G);
    for t=2:T
        E(t,1)=0.6*E(t-1,1)+0.3*randn;
        E(t,2)=0.5*E(t-1,1)+0.3*randn;
        E(t,3)=0.5*E(t-1,2)+0.3*randn;
    end
    for a=1:G, for b=1:G
        if a==b, continue; end
        if grangerF(E(:,a),E(:,b))>5, fprintf('Gene %d -> Gene %d\n',a,b); end
    end, end
end
function f = grangerF(src,tgt)
    y=tgt(2:end); py=tgt(1:end-1); px=src(1:end-1); n=numel(y);
    rr=sum((y-[ones(n,1) py]*([ones(n,1) py]\y)).^2);
    rf=sum((y-[ones(n,1) py px]*([ones(n,1) py px]\y)).^2);
    f=((rr-rf)/1)/(rf/(n-3));
end
