%% chapter_AIEFA_code_Problem4.m
% Logistic regression for credit risk classification (MATLABBook02_AIEFA_Problem4_CreditRiskLogistic.m).
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AIEFA_code_Problem4
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%=========================================================================
% FILE   : MATLABBook02_AIEFA_Problem4_CreditRiskLogistic.m
% DESCR. : Logistic regression from scratch for credit scoring
% AUTHOR : Dr Yi Chen
% MATLAB : R2023b (compatible with R2019b and later)
% CREATED: July 2025   VERSION: 1.0
%=========================================================================
clear; clc; close all;
rng(42);

%% -- 1. Synthetic Credit Data Generation --
numBorrowers = 1000;
numFeatures  = 4;
% Features: debt-to-income, credit score, loan amount, employ years
rawFeatures = [0.3 + 0.15*randn(numBorrowers, 1), ...   % debt-to-income
               700 + 80*randn(numBorrowers, 1), ...      % credit score
               25000 + 12000*randn(numBorrowers, 1), ... % loan amount
               8 + 4*randn(numBorrowers, 1)];            % employ years
% Clip to realistic ranges
rawFeatures(:,1) = max(rawFeatures(:,1), 0.05);
rawFeatures(:,2) = min(max(rawFeatures(:,2), 300), 850);
rawFeatures(:,3) = max(rawFeatures(:,3), 1000);
rawFeatures(:,4) = max(rawFeatures(:,4), 0);

% True logistic relationship
trueCoeffs = [0.8; -0.7; 0.35; -0.4];
trueIntercept = -0.5;

% Standardise features
featureMeans = mean(rawFeatures);
featureStds  = std(rawFeatures);
normFeatures = (rawFeatures - featureMeans) ./ featureStds;

% Generate labels
linearPredictor = trueIntercept + normFeatures * trueCoeffs;
probDefault     = 1 ./ (1 + exp(-linearPredictor));
labels          = double(rand(numBorrowers, 1) < probDefault);
fprintf('Default rate: %.2f%%\n', 100 * mean(labels));

%% -- 2. Train/Test Split (70/30) --
splitIdx     = round(0.7 * numBorrowers);
xTrain       = [ones(splitIdx, 1), normFeatures(1:splitIdx, :)];
yTrain       = labels(1:splitIdx);
xTest        = [ones(numBorrowers - splitIdx, 1), ...
                normFeatures(splitIdx+1:end, :)];
yTest        = labels(splitIdx+1:end);
numTrain     = size(xTrain, 1);
numTest      = size(xTest, 1);

%% -- 3. Gradient Descent Optimisation --
sigmoid       = @(z) 1 ./ (1 + exp(-z));
learningRate  = 0.5;
numIterations = 2000;
betaEstimate  = zeros(numFeatures + 1, 1);
lossHistory   = zeros(numIterations, 1);

for iterIdx = 1:numIterations
    hTrain = sigmoid(xTrain * betaEstimate);
    % Cross-entropy loss (with numerical stability)
    lossHistory(iterIdx) = -(1/numTrain) * ...
        sum(yTrain .* log(hTrain + 1e-12) + ...
            (1 - yTrain) .* log(1 - hTrain + 1e-12));
    % Gradient
    gradientVec = (1/numTrain) * (xTrain' * (hTrain - yTrain));
    betaEstimate = betaEstimate - learningRate * gradientVec;
end
fprintf('\nFinal training loss: %.6f\n', lossHistory(end));
fprintf('Estimated coefficients:\n');
featureNames = {'Intercept', 'Debt-to-Income', ...
                'Credit Score', 'Loan Amount', 'Employ Years'};
for featIdx = 1:(numFeatures + 1)
    fprintf('  %-16s: %+.4f\n', ...
        featureNames{featIdx}, betaEstimate(featIdx));
end

%% -- 4. Test Set Evaluation --
hTest       = sigmoid(xTest * betaEstimate);
predLabels  = double(hTest >= 0.5);

truePos  = sum(predLabels == 1 & yTest == 1);
trueNeg  = sum(predLabels == 0 & yTest == 0);
falsePos = sum(predLabels == 1 & yTest == 0);
falseNeg = sum(predLabels == 0 & yTest == 1);

accuracy  = (truePos + trueNeg) / numTest;
precision = truePos / max(truePos + falsePos, 1);
recall    = truePos / max(truePos + falseNeg, 1);
f1Score   = 2 * precision * recall / ...
            max(precision + recall, 1e-12);

fprintf('\n- Test Set Performance -\n');
fprintf('Accuracy  : %.4f\n', accuracy);
fprintf('Precision : %.4f\n', precision);
fprintf('Recall    : %.4f\n', recall);
fprintf('F1 Score  : %.4f\n', f1Score);
fprintf('Confusion Matrix:\n');
fprintf('           Pred=0  Pred=1\n');
fprintf('  Actual=0  %4d    %4d\n', trueNeg, falsePos);
fprintf('  Actual=1  %4d    %4d\n', falseNeg, truePos);

%% -- 5. Plotting --
figure('Position', [80, 80, 1000, 450]);
subplot(1, 2, 1);
plot(1:numIterations, lossHistory, 'b-', 'LineWidth', 1.0);
xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Cross-Entropy Loss $J(\beta)$', ...
    'Interpreter', 'latex', 'FontSize', 11);
title('Training Loss Curve', 'Interpreter', 'latex');
grid on;

subplot(1, 2, 2);
% Decision boundary for features 1 (debt-to-income) and
%   2 (credit score) with other features at mean (=0)
feat1Range = linspace(min(normFeatures(:,1)) - 0.5, ...
                      max(normFeatures(:,1)) + 0.5, 200);
feat2Range = linspace(min(normFeatures(:,2)) - 0.5, ...
                      max(normFeatures(:,2)) + 0.5, 200);
[gridF1, gridF2] = meshgrid(feat1Range, feat2Range);
gridInput  = [ones(numel(gridF1), 1), gridF1(:), gridF2(:), ...
              zeros(numel(gridF1), 2)];
gridProb   = sigmoid(gridInput * betaEstimate);
gridProb   = reshape(gridProb, size(gridF1));
contour(gridF1, gridF2, gridProb, [0.5, 0.5], 'k-', ...
    'LineWidth', 1.5);
hold on;
defaultIdx = yTest == 1;
scatter(normFeatures(splitIdx+find(~defaultIdx), 1), ...
        normFeatures(splitIdx+find(~defaultIdx), 2), ...
        15, 'b', 'filled', 'MarkerFaceAlpha', 0.4);
scatter(normFeatures(splitIdx+find(defaultIdx), 1), ...
        normFeatures(splitIdx+find(defaultIdx), 2), ...
        15, 'r', 'filled', 'MarkerFaceAlpha', 0.4);
xlabel('Debt-to-Income (standardised)', ...
    'Interpreter', 'latex', 'FontSize', 11);
ylabel('Credit Score (standardised)', ...
    'Interpreter', 'latex', 'FontSize', 11);
title('Decision Boundary (Test Set)', 'Interpreter', 'latex');
legend('Boundary', 'Non-Default', 'Default', ...
    'Interpreter', 'latex', 'Location', 'best');
grid on;
% Computational Complexity:
% Each gradient descent iteration: O(n*p) for n training
% samples and p features. Over K iterations: O(K*n*p).
% Test evaluation: O(n_test * p). Confusion matrix: O(n_test).
% For n=700, p=5, K=2000: approximately 7 million multiply-
% add operations total - convergence well under one second.
