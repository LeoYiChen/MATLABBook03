%% chapter_AILMI_prob10_drift.m
% Drift detection using accuracy monitoring.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AILMI_prob10_drift
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function isDrift = detectConceptDrift(accuracyHistory, windowSize, threshold)
    % Detect concept drift via accuracy degradation
    % accuracyHistory: [timesteps x 1] accuracy over time
    % windowSize: Number of recent timesteps to average
    % threshold: Percentage drop indicating drift
    
    if length(accuracyHistory) < windowSize * 2
        isDrift = false;
        return;
    end
    
    % Compute moving average
    recentAccuracy = mean(accuracyHistory(end-windowSize+1:end));
    referenceAccuracy = mean(accuracyHistory(end-windowSize*2+1:end-windowSize));
    
    % Check for significant drop
    accuracyDrop = referenceAccuracy - recentAccuracy;
    isDrift = (accuracyDrop > threshold);
    
    if isDrift
        fprintf('Drift detected! Accuracy dropped %.2f%%\n', accuracyDrop * 100);
    end
end
