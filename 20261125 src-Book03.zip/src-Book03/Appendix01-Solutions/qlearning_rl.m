%% qlearning_rl.m
% Q-Learning Reinforcement Learning
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : qlearning_rl
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Q-Learning Reinforcement Learning Implementation
% Author: Dr Leo Chen
% Version: R2023b
% Date: November 2024

function qlearning_reinforcement_learning()
% Define grid world environment
grid_size = [5, 5];
num_states = prod(grid_size);
num_actions = 4; % Up, Down, Left, Right

% Create custom grid world environment
environment = create_grid_world(grid_size);

% Define Q-learning parameters
learning_rate = 0.1;
discount_factor = 0.95;
epsilon_start = 1.0;
epsilon_end = 0.01;
epsilon_decay = 0.995;
num_episodes = 1000;

% Initialize Q-table
q_table = zeros(num_states, num_actions);

% Training statistics
episode_rewards = zeros(num_episodes, 1);
episode_steps = zeros(num_episodes, 1);
epsilon_values = zeros(num_episodes, 1);

% Training loop
fprintf('Training Q-Learning Agent...\\n');

for episode = 1:num_episodes
    % Reset environment
    current_state = environment.start_state;
    total_reward = 0;
    steps = 0;
    
    % Calculate current epsilon for exploration
    current_epsilon = max(epsilon_end, ...
        epsilon_start * (epsilon_decay ^ episode));
    epsilon_values(episode) = current_epsilon;
    
    while ~environment.is_terminal(current_state) && steps < 100
        % Choose action using epsilon-greedy policy
        if rand() < current_epsilon
            % Exploration: random action
            action = randi(num_actions);
        else
            % Exploitation: best action according to Q-table
            [~, action] = max(q_table(current_state, :));
        end
        
        % Take action and observe result
        [next_state, reward, is_done] = environment.step(current_state, action);
        
        % Q-learning update rule
        if is_done
            target_value = reward;
        else
            target_value = reward + discount_factor * max(q_table(next_state, :));
        end
        
        q_table(current_state, action) = q_table(current_state, action) + ...
            learning_rate * (target_value - q_table(current_state, action));
        
        % Update state and statistics
        current_state = next_state;
        total_reward = total_reward + reward;
        steps = steps + 1;
    end
    
    episode_rewards(episode) = total_reward;
    episode_steps(episode) = steps;
    
    % Progress reporting
    if mod(episode, 100) == 0
        avg_reward = mean(episode_rewards(max(1, episode-99):episode));
        fprintf('Episode %d: Average Reward = %.2f, Epsilon = %.3f\\n', ...
            episode, avg_reward, current_epsilon);
    end
end

% Extract learned policy
[~, optimal_policy] = max(q_table, [], 2);

% Evaluate final policy
evaluation_episodes = 100;
evaluation_rewards = zeros(evaluation_episodes, 1);

for eval_episode = 1:evaluation_episodes
    current_state = environment.start_state;
    total_reward = 0;
    steps = 0;
    
    while ~environment.is_terminal(current_state) && steps < 100
        action = optimal_policy(current_state);
        [next_state, reward, ~] = environment.step(current_state, action);
        
        current_state = next_state;
        total_reward = total_reward + reward;
        steps = steps + 1;
    end
    
    evaluation_rewards(eval_episode) = total_reward;
end

% Visualisation
figure('Name', 'Q-Learning Results');

% Training progress
subplot(2, 3, 1);
moving_avg_window = 50;
moving_avg_rewards = movmean(episode_rewards, moving_avg_window);
plot(1:num_episodes, episode_rewards, 'b-', 'Alpha', 0.3);
hold on;
plot(1:num_episodes, moving_avg_rewards, 'r-', 'LineWidth', 2);
xlabel('Episode', 'Interpreter', 'latex');
ylabel('Episode Reward', 'Interpreter', 'latex');
title('Training Progress', 'Interpreter', 'latex');
legend('Episode Rewards', 'Moving Average', 'Location', 'best');
grid on;

% Epsilon decay
subplot(2, 3, 2);
plot(1:num_episodes, epsilon_values, 'g-', 'LineWidth', 2);
xlabel('Episode', 'Interpreter', 'latex');
ylabel('Epsilon Value', 'Interpreter', 'latex');
title('Exploration Rate Decay', 'Interpreter', 'latex');
grid on;

% Q-values heatmap
subplot(2, 3, 3);
max_q_values = max(q_table, [], 2);
q_grid = reshape(max_q_values, grid_size);
imagesc(q_grid);
colorbar;
xlabel('Grid X', 'Interpreter', 'latex');
ylabel('Grid Y', 'Interpreter', 'latex');
title('State Values (Max Q)', 'Interpreter', 'latex');

% Policy visualisation
subplot(2, 3, 4);
policy_grid = reshape(optimal_policy, grid_size);
imagesc(policy_grid);
colorbar;
xlabel('Grid X', 'Interpreter', 'latex');
ylabel('Grid Y', 'Interpreter', 'latex');
title('Learned Policy', 'Interpreter', 'latex');

% Add action arrows to policy plot
hold on;
action_symbols = {'^', 'v', '<', '>'};
for row = 1:grid_size(1)
    for col = 1:grid_size(2)
        state_idx = (row - 1) * grid_size(2) + col;
        if ~environment.is_terminal(state_idx)
            action = optimal_policy(state_idx);
            text(col, row, action_symbols{action}, ...
                'HorizontalAlignment', 'center', ...
                'FontSize', 12, 'FontWeight', 'bold', 'Color', 'white');
        end
    end
end

% Steps per episode
subplot(2, 3, 5);
moving_avg_steps = movmean(episode_steps, moving_avg_window);
plot(1:num_episodes, episode_steps, 'b-', 'Alpha', 0.3);
hold on;
plot(1:num_episodes, moving_avg_steps, 'r-', 'LineWidth', 2);
xlabel('Episode', 'Interpreter', 'latex');
ylabel('Steps to Goal', 'Interpreter', 'latex');
title('Learning Efficiency', 'Interpreter', 'latex');
legend('Episode Steps', 'Moving Average', 'Location', 'best');
grid on;

% Policy evaluation results
subplot(2, 3, 6);
histogram(evaluation_rewards, 20, 'FaceColor', 'blue', 'Alpha', 0.7);
xlabel('Episode Reward', 'Interpreter', 'latex');
ylabel('Frequency', 'Interpreter', 'latex');
title('Final Policy Performance', 'Interpreter', 'latex');
grid on;

% Display performance metrics
fprintf('\\n\\textbf{Q-Learning Training Results}:\\n');
fprintf('Training Episodes: %d\\n', num_episodes);
fprintf('Final Average Reward: %.2f\\n', mean(episode_rewards(end-99:end)));
fprintf('Policy Evaluation Reward: %.2f -- %.2f\\n', ...
    mean(evaluation_rewards), std(evaluation_rewards));
fprintf('Average Steps to Goal: %.1f\\n', mean(episode_steps(end-99:end)));
fprintf('Learning Rate: %.2f\\n', learning_rate);
fprintf('Discount Factor: %.2f\\n', discount_factor);

% Analyse convergence
convergence_threshold = 0.01;
reward_diff = diff(moving_avg_rewards);
convergence_episode = find(abs(reward_diff) < convergence_threshold, 1, 'first');

if ~isempty(convergence_episode)
    fprintf('Convergence achieved at episode: %d\\n', convergence_episode);
else
    fprintf('Convergence not achieved within %d episodes\\n', num_episodes);
end

end

function environment = create_grid_world(grid_size)
% Create a simple grid world environment
environment = struct();
environment.grid_size = grid_size;
environment.num_states = prod(grid_size);

% Define start and goal positions
environment.start_state = 1; % Top-left corner
environment.goal_state = environment.num_states; % Bottom-right corner
environment.obstacle_states = []; % No obstacles for simplicity

% Define reward structure
environment.goal_reward = 100;
environment.step_penalty = -1;
environment.obstacle_penalty = -10;

% Function to check if state is terminal
environment.is_terminal = @(state) (state == environment.goal_state);

% Function to take a step in the environment
environment.step = @(state, action) step_function(state, action, environment);

end

function [next_state, reward, is_done] = step_function(state, action, env)
% Convert state to grid coordinates
[row, col] = ind2sub(env.grid_size, state);

% Define actions: 1=Up, 2=Down, 3=Left, 4=Right
switch action
    case 1 % Up
        new_row = max(1, row - 1);
        new_col = col;
    case 2 % Down
        new_row = min(env.grid_size(1), row + 1);
        new_col = col;
    case 3 % Left
        new_row = row;
        new_col = max(1, col - 1);
    case 4 % Right
        new_row = row;
        new_col = min(env.grid_size(2), col + 1);
    otherwise
        new_row = row;
        new_col = col;
end

% Convert back to state index
next_state = sub2ind(env.grid_size, new_row, new_col);

% Calculate reward
if next_state == env.goal_state
    reward = env.goal_reward;
    is_done = true;
elseif ismember(next_state, env.obstacle_states)
    reward = env.obstacle_penalty;
    next_state = state; % Stay in current state
    is_done = false;
else
    reward = env.step_penalty;
    is_done = false;
end

end
