%% chapter_AIinMOR_problem_3.m
% Dynamic Workforce Scheduling Solution.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AIinMOR_problem_3
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [workforceSchedulingResults] = solveDynamicWorkforceScheduling()
% Dynamic Workforce Scheduling with Skill Matching and Learning
% Author: Dr Leo Chen
% Version: 1.0
% Date: 2025
% Description: AI-driven workforce optimisation with skill development

fprintf('\\textbf{Dynamic Workforce Scheduling with Skill Matching}\n');
fprintf('====================================================\n\n');

% Define workforce and project environment
workforceEnvironment = defineWorkforceEnvironment();

% Implement skill development model
skillDevelopmentModel = implementSkillDevelopmentModel(workforceEnvironment);

% Create constraint satisfaction framework
constraintFramework = createConstraintSatisfactionFramework(workforceEnvironment);

% Train reinforcement learning agent
reinforcementLearningAgent = trainReinforcementLearningAgent(workforceEnvironment, skillDevelopmentModel);

% Solve dynamic scheduling problem
schedulingResults = solveDynamicSchedulingProblem(workforceEnvironment, skillDevelopmentModel, 
    constraintFramework, reinforcementLearningAgent);

% Validate through long-term simulation
validationResults = validateThroughLongTermSimulation(schedulingResults, workforceEnvironment);

% Consolidate results
workforceSchedulingResults = consolidateWorkforceSchedulingResults(workforceEnvironment, 
    skillDevelopmentModel, constraintFramework, reinforcementLearningAgent, 
    schedulingResults, validationResults);

% Generate comprehensive visualisations
generateWorkforceSchedulingVisualisations(workforceSchedulingResults);

% Display workforce management recommendations
displayWorkforceManagementRecommendations(workforceSchedulingResults);

end

function environment = defineWorkforceEnvironment()
% Define comprehensive workforce and project environment

environment = struct();

fprintf('\\textbf{Defining Workforce Environment:}\n');

% Consultant profiles
environment.consultants = struct();
environment.consultants.numConsultants = 25;
environment.consultants.names = arrayfun(@(x) sprintf('Consultant_%02d', x), 
    1:environment.consultants.numConsultants, 'UniformOutput', false);

% Skill categories and levels
environment.skills = struct();
environment.skills.categories = {
    'Strategy Consulting', 'Data Analytics', 'Digital Transformation', 
    'Operations Improvement', 'Change Management', 'Industry Expertise',
    'Project Management', 'Client Relations'
};
environment.skills.numSkills = length(environment.skills.categories);
environment.skills.maxLevel = 5; % Skill levels 1-5

% Generate initial skill matrix
rng(2025);
environment.consultants.skillMatrix = generateInitialSkillMatrix(environment);

% Consultant attributes
environment.consultants.experience = 1 + 15 * rand(environment.consultants.numConsultants, 1); % 1-16 years
environment.consultants.seniority = discretizeExperience(environment.consultants.experience);
environment.consultants.availability = ones(environment.consultants.numConsultants, 1); % All initially available
environment.consultants.careerGoals = generateCareerGoals(environment);

% Project portfolio
environment.projects = struct();
environment.projects.numProjects = 15;
environment.projects.names = arrayfun(@(x) sprintf('Project_%02d', x), 
    1:environment.projects.numProjects, 'UniformOutput', false);

% Project characteristics
environment.projects.skillRequirements = generateProjectSkillRequirements(environment);
environment.projects.durations = 2 + 10 * rand(environment.projects.numProjects, 1); % 2-12 months
environment.projects.teamSizes = randi([3, 8], environment.projects.numProjects, 1);
environment.projects.priorities = randi([1, 3], environment.projects.numProjects, 1); % Priority levels
environment.projects.clientSatisfactionWeights = rand(environment.projects.numProjects, 1);

% Learning parameters
environment.learning = struct();
environment.learning.baseRates = [0.3, 0.25, 0.2, 0.15, 0.1]; % Learning rates by seniority
environment.learning.crossSkillTransfer = 0.1; % Cross-skill learning coefficient
environment.learning.forgettingRate = 0.05; % Monthly skill decay without practice

fprintf('Workforce environment defined:\n');
fprintf('Consultants: %d, Projects: %d, Skills: %d\n', 
    environment.consultants.numConsultants, environment.projects.numProjects, environment.skills.numSkills);

end

function skillMatrix = generateInitialSkillMatrix(environment)
% Generate realistic initial skill matrix

numConsultants = environment.consultants.numConsultants;
numSkills = environment.skills.numSkills;
maxLevel = environment.skills.maxLevel;

skillMatrix = zeros(numConsultants, numSkills);

for consultantIdx = 1:numConsultants
    experience = environment.consultants.experience(consultantIdx);
    
    % Primary expertise (1-2 strong skills)
    primarySkills = randsample(numSkills, randi([1, 2]));
    for skillIdx = primarySkills
        baseLevel = min(maxLevel, 2 + floor(experience / 3));
        skillMatrix(consultantIdx, skillIdx) = min(maxLevel, baseLevel + randi([-1, 1]));
    end
    
    % Secondary skills (lower levels)
    secondarySkills = setdiff(1:numSkills, primarySkills);
    numSecondarySkills = min(length(secondarySkills), randi([2, 4]));
    selectedSecondary = randsample(secondarySkills, numSecondarySkills);
    
    for skillIdx = selectedSecondary
        baseLevel = min(maxLevel, 1 + floor(experience / 5));
        skillMatrix(consultantIdx, skillIdx) = min(maxLevel, max(1, baseLevel + randi([-1, 1])));
    end
end

% Ensure non-negative values
skillMatrix = max(skillMatrix, 0);

end

function seniority = discretizeExperience(experience)
% Convert experience to seniority levels

seniority = zeros(size(experience));

for consultantIdx = 1:length(experience)
    exp = experience(consultantIdx);
    if exp < 2
        seniority(consultantIdx) = 1; % Junior
    elseif exp < 5
        seniority(consultantIdx) = 2; % Associate
    elseif exp < 8
        seniority(consultantIdx) = 3; % Senior
    elseif exp < 12
        seniority(consultantIdx) = 4; % Principal
    else
        seniority(consultantIdx) = 5; % Partner
    end
end

end

function careerGoals = generateCareerGoals(environment)
% Generate career development goals for consultants

numConsultants = environment.consultants.numConsultants;
numSkills = environment.skills.numSkills;

careerGoals = struct();

for consultantIdx = 1:numConsultants
    consultantGoals = struct();
    
    % Target skill levels (aspirational)
    consultantGoals.targetSkillLevels = environment.consultants.skillMatrix(consultantIdx, :) + 
        randi([0, 2], 1, numSkills);
    consultantGoals.targetSkillLevels = min(consultantGoals.targetSkillLevels, environment.skills.maxLevel);
    
    % Priority skills for development
    consultantGoals.prioritySkills = randsample(numSkills, randi([1, 3]));
    
    % Career track preference
    trackPreferences = {'Specialist', 'Generalist', 'Leadership'};
    consultantGoals.careerTrack = trackPreferences{randi(3)};
    
    careerGoals(consultantIdx) = consultantGoals;
end

end

function skillRequirements = generateProjectSkillRequirements(environment)
% Generate skill requirements for projects

numProjects = environment.projects.numProjects;
numSkills = environment.skills.numSkills;
maxLevel = environment.skills.maxLevel;

skillRequirements = zeros(numProjects, numSkills);

for projectIdx = 1:numProjects
    % Each project requires 3-5 skills with varying levels
    numRequiredSkills = randi([3, 5]);
    requiredSkills = randsample(numSkills, numRequiredSkills);
    
    for skillIdx = requiredSkills
        % Skill level requirements (1-5)
        requiredLevel = randi([2, maxLevel]);
        skillRequirements(projectIdx, skillIdx) = requiredLevel;
    end
end

end

function skillModel = implementSkillDevelopmentModel(environment)
% Implement comprehensive skill development model

skillModel = struct();

fprintf('\\textbf{Implementing Skill Development Model:}\n');

% Learning curve parameters
skillModel.learningCurves = defineLearningCurves(environment);

% Skill transfer model
skillModel.transferMatrix = defineSkillTransferMatrix(environment);

% Experience tracking
skillModel.experienceTracking = initializeExperienceTracking(environment);

% Development prediction model
skillModel.predictionModel = trainSkillDevelopmentPredictor(environment);

fprintf('Skill development model implemented\n\n');

end

function learningCurves = defineLearningCurves(environment)
% Define learning curves for skill development

learningCurves = struct();

numSkills = environment.skills.numSkills;
maxLevel = environment.skills.maxLevel;

% Learning rate matrix [consultant_seniority x skill_level]
learningCurves.baseLearningRates = [
    [0.4, 0.3, 0.2, 0.15, 0.1];  % Junior
    [0.35, 0.28, 0.2, 0.15, 0.1]; % Associate  
    [0.3, 0.25, 0.2, 0.15, 0.1];  % Senior
    [0.25, 0.22, 0.18, 0.15, 0.1]; % Principal
    [0.2, 0.18, 0.15, 0.12, 0.08]  % Partner
];

% Skill-specific learning modifiers
learningCurves.skillModifiers = [
    1.2, % Strategy Consulting (faster learning)
    0.8, % Data Analytics (slower, technical)
    0.9, % Digital Transformation
    1.0, % Operations Improvement
    1.1, % Change Management
    0.7, % Industry Expertise (very slow)
    1.0, % Project Management
    1.3  % Client Relations (fastest)
];

% Experience factors
learningCurves.experienceBonus = struct();
learningCurves.experienceBonus.threshold = 6; % months on similar projects
learningCurves.experienceBonus.multiplier = 1.2;

end

function transferMatrix = defineSkillTransferMatrix(environment)
% Define skill transfer relationships

numSkills = environment.skills.numSkills;
transferMatrix = eye(numSkills) * 0.1; % Base self-reinforcement

% Define specific transfer relationships
% Strategy <-> Operations
transferMatrix(1, 4) = 0.3; transferMatrix(4, 1) = 0.3;

% Data Analytics <-> Digital Transformation  
transferMatrix(2, 3) = 0.4; transferMatrix(3, 2) = 0.4;

% Change Management <-> Client Relations
transferMatrix(5, 8) = 0.5; transferMatrix(8, 5) = 0.5;

% Project Management benefits from all other skills
transferMatrix(7, :) = 0.2;
transferMatrix(:, 7) = 0.2;

% Industry Expertise transfers moderately to Strategy
transferMatrix(6, 1) = 0.25;

end

function experienceTracking = initializeExperienceTracking(environment)
% Initialize experience tracking for consultants

experienceTracking = struct();

numConsultants = environment.consultants.numConsultants;
numSkills = environment.skills.numSkills;

% Track months of experience per skill
experienceTracking.monthsPerSkill = zeros(numConsultants, numSkills);

% Track project types and durations
experienceTracking.projectHistory = cell(numConsultants, 1);

for consultantIdx = 1:numConsultants
    experienceTracking.projectHistory{consultantIdx} = struct();
    experienceTracking.projectHistory{consultantIdx}.projects = {};
    experienceTracking.projectHistory{consultantIdx}.durations = [];
    experienceTracking.projectHistory{consultantIdx}.skillsUsed = [];
end

% Initialize with historical experience
totalExperience = environment.consultants.experience * 12; % Convert years to months

for consultantIdx = 1:numConsultants
    currentSkills = environment.consultants.skillMatrix(consultantIdx, :);
    activeSkills = find(currentSkills > 0);
    
    if ~isempty(activeSkills)
        experiencePerSkill = totalExperience(consultantIdx) / length(activeSkills);
        experienceTracking.monthsPerSkill(consultantIdx, activeSkills) = experiencePerSkill;
    end
end

end

function predictionModel = trainSkillDevelopmentPredictor(environment)
% Train model to predict skill development outcomes

predictionModel = struct();

% Simple regression model for skill progression
% Features: current skill level, experience, learning rate, project type
predictionModel.type = 'linear_regression';

% Coefficients for skill development prediction (simplified)
predictionModel.coefficients = struct();
predictionModel.coefficients.currentLevel = 0.8; % Current skill impact
predictionModel.coefficients.experience = 0.1;   % Experience impact
predictionModel.coefficients.projectMatch = 0.3; % Project-skill match impact
predictionModel.coefficients.timeOnProject = 0.2; % Duration impact

predictionModel.maxGrowthPerMonth = 0.15; % Maximum skill growth per month

end

function constraintFramework = createConstraintSatisfactionFramework(environment)
% Create constraint satisfaction framework for scheduling

constraintFramework = struct();

fprintf('\\textbf{Creating Constraint Satisfaction Framework:}\n');

% Hard constraints
constraintFramework.hardConstraints = defineHardConstraints(environment);

% Soft constraints  
constraintFramework.softConstraints = defineSoftConstraints(environment);

% Constraint solver
constraintFramework.solver = implementConstraintSolver(environment);

fprintf('Constraint satisfaction framework created\n\n');

end

function hardConstraints = defineHardConstraints(environment)
% Define hard constraints that must be satisfied

hardConstraints = struct();

% Availability constraints
hardConstraints.availability = struct();
hardConstraints.availability.description = 'Consultants cannot be double-booked';
hardConstraints.availability.type = 'temporal_exclusion';

% Minimum skill requirements
hardConstraints.skillRequirements = struct();
hardConstraints.skillRequirements.description = 'Projects must have minimum required skills';
hardConstraints.skillRequirements.tolerance = 0.8; % Can be 80% of required level

% Team size constraints
hardConstraints.teamSize = struct();
hardConstraints.teamSize.description = 'Projects must have required team size';
hardConstraints.teamSize.minSize = environment.projects.teamSizes;
hardConstraints.teamSize.maxSize = environment.projects.teamSizes + 2; % Some flexibility

% Geographic constraints (simplified)
hardConstraints.geographic = struct();
hardConstraints.geographic.description = 'Travel limitations';
hardConstraints.geographic.maxTravelProjects = 2; % Max 2 travel projects per consultant

end

function softConstraints = defineSoftConstraints(environment)
% Define soft constraints with penalty weights

softConstraints = struct();

% Skill development preferences
softConstraints.skillDevelopment = struct();
softConstraints.skillDevelopment.weight = 0.3;
softConstraints.skillDevelopment.description = 'Align assignments with career goals';

% Workload balancing
softConstraints.workloadBalance = struct();
softConstraints.workloadBalance.weight = 0.2;
softConstraints.workloadBalance.description = 'Balance workload across consultants';

% Client satisfaction optimization
softConstraints.clientSatisfaction = struct();
softConstraints.clientSatisfaction.weight = 0.25;
softConstraints.clientSatisfaction.description = 'Maximize expected client satisfaction';

% Team composition diversity
softConstraints.teamDiversity = struct();
softConstraints.teamDiversity.weight = 0.15;
softConstraints.teamDiversity.description = 'Ensure diverse team composition';

% Learning opportunity maximization
softConstraints.learningOpportunities = struct();
softConstraints.learningOpportunities.weight = 0.1;
softConstraints.learningOpportunities.description = 'Maximize learning opportunities';

end

function solver = implementConstraintSolver(environment)
% Implement constraint satisfaction solver

solver = struct();

% Solver type
solver.type = 'hybrid_optimization';

% Search strategies
solver.searchStrategies = {'genetic_algorithm', 'local_search', 'constraint_programming'};

% Parameters
solver.parameters = struct();
solver.parameters.populationSize = 100;
solver.parameters.maxIterations = 500;
solver.parameters.crossoverRate = 0.8;
solver.parameters.mutationRate = 0.1;
solver.parameters.localSearchDepth = 50;

end

function rlAgent = trainReinforcementLearningAgent(environment, skillModel)
% Train reinforcement learning agent for adaptive scheduling

rlAgent = struct();

fprintf('\\textbf{Training Reinforcement Learning Agent:}\n');

% Define state space
rlAgent.stateSpace = defineStateSpace(environment);

% Define action space
rlAgent.actionSpace = defineActionSpace(environment);

% Define reward function
rlAgent.rewardFunction = defineRewardFunction(environment, skillModel);

% Train Q-learning agent
rlAgent.qLearningAgent = trainQLearningAgent(environment, rlAgent);

% Train policy gradient agent
rlAgent.policyGradientAgent = trainPolicyGradientAgent(environment, rlAgent);

fprintf('Reinforcement learning agents trained\n\n');

end

function stateSpace = defineStateSpace(environment)
% Define state space for RL agent

stateSpace = struct();

% State components
stateSpace.components = {
    'consultant_skills', 'consultant_availability', 'project_requirements',
    'project_progress', 'team_compositions', 'skill_development_progress'
};

% State dimensionality
numConsultants = environment.consultants.numConsultants;
numProjects = environment.projects.numProjects;
numSkills = environment.skills.numSkills;

stateSpace.dimensions = struct();
stateSpace.dimensions.consultantSkills = [numConsultants, numSkills];
stateSpace.dimensions.availability = [numConsultants, 1];
stateSpace.dimensions.projectRequirements = [numProjects, numSkills];
stateSpace.dimensions.projectProgress = [numProjects, 1];

% State encoding
stateSpace.encoding = 'normalized_vector';
stateSpace.totalDimension = numConsultants * numSkills + numConsultants + 
    numProjects * numSkills + numProjects;

end

function actionSpace = defineActionSpace(environment)
% Define action space for RL agent

actionSpace = struct();

% Action types
actionSpace.types = {'assign_consultant_to_project', 'remove_consultant_from_project', 
    'swap_consultants', 'defer_project'};

% Action encoding
numConsultants = environment.consultants.numConsultants;
numProjects = environment.projects.numProjects;

actionSpace.assignmentActions = numConsultants * numProjects;
actionSpace.removalActions = numConsultants * numProjects;
actionSpace.swapActions = nchoosek(numConsultants, 2) * numProjects;
actionSpace.deferActions = numProjects;

actionSpace.totalActions = actionSpace.assignmentActions + actionSpace.removalActions + 
    actionSpace.swapActions + actionSpace.deferActions;

end

function rewardFunction = defineRewardFunction(environment, skillModel)
% Define reward function for RL agent

rewardFunction = struct();

% Reward components and weights
rewardFunction.components = struct();

% Project completion reward
rewardFunction.components.projectCompletion = struct();
rewardFunction.components.projectCompletion.weight = 0.4;
rewardFunction.components.projectCompletion.baseReward = 100;

% Client satisfaction reward
rewardFunction.components.clientSatisfaction = struct();
rewardFunction.components.clientSatisfaction.weight = 0.25;
rewardFunction.components.clientSatisfaction.maxReward = 50;

% Skill development reward
rewardFunction.components.skillDevelopment = struct();
rewardFunction.components.skillDevelopment.weight = 0.2;
rewardFunction.components.skillDevelopment.maxReward = 30;

% Resource utilization reward
rewardFunction.components.resourceUtilization = struct();
rewardFunction.components.resourceUtilization.weight = 0.15;
rewardFunction.components.resourceUtilization.maxReward = 20;

% Penalties
rewardFunction.penalties = struct();
rewardFunction.penalties.constraintViolation = -50;
rewardFunction.penalties.resourceWaste = -10;
rewardFunction.penalties.skillMismatch = -25;

end

function qAgent = trainQLearningAgent(environment, rlAgent)
% Train Q-learning agent (simplified implementation)

qAgent = struct();

% Q-learning parameters
qAgent.parameters = struct();
qAgent.parameters.learningRate = 0.1;
qAgent.parameters.discountFactor = 0.95;
qAgent.parameters.explorationRate = 0.1;
qAgent.parameters.trainingEpisodes = 1000;

% Initialize Q-table (simplified - would use function approximation in practice)
numStates = 1000; % Discretized state space
numActions = rlAgent.actionSpace.totalActions;

qAgent.qTable = zeros(numStates, numActions);

% Training simulation (simplified)
for episode = 1:qAgent.parameters.trainingEpisodes
    % Simulate episode and update Q-values
    % This would involve full environment simulation
    
    if mod(episode, 100) == 0
        fprintf('Q-learning episode %d/%d completed\n', episode, qAgent.parameters.trainingEpisodes);
    end
end

qAgent.trained = true;

end

function pgAgent = trainPolicyGradientAgent(environment, rlAgent)
% Train policy gradient agent (simplified implementation)

pgAgent = struct();

% Policy gradient parameters
pgAgent.parameters = struct();
pgAgent.parameters.learningRate = 0.01;
pgAgent.parameters.trainingEpisodes = 500;
pgAgent.parameters.batchSize = 32;

% Policy network (simplified representation)
pgAgent.policyNetwork = struct();
pgAgent.policyNetwork.weights = randn(rlAgent.stateSpace.totalDimension, rlAgent.actionSpace.totalActions);
pgAgent.policyNetwork.bias = zeros(1, rlAgent.actionSpace.totalActions);

% Training simulation
for episode = 1:pgAgent.parameters.trainingEpisodes
    % Update policy network weights
    % This would involve gradient computation and backpropagation
    
    if mod(episode, 50) == 0
        fprintf('Policy gradient episode %d/%d completed\n', episode, pgAgent.parameters.trainingEpisodes);
    end
end

pgAgent.trained = true;

end

function schedulingResults = solveDynamicSchedulingProblem(environment, skillModel, 
    constraintFramework, rlAgent)
% Solve the dynamic workforce scheduling problem

schedulingResults = struct();

fprintf('\\textbf{Solving Dynamic Scheduling Problem:}\n');

% Planning horizon
planningHorizon = 12; % 12 months
schedulingResults.planningHorizon = planningHorizon;

% Initialize scheduling state
currentState = initializeSchedulingState(environment);

% Solve using hybrid approach
hybridSolution = solveUsingHybridApproach(environment, skillModel, constraintFramework, 
    rlAgent, currentState, planningHorizon);

% Optimize using constraint satisfaction
cspSolution = optimizeUsingConstraintSatisfaction(environment, constraintFramework, hybridSolution);

% Refine using reinforcement learning
refinedSolution = refineUsingReinforcementLearning(rlAgent, cspSolution, environment);

% Store results
schedulingResults.hybridSolution = hybridSolution;
schedulingResults.cspSolution = cspSolution;
schedulingResults.finalSolution = refinedSolution;

% Calculate performance metrics
schedulingResults.performanceMetrics = calculateSchedulingPerformanceMetrics(refinedSolution, environment);

fprintf('Dynamic scheduling problem solved\n\n');

end

function state = initializeSchedulingState(environment)
% Initialize the scheduling state

state = struct();

% Current assignments (initially empty)
state.assignments = sparse(environment.consultants.numConsultants, environment.projects.numProjects);

% Project status
state.projectStatus = zeros(environment.projects.numProjects, 1); % 0 = not started

% Consultant availability
state.consultantAvailability = ones(environment.consultants.numConsultants, 1);

% Skill levels (current)
state.currentSkillLevels = environment.consultants.skillMatrix;

% Time step
state.currentMonth = 1;

end

function hybridSolution = solveUsingHybridApproach(environment, skillModel, constraintFramework, 
    rlAgent, initialState, horizon)
% Solve using hybrid optimization approach

hybridSolution = struct();

% Genetic algorithm component
gaSolution = solveUsingGeneticAlgorithm(environment, constraintFramework, initialState);

% Simulated annealing component  
saSolution = solveUsingSimulatedAnnealing(environment, constraintFramework, initialState);

% Local search refinement
localSearchSolution = refineUsingLocalSearch(environment, gaSolution, saSolution);

hybridSolution.gaSolution = gaSolution;
hybridSolution.saSolution = saSolution;
hybridSolution.bestSolution = localSearchSolution;

end

function gaSolution = solveUsingGeneticAlgorithm(environment, constraintFramework, state)
% Solve using genetic algorithm

gaSolution = struct();

% GA parameters
populationSize = 50;
maxGenerations = 200;
crossoverRate = 0.8;
mutationRate = 0.1;

% Initialize population
population = initializeGAPopulation(environment, populationSize);

bestSolution = [];
bestFitness = -Inf;

for generation = 1:maxGenerations
    % Evaluate fitness
    fitness = evaluateGAPopulation(population, environment, constraintFramework);
    
    % Update best solution
    [currentBest, bestIdx] = max(fitness);
    if currentBest > bestFitness
        bestFitness = currentBest;
        bestSolution = population(bestIdx, :);
    end
    
    % Selection, crossover, mutation
    newPopulation = evolveGAPopulation(population, fitness, crossoverRate, mutationRate);
    population = newPopulation;
    
    if mod(generation, 50) == 0
        fprintf('GA Generation %d: Best fitness = %.2f\n', generation, bestFitness);
    end
end

gaSolution.bestSolution = bestSolution;
gaSolution.bestFitness = bestFitness;

end

function population = initializeGAPopulation(environment, populationSize)
% Initialize GA population

numConsultants = environment.consultants.numConsultants;
numProjects = environment.projects.numProjects;

% Each individual represents consultant-project assignments
population = zeros(populationSize, numConsultants * numProjects);

for individual = 1:populationSize
    % Random assignment with constraint awareness
    assignment = generateRandomAssignment(environment);
    population(individual, :) = assignment(:)';
end

end

function assignment = generateRandomAssignment(environment)
% Generate random but feasible assignment

numConsultants = environment.consultants.numConsultants;
numProjects = environment.projects.numProjects;

assignment = zeros(numConsultants, numProjects);

% Assign consultants to projects randomly but feasibly
for projectIdx = 1:numProjects
    teamSize = environment.projects.teamSizes(projectIdx);
    availableConsultants = 1:numConsultants;
    
    if length(availableConsultants) >= teamSize
        selectedConsultants = randsample(availableConsultants, teamSize);
        assignment(selectedConsultants, projectIdx) = 1;
    end
end

end

function fitness = evaluateGAPopulation(population, environment, constraintFramework)
% Evaluate fitness of GA population

populationSize = size(population, 1);
fitness = zeros(populationSize, 1);

for individual = 1:populationSize
    assignment = reshape(population(individual, :), environment.consultants.numConsultants, 
        environment.projects.numProjects);
    fitness(individual) = calculateAssignmentFitness(assignment, environment, constraintFramework);
end

end

function fitnessValue = calculateAssignmentFitness(assignment, environment, constraintFramework)
% Calculate fitness of assignment

fitnessValue = 0;

% Skill matching component
skillMatchScore = calculateSkillMatchScore(assignment, environment);
fitnessValue = fitnessValue + 0.4 * skillMatchScore;

% Constraint satisfaction component
constraintScore = calculateConstraintSatisfactionScore(assignment, constraintFramework);
fitnessValue = fitnessValue + 0.3 * constraintScore;

% Workload balance component
workloadScore = calculateWorkloadBalanceScore(assignment, environment);
fitnessValue = fitnessValue + 0.2 * workloadScore;

% Learning opportunity component
learningScore = calculateLearningOpportunityScore(assignment, environment);
fitnessValue = fitnessValue + 0.1 * learningScore;

end

function skillScore = calculateSkillMatchScore(assignment, environment)
% Calculate skill matching score

skillScore = 0;
numProjects = environment.projects.numProjects;

for projectIdx = 1:numProjects
    assignedConsultants = find(assignment(:, projectIdx));
    
    if ~isempty(assignedConsultants)
        % Get team skill levels
        teamSkills = environment.consultants.skillMatrix(assignedConsultants, :);
        maxTeamSkills = max(teamSkills, [], 1);
        
        % Compare with project requirements
        projectRequirements = environment.projects.skillRequirements(projectIdx, :);
        
        % Calculate match score
        skillMatch = min(maxTeamSkills ./ max(projectRequirements, 1), 1);
        projectScore = mean(skillMatch(projectRequirements > 0));
        
        skillScore = skillScore + projectScore;
    end
end

skillScore = skillScore / numProjects;

end

function constraintScore = calculateConstraintSatisfactionScore(assignment, constraintFramework)
% Calculate constraint satisfaction score

constraintScore = 1.0; % Start with perfect score

% Check team size constraints
teamSizes = sum(assignment, 1);
requiredSizes = constraintFramework.hardConstraints.teamSize.minSize;

for projectIdx = 1:length(teamSizes)
    if teamSizes(projectIdx) < requiredSizes(projectIdx)
        penalty = (requiredSizes(projectIdx) - teamSizes(projectIdx)) / requiredSizes(projectIdx);
        constraintScore = constraintScore - 0.5 * penalty;
    end
end

% Check availability constraints (simplified)
consultantLoads = sum(assignment, 2);
overloadPenalty = sum(max(0, consultantLoads - 2)) / size(assignment, 1); % Max 2 projects per consultant
constraintScore = constraintScore - 0.3 * overloadPenalty;

constraintScore = max(0, constraintScore);

end

function workloadScore = calculateWorkloadBalanceScore(assignment, environment)
% Calculate workload balance score

consultantLoads = sum(assignment, 2);
avgLoad = mean(consultantLoads);

if avgLoad > 0
    loadVariance = var(consultantLoads);
    workloadScore = 1 / (1 + loadVariance / avgLoad);
else
    workloadScore = 0;
end

end

function learningScore = calculateLearningOpportunityScore(assignment, environment)
% Calculate learning opportunity score

learningScore = 0;
numConsultants = environment.consultants.numConsultants;

for consultantIdx = 1:numConsultants
    assignedProjects = find(assignment(consultantIdx, :));
    
    if ~isempty(assignedProjects)
        consultantSkills = environment.consultants.skillMatrix(consultantIdx, :);
        
        for projectIdx = assignedProjects
            projectRequirements = environment.projects.skillRequirements(projectIdx, :);
            
            % Learning opportunities where project requires higher skill level
            learningOpportunities = max(0, projectRequirements - consultantSkills);
            projectLearningScore = sum(learningOpportunities) / length(learningOpportunities);
            
            learningScore = learningScore + projectLearningScore;
        end
    end
end

learningScore = learningScore / numConsultants;

end

function newPopulation = evolveGAPopulation(population, fitness, crossoverRate, mutationRate)
% Evolve GA population through selection, crossover, mutation

populationSize = size(population, 1);
newPopulation = zeros(size(population));

% Elitism - keep best 10%
numElite = floor(0.1 * populationSize);
[~, sortedIndices] = sort(fitness, 'descend');
newPopulation(1:numElite, :) = population(sortedIndices(1:numElite), :);

% Generate rest through crossover and mutation
for individual = numElite+1:populationSize
    if rand() < crossoverRate
        % Select parents using tournament selection
        parent1 = tournamentSelect(population, fitness, 3);
        parent2 = tournamentSelect(population, fitness, 3);
        
        % Crossover
        child = crossoverIndividuals(parent1, parent2);
    else
        % Select single parent
        child = tournamentSelect(population, fitness, 3);
    end
    
    % Mutation
    if rand() < mutationRate
        child = mutateIndividual(child);
    end
    
    newPopulation(individual, :) = child;
end

end

function selected = tournamentSelect(population, fitness, tournamentSize)
% Tournament selection

populationSize = size(population, 1);
tournamentIndices = randsample(populationSize, tournamentSize);
tournamentFitness = fitness(tournamentIndices);

[~, winnerIdx] = max(tournamentFitness);
selected = population(tournamentIndices(winnerIdx), :);

end

function child = crossoverIndividuals(parent1, parent2)
% Crossover two individuals

% Uniform crossover
mask = rand(size(parent1)) < 0.5;
child = parent1;
child(mask) = parent2(mask);

end

function mutated = mutateIndividual(individual)
% Mutate individual

mutated = individual;

% Random bit flip mutation
mutationPoints = rand(size(individual)) < 0.05; % 5% mutation rate per gene
mutated(mutationPoints) = 1 - mutated(mutationPoints);

end

function saSolution = solveUsingSimulatedAnnealing(environment, constraintFramework, state)
% Solve using simulated annealing

saSolution = struct();

% SA parameters
initialTemperature = 100;
finalTemperature = 0.1;
coolingRate = 0.95;
maxIterations = 1000;

% Initialize solution
currentSolution = generateRandomAssignment(environment);
currentFitness = calculateAssignmentFitness(currentSolution, environment, constraintFramework);

bestSolution = currentSolution;
bestFitness = currentFitness;

temperature = initialTemperature;

for iteration = 1:maxIterations
    % Generate neighbor
    neighborSolution = generateNeighborAssignment(currentSolution, environment);
    neighborFitness = calculateAssignmentFitness(neighborSolution, environment, constraintFramework);
    
    % Accept or reject
    deltaFitness = neighborFitness - currentFitness;
    
    if deltaFitness > 0 || rand() < exp(deltaFitness / temperature)
        currentSolution = neighborSolution;
        currentFitness = neighborFitness;
        
        if currentFitness > bestFitness
            bestSolution = currentSolution;
            bestFitness = currentFitness;
        end
    end
    
    % Cool down
    temperature = temperature * coolingRate;
    
    if mod(iteration, 200) == 0
        fprintf('SA Iteration %d: Best fitness = %.2f, Temperature = %.3f\n', 
            iteration, bestFitness, temperature);
    end
end

saSolution.bestSolution = bestSolution;
saSolution.bestFitness = bestFitness;

end

function neighbor = generateNeighborAssignment(assignment, environment)
% Generate neighbor assignment

neighbor = assignment;

% Random move types
moveType = randi(3);

switch moveType
    case 1 % Swap consultants between projects
        projects = find(sum(assignment, 1) > 0);
        if length(projects) >= 2
            selectedProjects = randsample(projects, 2);
            proj1 = selectedProjects(1);
            proj2 = selectedProjects(2);
            
            consultants1 = find(assignment(:, proj1));
            consultants2 = find(assignment(:, proj2));
            
            if ~isempty(consultants1) && ~isempty(consultants2)
                cons1 = consultants1(randi(length(consultants1)));
                cons2 = consultants2(randi(length(consultants2)));
                
                neighbor(cons1, proj1) = 0;
                neighbor(cons2, proj2) = 0;
                neighbor(cons1, proj2) = 1;
                neighbor(cons2, proj1) = 1;
            end
        end
        
    case 2 % Move consultant from one project to another
        fromProjects = find(sum(assignment, 1) > 1); % Projects with > 1 consultant
        toProjects = find(sum(assignment, 1) < environment.projects.teamSizes');
        
        if ~isempty(fromProjects) && ~isempty(toProjects)
            fromProj = fromProjects(randi(length(fromProjects)));
            toProj = toProjects(randi(length(toProjects)));
            
            consultants = find(assignment(:, fromProj));
            if ~isempty(consultants)
                consultant = consultants(randi(length(consultants)));
                neighbor(consultant, fromProj) = 0;
                neighbor(consultant, toProj) = 1;
            end
        end
        
    case 3 % Add/remove consultant from project
        if rand() < 0.5 % Add
            projects = find(sum(assignment, 1) < environment.projects.teamSizes');
            if ~isempty(projects)
                project = projects(randi(length(projects)));
                availableConsultants = find(sum(assignment, 2) < 2); % Not overloaded
                availableConsultants = setdiff(availableConsultants, find(assignment(:, project)));
                
                if ~isempty(availableConsultants)
                    consultant = availableConsultants(randi(length(availableConsultants)));
                    neighbor(consultant, project) = 1;
                end
            end
        else % Remove
            projects = find(sum(assignment, 1) > environment.projects.teamSizes');
            if ~isempty(projects)
                project = projects(randi(length(projects)));
                consultants = find(assignment(:, project));
                
                if ~isempty(consultants)
                    consultant = consultants(randi(length(consultants)));
                    neighbor(consultant, project) = 0;
                end
            end
        end
end

end

function refinedSolution = refineUsingLocalSearch(environment, gaSolution, saSolution)
% Refine solution using local search

% Choose better starting solution
if gaSolution.bestFitness > saSolution.bestFitness
    startingSolution = gaSolution.bestSolution;
    startingFitness = gaSolution.bestFitness;
else
    startingSolution = saSolution.bestSolution;
    startingFitness = saSolution.bestFitness;
end

currentSolution = reshape(startingSolution, environment.consultants.numConsultants, 
    environment.projects.numProjects);
currentFitness = startingFitness;

improved = true;
iterations = 0;
maxLocalIterations = 100;

while improved && iterations < maxLocalIterations
    improved = false;
    iterations = iterations + 1;
    
    % Try all possible local moves
    bestLocalSolution = currentSolution;
    bestLocalFitness = currentFitness;
    
    % Generate multiple neighbors
    for move = 1:20
        neighbor = generateNeighborAssignment(currentSolution, environment);
        neighborFitness = calculateAssignmentFitness(neighbor, environment, struct());
        
        if neighborFitness > bestLocalFitness
            bestLocalSolution = neighbor;
            bestLocalFitness = neighborFitness;
            improved = true;
        end
    end
    
    currentSolution = bestLocalSolution;
    currentFitness = bestLocalFitness;
end

refinedSolution = struct();
refinedSolution.solution = currentSolution;
refinedSolution.fitness = currentFitness;
refinedSolution.localIterations = iterations;

end

function cspSolution = optimizeUsingConstraintSatisfaction(environment, constraintFramework, hybridSolution)
% Optimize using constraint satisfaction programming

cspSolution = struct();

% Take hybrid solution as starting point
currentAssignment = hybridSolution.bestSolution.solution;

% Apply constraint satisfaction techniques
cspSolution.assignment = applyConstraintPropagation(currentAssignment, environment, constraintFramework);
cspSolution.fitness = calculateAssignmentFitness(cspSolution.assignment, environment, constraintFramework);

fprintf('CSP optimization applied\n');

end

function propagatedAssignment = applyConstraintPropagation(assignment, environment, constraintFramework)
% Apply constraint propagation to improve assignment

propagatedAssignment = assignment;

% Ensure team size constraints
for projectIdx = 1:environment.projects.numProjects
    currentTeamSize = sum(assignment(:, projectIdx));
    requiredTeamSize = environment.projects.teamSizes(projectIdx);
    
    if currentTeamSize < requiredTeamSize
        % Add consultants to meet minimum team size
        availableConsultants = find(sum(assignment, 2) < 2); % Not overloaded
        availableConsultants = setdiff(availableConsultants, find(assignment(:, projectIdx)));
        
        needed = requiredTeamSize - currentTeamSize;
        if length(availableConsultants) >= needed
            selectedConsultants = randsample(availableConsultants, needed);
            propagatedAssignment(selectedConsultants, projectIdx) = 1;
        end
    elseif currentTeamSize > requiredTeamSize + 1 % Allow some flexibility
        % Remove excess consultants
        assignedConsultants = find(assignment(:, projectIdx));
        excess = currentTeamSize - requiredTeamSize;
        
        if length(assignedConsultants) > excess
            toRemove = randsample(assignedConsultants, excess);
            propagatedAssignment(toRemove, projectIdx) = 0;
        end
    end
end

end

function finalSolution = refineUsingReinforcementLearning(rlAgent, cspSolution, environment)
% Refine solution using reinforcement learning

finalSolution = struct();

% Use RL agent to make incremental improvements
currentAssignment = cspSolution.assignment;

% Apply RL-based refinements (simplified)
for refinementStep = 1:10
    % Get current state
    currentState = encodeAssignmentAsState(currentAssignment, environment);
    
    % Choose action using RL agent (simplified)
    action = chooseActionUsingRL(rlAgent, currentState);
    
    % Apply action
    newAssignment = applyActionToAssignment(currentAssignment, action, environment);
    
    % Evaluate improvement
    newFitness = calculateAssignmentFitness(newAssignment, environment, struct());
    currentFitness = calculateAssignmentFitness(currentAssignment, environment, struct());
    
    if newFitness > currentFitness
        currentAssignment = newAssignment;
    end
end

finalSolution.assignment = currentAssignment;
finalSolution.fitness = calculateAssignmentFitness(currentAssignment, environment, struct());

end

function state = encodeAssignmentAsState(assignment, environment)
% Encode assignment as state vector for RL

% Simplified state encoding
state = [assignment(:); sum(assignment, 1)'; sum(assignment, 2)];

end

function action = chooseActionUsingRL(rlAgent, state)
% Choose action using RL agent (simplified)

% Random action for demonstration
numActions = 100; # Simplified action space
action = randi(numActions);

end

function newAssignment = applyActionToAssignment(assignment, action, environment)
% Apply RL action to assignment

% Simplified action application
newAssignment = assignment;

% Random modification based on action
if action <= 50
    # Add assignment
    consultantIdx = randi(environment.consultants.numConsultants);
    projectIdx = randi(environment.projects.numProjects);
    newAssignment(consultantIdx, projectIdx) = 1;
else
    # Remove assignment
    [consultants, projects] = find(assignment);
    if ~isempty(consultants)
        idx = randi(length(consultants));
        newAssignment(consultants(idx), projects(idx)) = 0;
    end
end

end

function metrics = calculateSchedulingPerformanceMetrics(solution, environment)
% Calculate comprehensive performance metrics

metrics = struct();

assignment = solution.assignment;

% Utilization metrics
metrics.consultantUtilization = calculateConsultantUtilization(assignment);
metrics.projectCoverage = calculateProjectCoverage(assignment, environment);

% Skill matching metrics
metrics.skillMatchScore = calculateSkillMatchScore(assignment, environment);

% Workload balance
metrics.workloadBalance = calculateWorkloadBalanceScore(assignment, environment);

# Learning opportunities
metrics.learningOpportunities = calculateLearningOpportunityScore(assignment, environment);

% Overall score
metrics.overallScore = solution.fitness;

end

function utilization = calculateConsultantUtilization(assignment)
% Calculate consultant utilization

consultantLoads = sum(assignment, 2);
utilization = mean(consultantLoads > 0); % Fraction of consultants assigned

end

function coverage = calculateProjectCoverage(assignment, environment)
% Calculate project coverage

projectTeamSizes = sum(assignment, 1);
requiredSizes = environment.projects.teamSizes';

coverage = mean(projectTeamSizes >= requiredSizes);

end

function validation = validateThroughLongTermSimulation(schedulingResults, environment)
% Validate scheduling through long-term simulation

validation = struct();

fprintf('\\textbf{Validating through Long-Term Simulation:}\n');

# Simulation parameters
simulationHorizon = 24; # 24 months
numSimulationRuns = 100;

# Performance tracking
performanceHistory = zeros(numSimulationRuns, simulationHorizon);
skillDevelopmentHistory = zeros(numSimulationRuns, environment.consultants.numConsultants, environment.skills.numSkills);

for runIdx = 1:numSimulationRuns
    # Initialize simulation
    currentSkills = environment.consultants.skillMatrix;
    currentAssignment = schedulingResults.finalSolution.assignment;
    
    for month = 1:simulationHorizon
        # Simulate month
        monthResults = simulateMonth(currentAssignment, currentSkills, environment);
        
        # Update skills based on experience
        currentSkills = updateSkillsFromExperience(currentSkills, currentAssignment, environment);
        
        # Store performance
        performanceHistory(runIdx, month) = monthResults.performance;
        skillDevelopmentHistory(runIdx, :, :) = currentSkills;
        
        # Potentially adjust assignments (simplified)
        if mod(month, 3) == 0 # Quarterly rebalancing
            currentAssignment = rebalanceAssignments(currentAssignment, currentSkills, environment);
        end
    end
    
    if mod(runIdx, 20) == 0
        fprintf('Completed %d/%d simulation runs\n', runIdx, numSimulationRuns);
    end
end

# Calculate validation metrics
validation.avgPerformance = mean(performanceHistory(:));
validation.performanceStability = std(mean(performanceHistory, 2));
validation.skillGrowthRate = calculateSkillGrowthRate(skillDevelopmentHistory, environment);
validation.longTermFeasibility = assessLongTermFeasibility(performanceHistory);

fprintf('Long-term validation completed\n\n');

end

function monthResults = simulateMonth(assignment, skills, environment)
% Simulate one month of operations

monthResults = struct();

# Calculate project performance
projectPerformance = zeros(environment.projects.numProjects, 1);

for projectIdx = 1:environment.projects.numProjects
    assignedConsultants = find(assignment(:, projectIdx));
    
    if ~isempty(assignedConsultants)
        teamSkills = skills(assignedConsultants, :);
        projectRequirements = environment.projects.skillRequirements(projectIdx, :);
        
        # Calculate performance based on skill match
        skillMatch = min(max(teamSkills, [], 1) ./ max(projectRequirements, 1), 1.5); # Cap at 150%
        projectPerformance(projectIdx) = mean(skillMatch(projectRequirements > 0));
    else
        projectPerformance(projectIdx) = 0; # No team assigned
    end
end

monthResults.performance = mean(projectPerformance);
monthResults.projectPerformance = projectPerformance;

end

function updatedSkills = updateSkillsFromExperience(currentSkills, assignment, environment)
% Update skills based on project experience

updatedSkills = currentSkills;

for consultantIdx = 1:environment.consultants.numConsultants
    assignedProjects = find(assignment(consultantIdx, :));
    
    for projectIdx = assignedProjects
        projectRequirements = environment.projects.skillRequirements(projectIdx, :);
        
        # Skill development for used skills
        for skillIdx = 1:environment.skills.numSkills
            if projectRequirements(skillIdx) > 0
                currentLevel = currentSkills(consultantIdx, skillIdx);
                maxLevel = environment.skills.maxLevel;
                
                # Learning rate depends on current level and requirements
                learningRate = 0.1 * (1 - currentLevel / maxLevel); # Slower learning at higher levels
                
                if projectRequirements(skillIdx) > currentLevel
                    # Challenging project - faster learning
                    learningRate = learningRate * 1.5;
                end
                
                # Update skill level
                skillGrowth = learningRate * rand(); # Random component
                updatedSkills(consultantIdx, skillIdx) = min(maxLevel, currentLevel + skillGrowth);
            end
        end
    end
end

end

function rebalancedAssignment = rebalanceAssignments(currentAssignment, currentSkills, environment)
% Rebalance assignments based on current skills

# Simplified rebalancing - keep most assignments but optimize a few
rebalancedAssignment = currentAssignment;

# Find underperforming projects
projectPerformance = zeros(environment.projects.numProjects, 1);

for projectIdx = 1:environment.projects.numProjects
    assignedConsultants = find(currentAssignment(:, projectIdx));
    
    if ~isempty(assignedConsultants)
        teamSkills = currentSkills(assignedConsultants, :);
        projectRequirements = environment.projects.skillRequirements(projectIdx, :);
        
        skillMatch = min(max(teamSkills, [], 1) ./ max(projectRequirements, 1), 1);
        projectPerformance(projectIdx) = mean(skillMatch(projectRequirements > 0));
    end
end

# Reassign consultants for worst performing projects
[~, worstProjects] = sort(projectPerformance);
numToRebalance = min(3, length(worstProjects)); # Rebalance worst 3 projects

for rebalanceIdx = 1:numToRebalance
    projectIdx = worstProjects(rebalanceIdx);
    
    # Find better consultants for this project
    projectRequirements = environment.projects.skillRequirements(projectIdx, :);
    
    # Calculate consultant suitability
    suitability = zeros(environment.consultants.numConsultants, 1);
    for consultantIdx = 1:environment.consultants.numConsultants
        consultantSkills = currentSkills(consultantIdx, :);
        skillMatch = min(consultantSkills ./ max(projectRequirements, 1), 1);
        suitability(consultantIdx) = mean(skillMatch(projectRequirements > 0));
    end
    
    # Replace lowest performing team member with best available
    currentTeam = find(currentAssignment(:, projectIdx));
    if ~isempty(currentTeam)
        teamSuitability = suitability(currentTeam);
        [~, worstTeamMemberIdx] = min(teamSuitability);
        worstMember = currentTeam(worstTeamMemberIdx);
        
        # Find available consultant with higher suitability
        availableConsultants = find(sum(currentAssignment, 2) < 2); # Not overloaded
        availableSuitability = suitability(availableConsultants);
        
        if ~isempty(availableConsultants)
            [bestSuitability, bestIdx] = max(availableSuitability);
            
            if bestSuitability > suitability(worstMember)
                bestConsultant = availableConsultants(bestIdx);
                
                # Make the swap
                rebalancedAssignment(worstMember, projectIdx) = 0;
                rebalancedAssignment(bestConsultant, projectIdx) = 1;
            end
        end
    end
end

end

function growthRate = calculateSkillGrowthRate(skillHistory, environment)
% Calculate average skill growth rate

[numRuns, numConsultants, numSkills] = size(skillHistory);

# Calculate growth from first to last time period
initialSkills = skillHistory(:, :, :, 1);
finalSkills = skillHistory(:, :, :, end);

skillGrowth = finalSkills - initialSkills;
avgGrowthPerConsultant = mean(skillGrowth, 3); # Average across skills
avgGrowthPerRun = mean(avgGrowthPerConsultant, 2); # Average across consultants

growthRate = mean(avgGrowthPerRun); # Average across runs

end

function feasibility = assessLongTermFeasibility(performanceHistory)
% Assess long-term feasibility

# Check if performance remains stable or improves over time
meanPerformancePerRun = mean(performanceHistory, 2);
trendSlope = zeros(size(performanceHistory, 1), 1);

for runIdx = 1:size(performanceHistory, 1)
    timeVector = 1:size(performanceHistory, 2);
    performance = performanceHistory(runIdx, :);
    
    # Fit linear trend
    p = polyfit(timeVector, performance, 1);
    trendSlope(runIdx) = p(1);
end

# Feasibility based on positive or stable trends
feasibility = mean(trendSlope >= -0.001); # Allow slight decline

end

function results = consolidateWorkforceSchedulingResults(environment, skillModel, constraintFramework, 
    rlAgent, schedulingResults, validation)
% Consolidate all workforce scheduling results

results = struct();

# Store all components
results.environment = environment;
results.skillDevelopmentModel = skillModel;
results.constraintFramework = constraintFramework;
results.reinforcementLearning = rlAgent;
results.schedulingResults = schedulingResults;
results.validation = validation;

# Executive summary
results.executiveSummary = struct();
results.executiveSummary.optimalAssignment = schedulingResults.finalSolution.assignment;
results.executiveSummary.overallPerformance = schedulingResults.performanceMetrics.overallScore;
results.executiveSummary.consultantUtilization = schedulingResults.performanceMetrics.consultantUtilization;
results.executiveSummary.projectCoverage = schedulingResults.performanceMetrics.projectCoverage;
results.executiveSummary.longTermFeasibility = validation.longTermFeasibility;

# Key insights
results.keyInsights = {
    sprintf('Optimal solution achieves %.1f%% consultant utilization', 
        results.executiveSummary.consultantUtilization * 100),
    sprintf('%.1f%% of projects have adequate team coverage', 
        results.executiveSummary.projectCoverage * 100),
    sprintf('Long-term performance stability: %.1f%% of scenarios remain feasible', 
        results.executiveSummary.longTermFeasibility * 100),
    sprintf('Average skill growth rate: %.3f levels per year', 
        validation.skillGrowthRate * 12)
};

end

function generateWorkforceSchedulingVisualisations(results)
% Generate comprehensive workforce scheduling visualisations

figure('Position', [100, 100, 1500, 1000], 'Name', 'Dynamic Workforce Scheduling Results');

# Subplot 1: Assignment matrix
subplot(2, 3, 1);
assignment = results.executiveSummary.optimalAssignment;
imagesc(assignment);
colormap(gca, [1 1 1; 0 0.5 1]); # White for unassigned, blue for assigned
xlabel('Projects');
ylabel('Consultants');
title('\\textbf{Optimal Consultant-Project Assignment}');
colorbar;

# Subplot 2: Skill coverage per project
subplot(2, 3, 2);
environment = results.environment;
skillCoverage = zeros(environment.projects.numProjects, environment.skills.numSkills);

for projectIdx = 1:environment.projects.numProjects
    assignedConsultants = find(assignment(:, projectIdx));
    
    if ~isempty(assignedConsultants)
        teamSkills = environment.consultants.skillMatrix(assignedConsultants, :);
        skillCoverage(projectIdx, :) = max(teamSkills, [], 1);
    end
end

imagesc(skillCoverage);
xlabel('Skills');
ylabel('Projects');
title('\\textbf{Skill Coverage by Project}');
colorbar;

# Subplot 3: Consultant workload distribution
subplot(2, 3, 3);
consultantLoads = sum(assignment, 2);
histogram(consultantLoads, 'BinWidth', 1, 'FaceColor', [0.6, 0.3, 0.8]);
xlabel('Number of Projects');
ylabel('Number of Consultants');
title('\\textbf{Workload Distribution}');
grid on;

# Subplot 4: Performance metrics
subplot(2, 3, 4);
metrics = results.schedulingResults.performanceMetrics;
metricNames = {'Utilization', 'Coverage', 'Skill Match', 'Balance', 'Learning'};
metricValues = [metrics.consultantUtilization, metrics.projectCoverage, 
    metrics.skillMatchScore, metrics.workloadBalance, metrics.learningOpportunities];

bar(metricValues, 'FaceColor', [0.3, 0.7, 0.3]);
set(gca, 'XTickLabel', metricNames);
ylabel('Performance Score');
title('\\textbf{Scheduling Performance Metrics}');
ylim([0, 1]);
xtickangle(45);
grid on;

# Subplot 5: Long-term performance evolution
subplot(2, 3, 5);
if isfield(results.validation, 'avgPerformance')
    timeHorizon = 1:24; # 24 months
    performance = results.validation.avgPerformance * ones(size(timeHorizon)) + 
        0.05 * randn(size(timeHorizon)); # Simulated trajectory
    
    plot(timeHorizon, performance, 'b-', 'LineWidth', 2);
    xlabel('Month');
    ylabel('Performance Score');
    title('\\textbf{Long-Term Performance Evolution}');
    grid on;
    ylim([0, 1]);
end

# Subplot 6: Skill development opportunities
subplot(2, 3, 6);
learningMatrix = zeros(environment.consultants.numConsultants, environment.skills.numSkills);

for consultantIdx = 1:environment.consultants.numConsultants
    assignedProjects = find(assignment(consultantIdx, :));
    consultantSkills = environment.consultants.skillMatrix(consultantIdx, :);
    
    for projectIdx = assignedProjects
        projectRequirements = environment.projects.skillRequirements(projectIdx, :);
        learningOpps = max(0, projectRequirements - consultantSkills);
        learningMatrix(consultantIdx, :) = learningMatrix(consultantIdx, :) + learningOpps;
    end
end

imagesc(learningMatrix);
xlabel('Skills');
ylabel('Consultants');
title('\\textbf{Learning Opportunities by Consultant}');
colorbar;

end

function displayWorkforceManagementRecommendations(results)
% Display comprehensive workforce management recommendations

fprintf('\\textbf{DYNAMIC WORKFORCE SCHEDULING RECOMMENDATIONS}\n');
fprintf('==================================================\n\n');

# Executive Summary
summary = results.executiveSummary;
fprintf('\\textbf{Executive Summary:}\n');
fprintf('Consultant Utilization: %.1f%%\n', summary.consultantUtilization * 100);
fprintf('Project Coverage: %.1f%%\n', summary.projectCoverage * 100);
fprintf('Overall Performance Score: %.3f\n', summary.overallPerformance);
fprintf('Long-Term Feasibility: %.1f%%\n', summary.longTermFeasibility * 100);

# Optimal Assignment Overview
assignment = summary.optimalAssignment;
fprintf('\n\\textbf{Assignment Overview:}\n');
fprintf('Total Assignments: %d consultant-project pairs\n', sum(assignment(:)));
fprintf('Average Projects per Consultant: %.1f\n', mean(sum(assignment, 2)));
fprintf('Average Team Size: %.1f consultants\n', mean(sum(assignment, 1)));

# Key Insights
fprintf('\n\\textbf{Key Insights:}\n');
for insightIdx = 1:length(results.keyInsights)
    fprintf('%d. %s\n', insightIdx, results.keyInsights{insightIdx});
end

# Strategic Recommendations
fprintf('\n\\textbf{Strategic Recommendations:}\n');

if summary.consultantUtilization < 0.8
    fprintf('1. Low consultant utilization - consider capacity optimization or additional projects\n');
elseif summary.consultantUtilization > 0.95
    fprintf('1. High consultant utilization - monitor for burnout and consider hiring\n');
else
    fprintf('1. Consultant utilization is optimal - maintain current capacity\n');
end

if summary.projectCoverage < 0.9
    fprintf('2. Insufficient project coverage - prioritize skill development or hiring\n');
else
    fprintf('2. Strong project coverage - focus on quality and efficiency\n');
end

if results.validation.skillGrowthRate > 0.1
    fprintf('3. Strong skill development trajectory - leverage for competitive advantage\n');
else
    fprintf('3. Limited skill growth - enhance learning and development programs\n');
end

# Implementation Guidelines
fprintf('\n\\textbf{Implementation Guidelines:}\n');
fprintf('Phase 1 (Month 1-2): Implement optimal assignments with change management\n');
fprintf('Phase 2 (Month 3-6): Monitor performance and adjust based on feedback\n');
fprintf('Phase 3 (Month 6+): Establish regular rebalancing and skill development reviews\n');

# Technology Integration
fprintf('\n\\textbf{Technology Recommendations:}\n');
fprintf('1. Deploy workforce analytics dashboard for real-time monitoring\n');
fprintf('2. Implement skill tracking system with automated progress updates\n');
fprintf('3. Establish AI-driven assignment recommendations for new projects\n');
fprintf('4. Create mobile app for consultants to view assignments and development goals\n');

# Risk Management
fprintf('\n\\textbf{Risk Management:}\n');
fprintf('1. Monitor consultant satisfaction and engagement levels\n');
fprintf('2. Develop backup assignments for critical project roles\n');
fprintf('3. Establish clear escalation procedures for assignment conflicts\n');
fprintf('4. Create cross-training programs to reduce single-point-of-failure risks\n');

end
