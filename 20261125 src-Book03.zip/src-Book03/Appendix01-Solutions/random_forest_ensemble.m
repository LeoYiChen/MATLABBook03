%% random_forest_ensemble.m
% Random Forest Ensemble Learning
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : random_forest_ensemble
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Random Forest Ensemble Learning Implementation
% Author: Dr Leo Chen
% Version: R2023b
% Date: November 2024

function random_forest_ensemble_learning()
% Generate synthetic multi-class classification dataset
rng(303); % Ensure reproducibility
num_samples = 1000;
num_features = 20;
num_classes = 4;

% Create complex synthetic dataset with non-linear boundaries
[feature_matrix, class_labels] = create_complex_dataset(...
    num_samples, num_features, num_classes);

% Split dataset into training and testing sets
train_ratio = 0.7;
cv_partition = cvpartition(class_labels, 'HoldOut', 1 - train_ratio);

train_indices = training(cv_partition);
test_indices = test(cv_partition);

train_features = feature_matrix(train_indices, :);
train_labels = class_labels(train_indices);
test_features = feature_matrix(test_indices, :);
test_labels = class_labels(test_indices);

% Configure Random Forest parameters
num_trees = 100;
min_leaf_size = 5;
num_variables_to_sample = floor(sqrt(num_features));

% Train Random Forest ensemble
fprintf('Training Random Forest with %d trees...\\n', num_trees);

random_forest = TreeBagger(num_trees, train_features, train_labels, ...
    'Method', 'classification', ...
    'NumVariablesToSample', num_variables_to_sample, ...
    'MinLeafSize', min_leaf_size, ...
    'OOBPrediction', 'on', ...
    'OOBPredictorImportance', 'on');

% Make predictions on test set
[predicted_labels, prediction_scores] = predict(random_forest, test_features);

% Convert cell array to numeric for evaluation
predicted_numeric = str2double(predicted_labels);

% Calculate performance metrics
test_accuracy = sum(predicted_numeric == test_labels) / length(test_labels) * 100;

% Out-of-bag error analysis
oob_error = oobError(random_forest);
final_oob_error = oob_error(end);

% Feature importance analysis
feature_importance = random_forest.OOBPermutedPredictorDeltaError;
[sorted_importance, importance_indices] = sort(feature_importance, 'descend');

% Train individual decision tree for comparison
single_tree = fitctree(train_features, train_labels, ...
    'MinLeafSize', min_leaf_size);
single_tree_predictions = predict(single_tree, test_features);
single_tree_accuracy = sum(single_tree_predictions == test_labels) / ...
    length(test_labels) * 100;

% Ensemble size analysis
ensemble_sizes = 1:10:num_trees;
ensemble_accuracies = zeros(length(ensemble_sizes), 1);

for size_idx = 1:length(ensemble_sizes)
    current_size = ensemble_sizes(size_idx);
    temp_predictions = predict(random_forest, test_features, 'Trees', 1:current_size);
    temp_numeric = str2double(temp_predictions);
    ensemble_accuracies(size_idx) = sum(temp_numeric == test_labels) / ...
        length(test_labels) * 100;
end

% Calculate confusion matrix
confusion_matrix = confusionmat(test_labels, predicted_numeric);

% Precision and recall per class
num_test_classes = max(test_labels);
precision_per_class = zeros(num_test_classes, 1);
recall_per_class = zeros(num_test_classes, 1);

for class_idx = 1:num_test_classes
    true_positives = confusion_matrix(class_idx, class_idx);
    false_positives = sum(confusion_matrix(:, class_idx)) - true_positives;
    false_negatives = sum(confusion_matrix(class_idx, :)) - true_positives;
    
    precision_per_class(class_idx) = true_positives / ...
        (true_positives + false_positives);
    recall_per_class(class_idx) = true_positives / ...
        (true_positives + false_negatives);
end

% Calculate F1-scores
f1_scores = 2 * (precision_per_class .* recall_per_class) ./ ...
    (precision_per_class + recall_per_class);

% Visualisation
figure('Name', 'Random Forest Ensemble Results');

% Out-of-bag error convergence
subplot(2, 3, 1);
plot(1:num_trees, oob_error, 'b-', 'LineWidth', 2);
xlabel('Number of Trees', 'Interpreter', 'latex');
ylabel('Out-of-Bag Error', 'Interpreter', 'latex');
title('OOB Error Convergence', 'Interpreter', 'latex');
grid on;

% Feature importance
subplot(2, 3, 2);
bar(sorted_importance(1:min(15, length(sorted_importance))));
xlabel('Feature Rank', 'Interpreter', 'latex');
ylabel('Importance Score', 'Interpreter', 'latex');
title('Feature Importance Ranking', 'Interpreter', 'latex');

% Ensemble size vs accuracy
subplot(2, 3, 3);
plot(ensemble_sizes, ensemble_accuracies, 'ro-', 'LineWidth', 2);
xlabel('Ensemble Size', 'Interpreter', 'latex');
ylabel('Test Accuracy (\%)', 'Interpreter', 'latex');
title('Ensemble Size Effect', 'Interpreter', 'latex');
grid on;

% Confusion matrix heatmap
subplot(2, 3, 4);
imagesc(confusion_matrix);
colorbar;
xlabel('Predicted Class', 'Interpreter', 'latex');
ylabel('True Class', 'Interpreter', 'latex');
title('Confusion Matrix', 'Interpreter', 'latex');

% Add text annotations to confusion matrix
for row = 1:size(confusion_matrix, 1)
    for col = 1:size(confusion_matrix, 2)
        text(col, row, num2str(confusion_matrix(row, col)), ...
            'HorizontalAlignment', 'center', 'Color', 'white', ...
            'FontWeight', 'bold');
    end
end

% Performance comparison
subplot(2, 3, 5);
comparison_data = [single_tree_accuracy, test_accuracy];
bar(comparison_data, 'FaceColor', 'green');
set(gca, 'XTickLabel', {'Single Tree', 'Random Forest'});
ylabel('Test Accuracy (\%)', 'Interpreter', 'latex');
title('Model Comparison', 'Interpreter', 'latex');

% Per-class performance
subplot(2, 3, 6);
class_metrics = [precision_per_class, recall_per_class, f1_scores];
bar(class_metrics);
xlabel('Class', 'Interpreter', 'latex');
ylabel('Score', 'Interpreter', 'latex');
title('Per-Class Performance', 'Interpreter', 'latex');
legend('Precision', 'Recall', 'F1-Score', 'Location', 'best');

% Display comprehensive results
fprintf('\\n\\textbf{Random Forest Ensemble Results}:\\n');
fprintf('Number of Trees: %d\\n', num_trees);
fprintf('Variables per Split: %d\\n', num_variables_to_sample);
fprintf('Minimum Leaf Size: %d\\n', min_leaf_size);

fprintf('\\n\\textbf{Performance Metrics}:\\n');
fprintf('Test Accuracy: %.2f%%\\n', test_accuracy);
fprintf('Single Tree Accuracy: %.2f%%\\n', single_tree_accuracy);
fprintf('Improvement: %.2f%%\\n', test_accuracy - single_tree_accuracy);
fprintf('Final OOB Error: %.4f\\n', final_oob_error);

fprintf('\\n\\textbf{Per-Class Performance}:\\n');
for class_idx = 1:num_test_classes
    fprintf('Class %d - Precision: %.3f, Recall: %.3f, F1: %.3f\\n', ...
        class_idx, precision_per_class(class_idx), ...
        recall_per_class(class_idx), f1_scores(class_idx));
end

fprintf('\\n\\textbf{Top 5 Most Important Features}:\\n');
for rank = 1:min(5, length(importance_indices))
    feature_idx = importance_indices(rank);
    importance_score = sorted_importance(rank);
    fprintf('Feature %d: %.4f\\n', feature_idx, importance_score);
end

% Model interpretation
fprintf('\\n\\textbf{Model Interpretation}:\\n');
fprintf('Average Tree Depth: %.1f\\n', mean([random_forest.Trees{:}].NumNodes));
fprintf('Total Splits: %d\\n', sum([random_forest.Trees{:}].NumNodes) - num_trees);

% Stability analysis
stability_runs = 10;
stability_accuracies = zeros(stability_runs, 1);

for run = 1:stability_runs
    temp_forest = TreeBagger(num_trees, train_features, train_labels, ...
        'Method', 'classification', ...
        'NumVariablesToSample', num_variables_to_sample, ...
        'MinLeafSize', min_leaf_size);
    
    temp_predictions = predict(temp_forest, test_features);
    temp_numeric = str2double(temp_predictions);
    stability_accuracies(run) = sum(temp_numeric == test_labels) / ...
        length(test_labels) * 100;
end

fprintf('\\n\\textbf{Model Stability}:\\n');
fprintf('Mean Accuracy: %.2f%% -- %.2f%%\\n', ...
    mean(stability_accuracies), std(stability_accuracies));
    
    end

function [features, labels] = create_complex_dataset(num_samples, num_features, num_classes)
% Create synthetic dataset with complex decision boundaries

features = randn(num_samples, num_features);
labels = zeros(num_samples, 1);

% Create complex non-linear decision boundaries
for sample_idx = 1:num_samples
    x = features(sample_idx, :);
    
    % Non-linear combination of features
    decision_value = sum(x(1:5).^2) + sin(sum(x(6:10))) + ...
        prod(sign(x(11:15))) + norm(x(16:end));
    
    % Map to class labels
    if decision_value < -2
        labels(sample_idx) = 1;
    elseif decision_value < 0
        labels(sample_idx) = 2;
    elseif decision_value < 2
        labels(sample_idx) = 3;
    else
        labels(sample_idx) = 4;
    end
end

% Ensure all classes are represented
for class_idx = 1:num_classes
    if sum(labels == class_idx) == 0
        % Assign random samples to missing classes
        random_indices = randperm(num_samples, ceil(num_samples / num_classes));
        labels(random_indices) = class_idx;
    end
end

end
