%% chapter_AICE_code_P06.m
% Solution~6: indoor air quality monitoring and ventilation fault detection (MATLABBook02_Chapter13_section8_Problem06.m).
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AICE_code_P06
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% MATLABBook02_Chapter13_section8_Problem06.m
% Problem 6: Indoor Air Quality Monitoring and Ventilation Fault
%             Detection
%
% Description : Generates synthetic CO2 data for a lecture theatre,
%               trains a regression tree on normal operation and
%               detects a ventilation fault via residual thresholds.
% Author      : Dr Yi Chen
% Date        : 2025
% MATLAB      : R2024b or later
% Toolboxes   : Statistics and Machine Learning Toolbox
% Reference   : Chapter 13, Problem 6
% =================================================================

%% 1. Generate synthetic CO2 data (5-minute intervals, one week)
rng(99);
samplesPerDay = 288;                       % 24 * 60 / 5
nDays         = 7;
nSamples      = nDays * samplesPerDay;     % 2016
timeStamps    = datetime(2026,9,1) + ...
    minutes(5 * (0:nSamples-1))';
hourOfDay     = hour(timeStamps) + minute(timeStamps)/60;
dayIndex      = floor(days(timeStamps - timeStamps(1)));

%% 2. Normal CO2 pattern
outdoorCO2     = 400;                      % ppm baseline
occupancyPeak  = 350 * exp(-0.5 * ((hourOfDay - 13)/3).^2);
noiseCO2       = 15 * randn(nSamples, 1);
co2Level       = outdoorCO2 + occupancyPeak + noiseCO2;

%% 3. Inject ventilation fault from Day 4 onward
faultStart     = 3 * samplesPerDay + 1;
faultDrift     = zeros(nSamples, 1);
faultDrift(faultStart:end) = 0.08 * ...
    (1:(nSamples - faultStart + 1))';
co2Level       = co2Level + faultDrift;

%% 4. Train on the first 3 fault-free days
trainIdx  = 1:(3 * samplesPerDay);
features  = table(hourOfDay, dayIndex);
treeModel = fitrtree(features(trainIdx, :), ...
    co2Level(trainIdx));

%% 5. Predict and compute residuals
co2Predicted = predict(treeModel, features);
residual     = co2Level - co2Predicted;

%% 6. Anomaly detection
trainStd     = std(residual(trainIdx));
anomalyFlag  = abs(residual) > 3 * trainStd;
nAnomalies   = nnz(anomalyFlag);
firstAnomIdx = find(anomalyFlag, 1);
firstAnomTime = timeStamps(firstAnomIdx);

%% 7. Report
fprintf('Baseline CO2 std (ppm)      : %.1f\n', trainStd);
fprintf('Three-sigma threshold (ppm) : %.1f\n', 3*trainStd);
fprintf('First anomaly detected at   : %s\n', ...
    string(firstAnomTime));
fprintf('Anomalous intervals         : %d of %d (%.1f%%)\n', ...
    nAnomalies, nSamples, 100*nAnomalies/nSamples);

%% 8. Plot
figure;
subplot(2,1,1);
plot(timeStamps, co2Level, '.', 'MarkerSize', 2, ...
    'DisplayName', 'Measured CO$_2$');
hold on;
plot(timeStamps, co2Predicted, '-', 'LineWidth', 0.8, ...
    'DisplayName', 'Model prediction');
plot(timeStamps(anomalyFlag), co2Level(anomalyFlag), ...
    'ro', 'MarkerSize', 4, 'DisplayName', 'Anomaly');
xlabel('Time'); ylabel('CO$_2$ (ppm)');
legend('Location', 'northwest');
title('Indoor CO$_2$ Monitoring with Ventilation Fault');
grid on;

subplot(2,1,2);
plot(timeStamps, residual, '.', 'MarkerSize', 2);
hold on;
yline([3*trainStd, -3*trainStd], '--r', ...
    'LineWidth', 1);
xlabel('Time'); ylabel('Residual (ppm)');
title('Prediction Residual with Three-Sigma Threshold');
grid on;
% - Computational Complexity -
% Training on N = 864 samples with d = 2 features costs
% O(N d log N), well under 0.1 seconds. Prediction over
% M = 2016 samples is O(M log N). Residual formation and
% thresholding are O(M). The entire fault-detection loop runs
% in milliseconds, enabling deployment at every BMS polling
% interval without contention.
