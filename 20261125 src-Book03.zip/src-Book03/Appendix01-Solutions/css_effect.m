%% css_effect.m
% Effect size and permutation test in base MATLAB.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : css_effect
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [cohensD, pValue] = assessTrainingEffect(preScores, postScores, numPerm)
% assessTrainingEffect  Cohen's d and a permutation p-value.
%   [cohensD, pValue] = assessTrainingEffect(preScores, postScores, numPerm)
%   Author: Dr Leo Chen | Version 1.0 | Base MATLAB (R2021b+)

    if nargin < 3, numPerm = 10000; end
    rng(42);

    preScores  = preScores(:);
    postScores = postScores(:);

    pooledSd = sqrt((var(preScores) + var(postScores)) / 2);
    cohensD  = (mean(postScores) - mean(preScores)) / pooledSd;

    combined     = [preScores; postScores];
    groupSize    = numel(preScores);
    observedDiff = mean(postScores) - mean(preScores);

    permDiff = zeros(numPerm, 1);
    for permIndex = 1:numPerm
        shuffled = combined(randperm(numel(combined)));
        permDiff(permIndex) = mean(shuffled(groupSize+1:end)) ...
                            - mean(shuffled(1:groupSize));
    end

    pValue = mean(abs(permDiff) >= abs(observedDiff));
    fprintf('Cohen''s d = %.3f | permutation p = %.4f\n', cohensD, pValue);
end
