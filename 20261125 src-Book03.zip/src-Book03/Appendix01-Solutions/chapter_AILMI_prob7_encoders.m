%% chapter_AILMI_prob7_encoders.m
% Disentangled content and style encoders.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AILMI_prob7_encoders
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [contentVec, styleVec] = disentangledEncoders(tokens, embeddings, ...
                                                       lstmContent, lstmStyle)
    % Encode sentence into content and style representations
    % tokens: [seqLen x 1] token indices
    % embeddings: [vocabSize x embedDim]
    
    seqLen = length(tokens);
    
    % Embed tokens
    embedded = embeddings(tokens, :); % [seqLen x embedDim]
    
    % Content encoder: BiLSTM with mean pooling
    [contentHidden, ~] = lstm(embedded, lstmContent);
    contentVec = mean(contentHidden, 1)'; % Average over sequence
    
    % Layer normalisation (prevents style leakage through magnitude)
    contentVec = layerNorm(contentVec);
    
    % Style encoder: Separate BiLSTM with max pooling
    [styleHidden, ~] = lstm(embedded, lstmStyle);
    styleVec = max(styleHidden, [], 1)'; % Max pooling captures salient markers
    
    % Normalise style vector
    styleVec = styleVec / norm(styleVec);
end

function normalized = layerNorm(x)
    % Layer normalisation
    mu = mean(x);
    sigma = std(x);
    normalized = (x - mu) / (sigma + 1e-8);
end
