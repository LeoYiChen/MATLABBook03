%% chapter_AICSS_problem6_adversarial.m
% Adversarial robustness evaluation framework for security-safety applications.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AICSS_problem6_adversarial
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function adversarialResults = evaluateAdversarialRobustness(neuralNetworkModel, testData, attackConfiguration, defenceConfiguration)
    % Comprehensive adversarial robustness evaluation framework
    % Author: Dr Leo Chen
    % Version: 1.0 - Initial implementation
    % Date: December 2024
    
    fprintf('Executing adversarial robustness evaluation...\n');
    
    % Initialize results structure
    adversarialResults = struct();
    adversarialResults.timestamp = datetime('now');
    adversarialResults.attackConfiguration = attackConfiguration;
    adversarialResults.defenceConfiguration = defenceConfiguration;
    
    % Extract test data
    testInputs = testData.inputs;
    testLabels = testData.labels;
    numberOfSamples = size(testInputs, 1);
    
    % Baseline performance evaluation
    baselineAccuracy = evaluateModelAccuracy(neuralNetworkModel, testInputs, testLabels);
    adversarialResults.baselineAccuracy = baselineAccuracy;
    
    fprintf('Baseline accuracy: %.3f\n', baselineAccuracy);
    
    % Generate adversarial examples using different attack methods
    attackMethods = attackConfiguration.methods;
    adversarialExamples = struct();
    attackSuccessRates = struct();
    
    for methodIndex = 1:length(attackMethods)
        attackMethod = attackMethods{methodIndex};
        fprintf('Generating adversarial examples using %s attack...\n', attackMethod);
        
        switch attackMethod
            case 'FGSM'
                [adversarialInputs, perturbations] = generateFGSMAttack(neuralNetworkModel, testInputs, testLabels, attackConfiguration.fgsm);
                
            case 'PGD'
                [adversarialInputs, perturbations] = generatePGDAttack(neuralNetworkModel, testInputs, testLabels, attackConfiguration.pgd);
                
            case 'CW'
                [adversarialInputs, perturbations] = generateCWAttack(neuralNetworkModel, testInputs, testLabels, attackConfiguration.cw);
                
            case 'DeepFool'
                [adversarialInputs, perturbations] = generateDeepFoolAttack(neuralNetworkModel, testInputs, testLabels, attackConfiguration.deepfool);
                
            otherwise
                fprintf('Warning: Unknown attack method %s\n', attackMethod);
                continue;
        end
        
        % Evaluate attack success
        adversarialAccuracy = evaluateModelAccuracy(neuralNetworkModel, adversarialInputs, testLabels);
        attackSuccessRate = 1 - adversarialAccuracy;
        
        % Store results
        adversarialExamples.(attackMethod) = adversarialInputs;
        attackSuccessRates.(attackMethod) = attackSuccessRate;
        adversarialResults.perturbations.(attackMethod) = perturbations;
        
        fprintf('%s attack success rate: %.3f\n', attackMethod, attackSuccessRate);
    end
    
    adversarialResults.adversarialExamples = adversarialExamples;
    adversarialResults.attackSuccessRates = attackSuccessRates;
    
    % Evaluate defence mechanisms
    if ~isempty(defenceConfiguration)
        defenceResults = evaluateDefenceMechanisms(neuralNetworkModel, adversarialExamples, testLabels, defenceConfiguration);
        adversarialResults.defenceResults = defenceResults;
    end
    
    % Cross-domain impact analysis
    crossDomainImpact = analyseCrossDomainImpact(adversarialExamples, neuralNetworkModel, testData);
    adversarialResults.crossDomainImpact = crossDomainImpact;
    
    % Robustness metrics calculation
    robustnessMetrics = calculateRobustnessMetrics(adversarialResults, testData);
    adversarialResults.robustnessMetrics = robustnessMetrics;
    
    % Generate comprehensive visualisation
    generateAdversarialvisualisation(adversarialResults, testData);
    
    % Statistical analysis of perturbations
    perturbationAnalysis = analysePerturbationStatistics(adversarialResults.perturbations);
    adversarialResults.perturbationAnalysis = perturbationAnalysis;
    
    % Save results
    saveAdversarialResults(adversarialResults);
    
    fprintf('Adversarial robustness evaluation completed.\n');
end

function [adversarialInputs, perturbations] = generateFGSMAttack(model, inputs, labels, fgsmConfig)
    % Generate adversarial examples using Fast Gradient Sign Method (FGSM)
    
    epsilon = fgsmConfig.epsilon;
    numberOfSamples = size(inputs, 1);
    adversarialInputs = zeros(size(inputs));
    perturbations = zeros(size(inputs));
    
    for sampleIndex = 1:numberOfSamples
        currentInput = inputs(sampleIndex, :);
        trueLabel = labels(sampleIndex);
        
        % Calculate gradient of loss with respect to input
        gradient = calculateInputGradient(model, currentInput, trueLabel);
        
        % Generate adversarial perturbation
        perturbation = epsilon * sign(gradient);
        
        % Apply perturbation
        adversarialInput = currentInput + perturbation;
        
        % Ensure input bounds are respected
        adversarialInput = max(0, min(1, adversarialInput));
        
        adversarialInputs(sampleIndex, :) = adversarialInput;
        perturbations(sampleIndex, :) = perturbation;
    end
end

function [adversarialInputs, perturbations] = generatePGDAttack(model, inputs, labels, pgdConfig)
    % Generate adversarial examples using Projected Gradient Descent (PGD)
    
    epsilon = pgdConfig.epsilon;
    stepSize = pgdConfig.stepSize;
    numberOfSteps = pgdConfig.numberOfSteps;
    numberOfSamples = size(inputs, 1);
    
    adversarialInputs = zeros(size(inputs));
    perturbations = zeros(size(inputs));
    
    for sampleIndex = 1:numberOfSamples
        currentInput = inputs(sampleIndex, :);
        trueLabel = labels(sampleIndex);
        
        % Initialize adversarial example with random perturbation
        randomPerturbation = epsilon * (2 * rand(size(currentInput)) - 1);
        adversarialInput = currentInput + randomPerturbation;
        adversarialInput = max(0, min(1, adversarialInput));
        
        % Iterative gradient-based optimization
        for stepIndex = 1:numberOfSteps
            % Calculate gradient
            gradient = calculateInputGradient(model, adversarialInput, trueLabel);
            
            % Update adversarial example
            adversarialInput = adversarialInput + stepSize * sign(gradient);
            
            % Project back to epsilon-ball
            perturbation = adversarialInput - currentInput;
            perturbation = max(-epsilon, min(epsilon, perturbation));
            adversarialInput = currentInput + perturbation;
            
            % Ensure input bounds
            adversarialInput = max(0, min(1, adversarialInput));
        end
        
        adversarialInputs(sampleIndex, :) = adversarialInput;
        perturbations(sampleIndex, :) = adversarialInput - currentInput;
    end
end

function gradient = calculateInputGradient(model, input, trueLabel)
    % Calculate gradient of loss with respect to input (simplified implementation)
    
    delta = 1e-6;
    inputSize = length(input);
    gradient = zeros(size(input));
    
    % Forward pass to get baseline prediction
    baselinePrediction = predict(model, input);
    baselineLoss = calculateCrossEntropyLoss(baselinePrediction, trueLabel);
    
    % Numerical gradient calculation
    for dimensionIndex = 1:inputSize
        perturbedInput = input;
        perturbedInput(dimensionIndex) = perturbedInput(dimensionIndex) + delta;
        
        perturbedPrediction = predict(model, perturbedInput);
        perturbedLoss = calculateCrossEntropyLoss(perturbedPrediction, trueLabel);
        
        gradient(dimensionIndex) = (perturbedLoss - baselineLoss) / delta;
    end
end

function loss = calculateCrossEntropyLoss(predictions, trueLabel)
    % Calculate cross-entropy loss
    
    % Convert to probability distribution
    expPredictions = exp(predictions - max(predictions));
    probabilities = expPredictions / sum(expPredictions);
    
    % Calculate cross-entropy loss
    loss = -log(probabilities(trueLabel) + eps);
end

function defenceResults = evaluateDefenceMechanisms(model, adversarialExamples, testLabels, defenceConfig)
    % Evaluate various defence mechanisms against adversarial attacks
    
    defenceResults = struct();
    defenceMethods = defenceConfig.methods;
    
    for methodIndex = 1:length(defenceMethods)
        defenceMethod = defenceMethods{methodIndex};
        fprintf('Evaluating %s defence mechanism...\n', defenceMethod);
        
        switch defenceMethod
            case 'InputPreprocessing'
                defenceResults.inputPreprocessing = evaluateInputPreprocessing(model, adversarialExamples, testLabels, defenceConfig.preprocessing);
                
            case 'AdversarialDetection'
                defenceResults.adversarialDetection = evaluateAdversarialDetection(model, adversarialExamples, testLabels, defenceConfig.detection);
                
            case 'EnsembleDefence'
                defenceResults.ensembleDefence = evaluateEnsembleDefence(model, adversarialExamples, testLabels, defenceConfig.ensemble);
                
            case 'GradientMasking'
                defenceResults.gradientMasking = evaluateGradientMasking(model, adversarialExamples, testLabels, defenceConfig.masking);
        end
    end
end

function generateAdversarialvisualisation(adversarialResults, testData)
    % Generate comprehensive adversarial robustness visualisation
    
    figure('Position', [100, 100, 1800, 1200]);
    
    % Attack success rates comparison
    subplot(3, 4, 1);
    attackMethods = fieldnames(adversarialResults.attackSuccessRates);
    successRates = zeros(length(attackMethods), 1);
    
    for methodIndex = 1:length(attackMethods)
        successRates(methodIndex) = adversarialResults.attackSuccessRates.(attackMethods{methodIndex});
    end
    
    bar(successRates, 'FaceColor', [0.8, 0.4, 0.4], 'EdgeColor', 'darkred');
    set(gca, 'XTickLabel', attackMethods);
    ylabel('Attack Success Rate', 'FontSize', 12);
    title('Attack Method Comparison', 'FontSize', 14, 'FontWeight', 'bold');
    xtickangle(45);
    ylim([0, 1]);
    grid on;
    
    % Perturbation magnitude analysis
    subplot(3, 4, 2);
    if isfield(adversarialResults, 'perturbationAnalysis')
        perturbationMagnitudes = adversarialResults.perturbationAnalysis.averageMagnitudes;
        bar(perturbationMagnitudes, 'FaceColor', [0.6, 0.8, 0.6], 'EdgeColor', 'darkgreen');
        set(gca, 'XTickLabel', attackMethods);
        ylabel('Average Perturbation Magnitude', 'FontSize', 12);
        title('Perturbation Analysis', 'FontSize', 12, 'FontWeight', 'bold');
        xtickangle(45);
        grid on;
    end
    
    % Robustness metrics
    subplot(3, 4, 3);
    if isfield(adversarialResults, 'robustnessMetrics')
        robustnessScores = [adversarialResults.robustnessMetrics.certifiedRobustness, ...
                           adversarialResults.robustnessMetrics.empiricalRobustness, ...
                           adversarialResults.robustnessMetrics.averageRobustness];
        
        bar(robustnessScores, 'FaceColor', [0.7, 0.6, 0.9]);
        set(gca, 'XTickLabel', {'Certified', 'Empirical', 'Average'});
        ylabel('Robustness Score', 'FontSize', 12);
        title('Robustness Metrics', 'FontSize', 12, 'FontWeight', 'bold');
        ylim([0, 1]);
        grid on;
    end
    
    % Defence mechanism effectiveness
    subplot(3, 4, 4);
    if isfield(adversarialResults, 'defenceResults')
        defenceMethods = fieldnames(adversarialResults.defenceResults);
        defenceEffectiveness = zeros(length(defenceMethods), 1);
        
        for methodIndex = 1:length(defenceMethods)
            defenceEffectiveness(methodIndex) = adversarialResults.defenceResults.(defenceMethods{methodIndex}).effectiveness;
        end
        
        bar(defenceEffectiveness, 'FaceColor', [0.9, 0.7, 0.5]);
        set(gca, 'XTickLabel', defenceMethods);
        ylabel('Defence Effectiveness', 'FontSize', 12);
        title('Defence Mechanism Performance', 'FontSize', 12, 'FontWeight', 'bold');
        xtickangle(45);
        ylim([0, 1]);
        grid on;
    end
    
    % Adversarial example visualisation (for image data)
    if size(testData.inputs, 2) == 784 % MNIST-like data
        subplot(3, 4, 5);
        originalImage = reshape(testData.inputs(1, :), [28, 28]);
        imshow(originalImage, []);
        title('Original Image', 'FontSize', 12, 'FontWeight', 'bold');
        
        subplot(3, 4, 6);
        if isfield(adversarialResults.adversarialExamples, 'FGSM')
            adversarialImage = reshape(adversarialResults.adversarialExamples.FGSM(1, :), [28, 28]);
            imshow(adversarialImage, []);
            title('FGSM Adversarial Example', 'FontSize', 12, 'FontWeight', 'bold');
        end
        
        subplot(3, 4, 7);
        if isfield(adversarialResults.perturbations, 'FGSM')
            perturbation = reshape(adversarialResults.perturbations.FGSM(1, :), [28, 28]);
            imshow(perturbation, []);
            colormap(gca, 'hot');
            title('FGSM Perturbation', 'FontSize', 12, 'FontWeight', 'bold');
        end
    end
    
    % Cross-domain impact analysis
    subplot(3, 4, 8);
    if isfield(adversarialResults, 'crossDomainImpact')
        impactScores = adversarialResults.crossDomainImpact.domainImpactScores;
        domainNames = adversarialResults.crossDomainImpact.domainNames;
        
        bar(impactScores, 'FaceColor', [0.8, 0.8, 0.4]);
        set(gca, 'XTickLabel', domainNames);
        ylabel('Cross-domain Impact Score', 'FontSize', 12);
        title('Cross-domain Impact Analysis', 'FontSize', 12, 'FontWeight', 'bold');
        xtickangle(45);
        grid on;
    end
    
    % Perturbation distribution analysis
    subplot(3, 4, 9);
    if isfield(adversarialResults, 'perturbationAnalysis')
        perturbationDistribution = adversarialResults.perturbationAnalysis.distributionData;
        histogram(perturbationDistribution, 30, 'FaceColor', [0.6, 0.6, 0.8], 'EdgeColor', 'black');
        xlabel('Perturbation Magnitude', 'FontSize', 12);
        ylabel('Frequency', 'FontSize', 12);
        title('Perturbation Distribution', 'FontSize', 12, 'FontWeight', 'bold');
        grid on;
    end
    
    % Model confidence analysis
    subplot(3, 4, 10);
    if isfield(adversarialResults, 'robustnessMetrics')
        confidenceData = adversarialResults.robustnessMetrics.confidenceAnalysis;
        originalConfidence = confidenceData.originalConfidence;
        adversarialConfidence = confidenceData.adversarialConfidence;
        
        scatter(originalConfidence, adversarialConfidence, 50, 'filled', 'alpha', 0.6);
        hold on;
        plot([0, 1], [0, 1], 'r--', 'LineWidth', 2);
        xlabel('Original Confidence', 'FontSize', 12);
        ylabel('Adversarial Confidence', 'FontSize', 12);
        title('Confidence Analysis', 'FontSize', 12, 'FontWeight', 'bold');
        grid on;
    end
    
    % Computational overhead analysis
    subplot(3, 4, 11);
    if isfield(adversarialResults, 'computationalOverhead')
        overheadData = adversarialResults.computationalOverhead;
        methods = fieldnames(overheadData);
        computationTimes = zeros(length(methods), 1);
        
        for methodIndex = 1:length(methods)
            computationTimes(methodIndex) = overheadData.(methods{methodIndex});
        end
        
        bar(computationTimes, 'FaceColor', [0.9, 0.6, 0.7]);
        set(gca, 'XTickLabel', methods);
        ylabel('Computation Time (s)', 'FontSize', 12);
        title('Computational Overhead', 'FontSize', 12, 'FontWeight', 'bold');
        xtickangle(45);
        grid on;
    end
    
    % Summary statistics
    subplot(3, 4, 12);
    axis off;
    
    summaryText = sprintf('Adversarial Robustness Summary\n\n');
    summaryText = [summaryText, sprintf('Baseline Accuracy: %.3f\n', adversarialResults.baselineAccuracy)];
    
    if ~isempty(attackMethods)
        averageSuccessRate = mean(successRates);
        summaryText = [summaryText, sprintf('Average Attack Success: %.3f\n', averageSuccessRate)];
        summaryText = [summaryText, sprintf('Most Effective Attack: %s\n', attackMethods{successRates == max(successRates)})];
    end
    
    if isfield(adversarialResults, 'robustnessMetrics')
        summaryText = [summaryText, sprintf('Empirical Robustness: %.3f\n', ...
            adversarialResults.robustnessMetrics.empiricalRobustness)];
    end
    
    summaryText = [summaryText, sprintf('\nAttack Methods Tested: %d\n', length(attackMethods))];
    summaryText = [summaryText, sprintf('Test Samples: %d\n', size(testData.inputs, 1))];
    summaryText = [summaryText, sprintf('\nAnalysis Date: %s', string(adversarialResults.timestamp))];
    
    text(0.05, 0.95, summaryText, 'FontSize', 11, 'VerticalAlignment', 'top', ...
        'HorizontalAlignment', 'left', 'Interpreter', 'none', 'FontWeight', 'bold');
    
    % Save visualisation in multiple formats
    saveas(gcf, 'AdversarialRobustnessResults.fig');
    saveas(gcf, 'AdversarialRobustnessResults.eps', 'epsc');
    saveas(gcf, 'AdversarialRobustnessResults.jpg');
    
    fprintf('Adversarial robustness visualisation saved in multiple formats.\n');
end
