%% lst_sol07_syntax_sentiment.m
% Text tokenisation and VADER sentiment.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : lst:sol07_syntax_sentiment
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
documents = tokenizedDocument(rawLyrics);
documents = removeStopWords(documents);
documents = normalizeWords(documents, 'Style', 'lemma');
sentimentScores = vaderSentimentScores(documents);
