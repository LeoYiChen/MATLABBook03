%% lst_sol06_syntax_pdist2.m
% Pairwise distance computation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : lst:sol06_syntax_pdist2
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
distanceMatrix = pdist2( ...
    featureMatrix, featureMatrix, 'cosine');
[sortedDistances, sortedIndices] = sort( ...
    distanceMatrix(queryIndex, :), 'ascend');
recommendedIndices = sortedIndices(2:topK+1);
