%% chapter_AICE_code_P03.m
% Solution~3: IFC spatial containment hierarchy and graph queries (MATLABBook02_Chapter13_section8_Problem03.m).
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AICE_code_P03
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% MATLABBook02_Chapter13_section8_Problem03.m
% Problem 3: IFC Spatial Containment Hierarchy for a Hospital
%
% Description : Builds a directed graph encoding the IFC spatial
%               containment of a hospital, performs BFS queries
%               and identifies storey sizes.
% Author      : Dr Yi Chen
% Date        : 2025
% MATLAB      : R2024b or later
% Toolboxes   : None (base MATLAB)
% Reference   : Chapter 13, Problem 3
% =================================================================

%% 1. Define the containment hierarchy (parent -> child)
parentNodes = ["Project","Site", ...
    "Building","Building","Building", ...
    "GroundFloor","GroundFloor","GroundFloor", ...
    "FirstFloor","FirstFloor","FirstFloor", ...
    "SecondFloor","SecondFloor"];
childNodes  = ["Site","Building", ...
    "GroundFloor","FirstFloor","SecondFloor", ...
    "Reception","Pharmacy","Emergency", ...
    "WardA","WardB","OperatingTheatre", ...
    "PlantRoom","ServerRoom"];

%% 2. Construct the directed graph
containmentGraph = digraph(parentNodes, childNodes);

%% 3(a). BFS: all elements beneath the First Floor
queryNode       = "FirstFloor";
descendantIdx   = bfsearch(containmentGraph, queryNode);
descendantNames = containmentGraph.Nodes.Name(descendantIdx);
fprintf('Elements beneath %s:\n', queryNode);
for elementIndex = 1:numel(descendantNames)
    fprintf('  %s\n', descendantNames{elementIndex});
end

%% 3(b). Containment path from Project to OperatingTheatre
[pathNodes, pathLength] = shortestpath(containmentGraph, ...
    "Project", "OperatingTheatre");
fprintf('\nPath from Project to OperatingTheatre (%d edges):\n', ...
    pathLength);
fprintf('  %s\n', strjoin(pathNodes, ' -> '));

%% 3(c). Count child elements per storey
storeyNames  = ["GroundFloor", "FirstFloor", "SecondFloor"];
elementCount = zeros(size(storeyNames));
for storeyIndex = 1:numel(storeyNames)
    allDescendants = bfsearch(containmentGraph, ...
        storeyNames(storeyIndex));
    % Exclude the storey node itself
    elementCount(storeyIndex) = numel(allDescendants) - 1;
end
[maxCount, maxIdx] = max(elementCount);
fprintf('\nStorey with most elements: %s (%d elements)\n', ...
    storeyNames(maxIdx), maxCount);

%% 4. Visualise
figure;
plot(containmentGraph, 'Layout', 'layered', ...
    'NodeLabel', containmentGraph.Nodes.Name, ...
    'NodeFontSize', 9, 'ArrowSize', 10);
title('IFC Spatial Containment Hierarchy');
% - Computational Complexity -
% The graph has V = 13 nodes and E = 13 edges. Each bfsearch
% costs O(V + E) = O(26). shortestpath on a DAG is also
% O(V + E). The three storey queries therefore cost O(3(V + E)).
% The same linear scaling ensures that real IFC models with
% tens of thousands of elements remain interactively queryable.
