%% chapter_AI_CV_problem4_parallel.m
% Parallel processing syntax.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AI_CV_problem4_parallel
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Create parallel pool
parpool('local', numWorkers);

% Parallel data processing
parfor imageIndex = 1:numImages
    processedImages{imageIndex} = processImage(images{imageIndex});
end
