%% chapter_AI_CV_problem1_complete.m
% Advanced Temporal Cross-Validation Implementation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AI_CV_problem1_complete
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% Advanced Temporal Cross-Validation Framework
% Author: Dr Leo Chen
% Created: January 2025
% MATLAB Version: R2024a or later

function results = advancedTemporalCrossValidation()
    fprintf('Advanced Temporal Cross-Validation Framework\n');
    
    % Generate temporal dataset
    [features, labels, timeStamps] = generateTemporalDataset();
    
    % Compare validation strategies
    results = compareValidationStrategies(features, labels, timeStamps);
    
    % Visualise results
    visualiseResults(results);
end

function [features, labels, timeStamps] = generateTemporalDataset()
    numSamples = 1000;
    numFeatures = 50;
    
    % Generate time stamps
    baseTime = datetime('2023-01-01');
    intervals = exprnd(24, numSamples, 1);
    timeStamps = baseTime + hours(cumsum(intervals));
    
    % Generate features with temporal correlation
    features = zeros(numSamples, numFeatures);
    for sampleIndex = 1:numSamples
        if sampleIndex == 1
            features(sampleIndex, :) = randn(1, numFeatures);
        else
            correlation = 0.7 * features(sampleIndex-1, :);
            features(sampleIndex, :) = correlation + 0.3 * randn(1, numFeatures);
        end
    end
    
    % Generate labels with temporal trends
    trendComponent = sin(2 * pi * (1:numSamples) / 200);
    featureSum = sum(features, 2);
    combinedSignal = featureSum + 2 * trendComponent';
    
    % Convert to class labels
    thresholds = quantile(combinedSignal, [1/3, 2/3]);
    labels = ones(numSamples, 1);
    labels(combinedSignal > thresholds(1)) = 2;
    labels(combinedSignal > thresholds(2)) = 3;
end

function results = compareValidationStrategies(features, labels, timeStamps)
    % Standard k-fold
    results.standardKFold = performStandardKFold(features, labels);
    
    % Temporal expanding window
    results.expandingWindow = performExpandingWindow(features, labels);
    
    % Gap-based validation
    results.gapBasedCV = performGapBasedValidation(features, labels);
end

function results = performStandardKFold(features, labels)
    cv = cvpartition(labels, 'KFold', 5);
    accuracies = zeros(5, 1);
    
    for foldIndex = 1:5
        trainIdx = training(cv, foldIndex);
        testIdx = test(cv, foldIndex);
        
        model = fitcnb(features(trainIdx, :), labels(trainIdx));
        predictions = predict(model, features(testIdx, :));
        accuracies(foldIndex) = mean(predictions == labels(testIdx));
    end
    
    results.meanAccuracy = mean(accuracies);
    results.stdAccuracy = std(accuracies);
end

function results = performExpandingWindow(features, labels)
    minTrainSize = 200;
    testSize = 100;
    accuracies = [];
    
    currentTrainSize = minTrainSize;
    while currentTrainSize + testSize <= length(labels)
        trainIdx = 1:currentTrainSize;
        testIdx = (currentTrainSize + 1):(currentTrainSize + testSize);
        
        model = fitcnb(features(trainIdx, :), labels(trainIdx));
        predictions = predict(model, features(testIdx, :));
        accuracy = mean(predictions == labels(testIdx));
        
        accuracies = [accuracies; accuracy];
        currentTrainSize = currentTrainSize + testSize;
    end
    
    results.meanAccuracy = mean(accuracies);
    results.stdAccuracy = std(accuracies);
end

function results = performGapBasedValidation(features, labels)
    gapSize = 50;
    trainSize = 250;
    testSize = 100;
    accuracies = [];
    
    currentStart = 1;
    while currentStart + trainSize + gapSize + testSize <= length(labels)
        trainIdx = currentStart:(currentStart + trainSize - 1);
        testStart = currentStart + trainSize + gapSize;
        testIdx = testStart:(testStart + testSize - 1);
        
        model = fitcnb(features(trainIdx, :), labels(trainIdx));
        predictions = predict(model, features(testIdx, :));
        accuracy = mean(predictions == labels(testIdx));
        
        accuracies = [accuracies; accuracy];
        currentStart = currentStart + trainSize + gapSize + testSize;
    end
    
    results.meanAccuracy = mean(accuracies);
    results.stdAccuracy = std(accuracies);
end

function visualiseResults(results)
    figure('Position', [100, 100, 800, 600]);
    
    methods = fieldnames(results);
    accuracies = zeros(length(methods), 1);
    stds = zeros(length(methods), 1);
    
    for methodIndex = 1:length(methods)
        method = methods{methodIndex};
        accuracies(methodIndex) = results.(method).meanAccuracy;
        stds(methodIndex) = results.(method).stdAccuracy;
    end
    
    bar(accuracies);
    hold on;
    errorbar(1:length(methods), accuracies, stds, 'k.', 'LineWidth', 2);
    set(gca, 'XTickLabel', methods);
    xtickangle(45);
    ylabel('Accuracy');
    title('Validation Strategy Comparison');
end

% Execute main function
results = advancedTemporalCrossValidation();
