%% chapter_AILMI_prob8_adversarial.m
% Adversarial training for language-invariant features.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AILMI_prob8_adversarial
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [encLoss, discLoss, cmdLoss] = adversarialMultilingualLoss(...
    features, commandLabel, languageLabel, encoder, langDisc, cmdClassifier, ...
    lambdaAdv)
    % Compute adversarial training loss
    % features: [batchSize x timeSteps x mfccDim]
    % commandLabel: [batchSize x 1] semantic command (0-34)
    % languageLabel: [batchSize x 1] source language (0-8)
    
    % Forward pass through encoder
    acousticFeatures = encoder(features); % [batchSize x 128]
    
    % Command classification loss (main task)
    cmdLogits = cmdClassifier(acousticFeatures);
    cmdProbs = softmax(cmdLogits);
    cmdLoss = crossEntropyLoss(cmdProbs, commandLabel);
    
    % Language discrimination (with gradient reversal)
    % Discriminator tries to predict language
    langLogits = langDisc(acousticFeatures);
    langProbs = softmax(langLogits);
    
    % Discriminator loss: Correctly classify language
    discLoss = crossEntropyLoss(langProbs, languageLabel);
    
    % Encoder adversarial loss: Fool discriminator
    % Achieved via gradient reversal layer in practice
    % Here we maximise discriminator's entropy (uncertainty)
    langEntropy = -sum(langProbs .* log(langProbs + eps), 2);
    encAdvLoss = -mean(langEntropy); % Negative entropy (want high uncertainty)
    
    % Total encoder loss
    encLoss = cmdLoss + lambdaAdv * encAdvLoss;
end

function loss = crossEntropyLoss(probs, labels)
    % Cross-entropy loss
    % probs: [batchSize x numClasses]
    % labels: [batchSize x 1]
    
    batchSize = size(probs, 1);
    loss = 0;
    for i = 1:batchSize
        loss = loss - log(probs(i, labels(i) + 1) + eps);
    end
    loss = loss / batchSize;
end
