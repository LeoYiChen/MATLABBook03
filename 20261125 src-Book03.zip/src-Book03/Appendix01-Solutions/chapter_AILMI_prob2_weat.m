%% chapter_AILMI_prob2_weat.m
% WEAT bias quantification implementation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AILMI_prob2_weat
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [effectSize, pValue] = computeWEAT(embeddings, targetX, targetY, attrA, attrB)
    % Compute association scores for each target word
    scoresX = arrayfun(@(x) associationDiff(embeddings, x, attrA, attrB), targetX);
    scoresY = arrayfun(@(y) associationDiff(embeddings, y, attrA, attrB), targetY);
    
    % Effect size (Cohen's d)
    effectSize = (mean(scoresX) - mean(scoresY)) / std([scoresX, scoresY]);
    
    % Permutation test for p-value
    numPerms = 10000;
    observed = mean(scoresX) - mean(scoresY);
    permDiffs = zeros(numPerms, 1);
    
    allScores = [scoresX, scoresY];
    for i = 1:numPerms
        perm = randperm(length(allScores));
        permX = allScores(perm(1:length(targetX)));
        permY = allScores(perm(length(targetX)+1:end));
        permDiffs(i) = mean(permX) - mean(permY);
    end
    
    pValue = sum(abs(permDiffs) >= abs(observed)) / numPerms;
end

function score = associationDiff(embeddings, word, attrA, attrB)
    % Compute s(w, A, B) = mean_cos(w, A) - mean_cos(w, B)
    wordVec = embeddings(word, :);
    
    cosA = arrayfun(@(a) cosineSim(wordVec, embeddings(a, :)), attrA);
    cosB = arrayfun(@(b) cosineSim(wordVec, embeddings(b, :)), attrB);
    
    score = mean(cosA) - mean(cosB);
end
