%% chapter_AI_CV_problem5_quantum.m
% Quantum feature mapping syntax.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AI_CV_problem5_quantum
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Create quantum feature map
quantumState = encodeClassicalImage(image, numQubits);

% Apply quantum circuit
mappedFeatures = applyQuantumCircuit(quantumState, circuitParameters);
