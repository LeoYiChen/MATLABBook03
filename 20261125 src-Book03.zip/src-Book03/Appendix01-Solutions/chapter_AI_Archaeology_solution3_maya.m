%% chapter_AI_Archaeology_solution3_maya.m
% Maya Settlement Discovery System Using LiDAR Analysis.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AI_Archaeology_solution3_maya
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [mayaDiscoveries, landscapeAnalysis] = discoverMayaSettlements(lidarDataPath, knownSitesPath, outputDir)
%% Maya Settlement Discovery System Using LiDAR Analysis
% Author: Dr Leo Chen
% Version: 2.4.0
% Date: January 2025
% Purpose: Automated discovery of Maya settlements in Guatemalan rainforest
% Input: LiDAR point cloud data, known archaeological sites, output directory
% Output: Settlement discoveries and comprehensive landscape analysis

fprintf('\\textbf{Maya Settlement Discovery System Using LiDAR Analysis}\\n');
fprintf('Archaeological Region: Maya Lowlands, Pet--n, Guatemala\\n');
fprintf('Time Period: Classic Maya Civilisation (250-900 CE)\\n');
fprintf('Technology: Airborne Laser Scanning through 60m rainforest canopy\\n');
fprintf('Coverage Area: 500 km? of dense tropical forest\\n\\n');

%% Load LiDAR Dataset and Known Archaeological Sites
% Load massive LiDAR point cloud dataset
fprintf('Loading continental-scale LiDAR dataset...\\n');
lidarPointCloud = loadLiDARPointCloud(lidarDataPath);
fprintf('LiDAR data loaded: %.1f million points\\n', length(lidarPointCloud.Location) / 1000000);

% Load known Maya archaeological sites for training and validation
knownSites = loadKnownMayaSites(knownSitesPath);
numKnownSites = length(knownSites);
fprintf('Known Maya sites loaded: %d documented settlements\\n', numKnownSites);

%% LiDAR Data Preprocessing and Digital Terrain Model Generation
fprintf('\\textbf{Preprocessing LiDAR Data and Generating Terrain Models}\\n');

% Classify point cloud into ground and vegetation returns
groundPoints = classifyGroundReturns(lidarPointCloud);
vegetationPoints = classifyVegetationReturns(lidarPointCloud);

fprintf('Point cloud classification: %.1fM ground, %.1fM vegetation\\n', ...
    length(groundPoints) / 1000000, length(vegetationPoints) / 1000000);

% Generate high-resolution Digital Terrain Model (DTM)
[DTM, gridX, gridY] = generateDigitalTerrainModel(groundPoints, 'Resolution', 0.5); % 0.5m resolution
[DTMHeight, DTMWidth] = size(DTM);

% Generate canopy height model
CHM = generateCanopyHeightModel(groundPoints, vegetationPoints, gridX, gridY);

% Calculate terrain derivatives for feature detection
[slope, aspect] = gradient(DTM);
slopeMagnitude = sqrt(slope.^2 + aspect.^2);
curvature = del2(DTM);

fprintf('Terrain models generated: %dx%d grid at 0.5m resolution\\n', DTMHeight, DTMWidth);

%% Archaeological Feature Detection Using AI
fprintf('\\textbf{Detecting Archaeological Features Using Machine Learning}\\n');

% Extract known Maya architectural signatures for training
trainingFeatures = extractArchitecturalSignatures(knownSites, DTM, gridX, gridY);
featureTypes = {'Pyramids', 'Platforms', 'Plazas', 'Causeways', 'Reservoirs', 'Terraces', 'Walls'};

% Train feature detection models for each architectural type
detectionModels = struct();
for featureIdx = 1:length(featureTypes)
    featureType = featureTypes{featureIdx};
    fprintf('Training %s detection model...\\n', featureType);
    
    % Extract training data for current feature type
    positiveExamples = extractFeatureExamples(trainingFeatures, featureType, 'positive');
    negativeExamples = extractFeatureExamples(trainingFeatures, featureType, 'negative');
    
    % Train Random Forest classifier
    detectionModels.(featureType) = trainRandomForestDetector(positiveExamples, negativeExamples);
end

% Apply trained models to detect features across entire dataset
detectedFeatures = struct();
detectionConfidences = struct();

for featureIdx = 1:length(featureTypes)
    featureType = featureTypes{featureIdx};
    fprintf('Detecting %s across survey area...\\n', featureType);
    
    % Sliding window analysis across DTM
    [features, confidences] = detectFeaturesInDTM(DTM, slopeMagnitude, curvature, ...
        detectionModels.(featureType), featureType);
    
    detectedFeatures.(featureType) = features;
    detectionConfidences.(featureType) = confidences;
end

fprintf('Feature detection complete: %d feature types analysed\\n', length(featureTypes));

%% Cultural vs Natural Feature Classification
fprintf('\\textbf{Distinguishing Cultural Features from Natural Formations}\\n');

% Combine all detected features for cultural classification
allFeatures = combineDetectedFeatures(detectedFeatures);
numFeatures = length(allFeatures);

% Extract comprehensive feature descriptors
featureDescriptors = struct();
for featureIdx = 1:numFeatures
    feature = allFeatures(featureIdx);
    
    % Geometric descriptors
    featureDescriptors(featureIdx).area = feature.area;
    featureDescriptors(featureIdx).perimeter = feature.perimeter;
    featureDescriptors(featureIdx).elongation = feature.length / feature.width;
    featureDescriptors(featureIdx).rectangularity = feature.area / (feature.length * feature.width);
    
    % Topographic descriptors
    featureDescriptors(featureIdx).height = feature.maxElevation - feature.minElevation;
    featureDescriptors(featureIdx).volume = feature.volume;
    featureDescriptors(featureIdx).slopeVariability = std(feature.slopes);
    
    % Contextual descriptors
    featureDescriptors(featureIdx).isolation = calculateFeatureIsolation(feature, allFeatures);
    featureDescriptors(featureIdx).drainageProximity = calculateDrainageProximity(feature, DTM);
    featureDescriptors(featureIdx).topographicPosition = calculateTopographicPosition(feature, DTM);
end

% Train cultural vs natural classifier
culturalClassifier = trainCulturalClassifier(featureDescriptors, knownSites);

% Classify all features as cultural or natural
culturalProbabilities = zeros(numFeatures, 1);
for featureIdx = 1:numFeatures
    culturalProbabilities(featureIdx) = predict(culturalClassifier, featureDescriptors(featureIdx));
end

% Filter features by cultural probability threshold
culturalThreshold = 0.7;
culturalFeatures = allFeatures(culturalProbabilities > culturalThreshold);
numCulturalFeatures = length(culturalFeatures);

fprintf('Cultural feature classification: %d/%d features identified as cultural\\n', ...
    numCulturalFeatures, numFeatures);

%% Settlement Pattern Analysis and Clustering
fprintf('\\textbf{Analysing Settlement Patterns and Clustering}\\n');

% Extract settlement centres and boundaries
settlementCentres = extractSettlementCentres(culturalFeatures);
numSettlements = length(settlementCentres);

% Hierarchical clustering of settlements
distanceMatrix = calculateSettlementDistances(settlementCentres);
clusterTree = linkage(distanceMatrix, 'ward');

% Determine optimal number of clusters
optimalClusters = determineOptimalClusters(clusterTree, settlementCentres);
settlementClusters = cluster(clusterTree, 'MaxClust', optimalClusters);

% Analyse settlement hierarchy within clusters
settlementHierarchy = analyseSettlementHierarchy(culturalFeatures, settlementClusters);

% Calculate settlement density and distribution patterns
settlementDensity = calculateSettlementDensity(settlementCentres, gridX, gridY);
spatialDistribution = analyseSpacialDistribution(settlementCentres, settlementClusters);

fprintf('Settlement analysis: %d settlements grouped into %d clusters\\n', ...
    numSettlements, optimalClusters);

%% Ancient Landscape Reconstruction
fprintf('\\textbf{Reconstructing Ancient Maya Landscape Modifications}\\n');

% Detect ancient agricultural terraces
agriculturalTerraces = detectAgriculturalTerraces(DTM, slopeMagnitude, culturalFeatures);
numTerraces = length(agriculturalTerraces);

% Identify ancient water management systems
waterManagement = identifyWaterManagement(DTM, culturalFeatures);
numReservoirs = length(waterManagement.reservoirs);
numCanals = length(waterManagement.canals);

% Detect ancient road and causeway networks
roadNetworks = detectAncientRoads(DTM, culturalFeatures, settlementCentres);
totalRoadLength = sum([roadNetworks.length]);

% Analyse deforestation and landscape modification
ancientDeforestation = analyseAncientDeforestation(CHM, culturalFeatures, agriculturalTerraces);

% Calculate ancient population estimates
populationEstimates = estimateAncientPopulation(culturalFeatures, agriculturalTerraces, ...
    settlementHierarchy);

fprintf('Landscape reconstruction:\\n');
fprintf('  Agricultural terraces: %d systems\\n', numTerraces);
fprintf('  Water management: %d reservoirs, %d canals\\n', numReservoirs, numCanals);
fprintf('  Road networks: %.1f km total length\\n', totalRoadLength / 1000);
fprintf('  Population estimate: %d - %d inhabitants\\n', ...
    populationEstimates.minimum, populationEstimates.maximum);

%% Predictive Modelling for Undiscovered Sites
fprintf('\\textbf{Generating Predictive Models for Site Discovery}\\n');

% Environmental variables for predictive modelling
environmentalVariables = extractEnvironmentalVariables(DTM, gridX, gridY);

% Cultural proximity variables
culturalProximity = calculateCulturalProximity(settlementCentres, gridX, gridY);

% Combine variables for predictive modelling
predictiveVariables = combineVariables(environmentalVariables, culturalProximity);

% Train site probability model using known sites
sitesProbabilityModel = trainSiteProbabilityModel(predictiveVariables, knownSites, culturalFeatures);

% Generate probability map for undiscovered sites
[probabilityMap, highProbabilityAreas] = generateSiteProbabilityMap(predictiveVariables, ...
    sitesProbabilityModel, gridX, gridY);

numHighProbabilityAreas = length(highProbabilityAreas);

fprintf('Predictive modelling: %d high-probability areas identified for future survey\\n', ...
    numHighProbabilityAreas);

%% Ground-Truthing Recommendations and Validation
fprintf('\\textbf{Generating Ground-Truthing and Excavation Recommendations}\\n');

% Prioritise discoveries for ground verification
discoveryPriorities = prioritiseDiscoveries(culturalFeatures, culturalProbabilities, ...
    settlementHierarchy, highProbabilityAreas);

% Generate excavation recommendations
excavationRecommendations = generateExcavationRecommendations(discoveryPriorities, ...
    culturalFeatures, accessibilityAnalysis(DTM, gridX, gridY));

% Calculate survey effort and resource requirements
surveyEffort = calculateSurveyEffort(discoveryPriorities, excavationRecommendations);

fprintf('Ground-truthing recommendations: %d priority targets identified\\n', ...
    length(discoveryPriorities));

%% Comprehensive Visualisation and Analysis
figure('Position', [50, 50, 1800, 1200]);

% Digital Terrain Model with detected features
subplot(2, 4, 1);
imagesc(gridX(1, :), gridY(:, 1), DTM);
colormap(gca, 'terrain');
colorbar;
hold on;
plotDetectedFeatures(culturalFeatures, 'ko', 'MarkerSize', 4);
title('\\textbf{DTM with Detected Cultural Features}');
xlabel('Easting (m)'); ylabel('Northing (m)');

% Settlement clustering analysis
subplot(2, 4, 2);
scatter(settlementCentres(:, 1), settlementCentres(:, 2), 100, settlementClusters, 'filled');
colormap(gca, 'lines');
colorbar;
title('\\textbf{Settlement Clustering Analysis}');
xlabel('Easting (m)'); ylabel('Northing (m)');

% Feature type distribution
subplot(2, 4, 3);
featureCounts = zeros(1, length(featureTypes));
for i = 1:length(featureTypes)
    featureCounts(i) = length(detectedFeatures.(featureTypes{i}));
end
bar(featureCounts);
set(gca, 'XTickLabel', featureTypes, 'XTickLabelRotation', 45);
ylabel('Number of Features');
title('\\textbf{Archaeological Feature Distribution}');
grid on;

% Site probability map
subplot(2, 4, 4);
imagesc(gridX(1, :), gridY(:, 1), probabilityMap);
colormap(gca, 'hot');
colorbar;
hold on;
plotHighProbabilityAreas(highProbabilityAreas, 'w*', 'MarkerSize', 8);
title('\\textbf{Site Discovery Probability Map}');
xlabel('Easting (m)'); ylabel('Northing (m)');

% Settlement hierarchy analysis
subplot(2, 4, 5);
hierarchyLevels = {'Major Centres', 'Regional Centres', 'Local Centres', 'Villages', 'Hamlets'};
hierarchyCounts = [settlementHierarchy.major, settlementHierarchy.regional, ...
                  settlementHierarchy.local, settlementHierarchy.villages, ...
                  settlementHierarchy.hamlets];
pie(hierarchyCounts, hierarchyLevels);
title('\\textbf{Settlement Hierarchy Distribution}');

% Landscape modification analysis
subplot(2, 4, 6);
modificationTypes = {'Terraces', 'Reservoirs', 'Canals', 'Roads'};
modificationCounts = [numTerraces, numReservoirs, numCanals, length(roadNetworks)];
bar(modificationCounts);
set(gca, 'XTickLabel', modificationTypes, 'XTickLabelRotation', 45);
ylabel('Number of Features');
title('\\textbf{Landscape Modification Features}');
grid on;

% Population density estimation
subplot(2, 4, 7);
populationDensity = estimatePopulationDensity(populationEstimates, settlementCentres, gridX, gridY);
imagesc(gridX(1, :), gridY(:, 1), populationDensity);
colormap(gca, 'copper');
colorbar;
title('\\textbf{Ancient Population Density}');
xlabel('Easting (m)'); ylabel('Northing (m)');

% Discovery summary and impact assessment
subplot(2, 4, 8);
text(0.1, 0.9, '\\textbf{Maya Discovery Summary}', 'Units', 'normalized', 'FontSize', 12, 'FontWeight', 'bold');
text(0.1, 0.82, sprintf('Survey area: 500 km? analysed'), 'Units', 'normalized');
text(0.1, 0.75, sprintf('Cultural features: %d identified', numCulturalFeatures), 'Units', 'normalized');
text(0.1, 0.68, sprintf('Settlements: %d discovered', numSettlements), 'Units', 'normalized');
text(0.1, 0.61, sprintf('Settlement clusters: %d regions', optimalClusters), 'Units', 'normalized');
text(0.1, 0.54, sprintf('Population estimate: %d-%d people', populationEstimates.minimum, populationEstimates.maximum), 'Units', 'normalized');
text(0.1, 0.47, sprintf('Agricultural terraces: %d systems', numTerraces), 'Units', 'normalized');
text(0.1, 0.40, sprintf('Road networks: %.1f km', totalRoadLength/1000), 'Units', 'normalized');
text(0.1, 0.33, sprintf('High-probability areas: %d targets', numHighProbabilityAreas), 'Units', 'normalized');
text(0.1, 0.26, 'Impact: Fundamental revision of Maya demographics', 'Units', 'normalized', 'Color', 'red', 'FontWeight', 'bold');
text(0.1, 0.19, 'Status: Revolutionary archaeological discoveries', 'Units', 'normalized', 'Color', 'green');
axis off;

%% Compile Comprehensive Results
mayaDiscoveries = struct();
mayaDiscoveries.culturalFeatures = culturalFeatures;
mayaDiscoveries.settlements = struct();
mayaDiscoveries.settlements.centres = settlementCentres;
mayaDiscoveries.settlements.clusters = settlementClusters;
mayaDiscoveries.settlements.hierarchy = settlementHierarchy;
mayaDiscoveries.settlements.count = numSettlements;

mayaDiscoveries.featureTypes = struct();
for i = 1:length(featureTypes)
    mayaDiscoveries.featureTypes.(featureTypes{i}) = detectedFeatures.(featureTypes{i});
end

mayaDiscoveries.predictions = struct();
mayaDiscoveries.predictions.probabilityMap = probabilityMap;
mayaDiscoveries.predictions.highProbabilityAreas = highProbabilityAreas;
mayaDiscoveries.predictions.model = sitesProbabilityModel;

landscapeAnalysis = struct();
landscapeAnalysis.terrainModels = struct('DTM', DTM, 'CHM', CHM, 'gridX', gridX, 'gridY', gridY);
landscapeAnalysis.agriculture = agriculturalTerraces;
landscapeAnalysis.waterManagement = waterManagement;
landscapeAnalysis.roadNetworks = roadNetworks;
landscapeAnalysis.populationEstimates = populationEstimates;
landscapeAnalysis.ancientDeforestation = ancientDeforestation;

landscapeAnalysis.groundTruthing = struct();
landscapeAnalysis.groundTruthing.priorities = discoveryPriorities;
landscapeAnalysis.groundTruthing.excavationRecommendations = excavationRecommendations;
landscapeAnalysis.groundTruthing.surveyEffort = surveyEffort;

%% Generate Comprehensive Research Documentation
if nargin > 2 && ~isempty(outputDir)
    % Save complete analysis results
    resultsFile = fullfile(outputDir, 'maya_settlement_discoveries.mat');
    save(resultsFile, 'mayaDiscoveries', 'landscapeAnalysis', '-v7.3');
    
    % Generate archaeological research publication
    researchPaper = fullfile(outputDir, 'maya_lidar_discoveries_paper.pdf');
    generateMayaResearchPaper(mayaDiscoveries, landscapeAnalysis, researchPaper);
    
    % Export GIS database for field teams
    gisDatabase = fullfile(outputDir, 'maya_discoveries_gis.shp');
    exportGISDatabase(mayaDiscoveries, landscapeAnalysis, gisDatabase);
    
    % Create interactive discovery map
    interactiveMap = fullfile(outputDir, 'maya_discoveries_interactive.html');
    createInteractiveDiscoveryMap(mayaDiscoveries, landscapeAnalysis, interactiveMap);
    
    % Generate field survey priorities
    fieldSurveyFile = fullfile(outputDir, 'field_survey_priorities.xlsx');
    exportFieldSurveyPriorities(discoveryPriorities, excavationRecommendations, fieldSurveyFile);
    
    fprintf('Discovery results saved to: %s\\n', resultsFile);
    fprintf('Research paper generated: %s\\n', researchPaper);
    fprintf('GIS database exported: %s\\n', gisDatabase);
    fprintf('Interactive map created: %s\\n', interactiveMap);
    fprintf('Field survey priorities: %s\\n', fieldSurveyFile);
end

fprintf('\\n\\textbf{Maya Settlement Discovery Analysis Complete}\\n');
fprintf('LiDAR archaeological survey: 500 km? of rainforest analysed\\n');
fprintf('Revolutionary discoveries: %d previously unknown settlements\\n', numSettlements);
fprintf('Cultural features identified: %d archaeological structures\\n', numCulturalFeatures);
fprintf('Ancient population estimate: %d - %d inhabitants at peak\\n', ...
    populationEstimates.minimum, populationEstimates.maximum);
fprintf('Ground-truthing targets: %d high-priority areas for excavation\\n', ...
    length(discoveryPriorities));

%% Helper Functions for Maya Settlement Discovery
    function pointCloud = loadLiDARPointCloud(dataPath)
        % Load massive LiDAR point cloud dataset
        pointCloud = struct();
        % Simulate large point cloud - in practice would load .las/.laz files
        numPoints = 10000000; % 10 million points
        pointCloud.Location = rand(numPoints, 3) * 1000; % 1km x 1km area
        pointCloud.Classification = randi([1, 5], numPoints, 1); % Ground, vegetation, etc.
        pointCloud.Intensity = rand(numPoints, 1) * 255;
    end

    function sites = loadKnownMayaSites(sitesPath)
        % Load database of known Maya archaeological sites
        sites = struct();
        sites(1).name = 'Tikal';
        sites(1).coordinates = [585000, 1895000]; % UTM coordinates
        sites(1).type = 'Major Centre';
        sites(2).name = 'El Mirador';
        sites(2).coordinates = [580000, 1900000];
        sites(2).type = 'Major Centre';
        % Would load complete database in practice
    end

    function [DTM, gridX, gridY] = generateDigitalTerrainModel(groundPoints, varargin)
        % Generate high-resolution Digital Terrain Model
        p = inputParser;
        addParameter(p, 'Resolution', 1.0, @isnumeric);
        parse(p, varargin{:});
        
        resolution = p.Results.Resolution;
        
        % Create regular grid
        xMin = min(groundPoints.Location(:, 1));
        xMax = max(groundPoints.Location(:, 1));
        yMin = min(groundPoints.Location(:, 2));
        yMax = max(groundPoints.Location(:, 2));
        
        [gridX, gridY] = meshgrid(xMin:resolution:xMax, yMin:resolution:yMax);
        
        % Interpolate ground elevations to grid
        F = scatteredInterpolant(groundPoints.Location(:, 1), groundPoints.Location(:, 2), ...
            groundPoints.Location(:, 3), 'linear', 'nearest');
        DTM = F(gridX, gridY);
    end

    function features = extractArchitecturalSignatures(knownSites, DTM, gridX, gridY)
        % Extract architectural signatures from known Maya sites
        features = struct();
        features.pyramids = extractPyramidSignatures(knownSites, DTM);
        features.platforms = extractPlatformSignatures(knownSites, DTM);
        features.plazas = extractPlazaSignatures(knownSites, DTM);
        % Additional feature types would be extracted
    end

    function model = trainRandomForestDetector(positiveExamples, negativeExamples)
        % Train Random Forest model for feature detection
        allExamples = [positiveExamples; negativeExamples];
        labels = [ones(size(positiveExamples, 1), 1); zeros(size(negativeExamples, 1), 1)];
        model = TreeBagger(100, allExamples, labels, 'Method', 'classification');
    end

    function [features, confidences] = detectFeaturesInDTM(DTM, slope, curvature, model, featureType)
        % Detect features across DTM using sliding window
        [height, width] = size(DTM);
        windowSize = 50; % 50x50 pixel windows
        features = [];
        confidences = [];
        
        for i = 1:windowSize:height-windowSize
            for j = 1:windowSize:width-windowSize
                window = DTM(i:i+windowSize-1, j:j+windowSize-1);
                windowSlope = slope(i:i+windowSize-1, j:j+windowSize-1);
                windowCurvature = curvature(i:i+windowSize-1, j:j+windowSize-1);
                
                % Extract features for classification
                windowFeatures = extractWindowFeatures(window, windowSlope, windowCurvature);
                
                % Classify window
                [prediction, scores] = predict(model, windowFeatures);
                
                if strcmp(prediction{1}, '1') % Positive detection
                    feature = struct();
                    feature.row = i + windowSize/2;
                    feature.col = j + windowSize/2;
                    feature.type = featureType;
                    features = [features; feature];
                    confidences = [confidences; scores(2)];
                end
            end
        end
    end

    function windowFeatures = extractWindowFeatures(elevation, slope, curvature)
        % Extract features from DTM window for classification
        windowFeatures = [
            mean(elevation(:)), std(elevation(:)), min(elevation(:)), max(elevation(:)), ...
            mean(slope(:)), std(slope(:)), ...
            mean(curvature(:)), std(curvature(:))
        ];
    end

    function generateMayaResearchPaper(discoveries, analysis, filename)
        % Generate comprehensive archaeological research paper
        fprintf('Generating Maya LiDAR discoveries research paper: %s\\n', filename);
    end

    function exportGISDatabase(discoveries, analysis, filename)
        % Export discoveries as GIS shapefile database
        fprintf('Exporting Maya discoveries GIS database: %s\\n', filename);
    end

end
