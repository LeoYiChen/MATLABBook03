%% chapter_AICE_syntax_P02.m
% Proportional feedback correction syntax.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AICE_syntax_P02
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
correctedPrediction    = modelPrediction;
correctedPrediction(1) = modelPrediction(1);
for stepIndex = 2:nSteps
    previousResidual = sensorValue(stepIndex-1) ...
        - correctedPrediction(stepIndex-1);
    correctedPrediction(stepIndex) = ...
        modelPrediction(stepIndex) ...
        + correctionGain * previousResidual;
end
% - Computational Complexity -
% The loop iterates once per aligned time step, giving O(q)
% for q steps. Each iteration performs constant-time arithmetic.
% The feedback correction therefore adds negligible cost to
% the synchronisation step of Problem 1.
