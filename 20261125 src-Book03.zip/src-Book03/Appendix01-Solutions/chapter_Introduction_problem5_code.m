%% chapter_Introduction_problem5_code.m
% Basic machine learning workflow.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_Introduction_problem5_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% MATLABBook03_Chapter01_Problem05.m
% Basic Machine Learning Workflow
% This script demonstrates a complete machine learning workflow
% for classification that can be applied across disciplines

%% 1. Load and examine the dataset
% Load Fisher's iris dataset
load fisheriris
X = meas;      % Features (sepal length, sepal width, petal length, petal width)
species = categorical(species);  % Species names as categorical data
y = double(species);  % Convert to numeric for easier handling

% Display basic information about the dataset
disp('Dataset Information:');
disp(['Number of samples: ' num2str(size(X, 1))]);
disp(['Number of features: ' num2str(size(X, 2))]);
disp(['Number of classes: ' num2str(length(unique(y)))]);
disp(['Class names: ' char(join(string(categories(species)), ', '))]);

% Display first few samples
disp('First 5 samples:');
disp([array2table(X(1:5,:), 'VariableNames', {'SepalLength', 'SepalWidth', 'PetalLength', 'PetalWidth'}), table(species(1:5))]);

%% 2. Exploratory Data Analysis
% Basic statistics
disp('Basic Statistics:');
stats = array2table([mean(X); std(X); min(X); max(X)], ...
                  'RowNames', {'Mean', 'Std', 'Min', 'Max'}, ...
                  'VariableNames', {'SepalLength', 'SepalWidth', 'PetalLength', 'PetalWidth'});
disp(stats);

% Sample distribution by class
class_counts = histcounts(y, 'BinMethod', 'integers');
disp('Class distribution:');
disp(table(categories(species)', class_counts', 'VariableNames', {'Species', 'Count'}));

% Visualize the data
figure('Name', 'Exploratory Data Analysis', 'Position', [100, 100, 1200, 800]);

% Scatter plots of pairs of features
subplot(2, 3, 1);
gscatter(X(:,1), X(:,2), species, 'rgb', 'o*+');
xlabel('Sepal Length (cm)');
ylabel('Sepal Width (cm)');
title('Sepal Length vs. Sepal Width');
grid on;

subplot(2, 3, 2);
gscatter(X(:,3), X(:,4), species, 'rgb', 'o*+');
xlabel('Petal Length (cm)');
ylabel('Petal Width (cm)');
title('Petal Length vs. Petal Width');
grid on;

subplot(2, 3, 3);
gscatter(X(:,1), X(:,3), species, 'rgb', 'o*+');
xlabel('Sepal Length (cm)');
ylabel('Petal Length (cm)');
title('Sepal Length vs. Petal Length');
grid on;

% Box plots by feature and class
subplot(2, 3, 4);
boxplot(X(:,1), species, 'Colors', 'rgb');
ylabel('Sepal Length (cm)');
title('Sepal Length by Species');
grid on;

subplot(2, 3, 5);
boxplot(X(:,3), species, 'Colors', 'rgb');
ylabel('Petal Length (cm)');
title('Petal Length by Species');
grid on;

subplot(2, 3, 6);
boxplot(X(:,4), species, 'Colors', 'rgb');
ylabel('Petal Width (cm)');
title('Petal Width by Species');
grid on;

%% 3. Feature Analysis and Selection
% Calculate correlation matrix
corr_matrix = corr(X);
disp('Feature Correlation Matrix:');
disp(array2table(corr_matrix, 'RowNames', {'SepalLength', 'SepalWidth', 'PetalLength', 'PetalWidth'}, ...
                         'VariableNames', {'SepalLength', 'SepalWidth', 'PetalLength', 'PetalWidth'}));

% Visualize correlation matrix
figure('Name', 'Feature Analysis', 'Position', [150, 150, 1000, 800]);

subplot(2, 2, 1);
imagesc(corr_matrix);
colormap('jet');
colorbar;
title('Feature Correlation Matrix');
axis square;
xticks(1:4);
yticks(1:4);
xticklabels({'SepalLength', 'SepalWidth', 'PetalLength', 'PetalWidth'});
yticklabels({'SepalLength', 'SepalWidth', 'PetalLength', 'PetalWidth'});
textStrings = num2str(corr_matrix(:), '%0.2f');
textStrings = strtrim(cellstr(textStrings));
[x, y] = meshgrid(1:4);
hStrings = text(x(:), y(:), textStrings(:), 'HorizontalAlignment', 'center');
rotateXLabels(gca, 45);  % Assuming this function exists or using built-in rotation

% Principal Component Analysis
[coeff, score, ~, ~, explained] = pca(X);
disp('PCA: Proportion of Variance Explained:');
disp(table((1:4)', explained, cumsum(explained), 'VariableNames', {'PC', 'VarianceExplained', 'CumulativeVariance'}));

% Plot PCA results
subplot(2, 2, 2);
gscatter(score(:,1), score(:,2), species, 'rgb', 'o*+');
xlabel('First Principal Component');
ylabel('Second Principal Component');
title('PCA: First Two Principal Components');
grid on;

% Feature importance using simple ANOVA F-statistic
pValues = zeros(1, size(X, 2));
fStats = zeros(1, size(X, 2));
for i = 1:size(X, 2)
    [p, tbl] = anova1(X(:,i), species, 'off');
    pValues(i) = p;
    fStats(i) = tbl{2,5};  % F-statistic
end

subplot(2, 2, 3);
bar(fStats);
title('Feature Importance (F-statistic)');
xlabel('Feature');
xticklabels({'SepalLength', 'SepalWidth', 'PetalLength', 'PetalWidth'});
ylabel('F-statistic');
xtickangle(45);
grid on;

% Select the two most important features for visualisation
[~, sortIdx] = sort(fStats, 'descend');
selectedFeatures = sortIdx(1:2);
disp(['Selected features for visualisation: ' ...
     join(string({'SepalLength', 'SepalWidth', 'PetalLength', 'PetalWidth'}(selectedFeatures)), ' and ')]);

%% 4. Data Preprocessing
% Check for missing values
missing_count = sum(ismissing(X));
if any(missing_count)
    disp('Missing values detected:');
    disp(table({'SepalLength', 'SepalWidth', 'PetalLength', 'PetalWidth'}', missing_count', ...
             'VariableNames', {'Feature', 'MissingCount'}));
else
    disp('No missing values detected.');
end

% Normalize the data
X_norm = normalize(X);

% Split data into training and test sets
rng(42); % For reproducibility
cv = cvpartition(y, 'HoldOut', 0.2);
X_train = X(cv.training,:);
y_train = y(cv.training);
X_test = X(cv.test,:);
y_test = y(cv.test);
species_train = species(cv.training);
species_test = species(cv.test);

% Normalize using training set statistics
[X_train_norm, mu, sigma] = zscore(X_train);
X_test_norm = (X_test - mu) ./ sigma;

disp('Data split:');
disp(['Training set: ' num2str(size(X_train, 1)) ' samples']);
disp(['Test set: ' num2str(size(X_test, 1)) ' samples']);

%% 5. Model Training
% Train a k-NN classifier
k = 5; % Number of neighbors
mdl_knn = fitcknn(X_train, species_train, 'NumNeighbors', k, 'Standardize', true);

% Train alternative models for comparison
mdl_tree = fitctree(X_train, species_train);
mdl_svm = fitcecoc(X_train, species_train);

% Display model information
disp('k-NN model information:');
disp(mdl_knn);

%% 6. Model Evaluation
% Make predictions on test set
pred_knn = predict(mdl_knn, X_test);
pred_tree = predict(mdl_tree, X_test);
pred_svm = predict(mdl_svm, X_test);

% Calculate accuracy
accuracy_knn = sum(pred_knn == species_test) / length(species_test);
accuracy_tree = sum(pred_tree == species_test) / length(species_test);
accuracy_svm = sum(pred_svm == species_test) / length(species_test);

disp('Model Accuracies:');
disp(['k-NN (k=' num2str(k) '): ' num2str(accuracy_knn*100, '%.2f') '%']);
disp(['Decision Tree: ' num2str(accuracy_tree*100, '%.2f') '%']);
disp(['SVM: ' num2str(accuracy_svm*100, '%.2f') '%']);

% Confusion matrix for k-NN
cm_knn = confusionmat(species_test, pred_knn);
disp('Confusion Matrix (k-NN):');
cm_table = array2table(cm_knn, ...
                     'RowNames', categories(species), ...
                     'VariableNames', categories(species));
disp(cm_table);

% Calculate additional metrics
precision = diag(cm_knn) ./ sum(cm_knn, 1)';
recall = diag(cm_knn) ./ sum(cm_knn, 2);
f1_score = 2 * (precision .* recall) ./ (precision + recall);

disp('Performance Metrics by Class:');
metrics_table = table(categories(species), precision, recall, f1_score, ...
                    'VariableNames', {'Class', 'Precision', 'Recall', 'F1Score'});
disp(metrics_table);

% Visualize confusion matrix
figure('Name', 'Model Evaluation', 'Position', [200, 200, 1000, 800]);

subplot(2, 2, 1);
confusionchart(cm_knn, categories(species));
title('Confusion Matrix (k-NN)');

% Plot ROC curve for one-vs-all classifiers (for multiclass)
subplot(2, 2, 2);
[~, score_knn] = predict(mdl_knn, X_test);

% For each class, calculate ROC curve
hold on;
colors = 'rgb';
AUC = zeros(1, 3);

for i = 1:3
    % Convert to binary classification problem (one-vs-all)
    isCurrent = double(species_test == categories(species)(i));
    
    % Get scores for current class
    class_scores = score_knn(:, i);
    
    % Calculate ROC curve
    [x, y, ~, auc] = perfcurve(isCurrent, class_scores, 1);
    
    % Plot ROC curve
    plot(x, y, [colors(i) '-'], 'LineWidth', 2);
    
    AUC(i) = auc;
end

plot([0, 1], [0, 1], 'k--');
xlabel('False Positive Rate');
ylabel('True Positive Rate');
title('ROC Curves (One-vs-All)');
legend([categories(species), 'Random'], 'Location', 'southeast');
axis square;
grid on;

disp('Area Under ROC Curve by Class:');
disp(table(categories(species)', AUC', 'VariableNames', {'Class', 'AUC'}));

% Compare models
subplot(2, 2, 3);
bar([accuracy_knn, accuracy_tree, accuracy_svm]);
title('Model Accuracy Comparison');
xlabel('Model');
xticklabels({'k-NN', 'Decision Tree', 'SVM'});
ylabel('Accuracy');
ylim([0, 1]);
xtickangle(0);
grid on;

%% 7. Decision Boundary visualisation
% Create a mesh grid to visualize the decision boundary using the two most important features
figure('Name', 'Decision Boundaries', 'Position', [250, 250, 1000, 800]);

% Plot decision boundaries on normalized data
feature1 = selectedFeatures(1);
feature2 = selectedFeatures(2);
feature_names = {'Sepal Length', 'Sepal Width', 'Petal Length', 'Petal Width'};

% For each model
models = {mdl_knn, mdl_tree, mdl_svm};
model_names = {'k-NN', 'Decision Tree', 'SVM'};

for m = 1:length(models)
    subplot(2, 2, m);
    
    % Create a grid for visualisation
    [X1, X2] = meshgrid(linspace(min(X(:,feature1))-0.5, max(X(:,feature1))+0.5, 100), ...
                       linspace(min(X(:,feature2))-0.5, max(X(:,feature2))+0.5, 100));
    
    % Prepare grid points for prediction
    grid_points = zeros(size(X1(:), 1), size(X, 2));
    grid_points(:, feature1) = X1(:);
    grid_points(:, feature2) = X2(:);
    
    % For visualisation simplicity, set other features to their means
    for i = 1:size(X, 2)
        if i ~= feature1 && i ~= feature2
            grid_points(:, i) = mean(X(:, i));
        end
    end
    
    % Predict classes for grid points
    grid_pred = predict(models{m}, grid_points);
    
    % Reshape predictions for contour plot
    grid_pred_numeric = double(grid_pred);
    Z = reshape(grid_pred_numeric, size(X1));
    
    % Plot decision boundaries
    contourf(X1, X2, Z, 'LineStyle', 'none');
    colormap(gca, parula(3));
    hold on;
    
    % Plot training data points
    gscatter(X(:,feature1), X(:,feature2), species, 'rgb', 'o*+', 5);
    
    xlabel([feature_names{feature1} ' (cm)']);
    ylabel([feature_names{feature2} ' (cm)']);
    title(['Decision Boundaries: ' model_names{m}]);
    grid on;
end

% Additional subplot to show feature space with PCA
subplot(2, 2, 4);
biplot(coeff(:,1:2), 'scores', score(:,1:2), 'varlabels', {...
    'Sepal Length', 'Sepal Width', 'Petal Length', 'Petal Width'});
hold on;
gscatter(score(:,1), score(:,2), species, 'rgb', 'o*+', 5);
title('PCA Feature Space');
grid on;

%% 8. Model Optimization (k-value selection for k-NN)
figure('Name', 'Model Optimization', 'Position', [300, 300, 800, 600]);

% Try different k values and evaluate using cross-validation
k_values = 1:2:15;
cv_accuracy = zeros(size(k_values));

for i = 1:length(k_values)
    % 5-fold cross-validation
    cv_partition = cvpartition(y_train, 'KFold', 5);
    cv_accuracy_folds = zeros(cv_partition.NumTestSets, 1);
    
    for fold = 1:cv_partition.NumTestSets
        % Get training and validation indices for this fold
        train_idx = cv_partition.training(fold);
        test_idx = cv_partition.test(fold);
        
        % Train k-NN model
        fold_mdl = fitcknn(X_train(train_idx,:), species_train(train_idx), ...
                         'NumNeighbors', k_values(i), 'Standardize', true);
        
        % Predict on validation set
        fold_pred = predict(fold_mdl, X_train(test_idx,:));
        
        % Calculate accuracy
        cv_accuracy_folds(fold) = sum(fold_pred == species_train(test_idx)) / length(fold_pred);
    end
    
    % Average accuracy across folds
    cv_accuracy(i) = mean(cv_accuracy_folds);
end

% Plot cross-validation results
plot(k_values, cv_accuracy, 'bo-', 'LineWidth', 1.5);
xlabel('Number of Neighbors (k)');
ylabel('Cross-Validation Accuracy');
title('k-NN Model Optimization');
grid on;

% Find optimal k
[best_accuracy, best_idx] = max(cv_accuracy);
best_k = k_values(best_idx);
hold on;
plot(best_k, best_accuracy, 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
legend('CV Accuracy', 'Optimal k', 'Location', 'best');

disp(['Optimal number of neighbors (k): ' num2str(best_k)]);
disp(['Cross-validation accuracy with optimal k: ' num2str(best_accuracy*100, '%.2f') '%']);

%% 9. Final Model and Test Set Evaluation
% Train final model with optimal k
final_mdl = fitcknn(X_train, species_train, 'NumNeighbors', best_k, 'Standardize', true);
final_pred = predict(final_mdl, X_test);
final_accuracy = sum(final_pred == species_test) / length(species_test);

disp('Final Model Evaluation:');
disp(['Test set accuracy with optimal k=' num2str(best_k) ': ' num2str(final_accuracy*100, '%.2f') '%']);

% Final confusion matrix
cm_final = confusionmat(species_test, final_pred);
disp('Final Confusion Matrix:');
cm_final_table = array2table(cm_final, ...
                          'RowNames', categories(species), ...
                          'VariableNames', categories(species));
disp(cm_final_table);

%% 10. Multidisciplinary Applications Discussion
figure('Name', 'Multidisciplinary Applications', 'Position', [350, 350, 1200, 800]);

% Create a figure showing how the same classification workflow applies across disciplines
annotation('textbox', [0.1, 0.9, 0.8, 0.08], ...
           'String', 'Machine Learning Classification Workflow: Applications Across Disciplines', ...
           'EdgeColor', 'none', ...
           'HorizontalAlignment', 'center', ...
           'FontSize', 16, ...
           'FontWeight', 'bold');

% Engineering application
annotation('textbox', [0.05, 0.75, 0.28, 0.12], ...
           'String', {'Engineering Application:', ...
                    '- Fault detection in machinery', ...
                    '- Classification of material properties', ...
                    '- Quality control in manufacturing', ...
                    '- Sensor data interpretation'}, ...
           'EdgeColor', 'k');

% Medical application
annotation('textbox', [0.36, 0.75, 0.28, 0.12], ...
           'String', {'Medical Application:', ...
                    '- Disease diagnosis from symptoms', ...
                    '- Medical image classification', ...
                    '- Patient risk stratification', ...
                    '- Treatment response prediction'}, ...
           'EdgeColor', 'k');

% Social sciences application
annotation('textbox', [0.67, 0.75, 0.28, 0.12], ...
           'String', {'Social Sciences Application:', ...
                    '- Consumer behavior classification', ...
                    '- Text sentiment analysis', ...
                    '- Social network categorization', ...
                    '- Survey response clustering'}, ...
           'EdgeColor', 'k');

% Common workflow steps
workflow_steps = {
    'Data Collection', 
    'Exploratory Analysis', 
    'Feature Selection', 
    'Data Preprocessing', 
    'Model Training', 
    'Validation', 
    'Decision Boundary visualisation', 
    'Model Optimization', 
    'Final Evaluation'
};

for i = 1:length(workflow_steps)
    annotation('textbox', [0.1, 0.65-i*0.06, 0.8, 0.05], ...
               'String', [num2str(i) '. ' workflow_steps{i}], ...
               'EdgeColor', 'none', ...
               'BackgroundColor', [0.9, 0.9, 0.9], ...
               'HorizontalAlignment', 'center');
end

% Final annotation explaining transferability
annotation('textbox', [0.1, 0.05, 0.8, 0.1], ...
           'String', {'The power of machine learning workflows lies in their transferability across disciplines.', ...
                    'While the underlying algorithms remain the same, the features, interpretation, and application context differ.', ...
                    'MATLAB provides a consistent environment to implement these workflows regardless of the domain.'}, ...
           'EdgeColor', 'none', ...
           'HorizontalAlignment', 'center', ...
           'FontStyle', 'italic');
