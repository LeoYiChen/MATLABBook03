%% chapter_AICSS_problem9_transfer_learning.m
% Cross-domain transfer learning framework for security-safety applications.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AICSS_problem9_transfer_learning
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function transferResults = implementCrossDomainTransferLearning(sourceModel, sourceDomain, targetDomain, transferConfiguration)
    % Cross-domain transfer learning framework for security-safety applications
    % Author: Dr Leo Chen
    % Version: 1.0 - Initial implementation
    % Date: December 2024
    
    fprintf('Implementing cross-domain transfer learning framework...\n');
    fprintf('Source Domain: %s, Target Domain: %s\n', sourceDomain.name, targetDomain.name);
    
    % Initialize results structure
    transferResults = struct();
    transferResults.timestamp = datetime('now');
    transferResults.sourceDomain = sourceDomain;
    transferResults.targetDomain = targetDomain;
    transferResults.transferConfiguration = transferConfiguration;
    
    % Analyse domain characteristics and compatibility
    domainAnalysis = analyseDomainCompatibility(sourceDomain, targetDomain);
    transferResults.domainAnalysis = domainAnalysis;
    
    fprintf('Domain compatibility score: %.3f\n', domainAnalysis.compatibilityScore);
    
    % Implement transfer learning strategy
    transferStrategy = transferConfiguration.strategy;
    
    switch transferStrategy
        case 'FeatureTransfer'
            transferredModel = implementFeatureTransfer(sourceModel, sourceDomain, targetDomain, transferConfiguration);
            
        case 'ModelFineTuning'
            transferredModel = implementModelFineTuning(sourceModel, sourceDomain, targetDomain, transferConfiguration);
            
        case 'DomainAdaptation'
            transferredModel = implementDomainAdaptation(sourceModel, sourceDomain, targetDomain, transferConfiguration);
            
        case 'KnowledgeDistillation'
            transferredModel = implementKnowledgeDistillation(sourceModel, sourceDomain, targetDomain, transferConfiguration);
            
        case 'MultiTaskLearning'
            transferredModel = implementMultiTaskLearning(sourceModel, sourceDomain, targetDomain, transferConfiguration);
            
        otherwise
            error('Unknown transfer learning strategy: %s', transferStrategy);
    end
    
    transferResults.transferredModel = transferredModel;
    
    % Evaluate transfer learning performance
    transferPerformance = evaluateTransferPerformance(sourceModel, transferredModel, targetDomain, transferConfiguration);
    transferResults.transferPerformance = transferPerformance;
    
    % Assess knowledge transfer effectiveness
    knowledgeTransferAnalysis = assessKnowledgeTransfer(sourceModel, transferredModel, sourceDomain, targetDomain);
    transferResults.knowledgeTransferAnalysis = knowledgeTransferAnalysis;
    
    % Validate transferred model for safety-critical applications
    if strcmp(targetDomain.criticality, 'safety_critical')
        safetyValidation = validateForSafetyCriticalApplications(transferredModel, targetDomain, transferConfiguration);
        transferResults.safetyValidation = safetyValidation;
    end
    
    % Analyse negative transfer and catastrophic forgetting
    negativeTransferAnalysis = analyseNegativeTransfer(sourceModel, transferredModel, sourceDomain, targetDomain);
    transferResults.negativeTransferAnalysis = negativeTransferAnalysis;
    
    % Generate transfer learning visualisation
    generateTransferLearningvisualisation(transferResults);
    
    % Create transfer learning report
    transferReport = generateTransferLearningReport(transferResults);
    transferResults.transferReport = transferReport;
    
    % Save transfer learning results
    saveTransferLearningResults(transferResults);
    
    fprintf('Cross-domain transfer learning implementation completed.\n');
end

function domainAnalysis = analyseDomainCompatibility(sourceDomain, targetDomain)
    % Analyse compatibility between source and target domains
    
    domainAnalysis = struct();
    
    % Feature space compatibility analysis
    sourceFeatures = sourceDomain.featureSpace;
    targetFeatures = targetDomain.featureSpace;
    
    % Calculate feature overlap
    commonFeatures = intersect(sourceFeatures.featureNames, targetFeatures.featureNames);
    featureOverlap = length(commonFeatures) / max(length(sourceFeatures.featureNames), length(targetFeatures.featureNames));
    
    domainAnalysis.featureOverlap = featureOverlap;
    domainAnalysis.commonFeatures = commonFeatures;
    
    % Data distribution similarity analysis
    distributionSimilarity = calculateDistributionSimilarity(sourceDomain.dataStatistics, targetDomain.dataStatistics);
    domainAnalysis.distributionSimilarity = distributionSimilarity;
    
    % Task similarity analysis
    taskSimilarity = calculateTaskSimilarity(sourceDomain.taskDefinition, targetDomain.taskDefinition);
    domainAnalysis.taskSimilarity = taskSimilarity;
    
    % Domain shift assessment
    domainShift = assessDomainShift(sourceDomain, targetDomain);
    domainAnalysis.domainShift = domainShift;
    
    % Overall compatibility score
    compatibilityWeights = [0.3, 0.25, 0.25, 0.2]; % Feature, Distribution, Task, Domain shift
    compatibilityComponents = [featureOverlap, distributionSimilarity, taskSimilarity, 1-domainShift.magnitude];
    domainAnalysis.compatibilityScore = sum(compatibilityWeights .* compatibilityComponents);
    
    % Transferability assessment
    if domainAnalysis.compatibilityScore > 0.7
        domainAnalysis.transferability = 'High';
    elseif domainAnalysis.compatibilityScore > 0.4
        domainAnalysis.transferability = 'Moderate';
    else
        domainAnalysis.transferability = 'Low';
    end
end

function transferredModel = implementFeatureTransfer(sourceModel, sourceDomain, targetDomain, config)
    % Implement feature-based transfer learning
    
    fprintf('Implementing feature transfer...\n');
    
    % Extract feature representations from source model
    sourceFeatures = extractSourceFeatures(sourceModel, sourceDomain.data.inputs);
    
    % Map source features to target domain feature space
    featureMapping = createFeatureMapping(sourceDomain.featureSpace, targetDomain.featureSpace);
    mappedFeatures = applyFeatureMapping(sourceFeatures, featureMapping);
    
    % Train new classifier on mapped features
    targetLabels = targetDomain.data.labels;
    
    % Split target domain data
    trainRatio = 0.8;
    numSamples = size(mappedFeatures, 1);
    trainIndices = randperm(numSamples, round(trainRatio * numSamples));
    testIndices = setdiff(1:numSamples, trainIndices);
    
    trainFeatures = mappedFeatures(trainIndices, :);
    trainLabels = targetLabels(trainIndices);
    testFeatures = mappedFeatures(testIndices, :);
    testLabels = targetLabels(testIndices);
    
    % Train target domain classifier
    if config.classifierType == "SVM"
        targetClassifier = fitcsvm(trainFeatures, trainLabels);
    elseif config.classifierType == "RandomForest"
        targetClassifier = TreeBagger(config.numTrees, trainFeatures, trainLabels);
    else
        targetClassifier = fitcnet(trainFeatures, trainLabels);
    end
    
    % Create transferred model structure
    transferredModel = struct();
    transferredModel.featureExtractor = sourceModel.featureExtractor;
    transferredModel.featureMapping = featureMapping;
    transferredModel.targetClassifier = targetClassifier;
    transferredModel.transferType = 'FeatureTransfer';
    
    % Evaluate on test set
    testPredictions = predict(targetClassifier, testFeatures);
    transferredModel.testAccuracy = sum(testPredictions == testLabels) / length(testLabels);
    
    fprintf('Feature transfer completed. Test accuracy: %.3f\n', transferredModel.testAccuracy);
end

function transferredModel = implementDomainAdaptation(sourceModel, sourceDomain, targetDomain, config)
    % Implement domain adaptation using Maximum Mean Discrepancy (MMD)
    
    fprintf('Implementing domain adaptation...\n');
    
    % Extract features from both domains
    sourceFeatures = extractSourceFeatures(sourceModel, sourceDomain.data.inputs);
    targetInputs = targetDomain.data.inputs;
    
    % Initialize target feature extractor as copy of source
    adaptedFeatureExtractor = sourceModel.featureExtractor;
    
    % Domain adaptation using iterative approach
    numIterations = config.adaptationIterations;
    adaptationRate = config.adaptationRate;
    
    for iteration = 1:numIterations
        % Extract features using current feature extractor
        adaptedTargetFeatures = extractFeatures(adaptedFeatureExtractor, targetInputs);
        
        % Calculate MMD between source and target features
        mmdLoss = calculateMMD(sourceFeatures, adaptedTargetFeatures);
        
        % Update feature extractor to minimize domain discrepancy
        adaptedFeatureExtractor = updateFeatureExtractor(adaptedFeatureExtractor, mmdLoss, adaptationRate);
        
        fprintf('Iteration %d: MMD Loss = %.6f\n', iteration, mmdLoss);
    end
    
    % Train classifier on adapted features
    adaptedTargetFeatures = extractFeatures(adaptedFeatureExtractor, targetInputs);
    targetLabels = targetDomain.data.labels;
    
    % Split data for training and testing
    trainRatio = 0.8;
    numSamples = size(adaptedTargetFeatures, 1);
    trainIndices = randperm(numSamples, round(trainRatio * numSamples));
    testIndices = setdiff(1:numSamples, trainIndices);
    
    trainFeatures = adaptedTargetFeatures(trainIndices, :);
    trainLabels = targetLabels(trainIndices);
    testFeatures = adaptedTargetFeatures(testIndices, :);
    testLabels = targetLabels(testIndices);
    
    % Train adapted classifier
    adaptedClassifier = fitcnet(trainFeatures, trainLabels);
    
    % Create transferred model
    transferredModel = struct();
    transferredModel.adaptedFeatureExtractor = adaptedFeatureExtractor;
    transferredModel.adaptedClassifier = adaptedClassifier;
    transferredModel.transferType = 'DomainAdaptation';
    transferredModel.finalMMD = mmdLoss;
    
    % Evaluate performance
    testPredictions = predict(adaptedClassifier, testFeatures);
    transferredModel.testAccuracy = sum(testPredictions == testLabels) / length(testLabels);
    
    fprintf('Domain adaptation completed. Test accuracy: %.3f\n', transferredModel.testAccuracy);
end

function mmdLoss = calculateMMD(sourceFeatures, targetFeatures)
    % Calculate Maximum Mean Discrepancy between source and target features
    
    % Use RBF kernel with median heuristic for bandwidth
    allFeatures = [sourceFeatures; targetFeatures];
    distances = pdist(allFeatures);
    bandwidth = median(distances);
    
    % Calculate kernel matrices
    sourceKernel = calculateRBFKernel(sourceFeatures, sourceFeatures, bandwidth);
    targetKernel = calculateRBFKernel(targetFeatures, targetFeatures, bandwidth);
    crossKernel = calculateRBFKernel(sourceFeatures, targetFeatures, bandwidth);
    
    % MMD calculation
    numSourceSamples = size(sourceFeatures, 1);
    numTargetSamples = size(targetFeatures, 1);
    
    mmdLoss = (1/numSourceSamples^2) * sum(sourceKernel(:)) + ...
              (1/numTargetSamples^2) * sum(targetKernel(:)) - ...
              (2/(numSourceSamples * numTargetSamples)) * sum(crossKernel(:));
end

function kernelMatrix = calculateRBFKernel(X, Y, bandwidth)
    % Calculate RBF kernel matrix between X and Y
    
    numX = size(X, 1);
    numY = size(Y, 1);
    kernelMatrix = zeros(numX, numY);
    
    for i = 1:numX
        for j = 1:numY
            squaredDistance = sum((X(i, :) - Y(j, :)).^2);
            kernelMatrix(i, j) = exp(-squaredDistance / (2 * bandwidth^2));
        end
    end
end

function generateTransferLearningvisualisation(transferResults)
    % Generate comprehensive transfer learning visualisation
    
    figure('Position', [100, 100, 1800, 1200]);
    
    % Domain compatibility analysis
    subplot(3, 4, 1);
    domainAnalysis = transferResults.domainAnalysis;
    compatibilityComponents = [domainAnalysis.featureOverlap, domainAnalysis.distributionSimilarity, ...
                              domainAnalysis.taskSimilarity, 1-domainAnalysis.domainShift.magnitude];
    componentLabels = {'Feature Overlap', 'Distribution Sim.', 'Task Similarity', 'Domain Alignment'};
    
    bar(compatibilityComponents, 'FaceColor', [0.3, 0.6, 0.9], 'EdgeColor', 'darkblue');
    set(gca, 'XTickLabel', componentLabels);
    ylabel('Compatibility Score', 'FontSize', 12);
    title('Domain Compatibility Analysis', 'FontSize', 14, 'FontWeight', 'bold');
    xtickangle(45);
    ylim([0, 1]);
    grid on;
    
    % Transfer performance comparison
    subplot(3, 4, 2);
    if isfield(transferResults, 'transferPerformance')
        performanceData = transferResults.transferPerformance;
        performanceMetrics = {'Source Baseline', 'Target Baseline', 'Transferred Model', 'Upper Bound'};
        performanceValues = [performanceData.sourcePerformance, performanceData.targetBaseline, ...
                           performanceData.transferredPerformance, performanceData.upperBound];
        
        bar(performanceValues, 'FaceColor', [0.6, 0.8, 0.4], 'EdgeColor', 'darkgreen');
        set(gca, 'XTickLabel', performanceMetrics);
        ylabel('Performance Score', 'FontSize', 12);
        title('Transfer Performance Comparison', 'FontSize', 12, 'FontWeight', 'bold');
        xtickangle(45);
        ylim([0, 1]);
        grid on;
    end
    
    % Knowledge transfer effectiveness
    subplot(3, 4, 3);
    if isfield(transferResults, 'knowledgeTransferAnalysis')
        knowledgeData = transferResults.knowledgeTransferAnalysis;
        knowledgeMetrics = {'Positive Transfer', 'Negative Transfer', 'Knowledge Retention'};
        knowledgeValues = [knowledgeData.positiveTransfer, knowledgeData.negativeTransfer, knowledgeData.knowledgeRetention];
        
        barColours = [0.2, 0.8, 0.2; 0.8, 0.2, 0.2; 0.2, 0.2, 0.8];
        bar(knowledgeValues, 'FaceColor', 'flat', 'CData', barColours, 'EdgeColor', 'black');
        set(gca, 'XTickLabel', knowledgeMetrics);
        ylabel('Transfer Score', 'FontSize', 12);
        title('Knowledge Transfer Analysis', 'FontSize', 12, 'FontWeight', 'bold');
        xtickangle(45);
        ylim([0, 1]);
        grid on;
    end
    
    % Domain shift visualisation
    subplot(3, 4, 4);
    if isfield(domainAnalysis, 'domainShift')
        domainShiftData = domainAnalysis.domainShift;
        shiftComponents = [domainShiftData.featureShift, domainShiftData.labelShift, domainShiftData.conceptShift];
        shiftLabels = {'Feature Shift', 'Label Shift', 'Concept Shift'};
        
        pie(shiftComponents, shiftLabels);
        title('Domain Shift Composition', 'FontSize', 12, 'FontWeight', 'bold');
    end
    
    % Feature mapping visualisation
    subplot(3, 4, 5);
    if isfield(transferResults.transferredModel, 'featureMapping')
        % Create synthetic feature importance data for visualisation
        numFeatures = 20;
        sourceImportance = rand(numFeatures, 1);
        targetImportance = 0.7 * sourceImportance + 0.3 * rand(numFeatures, 1);
        
        scatter(sourceImportance, targetImportance, 100, 'filled', 'alpha', 0.7);
        hold on;
        plot([0, 1], [0, 1], 'r--', 'LineWidth', 2);
        xlabel('Source Feature Importance', 'FontSize', 12);
        ylabel('Target Feature Importance', 'FontSize', 12);
        title('Feature Importance Transfer', 'FontSize', 12, 'FontWeight', 'bold');
        grid on;
    end
    
    % Learning curves comparison
    subplot(3, 4, 6);
    % Generate synthetic learning curves
    epochs = 1:50;
    sourceOnly = 0.5 + 0.4 * (1 - exp(-epochs/10)) + 0.02 * randn(size(epochs));
    transferred = 0.7 + 0.25 * (1 - exp(-epochs/5)) + 0.015 * randn(size(epochs));
    fromScratch = 0.3 + 0.6 * (1 - exp(-epochs/15)) + 0.025 * randn(size(epochs));
    
    plot(epochs, sourceOnly, 'r-', 'LineWidth', 2, 'DisplayName', 'Source Only');
    hold on;
    plot(epochs, transferred, 'b-', 'LineWidth', 2, 'DisplayName', 'Transferred');
    plot(epochs, fromScratch, 'g-', 'LineWidth', 2, 'DisplayName', 'From Scratch');
    
    xlabel('Training Epochs', 'FontSize', 12);
    ylabel('Performance', 'FontSize', 12);
    title('Learning Curves Comparison', 'FontSize', 12, 'FontWeight', 'bold');
    legend('show', 'Location', 'southeast');
    grid on;
    
    % Safety validation results (if applicable)
    subplot(3, 4, 7);
    if isfield(transferResults, 'safetyValidation')
        safetyData = transferResults.safetyValidation;
        safetyMetrics = fieldnames(safetyData);
        safetyScores = zeros(length(safetyMetrics), 1);
        
        for metricIndex = 1:length(safetyMetrics)
            if isnumeric(safetyData.(safetyMetrics{metricIndex}))
                safetyScores(metricIndex) = safetyData.(safetyMetrics{metricIndex});
            else
                safetyScores(metricIndex) = 0.8; % Default value
            end
        end
        
        bar(safetyScores, 'FaceColor', [0.8, 0.6, 0.8], 'EdgeColor', 'darkmagenta');
        set(gca, 'XTickLabel', safetyMetrics);
        ylabel('Safety Score', 'FontSize', 12);
        title('Safety Validation Results', 'FontSize', 12, 'FontWeight', 'bold');
        xtickangle(45);
        ylim([0, 1]);
        grid on;
    end
    
    % Negative transfer analysis
    subplot(3, 4, 8);
    if isfield(transferResults, 'negativeTransferAnalysis')
        negativeData = transferResults.negativeTransferAnalysis;
        % Create visualisation of negative transfer over time
        timePoints = 1:20;
        negativeTransferCurve = negativeData.negativeTransferMagnitude * exp(-timePoints/5) + 0.05 * randn(size(timePoints));
        
        plot(timePoints, negativeTransferCurve, 'r-', 'LineWidth', 2);
        xlabel('Adaptation Steps', 'FontSize', 12);
        ylabel('Negative Transfer Magnitude', 'FontSize', 12);
        title('Negative Transfer Mitigation', 'FontSize', 12, 'FontWeight', 'bold');
        grid on;
    end
    
    % Transfer strategy effectiveness
    subplot(3, 4, 9);
    transferStrategies = {'Feature Transfer', 'Fine-tuning', 'Domain Adaptation', 'Knowledge Distillation'};
    strategyEffectiveness = [0.75, 0.82, 0.88, 0.79]; % Example values
    
    bar(strategyEffectiveness, 'FaceColor', [0.9, 0.7, 0.5], 'EdgeColor', 'darkorange');
    set(gca, 'XTickLabel', transferStrategies);
    ylabel('Effectiveness Score', 'FontSize', 12);
    title('Transfer Strategy Comparison', 'FontSize', 12, 'FontWeight', 'bold');
    xtickangle(45);
    ylim([0, 1]);
    grid on;
    
    % Cross-domain performance matrix
    subplot(3, 4, 10);
    % Create synthetic cross-domain performance matrix
    domainNames = {'Cybersecurity', 'Safety Systems', 'Anomaly Detection', 'Fault Diagnosis'};
    performanceMatrix = [0.85, 0.72, 0.78, 0.69; 0.68, 0.91, 0.75, 0.82; 0.81, 0.74, 0.89, 0.76; 0.71, 0.84, 0.77, 0.88];
    
    imagesc(performanceMatrix);
    colorbar;
    colormap('hot');
    set(gca, 'XTickLabel', domainNames);
    set(gca, 'YTickLabel', domainNames);
    xlabel('Target Domain', 'FontSize', 12);
    ylabel('Source Domain', 'FontSize', 12);
    title('Cross-Domain Performance Matrix', 'FontSize', 12, 'FontWeight', 'bold');
    xtickangle(45);
    
    % Transfer learning timeline
    subplot(3, 4, 11);
    transferStages = {'Pre-training', 'Feature Extraction', 'Domain Adaptation', 'Fine-tuning', 'Validation'};
    stageProgress = [1.0, 1.0, 0.85, 0.92, 0.88]; % Completion/success rates
    
    bar(stageProgress, 'FaceColor', [0.6, 0.9, 0.6], 'EdgeColor', 'darkgreen');
    set(gca, 'XTickLabel', transferStages);
    ylabel('Stage Success Rate', 'FontSize', 12);
    title('Transfer Learning Pipeline', 'FontSize', 12, 'FontWeight', 'bold');
    xtickangle(45);
    ylim([0, 1]);
    grid on;
    
    % Summary and recommendations
    subplot(3, 4, 12);
    axis off;
    
    summaryText = sprintf('Transfer Learning Summary\n\n');
    summaryText = [summaryText, sprintf('Source: %s\n', transferResults.sourceDomain.name)];
    summaryText = [summaryText, sprintf('Target: %s\n', transferResults.targetDomain.name)];
    summaryText = [summaryText, sprintf('Strategy: %s\n', transferResults.transferredModel.transferType)];
    summaryText = [summaryText, sprintf('Compatibility: %.3f\n', domainAnalysis.compatibilityScore)];
    
    if isfield(transferResults, 'transferPerformance')
        summaryText = [summaryText, sprintf('Performance Gain: %.3f\n', ...
            transferResults.transferPerformance.transferredPerformance - transferResults.transferPerformance.targetBaseline)];
    end
    
    if isfield(transferResults, 'knowledgeTransferAnalysis')
        summaryText = [summaryText, sprintf('Positive Transfer: %.3f\n', ...
            transferResults.knowledgeTransferAnalysis.positiveTransfer)];
    end
    
    summaryText = [summaryText, sprintf('\nRecommendation:\n')];
    if domainAnalysis.compatibilityScore > 0.7
        summaryText = [summaryText, sprintf('High transfer potential\n')];
    elseif domainAnalysis.compatibilityScore > 0.4
        summaryText = [summaryText, sprintf('Moderate transfer with adaptation\n')];
    else
        summaryText = [summaryText, sprintf('Limited transfer benefits\n')];
    end
    
    summaryText = [summaryText, sprintf('\nAnalysis Date: %s', string(transferResults.timestamp))];
    
    text(0.05, 0.95, summaryText, 'FontSize', 11, 'VerticalAlignment', 'top', ...
        'HorizontalAlignment', 'left', 'Interpreter', 'none', 'FontWeight', 'bold');
    
    % Save visualisation in multiple formats
    saveas(gcf, 'TransferLearningResults.fig');
    saveas(gcf, 'TransferLearningResults.eps', 'epsc');
    saveas(gcf, 'TransferLearningResults.jpg');
    
    fprintf('Transfer learning visualisation saved in multiple formats.\n');
end
