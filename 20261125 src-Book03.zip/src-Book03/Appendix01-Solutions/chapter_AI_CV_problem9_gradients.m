%% chapter_AI_CV_problem9_gradients.m
% Gradient explanation syntax.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AI_CV_problem9_gradients
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Compute integrated gradients
attribution = integratedGradients(model, input, baseline, target, numSteps);

% Generate Grad-CAM heatmap
heatmap = gradCAM(model, input, targetLayer, targetClass);
