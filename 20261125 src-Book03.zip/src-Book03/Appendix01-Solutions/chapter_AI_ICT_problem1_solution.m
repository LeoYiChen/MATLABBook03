%% chapter_AI_ICT_problem1_solution.m
% Deep Learning Channel Estimation Implementation
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AI_ICT_problem1_solution
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [estimation_results, performance_metrics] = deepLearningChannelEstimation()
% Deep Learning Channel Estimation for MIMO-OFDM Systems
% Author: Dr Leo Chen
% Version: 1.0
% Date: 2024
%
% Implements adaptive channel estimation using deep neural networks
% for high-mobility MIMO-OFDM communication systems

fprintf('=== Deep Learning Channel Estimation Solution ===\n');

% System configuration parameters
system_params = struct();
system_params.num_transmit_antennas = 4; % MIMO transmit antennas
system_params.num_receive_antennas = 4; % MIMO receive antennas
system_params.num_subcarriers = 64; % OFDM subcarriers
system_params.pilot_density = 0.25; % Pilot symbol density
system_params.doppler_frequency_hz = 350; % Maximum Doppler shift
system_params.snr_range_db = 0:5:30; % SNR evaluation range
system_params.channel_model = 'rayleigh'; % Fading channel type

% Generate comprehensive training dataset
fprintf('Generating MIMO-OFDM channel dataset...\n');
[training_data, validation_data, test_data] = generateMIMOChannelDataset(system_params);

% Design deep neural network architecture
fprintf('Designing neural network architecture...\n');
channel_estimator_network = designChannelEstimatorNetwork(system_params);

% Train the neural network with advanced optimisation
fprintf('Training deep learning channel estimator...\n');
trained_network = trainChannelEstimatorNetwork(channel_estimator_network, ...
training_data, validation_data, ...
system_params);

% Implement conventional estimators for comparison
fprintf('Implementing conventional channel estimators...\n');
conventional_estimators = implementConventionalEstimators(system_params);

% Comprehensive performance evaluation
fprintf('Evaluating channel estimation performance...\n');
estimation_results = evaluateChannelEstimationPerformance(trained_network, ...
conventional_estimators, ...
test_data, system_params);

% Calculate detailed performance metrics
performance_metrics = calculateChannelEstimationMetrics(estimation_results, system_params);

% Generate performance visualisations
generateChannelEstimationVisualisations(estimation_results, performance_metrics);

fprintf('Deep learning channel estimation analysis completed successfully!\n');
end

function [training_data, validation_data, test_data] = generateMIMOChannelDataset(params)
% Generate comprehensive MIMO-OFDM channel dataset with realistic impairments

% Dataset size configuration
num_training_samples = 50000;
num_validation_samples = 10000;
num_test_samples = 10000;

% Channel generation parameters
channel_taps = 6; % Multipath channel taps
delay_spread_samples = 4; % RMS delay spread
velocity_ms = 60 / 3.6; % Mobile velocity (m/s)
carrier_frequency_hz = 2.6e9; % Carrier frequency

% Generate training dataset
fprintf(' Generating training data...\n');
training_data = generateChannelSamples(num_training_samples, params, ...
channel_taps, delay_spread_samples, ...
velocity_ms, carrier_frequency_hz);

% Generate validation dataset
fprintf(' Generating validation data...\n');
validation_data = generateChannelSamples(num_validation_samples, params, ...
channel_taps, delay_spread_samples, ...
velocity_ms, carrier_frequency_hz);

% Generate test dataset with extended scenarios
fprintf(' Generating test data...\n');
test_data = generateChannelSamples(num_test_samples, params, ...
channel_taps, delay_spread_samples, ...
velocity_ms, carrier_frequency_hz);

fprintf(' Dataset generation completed: %d total samples\n', ...
num_training_samples + num_validation_samples + num_test_samples);
end

function network = designChannelEstimatorNetwork(params)
% Design sophisticated neural network architecture for channel estimation

% Input dimensions calculation
num_pilots = round(params.num_subcarriers * params.pilot_density);
input_size = 2 * params.num_receive_antennas * num_pilots; % Real and imaginary parts

% Output dimensions (full channel matrix)
output_size = 2 * params.num_receive_antennas * params.num_transmit_antennas * params.num_subcarriers;

% Design deep network architecture
layers = [
featureInputLayer(input_size, 'Name', 'pilot_input', ...
'Normalization', 'zscore')

 
% First convolutional block for spatial processing
fullyConnectedLayer(512, 'Name', 'spatial_fc1')
batchNormalizationLayer('Name', 'spatial_bn1')
reluLayer('Name', 'spatial_relu1')
dropoutLayer(0.2, 'Name', 'spatial_dropout1')

% Second convolutional block
fullyConnectedLayer(1024, 'Name', 'spatial_fc2')
batchNormalizationLayer('Name', 'spatial_bn2')
reluLayer('Name', 'spatial_relu2')
dropoutLayer(0.3, 'Name', 'spatial_dropout2')

% Temporal processing layers
fullyConnectedLayer(2048, 'Name', 'temporal_fc1')
batchNormalizationLayer('Name', 'temporal_bn1')
reluLayer('Name', 'temporal_relu1')
dropoutLayer(0.2, 'Name', 'temporal_dropout1')

% Output processing layers
fullyConnectedLayer(1024, 'Name', 'output_fc1')
batchNormalizationLayer('Name', 'output_bn1')
reluLayer('Name', 'output_relu1')

fullyConnectedLayer(output_size, 'Name', 'channel_output')
regressionLayer('Name', 'regression_loss')
];

% Create layer graph for advanced architecture
network = layerGraph(layers);

fprintf(' Neural network architecture designed: %d layers\n', length(layers));
end

function trained_network = trainChannelEstimatorNetwork(network, training_data, validation_data, params)
% Train neural network with advanced optimisation techniques

% Advanced training options
training_options = trainingOptions('adam', ...
'MaxEpochs', 200, ...
'MiniBatchSize', 128, ...
'InitialLearnRate', 1e-3, ...
'LearnRateSchedule', 'piecewise', ...
'LearnRateDropPeriod', 50, ...
'LearnRateDropFactor', 0.5, ...
'L2Regularization', 1e-4, ...
'ValidationData', {validation_data.input_features', validation_data.channel_targets'}, ...
'ValidationFrequency', 100, ...
'ValidationPatience', 20, ...
'Shuffle', 'every-epoch', ...
'VerboseFrequency', 50, ...
'ExecutionEnvironment', 'auto', ...
'Plots', 'none');

% Train the network
fprintf(' Training neural network...\n');
trained_network = trainNetwork(training_data.input_features', ...
training_data.channel_targets', ...
network, training_options);

fprintf(' Neural network training completed\n');
end
