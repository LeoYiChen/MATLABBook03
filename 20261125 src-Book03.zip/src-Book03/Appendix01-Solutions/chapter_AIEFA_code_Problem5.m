%% chapter_AIEFA_code_Problem5.m
% Structural break detection via Chow test and CUSUM analysis (MATLABBook02_AIEFA_Problem5_StructuralBreak.m).
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AIEFA_code_Problem5
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%=========================================================================
% FILE   : MATLABBook02_AIEFA_Problem5_StructuralBreak.m
% DESCR. : Chow test and CUSUM structural break detection
% AUTHOR : Dr Yi Chen
% MATLAB : R2023b (compatible with R2019b and later)
% CREATED: July 2025   VERSION: 1.0
%=========================================================================
clear; clc; close all;
rng(42);

%% -- 1. Synthetic Housing Price Data --
sampleSize   = 200;
trueBreakPt  = 100;
slopePreBreak  = 0.5;
slopePostBreak = -0.3;
interceptPre   = 50;
noiseSigma     = 2.0;

timeVec = (1:sampleSize)';
truePrice = zeros(sampleSize, 1);
for tIdx = 1:sampleSize
    if tIdx <= trueBreakPt
        truePrice(tIdx) = interceptPre + slopePreBreak * tIdx;
    else
        % Ensure continuity at break point
        priceAtBreak = interceptPre + slopePreBreak * trueBreakPt;
        truePrice(tIdx) = priceAtBreak + ...
            slopePostBreak * (tIdx - trueBreakPt);
    end
end
housingPrice = truePrice + noiseSigma * randn(sampleSize, 1);

%% -- 2. Pooled (Restricted) Regression --
xPooled    = [ones(sampleSize, 1), timeVec];
betaPooled = xPooled \ housingPrice;
residPooled = housingPrice - xPooled * betaPooled;
rssRestricted = sum(residPooled.^2);
numParams = 2;  % intercept + slope

%% -- 3. Chow Test at Grid of Candidate Break Points --
trimPct       = 0.10;
trimObs       = max(numParams + 1, round(trimPct * sampleSize));
candidateGrid = (trimObs : sampleSize - trimObs)';
numCandidates = length(candidateGrid);
fStatValues   = zeros(numCandidates, 1);
pValues       = zeros(numCandidates, 1);

for candIdx = 1:numCandidates
    breakCandidate = candidateGrid(candIdx);

    % Sub-sample 1: t = 1, ..., breakCandidate
    x1 = [ones(breakCandidate, 1), timeVec(1:breakCandidate)];
    y1 = housingPrice(1:breakCandidate);
    beta1 = x1 \ y1;
    rss1  = sum((y1 - x1 * beta1).^2);

    % Sub-sample 2: t = breakCandidate+1, ..., T
    x2 = [ones(sampleSize - breakCandidate, 1), ...
           timeVec(breakCandidate+1:end)];
    y2 = housingPrice(breakCandidate+1:end);
    beta2 = x2 \ y2;
    rss2  = sum((y2 - x2 * beta2).^2);

    % F-statistic (Chow, 1960)
    df1 = numParams;
    df2 = sampleSize - 2 * numParams;
    fStatValues(candIdx) = ...
        ((rssRestricted - rss1 - rss2) / df1) / ...
        ((rss1 + rss2) / df2);

    % p-value via incomplete beta function (base MATLAB)
    xBeta = df2 / (df2 + df1 * fStatValues(candIdx));
    pValues(candIdx) = betainc(xBeta, df2/2, df1/2);
end

% Identify supremum F-statistic
[maxFStat, maxFIdx] = max(fStatValues);
detectedBreak = candidateGrid(maxFIdx);
fprintf('Supremum Chow test: detected break at t* = %d\n', ...
    detectedBreak);
fprintf('  F-statistic = %.2f, p-value = %.6f\n', ...
    maxFStat, pValues(maxFIdx));
fprintf('  True break point: t* = %d\n', trueBreakPt);

%% -- 4. CUSUM Test (Brown, Durbin, Evans 1975) --
% Recursive residuals from forward expanding OLS
startObs       = numParams + 2;
recursiveResid = zeros(sampleSize - startObs + 1, 1);

for tIdx = startObs:sampleSize
    xHistory   = [ones(tIdx-1, 1), timeVec(1:tIdx-1)];
    yHistory   = housingPrice(1:tIdx-1);
    betaRecur  = xHistory \ yHistory;
    xCurrent   = [1, timeVec(tIdx)];
    yPredicted = xCurrent * betaRecur;
    leverageH  = xCurrent * ((xHistory' * xHistory) \ xCurrent');
    residRaw   = housingPrice(tIdx) - yPredicted;
    residVar   = sum((yHistory - xHistory * betaRecur).^2) / ...
                 (tIdx - 1 - numParams);
    recursiveResid(tIdx - startObs + 1) = ...
        residRaw / sqrt(residVar * (1 + leverageH));
end

% Standardised CUSUM
cusumStat    = cumsum(recursiveResid);
cusumNorm    = cusumStat / (sqrt(sum(recursiveResid.^2)));
numRecObs    = length(recursiveResid);
cusumTimeAxis = (startObs:sampleSize)';

% 5% significance boundaries (linear: 0.948 * (1 + 2*(t-k)/n))
alpha5       = 0.948;
cusumUpper   = alpha5 * (1 + 2 * (0:numRecObs-1)' / numRecObs);
cusumLower   = -cusumUpper;

%% -- 5. Display Table for Selected Break Points --
reportPoints = [40, 60, 80, 100, 120, 140, 160];
fprintf('\n- Chow Test Results at Selected Break Points -\n');
fprintf('%-12s %-14s %-12s %-12s\n', ...
    'Break t*', 'F-Statistic', 'p-Value', 'Reject H0');
for rpIdx = 1:length(reportPoints)
    rp = reportPoints(rpIdx);
    cIdx = find(candidateGrid == rp, 1);
    if ~isempty(cIdx)
        rejectStr = 'No';
        if pValues(cIdx) < 0.05
            rejectStr = 'Yes';
        end
        fprintf('%-12d %-14.2f %-12.6f %-12s\n', ...
            rp, fStatValues(cIdx), pValues(cIdx), rejectStr);
    end
end

%% -- 6. Plotting --
figure('Position', [50, 50, 1100, 700]);

subplot(2, 2, 1);
plot(timeVec, housingPrice, 'b.', 'MarkerSize', 4);
hold on;
plot(timeVec, truePrice, 'r-', 'LineWidth', 1.2);
xline(trueBreakPt, 'k--', 'LineWidth', 1.0);
xlabel('$t$ (Month)', 'Interpreter', 'latex');
ylabel('Housing Price Index', 'Interpreter', 'latex');
title('Synthetic Housing Price Series', 'Interpreter', 'latex');
legend('Observed', 'True Trend', 'True Break', ...
    'Interpreter', 'latex', 'Location', 'best');
grid on;

subplot(2, 2, 2);
plot(candidateGrid, fStatValues, 'b-', 'LineWidth', 1.0);
hold on;
plot(detectedBreak, maxFStat, 'rv', 'MarkerSize', 10, ...
    'MarkerFaceColor', 'r');
xline(trueBreakPt, 'k--', 'LineWidth', 1.0);
xlabel('Candidate Break Point $t^*$', 'Interpreter', 'latex');
ylabel('$F$-Statistic', 'Interpreter', 'latex');
title('Chow Test $F$-Statistics', 'Interpreter', 'latex');
legend('$F(t^*)$', 'Detected Break', 'True Break', ...
    'Interpreter', 'latex', 'Location', 'best');
grid on;

subplot(2, 2, 3);
plot(cusumTimeAxis, cusumNorm, 'b-', 'LineWidth', 1.0);
hold on;
plot(cusumTimeAxis, cusumUpper, 'r--', 'LineWidth', 1.0);
plot(cusumTimeAxis, cusumLower, 'r--', 'LineWidth', 1.0);
xline(trueBreakPt, 'k--', 'LineWidth', 1.0);
xlabel('$t$', 'Interpreter', 'latex');
ylabel('CUSUM', 'Interpreter', 'latex');
title('CUSUM Test with 5\% Boundaries', 'Interpreter', 'latex');
legend('CUSUM', '5\% Bounds', '', 'True Break', ...
    'Interpreter', 'latex', 'Location', 'best');
grid on;

subplot(2, 2, 4);
semilogy(candidateGrid, pValues, 'b-', 'LineWidth', 1.0);
hold on;
yline(0.05, 'r--', 'LineWidth', 1.0);
xline(trueBreakPt, 'k--', 'LineWidth', 1.0);
xlabel('Candidate Break Point $t^*$', 'Interpreter', 'latex');
ylabel('$p$-Value', 'Interpreter', 'latex');
title('Chow Test $p$-Values (Log Scale)', 'Interpreter', 'latex');
legend('$p$-value', '5\% Level', 'True Break', ...
    'Interpreter', 'latex', 'Location', 'best');
grid on;
% Computational Complexity:
% Chow test: for each of (T - 2*trim) candidates, two OLS
% regressions are solved, each O(T_i * k^2). Scanning all
% candidates: O(T^2 * k^2). CUSUM requires expanding-window
% OLS at each step: O(T^2 * k) with sequential updating or
% O(T^3 * k^2) naively. For T = 200 and k = 2, total cost
% is well under one second. Bai-Perron extensions for
% multiple breaks have complexity O(T^2) via dynamic
% programming.
