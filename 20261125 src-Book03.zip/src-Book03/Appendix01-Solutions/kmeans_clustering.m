%% kmeans_clustering.m
% K-Means Customer Segmentation
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : kmeans_clustering
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% K-Means Clustering for Customer Segmentation
% Author: Dr Leo Chen
% Version: R2023b
% Date: November 2024

function customer_segmentation_kmeans()
% Generate synthetic customer data
rng(123); % Ensure reproducibility
num_customers = 500;

% Customer features: Annual Spending, Frequency, Recency, Average Order Value
annual_spending = 1000 + 3000 * rand(num_customers, 1);
purchase_frequency = 1 + 50 * rand(num_customers, 1);
recency_days = 1 + 365 * rand(num_customers, 1);
average_order_value = 20 + 200 * rand(num_customers, 1);

% Combine features into matrix
customer_features = [annual_spending, purchase_frequency, ...
    recency_days, average_order_value];

% Standardise features for clustering
standardised_features = zscore(customer_features);

% Determine optimal number of clusters using elbow method
max_clusters = 10;
within_cluster_sum_squares = zeros(max_clusters, 1);
silhouette_scores = zeros(max_clusters-1, 1);

for cluster_count = 1:max_clusters
    [cluster_indices, cluster_centroids, sum_distances] = ...
        kmeans(standardised_features, cluster_count, ...
        'Replicates', 10, 'MaxIter', 1000);
    within_cluster_sum_squares(cluster_count) = sum(sum_distances);
    
    if cluster_count > 1
        silhouette_values = silhouette(standardised_features, cluster_indices);
        silhouette_scores(cluster_count-1) = mean(silhouette_values);
    end
end

% Find optimal clusters (elbow method)
[~, optimal_clusters] = max(diff(diff(within_cluster_sum_squares)));
optimal_clusters = optimal_clusters + 1;

% Perform final clustering with optimal number
[final_cluster_indices, final_centroids] = ...
    kmeans(standardised_features, optimal_clusters, ...
    'Replicates', 20, 'MaxIter', 1000);

% Calculate cluster statistics
cluster_sizes = histcounts(final_cluster_indices, 1:optimal_clusters+1);

% Visualisation using PCA
[principal_components, ~, explained_variance] = ...
    pca(standardised_features);

% Plot clustering results
figure('Name', 'Customer Segmentation Results');
subplot(2, 2, 1);
plot(1:max_clusters, within_cluster_sum_squares, 'bo-', 'LineWidth', 2);
xlabel('Number of Clusters', 'Interpreter', 'latex');
ylabel('Within-Cluster Sum of Squares', 'Interpreter', 'latex');
title('Elbow Method for Optimal Clusters', 'Interpreter', 'latex');
grid on;

subplot(2, 2, 2);
plot(2:max_clusters, silhouette_scores, 'ro-', 'LineWidth', 2);
xlabel('Number of Clusters', 'Interpreter', 'latex');
ylabel('Average Silhouette Score', 'Interpreter', 'latex');
title('Silhouette Analysis', 'Interpreter', 'latex');
grid on;

subplot(2, 2, 3);
scatter(principal_components(:, 1), principal_components(:, 2), ...
    50, final_cluster_indices, 'filled');
xlabel(sprintf('PC1 (%.1f%% variance)', explained_variance(1)), ...
    'Interpreter', 'latex');
ylabel(sprintf('PC2 (%.1f%% variance)', explained_variance(2)), ...
    'Interpreter', 'latex');
title('Customer Segments in PCA Space', 'Interpreter', 'latex');
colorbar;

subplot(2, 2, 4);
bar(cluster_sizes);
xlabel('Cluster Number', 'Interpreter', 'latex');
ylabel('Number of Customers', 'Interpreter', 'latex');
title('Cluster Size Distribution', 'Interpreter', 'latex');

% Display cluster characteristics
fprintf('\\textbf{Optimal Number of Clusters}: %d\\n', optimal_clusters);
fprintf('\\textbf{Average Silhouette Score}: %.3f\\n', ...
    mean(silhouette(standardised_features, final_cluster_indices)));

% Analyse cluster centroids in original scale
original_centroids = final_centroids .* std(customer_features) + ...
    mean(customer_features);

feature_names = {'Annual Spending', 'Purchase Frequency', ...
    'Recency Days', 'Average Order Value'};

fprintf('\\n\\textbf{Cluster Characteristics}:\\n');
for cluster_id = 1:optimal_clusters
    fprintf('Cluster %d (n=%d):\\n', cluster_id, cluster_sizes(cluster_id));
    for feature_idx = 1:length(feature_names)
        fprintf('  %s: %.2f\\n', feature_names{feature_idx}, ...
            original_centroids(cluster_id, feature_idx));
    end
    fprintf('\\n');
end

end
