%% chapter_AI_CV_problem4_complete.m
% Parallel Algorithm Design Framework.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AI_CV_problem4_complete
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% Parallel Algorithm Design Framework for Computer Vision
% Author: Dr Leo Chen
% Created: January 2025
% MATLAB Version: R2024a or later

function parallelResults = parallelAlgorithmDesign()
    fprintf('Parallel Algorithm Design Framework\n');
    
    % Initialize parallel computing environment
    parallelEnv = initializeParallelEnvironment();
    
    % Perform parallel algorithm tests
    parallelResults = performParallelAlgorithmTests(parallelEnv);
    
    % Visualise results
    visualiseParallelResults(parallelResults);
end

function env = initializeParallelEnvironment()
    env = struct();
    
    % Check available workers
    env.maxWorkers = feature('numcores');
    
    % Initialize parallel pool if not already active
    currentPool = gcp('nocreate');
    if isempty(currentPool)
        try
            env.pool = parpool('local', min(env.maxWorkers, 4));
            env.numWorkers = env.pool.NumWorkers;
        catch
            fprintf('Failed to create parallel pool, using sequential processing\n');
            env.pool = [];
            env.numWorkers = 1;
        end
    else
        env.pool = currentPool;
        env.numWorkers = currentPool.NumWorkers;
    end
    
    env.hasParallelToolbox = ~isempty(env.pool);
    
    fprintf('Parallel environment initialized with %d workers\n', env.numWorkers);
end

function results = performParallelAlgorithmTests(env)
    results = struct();
    
    % Test 1: Parallel image filtering
    results.imageFiltering = testParallelImageFiltering(env);
    
    % Test 2: Parallel feature extraction
    results.featureExtraction = testParallelFeatureExtraction(env);
    
    % Test 3: Parallel matrix operations
    results.matrixOperations = testParallelMatrixOperations(env);
    
    % Test 4: Load balancing analysis
    results.loadBalancing = testLoadBalancing(env);
    
    % Test 5: Scalability analysis
    results.scalabilityAnalysis = testScalabilityAnalysis(env);
    
    fprintf('Parallel algorithm tests completed\n');
end

function result = testParallelImageFiltering(env)
    fprintf('Testing parallel image filtering...\n');
    
    result = struct();
    result.testName = 'Parallel Image Filtering';
    
    % Create test images
    numImages = 100;
    imageSize = [512, 512, 3];
    images = cell(numImages, 1);
    
    for imageIndex = 1:numImages
        images{imageIndex} = rand(imageSize, 'single');
    end
    
    % Test sequential processing
    tic;
    sequentialResults = cell(numImages, 1);
    for imageIndex = 1:numImages
        sequentialResults{imageIndex} = applyImageFilters(images{imageIndex});
    end
    sequentialTime = toc;
    
    % Test parallel processing
    if env.hasParallelToolbox
        tic;
        parallelResults = cell(numImages, 1);
        parfor imageIndex = 1:numImages
            parallelResults{imageIndex} = applyImageFilters(images{imageIndex});
        end
        parallelTime = toc;
        
        % Verify correctness
        maxDifference = 0;
        for imageIndex = 1:numImages
            difference = max(abs(sequentialResults{imageIndex}(:) - parallelResults{imageIndex}(:)));
            maxDifference = max(maxDifference, difference);
        end
        
        result.correctnessCheck = maxDifference < 1e-6;
    else
        parallelTime = sequentialTime;
        result.correctnessCheck = true;
    end
    
    result.numImages = numImages;
    result.sequentialTime = sequentialTime;
    result.parallelTime = parallelTime;
    result.speedup = sequentialTime / parallelTime;
    result.efficiency = result.speedup / env.numWorkers;
    result.throughput = numImages / parallelTime;
end

function filteredImage = applyImageFilters(image)
    % Apply various image filters in sequence
    
    % Gaussian filter
    gaussianFiltered = imgaussfilt(image, 2);
    
    % Edge detection
    if size(image, 3) == 3
        grayImage = rgb2gray(gaussianFiltered);
    else
        grayImage = gaussianFiltered;
    end
    
    edges = edge(grayImage, 'canny');
    
    % Morphological operations
    se = strel('disk', 3);
    morphFiltered = imclose(edges, se);
    
    % Combine results
    filteredImage = double(morphFiltered);
end

function result = testParallelFeatureExtraction(env)
    fprintf('Testing parallel feature extraction...\n');
    
    result = struct();
    result.testName = 'Parallel Feature Extraction';
    
    % Generate test data
    numSamples = 500;
    dataSize = [64, 64, 3];
    testData = rand([dataSize, numSamples], 'single');
    
    % Sequential feature extraction
    tic;
    sequentialFeatures = zeros(numSamples, 128);
    for sampleIndex = 1:numSamples
        sequentialFeatures(sampleIndex, :) = extractImageFeatures(testData(:, :, :, sampleIndex));
    end
    sequentialTime = toc;
    
    % Parallel feature extraction
    if env.hasParallelToolbox
        tic;
        parallelFeatures = zeros(numSamples, 128);
        parfor sampleIndex = 1:numSamples
            parallelFeatures(sampleIndex, :) = extractImageFeatures(testData(:, :, :, sampleIndex));
        end
        parallelTime = toc;
        
        % Verify correctness
        featureDifference = max(abs(sequentialFeatures(:) - parallelFeatures(:)));
        result.correctnessCheck = featureDifference < 1e-6;
    else
        parallelTime = sequentialTime;
        parallelFeatures = sequentialFeatures;
        result.correctnessCheck = true;
    end
    
    result.numSamples = numSamples;
    result.featureDimension = size(sequentialFeatures, 2);
    result.sequentialTime = sequentialTime;
    result.parallelTime = parallelTime;
    result.speedup = sequentialTime / parallelTime;
    result.efficiency = result.speedup / env.numWorkers;
    result.extractionRate = numSamples / parallelTime;
end

function features = extractImageFeatures(image)
    % Extract various features from image
    
    % Convert to grayscale if needed
    if size(image, 3) == 3
        grayImage = rgb2gray(image);
    else
        grayImage = image;
    end
    
    % Texture features (simplified)
    glcm = graycomatrix(uint8(grayImage * 255));
    textureStats = graycoprops(glcm);
    
    % Statistical features
    meanVal = mean(grayImage(:));
    stdVal = std(grayImage(:));
    skewVal = skewness(grayImage(:));
    kurtVal = kurtosis(grayImage(:));
    
    % Gradient features
    [Gx, Gy] = gradient(double(grayImage));
    gradientMagnitude = sqrt(Gx.^2 + Gy.^2);
    meanGradient = mean(gradientMagnitude(:));
    maxGradient = max(gradientMagnitude(:));
    
    % Combine features
    features = [
        textureStats.Contrast, textureStats.Correlation, textureStats.Energy, textureStats.Homogeneity, ...
        meanVal, stdVal, skewVal, kurtVal, meanGradient, maxGradient, ...
        zeros(1, 118) % Pad to 128 features
    ];
end

function result = testParallelMatrixOperations(env)
    fprintf('Testing parallel matrix operations...\n');
    
    result = struct();
    result.testName = 'Parallel Matrix Operations';
    
    % Generate test matrices
    matrixSizes = [500, 1000, 1500, 2000];
    numSizes = length(matrixSizes);
    
    sequentialTimes = zeros(numSizes, 1);
    parallelTimes = zeros(numSizes, 1);
    speedups = zeros(numSizes, 1);
    
    for sizeIndex = 1:numSizes
        matrixSize = matrixSizes(sizeIndex);
        A = rand(matrixSize, matrixSize, 'single');
        B = rand(matrixSize, matrixSize, 'single');
        
        % Sequential matrix multiplication
        tic;
        C_sequential = A * B;
        sequentialTimes(sizeIndex) = toc;
        
        % Parallel matrix operations (using MATLAB's built-in parallelization)
        if env.hasParallelToolbox
            tic;
            C_parallel = parallelMatrixMultiply(A, B);
            parallelTimes(sizeIndex) = toc;
            
            % Verify correctness
            maxDiff = max(abs(C_sequential(:) - C_parallel(:)));
            if maxDiff > 1e-4
                fprintf('Warning: Matrix multiplication difference: %e\n', maxDiff);
            end
        else
            parallelTimes(sizeIndex) = sequentialTimes(sizeIndex);
        end
        
        speedups(sizeIndex) = sequentialTimes(sizeIndex) / parallelTimes(sizeIndex);
    end
    
    result.matrixSizes = matrixSizes;
    result.sequentialTimes = sequentialTimes;
    result.parallelTimes = parallelTimes;
    result.speedups = speedups;
    result.averageSpeedup = mean(speedups);
    result.efficiency = speedups / env.numWorkers;
end

function C = parallelMatrixMultiply(A, B)
    % Parallel matrix multiplication using block decomposition
    
    [m, k] = size(A);
    [k2, n] = size(B);
    
    if k ~= k2
        error('Matrix dimensions do not match');
    end
    
    % Determine block size based on matrix size
    blockSize = min(250, floor(sqrt(m * n / 4)));
    
    % Initialize result matrix
    C = zeros(m, n, 'like', A);
    
    % Block-wise parallel multiplication
    for blockRow = 1:blockSize:m
        for blockCol = 1:blockSize:n
            rowEnd = min(blockRow + blockSize - 1, m);
            colEnd = min(blockCol + blockSize - 1, n);
            
            % Compute block
            blockResult = zeros(rowEnd - blockRow + 1, colEnd - blockCol + 1, 'like', A);
            
            for blockK = 1:blockSize:k
                kEnd = min(blockK + blockSize - 1, k);
                
                blockA = A(blockRow:rowEnd, blockK:kEnd);
                blockB = B(blockK:kEnd, blockCol:colEnd);
                
                blockResult = blockResult + blockA * blockB;
            end
            
            C(blockRow:rowEnd, blockCol:colEnd) = blockResult;
        end
    end
end

function result = testLoadBalancing(env)
    fprintf('Testing load balancing...\n');
    
    result = struct();
    result.testName = 'Load Balancing';
    
    % Create tasks with varying computational complexity
    numTasks = 100;
    taskComplexities = [
        repmat(1, 40, 1);    % 40 simple tasks
        repmat(3, 30, 1);    % 30 medium tasks
        repmat(7, 20, 1);    % 20 complex tasks
        repmat(15, 10, 1)    % 10 very complex tasks
    ];
    
    % Sequential processing
    tic;
    sequentialResults = zeros(numTasks, 1);
    for taskIndex = 1:numTasks
        sequentialResults(taskIndex) = simulateComputationalTask(taskComplexities(taskIndex));
    end
    sequentialTime = toc;
    
    % Parallel processing with static load balancing
    if env.hasParallelToolbox
        tic;
        staticResults = zeros(numTasks, 1);
        parfor taskIndex = 1:numTasks
            staticResults(taskIndex) = simulateComputationalTask(taskComplexities(taskIndex));
        end
        staticTime = toc;
        
        % Dynamic load balancing (using parfeval)
        tic;
        dynamicResults = performDynamicLoadBalancing(taskComplexities, env);
        dynamicTime = toc;
    else
        staticTime = sequentialTime;
        dynamicTime = sequentialTime;
        staticResults = sequentialResults;
        dynamicResults = sequentialResults;
    end
    
    result.numTasks = numTasks;
    result.taskComplexities = taskComplexities;
    result.sequentialTime = sequentialTime;
    result.staticTime = staticTime;
    result.dynamicTime = dynamicTime;
    result.staticSpeedup = sequentialTime / staticTime;
    result.dynamicSpeedup = sequentialTime / dynamicTime;
    result.loadBalancingImprovement = staticTime / dynamicTime;
end

function resultValue = simulateComputationalTask(complexity)
    % Simulate computational task with given complexity
    
    matrixSize = complexity * 50;
    A = rand(matrixSize, matrixSize);
    
    % Perform matrix operations
    B = A * A';
    eigenvals = eig(B);
    
    resultValue = sum(eigenvals);
end

function results = performDynamicLoadBalancing(taskComplexities, env)
    % Perform dynamic load balancing using parfeval
    
    numTasks = length(taskComplexities);
    results = zeros(numTasks, 1);
    
    if env.hasParallelToolbox && env.numWorkers > 1
        % Submit all tasks to parallel pool
        futures = cell(numTasks, 1);
        
        for taskIndex = 1:numTasks
            futures{taskIndex} = parfeval(@simulateComputationalTask, 1, taskComplexities(taskIndex));
        end
        
        % Collect results as they complete
        for taskIndex = 1:numTasks
            [completedIndex, value] = fetchNext(futures{:});
            results(completedIndex) = value;
        end
    else
        % Fallback to sequential processing
        for taskIndex = 1:numTasks
            results(taskIndex) = simulateComputationalTask(taskComplexities(taskIndex));
        end
    end
end

function result = testScalabilityAnalysis(env)
    fprintf('Testing scalability analysis...\n');
    
    result = struct();
    result.testName = 'Scalability Analysis';
    
    % Test with different numbers of workers
    maxWorkers = env.numWorkers;
    workerCounts = 1:maxWorkers;
    
    % Fixed problem size
    problemSize = 50;
    testData = rand(64, 64, 3, problemSize, 'single');
    
    processingTimes = zeros(size(workerCounts));
    speedups = zeros(size(workerCounts));
    efficiencies = zeros(size(workerCounts));
    
    for workerIndex = 1:length(workerCounts)
        numWorkers = workerCounts(workerIndex);
        
        if numWorkers == 1 || ~env.hasParallelToolbox
            % Sequential processing
            tic;
            for sampleIndex = 1:problemSize
                processedSample = applyImageFilters(testData(:, :, :, sampleIndex));
            end
            processingTimes(workerIndex) = toc;
        else
            % Parallel processing (simulate different worker counts)
            effectiveWorkers = min(numWorkers, problemSize);
            chunkSize = ceil(problemSize / effectiveWorkers);
            
            tic;
            processedData = cell(problemSize, 1);
            parfor sampleIndex = 1:problemSize
                processedData{sampleIndex} = applyImageFilters(testData(:, :, :, sampleIndex));
            end
            processingTimes(workerIndex) = toc;
        end
        
        % Calculate performance metrics
        if workerIndex == 1
            baselineTime = processingTimes(1);
        end
        
        speedups(workerIndex) = baselineTime / processingTimes(workerIndex);
        efficiencies(workerIndex) = speedups(workerIndex) / numWorkers;
    end
    
    result.workerCounts = workerCounts;
    result.processingTimes = processingTimes;
    result.speedups = speedups;
    result.efficiencies = efficiencies;
    result.optimalWorkers = workerCounts(efficiencies == max(efficiencies));
    result.scalabilityFactor = speedups(end) / speedups(1);
end

function visualiseParallelResults(results)
    figure('Position', [100, 100, 1400, 1000]);
    
    % Image filtering performance
    if isfield(results, 'imageFiltering')
        subplot(2, 3, 1);
        if_result = results.imageFiltering;
        
        categories = {'Sequential', 'Parallel'};
        times = [if_result.sequentialTime, if_result.parallelTime];
        
        bar(times);
        set(gca, 'XTickLabel', categories);
        ylabel('Processing Time (s)');
        title(sprintf('Image Filtering\nSpeedup: %.2fx', if_result.speedup));
    end
    
    % Feature extraction performance
    if isfield(results, 'featureExtraction')
        subplot(2, 3, 2);
        fe_result = results.featureExtraction;
        
        bar([fe_result.sequentialTime, fe_result.parallelTime]);
        set(gca, 'XTickLabel', {'Sequential', 'Parallel'});
        ylabel('Processing Time (s)');
        title(sprintf('Feature Extraction\nSpeedup: %.2fx', fe_result.speedup));
    end
    
    % Matrix operations scalability
    if isfield(results, 'matrixOperations')
        subplot(2, 3, 3);
        mo_result = results.matrixOperations;
        
        plot(mo_result.matrixSizes, mo_result.speedups, 'b-o', 'LineWidth', 2);
        xlabel('Matrix Size');
        ylabel('Speedup');
        title('Matrix Operations Speedup');
        grid on;
    end
    
    % Load balancing comparison
    if isfield(results, 'loadBalancing')
        subplot(2, 3, 4);
        lb_result = results.loadBalancing;
        
        times = [lb_result.sequentialTime, lb_result.staticTime, lb_result.dynamicTime];
        methods = {'Sequential', 'Static Parallel', 'Dynamic Parallel'};
        
        bar(times);
        set(gca, 'XTickLabel', methods);
        xtickangle(45);
        ylabel('Processing Time (s)');
        title('Load Balancing Comparison');
    end
    
    % Scalability analysis
    if isfield(results, 'scalabilityAnalysis')
        subplot(2, 3, 5);
        sa_result = results.scalabilityAnalysis;
        
        plot(sa_result.workerCounts, sa_result.speedups, 'r-s', 'LineWidth', 2);
        hold on;
        plot(sa_result.workerCounts, sa_result.workerCounts, 'k--', 'LineWidth', 1);
        xlabel('Number of Workers');
        ylabel('Speedup');
        title('Scalability Analysis');
        legend('Actual Speedup', 'Ideal Speedup', 'Location', 'northwest');
        grid on;
    end
    
    % Efficiency analysis
    if isfield(results, 'scalabilityAnalysis')
        subplot(2, 3, 6);
        sa_result = results.scalabilityAnalysis;
        
        plot(sa_result.workerCounts, sa_result.efficiencies, 'g-^', 'LineWidth', 2);
        xlabel('Number of Workers');
        ylabel('Efficiency');
        title('Parallel Efficiency');
        grid on;
        ylim([0, 1]);
    end
    
    sgtitle('Parallel Algorithm Performance Analysis');
end

% Execute main function
parallelResults = parallelAlgorithmDesign();
