%% p10.m
% MATLABBook03_ChapterAIBHS_Problem10.m
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : p10
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function MATLABBook03_ChapterAIBHS_Problem10
% Purpose: boosted sepsis early-warning + AUROC. Author: Dr Leo Chen.
% R2024b + Statistics ML. v1.0 2025-06-01.
    rng(0); N=1000; nS=100; nC=N-nS;
    ctrl=[randn(nC,1)*8+80 randn(nC,1)*0.4+37 randn(nC,1)*2+8 abs(randn(nC,1)*0.4+1)];
    sept=[randn(nS,1)*10+100 randn(nS,1)*0.6+38.5 randn(nS,1)*4+14 abs(randn(nS,1)+3)];
    F=[ctrl;sept]; y=[zeros(nC,1);ones(nS,1)];
    cv=cvpartition(y,'HoldOut',0.3); tr=training(cv); te=test(cv);
    m=fitcensemble(F(tr,:),y(tr),'Method','LogitBoost','NumLearningCycles',100,'Prior','uniform');
    [~,sc]=predict(m,F(te,:)); [fp,tp,~,auc]=perfcurve(y(te),sc(:,2),1);
    idx=find(fp<=0.10,1,'last');
    fprintf('AUROC: %.3f  Sensitivity@90%%spec: %.3f\n',auc,tp(idx));
end
