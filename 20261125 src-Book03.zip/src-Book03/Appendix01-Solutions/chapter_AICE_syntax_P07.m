%% chapter_AICE_syntax_P07.m
% TF-IDF document retrieval syntax.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AICE_syntax_P07
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
documents  = tokenizedDocument(textArray);
bagModel   = bagOfWords(documents);
tfidfMat   = tfidf(bagModel);
queryVec   = tfidf(bagModel, tokenizedDocument(queryText));
scores     = cosineSimilarity(tfidfMat, queryVec);
% - Computational Complexity -
% Tokenisation is O(total words). TF-IDF weighting and cosine
% similarity are each O(nnz) in the sparse term matrix. A
% corpus of thousands of clauses is therefore searchable in
% milliseconds without any neural network.
