%% chapter_AIinMOR_problem_4.m
% AI-Driven Portfolio Optimisation with ESG Constraints.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AIinMOR_problem_4
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [portfolioOptimizationResults] = solveAIDrivenPortfolioOptimization()
% AI-Driven Financial Portfolio Optimisation with ESG Constraints
% Author: Dr Leo Chen
% Version: 1.0
% Date: 2025
% Description: Multi-objective portfolio optimization with sustainability integration

fprintf('\\textbf{AI-Driven Financial Portfolio Optimisation with ESG}\n');
fprintf('========================================================\n\n');

% Generate synthetic financial market data
marketData = generateSyntheticMarketData();

% Develop ESG scoring framework
esgFramework = developESGScoringFramework(marketData);

% Train ensemble ML models for prediction
predictionModels = trainEnsemblePredictionModels(marketData);

% Implement multi-objective portfolio optimization
portfolioOptimisation = implementMultiObjectivePortfolioOptimization(marketData, esgFramework, predictionModels);

% Apply robust optimization techniques
robustOptimisation = applyRobustOptimizationTechniques(portfolioOptimisation, marketData);

% Develop dynamic rebalancing strategy
rebalancingStrategy = developDynamicRebalancingStrategy(robustOptimisation, predictionModels);

% Validate through comprehensive backtesting
backtestingResults = validateThroughComprehensiveBacktesting(rebalancingStrategy, marketData, esgFramework);

% Consolidate results
portfolioOptimizationResults = consolidatePortfolioOptimizationResults(marketData, esgFramework, 
    predictionModels, portfolioOptimisation, robustOptimisation, rebalancingStrategy, backtestingResults);

% Generate comprehensive visualisations
generatePortfolioOptimizationVisualisations(portfolioOptimizationResults);

% Display investment recommendations
displayInvestmentRecommendations(portfolioOptimizationResults);

end

function marketData = generateSyntheticMarketData()
% Generate realistic synthetic financial market data

marketData = struct();

fprintf('\\textbf{Generating Synthetic Market Data:}\n');

% Market parameters
marketData.numAssets = 50;
marketData.timeHorizon = 252 * 5; % 5 years of daily data
marketData.assetNames = arrayfun(@(x) sprintf('Asset_%02d', x), 1:marketData.numAssets, 'UniformOutput', false);

% Asset categories
marketData.assetCategories = {
    'Technology', 'Healthcare', 'Financial', 'Energy', 'Utilities', 
    'Consumer', 'Industrial', 'Materials', 'Real Estate', 'Telecommunications'
};

% Assign categories to assets
marketData.assetCategoryMap = repmat(marketData.assetCategories, 1, ceil(marketData.numAssets/10));
marketData.assetCategoryMap = marketData.assetCategoryMap(1:marketData.numAssets);

% Generate returns with realistic features
rng(2025);
marketData.returns = generateRealisticReturns(marketData);

% Generate market factors
marketData.marketFactors = generateMarketFactors(marketData.timeHorizon);

% Price data (reconstruct from returns)
marketData.prices = generatePriceData(marketData.returns);

% Fundamental data
marketData.fundamentals = generateFundamentalData(marketData);

fprintf('Market data generated: %d assets, %d days\n', marketData.numAssets, marketData.timeHorizon);
fprintf('Average daily return: %.4f%%\n', mean(marketData.returns(:)) * 100);
fprintf('Average daily volatility: %.4f%%\n', std(marketData.returns(:)) * 100);

end

function returns = generateRealisticReturns(marketData)
% Generate realistic return series with stylized facts

numAssets = marketData.numAssets;
timeHorizon = marketData.timeHorizon;

returns = zeros(timeHorizon, numAssets);

% Market factor (common component)
marketReturns = generateMarketReturns(timeHorizon);

% Asset-specific parameters
expectedReturns = 0.0001 + 0.0003 * randn(numAssets, 1); % Daily expected returns
baseVolatilities = 0.01 + 0.015 * rand(numAssets, 1); % Base daily volatilities
marketBetas = 0.5 + 1.5 * rand(numAssets, 1); % Market betas

for assetIdx = 1:numAssets
    % GARCH-like volatility clustering
    volatility = generateGARCHVolatility(timeHorizon, baseVolatilities(assetIdx));
    
    # Idiosyncratic returns
    idiosyncraticReturns = randn(timeHorizon, 1) .* volatility;
    
    # Total returns (market + idiosyncratic)
    assetReturns = expectedReturns(assetIdx) + ...
                  marketBetas(assetIdx) * marketReturns + ...
                  idiosyncraticReturns;
    
    returns(:, assetIdx) = assetReturns;
end

end

function marketReturns = generateMarketReturns(timeHorizon)
% Generate market factor returns

# Market return parameters
marketExpectedReturn = 0.0003; % Daily market return
marketVolatility = 0.012; % Daily market volatility

# Generate with regime switching
regimeProbability = 0.02; # 2% chance of regime change each day
currentRegime = 1; # Start in normal regime

marketReturns = zeros(timeHorizon, 1);

for day = 1:timeHorizon
    # Check for regime change
    if rand() < regimeProbability
        currentRegime = 3 - currentRegime; # Switch between 1 and 2
    end
    
    if currentRegime == 1 # Normal market
        mu = marketExpectedReturn;
        sigma = marketVolatility;
    else # Stressed market
        mu = -0.001; # Negative expected return
        sigma = marketVolatility * 2; # Higher volatility
    end
    
    marketReturns(day) = mu + sigma * randn();
end

end

function volatility = generateGARCHVolatility(timeHorizon, baseVol)
% Generate GARCH(1,1) volatility process

# GARCH parameters
omega = 0.000001;
alpha = 0.1;
beta = 0.85;

volatility = zeros(timeHorizon, 1);
variance = baseVol^2;

for day = 1:timeHorizon
    # GARCH(1,1) equation
    if day > 1
        variance = omega + alpha * (returns_lag^2) + beta * variance;
    end
    
    volatility(day) = sqrt(variance);
    
    if day < timeHorizon
        returns_lag = volatility(day) * randn(); # Store for next iteration
    end
end

# Ensure minimum volatility
volatility = max(volatility, baseVol * 0.5);

end

function factors = generateMarketFactors(timeHorizon)
% Generate market factors (economic indicators)

factors = struct();

# Interest rates
factors.riskFreeRate = 0.02 + 0.01 * randn(timeHorizon, 1) / sqrt(252); # Annual to daily
factors.riskFreeRate = max(factors.riskFreeRate, 0); # Non-negative rates

# VIX-like volatility index
factors.volatilityIndex = 15 + 10 * abs(randn(timeHorizon, 1));

# Economic sentiment
factors.economicSentiment = 50 + 20 * randn(timeHorizon, 1);
factors.economicSentiment = max(0, min(100, factors.economicSentiment));

# Currency factors
factors.usdIndex = 100 + 10 * randn(timeHorizon, 1);

end

function prices = generatePriceData(returns)
% Generate price data from returns

[timeHorizon, numAssets] = size(returns);
prices = zeros(timeHorizon, numAssets);

# Initial prices
prices(1, :) = 100; # Start at $100

# Compound returns to get prices
for day = 2:timeHorizon
    prices(day, :) = prices(day-1, :) .* (1 + returns(day, :));
end

end

function fundamentals = generateFundamentalData(marketData)
% Generate fundamental data for assets

fundamentals = struct();

numAssets = marketData.numAssets;

# Financial metrics
fundamentals.peRatios = 10 + 20 * rand(numAssets, 1);
fundamentals.pbRatios = 0.5 + 3 * rand(numAssets, 1);
fundamentals.debtToEquity = 0.1 + 1.5 * rand(numAssets, 1);
fundamentals.roe = 0.05 + 0.15 * rand(numAssets, 1); # Return on equity
fundamentals.marketCap = 1e9 + 10e9 * rand(numAssets, 1); # Market capitalization

# Growth metrics
fundamentals.revenueGrowth = -0.1 + 0.3 * rand(numAssets, 1); # -10% to +20%
fundamentals.earningsGrowth = -0.2 + 0.5 * rand(numAssets, 1); # -20% to +30%

# Quality scores
fundamentals.qualityScore = rand(numAssets, 1); # 0 to 1

end

function esgFramework = developESGScoringFramework(marketData)
% Develop comprehensive ESG scoring framework

esgFramework = struct();

fprintf('\\textbf{Developing ESG Scoring Framework:}\n');

numAssets = marketData.numAssets;

# ESG components
esgFramework.components = {'Environmental', 'Social', 'Governance'};

# Generate ESG scores
esgFramework.environmentalScores = generateEnvironmentalScores(marketData);
esgFramework.socialScores = generateSocialScores(marketData);
esgFramework.governanceScores = generateGovernanceScores(marketData);

# Combined ESG scores
esgFramework.combinedScores = calculateCombinedESGScores(esgFramework);

# ESG constraints
esgFramework.constraints = defineESGConstraints(marketData);

# ESG benchmarks
esgFramework.benchmarks = defineESGBenchmarks(esgFramework);

fprintf('ESG framework developed with scores for %d assets\n', numAssets);
fprintf('Average ESG score: %.2f (out of 100)\n', mean(esgFramework.combinedScores));

end

function envScores = generateEnvironmentalScores(marketData)
% Generate environmental scores based on sector characteristics

numAssets = marketData.numAssets;
envScores = zeros(numAssets, 1);

for assetIdx = 1:numAssets
    category = marketData.assetCategoryMap{assetIdx};
    
    # Base scores by sector
    switch category
        case 'Technology'
            baseScore = 75 + 15 * randn();
        case 'Energy'
            baseScore = 30 + 20 * randn();
        case 'Utilities'
            baseScore = 50 + 20 * randn();
        case 'Industrial'
            baseScore = 45 + 15 * randn();
        case 'Materials'
            baseScore = 35 + 15 * randn();
        otherwise
            baseScore = 60 + 20 * randn();
    end
    
    # Add company-specific variation
    envScores(assetIdx) = max(0, min(100, baseScore));
end

end

function socialScores = generateSocialScores(marketData)
% Generate social scores

numAssets = marketData.numAssets;
socialScores = zeros(numAssets, 1);

for assetIdx = 1:numAssets
    category = marketData.assetCategoryMap{assetIdx};
    
    switch category
        case 'Healthcare'
            baseScore = 80 + 15 * randn();
        case 'Consumer'
            baseScore = 70 + 15 * randn();
        case 'Financial'
            baseScore = 55 + 20 * randn();
        case 'Technology'
            baseScore = 65 + 20 * randn();
        otherwise
            baseScore = 60 + 15 * randn();
    end
    
    socialScores(assetIdx) = max(0, min(100, baseScore));
end

end

function govScores = generateGovernanceScores(marketData)
% Generate governance scores

numAssets = marketData.numAssets;
govScores = zeros(numAssets, 1);

# Governance generally less sector-dependent
baseScore = 65;
variation = 25;

for assetIdx = 1:numAssets
    # Some correlation with market cap (larger companies tend to have better governance)
    marketCapEffect = log(marketData.fundamentals.marketCap(assetIdx) / 1e9) * 2;
    
    score = baseScore + marketCapEffect + variation * randn();
    govScores(assetIdx) = max(0, min(100, score));
end

end

function combinedScores = calculateCombinedESGScores(esgFramework)
% Calculate combined ESG scores

# Weights for ESG components
envWeight = 0.4;
socialWeight = 0.3;
govWeight = 0.3;

combinedScores = envWeight * esgFramework.environmentalScores + ...
                socialWeight * esgFramework.socialScores + ...
                govWeight * esgFramework.governanceScores;

end

function constraints = defineESGConstraints(marketData)
% Define ESG constraints for portfolio optimization

constraints = struct();

# Minimum ESG score constraint
constraints.minimumESGScore = 60; # Minimum weighted average ESG score

# Sector exclusions
constraints.excludedSectors = {'Energy'}; # Exclude high-carbon sectors

# Maximum allocation to low-ESG assets
constraints.maxLowESGAllocation = 0.1; # Max 10% in assets with ESG < 40

# Minimum allocation to high-ESG assets
constraints.minHighESGAllocation = 0.3; # Min 30% in assets with ESG > 80

end

function benchmarks = defineESGBenchmarks(esgFramework)
% Define ESG benchmarks for comparison

benchmarks = struct();

# Percentile rankings
scores = esgFramework.combinedScores;
benchmarks.percentile25 = prctile(scores, 25);
benchmarks.percentile50 = prctile(scores, 50);
benchmarks.percentile75 = prctile(scores, 75);
benchmarks.percentile90 = prctile(scores, 90);

# Category definitions
benchmarks.categories = struct();
benchmarks.categories.leaders = scores >= benchmarks.percentile90;
benchmarks.categories.performers = scores >= benchmarks.percentile75 & scores < benchmarks.percentile90;
benchmarks.categories.average = scores >= benchmarks.percentile25 & scores < benchmarks.percentile75;
benchmarks.categories.laggards = scores < benchmarks.percentile25;

end

function predictionModels = trainEnsemblePredictionModels(marketData)
% Train ensemble ML models for return and risk prediction

predictionModels = struct();

fprintf('\\textbf{Training Ensemble Prediction Models:}\n');

# Prepare features
features = preparePredictionFeatures(marketData);

# Train return prediction models
predictionModels.returnModels = trainReturnPredictionModels(features, marketData);

# Train volatility prediction models
predictionModels.volatilityModels = trainVolatilityPredictionModels(features, marketData);

# Train correlation prediction models
predictionModels.correlationModels = trainCorrelationPredictionModels(features, marketData);

# Ensemble combination
predictionModels.ensembleWeights = optimizeEnsembleWeights(predictionModels, marketData);

fprintf('Ensemble prediction models trained\n\n');

end

function features = preparePredictionFeatures(marketData)
% Prepare features for ML models

features = struct();

returns = marketData.returns;
prices = marketData.prices;
[timeHorizon, numAssets] = size(returns);

# Technical features
features.technical = struct();

# Lagged returns
lagOrder = 5;
features.technical.laggedReturns = zeros(timeHorizon - lagOrder, numAssets, lagOrder);

for lag = 1:lagOrder
    features.technical.laggedReturns(:, :, lag) = returns(lagOrder + 1 - lag:timeHorizon - lag, :);
end

# Moving averages
windowSizes = [5, 10, 20];
features.technical.movingAverages = zeros(timeHorizon - max(windowSizes), numAssets, length(windowSizes));

for windowIdx = 1:length(windowSizes)
    window = windowSizes(windowIdx);
    for assetIdx = 1:numAssets
        ma = movmean(prices(:, assetIdx), window);
        features.technical.movingAverages(:, assetIdx, windowIdx) = ma(max(windowSizes) + 1:end);
    end
end

# Volatility features
features.technical.realizedVolatility = zeros(timeHorizon - 20, numAssets);

for assetIdx = 1:numAssets
    for day = 21:timeHorizon
        features.technical.realizedVolatility(day - 20, assetIdx) = std(returns(day-19:day, assetIdx));
    end
end

# Fundamental features
features.fundamental = marketData.fundamentals;

# Market factors
features.market = marketData.marketFactors;

end

function returnModels = trainReturnPredictionModels(features, marketData)
% Train models for return prediction

returnModels = struct();

returns = marketData.returns;
[timeHorizon, numAssets] = size(returns);

# Prepare training data
lagOrder = 5;
trainEndIdx = floor(0.8 * timeHorizon);

# Model 1: Linear regression
fprintf('Training linear regression models...\n');
returnModels.linearRegression = trainLinearRegressionModels(features, returns, trainEndIdx);

# Model 2: Random forest
fprintf('Training random forest models...\n');
returnModels.randomForest = trainRandomForestModels(features, returns, trainEndIdx);

# Model 3: Support vector regression
fprintf('Training SVR models...\n');
returnModels.svr = trainSVRModels(features, returns, trainEndIdx);

# Model 4: Neural network
fprintf('Training neural network models...\n');
returnModels.neuralNetwork = trainNeuralNetworkModels(features, returns, trainEndIdx);

end

function linearModels = trainLinearRegressionModels(features, returns, trainEndIdx)
% Train linear regression models

linearModels = struct();

[timeHorizon, numAssets] = size(returns);
lagOrder = 5;

# Prepare feature matrix
featureMatrix = [];

# Add lagged returns
if isfield(features, 'technical') && isfield(features.technical, 'laggedReturns')
    laggedReturns = features.technical.laggedReturns;
    validStartIdx = size(laggedReturns, 1) - (timeHorizon - lagOrder - 1) + 1;
    
    for assetIdx = 1:numAssets
        for lag = 1:lagOrder
            featureMatrix = [featureMatrix, laggedReturns(validStartIdx:end, assetIdx, lag)];
        end
    end
end

# Target returns (next period)
targetReturns = returns(lagOrder + 2:trainEndIdx, :);

# Ensure dimensions match
if size(featureMatrix, 1) > size(targetReturns, 1)
    featureMatrix = featureMatrix(1:size(targetReturns, 1), :);
elseif size(featureMatrix, 1) < size(targetReturns, 1)
    targetReturns = targetReturns(1:size(featureMatrix, 1), :);
end

linearModels.models = cell(numAssets, 1);
linearModels.coefficients = zeros(size(featureMatrix, 2), numAssets);

for assetIdx = 1:numAssets
    if size(featureMatrix, 1) > 0 && size(featureMatrix, 2) > 0
        try
            # Fit linear model
            coefficients = featureMatrix \ targetReturns(:, assetIdx);
            linearModels.coefficients(:, assetIdx) = coefficients;
            
            # Store model
            model = struct();
            model.coefficients = coefficients;
            model.type = 'linear';
            linearModels.models{assetIdx} = model;
        catch
            # Fallback model
            model = struct();
            model.coefficients = zeros(size(featureMatrix, 2), 1);
            model.type = 'fallback';
            linearModels.models{assetIdx} = model;
        end
    else
        # Empty model
        linearModels.models{assetIdx} = struct('type', 'empty');
    end
end

end

function rfModels = trainRandomForestModels(features, returns, trainEndIdx)
% Train random forest models

rfModels = struct();

[timeHorizon, numAssets] = size(returns);
lagOrder = 5;

# Simplified feature preparation
featureMatrix = [];

if isfield(features, 'technical') && isfield(features.technical, 'laggedReturns')
    laggedReturns = features.technical.laggedReturns;
    validStartIdx = size(laggedReturns, 1) - (timeHorizon - lagOrder - 1) + 1;
    
    # Use only first asset's lagged returns as features (simplified)
    featureMatrix = reshape(laggedReturns(validStartIdx:end, 1, :), [], lagOrder);
end

targetReturns = returns(lagOrder + 2:trainEndIdx, :);

# Match dimensions
if size(featureMatrix, 1) > size(targetReturns, 1)
    featureMatrix = featureMatrix(1:size(targetReturns, 1), :);
elseif size(featureMatrix, 1) < size(targetReturns, 1)
    targetReturns = targetReturns(1:size(featureMatrix, 1), :);
end

rfModels.models = cell(numAssets, 1);

for assetIdx = 1:numAssets
    if size(featureMatrix, 1) > 10 && size(featureMatrix, 2) > 0
        try
            # Train random forest
            model = TreeBagger(50, featureMatrix, targetReturns(:, assetIdx), 'Method', 'regression');
            rfModels.models{assetIdx} = model;
        catch
            rfModels.models{assetIdx} = [];
        end
    else
        rfModels.models{assetIdx} = [];
    end
end

end

function svrModels = trainSVRModels(features, returns, trainEndIdx)
% Train support vector regression models

svrModels = struct();

# Similar to random forest but simplified
[timeHorizon, numAssets] = size(returns);
svrModels.models = cell(numAssets, 1);

# For demonstration, create simplified models
for assetIdx = 1:numAssets
    svrModels.models{assetIdx} = struct('type', 'svr', 'trained', false);
end

end

function nnModels = trainNeuralNetworkModels(features, returns, trainEndIdx)
% Train neural network models

nnModels = struct();

# Simplified neural network models
[timeHorizon, numAssets] = size(returns);
nnModels.models = cell(numAssets, 1);

# For demonstration, create simplified models
for assetIdx = 1:numAssets
    nnModels.models{assetIdx} = struct('type', 'neural_network', 'trained', false);
end

end

function volModels = trainVolatilityPredictionModels(features, marketData, trainEndIdx)
% Train volatility prediction models

volModels = struct();

# Implement GARCH and other volatility models (simplified)
volModels.garch = struct('type', 'garch', 'trained', true);
volModels.realized = struct('type', 'realized_vol', 'trained', true);

end

function corrModels = trainCorrelationPredictionModels(features, marketData, trainEndIdx)
% Train correlation prediction models

corrModels = struct();

# Implement DCC-GARCH and other correlation models (simplified)
corrModels.dcc = struct('type', 'dcc_garch', 'trained', true);
corrModels.ewma = struct('type', 'ewma', 'trained', true);

end

function ensembleWeights = optimizeEnsembleWeights(predictionModels, marketData)
% Optimize ensemble combination weights

ensembleWeights = struct();

# Simple equal weighting for demonstration
ensembleWeights.returnModels = struct();
ensembleWeights.returnModels.linearRegression = 0.3;
ensembleWeights.returnModels.randomForest = 0.3;
ensembleWeights.returnModels.svr = 0.2;
ensembleWeights.returnModels.neuralNetwork = 0.2;

ensembleWeights.volatilityModels = struct();
ensembleWeights.volatilityModels.garch = 0.6;
ensembleWeights.volatilityModels.realized = 0.4;

end

function portfolioOpt = implementMultiObjectivePortfolioOptimization(marketData, esgFramework, predictionModels)
% Implement multi-objective portfolio optimization

portfolioOpt = struct();

fprintf('\\textbf{Implementing Multi-Objective Portfolio Optimization:}\n');

# Generate expected returns and covariance matrix
expectedReturns = generateExpectedReturns(marketData, predictionModels);
covarianceMatrix = generateCovarianceMatrix(marketData, predictionModels);

# Solve multi-objective optimization
paretoFrontier = solveParetoOptimization(expectedReturns, covarianceMatrix, esgFramework);

# Select final portfolio using utility function
finalPortfolio = selectFinalPortfolio(paretoFrontier, esgFramework);

portfolioOpt.expectedReturns = expectedReturns;
portfolioOpt.covarianceMatrix = covarianceMatrix;
portfolioOpt.paretoFrontier = paretoFrontier;
portfolioOpt.finalPortfolio = finalPortfolio;

fprintf('Multi-objective portfolio optimization completed\n\n');

end

function expectedReturns = generateExpectedReturns(marketData, predictionModels)
% Generate expected returns using ensemble predictions

returns = marketData.returns;
numAssets = marketData.numAssets;

# Simple historical mean (baseline)
historicalMeans = mean(returns, 1)';

# Ensemble prediction (simplified)
ensemblePredictions = historicalMeans * 1.1; # Slight adjustment

expectedReturns = ensemblePredictions;

end

function covMatrix = generateCovarianceMatrix(marketData, predictionModels)
% Generate covariance matrix

returns = marketData.returns;

# Sample covariance matrix
covMatrix = cov(returns);

# Shrinkage towards diagonal (Ledoit-Wolf)
shrinkageParameter = 0.1;
targetMatrix = diag(diag(covMatrix));

covMatrix = (1 - shrinkageParameter) * covMatrix + shrinkageParameter * targetMatrix;

end

function paretoFrontier = solveParetoOptimization(expectedReturns, covMatrix, esgFramework)
% Solve Pareto optimization for return-risk-ESG

paretoFrontier = struct();

numAssets = length(expectedReturns);
numPoints = 20; # Number of Pareto points

# Initialize results storage
paretoFrontier.portfolios = cell(numPoints, 1);
paretoFrontier.returns = zeros(numPoints, 1);
paretoFrontier.risks = zeros(numPoints, 1);
paretoFrontier.esgScores = zeros(numPoints, 1);

# Weight combinations for objectives
returnWeights = linspace(0.2, 0.8, numPoints);
riskWeights = linspace(0.1, 0.6, numPoints);
esgWeights = 1 - returnWeights - riskWeights;
esgWeights = max(esgWeights, 0.1); # Minimum ESG weight

validPointCount = 0;

for pointIdx = 1:numPoints
    wReturn = returnWeights(pointIdx);
    wRisk = riskWeights(pointIdx);
    wESG = esgWeights(pointIdx);
    
    # Normalize weights
    totalWeight = wReturn + wRisk + wESG;
    wReturn = wReturn / totalWeight;
    wRisk = wRisk / totalWeight;
    wESG = wESG / totalWeight;
    
    # Solve single-objective optimization
    portfolio = solveSingleObjectiveOptimization(expectedReturns, covMatrix, esgFramework, 
        wReturn, wRisk, wESG);
    
    if ~isempty(portfolio)
        validPointCount = validPointCount + 1;
        
        # Calculate portfolio metrics
        portfolioReturn = expectedReturns' * portfolio;
        portfolioRisk = sqrt(portfolio' * covMatrix * portfolio);
        portfolioESG = esgFramework.combinedScores' * portfolio;
        
        paretoFrontier.portfolios{validPointCount} = portfolio;
        paretoFrontier.returns(validPointCount) = portfolioReturn;
        paretoFrontier.risks(validPointCount) = portfolioRisk;
        paretoFrontier.esgScores(validPointCount) = portfolioESG;
    end
end

# Trim to valid points
paretoFrontier.portfolios = paretoFrontier.portfolios(1:validPointCount);
paretoFrontier.returns = paretoFrontier.returns(1:validPointCount);
paretoFrontier.risks = paretoFrontier.risks(1:validPointCount);
paretoFrontier.esgScores = paretoFrontier.esgScores(1:validPointCount);
paretoFrontier.numPoints = validPointCount;

end

function portfolio = solveSingleObjectiveOptimization(expectedReturns, covMatrix, esgFramework, 
    wReturn, wRisk, wESG)
% Solve single objective optimization

numAssets = length(expectedReturns);

# Objective function coefficients
# Maximize: w_return * return - w_risk * risk + w_esg * ESG
# Convert to minimization: -w_return * return + w_risk * risk - w_esg * ESG

objectiveCoeffs = -wReturn * expectedReturns - wESG * esgFramework.combinedScores;

# Quadratic term (risk)
H = wRisk * covMatrix;

# Constraints
# Portfolio weights sum to 1
Aeq = ones(1, numAssets);
beq = 1;

# Long-only constraints
lb = zeros(numAssets, 1);
ub = ones(numAssets, 1);

# ESG constraints
A = [];
b = [];

# Minimum ESG score constraint
if isfield(esgFramework.constraints, 'minimumESGScore')
    minESG = esgFramework.constraints.minimumESGScore;
    A = [-esgFramework.combinedScores'];
    b = -minESG;
end

# Solve quadratic programming problem
options = optimoptions('quadprog', 'Display', 'off');

try
    [portfolio, ~, exitFlag] = quadprog(2*H, objectiveCoeffs, A, b, Aeq, beq, lb, ub, [], options);
    
    if exitFlag <= 0
        portfolio = [];
    end
catch
    portfolio = [];
end

end

function finalPortfolio = selectFinalPortfolio(paretoFrontier, esgFramework)
% Select final portfolio from Pareto frontier

finalPortfolio = struct();

if paretoFrontier.numPoints == 0
    finalPortfolio.weights = [];
    finalPortfolio.feasible = false;
    return;
end

# Utility function approach
# U = return - 0.5 * risk^2 + 0.01 * ESG
utilities = paretoFrontier.returns - 0.5 * paretoFrontier.risks.^2 + 0.01 * paretoFrontier.esgScores;

[~, bestIdx] = max(utilities);

finalPortfolio.weights = paretoFrontier.portfolios{bestIdx};
finalPortfolio.expectedReturn = paretoFrontier.returns(bestIdx);
finalPortfolio.expectedRisk = paretoFrontier.risks(bestIdx);
finalPortfolio.esgScore = paretoFrontier.esgScores(bestIdx);
finalPortfolio.utility = utilities(bestIdx);
finalPortfolio.feasible = true;

end

function robustOpt = applyRobustOptimizationTechniques(portfolioOpt, marketData)
% Apply robust optimization techniques

robustOpt = struct();

fprintf('\\textbf{Applying Robust Optimization Techniques:}\n');

if ~portfolioOpt.finalPortfolio.feasible
    robustOpt.feasible = false;
    return;
end

# Uncertainty sets for expected returns and covariance
uncertaintySet = defineUncertaintySet(marketData, portfolioOpt);

# Robust counterpart optimization
robustPortfolio = solveRobustCounterpart(portfolioOpt, uncertaintySet);

# Worst-case analysis
worstCaseAnalysis = performWorstCaseAnalysis(robustPortfolio, uncertaintySet);

robustOpt.uncertaintySet = uncertaintySet;
robustOpt.robustPortfolio = robustPortfolio;
robustOpt.worstCaseAnalysis = worstCaseAnalysis;
robustOpt.feasible = true;

fprintf('Robust optimization techniques applied\n\n');

end

function uncertaintySet = defineUncertaintySet(marketData, portfolioOpt)
% Define uncertainty sets for robust optimization

uncertaintySet = struct();

expectedReturns = portfolioOpt.expectedReturns;
covMatrix = portfolioOpt.covarianceMatrix;

# Box uncertainty for expected returns
returnUncertainty = 0.1; # 10% uncertainty
uncertaintySet.returnLowerBounds = expectedReturns * (1 - returnUncertainty);
uncertaintySet.returnUpperBounds = expectedReturns * (1 + returnUncertainty);

# Ellipsoidal uncertainty for covariance matrix
uncertaintySet.covarianceBase = covMatrix;
uncertaintySet.covarianceUncertaintyLevel = 0.2; # 20% uncertainty

end

function robustPortfolio = solveRobustCounterpart(portfolioOpt, uncertaintySet)
% Solve robust counterpart problem

robustPortfolio = struct();

numAssets = length(portfolioOpt.expectedReturns);

# Robust objective: maximize worst-case return - worst-case risk
# This is a simplified robust formulation

# Use conservative estimates
conservativeReturns = uncertaintySet.returnLowerBounds;
conservativeCovariance = uncertaintySet.covarianceBase * (1 + uncertaintySet.covarianceUncertaintyLevel);

# Solve conservative portfolio optimization
H = conservativeCovariance;
f = -conservativeReturns; # Negative for maximization

# Constraints
Aeq = ones(1, numAssets);
beq = 1;
lb = zeros(numAssets, 1);
ub = ones(numAssets, 1);

options = optimoptions('quadprog', 'Display', 'off');

try
    [weights, ~, exitFlag] = quadprog(2*H, f, [], [], Aeq, beq, lb, ub, [], options);
    
    if exitFlag > 0
        robustPortfolio.weights = weights;
        robustPortfolio.conservativeReturn = conservativeReturns' * weights;
        robustPortfolio.conservativeRisk = sqrt(weights' * conservativeCovariance * weights);
        robustPortfolio.feasible = true;
    else
        robustPortfolio.feasible = false;
    end
catch
    robustPortfolio.feasible = false;
end

end

function worstCase = performWorstCaseAnalysis(robustPortfolio, uncertaintySet)
% Perform worst-case scenario analysis

worstCase = struct();

if ~robustPortfolio.feasible
    worstCase.feasible = false;
    return;
end

weights = robustPortfolio.weights;

# Worst-case return (minimum possible)
worstCaseReturn = uncertaintySet.returnLowerBounds' * weights;

# Worst-case risk (maximum possible covariance)
worstCaseCovariance = uncertaintySet.covarianceBase * (1 + uncertaintySet.covarianceUncertaintyLevel);
worstCaseRisk = sqrt(weights' * worstCaseCovariance * weights);

worstCase.return = worstCaseReturn;
worstCase.risk = worstCaseRisk;
worstCase.sharpeRatio = worstCaseReturn / worstCaseRisk;
worstCase.feasible = true;

end

function rebalancing = developDynamicRebalancingStrategy(robustOpt, predictionModels)
% Develop dynamic rebalancing strategy

rebalancing = struct();

fprintf('\\textbf{Developing Dynamic Rebalancing Strategy:}\n');

if ~robustOpt.feasible
    rebalancing.feasible = false;
    return;
end

# Rebalancing triggers
rebalancing.triggers = defineRebalancingTriggers();

# Market regime detection
rebalancing.regimeDetection = implementRegimeDetection(predictionModels);

# Dynamic allocation rules
rebalancing.allocationRules = defineDynamicAllocationRules();

# Transaction cost model
rebalancing.transactionCosts = defineTransactionCostModel();

rebalancing.feasible = true;

fprintf('Dynamic rebalancing strategy developed\n\n');

end

function triggers = defineRebalancingTriggers()
% Define rebalancing triggers

triggers = struct();

# Time-based triggers
triggers.monthlyRebalancing = true;
triggers.quarterlyReview = true;

# Threshold-based triggers
triggers.allocationDriftThreshold = 0.05; # 5% drift from target
triggers.volatilityChangeThreshold = 0.2; # 20% change in volatility

# Market-based triggers
triggers.marketRegimeChange = true;
triggers.correlationBreakdown = true;

end

function regimeDetection = implementRegimeDetection(predictionModels)
% Implement market regime detection

regimeDetection = struct();

# Simple regime detection based on volatility
regimeDetection.method = 'volatility_based';
regimeDetection.lowVolThreshold = 0.01; # 1% daily volatility
regimeDetection.highVolThreshold = 0.03; # 3% daily volatility

# Regime states
regimeDetection.states = {'Low Volatility', 'Normal', 'High Volatility'};

end

function allocationRules = defineDynamicAllocationRules()
% Define dynamic allocation rules

allocationRules = struct();

# Regime-dependent allocations
allocationRules.lowVolatility = struct();
allocationRules.lowVolatility.riskBudget = 1.2; # Increase risk in low vol periods

allocationRules.highVolatility = struct();
allocationRules.highVolatility.riskBudget = 0.7; # Reduce risk in high vol periods

# ESG tilting rules
allocationRules.esgTilting = struct();
allocationRules.esgTilting.enabled = true;
allocationRules.esgTilting.tiltStrength = 0.1; # 10% tilt towards high ESG

end

function transactionCosts = defineTransactionCostModel()
% Define transaction cost model

transactionCosts = struct();

# Linear transaction costs
transactionCosts.proportionalCost = 0.001; # 10 basis points

# Fixed costs
transactionCosts.fixedCost = 5; # ?5 per transaction

# Market impact model
transactionCosts.marketImpactCoeff = 0.0001; # Square root impact

end

function backtesting = validateThroughComprehensiveBacktesting(rebalancing, marketData, esgFramework)
% Validate through comprehensive backtesting

backtesting = struct();

fprintf('\\textbf{Validating through Comprehensive Backtesting:}\n');

if ~rebalancing.feasible
    backtesting.feasible = false;
    return;
end

# Backtesting parameters
backtestingPeriod = floor(0.8 * marketData.timeHorizon); # Use last 20% for testing
lookbackWindow = 252; # 1 year lookback

# Performance tracking
backtesting.portfolioReturns = performBacktestingSimulation(marketData, esgFramework, backtestingPeriod);

# Performance metrics
backtesting.performanceMetrics = calculateBacktestingMetrics(backtesting.portfolioReturns, marketData);

# Risk analysis
backtesting.riskAnalysis = performBacktestingRiskAnalysis(backtesting.portfolioReturns);

# ESG tracking
backtesting.esgTracking = trackESGPerformance(backtesting.portfolioReturns, esgFramework);

backtesting.feasible = true;

fprintf('Comprehensive backtesting completed\n\n');

end

function portfolioReturns = performBacktestingSimulation(marketData, esgFramework, backtestingPeriod)
% Perform backtesting simulation

returns = marketData.returns;
[totalPeriods, numAssets] = size(returns);

startIdx = totalPeriods - backtestingPeriod + 1;
testReturns = returns(startIdx:end, :);

# Simple buy-and-hold strategy with equal ESG weighting
esgScores = esgFramework.combinedScores;
weights = esgScores / sum(esgScores); # ESG-weighted portfolio

# Calculate portfolio returns
portfolioReturns = testReturns * weights;

end

function metrics = calculateBacktestingMetrics(portfolioReturns, marketData)
% Calculate comprehensive backtesting metrics

metrics = struct();

# Basic metrics
metrics.totalReturn = prod(1 + portfolioReturns) - 1;
metrics.annualizedReturn = (1 + metrics.totalReturn)^(252 / length(portfolioReturns)) - 1;
metrics.volatility = std(portfolioReturns) * sqrt(252);
metrics.sharpeRatio = metrics.annualizedReturn / metrics.volatility;

# Risk-adjusted metrics
metrics.maxDrawdown = calculateMaxDrawdown(portfolioReturns);
metrics.calmarRatio = metrics.annualizedReturn / abs(metrics.maxDrawdown);

# Downside metrics
metrics.downsideDeviation = calculateDownsideDeviation(portfolioReturns);
metrics.sortinoRatio = metrics.annualizedReturn / metrics.downsideDeviation;

end

function maxDD = calculateMaxDrawdown(returns)
% Calculate maximum drawdown

cumulativeReturns = cumprod(1 + returns);
runningMax = cummax(cumulativeReturns);
drawdown = (cumulativeReturns - runningMax) ./ runningMax;
maxDD = min(drawdown);

end

function downsideDeviation = calculateDownsideDeviation(returns)
% Calculate downside deviation

negativeReturns = returns(returns < 0);
if ~isempty(negativeReturns)
    downsideDeviation = std(negativeReturns) * sqrt(252);
else
    downsideDeviation = 0;
end

end

function riskAnalysis = performBacktestingRiskAnalysis(portfolioReturns)
% Perform risk analysis on backtesting results

riskAnalysis = struct();

# VaR and CVaR
riskAnalysis.var95 = prctile(portfolioReturns, 5);
riskAnalysis.cvar95 = mean(portfolioReturns(portfolioReturns <= riskAnalysis.var95));

# Stress testing
riskAnalysis.stressTesting = performStressTesting(portfolioReturns);

end

function stressTesting = performStressTesting(portfolioReturns)
% Perform stress testing

stressTesting = struct();

# Worst 5% scenarios
worstScenarios = sort(portfolioReturns);
worstPercentile = floor(0.05 * length(worstScenarios));

stressTesting.worst5Percent = worstScenarios(1:worstPercentile);
stressTesting.averageWorstCase = mean(stressTesting.worst5Percent);

end

function esgTracking = trackESGPerformance(portfolioReturns, esgFramework)
% Track ESG performance

esgTracking = struct();

# ESG score evolution (simplified)
esgTracking.averageESGScore = mean(esgFramework.combinedScores);
esgTracking.esgPerformanceCorrelation = 0.1; # Simplified correlation

end

function results = consolidatePortfolioOptimizationResults(marketData, esgFramework, predictionModels, 
    portfolioOpt, robustOpt, rebalancing, backtesting)
% Consolidate all portfolio optimization results

results = struct();

# Store all components
results.marketData = marketData;
results.esgFramework = esgFramework;
results.predictionModels = predictionModels;
results.portfolioOptimisation = portfolioOpt;
results.robustOptimisation = robustOpt;
results.rebalancingStrategy = rebalancing;
results.backtesting = backtesting;

# Executive summary
results.executiveSummary = struct();

if portfolioOpt.finalPortfolio.feasible && backtesting.feasible
    results.executiveSummary.feasible = true;
    results.executiveSummary.recommendedWeights = portfolioOpt.finalPortfolio.weights;
    results.executiveSummary.expectedReturn = portfolioOpt.finalPortfolio.expectedReturn * 252; # Annualized
    results.executiveSummary.expectedRisk = portfolioOpt.finalPortfolio.expectedRisk * sqrt(252); # Annualized
    results.executiveSummary.esgScore = portfolioOpt.finalPortfolio.esgScore;
    results.executiveSummary.backtestReturn = backtesting.performanceMetrics.annualizedReturn;
    results.executiveSummary.backtestSharpe = backtesting.performanceMetrics.sharpeRatio;
    results.executiveSummary.maxDrawdown = backtesting.performanceMetrics.maxDrawdown;
else
    results.executiveSummary.feasible = false;
end

end

function generatePortfolioOptimizationVisualisations(results)
% Generate comprehensive portfolio optimization visualisations

if ~results.executiveSummary.feasible
    fprintf('Cannot generate visualisations - portfolio optimization not feasible\n');
    return;
end

figure('Position', [100, 100, 1500, 1000], 'Name', 'AI-Driven Portfolio Optimization Results');

# Subplot 1: Optimal portfolio weights
subplot(2, 3, 1);
weights = results.executiveSummary.recommendedWeights;
assetNames = results.marketData.assetNames;

# Show top 10 holdings
[sortedWeights, sortIndices] = sort(weights, 'descend');
top10Weights = sortedWeights(1:10);
top10Names = assetNames(sortIndices(1:10));

bar(top10Weights);
set(gca, 'XTickLabel', top10Names);
ylabel('Portfolio Weight');
title('\\textbf{Top 10 Portfolio Holdings}');
xtickangle(45);
grid on;

# Subplot 2: Pareto frontier
subplot(2, 3, 2);
if isfield(results.portfolioOptimisation, 'paretoFrontier')
    paretoFrontier = results.portfolioOptimisation.paretoFrontier;
    
    scatter(paretoFrontier.risks * sqrt(252) * 100, paretoFrontier.returns * 252 * 100, 
        60, paretoFrontier.esgScores, 'filled');
    colorbar;
    xlabel('Risk (% annualized)');
    ylabel('Return (% annualized)');
    title('\\textbf{Efficient Frontier (colored by ESG)}');
    
    # Highlight selected portfolio
    hold on;
    scatter(results.executiveSummary.expectedRisk * 100, results.executiveSummary.expectedReturn * 100, 
        120, 'r', 'filled', 'MarkerEdgeColor', 'k');
    grid on;
end

# Subplot 3: ESG score distribution
subplot(2, 3, 3);
esgScores = results.esgFramework.combinedScores;
portfolioESGWeighted = weights' * esgScores;

histogram(esgScores, 15, 'Normalization', 'probability', 'FaceColor', [0.6, 0.8, 1]);
hold on;
xline(portfolioESGWeighted, 'r-', 'LineWidth', 3, 'DisplayName', 'Portfolio ESG');
xlabel('ESG Score');
ylabel('Probability');
title('\\textbf{ESG Score Distribution}');
legend('Assets', 'Portfolio Average', 'Location', 'best');
grid on;

# Subplot 4: Sector allocation
subplot(2, 3, 4);
categories = results.marketData.assetCategories;
sectorWeights = zeros(length(categories), 1);

for categoryIdx = 1:length(categories)
    category = categories{categoryIdx};
    categoryAssets = strcmp(results.marketData.assetCategoryMap, category);
    sectorWeights(categoryIdx) = sum(weights(categoryAssets));
end

pie(sectorWeights, categories);
title('\\textbf{Sector Allocation}');

# Subplot 5: Backtesting performance
subplot(2, 3, 5);
if results.backtesting.feasible
    portfolioReturns = results.backtesting.portfolioReturns;
    cumulativeReturns = cumprod(1 + portfolioReturns);
    
    timeAxis = 1:length(cumulativeReturns);
    plot(timeAxis, cumulativeReturns, 'b-', 'LineWidth', 2);
    xlabel('Trading Days');
    ylabel('Cumulative Return');
    title('\\textbf{Backtesting Performance}');
    grid on;
    
    # Add performance statistics
    finalReturn = cumulativeReturns(end) - 1;
    text(0.1, 0.9, sprintf('Total Return: %.1f%%', finalReturn * 100), 
         'Units', 'normalized', 'FontSize', 10);
    text(0.1, 0.8, sprintf('Sharpe Ratio: %.2f', results.executiveSummary.backtestSharpe), 
         'Units', 'normalized', 'FontSize', 10);
end

# Subplot 6: Risk metrics
subplot(2, 3, 6);
if results.backtesting.feasible
    metrics = results.backtesting.performanceMetrics;
    
    riskMetricNames = {'Volatility', 'Max Drawdown', 'VaR 95%', 'Downside Dev'};
    riskMetricValues = [
        metrics.volatility * 100;
        abs(metrics.maxDrawdown) * 100;
        abs(results.backtesting.riskAnalysis.var95) * 100;
        metrics.downsideDeviation * 100
    ];
    
    bar(riskMetricValues, 'FaceColor', [0.8, 0.4, 0.4]);
    set(gca, 'XTickLabel', riskMetricNames);
    ylabel('Risk Metric (%)');
    title('\\textbf{Risk Profile}');
    xtickangle(45);
    grid on;
end

end

function displayInvestmentRecommendations(results)
% Display comprehensive investment recommendations

fprintf('\\textbf{AI-DRIVEN PORTFOLIO OPTIMIZATION RECOMMENDATIONS}\n');
fprintf('========================================================\n\n');

if ~results.executiveSummary.feasible
    fprintf('Portfolio optimization was not successful\n');
    return;
end

# Executive Summary
summary = results.executiveSummary;
fprintf('\\textbf{Executive Summary:}\n');
fprintf('Expected Annual Return: %.2f%%\n', summary.expectedReturn * 100);
fprintf('Expected Annual Risk: %.2f%%\n', summary.expectedRisk * 100);
fprintf('Portfolio ESG Score: %.1f (out of 100)\n', summary.esgScore);
fprintf('Backtested Annual Return: %.2f%%\n', summary.backtestReturn * 100);
fprintf('Backtested Sharpe Ratio: %.2f\n', summary.backtestSharpe);
fprintf('Maximum Drawdown: %.2f%%\n', abs(summary.maxDrawdown) * 100);

# Portfolio Composition
weights = summary.recommendedWeights;
assetNames = results.marketData.assetNames;

fprintf('\n\\textbf{Top Portfolio Holdings:}\n');
[sortedWeights, sortIndices] = sort(weights, 'descend');

for holdingIdx = 1:min(10, length(sortedWeights))
    assetIdx = sortIndices(holdingIdx);
    assetName = assetNames{assetIdx};
    weight = sortedWeights(holdingIdx);
    esgScore = results.esgFramework.combinedScores(assetIdx);
    
    fprintf('%d. %s: %.1f%% (ESG: %.1f)\n', holdingIdx, assetName, weight * 100, esgScore);
end

# ESG Analysis
fprintf('\n\\textbf{ESG Analysis:}\n');
esgComponents = results.esgFramework;
portfolioEnvScore = weights' * esgComponents.environmentalScores;
portfolioSocialScore = weights' * esgComponents.socialScores;
portfolioGovScore = weights' * esgComponents.governanceScores;

fprintf('Portfolio Environmental Score: %.1f\n', portfolioEnvScore);
fprintf('Portfolio Social Score: %.1f\n', portfolioSocialScore);
fprintf('Portfolio Governance Score: %.1f\n', portfolioGovScore);
fprintf('Overall ESG Score: %.1f\n', summary.esgScore);

# Risk Analysis
fprintf('\n\\textbf{Risk Analysis:}\n');
if results.backtesting.feasible
    riskAnalysis = results.backtesting.riskAnalysis;
    fprintf('Value at Risk (95%%): %.2f%%\n', abs(riskAnalysis.var95) * 100);
    fprintf('Conditional VaR (95%%): %.2f%%\n', abs(riskAnalysis.cvar95) * 100);
    
    metrics = results.backtesting.performanceMetrics;
    fprintf('Sortino Ratio: %.2f\n', metrics.sortinoRatio);
    fprintf('Calmar Ratio: %.2f\n', metrics.calmarRatio);
end

# Strategic Recommendations
fprintf('\n\\textbf{Strategic Recommendations:}\n');

if summary.esgScore >= 75
    fprintf('1. Strong ESG profile - suitable for sustainable investment mandates\n');
elseif summary.esgScore >= 60
    fprintf('1. Good ESG profile - meets most sustainable investment criteria\n');
else
    fprintf('1. ESG profile below target - consider increasing ESG allocation\n');
end

if summary.backtestSharpe > 1.5
    fprintf('2. Excellent risk-adjusted returns demonstrated\n');
elseif summary.backtestSharpe > 1.0
    fprintf('2. Good risk-adjusted returns - suitable for most investment objectives\n');
elseif summary.backtestSharpe > 0.5
    fprintf('2. Moderate risk-adjusted returns - monitor performance closely\n');
else
    fprintf('2. Below-target risk-adjusted returns - consider strategy refinement\n');
end

if abs(summary.maxDrawdown) < 0.1
    fprintf('3. Low maximum drawdown indicates good downside protection\n');
elseif abs(summary.maxDrawdown) < 0.2
    fprintf('3. Moderate maximum drawdown - acceptable for most risk profiles\n');
else
    fprintf('3. High maximum drawdown - implement additional risk controls\n');
end

% Implementation Guidelines
fprintf('\n\\textbf{Implementation Guidelines:}\n');
fprintf('Phase 1 (Month 1): Establish initial portfolio allocation\n');
fprintf('Phase 2 (Month 2-3): Monitor performance and ESG metrics\n');
fprintf('Phase 3 (Month 3+): Implement dynamic rebalancing strategy\n');

% Risk Management
fprintf('\n\\textbf{Risk Management Recommendations:}\n');
fprintf('1. Implement monthly portfolio rebalancing\n');
fprintf('2. Monitor ESG score changes and sector concentration\n');
fprintf('3. Establish stop-loss triggers for individual positions\n');
fprintf('4. Conduct quarterly stress testing and scenario analysis\n');

% Technology Integration
fprintf('\n\\textbf{Technology Enhancement Opportunities:}\n');
fprintf('1. Deploy real-time ESG monitoring and alert systems\n');
fprintf('2. Implement automated rebalancing based on market regimes\n');
fprintf('3. Integrate alternative data sources for enhanced predictions\n');
fprintf('4. Develop client reporting dashboard with sustainability metrics\n');

end
