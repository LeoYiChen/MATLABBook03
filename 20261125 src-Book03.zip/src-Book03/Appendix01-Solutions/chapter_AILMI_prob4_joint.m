%% chapter_AILMI_prob4_joint.m
% Joint multi-task learning for entities and relations.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AILMI_prob4_joint
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [entityLoss, relationLoss] = computeJointLoss(predictions, labels, lambda)
    % Compute combined loss for multi-task learning
    % predictions: struct with 'entities' and 'relations' fields
    % labels: struct with ground truth
    % lambda: relation loss weight
    
    % Entity recognition loss (CRF negative log-likelihood)
    entityLogProbs = predictions.entities;
    trueEntitySeq = labels.entities;
    entityLoss = -logProbSequence(entityLogProbs, trueEntitySeq);
    
    % Relation extraction loss (cross-entropy)
    relationLogits = predictions.relations;
    trueRelations = labels.relations;
    relationLoss = crossentropy(relationLogits, trueRelations);
    
    % Combined loss
    totalLoss = entityLoss + lambda * relationLoss;
end
