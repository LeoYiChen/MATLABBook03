%% p2.m
% MATLABBook03_ChapterAIBHS_Problem02.m
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : p2
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function MATLABBook03_ChapterAIBHS_Problem02
% Purpose: BiLSTM secondary-structure prediction (synthetic).
% Author: Dr Leo Chen. R2024b + Deep Learning Toolbox. v1.0 2025-06-01.
    rng(0); numSeq = 200; aa = 20; names = ["H","E","C"];
    X = cell(numSeq,1); Y = cell(numSeq,1);
    for s = 1:numSeq
        L = randi([40 80]); r = randi(aa,1,L); oneHot = full(ind2vec(r,aa));
        sig = movmean(mean(oneHot(1:7,:),1),5); lab = 3*ones(1,L);
        lab(sig>quantile(sig,.66))=1; lab(sig<quantile(sig,.33))=2;
        X{s}=oneHot; Y{s}=categorical(names(lab));
    end
    sp = round(0.8*numSeq);
    layers=[sequenceInputLayer(aa); bilstmLayer(64,'OutputMode','sequence');
            fullyConnectedLayer(3); softmaxLayer; classificationLayer];
    opt=trainingOptions('adam','MaxEpochs',15,'Verbose',false,'Plots','none');
    net=trainNetwork(X(1:sp),Y(1:sp),layers,opt);
    pred=classify(net,X(sp+1:end)); tru=Y(sp+1:end); correct=0; total=0;
    for k=1:numel(pred), correct=correct+sum(pred{k}==tru{k}); total=total+numel(tru{k}); end
    fprintf('Q3 accuracy: %.3f\n', correct/total);
end
