%% p2s.m
% BiLSTM layer syntax.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : p2s
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
layers = [sequenceInputLayer(f); bilstmLayer(h,'OutputMode','sequence'); ...
          fullyConnectedLayer(c); softmaxLayer; classificationLayer];
