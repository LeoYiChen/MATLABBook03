%% chapter_AICSS_problem10_benchmarking.m
% Integrated benchmarking and performance evaluation framework.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AICSS_problem10_benchmarking
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function benchmarkResults = executeIntegratedBenchmarkingFramework(systemsUnderTest, benchmarkSpecification, evaluationProtocol)
    % Comprehensive integrated benchmarking and performance evaluation framework
    % Author: Dr Leo Chen
    % Version: 1.0 - Initial implementation
    % Date: December 2024
    
    fprintf('Executing integrated benchmarking framework...\n');
    fprintf('Systems under test: %d\n', length(systemsUnderTest));
    
    % Initialize results structure
    benchmarkResults = struct();
    benchmarkResults.timestamp = datetime('now');
    benchmarkResults.benchmarkSpecification = benchmarkSpecification;
    benchmarkResults.evaluationProtocol = evaluationProtocol;
    benchmarkResults.systemsUnderTest = systemsUnderTest;
    
    % Validate benchmark specification
    specificationValidation = validateBenchmarkSpecification(benchmarkSpecification);
    benchmarkResults.specificationValidation = specificationValidation;
    
    if ~specificationValidation.isValid
        error('Benchmark specification validation failed: %s', specificationValidation.errorMessage);
    end
    
    % Initialize benchmark datasets and scenarios
    benchmarkData = initializeBenchmarkData(benchmarkSpecification);
    benchmarkResults.benchmarkData = benchmarkData;
    
    % Execute comprehensive evaluation for each system
    numberOfSystems = length(systemsUnderTest);
    systemResults = cell(numberOfSystems, 1);
    
    for systemIndex = 1:numberOfSystems
        currentSystem = systemsUnderTest{systemIndex};
        fprintf('Evaluating system: %s\n', currentSystem.name);
        
        % Execute comprehensive system evaluation
        systemEvaluation = evaluateSystemComprehensively(currentSystem, benchmarkData, evaluationProtocol);
        systemResults{systemIndex} = systemEvaluation;
        
        % Display progress
        fprintf('System %d/%d completed. Overall score: %.3f\n', ...
                systemIndex, numberOfSystems, systemEvaluation.overallScore);
    end
    
    benchmarkResults.systemResults = systemResults;
    
    % Perform comparative analysis
    comparativeAnalysis = performComparativeAnalysis(systemResults, benchmarkSpecification);
    benchmarkResults.comparativeAnalysis = comparativeAnalysis;
    
    % Statistical significance testing
    statisticalAnalysis = performStatisticalAnalysis(systemResults, evaluationProtocol);
    benchmarkResults.statisticalAnalysis = statisticalAnalysis;
    
    % Generate performance rankings
    performanceRankings = generatePerformanceRankings(systemResults, benchmarkSpecification);
    benchmarkResults.performanceRankings = performanceRankings;
    
    % Analyse benchmark coverage and completeness
    benchmarkCoverage = analyseBenchmarkCoverage(systemResults, benchmarkSpecification);
    benchmarkResults.benchmarkCoverage = benchmarkCoverage;
    
    % Generate comprehensive visualisation
    generateBenchmarkingvisualisation(benchmarkResults);
    
    % Create benchmark report
    benchmarkReport = generateBenchmarkReport(benchmarkResults);
    benchmarkResults.benchmarkReport = benchmarkReport;
    
    % Validate benchmark reproducibility
    reproducibilityValidation = validateBenchmarkReproducibility(benchmarkResults);
    benchmarkResults.reproducibilityValidation = reproducibilityValidation;
    
    % Save benchmark results
    saveBenchmarkResults(benchmarkResults);
    
    fprintf('Integrated benchmarking framework execution completed.\n');
end

function systemEvaluation = evaluateSystemComprehensively(system, benchmarkData, protocol)
    % Comprehensive evaluation of a single system across all benchmark dimensions
    
    systemEvaluation = struct();
    systemEvaluation.systemName = system.name;
    systemEvaluation.evaluationTimestamp = datetime('now');
    
    % Security performance evaluation
    securityEvaluation = evaluateSecurityPerformance(system, benchmarkData.securityDatasets, protocol.security);
    systemEvaluation.securityPerformance = securityEvaluation;
    
    % Safety performance evaluation
    safetyEvaluation = evaluateSafetyPerformance(system, benchmarkData.safetyDatasets, protocol.safety);
    systemEvaluation.safetyPerformance = safetyEvaluation;
    
    % Efficiency and scalability evaluation
    efficiencyEvaluation = evaluateEfficiencyPerformance(system, benchmarkData.scalabilityTests, protocol.efficiency);
    systemEvaluation.efficiencyPerformance = efficiencyEvaluation;
    
    % Robustness evaluation
    robustnessEvaluation = evaluateRobustnessPerformance(system, benchmarkData.robustnessTests, protocol.robustness);
    systemEvaluation.robustnessPerformance = robustnessEvaluation;
    
    % Usability and interpretability evaluation
    usabilityEvaluation = evaluateUsabilityPerformance(system, benchmarkData.usabilityTests, protocol.usability);
    systemEvaluation.usabilityPerformance = usabilityEvaluation;
    
    % Integration performance evaluation
    integrationEvaluation = evaluateIntegrationPerformance(system, benchmarkData.integrationTests, protocol.integration);
    systemEvaluation.integrationPerformance = integrationEvaluation;
    
    % Regulatory compliance evaluation
    complianceEvaluation = evaluateRegulatoryCompliance(system, benchmarkData.complianceTests, protocol.compliance);
    systemEvaluation.compliancePerformance = complianceEvaluation;
    
    % Calculate overall weighted score
    overallScore = calculateOverallScore(systemEvaluation, protocol.weightingScheme);
    systemEvaluation.overallScore = overallScore;
    
    % Generate performance profile
    performanceProfile = generatePerformanceProfile(systemEvaluation);
    systemEvaluation.performanceProfile = performanceProfile;
    
    % Identify strengths and weaknesses
    strengthsWeaknesses = identifyStrengthsWeaknesses(systemEvaluation, protocol.benchmarks);
    systemEvaluation.strengthsWeaknesses = strengthsWeaknesses;
end

function securityEvaluation = evaluateSecurityPerformance(system, securityDatasets, securityProtocol)
    % Evaluate security performance across multiple datasets and scenarios
    
    securityEvaluation = struct();
    
    % Threat detection evaluation
    threatDetectionResults = evaluateThreatDetection(system, securityDatasets.threatDetection, securityProtocol);
    securityEvaluation.threatDetection = threatDetectionResults;
    
    % Intrusion detection evaluation
    intrusionDetectionResults = evaluateIntrusionDetection(system, securityDatasets.intrusionDetection, securityProtocol);
    securityEvaluation.intrusionDetection = intrusionDetectionResults;
    
    % Malware classification evaluation
    malwareClassificationResults = evaluateMalwareClassification(system, securityDatasets.malwareClassification, securityProtocol);
    securityEvaluation.malwareClassification = malwareClassificationResults;
    
    % Anomaly detection evaluation
    anomalyDetectionResults = evaluateAnomalyDetection(system, securityDatasets.anomalyDetection, securityProtocol);
    securityEvaluation.anomalyDetection = anomalyDetectionResults;
    
    % Real-time performance evaluation
    realTimeResults = evaluateRealTimePerformance(system, securityDatasets.realTimeTests, securityProtocol);
    securityEvaluation.realTimePerformance = realTimeResults;
    
    % Adversarial robustness evaluation
    adversarialResults = evaluateAdversarialRobustness(system, securityDatasets.adversarialTests, securityProtocol);
    securityEvaluation.adversarialRobustness = adversarialResults;
    
    % Calculate weighted security score
    securityWeights = securityProtocol.weights;
    securityComponents = [threatDetectionResults.score, intrusionDetectionResults.score, ...
                         malwareClassificationResults.score, anomalyDetectionResults.score, ...
                         realTimeResults.score, adversarialResults.score];
    
    securityEvaluation.overallScore = sum(securityWeights .* securityComponents);
    securityEvaluation.componentScores = securityComponents;
    securityEvaluation.weights = securityWeights;
end

function comparativeAnalysis = performComparativeAnalysis(systemResults, benchmarkSpec)
    % Perform comprehensive comparative analysis across all systems
    
    comparativeAnalysis = struct();
    numberOfSystems = length(systemResults);
    
    % Extract performance matrices
    performanceMatrix = extractPerformanceMatrix(systemResults);
    comparativeAnalysis.performanceMatrix = performanceMatrix;
    
    % Calculate relative performance rankings
    relativeRankings = calculateRelativeRankings(performanceMatrix);
    comparativeAnalysis.relativeRankings = relativeRankings;
    
    % Identify performance leaders and laggards
    performanceLeaders = identifyPerformanceLeaders(performanceMatrix, benchmarkSpec);
    comparativeAnalysis.performanceLeaders = performanceLeaders;
    
    % Analyse performance trade-offs
    tradeOffAnalysis = analysePerformanceTradeOffs(performanceMatrix);
    comparativeAnalysis.tradeOffAnalysis = tradeOffAnalysis;
    
    % Calculate performance gaps
    performanceGaps = calculatePerformanceGaps(performanceMatrix);
    comparativeAnalysis.performanceGaps = performanceGaps;
    
    % Cluster systems by performance characteristics
    performanceClusters = clusterSystemsByPerformance(performanceMatrix);
    comparativeAnalysis.performanceClusters = performanceClusters;
    
    % Generate recommendations
    recommendations = generateComparativeRecommendations(comparativeAnalysis, benchmarkSpec);
    comparativeAnalysis.recommendations = recommendations;
end

function generateBenchmarkingvisualisation(benchmarkResults)
    % Generate comprehensive benchmarking visualisation
    
    figure('Position', [100, 100, 1800, 1400]);
    
    systemResults = benchmarkResults.systemResults;
    numberOfSystems = length(systemResults);
    
    % Overall performance comparison
    subplot(3, 4, [1, 2]);
    systemNames = cell(numberOfSystems, 1);
    overallScores = zeros(numberOfSystems, 1);
    
    for systemIndex = 1:numberOfSystems
        systemNames{systemIndex} = systemResults{systemIndex}.systemName;
        overallScores(systemIndex) = systemResults{systemIndex}.overallScore;
    end
    
    [sortedScores, sortOrder] = sort(overallScores, 'descend');
    sortedNames = systemNames(sortOrder);
    
    bar(sortedScores, 'FaceColor', [0.3, 0.6, 0.9], 'EdgeColor', 'darkblue');
    set(gca, 'XTickLabel', sortedNames);
    ylabel('Overall Performance Score', 'FontSize', 12);
    title('Benchmark Performance Rankings', 'FontSize', 14, 'FontWeight', 'bold');
    xtickangle(45);
    ylim([0, 1]);
    grid on;
    
    % Performance radar chart
    subplot(3, 4, 3);
    if numberOfSystems > 0
        % Create radar chart for top 3 systems
        topSystems = min(3, numberOfSystems);
        performanceDimensions = {'Security', 'Safety', 'Efficiency', 'Robustness', 'Usability', 'Integration'};
        
        % Extract performance data for radar chart
        radarData = zeros(topSystems, length(performanceDimensions));
        for systemIndex = 1:topSystems
            currentResult = systemResults{sortOrder(systemIndex)};
            radarData(systemIndex, :) = [
                currentResult.securityPerformance.overallScore,
                currentResult.safetyPerformance.overallScore,
                currentResult.efficiencyPerformance.overallScore,
                currentResult.robustnessPerformance.overallScore,
                currentResult.usabilityPerformance.overallScore,
                currentResult.integrationPerformance.overallScore
            ];
        end
        
        % Create polar plot
        angles = linspace(0, 2*pi, length(performanceDimensions) + 1);
        for systemIndex = 1:topSystems
            values = [radarData(systemIndex, :), radarData(systemIndex, 1)]; % Close the polygon
            polarplot(angles, values, 'LineWidth', 2, 'DisplayName', sortedNames{systemIndex});
            hold on;
        end
        
        title('Performance Radar Chart', 'FontSize', 12, 'FontWeight', 'bold');
        legend('show', 'Location', 'best');
    end
    
    % Performance matrix heatmap
    subplot(3, 4, 4);
    if isfield(benchmarkResults, 'comparativeAnalysis')
        performanceMatrix = benchmarkResults.comparativeAnalysis.performanceMatrix;
        imagesc(performanceMatrix');
        colorbar;
        colormap('hot');
        
        dimensionLabels = {'Security', 'Safety', 'Efficiency', 'Robustness', 'Usability', 'Integration'};
        set(gca, 'XTickLabel', systemNames);
        set(gca, 'YTickLabel', dimensionLabels);
        xlabel('Systems', 'FontSize', 12);
        ylabel('Performance Dimensions', 'FontSize', 12);
        title('Performance Matrix Heatmap', 'FontSize', 12, 'FontWeight', 'bold');
        xtickangle(45);
    end
    
    % Security performance breakdown
    subplot(3, 4, 5);
    if numberOfSystems > 0
        securityComponents = {'Threat Detection', 'Intrusion Detection', 'Malware Classification', 'Anomaly Detection'};
        securityData = zeros(numberOfSystems, length(securityComponents));
        
        for systemIndex = 1:numberOfSystems
            securityResult = systemResults{systemIndex}.securityPerformance;
            securityData(systemIndex, :) = [
                securityResult.threatDetection.score,
                securityResult.intrusionDetection.score,
                securityResult.malwareClassification.score,
                securityResult.anomalyDetection.score
            ];
        end
        
        bar(securityData, 'grouped');
        set(gca, 'XTickLabel', systemNames);
        ylabel('Security Component Score', 'FontSize', 12);
        title('Security Performance Breakdown', 'FontSize', 12, 'FontWeight', 'bold');
        legend(securityComponents, 'Location', 'best');
        xtickangle(45);
        grid on;
    end
    
    % Safety performance breakdown
    subplot(3, 4, 6);
    if numberOfSystems > 0
        safetyComponents = {'Hazard Detection', 'Failure Prediction', 'Emergency Response', 'Compliance'};
        safetyData = zeros(numberOfSystems, length(safetyComponents));
        
        for systemIndex = 1:numberOfSystems
            safetyResult = systemResults{systemIndex}.safetyPerformance;
            % Generate representative safety component scores
            safetyData(systemIndex, :) = safetyResult.overallScore * [0.9, 0.85, 0.95, 0.88] + 0.05 * randn(1, 4);
        end
        
        bar(safetyData, 'grouped');
        set(gca, 'XTickLabel', systemNames);
        ylabel('Safety Component Score', 'FontSize', 12);
        title('Safety Performance Breakdown', 'FontSize', 12, 'FontWeight', 'bold');
        legend(safetyComponents, 'Location', 'best');
        xtickangle(45);
        grid on;
    end
    
    % Efficiency and scalability analysis
    subplot(3, 4, 7);
    if numberOfSystems > 0
        executionTimes = zeros(numberOfSystems, 1);
        memoryUsage = zeros(numberOfSystems, 1);
        
        for systemIndex = 1:numberOfSystems
            efficiencyResult = systemResults{systemIndex}.efficiencyPerformance;
            executionTimes(systemIndex) = efficiencyResult.averageExecutionTime;
            memoryUsage(systemIndex) = efficiencyResult.memoryUsage;
        end
        
        scatter(executionTimes, memoryUsage, 100, overallScores, 'filled');
        xlabel('Execution Time (ms)', 'FontSize', 12);
        ylabel('Memory Usage (MB)', 'FontSize', 12);
        title('Efficiency vs Resource Usage', 'FontSize', 12, 'FontWeight', 'bold');
        colorbar;
        colormap('hot');
        grid on;
        
        % Add system labels
        for systemIndex = 1:numberOfSystems
            text(executionTimes(systemIndex), memoryUsage(systemIndex), ...
                sprintf('  %s', systemNames{systemIndex}), 'FontSize', 8);
        end
    end
    
    % Statistical significance analysis
    subplot(3, 4, 8);
    if isfield(benchmarkResults, 'statisticalAnalysis')
        statisticalData = benchmarkResults.statisticalAnalysis;
        pValues = statisticalData.pairwisePValues;
        
        imagesc(pValues);
        colorbar;
        colormap(gca, 'bone');
        set(gca, 'XTickLabel', systemNames);
        set(gca, 'YTickLabel', systemNames);
        title('Statistical Significance (p-values)', 'FontSize', 12, 'FontWeight', 'bold');
        xtickangle(45);
    end
    
    % Robustness evaluation results
    subplot(3, 4, 9);
    if numberOfSystems > 0
        robustnessScores = zeros(numberOfSystems, 1);
        for systemIndex = 1:numberOfSystems
            robustnessScores(systemIndex) = systemResults{systemIndex}.robustnessPerformance.overallScore;
        end
        
        bar(robustnessScores, 'FaceColor', [0.8, 0.6, 0.4], 'EdgeColor', 'darkred');
        set(gca, 'XTickLabel', systemNames);
        ylabel('Robustness Score', 'FontSize', 12);
        title('Robustness Evaluation', 'FontSize', 12, 'FontWeight', 'bold');
        xtickangle(45);
        ylim([0, 1]);
        grid on;
    end
    
    % Performance trade-off analysis
    subplot(3, 4, 10);
    if isfield(benchmarkResults, 'comparativeAnalysis')
        tradeOffData = benchmarkResults.comparativeAnalysis.tradeOffAnalysis;
        securitySafetyTradeOff = tradeOffData.securityVsSafety;
        
        scatter(securitySafetyTradeOff(:, 1), securitySafetyTradeOff(:, 2), 100, 'filled');
        xlabel('Security Performance', 'FontSize', 12);
        ylabel('Safety Performance', 'FontSize', 12);
        title('Security vs Safety Trade-off', 'FontSize', 12, 'FontWeight', 'bold');
        grid on;
        
        % Add system labels
        for systemIndex = 1:numberOfSystems
            text(securitySafetyTradeOff(systemIndex, 1), securitySafetyTradeOff(systemIndex, 2), ...
                sprintf('  %s', systemNames{systemIndex}), 'FontSize', 8);
        end
    end
    
    % Benchmark coverage analysis
    subplot(3, 4, 11);
    if isfield(benchmarkResults, 'benchmarkCoverage')
        coverageData = benchmarkResults.benchmarkCoverage;
        coverageCategories = fieldnames(coverageData);
        coverageValues = zeros(length(coverageCategories), 1);
        
        for categoryIndex = 1:length(coverageCategories)
            coverageValues(categoryIndex) = coverageData.(coverageCategories{categoryIndex});
        end
        
        bar(coverageValues, 'FaceColor', [0.6, 0.9, 0.6], 'EdgeColor', 'darkgreen');
        set(gca, 'XTickLabel', coverageCategories);
        ylabel('Coverage Percentage', 'FontSize', 12);
        title('Benchmark Coverage Analysis', 'FontSize', 12, 'FontWeight', 'bold');
        xtickangle(45);
        ylim([0, 100]);
        grid on;
    end
    
    % Summary and recommendations
    subplot(3, 4, 12);
    axis off;
    
    summaryText = sprintf('Benchmark Summary\n\n');
    summaryText = [summaryText, sprintf('Systems Evaluated: %d\n', numberOfSystems)];
    summaryText = [summaryText, sprintf('Performance Dimensions: 6\n')];
    
    if numberOfSystems > 0
        [bestScore, bestIndex] = max(overallScores);
        summaryText = [summaryText, sprintf('Best Overall: %s (%.3f)\n', systemNames{bestIndex}, bestScore)];
        summaryText = [summaryText, sprintf('Average Score: %.3f\n', mean(overallScores))];
        summaryText = [summaryText, sprintf('Performance Range: %.3f\n', max(overallScores) - min(overallScores))];
    end
    
    if isfield(benchmarkResults, 'comparativeAnalysis') && isfield(benchmarkResults.comparativeAnalysis, 'recommendations')
        recommendations = benchmarkResults.comparativeAnalysis.recommendations;
        summaryText = [summaryText, sprintf('\nKey Findings:\n')];
        summaryText = [summaryText, sprintf('? %s\n', recommendations.keyFinding1)];
        summaryText = [summaryText, sprintf('? %s\n', recommendations.keyFinding2)];
    end
    
    summaryText = [summaryText, sprintf('\nBenchmark Date: %s', string(benchmarkResults.timestamp))];
    
    text(0.05, 0.95, summaryText, 'FontSize', 11, 'VerticalAlignment', 'top', ...
        'HorizontalAlignment', 'left', 'Interpreter', 'none', 'FontWeight', 'bold');
    
    % Save visualisation in multiple formats
    saveas(gcf, 'IntegratedBenchmarkingResults.fig');
    saveas(gcf, 'IntegratedBenchmarkingResults.eps', 'epsc');
    saveas(gcf, 'IntegratedBenchmarkingResults.jpg');
    
    fprintf('Integrated benchmarking visualisation saved in multiple formats.\n');
end
