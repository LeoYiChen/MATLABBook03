%% chapter_AILMI_prob5_pointer.m
% Pointer-generator network with copy mechanism.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AILMI_prob5_pointer
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [word, pGen] = pointerGenerator(decoderState, encoderHiddens, attention, ...
                                         vocabDist, sourceTokens, Wc, bc)
    % Compute generation probability
    % decoderState: [hiddenDim x 1]
    % encoderHiddens: [seqLen x hiddenDim]
    % attention: [seqLen x 1] attention weights
    % vocabDist: [vocabSize x 1] generation distribution
    
    % Concatenate context for generation probability
    contextVec = encoderHiddens' * attention; % Weighted sum
    features = [decoderState; contextVec];
    
    % Compute p_gen = sigmoid(W * [h; s; x] + b)
    pGen = sigmoid(Wc' * features + bc);
    
    % Mixture distribution: p_gen * P_vocab + (1-p_gen) * P_copy
    finalDist = pGen * vocabDist;
    
    % Add copy probabilities for source words
    for i = 1:length(sourceTokens)
        tokenIdx = sourceTokens(i);
        finalDist(tokenIdx) = finalDist(tokenIdx) + (1 - pGen) * attention(i);
    end
    
    % Normalise (in case of probability mass concentration)
    finalDist = finalDist / sum(finalDist);
    
    % Sample word from mixture distribution
    [~, word] = max(finalDist);
end
