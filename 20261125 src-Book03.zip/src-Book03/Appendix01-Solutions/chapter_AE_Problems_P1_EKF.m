%% chapter_AE_Problems_P1_EKF.m
% Extended Kalman Filter for spacecraft docking navigation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AE_Problems_P1_EKF
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [stateEstimate, covariance] = spacecraftDockingEKF(measurements, controlInputs, timeStep, systemModel)
    % Extended Kalman Filter for spacecraft docking navigation
    % Author: Dr Leo Chen
    % Version: 2.1.0 - Enhanced sensor fusion capabilities
    % Date: 2024-11-14
    
    persistent previousState previousCovariance isInitialised
    
    if isempty(isInitialised)
        % Initialize filter state
        previousState = systemModel.initialState;
        previousCovariance = systemModel.initialCovariance;
        isInitialised = true;
        fprintf('EKF initialised for spacecraft docking navigation\n');
    end
    
    %% Prediction Step
    
    % State transition function with orbital dynamics
    predictedState = propagateOrbitDynamics(previousState, controlInputs, timeStep, systemModel);
    
    % Compute Jacobian of state transition function
    jacobianF = computeStateTransitionJacobian(previousState, controlInputs, timeStep, systemModel);
    
    % Process noise covariance matrix
    processNoiseQ = systemModel.processNoise * timeStep;
    
    % Predict covariance
    predictedCovariance = jacobianF * previousCovariance * jacobianF' + processNoiseQ;
    
    fprintf('Prediction completed: ||x|| = %.3f, trace(P) = %.6f\n', ...
            norm(predictedState), trace(predictedCovariance));
    
    %% Update Step
    
    if ~isempty(measurements)
        % Process each available measurement
        for sensorIndex = 1:length(measurements)
            if measurements(sensorIndex).isValid
                % Measurement function
                [predictedMeasurement, jacobianH] = computeMeasurementModel(...
                    predictedState, measurements(sensorIndex).type, systemModel);
                
                % Innovation and covariance
                innovation = measurements(sensorIndex).value - predictedMeasurement;
                measurementNoise = measurements(sensorIndex).noiseCovariance;
                innovationCovariance = jacobianH * predictedCovariance * jacobianH' + measurementNoise;
                
                % Kalman gain
                kalmanGain = predictedCovariance * jacobianH' / innovationCovariance;
                
                % State and covariance update
                predictedState = predictedState + kalmanGain * innovation;
                predictedCovariance = (eye(length(predictedState)) - kalmanGain * jacobianH) * predictedCovariance;
                
                fprintf('Sensor %s update: innovation norm = %.4f\n', ...
                        measurements(sensorIndex).type, norm(innovation));
            end
        end
    end
    
    % Store results for next iteration
    previousState = predictedState;
    previousCovariance = predictedCovariance;
    
    stateEstimate = predictedState;
    covariance = predictedCovariance;
end

function predictedState = propagateOrbitDynamics(currentState, controlInputs, deltaTime, systemModel)
    % Propagate spacecraft state using nonlinear orbital dynamics
    
    % Extract state components
    position = currentState(1:3);
    velocity = currentState(4:6);
    quaternion = currentState(7:10);
    angularVelocity = currentState(11:12);
    
    % Orbital dynamics with J2 perturbation
    earthRadius = 6378137; % m
    mu = 3.986004418e14; % m?/s?
    J2 = 1.08262668e-3;
    
    r = norm(position);
    
    % Gravitational acceleration with J2 perturbation
    acceleration = -mu * position / r^3;
    
    % J2 perturbation
    j2Factor = 1.5 * J2 * mu * earthRadius^2 / r^5;
    j2Acceleration = j2Factor * [position(1) * (5 * position(3)^2 / r^2 - 1);
                                 position(2) * (5 * position(3)^2 / r^2 - 1);
                                 position(3) * (5 * position(3)^2 / r^2 - 3)];
    
    acceleration = acceleration + j2Acceleration;
    
    % Add control acceleration
    if ~isempty(controlInputs)
        acceleration = acceleration + controlInputs.thrust / systemModel.spacecraft.mass;
    end
    
    % Integrate using RK4
    newVelocity = velocity + acceleration * deltaTime;
    newPosition = position + velocity * deltaTime + 0.5 * acceleration * deltaTime^2;
    
    % Attitude dynamics (simplified)
    quaternionRate = 0.5 * quaternionMultiply([0; angularVelocity], quaternion);
    newQuaternion = quaternion + quaternionRate * deltaTime;
    newQuaternion = newQuaternion / norm(newQuaternion); % Normalise
    
    predictedState = [newPosition; newVelocity; newQuaternion; angularVelocity];
end
