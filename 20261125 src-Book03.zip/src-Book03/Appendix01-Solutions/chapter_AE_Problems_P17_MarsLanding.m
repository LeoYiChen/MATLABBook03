%% chapter_AE_Problems_P17_MarsLanding.m
% Autonomous Mars landing navigation system.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AE_Problems_P17_MarsLanding
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [landingResults, navigationPerformance, systemReliability] = autonomousMarsLandingNavigation(missionConfig, spacecraftConfig, martianEnvironment, landingRequirements)
    % Comprehensive autonomous Mars landing navigation system
    % Author: Dr Leo Chen
    % Version: 2.5.0 - Enhanced terrain-relative navigation and hazard avoidance
    % Date: 2024-11-14
    
    fprintf('Autonomous Mars Landing Navigation System\n');
    fprintf('Entry velocity: %.1f km/s, Landing site: %s\n', ...
            missionConfig.entryVelocity / 1000, missionConfig.landingSite);
    fprintf('Spacecraft mass: %.0f kg, Landing accuracy: --%.0f m\n', ...
            spacecraftConfig.mass, landingRequirements.landingAccuracy);
    fprintf('Atmospheric uncertainty: --%.0f%%, Terrain uncertainty: --%.0f m\n', ...
            martianEnvironment.atmosphericUncertainty * 100, martianEnvironment.terrainUncertainty);
    
    %% Phase 1: Mission Architecture and System Initialization
    
    % Initialize spacecraft systems and navigation suite
    [navigationSuite, sensorConfiguration] = initializeNavigationSuite(spacecraftConfig, landingRequirements);
    
    # Entry, descent, and landing phase definition
    [edlPhases, phaseTransitions] = defineEDLPhases(missionConfig, spacecraftConfig);
    
    % Mars atmospheric and surface models
    [atmosphericModel, surfaceModel] = initializeMartianModels(martianEnvironment, missionConfig.landingSite);
    
    # Guidance, navigation, and control system architecture
    [gncSystem, gncConfiguration] = initializeGNCSystem(navigationSuite, spacecraftConfig, landingRequirements);
    
    fprintf('Mars landing system initialized\n');
    fprintf('  Navigation sensors: %d active systems\n', length(navigationSuite.sensors));
    fprintf('  EDL phases: %d distinct phases\n', length(edlPhases));
    fprintf('  GNC update rate: %.0f Hz\n', gncConfiguration.updateRate);
    
    %% Phase 2: Pre-Entry Navigation and Trajectory Correction
    
    % Deep space navigation using celestial references
    [preEntryNavigation, trajectoryCorrections] = performPreEntryNavigation(navigationSuite, missionConfig, atmosphericModel);
    
    # Entry trajectory targeting and optimization
    [entryTrajectory, entryUncertainty] = optimizeEntryTrajectory(preEntryNavigation, spacecraftConfig, atmosphericModel);
    
    % Final trajectory correction maneuvers
    [finalTCM, residualErrors] = executeFinalTrajectoryCorrections(entryTrajectory, navigationSuite, spacecraftConfig);
    
    fprintf('Pre-entry navigation completed\n');
    fprintf('  Entry targeting accuracy: %.1f km 3-sigma ellipse\n', entryUncertainty.majorAxis / 1000);
    fprintf('  Residual velocity error: %.1f m/s\n', residualErrors.velocityError);
    
    %% Phase 3: Entry Phase Navigation
    
    % Atmospheric entry dynamics simulation
    entryPhase = edlPhases.entry;
    entryTimeVector = 0:gncConfiguration.timeStep:entryPhase.duration;
    
    # Initialize entry state
    entryState = struct();
    entryState.position = entryTrajectory.entryInterface.position;
    entryState.velocity = entryTrajectory.entryInterface.velocity;
    entryState.attitude = entryTrajectory.entryInterface.attitude;
    entryState.mass = spacecraftConfig.mass;
    
    % Entry navigation arrays
    entryPositionHistory = zeros(3, length(entryTimeVector));
    entryVelocityHistory = zeros(3, length(entryTimeVector));
    entryNavigationErrors = zeros(3, length(entryTimeVector));
    
    fprintf('Starting entry phase navigation...\n');
    fprintf('  Entry interface altitude: %.1f km\n', norm(entryState.position) / 1000 - martianEnvironment.planetRadius / 1000);
    
    for entryIndex = 1:length(entryTimeVector)
        currentTime = entryTimeVector(entryIndex);
        
        # Atmospheric entry dynamics
        [newEntryState, atmosphericForces] = propagateEntryDynamics(entryState, atmosphericModel, gncConfiguration.timeStep);
        
        % Inertial navigation system update
        [insNavigation, insErrors] = updateInertialNavigation(navigationSuite.ins, newEntryState, atmosphericForces);
        
        # Navigation state estimation using extended Kalman filter
        [navigationEstimate, estimationCovariance] = performEntryNavigation(insNavigation, newEntryState, gncSystem);
        
        % Store navigation history
        entryPositionHistory(:, entryIndex) = navigationEstimate.position;
        entryVelocityHistory(:, entryIndex) = navigationEstimate.velocity;
        entryNavigationErrors(:, entryIndex) = navigationEstimate.position - newEntryState.position;
        
        entryState = newEntryState;
    end
    
    fprintf('Entry phase navigation completed\n');
    fprintf('  Entry navigation accuracy: %.1f km RMS\n', rms(vecnorm(entryNavigationErrors)) / 1000);
    
    %% Phase 4: Parachute Descent and Terrain-Relative Navigation
    
    % Parachute deployment and dynamics
    descentPhase = edlPhases.descent;
    descentTimeVector = 0:gncConfiguration.timeStep:descentPhase.duration;
    
    # Initialize descent state at parachute deployment
    descentState = struct();
    descentState.position = entryPositionHistory(:, end);
    descentState.velocity = entryVelocityHistory(:, end);
    descentState.altitude = norm(descentState.position) - martianEnvironment.planetRadius;
    
    % Terrain-relative navigation initialization
    [terrainNavigation, terrainDatabase] = initializeTerrainNavigation(navigationSuite.camera, navigationSuite.lidar, surfaceModel);
    
    # Radar altimeter integration
    [radarAltimeter, altimeterConfiguration] = initializeRadarAltimeter(navigationSuite.radar, descentState);
    
    % Descent navigation arrays
    descentPositionHistory = zeros(3, length(descentTimeVector));
    descentVelocityHistory = zeros(3, length(descentTimeVector));
    terrainNavigationHistory = zeros(3, length(descentTimeVector));
    
    fprintf('Starting descent phase with terrain-relative navigation...\n');
    fprintf('  Parachute deployment altitude: %.1f km\n', descentState.altitude / 1000);
    
    for descentIndex = 1:length(descentTimeVector)
        currentTime = descentTimeVector(descentIndex);
        
        # Parachute descent dynamics
        [newDescentState, aerodynamicForces] = propagateDescentDynamics(descentState, atmosphericModel, descentPhase.parachute, gncConfiguration.timeStep);
        
        % Terrain-relative navigation using visual odometry
        [visualNavigation, visualLandmarks] = performVisualNavigation(terrainNavigation, newDescentState, surfaceModel);
        
        # LIDAR-based terrain mapping and navigation
        [lidarNavigation, terrainMapping] = performLidarNavigation(terrainNavigation, newDescentState, surfaceModel);
        
        % Radar altimeter measurements
        [altimeterMeasurement, altimeterQuality] = updateRadarAltimeter(radarAltimeter, newDescentState, surfaceModel);
        
        # Multi-sensor navigation fusion
        [fusedNavigation, navigationCovariance] = fuseDescentNavigation(visualNavigation, lidarNavigation, altimeterMeasurement, gncSystem);
        
        % Store navigation history
        descentPositionHistory(:, descentIndex) = fusedNavigation.position;
        descentVelocityHistory(:, descentIndex) = fusedNavigation.velocity;
        terrainNavigationHistory(:, descentIndex) = fusedNavigation.terrainRelativePosition;
        
        descentState = newDescentState;
    end
    
    fprintf('Descent phase navigation completed\n');
    fprintf('  Terrain-relative accuracy: %.1f m RMS\n', rms(vecnorm(terrainNavigationHistory - descentPositionHistory)));
    
    %% Phase 5: Powered Descent and Precision Landing
    
    % Powered descent phase initialization
    poweredDescentPhase = edlPhases.poweredDescent;
    pdTimeVector = 0:gncConfiguration.timeStep:poweredDescentPhase.duration;
    
    # Initialize powered descent state
    pdState = struct();
    pdState.position = descentPositionHistory(:, end);
    pdState.velocity = descentVelocityHistory(:, end);
    pdState.mass = spacecraftConfig.mass - spacecraftConfig.propellantUsed.entry - spacecraftConfig.propellantUsed.descent;
    pdState.attitude = [0; 0; 0]; % Euler angles
    
    % Hazard detection and avoidance system
    [hazardDetection, hazardMap] = initializeHazardDetection(navigationSuite.hazardCamera, surfaceModel, landingRequirements);
    
    # Precision landing guidance
    [precisionGuidance, guidanceParameters] = initializePrecisionGuidance(landingRequirements, spacecraftConfig);
    
    % Powered descent navigation arrays
    pdPositionHistory = zeros(3, length(pdTimeVector));
    pdVelocityHistory = zeros(3, length(pdTimeVector));
    thrustCommands = zeros(3, length(pdTimeVector));
    hazardAssessments = zeros(length(pdTimeVector), 1);
    
    fprintf('Starting powered descent phase...\n');
    fprintf('  Initial altitude: %.1f m, Remaining propellant: %.0f kg\n', ...
            norm(pdState.position) - martianEnvironment.planetRadius, pdState.mass - spacecraftConfig.dryMass);
    
    for pdIndex = 1:length(pdTimeVector)
        currentTime = pdTimeVector(pdIndex);
        
        # Powered descent dynamics with thrust
        thrustCommand = calculateThrustCommand(pdState, precisionGuidance, landingRequirements, currentTime);
        [newPdState, thrustForces] = propagatePoweredDescentDynamics(pdState, thrustCommand, atmosphericModel, gncConfiguration.timeStep);
        
        % High-precision terrain-relative navigation
        [precisionNavigation, navigationQuality] = performPrecisionNavigation(terrainNavigation, newPdState, surfaceModel);
        
        # Hazard detection and landing site evaluation
        [hazardAssessment, landingSiteSafety] = performHazardDetection(hazardDetection, newPdState, surfaceModel);
        
        % Adaptive guidance based on hazard assessment
        if hazardAssessment.hazardLevel > hazardDetection.safetyThreshold
            [adaptiveGuidance, landingSiteAdjustment] = performAdaptiveGuidance(precisionGuidance, hazardAssessment, newPdState);
            precisionGuidance = adaptiveGuidance;
        end
        
        # Navigation state estimation with high-precision requirements
        [finalNavigation, finalCovariance] = performFinalNavigationEstimate(precisionNavigation, hazardAssessment, gncSystem);
        
        % Store powered descent history
        pdPositionHistory(:, pdIndex) = finalNavigation.position;
        pdVelocityHistory(:, pdIndex) = finalNavigation.velocity;
        thrustCommands(:, pdIndex) = thrustCommand;
        hazardAssessments(pdIndex) = hazardAssessment.hazardLevel;
        
        pdState = newPdState;
        
        # Check for landing condition
        currentAltitude = norm(pdState.position) - martianEnvironment.planetRadius;
        if currentAltitude < landingRequirements.landingDetectionAltitude
            fprintf('  Landing detected at t=%.1f s, altitude=%.1f m\n', currentTime, currentAltitude);
            break;
        end
    end
    
    fprintf('Powered descent phase completed\n');
    
    %% Phase 6: Landing Analysis and Performance Assessment
    
    % Final landing position and accuracy
    finalLandingPosition = pdPositionHistory(:, pdIndex);
    targetLandingPosition = landingRequirements.targetPosition;
    landingError = norm(finalLandingPosition - targetLandingPosition);
    
    # Landing velocity and safety assessment
    finalLandingVelocity = pdVelocityHistory(:, pdIndex);
    horizontalVelocity = norm(finalLandingVelocity(1:2));
    verticalVelocity = abs(finalLandingVelocity(3));
    
    % Navigation system performance evaluation
    [navigationPerformanceMetrics, systemAccuracy] = evaluateNavigationPerformance(entryNavigationErrors, ...
                                                                                   terrainNavigationHistory, ...
                                                                                   pdPositionHistory, landingRequirements);
    
    # Sensor performance and reliability assessment
    [sensorPerformanceMetrics, sensorReliability] = evaluateSensorPerformance(navigationSuite, gncSystem, ...
                                                                              entryTimeVector, descentTimeVector, pdTimeVector);
    
    fprintf('Landing analysis completed\n');
    fprintf('  Landing accuracy: %.1f m (requirement: --%.0f m)\n', landingError, landingRequirements.landingAccuracy);
    fprintf('  Landing velocity: %.1f m/s horizontal, %.1f m/s vertical\n', horizontalVelocity, verticalVelocity);
    fprintf('  Navigation accuracy: %.1f m RMS\n', systemAccuracy.overallRMS);
    
    %% Phase 7: Fault Tolerance and Contingency Analysis
    
    # Sensor failure scenarios
    [sensorFaultAnalysis, sensorRedundancy] = analyzeSensorFaultTolerance(navigationSuite, gncSystem, ...
                                                                          pdPositionHistory, landingRequirements);
    
    % Communication blackout scenarios
    [commBlackoutAnalysis, autonomousCapability] = analyzeCommBlackoutScenarios(gncSystem, precisionGuidance, ...
                                                                                pdTimeVector, landingRequirements);
    
    # Propulsion system degradation
    [propulsionFaultAnalysis, propulsionRedundancy] = analyzePropulsionFaults(spacecraftConfig, thrustCommands, ...
                                                                              pdState, landingRequirements);
    
    % Atmospheric uncertainty impact
    [atmosphericSensitivity, robustnessAnalysis] = analyzeAtmosphericUncertainty(atmosphericModel, entryTrajectory, ...
                                                                                 descentPhase, poweredDescentPhase);
    
    fprintf('Fault tolerance analysis completed\n');
    fprintf('  Sensor fault tolerance: %.1f%% mission success\n', sensorRedundancy.missionSuccessRate * 100);
    fprintf('  Communication blackout capability: %.1f%% autonomous success\n', autonomousCapability.successRate * 100);
    fprintf('  Atmospheric robustness: %.1f%% success under uncertainty\n', robustnessAnalysis.successRate * 100);
    
    %% Phase 8: Results Compilation
    
    landingResults = struct();
    landingResults.landingAccuracy = landingError;
    landingResults.landingVelocity = finalLandingVelocity;
    landingResults.missionSuccess = (landingError <= landingRequirements.landingAccuracy) && ...
                                   (horizontalVelocity <= landingRequirements.maxHorizontalVelocity) && ...
                                   (verticalVelocity <= landingRequirements.maxVerticalVelocity);
    landingResults.trajectoryHistory = struct('entry', entryPositionHistory, 'descent', descentPositionHistory, ...
                                             'poweredDescent', pdPositionHistory);
    landingResults.navigationHistory = struct('terrainRelative', terrainNavigationHistory, 'hazardAssessment', hazardAssessments);
    
    navigationPerformance = struct();
    navigationPerformance.systemMetrics = navigationPerformanceMetrics;
    navigationPerformance.sensorMetrics = sensorPerformanceMetrics;
    navigationPerformance.accuracy = systemAccuracy;
    navigationPerformance.terrainNavigation = struct('visualAccuracy', visualNavigation.accuracy, ...
                                                    'lidarAccuracy', lidarNavigation.accuracy);
    
    systemReliability = struct();
    systemReliability.sensorFaultTolerance = sensorFaultAnalysis;
    systemReliability.communicationRobustness = commBlackoutAnalysis;
    systemReliability.propulsionReliability = propulsionFaultAnalysis;
    systemReliability.atmosphericRobustness = atmosphericSensitivity;
    systemReliability.overallReliability = calculateOverallReliability(sensorRedundancy, autonomousCapability, ...
                                                                       propulsionRedundancy, robustnessAnalysis);
    
    %% Phase 9: Comprehensive visualisation
    
    fprintf('Creating comprehensive Mars landing analysis...\n');
    
    # Create analysis figure
    figure('Name', 'Autonomous Mars Landing Navigation System', 'Position', [100, 100, 1600, 1200]);
    
    % Landing trajectory 3D visualisation
    subplot(3,4,1);
    plot3(entryPositionHistory(1,:)/1000, entryPositionHistory(2,:)/1000, entryPositionHistory(3,:)/1000, 'r-', 'LineWidth', 2);
    hold on;
    plot3(descentPositionHistory(1,:)/1000, descentPositionHistory(2,:)/1000, descentPositionHistory(3,:)/1000, 'g-', 'LineWidth', 2);
    plot3(pdPositionHistory(1,:)/1000, pdPositionHistory(2,:)/1000, pdPositionHistory(3,:)/1000, 'b-', 'LineWidth', 2);
    xlabel('X (km)'); ylabel('Y (km)'); zlabel('Z (km)'); title('Mars Landing Trajectory');
    legend({'Entry', 'Descent', 'Powered Descent'}); grid on;
    
    # Navigation error evolution
    subplot(3,4,2);
    plot(entryTimeVector, vecnorm(entryNavigationErrors), 'r-', 'LineWidth', 2);
    xlabel('Time (s)'); ylabel('Navigation Error (m)'); title('Entry Navigation Accuracy');
    grid on;
    
    % Terrain-relative navigation performance
    subplot(3,4,3);
    if ~isempty(terrainNavigationHistory)
        terrainErrors = vecnorm(terrainNavigationHistory - descentPositionHistory);
        plot(descentTimeVector, terrainErrors, 'g-', 'LineWidth', 2);
        xlabel('Time (s)'); ylabel('Terrain Navigation Error (m)'); title('Terrain-Relative Navigation');
        grid on;
    end
    
    # Powered descent trajectory
    subplot(3,4,4);
    if ~isempty(pdPositionHistory)
        altitudes = vecnorm(pdPositionHistory) - martianEnvironment.planetRadius;
        plot(pdTimeVector(1:length(altitudes)), altitudes, 'b-', 'LineWidth', 2);
        xlabel('Time (s)'); ylabel('Altitude (m)'); title('Powered Descent Profile');
        grid on;
    end
    
    % Hazard assessment timeline
    subplot(3,4,5);
    if ~isempty(hazardAssessments)
        plot(pdTimeVector(1:length(hazardAssessments)), hazardAssessments, 'm-', 'LineWidth', 2);
        xlabel('Time (s)'); ylabel('Hazard Level'); title('Landing Hazard Assessment');
        grid on;
    end
    
    # Thrust command history
    subplot(3,4,6);
    if ~isempty(thrustCommands)
        thrustMagnitudes = vecnorm(thrustCommands);
        plot(pdTimeVector(1:length(thrustMagnitudes)), thrustMagnitudes/1000, 'c-', 'LineWidth', 2);
        xlabel('Time (s)'); ylabel('Thrust (kN)'); title('Powered Descent Thrust');
        grid on;
    end
    
    % Landing accuracy visualisation
    subplot(3,4,7);
    landingEllipse = generateLandingEllipse(landingRequirements.landingAccuracy);
    plot(landingEllipse.x, landingEllipse.y, 'k--', 'LineWidth', 2);
    hold on;
    plot(0, 0, 'ro', 'MarkerSize', 10, 'LineWidth', 2); % Target
    plot(landingError * cos(0), landingError * sin(0), 'bx', 'MarkerSize', 10, 'LineWidth', 2); % Actual
    xlabel('East (m)'); ylabel('North (m)'); title('Landing Accuracy');
    legend({'Requirement', 'Target', 'Actual'}); axis equal; grid on;
    
    # Sensor performance comparison
    subplot(3,4,8);
    if isfield(sensorPerformanceMetrics, 'sensorAccuracies')
        sensorNames = fieldnames(sensorPerformanceMetrics.sensorAccuracies);
        accuracies = cell2mat(struct2cell(sensorPerformanceMetrics.sensorAccuracies));
        
        bar(accuracies);
        set(gca, 'XTickLabel', sensorNames);
        ylabel('Accuracy (m)'); title('Sensor Performance');
        grid on;
    end
    
    % Fault tolerance analysis
    subplot(3,4,9);
    faultScenarios = {'Sensor Faults', 'Comm Blackout', 'Propulsion Faults', 'Atmospheric'};
    successRates = [sensorRedundancy.missionSuccessRate, autonomousCapability.successRate, ...
                   propulsionRedundancy.missionSuccessRate, robustnessAnalysis.successRate] * 100;
    
    bar(successRates);
    set(gca, 'XTickLabel', faultScenarios);
    ylabel('Success Rate (%)'); title('Fault Tolerance');
    ylim([0, 100]); grid on;
    
    # Mission phase durations
    subplot(3,4,10);
    phaseDurations = [length(entryTimeVector), length(descentTimeVector), length(pdTimeVector)] * gncConfiguration.timeStep;
    phaseNames = {'Entry', 'Descent', 'Powered Descent'};
    
    bar(phaseDurations);
    set(gca, 'XTickLabel', phaseNames);
    ylabel('Duration (s)'); title('Mission Phase Durations');
    grid on;
    
    % Navigation system reliability
    subplot(3,4,11);
    reliabilityMetrics = [systemReliability.overallReliability.navigation, ...
                         systemReliability.overallReliability.guidance, ...
                         systemReliability.overallReliability.control] * 100;
    reliabilityLabels = {'Navigation', 'Guidance', 'Control'};
    
    bar(reliabilityMetrics);
    set(gca, 'XTickLabel', reliabilityLabels);
    ylabel('Reliability (%)'); title('System Reliability');
    ylim([0, 100]); grid on;
    
    # Overall mission performance
    subplot(3,4,12);
    overallMetrics = [double(landingResults.missionSuccess), ...
                     (landingRequirements.landingAccuracy - landingError) / landingRequirements.landingAccuracy, ...
                     systemReliability.overallReliability.overall] * 100;
    metricLabels = {'Mission Success', 'Landing Accuracy', 'System Reliability'};
    
    bar(overallMetrics, 'FaceColor', 'gold');
    set(gca, 'XTickLabel', metricLabels);
    ylabel('Performance Score (%)'); title('Overall Mission Performance');
    ylim([0, 100]); grid on;
    
    sgtitle('Autonomous Mars Landing Navigation: Comprehensive Mission Analysis');
    
    fprintf('\nMars landing navigation analysis completed successfully!\n');
    fprintf('Mission performance summary:\n');
    fprintf('  Landing success: %s\n', landingResults.missionSuccess ? 'SUCCESS' : 'FAILURE');
    fprintf('  Landing accuracy: %.1f m (%.1f%% of requirement)\n', landingError, ...
            (landingError / landingRequirements.landingAccuracy) * 100);
    fprintf('  Navigation system reliability: %.1f%%\n', systemReliability.overallReliability.overall * 100);
    fprintf('  Autonomous operation capability: %.1f%%\n', autonomousCapability.successRate * 100);
    
end

% Helper functions for Mars landing navigation

function [suite, config] = initializeNavigationSuite(spacecraftConfig, requirements)
    % Initialize comprehensive navigation sensor suite
    
    suite = struct();
    
    # Inertial Navigation System
    suite.ins = struct();
    suite.ins.accelerometers = generateAccelerometerSpecs(spacecraftConfig);
    suite.ins.gyroscopes = generateGyroscopeSpecs(spacecraftConfig);
    suite.ins.updateRate = 100; % Hz
    
    % Visual navigation cameras
    suite.camera = struct();
    suite.camera.resolution = [2048, 2048]; % pixels
    suite.camera.fieldOfView = 60 * pi/180; % radians
    suite.camera.frameRate = 10; % Hz
    
    # LIDAR system
    suite.lidar = struct();
    suite.lidar.range = 1000; % meters
    suite.lidar.accuracy = 0.1; % meters
    suite.lidar.pointsPerSecond = 100000;
    
    % Radar altimeter
    suite.radar = struct();
    suite.radar.maxRange = 2500; % meters
    suite.radar.accuracy = 0.05; % meters
    suite.radar.updateRate = 50; % Hz
    
    # Hazard detection camera
    suite.hazardCamera = struct();
    suite.hazardCamera.resolution = [1024, 1024];
    suite.hazardCamera.fieldOfView = 45 * pi/180;
    suite.hazardCamera.frameRate = 20; % Hz
    
    config = struct();
    config.totalMass = calculateSensorSuiteMass(suite);
    config.powerConsumption = calculateSensorSuitePower(suite);
    config.dataGeneration = calculateDataGeneration(suite);
    
    fprintf('Navigation suite initialized: %.1f kg, %.1f W, %.1f MB/s\n', ...
            config.totalMass, config.powerConsumption, config.dataGeneration);
end
