%% p17.m
% MATLABBook03_ChapterAIBHS_Problem17.m
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : p17
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function MATLABBook03_ChapterAIBHS_Problem17
% Purpose: Bayesian optimisation of a dissolution process (surrogate).
% Author: Dr Leo Chen. R2024b + Statistics ML. v1.0 2025-06-01.
    rng(0);
    temperature=optimizableVariable('temperature',[20 60]);
    mixTime=optimizableVariable('mixTime',[1 30]);
    result=bayesopt(@dissolutionObjective,[temperature mixTime], ...
        'MaxObjectiveEvaluations',20,'Verbose',0,'PlotFcn',[]);
    fprintf('Best temperature: %.1f  Best mix time: %.1f\n', ...
        result.XAtMinObjective.temperature, result.XAtMinObjective.mixTime);
end
function loss = dissolutionObjective(x)
    target=85;
    predicted=90-0.05*(x.temperature-45).^2-0.1*(x.mixTime-15).^2;
    loss=abs(predicted-target);
end
