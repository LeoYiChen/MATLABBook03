%% chapter_AILMI_prob5_coverage.m
% Coverage mechanism to prevent repetition.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AILMI_prob5_coverage
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [attention, coverage, coverageLoss] = computeCoverageAttention(...
    decoderState, encoderHiddens, prevCoverage, Wh, Ws, Wc, v)
    % Compute attention with coverage penalty
    % prevCoverage: [seqLen x 1] cumulative attention from previous steps
    
    seqLen = size(encoderHiddens, 1);
    hiddenDim = size(encoderHiddens, 2);
    
    % Compute attention energies with coverage term
    energies = zeros(seqLen, 1);
    for i = 1:seqLen
        h_i = encoderHiddens(i, :)';
        
        % e_i = v^T * tanh(W_h * h_i + W_s * s_t + W_c * c_i + b)
        energies(i) = v' * tanh(Wh * h_i + Ws * decoderState + ...
                                 Wc * prevCoverage(i));
    end
    
    % Softmax to get attention distribution
    attention = softmax(energies);
    
    % Update coverage: c^t = c^{t-1} + alpha^t
    coverage = prevCoverage + attention;
    
    % Coverage loss: sum of min(alpha_i, c_i)
    % Penalises attending to already-covered positions
    coverageLoss = sum(min(attention, prevCoverage));
end
