%% lstm_forecasting.m
% LSTM Time Series Forecasting
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : lstm_forecasting
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% LSTM Time Series Forecasting
% Author: Dr Leo Chen
% Version: R2023b
% Date: November 2024

function lstm_time_series_forecasting()
% Generate synthetic time series data
rng(456); % Ensure reproducibility
time_points = 1:500;


% Create complex time series with trend, seasonality, and noise
trend_component = 0.02 * time_points;
seasonal_component = 2 * sin(2 * pi * time_points / 50) + ...
    0.5 * sin(2 * pi * time_points / 12);
noise_component = 0.5 * randn(size(time_points));

time_series = trend_component + seasonal_component + noise_component;

% Prepare data for LSTM training
sequence_length = 20;
forecast_horizon = 1;

% Normalise the time series
series_mean = mean(time_series);
series_std = std(time_series);
normalised_series = (time_series - series_mean) / series_std;

% Create sequences for training
[input_sequences, target_sequences] = create_sequences(...
    normalised_series, sequence_length, forecast_horizon);

% Split data into training and testing sets
train_ratio = 0.8;
num_train_sequences = floor(train_ratio * size(input_sequences, 2));

train_inputs = input_sequences(:, 1:num_train_sequences);
train_targets = target_sequences(:, 1:num_train_sequences);
test_inputs = input_sequences(:, num_train_sequences+1:end);
test_targets = target_sequences(:, num_train_sequences+1:end);

% Define LSTM network architecture
num_features = 1;
num_hidden_units = 50;
num_responses = 1;

lstm_layers = [
    sequenceInputLayer(num_features)
    lstmLayer(num_hidden_units, 'OutputMode', 'sequence')
    dropoutLayer(0.2)
    lstmLayer(num_hidden_units, 'OutputMode', 'last')
    fullyConnectedLayer(num_responses)
    regressionLayer
];

% Configure training options
training_options = trainingOptions('adam', ...
    'MaxEpochs', 100, ...
    'GradientThreshold', 1, ...
    'InitialLearnRate', 0.01, ...
    'LearnRateSchedule', 'piecewise', ...
    'LearnRateDropPeriod', 50, ...
    'LearnRateDropFactor', 0.2, ...
    'ValidationData', {test_inputs, test_targets}, ...
    'ValidationFrequency', 10, ...
    'Plots', 'training-progress', ...
    'Verbose', false);

% Train the LSTM network
fprintf('Training LSTM network...\\n');
trained_lstm_net = trainNetwork(train_inputs, train_targets, ...
    lstm_layers, training_options);

% Generate predictions on test set
predicted_values = predict(trained_lstm_net, test_inputs);

% Denormalise predictions and targets
predicted_denormalised = predicted_values * series_std + series_mean;
actual_denormalised = test_targets * series_std + series_mean;

% Calculate performance metrics
rmse_value = sqrt(mean((predicted_denormalised - actual_denormalised).^2));
mae_value = mean(abs(predicted_denormalised - actual_denormalised));
mape_value = mean(abs((actual_denormalised - predicted_denormalised) ./ ...
    actual_denormalised)) * 100;

% Visualise results
figure('Name', 'LSTM Forecasting Results');

subplot(2, 1, 1);
plot(time_points, time_series, 'b-', 'LineWidth', 1.5, ...
    'DisplayName', 'Original Series');
hold on;
train_end_point = num_train_sequences + sequence_length;
plot(train_end_point:length(time_series), ...
    [time_series(train_end_point), predicted_denormalised'], ...
    'r--', 'LineWidth', 2, 'DisplayName', 'LSTM Predictions');
plot(train_end_point:length(time_series), ...
    time_series(train_end_point:end), 'g-', 'LineWidth', 1.5, ...
    'DisplayName', 'Actual Values');

xlabel('Time Points', 'Interpreter', 'latex');
ylabel('Series Value', 'Interpreter', 'latex');
title('LSTM Time Series Forecasting', 'Interpreter', 'latex');
legend('Location', 'best');
grid on;

subplot(2, 1, 2);
prediction_errors = actual_denormalised - predicted_denormalised;
plot(prediction_errors, 'ro-', 'MarkerSize', 4);
xlabel('Test Sample', 'Interpreter', 'latex');
ylabel('Prediction Error', 'Interpreter', 'latex');
title('Forecasting Errors', 'Interpreter', 'latex');
grid on;

% Display performance metrics
fprintf('\\n\\textbf{LSTM Forecasting Performance}:\\n');
fprintf('RMSE: %.4f\\n', rmse_value);
fprintf('MAE: %.4f\\n', mae_value);
fprintf('MAPE: %.2f%%\\n', mape_value);

end

function [input_sequences, target_sequences] = create_sequences(...
data, sequence_length, forecast_horizon)
% Create input-output sequences for LSTM training
num_sequences = length(data) - sequence_length - forecast_horizon + 1;
input_sequences = zeros(sequence_length, num_sequences);
target_sequences = zeros(forecast_horizon, num_sequences);

for sequence_idx = 1:num_sequences
    input_start = sequence_idx;
    input_end = sequence_idx + sequence_length - 1;
    target_start = input_end + 1;
    target_end = target_start + forecast_horizon - 1;
    
    input_sequences(:, sequence_idx) = data(input_start:input_end)';
    target_sequences(:, sequence_idx) = data(target_start:target_end)';
end

end
