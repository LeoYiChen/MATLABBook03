%% chapter_AE_Problems_P11_MagneticReconnection.m
% Magnetic reconnection spacecraft propulsion system.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AE_Problems_P11_MagneticReconnection
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [propulsionPerformance, reconnectionDynamics, systemDesign] = magneticReconnectionPropulsion(plasmaConfig, magneticConfig, thrusterConfig, operatingConditions)
    % Magnetic reconnection spacecraft propulsion system simulation
    % Author: Dr Leo Chen
    % Version: 1.2.0 - Advanced MHD modeling with particle acceleration
    % Date: 2024-11-14
    
    fprintf('Magnetic Reconnection Spacecraft Propulsion System\n');
    fprintf('Magnetic field strength: %.1f T, Plasma density: %.2e m??\n', ...
            magneticConfig.fieldStrength, plasmaConfig.density);
    fprintf('Propellant type: %s, Mass flow rate: %.3f kg/s\n', ...
            plasmaConfig.propellantType, thrusterConfig.massFlowRate);
    fprintf('Operating mode: %s\n', operatingConditions.operatingMode);
    
    %% Phase 1: Magnetohydrodynamic Field Configuration
    
    % Define computational domain for MHD simulation
    [computationalDomain, gridResolution] = setupMHDDomain(magneticConfig.domainSize, thrusterConfig.geometryConfig);
    
    % Initialize magnetic field topology for reconnection
    [initialMagneticField, fieldTopology] = initializeMagneticTopology(magneticConfig, computationalDomain);
    
    % Create current sheet configuration for reconnection trigger
    [currentSheet, currentDistribution] = setupCurrentSheet(initialMagneticField, magneticConfig);
    
    % Implement magnetic field coil design
    [magneticCoils, coilParameters] = designMagneticCoils(magneticConfig, thrusterConfig.coilConfig);
    
    fprintf('Magnetic field configuration established\n');
    fprintf('  Field topology: %s, Current sheet thickness: %.2f ion gyroradii\n', ...
            fieldTopology.type, currentSheet.thickness / plasmaConfig.ionGyroRadius);
    fprintf('  Magnetic coils: %d coils, Total power: %.1f kW\n', ...
            length(magneticCoils), sum([magneticCoils.power]) / 1000);
    
    %% Phase 2: Plasma Injection and Initialisation
    
    % Plasma injection system design
    [plasmaInjector, injectionParameters] = designPlasmaInjector(plasmaConfig, thrusterConfig.injectorConfig);
    
    % Initialize plasma distribution
    [initialPlasmaState, plasmaParameters] = initializePlasmaState(plasmaConfig, currentSheet, computationalDomain);
    
    % Plasma confinement and heating
    [confinementSystem, heatingMechanism] = implementPlasmaConfinement(initialPlasmaState, magneticConfig);
    
    # Ion and electron temperature profiles
    [temperatureProfiles, thermalEquilibrium] = calculateTemperatureProfiles(initialPlasmaState, confinementSystem);
    
    fprintf('Plasma system initialized\n');
    fprintf('  Ion temperature: %.1f keV, Electron temperature: %.1f keV\n', ...
            temperatureProfiles.ionTemperature / 1000, temperatureProfiles.electronTemperature / 1000);
    fprintf('  Plasma beta: %.3f, Confinement time: %.2f ms\n', ...
            plasmaParameters.beta, confinementSystem.confinementTime * 1000);
    
    %% Phase 3: Magnetic Reconnection Simulation
    
    % Implement advanced MHD solver with reconnection physics
    [mhdSolver, solverParameters] = setupAdvancedMHDSolver(computationalDomain, plasmaConfig, magneticConfig);
    
    % Time evolution parameters
    timeStep = operatingConditions.timeStep;
    totalTime = operatingConditions.simulationTime;
    timeVector = 0:timeStep:totalTime;
    numTimeSteps = length(timeVector);
    
    % Initialize evolution arrays
    magneticFieldEvolution = zeros([size(initialMagneticField), numTimeSteps]);
    plasmaStateEvolution = zeros([size(initialPlasmaState.density), numTimeSteps]);
    reconnectionRateEvolution = zeros(numTimeSteps, 1);
    
    fprintf('Starting magnetic reconnection simulation...\n');
    fprintf('  Time steps: %d, Duration: %.2f ms\n', numTimeSteps, totalTime * 1000);
    
    currentMagneticField = initialMagneticField;
    currentPlasmaState = initialPlasmaState;
    
    for timeIndex = 1:numTimeSteps
        currentTime = timeVector(timeIndex);
        
        % Solve MHD equations with reconnection
        [newMagneticField, newPlasmaState, reconnectionRate] = solveMHDWithReconnection(...
            currentMagneticField, currentPlasmaState, mhdSolver, timeStep);
        
        # Calculate energy conversion and particle acceleration
        [energyConversion, particleAcceleration] = calculateEnergyConversion(currentMagneticField, newMagneticField, ...
                                                                             currentPlasmaState, newPlasmaState);
        
        % Update magnetic nozzle dynamics
        [nozzleField, nozzleEfficiency] = updateMagneticNozzle(newMagneticField, thrusterConfig.nozzleConfig);
        
        # Calculate thrust and specific impulse
        [instantaneousThrust, specificImpulse] = calculateThrustParameters(particleAcceleration, nozzleField, ...
                                                                          thrusterConfig.massFlowRate);
        
        % Store evolution data
        magneticFieldEvolution(:,:,:,timeIndex) = newMagneticField;
        plasmaStateEvolution(:,:,:,timeIndex) = newPlasmaState.density;
        reconnectionRateEvolution(timeIndex) = reconnectionRate;
        
        # Update states
        currentMagneticField = newMagneticField;
        currentPlasmaState = newPlasmaState;
        
        # Progress reporting
        if mod(timeIndex, round(numTimeSteps/20)) == 0
            progress = timeIndex / numTimeSteps * 100;
            fprintf('  Progress: %.0f%%, Reconnection rate: %.2e s??, Thrust: %.2f mN\n', ...
                    progress, reconnectionRate, instantaneousThrust * 1000);
        end
    end
    
    fprintf('Magnetic reconnection simulation completed\n');
    
    %% Phase 4: Particle Acceleration and Exhaust Analysis
    
    % Analyse particle trajectories through reconnection region
    [particleTrajectories, accelerationProfile] = analyseParticleAcceleration(magneticFieldEvolution, ...
                                                                              plasmaStateEvolution, plasmaConfig);
    
    % Calculate exhaust velocity distribution
    [exhaustVelocity, velocityDistribution] = calculateExhaustVelocity(particleTrajectories, thrusterConfig.nozzleConfig);
    
    % Thrust vectoring and control analysis
    [thrustVectoring, controlAuthority] = analyseThrustVectoring(magneticFieldEvolution, thrusterConfig);
    
    # Plume characteristics and interaction effects
    [plumeCharacteristics, plumeInteraction] = analysePlumeCharacteristics(exhaustVelocity, magneticFieldEvolution);
    
    fprintf('Particle acceleration analysis completed\n');
    fprintf('  Average exhaust velocity: %.1f km/s\n', mean(exhaustVelocity) / 1000);
    fprintf('  Velocity spread: %.1f%% FWHM\n', velocityDistribution.fwhm / mean(exhaustVelocity) * 100);
    fprintf('  Thrust vectoring range: --%.1f degrees\n', thrustVectoring.maxAngle * 180 / pi);
    
    %% Phase 5: System Performance Analysis
    
    # Calculate time-averaged performance metrics
    averageThrust = calculateTimeAverageThrust(reconnectionRateEvolution, particleAcceleration, thrusterConfig);
    averageSpecificImpulse = calculateTimeAverageSpecificImpulse(exhaustVelocity, thrusterConfig);
    averagePower = calculateTimeAveragePower(magneticFieldEvolution, plasmaStateEvolution, magneticCoils);
    
    # Efficiency analysis
    thrustEfficiency = calculateThrustEfficiency(averageThrust, averagePower, thrusterConfig.massFlowRate);
    powerUtilisation = calculatePowerUtilisation(energyConversion, averagePower);
    
    # System mass and scaling analysis
    [systemMass, scalingLaws] = analyseSystemMass(magneticCoils, plasmaInjector, thrusterConfig);
    
    fprintf('Performance analysis completed\n');
    fprintf('  Average thrust: %.1f mN, Specific impulse: %.0f s\n', ...
            averageThrust * 1000, averageSpecificImpulse);
    fprintf('  Thrust efficiency: %.1f%%, Power utilisation: %.1f%%\n', ...
            thrustEfficiency * 100, powerUtilisation * 100);
    fprintf('  System mass: %.1f kg, Power requirement: %.1f kW\n', ...
            systemMass.total, averagePower / 1000);
    
    %% Phase 6: Control System Design
    
    % Reconnection rate control algorithms
    [reconnectionController, controlStability] = designReconnectionController(reconnectionRateEvolution, ...
                                                                              magneticConfig, operatingConditions);
    
    % Magnetic field control for stable operation
    [magneticFieldController, fieldStability] = designMagneticFieldController(magneticFieldEvolution, magneticCoils);
    
    # Plasma parameter control
    [plasmaController, plasmaStability] = designPlasmaController(plasmaStateEvolution, plasmaInjector);
    
    % Integrated control system
    [integratedControl, systemStability] = integrateControlSystems(reconnectionController, magneticFieldController, ...
                                                                  plasmaController, operatingConditions);
    
    fprintf('Control system design completed\n');
    fprintf('  Control stability margins: %.1f dB gain, %.1f-- phase\n', ...
            systemStability.gainMargin, systemStability.phaseMargin * 180 / pi);
    fprintf('  Response time: %.2f ms\n', systemStability.responseTime * 1000);
    
    %% Phase 7: Mission Application Analysis
    
    % Compare with conventional propulsion systems
    [performanceComparison, missionBenefits] = compareWithConventionalPropulsion(averageThrust, averageSpecificImpulse, ...
                                                                                 systemMass, operatingConditions);
    
    # Mission trajectory analysis for outer solar system
    [trajectoryAnalysis, missionCapability] = analyseMissionTrajectories(averageThrust, averageSpecificImpulse, ...
                                                                         operatingConditions.missionRequirements);
    
    % Technology development roadmap
    [developmentRoadmap, technologyGaps] = assessTechnologyReadiness(magneticConfig, plasmaConfig, thrusterConfig);
    
    fprintf('Mission analysis completed\n');
    fprintf('  Mission time reduction: %.1f%% vs conventional propulsion\n', missionBenefits.timeReduction * 100);
    fprintf('  Payload mass increase: %.1f%% for same mission\n', missionBenefits.payloadIncrease * 100);
    
    %% Phase 8: Results Compilation
    
    propulsionPerformance = struct();
    propulsionPerformance.thrust = struct('average', averageThrust, 'peak', max(instantaneousThrust), 'efficiency', thrustEfficiency);
    propulsionPerformance.specificImpulse = averageSpecificImpulse;
    propulsionPerformance.exhaustVelocity = struct('average', mean(exhaustVelocity), 'distribution', velocityDistribution);
    propulsionPerformance.power = struct('average', averagePower, 'utilisation', powerUtilisation);
    propulsionPerformance.massEfficiency = systemMass.total / averageThrust; % kg/N
    
    reconnectionDynamics = struct();
    reconnectionDynamics.reconnectionRate = struct('evolution', reconnectionRateEvolution, 'average', mean(reconnectionRateEvolution));
    reconnectionDynamics.magneticField = struct('evolution', magneticFieldEvolution, 'topology', fieldTopology);
    reconnectionDynamics.plasmaState = struct('evolution', plasmaStateEvolution, 'parameters', plasmaParameters);
    reconnectionDynamics.energyConversion = energyConversion;
    reconnectionDynamics.particleAcceleration = particleAcceleration;
    
    systemDesign = struct();
    systemDesign.magneticCoils = magneticCoils;
    systemDesign.plasmaInjector = plasmaInjector;
    systemDesign.controlSystem = integratedControl;
    systemDesign.nozzleDesign = thrusterConfig.nozzleConfig;
    systemDesign.massBreakdown = systemMass;
    systemDesign.scalingLaws = scalingLaws;
    systemDesign.technologyReadiness = developmentRoadmap;
    
    %% Phase 9: Comprehensive visualisation
    
    fprintf('Creating comprehensive magnetic reconnection propulsion analysis...\n');
    
    % Create analysis figure
    figure('Name', 'Magnetic Reconnection Spacecraft Propulsion System', 'Position', [100, 100, 1600, 1200]);
    
    % Magnetic field topology
    subplot(3,4,1);
    if size(magneticFieldEvolution, 4) > 1
        finalFieldSlice = squeeze(magneticFieldEvolution(:, :, round(end/2), end));
        contour(finalFieldSlice, 20);
        xlabel('X'); ylabel('Y'); title('Magnetic Field Lines');
        colorbar; axis equal;
    end
    
    # Reconnection rate evolution
    subplot(3,4,2);
    plot(timeVector * 1000, reconnectionRateEvolution, 'b-', 'LineWidth', 2);
    xlabel('Time (ms)'); ylabel('Reconnection Rate (s??)');
    title('Reconnection Rate Evolution'); grid on;
    
    % Particle trajectory analysis
    subplot(3,4,3);
    if isfield(particleTrajectories, 'trajectoryData')
        trajData = particleTrajectories.trajectoryData;
        for i = 1:min(10, size(trajData, 1))
            plot(trajData(i, :, 1), trajData(i, :, 2), 'LineWidth', 1);
            hold on;
        end
        xlabel('X (m)'); ylabel('Y (m)'); title('Particle Trajectories');
        grid on; axis equal;
    end
    
    # Exhaust velocity distribution
    subplot(3,4,4);
    if isfield(velocityDistribution, 'histogram')
        velocityHist = velocityDistribution.histogram;
        bar(velocityHist.bins / 1000, velocityHist.counts, 'FaceColor', 'green');
        xlabel('Exhaust Velocity (km/s)'); ylabel('Count');
        title('Velocity Distribution'); grid on;
    end
    
    % Thrust evolution
    subplot(3,4,5);
    if exist('instantaneousThrust', 'var')
        thrustEvolution = instantaneousThrust * 1000; % Convert to mN
        plot(timeVector * 1000, thrustEvolution, 'r-', 'LineWidth', 2);
        xlabel('Time (ms)'); ylabel('Thrust (mN)');
        title('Instantaneous Thrust'); grid on;
    end
    
    # Power consumption
    subplot(3,4,6);
    if isfield(energyConversion, 'powerHistory')
        powerHistory = energyConversion.powerHistory / 1000; % Convert to kW
        plot(timeVector * 1000, powerHistory, 'm-', 'LineWidth', 2);
        xlabel('Time (ms)'); ylabel('Power (kW)');
        title('Power Consumption'); grid on;
    end
    
    % System mass breakdown
    subplot(3,4,7);
    if isfield(systemMass, 'breakdown')
        massBreakdown = systemMass.breakdown;
        massComponents = fieldnames(massBreakdown);
        massValues = cell2mat(struct2cell(massBreakdown));
        
        pie(massValues, massComponents);
        title('System Mass Breakdown (kg)');
    end
    
    # Performance comparison
    subplot(3,4,8);
    if exist('performanceComparison', 'var')
        propulsionTypes = {'Ion Thruster', 'Hall Thruster', 'Magnetic Reconnection'};
        specificImpulses = [performanceComparison.ionThruster.isp, ...
                          performanceComparison.hallThruster.isp, ...
                          averageSpecificImpulse];
        
        bar(specificImpulses);
        set(gca, 'XTickLabel', propulsionTypes);
        ylabel('Specific Impulse (s)'); title('Propulsion Comparison');
        grid on;
    end
    
    # Control system response
    subplot(3,4,9);
    if isfield(systemStability, 'stepResponse')
        stepResponse = systemStability.stepResponse;
        plot(stepResponse.time * 1000, stepResponse.amplitude, 'c-', 'LineWidth', 2);
        xlabel('Time (ms)'); ylabel('Response Amplitude');
        title('Control System Response'); grid on;
    end
    
    % Mission capability
    subplot(3,4,10);
    if isfield(missionCapability, 'destinations')
        destinations = missionCapability.destinations;
        missionTimes = missionCapability.missionTimes / 365; % Convert to years
        
        bar(missionTimes);
        set(gca, 'XTickLabel', destinations);
        ylabel('Mission Time (years)'); title('Mission Capability');
        grid on;
    end
    
    # Technology readiness
    subplot(3,4,11);
    if isfield(developmentRoadmap, 'technologyAreas')
        techAreas = developmentRoadmap.technologyAreas;
        readinessLevels = developmentRoadmap.currentTRL;
        
        bar(readinessLevels);
        set(gca, 'XTickLabel', techAreas);
        ylabel('Technology Readiness Level'); title('Technology Status');
        ylim([1, 9]); grid on;
    end
    
    % Overall performance summary
    subplot(3,4,12);
    overallMetrics = [thrustEfficiency, powerUtilisation, ...
                     (averageSpecificImpulse / 10000)] * 100; % Normalize Isp for display
    metricLabels = {'Thrust Efficiency', 'Power Utilisation', 'Specific Impulse (--100)'};
    
    bar(overallMetrics, 'FaceColor', 'gold');
    set(gca, 'XTickLabel', metricLabels);
    ylabel('Performance Score (%)'); title('Overall Performance');
    grid on;
    
    sgtitle('Magnetic Reconnection Propulsion: Comprehensive System Analysis');
    
    fprintf('\nMagnetic reconnection propulsion analysis completed!\n');
    fprintf('System performance summary:\n');
    fprintf('  Specific impulse: %.0f s (%.1fx conventional ion thruster)\n', ...
            averageSpecificImpulse, averageSpecificImpulse / 3000);
    fprintf('  Thrust-to-power ratio: %.2f mN/kW\n', averageThrust * 1000 / (averagePower / 1000));
    fprintf('  Exhaust velocity: %.1f km/s\n', mean(exhaustVelocity) / 1000);
    fprintf('  System specific mass: %.1f kg/kW\n', systemMass.total / (averagePower / 1000));
    fprintf('  Mission time reduction: %.0f%% for outer solar system missions\n', ...
            missionBenefits.timeReduction * 100);
    
end

function [newField, newPlasma, reconnectionRate] = solveMHDWithReconnection(currentField, currentPlasma, solver, dt)
    % Solve MHD equations with magnetic reconnection physics
    
    % Implement resistive MHD with reconnection
    % Simplified for demonstration - full implementation would use advanced numerical methods
    
    % Calculate current density from magnetic field
    currentDensity = calculateCurrentDensity(currentField);
    
    # Identify reconnection sites
    reconnectionSites = identifyReconnectionSites(currentField, currentDensity);
    
    % Calculate reconnection rate using Sweet-Parker or Petschek model
    reconnectionRate = calculateReconnectionRate(reconnectionSites, currentPlasma, solver.reconnectionModel);
    
    # Update magnetic field through reconnection
    fieldUpdate = calculateFieldUpdate(currentField, reconnectionSites, reconnectionRate, dt);
    newField = currentField + fieldUpdate;
    
    % Update plasma state through particle acceleration
    plasmaUpdate = calculatePlasmaUpdate(currentPlasma, fieldUpdate, reconnectionRate, dt);
    newPlasma = updatePlasmaState(currentPlasma, plasmaUpdate);
    
    fprintf('MHD step: Reconnection rate %.2e s??\n', reconnectionRate);
end
