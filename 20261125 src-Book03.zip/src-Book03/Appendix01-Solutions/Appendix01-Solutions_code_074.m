%% Appendix01-Solutions_code_074.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function features = extractFeatures(tweet_text)
    % Preprocessing
    tweet_clean = lower(tweet_text);
    tweet_clean = regexprep(tweet_clean, '@\w+', ''); % Remove mentions
    tweet_clean = regexprep(tweet_clean, 'http\S+', ''); % Remove URLs
    tweet_clean = regexprep(tweet_clean, '#', ''); % Remove hashtag symbols
    
    % Tokenization
    tokens = split(tweet_clean);
    
    % TF-IDF features (assuming vocabulary pre-built)
    global vocabulary tfidf_model;
    bag = bagOfWords(tokens);
    tfidf = tfidf_model.transform(bag);
    
    % Sentiment lexicon features
    afinn = loadAfinnLexicon();
    sentiment_score = sum(arrayfun(@(tok) getScore(afinn, tok), tokens));
    
    % Metadata features
    has_url = contains(tweet_text, 'http');
    has_mention = contains(tweet_text, '@');
    num_hashtags = length(regexp(tweet_text, '#'));
    num_exclamations = length(regexp(tweet_text, '!'));
    
    % Combine features
    features = [tfidf, sentiment_score, has_url, has_mention, ...
                num_hashtags, num_exclamations];
end
