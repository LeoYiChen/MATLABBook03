%% p3.m
% MATLABBook03_ChapterAIBHS_Problem03.m
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : p3
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function MATLABBook03_ChapterAIBHS_Problem03
% Purpose: wavelet ECG arrhythmia detection + latency.
% Author: Dr Leo Chen. R2024b + Wavelet + Statistics ML. v1.0 2025-06-01.
    rng(0); n=150; L=64; t=linspace(-1,1,L);
    normal = exp(-(t.^2)/0.02)+0.05*randn(n,L);
    abnorm = exp(-(t.^2)/0.08)+0.4*sin(6*pi*t)+0.05*randn(n,L);
    beats=[normal;abnorm]; y=[zeros(n,1);ones(n,1)];
    F=cell2mat(arrayfun(@(r) beatFeat(beats(r,:)),(1:2*n)','UniformOutput',false));
    cv=cvpartition(y,'HoldOut',0.3); tr=training(cv); te=test(cv);
    tree=fitctree(F(tr,:),y(tr),'MaxNumSplits',8);
    p=predict(tree,F(te,:)); C=confusionmat(y(te),p);
    fprintf('Accuracy: %.3f  FPR: %.3f\n', sum(diag(C))/sum(C(:)), C(1,2)/sum(C(1,:)));
    fprintf('Latency: %.3f ms\n', timeit(@() predict(tree,F(find(te,1),:)))*1e3);
end
function f = beatFeat(beat)
    [a,d]=dwt(beat,'db4'); f=[sum(a.^2) sum(d.^2) max(beat) min(beat)];
end
