%% chapter_AI_ICT_problem10_solution.m
% Neuromorphic Computing for Edge AI Implementation
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AI_ICT_problem10_solution
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [neuromorphic_results, energy_analysis] = neuromorphicEdgeAI()
% Neuromorphic Computing for Edge AI in Communication Systems
% Author: Dr Leo Chen
% Version: 1.0
% Date: 2024
%
% Implements spiking neural networks for ultra-low power edge AI applications
% in communication systems with comprehensive energy and performance analysis

fprintf('=== Neuromorphic Edge AI Solution ===\n');

% Neuromorphic system configuration
neuromorphic_config = struct();
neuromorphic_config.neuron_model = 'leaky_integrate_fire'; % LIF neuron model
neuromorphic_config.network_topology = 'feed_forward'; % Network architecture
neuromorphic_config.num_input_neurons = 128; % Input layer size
neuromorphic_config.num_hidden_neurons = 256; % Hidden layer size
neuromorphic_config.num_output_neurons = 8; % Output classifications

% Communication task configuration
task_config = struct();
task_config.signal_types = {'BPSK', 'QPSK', '16QAM', '64QAM', 'OFDM', 'FSK', 'PSK', 'QAM'};
task_config.snr_range_db = [-10, 20]; % Operating SNR range
task_config.sample_rate_mhz = 10; % Signal sampling rate
task_config.processing_latency_target_us = 100; % Latency requirement
task_config.energy_budget_nj = 1000; % Energy per inference

% Learning algorithm configuration
learning_config = struct();
learning_config.algorithm = 'surrogate_gradient'; % Learning algorithm
learning_config.stdp_enabled = true; % STDP plasticity
learning_config.learning_rate = 1e-3; % Learning rate
learning_config.num_epochs = 500; % Training epochs
learning_config.adaptation_rate = 0.1; % Online adaptation rate

% Generate neuromorphic-compatible datasets
fprintf('Generating neuromorphic-compatible datasets...\n');
[spike_datasets, temporal_patterns] = generateNeuromorphicDatasets(task_config, neuromorphic_config);

% Implement spiking neural network architectures
fprintf('Implementing spiking neural network architectures...\n');
snn_architectures = implementSpikingNeuralNetworks(neuromorphic_config, learning_config);

% Train neuromorphic models
fprintf('Training neuromorphic models...\n');
[trained_models, training_history] = trainNeuromorphicModels(snn_architectures, ...
spike_datasets, ...
learning_config);

% Implement real-time processing frameworks
fprintf('Implementing real-time processing frameworks...\n');
realtime_frameworks = implementRealtimeProcessing(trained_models, task_config);

% Analyse energy consumption characteristics
fprintf('Analysing energy consumption...\n');
energy_analysis = analyseEnergyConsumption(trained_models, realtime_frameworks, task_config);

% Evaluate performance against digital baselines
fprintf('Evaluating performance against digital baselines...\n');
performance_comparison = evaluatePerformanceComparison(trained_models, energy_analysis, task_config);

% Implement adaptive learning mechanisms
fprintf('Implementing adaptive learning mechanisms...\n');
adaptive_learning_results = implementAdaptiveLearning(trained_models, spike_datasets, learning_config);

% Compile comprehensive results
neuromorphic_results = struct();
neuromorphic_results.trained_models = trained_models;
neuromorphic_results.training_history = training_history;
neuromorphic_results.realtime_performance = realtime_frameworks;
neuromorphic_results.performance_comparison = performance_comparison;
neuromorphic_results.adaptive_learning = adaptive_learning_results;

% Generate comprehensive visualisations
generateNeuromorphicVisualisations(neuromorphic_results, energy_analysis);

fprintf('Neuromorphic edge AI analysis completed successfully!\n');
end

function [spike_datasets, temporal_patterns] = generateNeuromorphicDatasets(task_config, neuromorphic_config)
% Generate datasets compatible with neuromorphic processing

spike_datasets = struct();
num_signals_per_type = 1000;
signal_types = task_config.signal_types;

fprintf(' Converting communication signals to spike trains...\n');

for signal_idx = 1:length(signal_types)
signal_type = signal_types{signal_idx};

 
% Generate communication signals
raw_signals = generateCommunicationSignals(signal_type, num_signals_per_type, task_config);

% Convert to spike trains using temporal encoding
spike_trains = convertToSpikeTrains(raw_signals, neuromorphic_config);

% Extract temporal patterns
temporal_patterns_per_type = extractTemporalPatterns(spike_trains, neuromorphic_config);

spike_datasets.(signal_type) = spike_trains;
temporal_patterns.(signal_type) = temporal_patterns_per_type;
end

fprintf(' Neuromorphic datasets generated for %d signal types\n', length(signal_types));
end

function spike_trains = convertToSpikeTrains(raw_signals, neuromorphic_config)
% Convert analog signals to spike trains using rate and temporal encoding

num_signals = size(raw_signals, 2);
signal_length = size(raw_signals, 1);
num_input_neurons = neuromorphic_config.num_input_neurons;

% Initialise spike train storage
spike_trains = struct();
spike_trains.times = cell(num_signals, num_input_neurons);
spike_trains.patterns = zeros(num_signals, num_input_neurons, signal_length);

fprintf(' Converting %d signals to spike trains...\n', num_signals);

for signal_idx = 1:num_signals
signal = raw_signals(:, signal_idx);

 
% Normalise signal to [0, 1] range
normalised_signal = (signal - min(signal)) / (max(signal) - min(signal) + eps);

% Rate encoding: spike probability proportional to signal amplitude
spike_probabilities = repmat(normalised_signal, 1, num_input_neurons);

% Add temporal structure through phase encoding
for neuron_idx = 1:num_input_neurons
    phase_shift = (neuron_idx - 1) / num_input_neurons * 2 * pi;
    temporal_modulation = 0.5 * (1 + sin(phase_shift + (1:signal_length)' * 0.1));
    spike_probabilities(:, neuron_idx) = spike_probabilities(:, neuron_idx) .* temporal_modulation;
end

% Generate spike trains using Poisson process
spike_pattern = rand(signal_length, num_input_neurons) < spike_probabilities;

% Extract spike times for each neuron
for neuron_idx = 1:num_input_neurons
    spike_times = find(spike_pattern(:, neuron_idx));
    spike_trains.times{signal_idx, neuron_idx} = spike_times;
end

spike_trains.patterns(signal_idx, :, :) = spike_pattern';
end

fprintf(' Spike train conversion completed\n');
end

function snn_architectures = implementSpikingNeuralNetworks(neuromorphic_config, learning_config)
% Implement comprehensive spiking neural network architectures

snn_architectures = struct();

% Leaky Integrate-and-Fire (LIF) network
fprintf(' Implementing LIF spiking neural network...\n');
snn_architectures.lif_network = implementLIFNetwork(neuromorphic_config);

% Adaptive Exponential Integrate-and-Fire (AdEx) network
fprintf(' Implementing AdEx spiking neural network...\n');
snn_architectures.adex_network = implementAdExNetwork(neuromorphic_config);

% Izhikevich neuron network
fprintf(' Implementing Izhikevich spiking neural network...\n');
snn_architectures.izhikevich_network = implementIzhikevichNetwork(neuromorphic_config);

fprintf(' SNN architectures implemented: %d network types\n', length(fieldnames(snn_architectures)));
end

function lif_network = implementLIFNetwork(config)
% Implement Leaky Integrate-and-Fire spiking neural network

lif_network = struct();
lif_network.neuron_model = 'leaky_integrate_fire';

% Network topology
lif_network.topology = struct();
lif_network.topology.input_layer_size = config.num_input_neurons;
lif_network.topology.hidden_layer_size = config.num_hidden_neurons;
lif_network.topology.output_layer_size = config.num_output_neurons;

% LIF neuron parameters
lif_network.neuron_params = struct();
lif_network.neuron_params.membrane_time_constant = 20e-3; % 20 ms
lif_network.neuron_params.resting_potential = -65e-3; % -65 mV
lif_network.neuron_params.threshold_potential = -50e-3; % -50 mV
lif_network.neuron_params.reset_potential = -70e-3; % -70 mV
lif_network.neuron_params.refractory_period = 2e-3; % 2 ms
lif_network.neuron_params.membrane_resistance = 10e6; % 10 M--

% Synaptic parameters
lif_network.synapse_params = struct();
lif_network.synapse_params.excitatory_weight_range = [0, 1];
lif_network.synapse_params.inhibitory_weight_range = [-1, 0];
lif_network.synapse_params.synaptic_delay_range = [1e-3, 5e-3]; % 1-5 ms
lif_network.synapse_params.stdp_window = 20e-3; % STDP window

% Connection matrices
lif_network.connections = struct();
lif_network.connections.input_to_hidden = generateConnectionMatrix(config.num_input_neurons, ...
config.num_hidden_neurons, ...
0.8); % 80% connectivity
lif_network.connections.hidden_to_output = generateConnectionMatrix(config.num_hidden_neurons, ...
config.num_output_neurons, ...
1.0); % Full connectivity

% Weight matrices
lif_network.weights = struct();
lif_network.weights.input_to_hidden = (rand(config.num_hidden_neurons, config.num_input_neurons) - 0.5) * 2;
lif_network.weights.hidden_to_output = (rand(config.num_output_neurons, config.num_hidden_neurons) - 0.5) * 2;

% State variables
lif_network.states = struct();
lif_network.states.membrane_potentials = zeros(config.num_hidden_neurons + config.num_output_neurons, 1);
lif_network.states.spike_times = cell(config.num_hidden_neurons + config.num_output_neurons, 1);
lif_network.states.refractory_timers = zeros(config.num_hidden_neurons + config.num_output_neurons, 1);

% Simulation parameters
lif_network.simulation = struct();
lif_network.simulation.time_step = 1e-4; % 0.1 ms time step
lif_network.simulation.simulation_duration = 100e-3; % 100 ms simulation

fprintf(' LIF network implemented: %d -- %d -- %d architecture\n', ...
config.num_input_neurons, config.num_hidden_neurons, config.num_output_neurons);
end

function energy_analysis = analyseEnergyConsumption(trained_models, realtime_frameworks, task_config)
% Comprehensive energy consumption analysis

energy_analysis = struct();
model_names = fieldnames(trained_models);

fprintf(' Analysing energy consumption for each model...\n');

for model_idx = 1:length(model_names)
model_name = model_names{model_idx};
model = trained_models.(model_name);
 
% Calculate spike-based energy consumption
spike_energy = calculateSpikeEnergy(model, task_config);

% Calculate synaptic energy consumption
synaptic_energy = calculateSynapticEnergy(model, task_config);

% Calculate leakage energy consumption
leakage_energy = calculateLeakageEnergy(model, task_config);

% Total energy per inference
total_energy_per_inference = spike_energy + synaptic_energy + leakage_energy;

% Energy efficiency metrics
energy_per_operation = total_energy_per_inference / model.topology.total_operations;
energy_per_spike = total_energy_per_inference / model.statistics.average_spikes_per_inference;

% Comparison with digital baseline
digital_baseline_energy = calculateDigitalBaselineEnergy(model, task_config);
energy_efficiency_ratio = digital_baseline_energy / total_energy_per_inference;

% Store energy analysis results
energy_analysis.(model_name) = struct();
energy_analysis.(model_name).spike_energy = spike_energy;
energy_analysis.(model_name).synaptic_energy = synaptic_energy;
energy_analysis.(model_name).leakage_energy = leakage_energy;
energy_analysis.(model_name).total_energy = total_energy_per_inference;
energy_analysis.(model_name).energy_per_operation = energy_per_operation;
energy_analysis.(model_name).energy_per_spike = energy_per_spike;
energy_analysis.(model_name).efficiency_ratio = energy_efficiency_ratio;

fprintf('    %s: %.2f nJ per inference (%.1fx more efficient than digital)\n', ...
        upper(model_name), total_energy_per_inference * 1e9, energy_efficiency_ratio);
end

% Overall energy analysis summary
energy_analysis.summary = struct();
energy_analysis.summary.best_efficiency = calculateBestEfficiency(energy_analysis);
energy_analysis.summary.average_energy = calculateAverageEnergy(energy_analysis);
energy_analysis.summary.energy_breakdown = calculateEnergyBreakdown(energy_analysis);

fprintf(' Energy consumption analysis completed\n');
end
