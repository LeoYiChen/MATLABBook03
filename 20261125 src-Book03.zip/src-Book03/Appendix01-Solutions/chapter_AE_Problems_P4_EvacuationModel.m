%% chapter_AE_Problems_P4_EvacuationModel.m
% Social force model for launch facility evacuation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AE_Problems_P4_EvacuationModel
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [evacuationResults, flowAnalysis] = launchFacilityEvacuation(facilityLayout, personnelData, emergencyScenario)
    % Social force model for launch facility evacuation simulation
    % Author: Dr Leo Chen
    % Version: 1.8.0 - Enhanced with personnel type differentiation  
    % Date: 2024-11-14
    
    fprintf('Launch Facility Evacuation Simulation\n');
    fprintf('Total personnel: %d, Facility area: %.2f km?\n', ...
            length(personnelData), facilityLayout.totalArea / 1e6);
    fprintf('Emergency scenario: %s\n', emergencyScenario.type);
    
    % Simulation parameters
    timeStep = emergencyScenario.timeStep;
    maxSimulationTime = emergencyScenario.maxTime;
    timeVector = 0:timeStep:maxSimulationTime;
    numTimeSteps = length(timeVector);
    
    % Initialize personnel positions and states
    numPersonnel = length(personnelData);
    personnelPositions = zeros(numPersonnel, 2, numTimeSteps);
    personnelVelocities = zeros(numPersonnel, 2, numTimeSteps);
    personnelStates = zeros(numPersonnel, numTimeSteps); % 0: normal, 1: alarmed, 2: evacuated
    
    % Set initial positions
    for personIndex = 1:numPersonnel
        personnelPositions(personIndex, :, 1) = personnelData(personIndex).initialPosition;
        personnelStates(personIndex, 1) = 0; % Initially normal state
    end
    
    % Evacuation tracking
    evacuationTimes = zeros(numPersonnel, 1);
    evacuatedCount = 0;
    
    fprintf('Simulation initialised, starting temporal evolution...\n');
    
    % Main simulation loop
    for timeIndex = 2:numTimeSteps
        currentTime = timeVector(timeIndex);
        
        % Update alarm propagation
        alarmRadius = emergencyScenario.alarmSpeed * currentTime;
        
        % Process each person
        for personIndex = 1:numPersonnel
            if personnelStates(personIndex, timeIndex-1) < 2 % Not yet evacuated
                currentPosition = personnelPositions(personIndex, :, timeIndex-1);
                currentVelocity = personnelVelocities(personIndex, :, timeIndex-1);
                
                % Check if person becomes aware of emergency
                if personnelStates(personIndex, timeIndex-1) == 0 % Normal state
                    alarmDistance = norm(currentPosition - emergencyScenario.alarmOrigin);
                    if alarmDistance <= alarmRadius
                        personnelStates(personIndex, timeIndex) = 1; % Alarmed
                        fprintf('Person %d alarmed at t=%.1fs\n', personIndex, currentTime);
                    else
                        personnelStates(personIndex, timeIndex) = 0; % Still normal
                    end
                else
                    personnelStates(personIndex, timeIndex) = 1; % Remain alarmed
                end
                
                % Calculate social forces
                totalForce = calculateLaunchFacilitySocialForces(personIndex, personnelPositions(:,:,timeIndex-1), ...
                                                               personnelData, facilityLayout, ...
                                                               personnelStates(personIndex, timeIndex));
                
                % Apply force limits based on person type
                maxForce = personnelData(personIndex).maxForce;
                forceMagnitude = norm(totalForce);
                if forceMagnitude > maxForce
                    totalForce = totalForce * maxForce / forceMagnitude;
                end
                
                % Update velocity and position using Euler integration
                mass = personnelData(personIndex).mass;
                acceleration = totalForce / mass;
                
                newVelocity = currentVelocity + acceleration * timeStep;
                
                % Apply velocity constraints
                maxSpeed = personnelData(personIndex).maxSpeed;
                if personnelStates(personIndex, timeIndex) == 1 % Alarmed state
                    maxSpeed = maxSpeed * emergencyScenario.panicSpeedMultiplier;
                end
                
                velocityMagnitude = norm(newVelocity);
                if velocityMagnitude > maxSpeed
                    newVelocity = newVelocity * maxSpeed / velocityMagnitude;
                end
                
                newPosition = currentPosition + newVelocity * timeStep;
                
                % Check for facility boundaries and obstacles
                [newPosition, newVelocity] = enforceFacilityConstraints(newPosition, newVelocity, ...
                                                                       facilityLayout);
                
                % Check if person has reached an exit
                [hasExited, exitReached] = checkExitReached(newPosition, facilityLayout.exits, ...
                                                           emergencyScenario.exitTolerance);
                
                if hasExited
                    personnelStates(personIndex, timeIndex) = 2; % Evacuated
                    evacuationTimes(personIndex) = currentTime;
                    evacuatedCount = evacuatedCount + 1;
                    fprintf('Person %d evacuated via exit %d at t=%.1fs\n', ...
                            personIndex, exitReached, currentTime);
                else
                    personnelPositions(personIndex, :, timeIndex) = newPosition;
                    personnelVelocities(personIndex, :, timeIndex) = newVelocity;
                end
            else
                % Person already evacuated
                personnelStates(personIndex, timeIndex) = 2;
            end
        end
        
        % Progress reporting
        if mod(timeIndex, round(numTimeSteps/20)) == 0
            progress = timeIndex / numTimeSteps * 100;
            evacuationProgress = evacuatedCount / numPersonnel * 100;
            fprintf('Time: %.1fs (%.0f%% complete), Evacuated: %d/%d (%.1f%%)\n', ...
                    currentTime, progress, evacuatedCount, numPersonnel, evacuationProgress);
        end
        
        % Check if everyone evacuated
        if evacuatedCount == numPersonnel
            fprintf('All personnel evacuated at t=%.1fs\n', currentTime);
            break;
        end
    end
    
    % Calculate evacuation statistics
    evacuationResults = analyseEvacuationResults(evacuationTimes, personnelData, facilityLayout, timeVector);
    flowAnalysis = analyseEvacuationFlow(personnelPositions, personnelStates, facilityLayout, timeVector);
    
    fprintf('Evacuation simulation completed\n');
    fprintf('Total evacuation time: %.1f minutes\n', max(evacuationTimes) / 60);
    fprintf('Average evacuation time: %.1f minutes\n', mean(evacuationTimes(evacuationTimes > 0)) / 60);
end

function totalForce = calculateLaunchFacilitySocialForces(personIndex, allPositions, personnelData, facilityLayout, personState)
    % Calculate social forces for launch facility evacuation
    
    currentPosition = allPositions(personIndex, :);
    personData = personnelData(personIndex);
    
    % Social force parameters
    socialForceParams = getSocialForceParameters(personData.type, personState);
    
    % 1. Goal-seeking force towards nearest exit
    nearestExit = findNearestExit(currentPosition, facilityLayout.exits, personData.accessLevel);
    exitDirection = (nearestExit.position - currentPosition);
    exitDistance = norm(exitDirection);
    
    if exitDistance > 0
        exitDirection = exitDirection / exitDistance;
        desiredVelocity = personData.desiredSpeed * exitDirection;
        goalForce = (desiredVelocity - [0, 0]) / socialForceParams.relaxationTime; % Assuming zero current velocity
    else
        goalForce = [0, 0];
    end
    
    % 2. Repulsive forces from other people
    repulsiveForce = [0, 0];
    for otherIndex = 1:size(allPositions, 1)
        if otherIndex ~= personIndex
            otherPosition = allPositions(otherIndex, :);
            distanceVector = currentPosition - otherPosition;
            distance = norm(distanceVector);
            
            if distance > 0 && distance < socialForceParams.interactionRange
                directionVector = distanceVector / distance;
                
                % Exponential repulsion
                repulsionMagnitude = socialForceParams.repulsionStrength * ...
                                   exp((personData.radius + personnelData(otherIndex).radius - distance) / ...
                                       socialForceParams.repulsionRange);
                
                repulsiveForce = repulsiveForce + repulsionMagnitude * directionVector;
            end
        end
    end
    
    % 3. Forces from facility walls and obstacles
    wallForce = calculateWallForces(currentPosition, facilityLayout.walls, socialForceParams);
    
    % 4. Random fluctuation force
    fluctuationForce = socialForceParams.fluctuationStrength * randn(1, 2);
    
    % 5. Leader-following force (for guided evacuation)
    leaderForce = [0, 0];
    if isfield(personData, 'followsLeader') && personData.followsLeader
        leaderPosition = findLeaderPosition(allPositions, personnelData, personData.leaderID);
        if ~isempty(leaderPosition)
            leaderDirection = leaderPosition - currentPosition;
            leaderDistance = norm(leaderDirection);
            if leaderDistance > 0
                leaderForce = socialForceParams.leaderAttraction * leaderDirection / leaderDistance;
            end
        end
    end
    
    % Combine all forces
    totalForce = goalForce + repulsiveForce + wallForce + fluctuationForce + leaderForce;
end
