%% css_leslie.m
% Leslie matrix population projection.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : css_leslie
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [projection, growthRate] = projectPopulation(fertility, survival, ...
                                                      initialAges, numYears)
% projectPopulation  Age-structured projection via a Leslie matrix.
%   [projection, growthRate] = projectPopulation(fertility, survival, ...
%                                                initialAges, numYears)
%   fertility : 1-by-n row, survival : 1-by-(n-1) sub-diagonal.
%   Author: Dr Leo Chen | Version 1.0 | Base MATLAB (R2021b+)

    numAges = numel(fertility);
    leslie = zeros(numAges);
    leslie(1, :) = fertility;
    leslie(2:end, 1:end-1) = diag(survival);

    projection = zeros(numAges, numYears + 1);
    projection(:, 1) = initialAges(:);
    for year = 1:numYears
        projection(:, year + 1) = leslie * projection(:, year);
    end

    growthRate = max(abs(eig(leslie)));      % dominant eigenvalue
    fprintf('Long-run growth rate = %.4f\n', growthRate);
end
