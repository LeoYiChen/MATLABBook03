%% chapter_AI_CV_problem3_complete.m
% Advanced GPU Memory Management System.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AI_CV_problem3_complete
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% Advanced GPU Memory Management System
% Author: Dr Leo Chen
% Created: January 2025
% MATLAB Version: R2024a or later

function memoryResults = advancedGPUMemoryManagement()
    fprintf('Advanced GPU Memory Management System\n');
    
    % Check GPU availability
    if ~canUseGPU()
        fprintf('GPU not available. Using CPU simulation.\n');
        memoryResults = simulateCPUProcessing();
        return;
    end
    
    % Initialize GPU memory manager
    memoryManager = initializeGPUMemoryManager();
    
    % Perform memory management tests
    memoryResults = performMemoryManagementTests(memoryManager);
    
    % Visualise results
    visualiseMemoryResults(memoryResults);
end

function available = canUseGPU()
    try
        gpu = gpuDevice();
        available = true;
        fprintf('GPU detected: %s (%.1f GB memory)\n', gpu.Name, gpu.TotalMemory/1e9);
    catch
        available = false;
    end
end

function results = simulateCPUProcessing()
    % Simulate GPU processing on CPU for demonstration
    results = struct();
    results.method = 'CPU Simulation';
    results.processingTimes = [0.5, 0.3, 0.2, 0.4, 0.6]; % Simulated times
    results.memoryUsage = [2.1, 1.8, 1.5, 2.3, 2.8]; % Simulated memory in GB
    results.throughput = 1000 ./ results.processingTimes; % Images per second
    
    fprintf('CPU simulation completed\n');
end

function manager = initializeGPUMemoryManager()
    manager = struct();
    
    % GPU information
    gpu = gpuDevice();
    manager.totalMemory = gpu.TotalMemory;
    manager.availableMemory = gpu.AvailableMemory;
    
    % Memory pool configuration
    manager.poolSize = manager.availableMemory * 0.8; % Use 80% of available memory
    manager.allocatedBlocks = containers.Map('KeyType', 'int32', 'ValueType', 'any');
    manager.freeBlocks = [];
    manager.nextBlockID = 1;
    
    % Performance monitoring
    manager.allocationCount = 0;
    manager.deallocationCount = 0;
    manager.totalAllocated = 0;
    manager.peakUsage = 0;
    
    fprintf('GPU memory manager initialized\n');
    fprintf('Total GPU memory: %.1f GB\n', manager.totalMemory/1e9);
    fprintf('Memory pool size: %.1f GB\n', manager.poolSize/1e9);
end

function results = performMemoryManagementTests(manager)
    results = struct();
    
    % Test 1: Basic allocation and deallocation
    results.basicAllocation = testBasicAllocation(manager);
    
    % Test 2: Streaming data processing
    results.streamingProcessing = testStreamingProcessing(manager);
    
    % Test 3: Adaptive batch sizing
    results.adaptiveBatching = testAdaptiveBatching(manager);
    
    % Test 4: Memory fragmentation handling
    results.fragmentationHandling = testFragmentationHandling(manager);
    
    % Test 5: Performance profiling
    results.performanceProfiling = profileMemoryPerformance(manager);
    
    fprintf('Memory management tests completed\n');
end

function result = testBasicAllocation(manager)
    fprintf('Testing basic allocation and deallocation...\n');
    
    result = struct();
    result.testName = 'Basic Allocation';
    
    % Test different allocation sizes
    testSizes = [100, 500, 1000, 2000, 5000]; % Number of images
    imageSize = [224, 224, 3]; % Standard CNN input size
    bytesPerImage = prod(imageSize) * 4; % Single precision float
    
    allocationTimes = zeros(size(testSizes));
    deallocationTimes = zeros(size(testSizes));
    memoryUsage = zeros(size(testSizes));
    
    for testIndex = 1:length(testSizes)
        numImages = testSizes(testIndex);
        totalBytes = numImages * bytesPerImage;
        
        % Allocation test
        tic;
        gpuData = allocateGPUMemory(manager, totalBytes, numImages);
        allocationTimes(testIndex) = toc;
        
        % Memory usage
        memInfo = memory;
        memoryUsage(testIndex) = memInfo.MemUsedMATLAB;
        
        % Deallocation test
        tic;
        deallocateGPUMemory(manager, gpuData);
        deallocationTimes(testIndex) = toc;
    end
    
    result.testSizes = testSizes;
    result.allocationTimes = allocationTimes;
    result.deallocationTimes = deallocationTimes;
    result.memoryUsage = memoryUsage;
    result.efficiency = testSizes ./ allocationTimes; % Images per second
end

function gpuData = allocateGPUMemory(manager, totalBytes, numImages)
    try
        % Attempt GPU allocation
        gpuData = gpuArray(zeros(224, 224, 3, numImages, 'single'));
        manager.allocationCount = manager.allocationCount + 1;
        manager.totalAllocated = manager.totalAllocated + totalBytes;
    catch ME
        % Fallback to CPU if GPU memory insufficient
        fprintf('GPU allocation failed, using CPU: %s\n', ME.message);
        gpuData = zeros(224, 224, 3, numImages, 'single');
    end
end

function deallocateGPUMemory(manager, gpuData)
    try
        if isa(gpuData, 'gpuArray')
            clear gpuData;
            manager.deallocationCount = manager.deallocationCount + 1;
        end
    catch ME
        fprintf('Deallocation warning: %s\n', ME.message);
    end
end

function result = testStreamingProcessing(manager)
    fprintf('Testing streaming data processing...\n');
    
    result = struct();
    result.testName = 'Streaming Processing';
    
    % Simulate large dataset that doesn't fit in GPU memory
    totalImages = 10000;
    batchSizes = [16, 32, 64, 128, 256];
    
    processingTimes = zeros(size(batchSizes));
    memoryEfficiency = zeros(size(batchSizes));
    throughput = zeros(size(batchSizes));
    
    for batchIndex = 1:length(batchSizes)
        batchSize = batchSizes(batchIndex);
        numBatches = ceil(totalImages / batchSize);
        
        tic;
        totalProcessed = 0;
        maxMemoryUsed = 0;
        
        for batch = 1:numBatches
            % Simulate batch processing
            currentBatchSize = min(batchSize, totalImages - totalProcessed);
            
            % Allocate memory for current batch
            batchData = allocateGPUMemory(manager, currentBatchSize * prod([224, 224, 3]) * 4, currentBatchSize);
            
            % Simulate processing
            processedBatch = processBatchOnGPU(batchData);
            
            % Track memory usage
            if isa(batchData, 'gpuArray')
                currentMemory = whos('batchData');
                maxMemoryUsed = max(maxMemoryUsed, currentMemory.bytes);
            end
            
            % Clean up
            deallocateGPUMemory(manager, batchData);
            clear processedBatch;
            
            totalProcessed = totalProcessed + currentBatchSize;
        end
        
        processingTimes(batchIndex) = toc;
        memoryEfficiency(batchIndex) = maxMemoryUsed;
        throughput(batchIndex) = totalImages / processingTimes(batchIndex);
    end
    
    result.batchSizes = batchSizes;
    result.processingTimes = processingTimes;
    result.memoryEfficiency = memoryEfficiency;
    result.throughput = throughput;
    result.optimalBatchSize = batchSizes(throughput == max(throughput));
end

function processedData = processBatchOnGPU(batchData)
    % Simulate CNN processing on GPU
    try
        if isa(batchData, 'gpuArray')
            % Simulate convolution operation
            processedData = sum(batchData, [1, 2, 3]);
        else
            % CPU fallback
            processedData = sum(batchData, [1, 2, 3]);
        end
    catch
        processedData = [];
    end
end

function result = testAdaptiveBatching(manager)
    fprintf('Testing adaptive batch sizing...\n');
    
    result = struct();
    result.testName = 'Adaptive Batching';
    
    % Test adaptive batch sizing based on available memory
    targetMemoryUsage = 0.7; % Use 70% of available GPU memory
    
    if manager.availableMemory > 0
        maxBatchSize = floor(manager.availableMemory * targetMemoryUsage / (prod([224, 224, 3]) * 4));
    else
        maxBatchSize = 32; % Default for CPU
    end
    
    % Test with varying memory pressure
    memoryPressure = [0.1, 0.3, 0.5, 0.7, 0.9]; % Fraction of memory already used
    adaptiveBatchSizes = zeros(size(memoryPressure));
    
    for pressureIndex = 1:length(memoryPressure)
        pressure = memoryPressure(pressureIndex);
        availableMemory = manager.availableMemory * (1 - pressure);
        
        if availableMemory > 0
            adaptiveBatchSize = floor(availableMemory * targetMemoryUsage / (prod([224, 224, 3]) * 4));
            adaptiveBatchSizes(pressureIndex) = max(1, min(adaptiveBatchSize, maxBatchSize));
        else
            adaptiveBatchSizes(pressureIndex) = 1;
        end
    end
    
    result.memoryPressure = memoryPressure;
    result.adaptiveBatchSizes = adaptiveBatchSizes;
    result.maxBatchSize = maxBatchSize;
    result.memoryEfficiency = adaptiveBatchSizes / maxBatchSize;
end

function result = testFragmentationHandling(manager)
    fprintf('Testing memory fragmentation handling...\n');
    
    result = struct();
    result.testName = 'Fragmentation Handling';
    
    % Simulate memory fragmentation scenario
    numAllocations = 20;
    allocationSizes = randi([50, 500], numAllocations, 1); % Random allocation sizes
    
    fragmentationLevels = zeros(numAllocations, 1);
    allocationSuccess = zeros(numAllocations, 1);
    
    allocatedData = cell(numAllocations, 1);
    
    for allocIndex = 1:numAllocations
        try
            % Attempt allocation
            currentSize = allocationSizes(allocIndex);
            allocatedData{allocIndex} = allocateGPUMemory(manager, currentSize * prod([224, 224, 3]) * 4, currentSize);
            allocationSuccess(allocIndex) = 1;
            
            % Simulate fragmentation by randomly deallocating some previous allocations
            if allocIndex > 5 && rand() > 0.7
                deallocIndex = randi(allocIndex - 1);
                if ~isempty(allocatedData{deallocIndex})
                    deallocateGPUMemory(manager, allocatedData{deallocIndex});
                    allocatedData{deallocIndex} = [];
                end
            end
            
            % Estimate fragmentation level (simplified)
            fragmentationLevels(allocIndex) = 1 - (sum(allocationSuccess(1:allocIndex)) / allocIndex);
            
        catch
            allocationSuccess(allocIndex) = 0;
            fragmentationLevels(allocIndex) = 1;
        end
    end
    
    % Clean up remaining allocations
    for cleanupIndex = 1:numAllocations
        if ~isempty(allocatedData{cleanupIndex})
            deallocateGPUMemory(manager, allocatedData{cleanupIndex});
        end
    end
    
    result.allocationSizes = allocationSizes;
    result.allocationSuccess = allocationSuccess;
    result.fragmentationLevels = fragmentationLevels;
    result.successRate = mean(allocationSuccess);
    result.averageFragmentation = mean(fragmentationLevels);
end

function result = profileMemoryPerformance(manager)
    fprintf('Profiling memory performance...\n');
    
    result = struct();
    result.testName = 'Performance Profiling';
    
    % Profile memory operations
    profileOperations = {'small_alloc', 'large_alloc', 'streaming', 'batch_process'};
    operationTimes = zeros(size(profileOperations));
    memoryFootprint = zeros(size(profileOperations));
    
    for opIndex = 1:length(profileOperations)
        operation = profileOperations{opIndex};
        
        tic;
        switch operation
            case 'small_alloc'
                % Small frequent allocations
                for smallAlloc = 1:100
                    data = allocateGPUMemory(manager, 10 * prod([224, 224, 3]) * 4, 10);
                    deallocateGPUMemory(manager, data);
                end
                
            case 'large_alloc'
                % Large single allocation
                data = allocateGPUMemory(manager, 1000 * prod([224, 224, 3]) * 4, 1000);
                deallocateGPUMemory(manager, data);
                
            case 'streaming'
                % Streaming simulation
                for stream = 1:10
                    data = allocateGPUMemory(manager, 100 * prod([224, 224, 3]) * 4, 100);
                    processedData = processBatchOnGPU(data);
                    deallocateGPUMemory(manager, data);
                    clear processedData;
                end
                
            case 'batch_process'
                % Batch processing simulation
                batchData = allocateGPUMemory(manager, 500 * prod([224, 224, 3]) * 4, 500);
                for batchOp = 1:5
                    processedData = processBatchOnGPU(batchData);
                    clear processedData;
                end
                deallocateGPUMemory(manager, batchData);
        end
        
        operationTimes(opIndex) = toc;
        
        % Estimate memory footprint
        memInfo = memory;
        memoryFootprint(opIndex) = memInfo.MemUsedMATLAB;
    end
    
    result.operations = profileOperations;
    result.operationTimes = operationTimes;
    result.memoryFootprint = memoryFootprint;
    result.efficiency = 1 ./ operationTimes; % Operations per second
end

function visualiseMemoryResults(results)
    figure('Position', [100, 100, 1400, 1000]);
    
    % Basic allocation performance
    if isfield(results, 'basicAllocation')
        subplot(2, 3, 1);
        ba = results.basicAllocation;
        plot(ba.testSizes, ba.allocationTimes, 'b-o', 'LineWidth', 2);
        xlabel('Number of Images');
        ylabel('Allocation Time (s)');
        title('Memory Allocation Performance');
        grid on;
    end
    
    % Streaming processing throughput
    if isfield(results, 'streamingProcessing')
        subplot(2, 3, 2);
        sp = results.streamingProcessing;
        bar(sp.throughput);
        set(gca, 'XTickLabel', arrayfun(@num2str, sp.batchSizes, 'UniformOutput', false));
        xlabel('Batch Size');
        ylabel('Throughput (Images/s)');
        title('Streaming Processing Throughput');
    end
    
    % Adaptive batch sizing
    if isfield(results, 'adaptiveBatching')
        subplot(2, 3, 3);
        ab = results.adaptiveBatching;
        plot(ab.memoryPressure, ab.adaptiveBatchSizes, 'r-s', 'LineWidth', 2);
        xlabel('Memory Pressure');
        ylabel('Adaptive Batch Size');
        title('Adaptive Batch Sizing');
        grid on;
    end
    
    % Fragmentation analysis
    if isfield(results, 'fragmentationHandling')
        subplot(2, 3, 4);
        fh = results.fragmentationHandling;
        plot(fh.fragmentationLevels, 'g-^', 'LineWidth', 2);
        xlabel('Allocation Number');
        ylabel('Fragmentation Level');
        title('Memory Fragmentation');
        grid on;
    end
    
    % Performance profiling
    if isfield(results, 'performanceProfiling')
        subplot(2, 3, 5);
        pp = results.performanceProfiling;
        bar(pp.operationTimes);
        set(gca, 'XTickLabel', pp.operations);
        xtickangle(45);
        ylabel('Operation Time (s)');
        title('Performance Profiling');
    end
    
    % Memory efficiency summary
    subplot(2, 3, 6);
    if isfield(results, 'basicAllocation') && isfield(results, 'streamingProcessing')
        efficiency_basic = mean(results.basicAllocation.efficiency);
        efficiency_streaming = mean(results.streamingProcessing.throughput);
        
        bar([efficiency_basic, efficiency_streaming]);
        set(gca, 'XTickLabel', {'Basic Allocation', 'Streaming'});
        ylabel('Efficiency (Images/s)');
        title('Memory Management Efficiency');
    end
    
    sgtitle('GPU Memory Management Performance Analysis');
end

% Execute main function
memoryResults = advancedGPUMemoryManagement();
