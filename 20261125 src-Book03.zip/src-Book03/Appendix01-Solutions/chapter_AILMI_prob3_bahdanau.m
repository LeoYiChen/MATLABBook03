%% chapter_AILMI_prob3_bahdanau.m
% Bahdanau additive attention implementation.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AILMI_prob3_bahdanau
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [context, alignments] = bahdanauAttention(decoderState, encoderHiddens, Wa, Ua, v)
    % decoderState: [batchSize x hiddenDim]
    % encoderHiddens: [batchSize x seqLen x hiddenDim]
    % Returns context vector and attention weights
    
    batchSize = size(encoderHiddens, 1);
    seqLen = size(encoderHiddens, 2);
    hiddenDim = size(encoderHiddens, 3);
    
    % Expand decoder state to match encoder sequence length
    decoderExpanded = repmat(decoderState, [1, 1, seqLen]); % [batch x hidden x seqLen]
    decoderExpanded = permute(decoderExpanded, [1, 3, 2]); % [batch x seqLen x hidden]
    
    % Compute alignment scores: v^T * tanh(Wa*s + Ua*h)
    energies = zeros(batchSize, seqLen);
    for i = 1:batchSize
        for j = 1:seqLen
            s = decoderState(i, :)'; % [hiddenDim x 1]
            h = squeeze(encoderHiddens(i, j, :)); % [hiddenDim x 1]
            
            % e_ij = v^T * tanh(Wa*s + Ua*h)
            energies(i, j) = v' * tanh(Wa * s + Ua * h);
        end
    end
    
    % Softmax normalisation
    alignments = softmax(energies, 2); % [batchSize x seqLen]
    
    % Compute context as weighted sum
    context = zeros(batchSize, hiddenDim);
    for i = 1:batchSize
        for j = 1:seqLen
            context(i, :) = context(i, :) + alignments(i, j) * encoderHiddens(i, j, :);
        end
    end
end
