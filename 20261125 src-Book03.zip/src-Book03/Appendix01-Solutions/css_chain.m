%% css_chain.m
% Reliability propagation along a system chain.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : css_chain
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [endToEnd, cumulative] = propagateChainReliability(stageReliability)
% propagateChainReliability  End-to-end reliability of an independent chain.
%   [endToEnd, cumulative] = propagateChainReliability(stageReliability)
%   Author: Dr Leo Chen | Version 1.0 | Base MATLAB (R2021b+)

    cumulative = cumprod(stageReliability(:));
    endToEnd   = cumulative(end);

    fprintf('End-to-end reliability = %.4f\n', endToEnd);
end
