%% chapter_AICE_code_P02.m
% Solution~2: upgrading a digital shadow to a digital twin (MATLABBook02_Chapter13_section8_Problem02.m).
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AICE_code_P02
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% MATLABBook02_Chapter13_section8_Problem02.m
% Problem 2: Upgrading a Digital Shadow to a Digital Twin
%
% Description : Applies proportional feedback to the model
%               prediction from Problem 1, demonstrating the
%               shadow-to-twin transition in Kritzinger's taxonomy.
% Author      : Dr Yi Chen
% Date        : 2025
% MATLAB      : R2024b or later
% Toolboxes   : None (base MATLAB)
% Reference   : Chapter 13, Problem 2
% =================================================================

%% 1. Regenerate aligned data from Problem 1
rng(7);
nSensorSamples   = 400;
sensorTimes      = datetime(2026,7,1) + ...
    hours(sort(168 * rand(nSensorSamples, 1)));
dailyCycle       = @(t) 12*sin(2*pi*(hour(t) + ...
    minute(t)/60 - 9)/24);
sensorDisplacement = dailyCycle(sensorTimes) ...
    + 0.8*randn(nSensorSamples, 1) ...
    + 4*max(0, days(sensorTimes - datetime(2026,7,6)));
modelTimes       = (datetime(2026,7,1):minutes(30): ...
    datetime(2026,7,8))';
modelDisplacement = dailyCycle(modelTimes);
sensorTable = timetable(sensorTimes, sensorDisplacement);
modelTable  = timetable(modelTimes, modelDisplacement);
alignedData = synchronize(sensorTable, modelTable, ...
    "regular", "linear", "TimeStep", minutes(30));

%% 2. Uncorrected residual
uncorrectedResidual = alignedData.sensorDisplacement ...
    - alignedData.modelDisplacement;
rmsUncorrected = sqrt(mean(uncorrectedResidual.^2, "omitnan"));

%% 3. Proportional feedback correction
correctionGain     = 0.3;
nSteps             = height(alignedData);
correctedPrediction = alignedData.modelDisplacement;
for stepIndex = 2:nSteps
    previousResidual = alignedData.sensorDisplacement(stepIndex-1) ...
        - correctedPrediction(stepIndex-1);
    correctedPrediction(stepIndex) = ...
        alignedData.modelDisplacement(stepIndex) ...
        + correctionGain * previousResidual;
end

%% 4. Corrected residual
correctedResidual = alignedData.sensorDisplacement ...
    - correctedPrediction;
rmsCorrected = sqrt(mean(correctedResidual.^2, "omitnan"));

%% 5. Report
fprintf('RMS residual (shadow, uncorrected) : %.3f mm\n', ...
    rmsUncorrected);
fprintf('RMS residual (twin, corrected)     : %.3f mm\n', ...
    rmsCorrected);
fprintf('Improvement                        : %.1f%%\n', ...
    100*(rmsUncorrected - rmsCorrected)/rmsUncorrected);

%% 6. Plot
figure;
plot(alignedData.Time, alignedData.sensorDisplacement, '.', ...
    'MarkerSize', 4, 'DisplayName', 'Sensor');
hold on;
plot(alignedData.Time, alignedData.modelDisplacement, '-', ...
    'LineWidth', 1, 'DisplayName', 'Shadow (uncorrected)');
plot(alignedData.Time, correctedPrediction, '--', ...
    'LineWidth', 1.2, 'DisplayName', ...
    sprintf('Twin (\\alpha = %.1f)', correctionGain));
xlabel('Time');
ylabel('Displacement (mm)');
legend('Location', 'northwest');
title('Shadow vs.\ Twin: Proportional Feedback Correction');
grid on;
% - Computational Complexity -
% The feedback loop is O(q) for q = 337 aligned steps.
% Combined with the O(m log m) synchronisation inherited from
% Problem 1, the total cost remains dominated by sorting.
% The correction is therefore deployable at every polling
% interval of a real-time monitoring system without contention.
