%% chapter_AIEFA_code_Problem1.m
% AR time series modelling and forecasting (MATLABBook02_AIEFA_Problem1_ARTimeSeries.m).
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AIEFA_code_Problem1
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%=========================================================================
% FILE   : MATLABBook02_AIEFA_Problem1_ARTimeSeries.m
% DESCR. : AR(p) model identification, estimation, and forecasting
% AUTHOR : Dr Yi Chen
% MATLAB : R2023b (compatible with R2019b and later)
% CREATED: July 2025   VERSION: 1.0
%=========================================================================
clear; clc; close all;
rng(42);  % reproducibility

%% -- 1. Data Generation (True AR(2)) --
sampleSize   = 200;
trueConst    = 0.3;
truePhi1     = 0.6;
truePhi2     = -0.2;
trueSigma    = 0.5;
innovations  = trueSigma * randn(sampleSize, 1);
gdpGrowth    = zeros(sampleSize, 1);
gdpGrowth(1) = trueConst + innovations(1);
gdpGrowth(2) = trueConst + truePhi1*gdpGrowth(1) + innovations(2);
for timeIdx = 3:sampleSize
    gdpGrowth(timeIdx) = trueConst ...
        + truePhi1 * gdpGrowth(timeIdx - 1) ...
        + truePhi2 * gdpGrowth(timeIdx - 2) ...
        + innovations(timeIdx);
end

%% -- 2. Sample ACF --
maxLag       = 20;
gdpDemeaned  = gdpGrowth - mean(gdpGrowth);
gamma0       = sum(gdpDemeaned.^2) / sampleSize;
acfValues    = zeros(maxLag, 1);
for lagIdx = 1:maxLag
    acfValues(lagIdx) = sum( ...
        gdpDemeaned(1:sampleSize - lagIdx) .* ...
        gdpDemeaned(lagIdx + 1:sampleSize)) ...
        / (sampleSize * gamma0);
end

%% -- 3. Sample PACF (Durbin-Levinson) --
pacfValues = zeros(maxLag, 1);
phiCoeffs  = zeros(maxLag, maxLag);
phiCoeffs(1, 1) = acfValues(1);
pacfValues(1)   = acfValues(1);
for orderK = 2:maxLag
    numerator = acfValues(orderK);
    denominator = 1.0;
    for jIdx = 1:(orderK - 1)
        numerator   = numerator   - phiCoeffs(orderK-1, jIdx) ...
                      * acfValues(orderK - jIdx);
        denominator = denominator - phiCoeffs(orderK-1, jIdx) ...
                      * acfValues(jIdx);
    end
    phiCoeffs(orderK, orderK) = numerator / denominator;
    pacfValues(orderK) = phiCoeffs(orderK, orderK);
    for jIdx = 1:(orderK - 1)
        phiCoeffs(orderK, jIdx) = phiCoeffs(orderK-1, jIdx) ...
            - phiCoeffs(orderK, orderK) ...
            * phiCoeffs(orderK-1, orderK - jIdx);
    end
end

%% -- 4. Model Selection (AIC / BIC) --
maxOrder       = 6;
aicPerObs      = zeros(maxOrder, 1);
bicPerObs      = zeros(maxOrder, 1);
residVarStore  = zeros(maxOrder, 1);
coeffStore     = cell(maxOrder, 1);
for modelOrder = 1:maxOrder
    responseVec = gdpGrowth(modelOrder + 1 : end);
    designMat   = ones(sampleSize - modelOrder, 1);
    for lagJ = 1:modelOrder
        designMat = [designMat, ...
            gdpGrowth(modelOrder + 1 - lagJ : end - lagJ)];
    end
    betaHat     = designMat \ responseVec;
    residuals   = responseVec - designMat * betaHat;
    nEff        = length(responseVec);
    numParams   = modelOrder + 1;
    sigSqHat    = sum(residuals.^2) / nEff;
    residVarStore(modelOrder) = sigSqHat;
    coeffStore{modelOrder}    = betaHat;
    aicPerObs(modelOrder) = log(sigSqHat) + 2*numParams/nEff;
    bicPerObs(modelOrder) = log(sigSqHat) + numParams*log(nEff)/nEff;
end
[~, optOrderAIC] = min(aicPerObs);
[~, optOrderBIC] = min(bicPerObs);
fprintf('Optimal order: AIC selects AR(%d), BIC selects AR(%d)\n', ...
    optOrderAIC, optOrderBIC);

%% -- 5. Display Selected Model Coefficients --
selectedOrder = optOrderBIC;
betaSelected  = coeffStore{selectedOrder};
fprintf('\n- AR(%d) Coefficient Estimates -\n', selectedOrder);
fprintf('Intercept  c    = %.4f  (true = %.4f)\n', ...
    betaSelected(1), trueConst);
for coeffIdx = 1:selectedOrder
    fprintf('Coefficient phi_%d = %.4f  (true = %.4f)\n', ...
        coeffIdx, betaSelected(coeffIdx+1), ...
        [truePhi1, truePhi2, zeros(1,4)]* ...
        (coeffIdx <= 2) + 0*(coeffIdx > 2));
end

%% -- 6. Forecasting --
horizonSteps  = 8;
forecastVals  = zeros(horizonSteps, 1);
historyData   = gdpGrowth;
responseVec   = gdpGrowth(selectedOrder + 1 : end);
designMat     = ones(sampleSize - selectedOrder, 1);
for lagJ = 1:selectedOrder
    designMat = [designMat, ...
        gdpGrowth(selectedOrder + 1 - lagJ : end - lagJ)];
end
residSelected = responseVec - designMat * betaSelected;
sigmaHat      = sqrt(sum(residSelected.^2) / ...
                (length(responseVec) - selectedOrder - 1));

% Recursive point forecasts
for step = 1:horizonSteps
    xNewRow = 1;
    for lagJ = 1:selectedOrder
        xNewRow = [xNewRow, historyData(end + 1 - lagJ)];
    end
    forecastVals(step) = xNewRow * betaSelected;
    historyData = [historyData; forecastVals(step)];
end

% Psi-weights for forecast error variance
psiWeights    = zeros(horizonSteps, 1);
psiWeights(1) = 1;
if horizonSteps >= 2 && selectedOrder >= 1
    psiWeights(2) = betaSelected(2);
end
for hIdx = 3:horizonSteps
    for jIdx = 1:min(selectedOrder, hIdx - 1)
        psiWeights(hIdx) = psiWeights(hIdx) ...
            + betaSelected(jIdx + 1) * psiWeights(hIdx - jIdx);
    end
end
forecastSE = zeros(horizonSteps, 1);
for hIdx = 1:horizonSteps
    forecastSE(hIdx) = sigmaHat * sqrt(sum(psiWeights(1:hIdx).^2));
end
ciLower = forecastVals - 1.96 * forecastSE;
ciUpper = forecastVals + 1.96 * forecastSE;

%% -- 7. Residual Diagnostics (Ljung-Box-type) --
residACF    = zeros(maxLag, 1);
resDemeaned = residSelected - mean(residSelected);
resGamma0   = sum(resDemeaned.^2) / length(residSelected);
nRes        = length(residSelected);
for lagIdx = 1:maxLag
    residACF(lagIdx) = sum(resDemeaned(1:nRes-lagIdx) .* ...
        resDemeaned(lagIdx+1:nRes)) / (nRes * resGamma0);
end
ljungBoxQ = nRes * (nRes + 2) * ...
    sum(residACF(1:10).^2 ./ (nRes - (1:10)'));
dfLB      = 10 - selectedOrder;
% p-value from chi-squared via regularised incomplete gamma
pValueLB  = 1 - gammainc(ljungBoxQ / 2, dfLB / 2);
fprintf('\nLjung-Box Q(%d) = %.3f, p-value = %.4f\n', ...
    10, ljungBoxQ, pValueLB);

%% -- 8. Plotting --
figure('Position', [50, 50, 1000, 700]);
confBand = 1.96 / sqrt(sampleSize);

subplot(2, 2, 1);
plot(1:sampleSize, gdpGrowth, 'b-', 'LineWidth', 0.8);
xlabel('$t$ (Quarter)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('GDP Growth (\%)', 'Interpreter', 'latex', 'FontSize', 11);
title('Synthetic GDP Growth Series', 'Interpreter', 'latex');
grid on;

subplot(2, 2, 2);
stem(1:maxLag, acfValues, 'filled', 'MarkerSize', 4);
hold on;
yline(confBand, 'r--'); yline(-confBand, 'r--');
xlabel('Lag $k$', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('$\hat{\rho}(k)$', 'Interpreter', 'latex', 'FontSize', 11);
title('Sample ACF', 'Interpreter', 'latex'); grid on;

subplot(2, 2, 3);
stem(1:maxLag, pacfValues, 'filled', 'MarkerSize', 4);
hold on;
yline(confBand, 'r--'); yline(-confBand, 'r--');
xlabel('Lag $k$', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('$\hat{\phi}_{kk}$', 'Interpreter', 'latex', 'FontSize', 11);
title('Sample PACF', 'Interpreter', 'latex'); grid on;

subplot(2, 2, 4);
tHistory = (sampleSize - 19):sampleSize;
tForecast = sampleSize + (1:horizonSteps);
plot(tHistory, gdpGrowth(tHistory), 'b-', 'LineWidth', 1.2);
hold on;
plot(tForecast, forecastVals, 'r-o', 'LineWidth', 1.2, ...
    'MarkerSize', 4);
fill([tForecast, fliplr(tForecast)], ...
     [ciLower', fliplr(ciUpper')], ...
     'r', 'FaceAlpha', 0.15, 'EdgeColor', 'none');
xlabel('$t$', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('GDP Growth (\%)', 'Interpreter', 'latex', 'FontSize', 11);
title('8-Step Forecast with 95\% CI', 'Interpreter', 'latex');
legend('Historical', 'Forecast', '95\% CI', ...
    'Interpreter', 'latex', 'Location', 'best');
grid on;
% Computational Complexity:
% Design matrix construction: O(T*p). OLS via QR decomposition
% (backslash): O(T*p^2). ACF: O(T*L) for L lags. PACF via
% Durbin-Levinson: O(L^2). Model selection over p_max orders:
% O(T*p_max^2). Forecasting: O(h*p) for h steps. For T=200,
% p_max=6, L=20, total cost is negligible on modern hardware.
