%% p14.m
% MATLABBook03_ChapterAIBHS_Problem14.m
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : p14
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function MATLABBook03_ChapterAIBHS_Problem14
% Purpose: incremental (lifelong) DNA-protein binding classifier.
% Author: Dr Leo Chen. R2024b + Statistics ML. v1.0 2025-06-01.
    rng(0); nFeat=8; model=incrementalClassificationLinear('Learner','logistic');
    accHistory=zeros(5,1);
    for batch=1:5
        Xb=randn(100,nFeat); yb=double(sum(Xb(:,1:3),2)+0.3*randn(100,1)>0);
        model=fit(model,Xb,yb); accHistory(batch)=mean(predict(model,Xb)==yb);
    end
    fprintf('Final batch accuracy: %.3f\n', accHistory(end));
end
