%% chapter_Introduction_problem1_code.m
% Matrix operations across disciplines.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_Introduction_problem1_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% MATLABBook03_Chapter01_Problem01.m
% Matrix Operations Across Multiple Disciplines
% This script demonstrates how MATLAB's matrix operations apply across
% different fields

%% Engineering: Stress-Strain Data (3 materials, 4 measurements)
% Rows: different materials, Columns: strain measurements
engineering_data = [
    0.2, 0.4, 0.6, 0.8;  % Material 1
    0.15, 0.35, 0.55, 0.75;  % Material 2
    0.3, 0.5, 0.7, 0.9   % Material 3
];

% Young's modulus for each material (GPa)
youngs_modulus = [210; 180; 150];

% Calculate stress values (stress = Young's modulus * strain)
stress_data = youngs_modulus .* engineering_data;

disp("Stress values (MPa) for each material at different strain levels:");
disp(stress_data);

%% Finance: Stock Price Data (3 companies, 5 days)
% Rows: different companies, Columns: daily prices
finance_data = [
    105.2, 106.7, 104.8, 107.3, 108.1;  % Company 1
    75.6, 77.2, 76.8, 74.9, 76.3;  % Company 2
    215.4, 214.8, 216.9, 218.2, 217.5   % Company 3
];

% Calculate daily returns (percentage change)
daily_returns = 100 * diff(finance_data, 1, 2) ./ finance_data(:, 1:end-1);

disp("Daily returns (%) for each company:");
disp(daily_returns);

% Calculate correlation matrix of returns
returns_correlation = corrcoef(daily_returns');
disp("Correlation matrix of stock returns:");
disp(returns_correlation);

%% Healthcare: Patient Vital Signs (4 patients, 3 measurements)
% Rows: different patients, Columns: heart rate, blood pressure, temperature
healthcare_data = [
    72, 120, 37.0;  % Patient 1
    65, 115, 36.8;  % Patient 2
    88, 135, 38.2;  % Patient 3
    78, 125, 37.3   % Patient 4
];

% Calculate z-scores to standardize measurements
means = mean(healthcare_data);
stds = std(healthcare_data);
zscore_data = (healthcare_data - means) ./ stds;

disp("Standardized vital signs (z-scores):");
disp(zscore_data);

%% Matrix Operation 1: Transpose (changing perspective)
% Engineering: View by measurement instead of by material
eng_by_measurement = engineering_data';
disp("Engineering data reorganized by measurement point:");
disp(eng_by_measurement);

%% Matrix Operation 2: Matrix multiplication (transformation)
% Finance: Apply a weighting matrix to calculate weighted index
portfolio_weights = [0.5; 0.3; 0.2];  % Weights for each company
portfolio_value = finance_data * portfolio_weights;

disp("Weighted portfolio value over time:");
disp(portfolio_value');

%% Matrix Operation 3: Eigenvalue analysis (finding principal components)
% Healthcare: Find principal components of patient data
[vectors, values] = eig(cov(healthcare_data));
disp("Principal components of healthcare data:");
disp(vectors);
disp("Variance explained by each component:");
disp(diag(values)');

%% Matrix Operation 4: Element-wise operations (data transformation)
% Engineering: Calculate elastic energy (0.5 * stress * strain)
elastic_energy = 0.5 * stress_data .* engineering_data;
disp("Elastic energy stored in each material:");
disp(elastic_energy);

%% Matrix Operation 5: Matrix concatenation (data integration)
% Combine normalized data from all three domains for integrated analysis
% First, normalize each dataset
norm_eng = engineering_data ./ max(engineering_data(:));
norm_fin = finance_data ./ max(finance_data(:));
norm_health = healthcare_data ./ max(healthcare_data(:));

% Reshape for consistent dimensions (example approach)
reshaped_eng = reshape(norm_eng, [], 1);
reshaped_fin = reshape(norm_fin, [], 1);
reshaped_health = reshape(norm_health, [], 1);

% Combine the first few elements from each dataset
integrated_data = [reshaped_eng(1:5), reshaped_fin(1:5), reshaped_health(1:5)];
disp("Integrated normalized data from three disciplines:");
disp(integrated_data);
