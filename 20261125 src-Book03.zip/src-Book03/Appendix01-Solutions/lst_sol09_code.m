%% lst_sol09_code.m
% Ethical Analysis Visualisation (MATLABBook02_Chapter10_Problem09.m).
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : lst:sol09_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% MATLABBook02_Chapter10_Problem09.m
%  Ethical Implications of AI-Generated Music
%  -------------------
%  Author       : Dr Leo Chen
%  Date         : 2024-01-20
%  Modified     : 2024-07-01
%  Version      : 1.2
%  MATLAB Ver.  : R2024a
%  Toolboxes    : (none required)
%  Description  :
%    Generates a stakeholder impact heat-map and
%    comparison table for the ethical analysis of
%    AI-generated music.
%  Change Log   :
%    v1.0 - Initial release.
%    v1.1 - Added mitigation strategies column.
%    v1.2 - Improved LaTeX annotations on heat-map.
%  -------------------

%% Initialisation
clc; clear; close all;

%% --- Define Ethical Framework ---------
dimensions   = {'Copyright'; 'Authorship'; ...
                'Economic Impact'};
stakeholders = {'Original Artist', 'Consumer', ...
                'AI Developer', 'Legislator'};

% Impact matrix: rows = dimensions, cols = stakeholders
% Scale: 1 = Low, 2 = Medium, 3 = High
impactMatrix = [3, 1, 2, 3;    % Copyright
                3, 1, 2, 3;    % Authorship
                3, 2, 2, 2];   % Economic Impact

%% --- Mitigation Strategies Table --------
mitigationStrategies = { ...
    ['Require explicit licensing of training data; ', ...
     'implement content fingerprinting.']; ...
    ['Mandate AI-generated labels; adopt shared ', ...
     'attribution models.']; ...
    ['Establish royalty pools; invest in promotion ', ...
     'of human artists.']};

comparisonTable = table(dimensions, ...
    mitigationStrategies, ...
    'VariableNames', {'Dimension', 'Mitigation'});

fprintf('===== Ethical Analysis Summary =====\n\n');
disp(comparisonTable);

%% --- Stakeholder Impact Heat-Map ---------
figure('Color', 'w', 'Position', [100 100 700 400]);
imagesc(impactMatrix);
colormap([0.6 0.9 0.6;     % 1 = Low (green)
          1.0 0.9 0.4;     % 2 = Medium (amber)
          1.0 0.4 0.4]);   % 3 = High (red)
colorbar('Ticks', [1, 2, 3], ...
         'TickLabels', {'Low', 'Medium', 'High'});

set(gca, 'XTick', 1:numel(stakeholders), ...
         'XTickLabel', stakeholders, ...
         'XTickLabelRotation', 30, ...
         'YTick', 1:numel(dimensions), ...
         'YTickLabel', dimensions);
xlabel('Stakeholder', 'Interpreter', 'latex');
ylabel('Ethical Dimension', 'Interpreter', 'latex');
title(['Stakeholder Impact Matrix - ', ...
       'AI-Generated Music'], ...
      'Interpreter', 'latex', 'FontSize', 14);

% Annotate cells with rating text
ratingLabels = {'Low', 'Medium', 'High'};
for rowIdx = 1:size(impactMatrix, 1)
    for colIdx = 1:size(impactMatrix, 2)
        text(colIdx, rowIdx, ...
            ratingLabels{impactMatrix(rowIdx, colIdx)},...
            'HorizontalAlignment', 'center', ...
            'FontWeight', 'bold', 'FontSize', 11);
    end
end

exportgraphics(gcf, ...
    'MATLABBook02_Chapter10_Problem09_output.pdf', ...
    'ContentType', 'vector');
fprintf('Heat-map exported.\n');
