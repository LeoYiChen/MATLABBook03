%% ga_feature_selection.m
% Genetic Algorithm Feature Selection
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : ga_feature_selection
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Genetic Algorithm for Feature Selection
% Author: Dr Leo Chen
% Version: R2023b
% Date: November 2024

function genetic_feature_selection()
% Generate synthetic dataset with mixed feature relevance
rng(202); % Ensure reproducibility
num_samples = 500;
num_relevant_features = 10;
num_irrelevant_features = 40;
total_features = num_relevant_features + num_irrelevant_features;

% Create relevant features with class separation
class_labels = [ones(num_samples/2, 1); -ones(num_samples/2, 1)];

relevant_features = zeros(num_samples, num_relevant_features);
for feature_idx = 1:num_relevant_features
    % Create features with class-dependent distributions
    class1_mean = 2 * randn();
    class2_mean = class1_mean + 3 * randn();
    
    relevant_features(class_labels == 1, feature_idx) = ...
        class1_mean + randn(sum(class_labels == 1), 1);
    relevant_features(class_labels == -1, feature_idx) = ...
        class2_mean + randn(sum(class_labels == -1), 1);
end

% Create irrelevant features (pure noise)
irrelevant_features = randn(num_samples, num_irrelevant_features);

% Combine all features
feature_matrix = [relevant_features, irrelevant_features];

% Standardise features
standardised_features = zscore(feature_matrix);

% Define genetic algorithm parameters
population_size = 50;
max_generations = 100;
crossover_fraction = 0.8;
mutation_rate = 0.1;

% Configure genetic algorithm options
ga_options = optimoptions('ga', ...
    'PopulationSize', population_size, ...
    'MaxGenerations', max_generations, ...
    'CrossoverFraction', crossover_fraction, ...
    'MutationFcn', {@mutationuniform, mutation_rate}, ...
    'SelectionFcn', @selectiontournament, ...
    'EliteCount', 2, ...
    'PlotFcn', {@gaplotbestf, @gaplotselection}, ...
    'Display', 'iter', ...
    'UseParallel', false);

% Define fitness function
fitness_function = @(chromosome) evaluate_feature_subset(...
    chromosome, standardised_features, class_labels);

% Run genetic algorithm
fprintf('Running Genetic Algorithm for Feature Selection...\\n');
[optimal_chromosome, best_fitness, exit_flag, ga_output] = ...
    ga(fitness_function, total_features, [], [], [], [], ...
    zeros(1, total_features), ones(1, total_features), [], ...
    1:total_features, ga_options);

% Convert continuous chromosome to binary feature selection
selected_features = optimal_chromosome > 0.5;
num_selected_features = sum(selected_features);

% Evaluate final performance with selected features
selected_feature_matrix = standardised_features(:, selected_features);

% Train final classifier with selected features
final_classifier = fitcsvm(selected_feature_matrix, class_labels, ...
    'KernelFunction', 'linear', 'Standardize', false);

% Perform cross-validation
cv_model = crossval(final_classifier, 'KFold', 5);
cv_accuracy = (1 - kfoldLoss(cv_model)) * 100;

% Compare with all features
full_classifier = fitcsvm(standardised_features, class_labels, ...
    'KernelFunction', 'linear', 'Standardize', false);
full_cv_model = crossval(full_classifier, 'KFold', 5);
full_cv_accuracy = (1 - kfoldLoss(full_cv_model)) * 100;

% Analyse feature selection results
selected_relevant = sum(selected_features(1:num_relevant_features));
selected_irrelevant = sum(selected_features(num_relevant_features+1:end));

precision_relevant = selected_relevant / num_relevant_features;
precision_irrelevant = 1 - (selected_irrelevant / num_irrelevant_features);

% Visualisation
figure('Name', 'Genetic Algorithm Feature Selection Results');

% Feature selection visualisation
subplot(2, 3, 1);
feature_indices = 1:total_features;
bar(feature_indices, selected_features, 'FaceColor', 'blue');
hold on;
plot([num_relevant_features + 0.5, num_relevant_features + 0.5], ...
    [0, 1], 'r--', 'LineWidth', 2);
xlabel('Feature Index', 'Interpreter', 'latex');
ylabel('Selected (1) / Not Selected (0)', 'Interpreter', 'latex');
title('Selected Features', 'Interpreter', 'latex');
legend('Selected Features', 'Relevant/Irrelevant Boundary', 'Location', 'best');

% Performance comparison
subplot(2, 3, 2);
performance_data = [full_cv_accuracy, cv_accuracy];
feature_counts = [total_features, num_selected_features];

yyaxis left;
bar([1, 2], performance_data, 'FaceColor', 'green');
ylabel('Cross-Validation Accuracy (\%)', 'Interpreter', 'latex');

yyaxis right;
plot([1, 2], feature_counts, 'ro-', 'LineWidth', 3, 'MarkerSize', 8);
ylabel('Number of Features', 'Interpreter', 'latex');

set(gca, 'XTickLabel', {'All Features', 'Selected Features'});
title('Performance vs Feature Count', 'Interpreter', 'latex');

% GA convergence plot
subplot(2, 3, 3);
plot(ga_output.bestfeval, 'b-', 'LineWidth', 2);
xlabel('Generation', 'Interpreter', 'latex');
ylabel('Best Fitness', 'Interpreter', 'latex');
title('GA Convergence', 'Interpreter', 'latex');
grid on;

% Feature importance heatmap
subplot(2, 3, 4);
feature_importance = abs(final_classifier.Beta);
[sorted_importance, sort_indices] = sort(feature_importance, 'descend');

bar(sorted_importance(1:min(20, length(sorted_importance))));
xlabel('Feature Rank', 'Interpreter', 'latex');
ylabel('Feature Importance', 'Interpreter', 'latex');
title('Selected Feature Importance', 'Interpreter', 'latex');

% Confusion matrix for selected features
subplot(2, 3, 5);
predicted_labels = predict(final_classifier, selected_feature_matrix);
confusion_matrix = confusionmat(class_labels, predicted_labels);

confusionchart(class_labels, predicted_labels);
title('Classification with Selected Features', 'Interpreter', 'latex');

% Selection efficiency analysis
subplot(2, 3, 6);
categories = {'Relevant Selected', 'Relevant Missed', ...
    'Irrelevant Selected', 'Irrelevant Rejected'};
values = [selected_relevant, num_relevant_features - selected_relevant, ...
    selected_irrelevant, num_irrelevant_features - selected_irrelevant];

pie(values, categories);
title('Feature Selection Efficiency', 'Interpreter', 'latex');

% Display comprehensive results
fprintf('\\n\\textbf{Genetic Algorithm Feature Selection Results}:\\n');
fprintf('Total Features: %d\\n', total_features);
fprintf('Selected Features: %d (%.1f%%)\\n', num_selected_features, ...
    (num_selected_features / total_features) * 100);
fprintf('Relevant Features Selected: %d/%d (%.1f%%)\\n', ...
    selected_relevant, num_relevant_features, precision_relevant * 100);
fprintf('Irrelevant Features Rejected: %d/%d (%.1f%%)\\n', ...
    num_irrelevant_features - selected_irrelevant, num_irrelevant_features, ...
    precision_irrelevant * 100);

fprintf('\\n\\textbf{Classification Performance}:\\n');
fprintf('All Features CV Accuracy: %.2f%%\\n', full_cv_accuracy);
fprintf('Selected Features CV Accuracy: %.2f%%\\n', cv_accuracy);
fprintf('Performance Change: %.2f%%\\n', cv_accuracy - full_cv_accuracy);

fprintf('\\n\\textbf{Computational Efficiency}:\\n');
fprintf('Feature Reduction Ratio: %.1f%%\\n', ...
    (1 - num_selected_features / total_features) * 100);
fprintf('GA Generations: %d\\n', ga_output.generations);
fprintf('Best Fitness: %.4f\\n', -best_fitness); % Convert back from minimization

end

function fitness_value = evaluate_feature_subset(chromosome, features, labels)
% Evaluate fitness of feature subset using classification accuracy

% Convert continuous chromosome to binary selection
selected_features = chromosome > 0.5;
num_selected = sum(selected_features);

% Penalise solutions with no features or all features
if num_selected == 0 || num_selected == length(chromosome)
    fitness_value = 1000; % High penalty (minimization problem)
    return;
end

% Extract selected features
selected_feature_matrix = features(:, selected_features);

try
    % Train classifier with selected features
    classifier = fitcsvm(selected_feature_matrix, labels, ...
        'KernelFunction', 'linear', 'Standardize', false);
    
    % Evaluate using cross-validation
    cv_model = crossval(classifier, 'KFold', 3);
    cv_error = kfoldLoss(cv_model);
    
    % Multi-objective fitness: accuracy + feature count penalty
    accuracy_component = cv_error;
    complexity_component = 0.01 * (num_selected / length(chromosome));
    
    fitness_value = accuracy_component + complexity_component;
    
catch
    % Handle degenerate cases
    fitness_value = 1000;
end

end
