%% chapter_AIEFA_code_Problem3.m
% Monte Carlo European option pricing with antithetic variates (MATLABBook02_AIEFA_Problem3_MonteCarloOption.m).
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AIEFA_code_Problem3
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%=========================================================================
% FILE   : MATLABBook02_AIEFA_Problem3_MonteCarloOption.m
% DESCR. : European call option pricing via Monte Carlo
% AUTHOR : Dr Yi Chen
% MATLAB : R2023b (compatible with R2019b and later)
% CREATED: July 2025   VERSION: 1.0
%=========================================================================
clear; clc; close all;
rng(42);

%% -- 1. Option Parameters --
spotPrice   = 100;    % S_0
strikePrice = 100;    % K
riskFree    = 0.05;   % r
volatility  = 0.20;   % sigma
maturity    = 1.0;    % T (years)

%% -- 2. Closed-Form Black-Scholes Price --
% Normal CDF via error function (base MATLAB)
normalCDF = @(x) 0.5 * (1 + erf(x / sqrt(2)));

d1Value = (log(spotPrice / strikePrice) + ...
          (riskFree + volatility^2 / 2) * maturity) / ...
          (volatility * sqrt(maturity));
d2Value = d1Value - volatility * sqrt(maturity);
bsPrice = spotPrice * normalCDF(d1Value) - ...
          strikePrice * exp(-riskFree * maturity) * ...
          normalCDF(d2Value);
fprintf('Black-Scholes analytical price: %.4f\n', bsPrice);

%% -- 3. Monte Carlo Simulation --
pathCounts = [1e3, 1e4, 1e5, 1e6];
numTrials  = length(pathCounts);
resultsMC  = zeros(numTrials, 6);
% Columns: M, MC_price, MC_SE, Anti_price, Anti_SE, Time

discountFactor = exp(-riskFree * maturity);
drift          = (riskFree - volatility^2 / 2) * maturity;
diffusion      = volatility * sqrt(maturity);

for trialIdx = 1:numTrials
    numPaths = pathCounts(trialIdx);
    tic;

    % Standard Monte Carlo
    zDraws    = randn(numPaths, 1);
    terminalS = spotPrice * exp(drift + diffusion * zDraws);
    payoffs   = max(terminalS - strikePrice, 0);
    mcPrice   = discountFactor * mean(payoffs);
    mcSE      = discountFactor * std(payoffs) / sqrt(numPaths);

    % Antithetic Variates
    terminalS_pos = spotPrice * exp(drift + diffusion * zDraws);
    terminalS_neg = spotPrice * exp(drift - diffusion * zDraws);
    payoff_pos    = max(terminalS_pos - strikePrice, 0);
    payoff_neg    = max(terminalS_neg - strikePrice, 0);
    pairedPayoffs = 0.5 * (payoff_pos + payoff_neg);
    antiPrice     = discountFactor * mean(pairedPayoffs);
    antiSE        = discountFactor * std(pairedPayoffs) / ...
                    sqrt(numPaths);

    elapsed = toc;
    resultsMC(trialIdx, :) = [numPaths, mcPrice, mcSE, ...
                               antiPrice, antiSE, elapsed];

    fprintf(['M = %7d | MC: %.4f (SE %.4f) | ' ...
             'Anti: %.4f (SE %.4f) | Time: %.4fs\n'], ...
        numPaths, mcPrice, mcSE, antiPrice, antiSE, elapsed);
end

%% -- 4. Variance Reduction Ratio --
vrRatio = (resultsMC(:, 3).^2) ./ (resultsMC(:, 5).^2);
fprintf('\nVariance reduction ratios:\n');
for trialIdx = 1:numTrials
    fprintf('  M = %7d : VR = %.2fx\n', ...
        pathCounts(trialIdx), vrRatio(trialIdx));
end

%% -- 5. Convergence Plot --
figure('Position', [80, 80, 900, 500]);
subplot(1, 2, 1);
semilogx(pathCounts, resultsMC(:, 2), 'bo-', ...
    'LineWidth', 1.2, 'MarkerSize', 7);
hold on;
semilogx(pathCounts, resultsMC(:, 4), 'r^-', ...
    'LineWidth', 1.2, 'MarkerSize', 7);
yline(bsPrice, 'k--', 'LineWidth', 1.0);
xlabel('Number of Paths $M$', 'Interpreter', 'latex');
ylabel('Option Price Estimate', 'Interpreter', 'latex');
title('Price Convergence', 'Interpreter', 'latex');
legend('Standard MC', 'Antithetic', 'BS Exact', ...
    'Interpreter', 'latex', 'Location', 'best');
grid on;

subplot(1, 2, 2);
loglog(pathCounts, resultsMC(:, 3), 'bo-', ...
    'LineWidth', 1.2, 'MarkerSize', 7);
hold on;
loglog(pathCounts, resultsMC(:, 5), 'r^-', ...
    'LineWidth', 1.2, 'MarkerSize', 7);
xlabel('Number of Paths $M$', 'Interpreter', 'latex');
ylabel('Standard Error', 'Interpreter', 'latex');
title('Standard Error Convergence', 'Interpreter', 'latex');
legend('Standard MC', 'Antithetic', ...
    'Interpreter', 'latex', 'Location', 'best');
grid on;
% Computational Complexity:
% Generating M paths: O(M). Payoff evaluation: O(M).
% Total per configuration: O(M). SE decreases as O(M^{-1/2}),
% so halving the error requires quadrupling the paths.
% Antithetic variates incur no additional order of complexity;
% the constant factor is approximately doubled per path but
% variance is reduced by a factor exceeding 2. For M = 10^6,
% vectorised MATLAB execution requires under one second.
