%% chapter_AILMI_prob7_decoder.m
% Conditional decoder with style control.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AILMI_prob7_decoder
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function output = conditionalDecoder(contentVec, targetStyleVec, lstmDec, maxLen)
    % Generate text conditioned on content and target style
    % contentVec: [contentDim x 1]
    % targetStyleVec: [styleDim x 1]
    
    % Initialise decoder state with content
    decoderState = contentVec;
    output = [];
    
    % Start token
    currentToken = SOS_TOKEN;
    
    for t = 1:maxLen
        % Concatenate token embedding with style vector
        tokenEmbed = getEmbedding(currentToken);
        inputVec = [tokenEmbed; targetStyleVec];
        
        % LSTM step
        [decoderState, outputVec] = lstmStep(inputVec, decoderState, lstmDec);
        
        % Attention over content (simplified)
        contextVec = contentVec; % In full model: attention mechanism
        
        % Combine decoder output with context and style
        combined = [outputVec; contextVec; targetStyleVec];
        
        % Predict next token
        logits = Wout * combined + bout;
        probs = softmax(logits);
        
        % Sample (or use beam search in practice)
        [~, nextToken] = max(probs);
        output = [output, nextToken];
        
        if nextToken == EOS_TOKEN
            break;
        end
        
        currentToken = nextToken;
    end
end
