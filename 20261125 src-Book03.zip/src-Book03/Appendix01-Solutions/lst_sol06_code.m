%% lst_sol06_code.m
% Content-Based Music Recommendation (MATLABBook02_Chapter10_Problem06.m).
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : lst:sol06_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% MATLABBook02_Chapter10_Problem06.m
%  Content-Based Music Recommendation System
%  -------------------
%  Author       : Dr Leo Chen
%  Date         : 2024-01-20
%  Modified     : 2024-07-01
%  Version      : 1.2
%  MATLAB Ver.  : R2024a
%  Toolboxes    : Audio Toolbox, Statistics and Machine
%                 Learning Toolbox
%  Description  :
%    Recommends similar tracks based on audio feature
%    similarity (cosine distance). Evaluates using
%    precision@k and recall@k.
%  Change Log   :
%    v1.0 - Initial release.
%    v1.1 - Added t-SNE visualisation.
%    v1.2 - Improved normalisation and evaluation loop.
%  -------------------

%% Initialisation
clc; clear; close all;

%% --- User Parameters ------------
featureFilePath = 'music_features.mat';
topKValues      = [5, 10, 20];
queryTrackIndex = 1;

%% --- Load Pre-Extracted Features --------
loadedData     = load(featureFilePath);
featureMatrix  = loadedData.featureMatrix;  % N x D
trackNames     = loadedData.trackNames;     % N x 1 cell
genreLabels    = categorical( ...
    loadedData.genreLabels);                % N x 1
numTracks      = size(featureMatrix, 1);
fprintf('Library size: %d tracks\n', numTracks);

%% --- Normalise Features -----------
featureMean   = mean(featureMatrix, 1);
featureStdDev = std(featureMatrix, 0, 1);
featureStdDev(featureStdDev == 0) = 1;
normalisedFeatures = (featureMatrix - featureMean) ...
                     ./ featureStdDev;

%% --- Compute Pairwise Cosine Distance -------
distanceMatrix = pdist2(normalisedFeatures, ...
                        normalisedFeatures, 'cosine');

%% --- Generate Recommendations ---------
queryGenre = genreLabels(queryTrackIndex);
fprintf('Query track : %s\n', ...
        trackNames{queryTrackIndex});
fprintf('Query genre : %s\n', string(queryGenre));

[sortedDist, sortedIdx] = sort( ...
    distanceMatrix(queryTrackIndex, :), 'ascend');

% Skip self (index 1)
candidateIndices = sortedIdx(2:end);
candidateGenres  = genreLabels(candidateIndices);

%% --- Evaluate Precision@k and Recall@k ------
totalRelevant = sum(genreLabels == queryGenre) - 1;

fprintf('\n%6s  %12s  %10s\n', ...
        'k', 'Precision@k', 'Recall@k');
fprintf('%s\n', repmat('-', 1, 32));

for topK = topKValues
    topKIdx        = candidateIndices(1:topK);
    topKGenres     = genreLabels(topKIdx);
    relevantInTopK = sum(topKGenres == queryGenre);

    precisionAtK = relevantInTopK / topK;
    recallAtK    = relevantInTopK / totalRelevant;

    fprintf('%6d  %11.2f%%  %9.2f%%\n', ...
            topK, precisionAtK*100, recallAtK*100);
end

%% --- t-SNE Visualisation ------------
tsneCoords = tsne(normalisedFeatures, ...
    'Distance', 'cosine', 'Perplexity', 30);

figure('Color', 'w', 'Position', [100 100 700 550]);
gscatter(tsneCoords(:,1), tsneCoords(:,2), ...
         genreLabels, [], [], 25);
hold on;
plot(tsneCoords(queryTrackIndex, 1), ...
     tsneCoords(queryTrackIndex, 2), ...
     'kp', 'MarkerSize', 20, 'MarkerFaceColor', 'y');

topKDisplay = candidateIndices(1:topKValues(1));
plot(tsneCoords(topKDisplay, 1), ...
     tsneCoords(topKDisplay, 2), ...
     'ro', 'MarkerSize', 12, 'LineWidth', 2);
legend('Location', 'bestoutside');
xlabel('$t$-SNE Dimension 1', 'Interpreter', 'latex');
ylabel('$t$-SNE Dimension 2', 'Interpreter', 'latex');
title('Music Library Feature Space ($t$-SNE)', ...
      'Interpreter', 'latex', 'FontSize', 14);
grid on;
exportgraphics(gcf, ...
    'MATLABBook02_Chapter10_Problem06_output.pdf', ...
    'ContentType', 'vector');
