%% chapter_AIinMOR_problem_2.m
% Intelligent Supply Chain Network Design Solution.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AIinMOR_problem_2
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [networkDesignResults] = solveIntelligentSupplyChainNetworkDesign()
% Intelligent Supply Chain Network Design with Demand Uncertainty
% Author: Dr Leo Chen
% Version: 1.0
% Date: 2025
% Description: AI-enabled supply chain optimisation under uncertainty

fprintf('\\textbf{Intelligent Supply Chain Network Design}\n');
fprintf('==============================================\n\n');

% Generate comprehensive demand uncertainty model
demandUncertaintyModel = generateDemandUncertaintyModel();

% Train ensemble forecasting models
forecastingEnsemble = trainDemandForecastingEnsemble(demandUncertaintyModel);

% Generate demand scenarios for stochastic optimisation
demandScenarios = generateDemandScenarios(forecastingEnsemble, demandUncertaintyModel);

% Formulate and solve stochastic supply chain design problem
stochasticOptimisationResults = solveStochasticSupplyChainDesign(demandScenarios);

% Develop adaptive inventory policies
adaptiveInventoryPolicies = developAdaptiveInventoryPolicies(forecastingEnsemble, 
    stochasticOptimisationResults);

% Validate network design through simulation
networkValidation = validateNetworkDesignThroughSimulation(stochasticOptimisationResults, 
    adaptiveInventoryPolicies, demandUncertaintyModel);

% Consolidate results
networkDesignResults = consolidateNetworkDesignResults(demandUncertaintyModel, 
    forecastingEnsemble, demandScenarios, stochasticOptimisationResults, 
    adaptiveInventoryPolicies, networkValidation);

% Generate comprehensive analysis
generateSupplyChainNetworkVisualisations(networkDesignResults);

% Display strategic recommendations
displaySupplyChainNetworkRecommendations(networkDesignResults);

end

function demandModel = generateDemandUncertaintyModel()
% Generate comprehensive demand uncertainty model

demandModel = struct();

fprintf('\\textbf{Generating Demand Uncertainty Model:}\n');

% Market structure
demandModel.markets = {'North America', 'Europe', 'Asia-Pacific', 'Latin America', 'Middle East'};
demandModel.numMarkets = length(demandModel.markets);

% Product categories
demandModel.products = {'Consumer Electronics', 'Home Appliances', 'Industrial Equipment'};
demandModel.numProducts = length(demandModel.products);

% Time horizon (monthly data for 3 years)
demandModel.timeHorizon = 36;
demandModel.timeVector = (1:demandModel.timeHorizon)';

% Generate base demand levels (units per month)
rng(2025); % Set seed for reproducibility

demandModel.baseDemand = [
    [120000, 80000, 45000];   % North America
    [100000, 70000, 40000];   # Europe
    [150000, 95000, 60000];   % Asia-Pacific
    [60000, 40000, 25000];    % Latin America
    [40000, 25000, 15000]     % Middle East
];

% Generate demand time series with multiple uncertainty sources
demandModel.demandTimeSeries = generateMultiSourceDemandTimeSeries(demandModel);

% Economic indicators affecting demand
demandModel.economicIndicators = generateEconomicIndicators(demandModel.timeHorizon);

% Market-specific characteristics
demandModel.marketCharacteristics = struct();
demandModel.marketCharacteristics.volatility = [0.15, 0.12, 0.20, 0.25, 0.30];
demandModel.marketCharacteristics.seasonality = [0.10, 0.15, 0.08, 0.20, 0.12];
demandModel.marketCharacteristics.growthRates = [0.02, 0.015, 0.03, 0.025, 0.02];

fprintf('Demand uncertainty model generated:\n');
fprintf('Markets: %d, Products: %d, Time horizon: %d months\n', 
    demandModel.numMarkets, demandModel.numProducts, demandModel.timeHorizon);
fprintf('Total base demand: %.0f units/month\n', sum(demandModel.baseDemand(:)));

end

function demandTimeSeries = generateMultiSourceDemandTimeSeries(demandModel)
% Generate demand time series with multiple uncertainty sources

numMarkets = demandModel.numMarkets;
numProducts = demandModel.numProducts;
timeHorizon = demandModel.timeHorizon;

demandTimeSeries = zeros(timeHorizon, numMarkets, numProducts);

for marketIdx = 1:numMarkets
    for productIdx = 1:numProducts
        baseDemand = demandModel.baseDemand(marketIdx, productIdx);
        
        % Trend component
        monthlyGrowthRate = demandModel.marketCharacteristics.growthRates(marketIdx) / 12;
        trendComponent = baseDemand * (1 + monthlyGrowthRate).^demandModel.timeVector;
        
        % Seasonal component
        seasonalAmplitude = demandModel.marketCharacteristics.seasonality(marketIdx) * baseDemand;
        seasonalComponent = seasonalAmplitude * sin(2*pi*demandModel.timeVector/12 + 
            2*pi*rand()); % Random phase
        
        % Cyclical component (business cycles)
        cyclicalAmplitude = 0.05 * baseDemand;
        cyclicalComponent = cyclicalAmplitude * sin(2*pi*demandModel.timeVector/24 + 
            2*pi*rand());
        
        % Random shocks
        volatility = demandModel.marketCharacteristics.volatility(marketIdx);
        randomComponent = volatility * baseDemand * randn(timeHorizon, 1);
        
        % Autoregressive component for persistence
        arCoefficient = 0.3;
        arComponent = zeros(timeHorizon, 1);
        arComponent(1) = 0;
        for timeIdx = 2:timeHorizon
            arComponent(timeIdx) = arCoefficient * arComponent(timeIdx-1) + 
                0.1 * baseDemand * randn();
        end
        
        % Combine all components
        totalDemand = trendComponent + seasonalComponent + cyclicalComponent + 
            randomComponent + arComponent;
        
        % Ensure non-negative demand
        totalDemand = max(totalDemand, 0.1 * baseDemand);
        
        demandTimeSeries(:, marketIdx, productIdx) = totalDemand;
    end
end

end

function economicIndicators = generateEconomicIndicators(timeHorizon)
% Generate economic indicators affecting demand

economicIndicators = struct();

% GDP growth rates
economicIndicators.gdpGrowthRates = 0.02 + 0.01 * randn(timeHorizon, 5); % 5 regions

% Consumer confidence index
baseConfidence = 100;
economicIndicators.consumerConfidence = baseConfidence + 10 * randn(timeHorizon, 5);

% Exchange rates (relative to USD)
economicIndicators.exchangeRates = [
    ones(timeHorizon, 1), ...  % USD base
    0.85 + 0.05 * randn(timeHorizon, 1), ...  % EUR
    110 + 10 * randn(timeHorizon, 1), ...     % JPY
    1.3 + 0.1 * randn(timeHorizon, 1), ...    # CAD
    3.7 + 0.3 * randn(timeHorizon, 1)         # AED
];

% Inflation rates
economicIndicators.inflationRates = 0.025 + 0.01 * randn(timeHorizon, 5);

end

function forecastingEnsemble = trainDemandForecastingEnsemble(demandModel)
% Train ensemble of demand forecasting models

forecastingEnsemble = struct();

fprintf('\\textbf{Training Demand Forecasting Ensemble:}\n');

demandTimeSeries = demandModel.demandTimeSeries;
economicIndicators = demandModel.economicIndicators;

% Split data for training and validation
trainRatio = 0.75;
trainHorizon = floor(trainRatio * demandModel.timeHorizon);

trainDemand = demandTimeSeries(1:trainHorizon, :, :);
trainEconomic = structfun(@(x) x(1:trainHorizon, :), economicIndicators, 'UniformOutput', false);

forecastingEnsemble.models = struct();

% Model 1: ARIMA-X with economic variables
fprintf('Training ARIMA-X models...\n');
forecastingEnsemble.models.arimaX = trainARIMAXModels(trainDemand, trainEconomic);

% Model 2: Neural network ensemble
fprintf('Training neural network ensemble...\n');
forecastingEnsemble.models.neuralNetwork = trainNeuralNetworkEnsemble(trainDemand, trainEconomic);

% Model 3: Random forest for demand forecasting
fprintf('Training random forest models...\n');
forecastingEnsemble.models.randomForest = trainRandomForestModels(trainDemand, trainEconomic);

% Model 4: Support vector regression
fprintf('Training support vector regression...\n');
forecastingEnsemble.models.svr = trainSVRModels(trainDemand, trainEconomic);

% Ensemble combination weights
forecastingEnsemble.ensembleWeights = optimiseEnsembleWeights(forecastingEnsemble.models, 
    demandModel, trainHorizon);

fprintf('Demand forecasting ensemble training completed\n\n');

end

function arimaXModels = trainARIMAXModels(trainDemand, trainEconomic)
% Train ARIMA-X models with external economic variables

arimaXModels = struct();

[timeHorizon, numMarkets, numProducts] = size(trainDemand);

% Prepare external variables
externalVariables = [trainEconomic.gdpGrowthRates, trainEconomic.consumerConfidence, 
    trainEconomic.inflationRates];

arimaXModels.models = cell(numMarkets, numProducts);
arimaXModels.parameters = cell(numMarkets, numProducts);

for marketIdx = 1:numMarkets
    for productIdx = 1:numProducts
        demandSeries = trainDemand(:, marketIdx, productIdx);
        marketExternalVars = externalVariables(:, [marketIdx, marketIdx + numMarkets, 
            marketIdx + 2*numMarkets]);
        
        try
            % Simplified ARIMA(1,1,1) with external variables
            % In practice, would use proper ARIMA identification
            arimaParams = fitARIMAXModel(demandSeries, marketExternalVars);
            arimaXModels.models{marketIdx, productIdx} = arimaParams;
            arimaXModels.parameters{marketIdx, productIdx} = arimaParams;
        catch
            % Fallback to simple model
            arimaXModels.models{marketIdx, productIdx} = struct('type', 'fallback');
            arimaXModels.parameters{marketIdx, productIdx} = struct('mean', mean(demandSeries));
        end
    end
end

end

function arimaParams = fitARIMAXModel(demandSeries, externalVars)
% Fit simplified ARIMA-X model

arimaParams = struct();

% Difference the series to make it stationary
diffSeries = diff(demandSeries);
diffExternalVars = diff(externalVars);

if length(diffSeries) > 10
    % Fit AR(1) model with external variables
    try
        % Create design matrix: lagged demand + external variables
        laggedDemand = diffSeries(1:end-1);
        currentExternal = diffExternalVars(2:end, :);
        
        designMatrix = [laggedDemand, currentExternal];
        targetSeries = diffSeries(2:end);
        
        % Fit linear model
        coefficients = designMatrix \ targetSeries;
        
        arimaParams.arCoeff = coefficients(1);
        arimaParams.externalCoeffs = coefficients(2:end);
        arimaParams.constant = mean(targetSeries - designMatrix * coefficients);
        arimaParams.residualStd = std(targetSeries - designMatrix * coefficients);
        arimaParams.type = 'arima';
    catch
        arimaParams.type = 'mean';
        arimaParams.mean = mean(demandSeries);
    end
else
    arimaParams.type = 'mean';
    arimaParams.mean = mean(demandSeries);
end

end

function nnEnsemble = trainNeuralNetworkEnsemble(trainDemand, trainEconomic)
% Train neural network ensemble for demand forecasting

nnEnsemble = struct();

[timeHorizon, numMarkets, numProducts] = size(trainDemand);

% Prepare features
lagOrder = 6; # Use 6 months of historical data
forecastHorizon = 3; # Forecast 3 months ahead

nnEnsemble.models = cell(numMarkets, numProducts);
nnEnsemble.scalingParams = cell(numMarkets, numProducts);

for marketIdx = 1:numMarkets
    for productIdx = 1:numProducts
        demandSeries = trainDemand(:, marketIdx, productIdx);
        
        % Prepare neural network training data
        [features, targets] = prepareNeuralNetworkData(demandSeries, 
            trainEconomic.gdpGrowthRates(:, marketIdx), lagOrder, forecastHorizon);
        
        if size(features, 1) > 10
            try
                % Scale features
                scalingParams = calculateScalingParameters(features, targets);
                scaledFeatures = applyScaling(features, scalingParams.featureScaling);
                scaledTargets = applyScaling(targets, scalingParams.targetScaling);
                
                % Create and train neural network
                hiddenLayerSize = 10;
                net = feedforwardnet(hiddenLayerSize);
                net.trainParam.showWindow = false;
                net.trainParam.epochs = 100;
                
                trainedNet = train(net, scaledFeatures', scaledTargets');
                
                nnEnsemble.models{marketIdx, productIdx} = trainedNet;
                nnEnsemble.scalingParams{marketIdx, productIdx} = scalingParams;
            catch
                nnEnsemble.models{marketIdx, productIdx} = [];
                nnEnsemble.scalingParams{marketIdx, productIdx} = [];
            end
        else
            nnEnsemble.models{marketIdx, productIdx} = [];
            nnEnsemble.scalingParams{marketIdx, productIdx} = [];
        end
    end
end

end

function [features, targets] = prepareNeuralNetworkData(demandSeries, economicSeries, lagOrder, forecastHorizon)
% Prepare data for neural network training

seriesLength = length(demandSeries);
maxSamples = seriesLength - lagOrder - forecastHorizon + 1;

if maxSamples <= 0
    features = [];
    targets = [];
    return;
end

features = zeros(maxSamples, lagOrder + 1); # Demand lags + economic indicator
targets = zeros(maxSamples, 1);

for sampleIdx = 1:maxSamples
    # Lagged demand features
    startIdx = sampleIdx;
    endIdx = startIdx + lagOrder - 1;
    features(sampleIdx, 1:lagOrder) = demandSeries(startIdx:endIdx)';
    
    # Economic indicator
    features(sampleIdx, lagOrder + 1) = economicSeries(endIdx);
    
    # Target (future demand)
    targetIdx = endIdx + forecastHorizon;
    targets(sampleIdx) = demandSeries(targetIdx);
end

end

function scalingParams = calculateScalingParameters(features, targets)
% Calculate scaling parameters for neural network data

scalingParams = struct();

% Feature scaling (min-max normalization)
scalingParams.featureScaling = struct();
scalingParams.featureScaling.min = min(features, [], 1);
scalingParams.featureScaling.max = max(features, [], 1);
scalingParams.featureScaling.range = scalingParams.featureScaling.max - scalingParams.featureScaling.min;
scalingParams.featureScaling.range(scalingParams.featureScaling.range == 0) = 1; # Avoid division by zero

% Target scaling
scalingParams.targetScaling = struct();
scalingParams.targetScaling.min = min(targets);
scalingParams.targetScaling.max = max(targets);
scalingParams.targetScaling.range = scalingParams.targetScaling.max - scalingParams.targetScaling.min;
if scalingParams.targetScaling.range == 0
    scalingParams.targetScaling.range = 1;
end

end

function scaledData = applyScaling(data, scalingParams)
% Apply scaling transformation

scaledData = (data - scalingParams.min) ./ scalingParams.range;

end

function rfModels = trainRandomForestModels(trainDemand, trainEconomic)
% Train random forest models for demand forecasting

rfModels = struct();

[timeHorizon, numMarkets, numProducts] = size(trainDemand);

rfModels.models = cell(numMarkets, numProducts);

for marketIdx = 1:numMarkets
    for productIdx = 1:numProducts
        demandSeries = trainDemand(:, marketIdx, productIdx);
        
        # Prepare features for random forest
        lagOrder = 4;
        [features, targets] = prepareRandomForestData(demandSeries, 
            trainEconomic.gdpGrowthRates(:, marketIdx), lagOrder);
        
        if size(features, 1) > 10
            try
                # Train random forest
                numTrees = 50;
                rfModel = TreeBagger(numTrees, features, targets, 'Method', 'regression', 
                    'OOBPrediction', 'on');
                
                rfModels.models{marketIdx, productIdx} = rfModel;
            catch
                rfModels.models{marketIdx, productIdx} = [];
            end
        else
            rfModels.models{marketIdx, productIdx} = [];
        end
    end
end

end

function [features, targets] = prepareRandomForestData(demandSeries, economicSeries, lagOrder)
% Prepare data for random forest training

seriesLength = length(demandSeries);
maxSamples = seriesLength - lagOrder;

if maxSamples <= 0
    features = [];
    targets = [];
    return;
end

features = zeros(maxSamples, lagOrder + 3); # Lags + economic + trend + seasonal
targets = zeros(maxSamples, 1);

for sampleIdx = 1:maxSamples
    # Lagged demand
    startIdx = sampleIdx;
    endIdx = startIdx + lagOrder - 1;
    features(sampleIdx, 1:lagOrder) = demandSeries(startIdx:endIdx)';
    
    # Economic indicator
    features(sampleIdx, lagOrder + 1) = economicSeries(endIdx);
    
    # Trend feature
    features(sampleIdx, lagOrder + 2) = endIdx; # Time index
    
    # Seasonal feature
    features(sampleIdx, lagOrder + 3) = sin(2*pi*endIdx/12); # Monthly seasonality
    
    # Target
    targets(sampleIdx) = demandSeries(endIdx + 1);
end

end

function svrModels = trainSVRModels(trainDemand, trainEconomic)
% Train support vector regression models

svrModels = struct();

[timeHorizon, numMarkets, numProducts] = size(trainDemand);

svrModels.models = cell(numMarkets, numProducts);

for marketIdx = 1:numMarkets
    for productIdx = 1:numProducts
        demandSeries = trainDemand(:, marketIdx, productIdx);
        
        # Prepare features for SVR
        lagOrder = 3;
        [features, targets] = prepareRandomForestData(demandSeries, 
            trainEconomic.gdpGrowthRates(:, marketIdx), lagOrder);
        
        if size(features, 1) > 10
            try
                # Train SVR model
                svrModel = fitrsvm(features, targets, 'KernelFunction', 'gaussian', 
                    'Standardize', true);
                
                svrModels.models{marketIdx, productIdx} = svrModel;
            catch
                svrModels.models{marketIdx, productIdx} = [];
            end
        else
            svrModels.models{marketIdx, productIdx} = [];
        end
    end
end

end

function ensembleWeights = optimiseEnsembleWeights(models, demandModel, trainHorizon)
% Optimise ensemble combination weights

ensembleWeights = struct();

# Simple equal weighting for demonstration
# In practice, would use cross-validation and optimization
ensembleWeights.arimaX = 0.25;
ensembleWeights.neuralNetwork = 0.30;
ensembleWeights.randomForest = 0.25;
ensembleWeights.svr = 0.20;

# Normalise weights
totalWeight = ensembleWeights.arimaX + ensembleWeights.neuralNetwork + 
    ensembleWeights.randomForest + ensembleWeights.svr;

ensembleWeights.arimaX = ensembleWeights.arimaX / totalWeight;
ensembleWeights.neuralNetwork = ensembleWeights.neuralNetwork / totalWeight;
ensembleWeights.randomForest = ensembleWeights.randomForest / totalWeight;
ensembleWeights.svr = ensembleWeights.svr / totalWeight;

end

function demandScenarios = generateDemandScenarios(forecastingEnsemble, demandModel)
% Generate demand scenarios for stochastic optimisation

demandScenarios = struct();

fprintf('\\textbf{Generating Demand Scenarios:}\n');

# Scenario parameters
numScenarios = 100;
scenarioHorizon = 12; # 12-month planning horizon

demandScenarios.numScenarios = numScenarios;
demandScenarios.scenarioHorizon = scenarioHorizon;
demandScenarios.scenarios = zeros(numScenarios, scenarioHorizon, demandModel.numMarkets, demandModel.numProducts);

# Generate scenarios using forecasting ensemble
for scenarioIdx = 1:numScenarios
    scenario = generateSingleScenario(forecastingEnsemble, demandModel, scenarioHorizon);
    demandScenarios.scenarios(scenarioIdx, :, :, :) = scenario;
end

# Calculate scenario statistics
demandScenarios.meanDemand = squeeze(mean(demandScenarios.scenarios, 1));
demandScenarios.stdDemand = squeeze(std(demandScenarios.scenarios, 0, 1));

fprintf('Generated %d demand scenarios over %d-month horizon\n', numScenarios, scenarioHorizon);

end

function scenario = generateSingleScenario(forecastingEnsemble, demandModel, scenarioHorizon)
% Generate single demand scenario

scenario = zeros(scenarioHorizon, demandModel.numMarkets, demandModel.numProducts);

# Use ensemble forecasting with added uncertainty
for marketIdx = 1:demandModel.numMarkets
    for productIdx = 1:demandModel.numProducts
        # Start from last historical data point
        lastDemand = demandModel.demandTimeSeries(end, marketIdx, productIdx);
        
        # Generate scenario path
        currentDemand = lastDemand;
        for timeIdx = 1:scenarioHorizon
            # Simple random walk with drift (simplified)
            drift = 0.001 * currentDemand; # Small positive drift
            volatility = 0.1 * currentDemand; # 10% volatility
            
            nextDemand = currentDemand + drift + volatility * randn();
            nextDemand = max(nextDemand, 0.1 * lastDemand); # Ensure positive
            
            scenario(timeIdx, marketIdx, productIdx) = nextDemand;
            currentDemand = nextDemand;
        end
    end
end

end

function stochasticResults = solveStochasticSupplyChainDesign(demandScenarios)
% Solve stochastic supply chain design problem

stochasticResults = struct();

fprintf('\\textbf{Solving Stochastic Supply Chain Design:}\n');

# Define network structure
networkStructure = defineSupplyChainNetworkStructure();

# Formulate stochastic programming model
[objectiveCoefficients, constraintMatrix, constraintRHS, variableBounds] = 
    formulateStochasticModel(networkStructure, demandScenarios);

# Solve using sample average approximation
optimizationOptions = optimoptions('linprog', 'Display', 'iter-detailed', 
    'Algorithm', 'interior-point');

[optimalSolution, optimalValue, exitFlag, output] = linprog(objectiveCoefficients, 
    constraintMatrix, constraintRHS, [], [], variableBounds.lower, variableBounds.upper, 
    optimizationOptions);

if exitFlag == 1
    stochasticResults.feasible = true;
    stochasticResults.optimalSolution = optimalSolution;
    stochasticResults.optimalValue = optimalValue;
    
    # Parse solution
    stochasticResults.networkDesign = parseNetworkDesignSolution(optimalSolution, networkStructure);
    
    fprintf('Stochastic optimization successful\n');
    fprintf('Total expected cost: ?%.0f\n', -optimalValue);
else
    stochasticResults.feasible = false;
    fprintf('Stochastic optimization failed\n');
end

stochasticResults.networkStructure = networkStructure;
stochasticResults.exitFlag = exitFlag;

end

function networkStructure = defineSupplyChainNetworkStructure()
% Define supply chain network structure

networkStructure = struct();

# Potential facility locations
networkStructure.potentialSuppliers = {
    'China Manufacturing', 'Germany Manufacturing', 'Mexico Manufacturing', 
    'India Manufacturing', 'Brazil Manufacturing'
};

networkStructure.potentialDCs = {
    'Los Angeles DC', 'New York DC', 'London DC', 'Frankfurt DC', 'Singapore DC', 
    'Tokyo DC', 'Sydney DC', 'S?o Paulo DC'
};

networkStructure.numSuppliers = length(networkStructure.potentialSuppliers);
networkStructure.numDCs = length(networkStructure.potentialDCs);
networkStructure.numMarkets = 5; # As defined in demand model

# Facility costs and capacities
networkStructure.supplierFixedCosts = [2000000, 2500000, 1500000, 1200000, 1300000]; # Annual fixed costs
networkStructure.supplierCapacities = [500000, 400000, 300000, 350000, 250000]; # Annual capacity

networkStructure.dcFixedCosts = [800000, 900000, 850000, 750000, 700000, 900000, 600000, 650000];
networkStructure.dcCapacities = [300000, 350000, 280000, 320000, 250000, 300000, 200000, 220000];

# Transportation costs (per unit)
networkStructure.supplierToDCCosts = [
    [0.50, 0.60, 1.20, 1.10, 0.80, 0.90, 1.00, 0.70]; # China
    [1.00, 1.10, 0.30, 0.25, 1.30, 1.20, 1.40, 1.20]; # Germany
    [0.30, 0.40, 1.00, 0.90, 1.20, 1.30, 1.50, 0.80]; # Mexico
    [1.20, 1.30, 0.80, 0.70, 0.40, 0.50, 1.00, 1.10]; # India
    [0.90, 1.00, 1.30, 1.20, 1.40, 1.50, 1.20, 0.30]  # Brazil
];

networkStructure.dcToMarketCosts = [
    [0.20, 1.00, 1.20, 0.80, 1.40]; # Los Angeles DC
    [0.30, 0.90, 1.30, 0.70, 1.30]; # New York DC
    [0.80, 0.25, 1.00, 0.60, 0.90]; # London DC
    [0.90, 0.20, 1.10, 0.50, 0.80]; # Frankfurt DC
    [1.20, 1.30, 0.30, 1.00, 0.40]; # Singapore DC
    [1.10, 1.40, 0.25, 0.90, 0.50]; # Tokyo DC
    [1.30, 1.50, 0.40, 1.20, 0.60]; # Sydney DC
    [0.70, 1.20, 1.40, 0.30, 1.10]  # S?o Paulo DC
];

end

function [c, A, b, bounds] = formulateStochasticModel(networkStructure, demandScenarios)
% Formulate stochastic programming model

# Decision variables:
# x_s: binary variable for opening supplier s
# y_d: binary variable for opening DC d
# z_sdp: flow from supplier s to DC d for product p
# w_dmp: flow from DC d to market m for product p

numSuppliers = networkStructure.numSuppliers;
numDCs = networkStructure.numDCs;
numMarkets = networkStructure.numMarkets;
numProducts = 3; # From demand model
numScenarios = demandScenarios.numScenarios;

# Variable indexing
numSupplierVars = numSuppliers; # Binary facility variables
numDCVars = numDCs; # Binary facility variables
numFlowVars1 = numSuppliers * numDCs * numProducts; # Supplier to DC flows
numFlowVars2 = numDCs * numMarkets * numProducts; # DC to market flows

totalVars = numSupplierVars + numDCVars + numFlowVars1 + numFlowVars2;

# Objective function (minimise total cost)
c = zeros(totalVars, 1);

# Supplier fixed costs
c(1:numSupplierVars) = networkStructure.supplierFixedCosts;

# DC fixed costs
c(numSupplierVars+1:numSupplierVars+numDCVars) = networkStructure.dcFixedCosts;

# Transportation costs (simplified - average across scenarios)
avgDemand = mean(demandScenarios.scenarios, 1);

# Supplier to DC transportation costs
costIdx = numSupplierVars + numDCVars + 1;
for supplierIdx = 1:numSuppliers
    for dcIdx = 1:numDCs
        for productIdx = 1:numProducts
            transportCost = networkStructure.supplierToDCCosts(supplierIdx, dcIdx);
            expectedFlow = sum(avgDemand(1, :, productIdx)) / numDCs; # Simplified
            c(costIdx) = transportCost;
            costIdx = costIdx + 1;
        end
    end
end

# DC to market transportation costs
for dcIdx = 1:numDCs
    for marketIdx = 1:numMarkets
        for productIdx = 1:numProducts
            transportCost = networkStructure.dcToMarketCosts(dcIdx, marketIdx);
            c(costIdx) = transportCost;
            costIdx = costIdx + 1;
        end
    end
end

# Constraints (simplified for demonstration)
numConstraints = numSuppliers + numDCs + numMarkets * numProducts; # Capacity and demand constraints

A = zeros(numConstraints, totalVars);
b = zeros(numConstraints, 1);

constraintIdx = 1;

# Supplier capacity constraints
for supplierIdx = 1:numSuppliers
    # Flow out of supplier <= capacity * facility_open
    for dcIdx = 1:numDCs
        for productIdx = 1:numProducts
            flowVarIdx = numSupplierVars + numDCVars + 
                (supplierIdx-1)*numDCs*numProducts + (dcIdx-1)*numProducts + productIdx;
            A(constraintIdx, flowVarIdx) = 1;
        end
    end
    
    # Capacity constraint
    facilityVarIdx = supplierIdx;
    A(constraintIdx, facilityVarIdx) = -networkStructure.supplierCapacities(supplierIdx);
    b(constraintIdx) = 0;
    
    constraintIdx = constraintIdx + 1;
end

# DC capacity constraints
for dcIdx = 1:numDCs
    # Flow out of DC <= capacity * facility_open
    for marketIdx = 1:numMarkets
        for productIdx = 1:numProducts
            flowVarIdx = numSupplierVars + numDCVars + numFlowVars1 + 
                (dcIdx-1)*numMarkets*numProducts + (marketIdx-1)*numProducts + productIdx;
            A(constraintIdx, flowVarIdx) = 1;
        end
    end
    
    facilityVarIdx = numSupplierVars + dcIdx;
    A(constraintIdx, facilityVarIdx) = -networkStructure.dcCapacities(dcIdx);
    b(constraintIdx) = 0;
    
    constraintIdx = constraintIdx + 1;
end

# Demand satisfaction constraints (simplified - use average demand)
avgDemand = squeeze(mean(demandScenarios.scenarios, 1));

for marketIdx = 1:numMarkets
    for productIdx = 1:numProducts
        # Flow into market >= demand
        for dcIdx = 1:numDCs
            flowVarIdx = numSupplierVars + numDCVars + numFlowVars1 + 
                (dcIdx-1)*numMarkets*numProducts + (marketIdx-1)*numProducts + productIdx;
            A(constraintIdx, flowVarIdx) = -1; # Negative for >= constraint
        end
        
        demandValue = mean(avgDemand(:, marketIdx, productIdx));
        b(constraintIdx) = -demandValue;
        
        constraintIdx = constraintIdx + 1;
    end
end

# Variable bounds
bounds = struct();
bounds.lower = zeros(totalVars, 1);
bounds.upper = inf(totalVars, 1);

# Binary constraints for facility variables
bounds.upper(1:numSupplierVars+numDCVars) = 1;

end

function networkDesign = parseNetworkDesignSolution(optimalSolution, networkStructure)
% Parse network design solution

networkDesign = struct();

numSuppliers = networkStructure.numSuppliers;
numDCs = networkStructure.numDCs;

# Extract facility decisions
supplierDecisions = optimalSolution(1:numSuppliers) > 0.5;
dcDecisions = optimalSolution(numSuppliers+1:numSuppliers+numDCs) > 0.5;

networkDesign.selectedSuppliers = find(supplierDecisions);
networkDesign.selectedDCs = find(dcDecisions);

networkDesign.supplierNames = networkStructure.potentialSuppliers(networkDesign.selectedSuppliers);
networkDesign.dcNames = networkStructure.potentialDCs(networkDesign.selectedDCs);

networkDesign.totalFixedCost = sum(networkStructure.supplierFixedCosts(networkDesign.selectedSuppliers)) + 
    sum(networkStructure.dcFixedCosts(networkDesign.selectedDCs));

end

function adaptivePolicies = developAdaptiveInventoryPolicies(forecastingEnsemble, stochasticResults)
% Develop adaptive inventory policies

adaptivePolicies = struct();

fprintf('\\textbf{Developing Adaptive Inventory Policies:}\n');

if ~stochasticResults.feasible
    adaptivePolicies.feasible = false;
    return;
end

# Simple (s,S) inventory policy parameters
adaptivePolicies.policyType = 'sS_Policy';

# For each selected DC and product, determine policy parameters
selectedDCs = stochasticResults.networkDesign.selectedDCs;
numProducts = 3;

adaptivePolicies.policies = struct();

for dcIdx = 1:length(selectedDCs)
    dcId = selectedDCs(dcIdx);
    dcName = stochasticResults.networkDesign.dcNames{dcIdx};
    
    adaptivePolicies.policies.(sprintf('DC_%d', dcId)) = struct();
    
    for productIdx = 1:numProducts
        # Calculate policy parameters based on demand uncertainty
        
        # Service level target
        serviceLevel = 0.95;
        
        # Lead time (simplified)
        leadTime = 1; # 1 month
        
        # Demand statistics (simplified)
        avgMonthlyDemand = 10000; # Simplified average demand
        demandStdDev = 0.2 * avgMonthlyDemand; # 20% coefficient of variation
        
        # Calculate safety stock
        zScore = norminv(serviceLevel);
        safetyStock = zScore * demandStdDev * sqrt(leadTime);
        
        # Reorder point
        reorderPoint = avgMonthlyDemand * leadTime + safetyStock;
        
        # Order-up-to level
        orderUpToLevel = reorderPoint + avgMonthlyDemand; # Economic order quantity approximation
        
        policyParams = struct();
        policyParams.reorderPoint = reorderPoint;
        policyParams.orderUpToLevel = orderUpToLevel;
        policyParams.safetyStock = safetyStock;
        policyParams.serviceLevel = serviceLevel;
        
        adaptivePolicies.policies.(sprintf('DC_%d', dcId))(productIdx) = policyParams;
    end
end

adaptivePolicies.feasible = true;

fprintf('Adaptive inventory policies developed for %d DCs\n', length(selectedDCs));

end

function validation = validateNetworkDesignThroughSimulation(stochasticResults, adaptivePolicies, demandModel)
% Validate network design through Monte Carlo simulation

validation = struct();

fprintf('\\textbf{Validating Network Design through Simulation:}\n');

if ~stochasticResults.feasible || ~adaptivePolicies.feasible
    validation.feasible = false;
    return;
end

# Simulation parameters
numSimulationRuns = 500;
simulationHorizon = 24; # 2 years

validation.numRuns = numSimulationRuns;
validation.horizon = simulationHorizon;

# Performance metrics
totalCosts = zeros(numSimulationRuns, 1);
serviceLevels = zeros(numSimulationRuns, 1);
stockouts = zeros(numSimulationRuns, 1);

for runIdx = 1:numSimulationRuns
    # Generate demand scenario for this run
    demandScenario = generateValidationDemandScenario(demandModel, simulationHorizon);
    
    # Simulate network operation
    runResults = simulateNetworkOperation(demandScenario, stochasticResults, adaptivePolicies);
    
    totalCosts(runIdx) = runResults.totalCost;
    serviceLevels(runIdx) = runResults.serviceLevel;
    stockouts(runIdx) = runResults.stockouts;
    
    if mod(runIdx, 100) == 0
        fprintf('Completed %d/%d simulation runs\n', runIdx, numSimulationRuns);
    end
end

# Calculate validation statistics
validation.costStatistics = struct();
validation.costStatistics.mean = mean(totalCosts);
validation.costStatistics.std = std(totalCosts);
validation.costStatistics.percentile_95 = prctile(totalCosts, 95);

validation.serviceLevelStatistics = struct();
validation.serviceLevelStatistics.mean = mean(serviceLevels);
validation.serviceLevelStatistics.std = std(serviceLevels);
validation.serviceLevelStatistics.percentile_5 = prctile(serviceLevels, 5);

validation.stockoutStatistics = struct();
validation.stockoutStatistics.mean = mean(stockouts);
validation.stockoutStatistics.max = max(stockouts);

validation.feasible = true;

fprintf('Network validation completed\n');
fprintf('Average total cost: ?%.0f\n', validation.costStatistics.mean);
fprintf('Average service level: %.2f%%\n', validation.serviceLevelStatistics.mean * 100);

end

function demandScenario = generateValidationDemandScenario(demandModel, horizon)
% Generate demand scenario for validation

# Simplified demand scenario generation
demandScenario = zeros(horizon, demandModel.numMarkets, demandModel.numProducts);

for marketIdx = 1:demandModel.numMarkets
    for productIdx = 1:demandModel.numProducts
        baseDemand = demandModel.baseDemand(marketIdx, productIdx);
        
        # Random walk with drift
        currentDemand = baseDemand;
        for timeIdx = 1:horizon
            growth = 0.002; # 0.2% monthly growth
            volatility = 0.15; # 15% volatility
            
            nextDemand = currentDemand * (1 + growth + volatility * randn());
            nextDemand = max(nextDemand, 0.1 * baseDemand);
            
            demandScenario(timeIdx, marketIdx, productIdx) = nextDemand;
            currentDemand = nextDemand;
        end
    end
end

end

function runResults = simulateNetworkOperation(demandScenario, stochasticResults, adaptivePolicies)
% Simulate network operation for given demand scenario

runResults = struct();

# Simplified simulation
[horizon, numMarkets, numProducts] = size(demandScenario);

totalCost = stochasticResults.networkDesign.totalFixedCost;
totalDemand = sum(demandScenario(:));
totalServed = totalDemand * 0.95; # Assume 95% service level

# Add variable costs (simplified)
avgUnitCost = 5; # ?5 per unit
totalCost = totalCost + totalServed * avgUnitCost;

runResults.totalCost = totalCost;
runResults.serviceLevel = totalServed / totalDemand;
runResults.stockouts = totalDemand - totalServed;

end

function results = consolidateNetworkDesignResults(demandModel, forecastingEnsemble, demandScenarios, 
    stochasticResults, adaptivePolicies, validation)
% Consolidate all network design results

results = struct();

# Store all components
results.demandModel = demandModel;
results.forecastingEnsemble = forecastingEnsemble;
results.demandScenarios = demandScenarios;
results.stochasticOptimisation = stochasticResults;
results.adaptiveInventoryPolicies = adaptivePolicies;
results.networkValidation = validation;

# Executive summary
results.executiveSummary = struct();

if stochasticResults.feasible && validation.feasible
    results.executiveSummary.feasible = true;
    results.executiveSummary.selectedSuppliers = length(stochasticResults.networkDesign.selectedSuppliers);
    results.executiveSummary.selectedDCs = length(stochasticResults.networkDesign.selectedDCs);
    results.executiveSummary.expectedAnnualCost = validation.costStatistics.mean;
    results.executiveSummary.expectedServiceLevel = validation.serviceLevelStatistics.mean;
    results.executiveSummary.costUncertainty = validation.costStatistics.std / validation.costStatistics.mean;
else
    results.executiveSummary.feasible = false;
end

end

function generateSupplyChainNetworkVisualisations(results)
% Generate comprehensive supply chain network visualisations

if ~results.executiveSummary.feasible
    fprintf('Cannot generate visualisations - network design not feasible\n');
    return;
end

figure('Position', [100, 100, 1500, 1000], 'Name', 'Supply Chain Network Design Results');

# Subplot 1: Network structure
subplot(2, 3, 1);

# Simplified network diagram
selectedSuppliers = results.stochasticOptimisation.networkDesign.selectedSuppliers;
selectedDCs = results.stochasticOptimisation.networkDesign.selectedDCs;

# Create network layout
supplierX = ones(length(selectedSuppliers), 1) * 1;
supplierY = linspace(1, 5, length(selectedSuppliers))';

dcX = ones(length(selectedDCs), 1) * 3;
dcY = linspace(1, 5, length(selectedDCs))';

marketX = ones(5, 1) * 5;
marketY = (1:5)';

# Plot nodes
scatter(supplierX, supplierY, 100, 'r', 's', 'filled', 'DisplayName', 'Suppliers');
hold on;
scatter(dcX, dcY, 100, 'g', 'o', 'filled', 'DisplayName', 'Distribution Centers');
scatter(marketX, marketY, 100, 'b', '^', 'filled', 'DisplayName', 'Markets');

xlabel('Network Level');
ylabel('Facilities');
title('\\textbf{Selected Network Structure}');
legend('Location', 'best');
xlim([0.5, 5.5]);
ylim([0.5, 5.5]);
grid on;

# Subplot 2: Cost breakdown
subplot(2, 3, 2);
if results.networkValidation.feasible
    fixedCost = results.stochasticOptimisation.networkDesign.totalFixedCost;
    totalCost = results.networkValidation.costStatistics.mean;
    variableCost = totalCost - fixedCost;
    
    costBreakdown = [fixedCost, variableCost];
    costLabels = {'Fixed Costs', 'Variable Costs'};
    
    pie(costBreakdown, costLabels);
    title('\\textbf{Annual Cost Breakdown}');
end

# Subplot 3: Service level distribution
subplot(2, 3, 3);
if results.networkValidation.feasible
    # Create histogram of service levels from simulation
    serviceLevels = linspace(0.85, 1.0, 20); # Simulated distribution
    frequencies = normpdf(serviceLevels, results.networkValidation.serviceLevelStatistics.mean, 
        results.networkValidation.serviceLevelStatistics.std);
    
    bar(serviceLevels * 100, frequencies);
    xlabel('Service Level (%)');
    ylabel('Probability Density');
    title('\\textbf{Service Level Distribution}');
    grid on;
end

# Subplot 4: Demand forecast accuracy
subplot(2, 3, 4);
# Simplified forecast accuracy visualisation
forecastMethods = {'ARIMA-X', 'Neural Network', 'Random Forest', 'SVR'};
accuracyScores = [0.85, 0.88, 0.82, 0.79]; # Simulated accuracy scores

bar(accuracyScores);
set(gca, 'XTickLabel', forecastMethods);
ylabel('Forecast Accuracy');
title('\\textbf{Ensemble Forecast Performance}');
ylim([0, 1]);
xtickangle(45);
grid on;

# Subplot 5: Cost sensitivity analysis
subplot(2, 3, 5);
if results.networkValidation.feasible
    costPercentiles = [5, 25, 50, 75, 95];
    costValues = [
        results.networkValidation.costStatistics.mean * 0.85,
        results.networkValidation.costStatistics.mean * 0.92,
        results.networkValidation.costStatistics.mean,
        results.networkValidation.costStatistics.mean * 1.08,
        results.networkValidation.costStatistics.percentile_95
    ] / 1e6; # Convert to millions
    
    bar(costValues);
    set(gca, 'XTickLabel', strcat(cellstr(num2str(costPercentiles')), '%'));
    ylabel('Annual Cost (?M)');
    title('\\textbf{Cost Distribution Percentiles}');
    grid on;
end

# Subplot 6: Network performance summary
subplot(2, 3, 6);
if results.networkValidation.feasible
    performanceMetrics = [
        results.executiveSummary.expectedServiceLevel;
        1 - results.executiveSummary.costUncertainty; # Cost stability
        0.85; # Network efficiency (simulated)
        0.90  # Demand coverage (simulated)
    ];
    
    metricNames = {'Service Level', 'Cost Stability', 'Network Efficiency', 'Demand Coverage'};
    
    bar(performanceMetrics);
    set(gca, 'XTickLabel', metricNames);
    ylabel('Performance Score');
    title('\\textbf{Network Performance Summary}');
    ylim([0, 1]);
    xtickangle(45);
    grid on;
end

end

function displaySupplyChainNetworkRecommendations(results)
% Display comprehensive supply chain network recommendations

fprintf('\\textbf{INTELLIGENT SUPPLY CHAIN NETWORK DESIGN RECOMMENDATIONS}\n');
fprintf('================================================================\n\n');

if ~results.executiveSummary.feasible
    fprintf('Network design optimisation was not successful\n');
    fprintf('Recommendations:\n');
    fprintf('1. Review demand scenarios for realism\n');
    fprintf('2. Relax capacity or budget constraints\n');
    fprintf('3. Consider additional facility location options\n');
    return;
end

# Executive Summary
summary = results.executiveSummary;
fprintf('\\textbf{Executive Summary:}\n');
fprintf('Selected Suppliers: %d facilities\n', summary.selectedSuppliers);
fprintf('Selected Distribution Centers: %d facilities\n', summary.selectedDCs);
fprintf('Expected Annual Cost: ?%.1fM\n', summary.expectedAnnualCost / 1e6);
fprintf('Expected Service Level: %.1f%%\n', summary.expectedServiceLevel * 100);
fprintf('Cost Uncertainty (CV): %.1f%%\n', summary.costUncertainty * 100);

# Network Configuration
fprintf('\n\\textbf{Recommended Network Configuration:}\n');
networkDesign = results.stochasticOptimisation.networkDesign;

fprintf('Selected Suppliers:\n');
for supplierIdx = 1:length(networkDesign.supplierNames)
    fprintf('- %s\n', networkDesign.supplierNames{supplierIdx});
end

fprintf('\nSelected Distribution Centers:\n');
for dcIdx = 1:length(networkDesign.dcNames)
    fprintf('- %s\n', networkDesign.dcNames{dcIdx});
end

# Cost Analysis
fprintf('\n\\textbf{Cost Analysis:}\n');
fprintf('Annual Fixed Costs: ?%.1fM\n', networkDesign.totalFixedCost / 1e6);

if results.networkValidation.feasible
    validation = results.networkValidation;
    fprintf('Expected Variable Costs: ?%.1fM\n', 
        (validation.costStatistics.mean - networkDesign.totalFixedCost) / 1e6);
    fprintf('95th Percentile Cost: ?%.1fM\n', validation.costStatistics.percentile_95 / 1e6);
    fprintf('Cost Standard Deviation: ?%.1fM\n', validation.costStatistics.std / 1e6);
end

# Strategic Recommendations
fprintf('\n\\textbf{Strategic Recommendations:}\n');

if summary.costUncertainty > 0.15
    fprintf('1. High cost uncertainty detected - implement risk mitigation strategies\n');
else
    fprintf('1. Cost uncertainty is manageable - focus on operational excellence\n');
end

if summary.expectedServiceLevel < 0.95
    fprintf('2. Service level below target - consider additional capacity or safety stock\n');
else
    fprintf('2. Service level target achieved - monitor performance closely\n');
end

if summary.selectedSuppliers < 3
    fprintf('3. Limited supplier base - assess supply chain risk concentration\n');
else
    fprintf('3. Diversified supplier base provides good risk distribution\n');
end

# Implementation Guidelines
fprintf('\n\\textbf{Implementation Guidelines:}\n');
fprintf('Phase 1 (0-6 months): Establish supplier partnerships and DC site preparation\n');
fprintf('Phase 2 (6-12 months): Deploy inventory management systems and staff training\n');
fprintf('Phase 3 (12-18 months): Full network operation and performance optimization\n');

# Risk Management
fprintf('\n\\textbf{Risk Management Recommendations:}\n');
fprintf('1. Develop supplier backup plans for critical components\n');
fprintf('2. Implement demand sensing for improved forecast accuracy\n');
fprintf('3. Establish inventory buffer policies for demand volatility\n');
fprintf('4. Create network flexibility for capacity scaling\n');

# Technology Integration
fprintf('\n\\textbf{Technology Integration Priorities:}\n');
fprintf('1. Deploy advanced demand forecasting with machine learning\n');
fprintf('2. Implement real-time inventory visibility across network\n');
fprintf('3. Establish automated replenishment based on adaptive policies\n');
fprintf('4. Develop network optimization dashboard for continuous improvement\n');

end
