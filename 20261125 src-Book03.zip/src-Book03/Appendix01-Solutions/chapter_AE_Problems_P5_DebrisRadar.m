%% chapter_AE_Problems_P5_DebrisRadar.m
% Matched filter for space debris radar detection.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AE_Problems_P5_DebrisRadar
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [detectionResults, performanceMetrics] = spaceDebrisRadarDetection(radarParameters, targetScenario, processingConfig)
    % Matched filter processing for space debris detection and tracking
    % Author: Dr Leo Chen
    % Version: 2.2.0 - Enhanced CFAR processing
    % Date: 2024-11-14
    
    fprintf('Space Debris Radar Detection System\n');
    fprintf('Radar frequency: %.1f GHz, PRF: %.1f kHz\n', ...
            radarParameters.frequency / 1e9, radarParameters.prf / 1e3);
    fprintf('Detection range: %.0f km, Debris size: %.1f-%.1f cm\n', ...
            radarParameters.maxRange / 1e3, targetScenario.minSize * 100, targetScenario.maxSize * 100);
    
    % Radar system parameters
    carrierFreq = radarParameters.frequency;
    prf = radarParameters.prf;
    pulseWidth = radarParameters.pulseWidth;
    bandwidth = radarParameters.bandwidth;
    transmitPower = radarParameters.transmitPower;
    
    % Generate radar waveform (Linear Frequency Modulated chirp)
    [transmitWaveform, timeVector] = generateLFMChirp(pulseWidth, bandwidth, ...
                                                     radarParameters.samplingRate);
    
    fprintf('Radar waveform generated\n');
    fprintf('  Pulse width: %.1f --s, Bandwidth: %.1f MHz\n', ...
            pulseWidth * 1e6, bandwidth / 1e6);
    fprintf('  Time-bandwidth product: %.0f\n', pulseWidth * bandwidth);
    
    % Simulate debris targets
    numTargets = length(targetScenario.debris);
    receivedSignals = cell(numTargets, 1);
    targetParameters = struct('range', {}, 'velocity', {}, 'rcs', {});
    
    for targetIndex = 1:numTargets
        debris = targetScenario.debris(targetIndex);
        
        % Calculate target parameters
        targetRange = debris.range;
        targetVelocity = debris.velocity; % Radial velocity
        targetRCS = calculateDebrisRCS(debris.size, carrierFreq);
        
        % Simulate received signal
        receivedSignal = simulateTargetReturn(transmitWaveform, targetRange, targetVelocity, ...
                                            targetRCS, radarParameters, timeVector);
        
        % Add noise
        noisePower = calculateNoisePower(radarParameters);
        noise = sqrt(noisePower/2) * (randn(size(receivedSignal)) + 1j*randn(size(receivedSignal)));
        receivedSignals{targetIndex} = receivedSignal + noise;
        
        targetParameters(targetIndex).range = targetRange;
        targetParameters(targetIndex).velocity = targetVelocity;
        targetParameters(targetIndex).rcs = targetRCS;
        
        fprintf('Target %d: Range %.1f km, Velocity %.1f m/s, RCS %.1f dBsm\n', ...
                targetIndex, targetRange/1e3, targetVelocity, 10*log10(targetRCS));
    end
    
    % Matched filter processing
    detectionResults = cell(numTargets, 1);
    
    for targetIndex = 1:numTargets
        fprintf('Processing target %d...\n', targetIndex);
        
        % Apply matched filter
        [matchedFilterOutput, detectionStatistic] = applyMatchedFilter(receivedSignals{targetIndex}, ...
                                                                      transmitWaveform, ...
                                                                      radarParameters.samplingRate);
        
        % Range-Doppler processing
        [rangeDopplerMap, rangeAxis, dopplerAxis] = performRangeDopplerProcessing(receivedSignals{targetIndex}, ...
                                                                                  transmitWaveform, ...
                                                                                  radarParameters);
        
        % CFAR detection
        [detections, thresholdMap] = performCFARDetection(detectionStatistic, processingConfig.cfar);
        
        % Extract target measurements
        measurements = extractTargetMeasurements(detections, rangeAxis, dopplerAxis, radarParameters);
        
        % Store results
        detectionResults{targetIndex}.matchedFilterOutput = matchedFilterOutput;
        detectionResults{targetIndex}.detectionStatistic = detectionStatistic;
        detectionResults{targetIndex}.rangeDopplerMap = rangeDopplerMap;
        detectionResults{targetIndex}.detections = detections;
        detectionResults{targetIndex}.measurements = measurements;
        detectionResults{targetIndex}.threshold = thresholdMap;
        
        if ~isempty(measurements)
            fprintf('  Detected: Range %.1f km (true: %.1f), Velocity %.1f m/s (true: %.1f)\n', ...
                    measurements.range/1e3, targetParameters(targetIndex).range/1e3, ...
                    measurements.velocity, targetParameters(targetIndex).velocity);
        else
            fprintf('  Target not detected\n');
        end
    end
    
    % Calculate performance metrics
    performanceMetrics = calculatePerformanceMetrics(detectionResults, targetParameters, processingConfig);
    
    fprintf('Radar processing completed\n');
    fprintf('Overall detection probability: %.1f%%\n', performanceMetrics.detectionProbability * 100);
    fprintf('False alarm rate: %.2e\n', performanceMetrics.falseAlarmRate);
    fprintf('Range accuracy (RMS): %.1f m\n', performanceMetrics.rangeAccuracy);
    fprintf('Velocity accuracy (RMS): %.2f m/s\n', performanceMetrics.velocityAccuracy);
end

function [matchedFilterOutput, detectionStatistic] = applyMatchedFilter(receivedSignal, templateSignal, samplingRate)
    % Apply matched filter to received radar signal
    
    % Ensure signals are column vectors
    receivedSignal = receivedSignal(:);
    templateSignal = templateSignal(:);
    
    % Zero-pad to avoid circular convolution effects
    signalLength = length(receivedSignal);
    templateLength = length(templateSignal);
    fftLength = signalLength + templateLength - 1;
    
    % Frequency domain implementation for efficiency
    receivedFFT = fft(receivedSignal, fftLength);
    templateFFT = fft(templateSignal, fftLength);
    
    % Matched filter frequency response (conjugate of template)
    matchedFilterResponse = conj(templateFFT);
    
    % Apply matched filter
    outputFFT = receivedFFT .* matchedFilterResponse;
    matchedFilterOutput = ifft(outputFFT);
    
    % Extract valid portion (same length as received signal)
    matchedFilterOutput = matchedFilterOutput(templateLength:templateLength+signalLength-1);
    
    % Normalise by template energy
    templateEnergy = sum(abs(templateSignal).^2);
    matchedFilterOutput = matchedFilterOutput / sqrt(templateEnergy);
    
    % Detection statistic (magnitude squared for energy detection)
    detectionStatistic = abs(matchedFilterOutput).^2;
end

function targetRCS = calculateDebrisRCS(debrisSize, frequency)
    % Calculate radar cross-section for spherical debris
    
    wavelength = 3e8 / frequency; % Speed of light / frequency
    radius = debrisSize / 2;
    
    % Rayleigh scattering regime for small debris
    if radius < wavelength / (2 * pi)
        % Rayleigh scattering: -- -- (2--r/--)?
        targetRCS = pi * radius^2 * (2 * pi * radius / wavelength)^4 / 9;
    else
        % Geometric optics approximation for larger debris
        targetRCS = pi * radius^2;
    end
    
    % Add material properties (assume metallic debris)
    materialFactor = 0.8; % Metallic reflection coefficient
    targetRCS = targetRCS * materialFactor;
end

function [rangeDopplerMap, rangeAxis, dopplerAxis] = performRangeDopplerProcessing(receivedSignal, templateSignal, radarParams)
    % Perform range-Doppler processing for moving target detection
    
    prf = radarParams.prf;
    pulseWidth = radarParams.pulseWidth;
    samplingRate = radarParams.samplingRate;
    
    % Reshape received signal into pulse matrix
    samplesPerPulse = round(pulseWidth * samplingRate);
    numPulses = floor(length(receivedSignal) / samplesPerPulse);
    
    pulseMatrix = reshape(receivedSignal(1:numPulses*samplesPerPulse), samplesPerPulse, numPulses);
    
    % Apply matched filter to each pulse
    templateFFT = fft(templateSignal, samplesPerPulse);
    rangeDopplerMap = zeros(samplesPerPulse, numPulses);
    
    for pulseIndex = 1:numPulses
        pulseFFT = fft(pulseMatrix(:, pulseIndex));
        matchedOutput = ifft(pulseFFT .* conj(templateFFT));
        rangeDopplerMap(:, pulseIndex) = abs(matchedOutput).^2;
    end
    
    % Apply Doppler FFT across pulses
    rangeDopplerMap = abs(fft(rangeDopplerMap, [], 2));
    
    % Create axes
    maxRange = samplesPerPulse * 3e8 / (2 * samplingRate);
    rangeAxis = linspace(0, maxRange, samplesPerPulse);
    
    maxDoppler = prf / 2;
    dopplerAxis = linspace(-maxDoppler, maxDoppler, numPulses);
end
