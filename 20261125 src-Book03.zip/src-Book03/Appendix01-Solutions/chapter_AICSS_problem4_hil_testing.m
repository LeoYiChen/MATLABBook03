%% chapter_AICSS_problem4_hil_testing.m
% Hardware-in-the-Loop testing framework for autonomous systems.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_AICSS_problem4_hil_testing
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function hilTestResults = executeHILTestingFramework(testConfiguration, hardwareSetup, simulationModel)
    % Comprehensive Hardware-in-the-Loop testing framework
    % Author: Dr Leo Chen
    % Version: 1.0 - Initial implementation
    % Date: December 2024
    
    fprintf('Initialising Hardware-in-the-Loop testing framework...\n');
    
    % Initialize results structure
    hilTestResults = struct();
    hilTestResults.timestamp = datetime('now');
    hilTestResults.testConfiguration = testConfiguration;
    
    % Initialize hardware interfaces
    hardwareInterfaces = initializeHardwareInterfaces(hardwareSetup);
    hilTestResults.hardwareStatus = hardwareInterfaces.status;
    
    % Initialize simulation environment
    simulationEnvironment = initializeSimulationEnvironment(simulationModel);
    hilTestResults.simulationStatus = simulationEnvironment.status;
    
    % Execute test scenarios
    testScenarios = testConfiguration.scenarios;
    scenarioResults = cell(length(testScenarios), 1);
    
    for scenarioIndex = 1:length(testScenarios)
        currentScenario = testScenarios{scenarioIndex};
        fprintf('Executing test scenario: %s\n', currentScenario.name);
        
        % Execute single HIL test
        singleTestResult = executeSingleHILTest(currentScenario, hardwareInterfaces, ...
            simulationEnvironment, testConfiguration);
        
        scenarioResults{scenarioIndex} = singleTestResult;
        
        % Real-time performance monitoring
        performanceMetrics = monitorRealTimePerformance(singleTestResult);
        singleTestResult.realTimePerformance = performanceMetrics;
        
        % Safety monitoring during test execution
        safetyStatus = monitorTestSafety(singleTestResult, testConfiguration.safetyLimits);
        if ~safetyStatus.isSafe
            fprintf('Safety violation detected. Stopping test execution.\n');
            break;
        end
    end
    
    hilTestResults.scenarioResults = scenarioResults;
    
    % Comprehensive analysis of all test results
    comprehensiveAnalysis = analyseHILTestResults(scenarioResults, testConfiguration);
    hilTestResults.comprehensiveAnalysis = comprehensiveAnalysis;
    
    % Generate comprehensive visualisation
    generateHILvisualisation(hilTestResults, testConfiguration);
    
    % Statistical analysis of performance across scenarios
    statisticalAnalysis = performHILStatisticalAnalysis(scenarioResults);
    hilTestResults.statisticalAnalysis = statisticalAnalysis;
    
    % Generate test report
    generateHILTestReport(hilTestResults);
    
    % Cleanup hardware interfaces
    cleanupHardwareInterfaces(hardwareInterfaces);
    
    fprintf('HIL testing framework execution completed.\n');
end

function singleTestResult = executeSingleHILTest(scenario, hardwareInterfaces, simulationEnvironment, config)
    % Execute single Hardware-in-the-Loop test scenario
    
    singleTestResult = struct();
    singleTestResult.scenarioName = scenario.name;
    singleTestResult.startTime = datetime('now');
    
    % Initialize scenario-specific conditions
    initializeScenarioConditions(scenario, simulationEnvironment);
    
    % Test execution parameters
    testDuration = scenario.duration;
    sampleTime = config.sampleTime;
    numberOfSamples = ceil(testDuration / sampleTime);
    
    % Data storage arrays
    timeVector = zeros(numberOfSamples, 1);
    sensorData = zeros(numberOfSamples, length(hardwareInterfaces.sensors));
    actuatorCommands = zeros(numberOfSamples, length(hardwareInterfaces.actuators));
    systemStates = zeros(numberOfSamples, length(simulationEnvironment.stateVariables));
    performanceMetrics = zeros(numberOfSamples, 5); % Response time, accuracy, etc.
    
    % Real-time test execution loop
    for sampleIndex = 1:numberOfSamples
        currentTime = (sampleIndex - 1) * sampleTime;
        timeVector(sampleIndex) = currentTime;
        
        % Read sensor data from hardware
        currentSensorData = readHardwareSensors(hardwareInterfaces.sensors);
        sensorData(sampleIndex, :) = currentSensorData;
        
        % Update simulation environment
        simulationState = updateSimulationEnvironment(simulationEnvironment, currentTime, scenario);
        systemStates(sampleIndex, :) = simulationState;
        
        % Execute AI algorithm on hardware
        algorithmStartTime = tic;
        aiDecision = executeAIAlgorithm(currentSensorData, simulationState, hardwareInterfaces.aiSystem);
        algorithmExecutionTime = toc(algorithmStartTime);
        
        % Send actuator commands to hardware
        sendActuatorCommands(hardwareInterfaces.actuators, aiDecision.actuatorCommands);
        actuatorCommands(sampleIndex, :) = aiDecision.actuatorCommands;
        
        % Calculate performance metrics
        currentPerformanceMetrics = calculateCurrentPerformanceMetrics(aiDecision, simulationState, scenario.groundTruth);
        performanceMetrics(sampleIndex, :) = [algorithmExecutionTime, currentPerformanceMetrics];
        
        % Enforce real-time constraints
        enforceRealTimeConstraints(sampleTime, algorithmExecutionTime);
    end
    
    % Store test data
    singleTestResult.timeVector = timeVector;
    singleTestResult.sensorData = sensorData;
    singleTestResult.actuatorCommands = actuatorCommands;
    singleTestResult.systemStates = systemStates;
    singleTestResult.performanceMetrics = performanceMetrics;
    singleTestResult.endTime = datetime('now');
    singleTestResult.testDuration = testDuration;
    
    % Calculate scenario-specific metrics
    singleTestResult.scenarioMetrics = calculateScenarioMetrics(singleTestResult, scenario);
end

function generateHILvisualisation(hilResults, config)
    % Generate comprehensive HIL testing visualisation
    
    figure('Position', [100, 100, 1800, 1200]);
    
    % Test scenario performance summary
    subplot(3, 4, [1, 2]);
    scenarioNames = cell(length(hilResults.scenarioResults), 1);
    overallPerformance = zeros(length(hilResults.scenarioResults), 1);
    
    for scenarioIndex = 1:length(hilResults.scenarioResults)
        result = hilResults.scenarioResults{scenarioIndex};
        scenarioNames{scenarioIndex} = result.scenarioName;
        overallPerformance(scenarioIndex) = result.scenarioMetrics.overallPerformance;
    end
    
    bar(overallPerformance, 'FaceColor', [0.2, 0.6, 0.8], 'EdgeColor', [0.1, 0.3, 0.6]);
    set(gca, 'XTickLabel', scenarioNames);
    ylabel('Performance Score', 'FontSize', 12);
    title('HIL Test Scenario Performance Summary', 'FontSize', 14, 'FontWeight', 'bold');
    xtickangle(45);
    ylim([0, 1]);
    grid on;
    
    % Real-time performance analysis
    subplot(3, 4, 3);
    if ~isempty(hilResults.scenarioResults)
        exampleResult = hilResults.scenarioResults{1};
        executionTimes = exampleResult.performanceMetrics(:, 1) * 1000; % Convert to ms
        plot(exampleResult.timeVector, executionTimes, 'r-', 'LineWidth', 2);
        hold on;
        yline(config.maxExecutionTime * 1000, 'k--', 'Real-time Limit', 'LineWidth', 2);
        xlabel('Time (s)', 'FontSize', 12);
        ylabel('Execution Time (ms)', 'FontSize', 12);
        title('Real-time Performance', 'FontSize', 12, 'FontWeight', 'bold');
        grid on;
    end
    
    % Sensor data time series
    subplot(3, 4, 4);
    if ~isempty(hilResults.scenarioResults)
        exampleResult = hilResults.scenarioResults{1};
        plot(exampleResult.timeVector, exampleResult.sensorData(:, 1:3), 'LineWidth', 1.5);
        xlabel('Time (s)', 'FontSize', 12);
        ylabel('Sensor Reading', 'FontSize', 12);
        title('Sensor Data During Test', 'FontSize', 12, 'FontWeight', 'bold');
        legend({'Sensor 1', 'Sensor 2', 'Sensor 3'}, 'Location', 'best');
        grid on;
    end
    
    % Actuator command analysis
    subplot(3, 4, 5);
    if ~isempty(hilResults.scenarioResults)
        exampleResult = hilResults.scenarioResults{1};
        plot(exampleResult.timeVector, exampleResult.actuatorCommands, 'LineWidth', 2);
        xlabel('Time (s)', 'FontSize', 12);
        ylabel('Actuator Command', 'FontSize', 12);
        title('Actuator Commands', 'FontSize', 12, 'FontWeight', 'bold');
        legend({'Actuator 1', 'Actuator 2'}, 'Location', 'best');
        grid on;
    end
    
    % System state evolution
    subplot(3, 4, 6);
    if ~isempty(hilResults.scenarioResults)
        exampleResult = hilResults.scenarioResults{1};
        plot(exampleResult.timeVector, exampleResult.systemStates(:, 1:2), 'LineWidth', 2);
        xlabel('Time (s)', 'FontSize', 12);
        ylabel('System State', 'FontSize', 12);
        title('System State Evolution', 'FontSize', 12, 'FontWeight', 'bold');
        legend({'State 1', 'State 2'}, 'Location', 'best');
        grid on;
    end
    
    % Performance metrics distribution
    subplot(3, 4, 7);
    if isfield(hilResults, 'statisticalAnalysis')
        accuracyData = hilResults.statisticalAnalysis.accuracyDistribution;
        histogram(accuracyData, 20, 'FaceColor', [0.6, 0.8, 0.4], 'EdgeColor', 'black');
        xlabel('Accuracy Score', 'FontSize', 12);
        ylabel('Frequency', 'FontSize', 12);
        title('Accuracy Distribution', 'FontSize', 12, 'FontWeight', 'bold');
        grid on;
    end
    
    % Response time analysis
    subplot(3, 4, 8);
    if isfield(hilResults, 'statisticalAnalysis')
        responseTimeData = hilResults.statisticalAnalysis.responseTimeDistribution * 1000; % Convert to ms
        histogram(responseTimeData, 20, 'FaceColor', [0.8, 0.6, 0.4], 'EdgeColor', 'black');
        xlabel('Response Time (ms)', 'FontSize', 12);
        ylabel('Frequency', 'FontSize', 12);
        title('Response Time Distribution', 'FontSize', 12, 'FontWeight', 'bold');
        grid on;
    end
    
    % Safety monitoring results
    subplot(3, 4, 9);
    safetyViolations = zeros(length(hilResults.scenarioResults), 1);
    for scenarioIndex = 1:length(hilResults.scenarioResults)
        result = hilResults.scenarioResults{scenarioIndex};
        if isfield(result, 'safetyViolations')
            safetyViolations(scenarioIndex) = result.safetyViolations.count;
        end
    end
    
    bar(safetyViolations, 'FaceColor', [1, 0.6, 0.6], 'EdgeColor', 'darkred');
    set(gca, 'XTickLabel', scenarioNames);
    ylabel('Safety Violations', 'FontSize', 12);
    title('Safety Monitoring Results', 'FontSize', 12, 'FontWeight', 'bold');
    xtickangle(45);
    grid on;
    
    % Hardware utilisation analysis
    subplot(3, 4, 10);
    if isfield(hilResults, 'hardwareStatus')
        utilisationData = [hilResults.hardwareStatus.cpuUtilisation, ...
                          hilResults.hardwareStatus.memoryUtilisation, ...
                          hilResults.hardwareStatus.networkUtilisation];
        bar(utilisationData, 'FaceColor', [0.7, 0.7, 0.9]);
        set(gca, 'XTickLabel', {'CPU', 'Memory', 'Network'});
        ylabel('Utilisation (%)', 'FontSize', 12);
        title('Hardware Utilisation', 'FontSize', 12, 'FontWeight', 'bold');
        ylim([0, 100]);
        grid on;
    end
    
    % Test coverage analysis
    subplot(3, 4, 11);
    if isfield(hilResults, 'comprehensiveAnalysis')
        coverageMetrics = [hilResults.comprehensiveAnalysis.functionalCoverage, ...
                          hilResults.comprehensiveAnalysis.scenarioCoverage, ...
                          hilResults.comprehensiveAnalysis.boundaryValueCoverage];
        bar(coverageMetrics, 'FaceColor', [0.9, 0.7, 0.5]);
        set(gca, 'XTickLabel', {'Functional', 'Scenario', 'Boundary'});
        ylabel('Coverage (%)', 'FontSize', 12);
        title('Test Coverage Analysis', 'FontSize', 12, 'FontWeight', 'bold');
        ylim([0, 100]);
        grid on;
    end
    
    % Overall test summary
    subplot(3, 4, 12);
    axis off;
    
    summaryText = sprintf('HIL Testing Summary\n\n');
    summaryText = [summaryText, sprintf('Test Scenarios: %d\n', length(hilResults.scenarioResults))];
    summaryText = [summaryText, sprintf('Overall Performance: %.2f\n', mean(overallPerformance))];
    if isfield(hilResults, 'statisticalAnalysis')
        summaryText = [summaryText, sprintf('Average Accuracy: %.3f\n', ...
            hilResults.statisticalAnalysis.averageAccuracy)];
        summaryText = [summaryText, sprintf('Average Response Time: %.1f ms\n', ...
            hilResults.statisticalAnalysis.averageResponseTime * 1000)];
    end
    summaryText = [summaryText, sprintf('Safety Violations: %d\n', sum(safetyViolations))];
    summaryText = [summaryText, sprintf('Test Duration: %.1f hours\n', ...
        hours(hilResults.timestamp - hilResults.scenarioResults{1}.startTime))];
    summaryText = [summaryText, sprintf('\nTest Date: %s', string(hilResults.timestamp))];
    
    text(0.05, 0.95, summaryText, 'FontSize', 11, 'VerticalAlignment', 'top', ...
        'HorizontalAlignment', 'left', 'Interpreter', 'none', 'FontWeight', 'bold');
    
    % Save visualisation in multiple formats
    saveas(gcf, 'HILTestingResults.fig');
    saveas(gcf, 'HILTestingResults.eps', 'epsc');
    saveas(gcf, 'HILTestingResults.jpg');
    
    % Generate video of test execution if requested
    if isfield(config, 'generateVideo') && config.generateVideo
        generateHILTestVideo(hilResults);
    end
    
    fprintf('HIL testing visualisation saved in multiple formats.\n');
end

function generateHILTestVideo(hilResults)
    % Generate video showing HIL test execution
    
    videoWriter = VideoWriter('HILTestExecution.mp4', 'MPEG-4');
    videoWriter.FrameRate = 10;
    open(videoWriter);
    
    % Create frames showing test progression
    exampleResult = hilResults.scenarioResults{1};
    numberOfFrames = min(100, length(exampleResult.timeVector));
    frameIndices = round(linspace(1, length(exampleResult.timeVector), numberOfFrames));
    
    for frameIndex = 1:numberOfFrames
        dataIndex = frameIndices(frameIndex);
        
        figure('Position', [100, 100, 800, 600], 'Visible', 'off');
        
        % System state visualisation
        subplot(2, 2, 1);
        plot(exampleResult.timeVector(1:dataIndex), exampleResult.systemStates(1:dataIndex, 1), 'b-', 'LineWidth', 2);
        xlabel('Time (s)');
        ylabel('System State 1');
        title(sprintf('System State Evolution (t=%.1fs)', exampleResult.timeVector(dataIndex)));
        grid on;
        
        % Sensor data visualisation
        subplot(2, 2, 2);
        plot(exampleResult.timeVector(1:dataIndex), exampleResult.sensorData(1:dataIndex, 1), 'r-', 'LineWidth', 2);
        xlabel('Time (s)');
        ylabel('Sensor Reading');
        title('Sensor Data');
        grid on;
        
        % Performance metrics
        subplot(2, 2, 3);
        plot(exampleResult.timeVector(1:dataIndex), exampleResult.performanceMetrics(1:dataIndex, 2), 'g-', 'LineWidth', 2);
        xlabel('Time (s)');
        ylabel('Performance Metric');
        title('Real-time Performance');
        grid on;
        
        % Current status
        subplot(2, 2, 4);
        axis off;
        statusText = sprintf('HIL Test Execution\n\n');
        statusText = [statusText, sprintf('Scenario: %s\n', exampleResult.scenarioName)];
        statusText = [statusText, sprintf('Current Time: %.1f s\n', exampleResult.timeVector(dataIndex))];
        statusText = [statusText, sprintf('Progress: %.1f%%\n', 100 * dataIndex / length(exampleResult.timeVector))];
        text(0.1, 0.9, statusText, 'FontSize', 12, 'VerticalAlignment', 'top');
        
        % Capture frame
        frame = getframe(gcf);
        writeVideo(videoWriter, frame);
        
        close(gcf);
    end
    
    close(videoWriter);
    fprintf('HIL test execution video saved as HILTestExecution.mp4\n');
end
