%% chapter_Introduction_problem4_code.m
% Simple systems simulation with multidisciplinary applications.
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix01-Solutions/
% Listing label         : chapter_Introduction_problem4_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% MATLABBook03_Chapter01_Problem04.m
% Simple Systems Simulation with Multidisciplinary Applications
% This script implements a Lotka-Volterra model that can be interpreted
% from ecological, economic, and epidemiological perspectives

%% Define the Lotka-Volterra model
% The basic Lotka-Volterra equations:
% dx/dt = alpha*x - beta*x*y
% dy/dt = delta*x*y - gamma*y
%
% Where:
% x is the prey/resource/susceptible population
% y is the predator/consumer/infected population
% alpha is the prey growth rate / resource regeneration / infection rate
% beta is the predation rate / resource consumption / transmission rate
% delta is the predator birth rate / consumer benefit / recovery rate
% gamma is the predator death rate / consumer decline / recovery rate

function dydt = lotkaVolterra(t, y, params)
    % Extract state variables
    x = y(1);  % Prey/resource/susceptible
    y = y(2);  % Predator/consumer/infected
    
    % Extract parameters
    alpha = params.alpha;
    beta = params.beta;
    delta = params.delta;
    gamma = params.gamma;
    
    % Compute derivatives
    dxdt = alpha*x - beta*x*y;
    dydt = delta*x*y - gamma*y;
    
    % Return as column vector
    dydt = [dxdt; dydt];
end

%% Simulate the model with different disciplinary interpretations

% Set simulation time parameters
tspan = [0 100];
options = odeset('RelTol', 1e-6, 'AbsTol', 1e-6);

% 1. Ecological Interpretation: Predator-Prey Dynamics
% Parameters for a predator-prey system (e.g., rabbits and foxes)
ecology_params = struct();
ecology_params.alpha = 0.1;  % Prey birth rate
ecology_params.beta = 0.02;  % Predation rate
ecology_params.delta = 0.01; % Conversion of prey to predator births
ecology_params.gamma = 0.1;  % Predator death rate
ecology_params.name = 'Ecological';
ecology_params.x_label = 'Prey Population';
ecology_params.y_label = 'Predator Population';
ecology_params.x_units = 'thousands';
ecology_params.y_units = 'hundreds';
ecology_params.description = ['In ecological systems, these equations model how predator ' ...
                           'and prey populations interact and cycle over time. The model ' ...
                           'captures basic mechanisms like prey reproduction, predation, ' ...
                           'and predator mortality.'];

% Initial conditions: 50 prey, 10 predators
ecology_initial = [50; 10];

% 2. Economic Interpretation: Resource-Consumer Dynamics
% Parameters for a resource-consumer system
economics_params = struct();
economics_params.alpha = 0.05; % Resource regeneration rate
economics_params.beta = 0.01;  % Resource consumption rate
economics_params.delta = 0.02; % Consumer benefit from resource
economics_params.gamma = 0.08; % Consumer decline rate
economics_params.name = 'Economic';
economics_params.x_label = 'Resource Availability';
economics_params.y_label = 'Consumer Population';
economics_params.x_units = 'units';
economics_params.y_units = 'millions';
economics_params.description = ['In economics, these equations can model resource consumption ' ...
                             'cycles. The resource (x) grows logistically, while consumer ' ...
                             'population (y) grows based on resource availability and ' ...
                             'declines when resources are scarce.'];

% Initial conditions: 100 resource units, 20 consumer units
economics_initial = [100; 20];

% 3. Epidemiological Interpretation: Susceptible-Infected Dynamics
% Parameters for a simplified infection model
epidemiology_params = struct();
epidemiology_params.alpha = 0.02; % Birth/immigration rate of susceptibles
epidemiology_params.beta = 0.01;  % Infection rate
epidemiology_params.delta = 0.03; % Transmission efficiency
epidemiology_params.gamma = 0.15; % Recovery/death rate
epidemiology_params.name = 'Epidemiological';
epidemiology_params.x_label = 'Susceptible Population';
epidemiology_params.y_label = 'Infected Population';
epidemiology_params.x_units = 'thousands';
epidemiology_params.y_units = 'thousands';
epidemiology_params.description = ['In epidemiology, a similar system can model infectious ' ...
                                'disease spread. Susceptible individuals (x) become infected ' ...
                                'through contact with infected individuals (y), who eventually ' ...
                                'recover or die.'];

% Initial conditions: 200 susceptible, 5 infected
epidemiology_initial = [200; 5];

% Run simulations for all three interpretations
[t_eco, y_eco] = ode45(@(t,y) lotkaVolterra(t, y, ecology_params), tspan, ecology_initial, options);
[t_econ, y_econ] = ode45(@(t,y) lotkaVolterra(t, y, economics_params), tspan, economics_initial, options);
[t_epi, y_epi] = ode45(@(t,y) lotkaVolterra(t, y, epidemiology_params), tspan, epidemiology_initial, options);

%% Visualize the results with disciplinary interpretations

% Create a figure for each disciplinary interpretation
disciplinary_interpretations = {
    struct('name', ecology_params.name, 't', t_eco, 'y', y_eco, 'params', ecology_params),
    struct('name', economics_params.name, 't', t_econ, 'y', y_econ, 'params', economics_params),
    struct('name', epidemiology_params.name, 't', t_epi, 'y', y_epi, 'params', epidemiology_params)
};

for i = 1:length(disciplinary_interpretations)
    interp = disciplinary_interpretations{i};
    figure('Name', [interp.name ' Interpretation'], 'Position', [100, 100, 1200, 600]);
    
    % Time series plot
    subplot(1, 2, 1);
    plot(interp.t, interp.y(:,1), 'b-', 'LineWidth', 1.5);
    hold on;
    plot(interp.t, interp.y(:,2), 'r-', 'LineWidth', 1.5);
    xlabel('Time');
    ylabel('Population');
    legend(interp.params.x_label, interp.params.y_label, 'Location', 'best');
    title([interp.name ' Interpretation: Time Series']);
    grid on;
    
    % Phase plot
    subplot(1, 2, 2);
    plot(interp.y(:,1), interp.y(:,2), 'k-', 'LineWidth', 1.5);
    hold on;
    plot(interp.y(1,1), interp.y(1,2), 'go', 'MarkerSize', 10, 'MarkerFaceColor', 'g'); % Start
    plot(interp.y(end,1), interp.y(end,2), 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r'); % End
    xlabel([interp.params.x_label ' (' interp.params.x_units ')']);
    ylabel([interp.params.y_label ' (' interp.params.y_units ')']);
    title([interp.name ' Interpretation: Phase Portrait']);
    grid on;
    legend('Trajectory', 'Initial State', 'Final State', 'Location', 'best');
    
    % Add interpretation text
    annotation('textbox', [0.1, 0.01, 0.8, 0.08], ...
               'String', interp.params.description, ...
               'EdgeColor', 'none', ...
               'HorizontalAlignment', 'center');
end

%% Create a combined comparison figure
figure('Name', 'Multidisciplinary Model Comparison', 'Position', [150, 150, 1200, 800]);

% Phase portraits for all three interpretations
subplot(2, 2, 1);
hold on;
plot(y_eco(:,1), y_eco(:,2), 'b-', 'LineWidth', 1.5);
plot(y_econ(:,1), y_econ(:,2), 'r-', 'LineWidth', 1.5);
plot(y_epi(:,1), y_epi(:,2), 'g-', 'LineWidth', 1.5);
xlabel('Variable x (Population/Resource/Susceptible)');
ylabel('Variable y (Predator/Consumer/Infected)');
title('Phase Portraits Across Disciplines');
legend('Ecological', 'Economic', 'Epidemiological', 'Location', 'best');
grid on;

% Time series of first variable
subplot(2, 2, 2);
hold on;
plot(t_eco, y_eco(:,1), 'b-', 'LineWidth', 1.5);
plot(t_econ, y_econ(:,1), 'r-', 'LineWidth', 1.5);
plot(t_epi, y_epi(:,1), 'g-', 'LineWidth', 1.5);
xlabel('Time');
ylabel('Variable x Value');
title('Population/Resource/Susceptible Dynamics');
legend('Prey', 'Resource', 'Susceptible', 'Location', 'best');
grid on;

% Time series of second variable
subplot(2, 2, 3);
hold on;
plot(t_eco, y_eco(:,2), 'b-', 'LineWidth', 1.5);
plot(t_econ, y_econ(:,2), 'r-', 'LineWidth', 1.5);
plot(t_epi, y_epi(:,2), 'g-', 'LineWidth', 1.5);
xlabel('Time');
ylabel('Variable y Value');
title('Predator/Consumer/Infected Dynamics');
legend('Predator', 'Consumer', 'Infected', 'Location', 'best');
grid on;

% Frequency analysis
subplot(2, 2, 4);
hold on;

% Calculate periods using FFT
function period = calculateDominantPeriod(t, y)
    % Interpolate to uniform time steps
    t_uniform = linspace(t(1), t(end), length(t));
    y_uniform = interp1(t, y, t_uniform);
    
    % Remove mean
    y_detrended = y_uniform - mean(y_uniform);
    
    % Compute FFT
    Y = fft(y_detrended);
    n = length(Y);
    
    % Compute frequency axis
    fs = 1 / (t_uniform(2) - t_uniform(1));
    f = (0:n-1)*(fs/n);
    
    % Find dominant frequency (excluding DC component)
    [~, idx] = max(abs(Y(2:floor(n/2)+1)));
    dominant_freq = f(idx+1); % +1 because we excluded the first element
    
    % Calculate period
    period = 1 / dominant_freq;
end

periods_eco = [calculateDominantPeriod(t_eco, y_eco(:,1)), calculateDominantPeriod(t_eco, y_eco(:,2))];
periods_econ = [calculateDominantPeriod(t_econ, y_econ(:,1)), calculateDominantPeriod(t_econ, y_econ(:,2))];
periods_epi = [calculateDominantPeriod(t_epi, y_epi(:,1)), calculateDominantPeriod(t_epi, y_epi(:,2))];

disciplines = {'Ecological', 'Economic', 'Epidemiological'};
x_periods = [periods_eco(1), periods_econ(1), periods_epi(1)];
y_periods = [periods_eco(2), periods_econ(2), periods_epi(2)];

bar([x_periods; y_periods]');
set(gca, 'XTickLabel', disciplines);
ylabel('Oscillation Period');
title('Dominant Oscillation Periods');
legend('Variable x', 'Variable y', 'Location', 'best');
grid on;

% Add annotation explaining the multidisciplinary significance
annotation('textbox', [0.1, 0.01, 0.8, 0.08], ...
           'String', ['The Lotka-Volterra equations demonstrate how the same mathematical framework can be applied across disciplines. ' ...
                    'While the underlying dynamics are similar, each field interprets variables differently and uses ' ...
                    'domain-specific parameters, yielding distinct insights from the same computational approach.'], ...
           'EdgeColor', 'none', ...
           'HorizontalAlignment', 'center');

%% Sensitivity Analysis (Common across disciplines)
% Examine how changing parameters affects the system dynamics

figure('Name', 'Sensitivity Analysis', 'Position', [200, 200, 1200, 800]);

% Use ecological parameters as baseline
base_params = ecology_params;
initial = ecology_initial;

% Parameters to vary (one at a time)
param_names = {'alpha', 'beta', 'delta', 'gamma'};
param_descriptions = {'Prey Growth Rate', 'Predation Rate', 'Predator Birth Rate', 'Predator Death Rate'};
variations = 0.8:0.1:1.2; % -20% to +20%

% Create subplots for each parameter
for i = 1:length(param_names)
    subplot(2, 2, i);
    hold on;
    
    param = param_names{i};
    
    for j = 1:length(variations)
        % Create modified parameters
        mod_params = base_params;
        mod_params.(param) = base_params.(param) * variations(j);
        
        % Run simulation
        [t_mod, y_mod] = ode45(@(t,y) lotkaVolterra(t, y, mod_params), [0 50], initial, options);
        
        % Plot phase portrait
        plot(y_mod(:,1), y_mod(:,2), 'LineWidth', 1.5);
    end
    
    xlabel(base_params.x_label);
    ylabel(base_params.y_label);
    title(['Sensitivity to ' param_descriptions{i}]);
    legend(strcat(num2str((variations'-1)*100), '%'), 'Location', 'best');
    grid on;
end

% Add explanation
annotation('textbox', [0.1, 0.01, 0.8, 0.08], ...
           'String', ['Sensitivity analysis shows how parameter changes affect system behavior. ' ...
                    'This analysis is valuable across disciplines: ecologists study how environmental factors ' ...
                    'affect population dynamics, economists examine how policy changes impact resource cycles, ' ...
                    'and epidemiologists investigate how intervention strategies alter disease spread.'], ...
           'EdgeColor', 'none', ...
           'HorizontalAlignment', 'center');
