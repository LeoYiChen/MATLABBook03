%% Appendix02-FAQs_code_020.m
% Trigonometry-Driven Image Rotation for Computer Vision AI
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix02-FAQs/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Load sample image (MATLAB built-in dataset)
img = imread('peppers.png');
rot_angle_deg = 45; % Rotation angle (degrees)
rot_angle_rad = deg2rad(rot_angle_deg);

% 1. MATLAB built-in rotation (uses trigonometric rotation matrix)
rot_img_builtin = imrotate(img, rot_angle_deg, 'bilinear', 'crop');

% 2. Explicit rotation matrix (to show trigonometric core)
% Rotation matrix: [cos(theta), -sin(theta); sin(theta), cos(theta)]
rot_matrix = [cos(rot_angle_rad), -sin(rot_angle_rad); 
              sin(rot_angle_rad), cos(rot_angle_rad)];

% Plot results for visual verification
figure;
subplot(1,2,1);
imshow(img);
title('Original Image');
subplot(1,2,2);
imshow(rot_img_builtin);
title(sprintf('Rotated Image (%d deg) -- Trigonometry-Driven', rot_angle_deg));
