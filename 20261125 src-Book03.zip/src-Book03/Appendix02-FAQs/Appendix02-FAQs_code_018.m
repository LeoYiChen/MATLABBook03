%% Appendix02-FAQs_code_018.m
% Basic Trigonometric Calculations in MATLAB
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix02-FAQs/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Basic trigonometric calculations (radians are default in MATLAB)
% Convert degrees to radians (essential for accurate results)
angle_deg = 30; % 30 degrees
angle_rad = deg2rad(angle_deg); % MATLAB built-in unit conversion

% Calculate core trigonometric values
sin_val = sin(angle_rad);    % Sine of 30 deg (expected: 0.5)
cos_val = cos(angle_rad);    % Cosine of 30 deg (expected: sqrt(3)/2 ~ 0.866)
tan_val = tan(angle_rad);    % Tangent of 30 deg (expected: 1/sqrt(3) ~ 0.577)

% Display formatted results
fprintf('Sine of %d deg = %.4f\n', angle_deg, sin_val);
fprintf('Cosine of %d deg = %.4f\n', angle_deg, cos_val);
fprintf('Tangent of %d deg = %.4f\n', angle_deg, tan_val);

% Inverse trigonometric function (convert ratio back to angle)
inverse_angle = rad2deg(asin(sin_val)); % Convert radians to degrees
fprintf('Inverse sine of %.4f = %d deg\n', sin_val, inverse_angle);
