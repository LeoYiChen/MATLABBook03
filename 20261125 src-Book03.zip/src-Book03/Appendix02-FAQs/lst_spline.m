%% lst_spline.m
% Spline interpolation example
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix02-FAQs/
% Listing label         : lst:spline
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
x = linspace(0,2*pi,10);
y = sin(x) + 0.1*randn(size(x));
xd = linspace(0,2*pi,200);
yd = spline(x,y,xd);
plot(x,y,'ro'); hold on;
plot(xd,yd,'b-'); grid on;
