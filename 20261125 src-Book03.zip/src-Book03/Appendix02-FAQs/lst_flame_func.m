%% lst_flame_func.m
% Advanced 3D Flame Simulation Function (British English Parameterisation)
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix02-FAQs/
% Listing label         : lst:flame_func
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function [X,Y,Z,flame_intensity,particle_tracks] = advanced_3D_flame(flame_type, wind_params, time_step, num_particles)
    % ADVANCED_3D_FLAME: Physics-based 3D flame generation (UK units)
    % INPUTS:
    %   flame_type - 'rocket_jet'/'candle'/'gas_stove' (UK engineering terminology)
    %   wind_params - Struct: speed (m/s), direction [x,y,z] (UK meteorological axes)
    %   time_step - Simulation time step (s)
    %   num_particles - Number of soot/spark particles for stochastic behaviour
    % OUTPUTS:
    %   X,Y,Z - 3D mesh coordinates (m) | flame_intensity - Volumetric intensity (0-1)
    %   particle_tracks - Time-dependent particle positions (transient behaviour)

    % 1. Base mesh (UK coordinate system: z = vertical)
    [X,Y,Z] = meshgrid(-2:0.1:2, -2:0.1:2, 0:0.1:5); % Normalised metres
    flame_intensity = zeros(size(X));

    % 2. Physics-based core logic
    switch flame_type
        case 'rocket_jet'
            k = 0.8; % Jet decay constant (rocket nozzle calibration)
            axial_velocity = exp(-k * Z) .* (1 + wind_params.speed * wind_params.direction(3));
            radial_decay = exp(-k * (X.^2 + Y.^2));
            temp = 2000 * radial_decay .* axial_velocity; % Peak temp (2000K)
            flame_intensity = temp / 2000; % Normalise intensity
        
        case 'candle'
            % Buoyancy-driven natural convection (Boussinesq approximation)
            buoyancy = 9.81 * (1 - 300/2000) .* exp(-0.5*(X.^2 + Y.^2));
            flame_intensity = exp(-0.3*(X.^2 + Y.^2)) .* sin(2*pi*Z/5) .* buoyancy;
            % Wind-induced stochastic fluctuation (UK meteorological scaling)
            flame_intensity = flame_intensity + randn(size(Z)) * wind_params.speed * 0.1;
        
        case 'gas_stove'
            % Turbulent diffusion flame (simplified k-epsilon turbulence)
            turbulence = randn(size(Z)) * 0.05; % UK domestic stove turbulence
            flame_intensity = exp(-0.6*(X.^2 + Y.^2)) .* exp(-0.2*Z) .* (1 + turbulence);
    end

    % 3. Particle system for sparks/soot (time-dependent motion)
    particle_tracks = zeros(num_particles, 3, ceil(1/time_step));
    for i = 1:num_particles
        % Initial position (random within flame core)
        particle_tracks(i, :, 1) = [(rand-0.5)*0.5, (rand-0.5)*0.5, rand*2];
        % Update motion (drag + wind + buoyancy)
        for t = 2:size(particle_tracks,3)
            prev = particle_tracks(i,:,t-1);
            drag = 0.47 * prev / time_step; % UK standard drag coefficient
            wind = wind_params.speed * wind_params.direction * time_step;
            lift = [0,0,0.1*time_step]; % Buoyancy lift (z-axis only)
            particle_tracks(i,:,t) = prev + (lift + wind - drag);
        end
    end

    % 4. Clamp to physical intensity bounds
    flame_intensity(flame_intensity < 0) = 0;
    flame_intensity(flame_intensity > 1) = 1;
end
