%% lst_protection_comparison.m
% Comprehensive comparison of code protection methods
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix02-FAQs/
% Listing label         : lst:protection_comparison
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Code Protection Strategy Comparison Framework
function comparisonResults = compareProtectionMethods(requirements)
% Comprehensive comparison of MATLAB code protection strategies
% This function helps determine optimal protection approach based on requirements

fprintf('Analysing code protection requirements...\n');

% Define protection methods for comparison
protectionMethods = initialiseProtectionMethods();

% Evaluate each method against requirements
evaluationResults = evaluateProtectionMethods(protectionMethods, requirements);

% Generate comprehensive comparison
comparisonResults = generateComparison(evaluationResults, requirements);

% Provide recommendations
recommendations = generateRecommendations(comparisonResults, requirements);
comparisonResults.recommendations = recommendations;

fprintf('Code protection analysis completed\n');

    function methods = initialiseProtectionMethods()
        % Define available protection methods with characteristics
        methods = struct();
        
        % P-Code protection
        methods.pcode = struct();
        methods.pcode.name = 'P-Code Files';
        methods.pcode.security = 'Medium';
        methods.pcode.performance = 'Good';
        methods.pcode.complexity = 'Low';
        methods.pcode.portability = 'High';
        methods.pcode.cost = 'None';
        methods.pcode.matlabRequired = true;
        
        % MEX file protection
        methods.mex = struct();
        methods.mex.name = 'MEX Compilation';
        methods.mex.security = 'High';
        methods.mex.performance = 'Excellent';
        methods.mex.complexity = 'High';
        methods.mex.portability = 'Medium';
        methods.mex.cost = 'Development Time';
        methods.mex.matlabRequired = true;
        
        % MATLAB Compiler deployment
        methods.compiler = struct();
        methods.compiler.name = 'MATLAB Compiler';
        methods.compiler.security = 'Very High';
        methods.compiler.performance = 'Good';
        methods.compiler.complexity = 'Medium';
        methods.compiler.portability = 'High';
        methods.compiler.cost = 'License Required';
        methods.compiler.matlabRequired = false;
        
        % Hybrid approach
        methods.hybrid = struct();
        methods.hybrid.name = 'Hybrid Protection';
        methods.hybrid.security = 'Very High';
        methods.hybrid.performance = 'Excellent';
        methods.hybrid.complexity = 'Very High';
        methods.hybrid.portability = 'Medium';
        methods.hybrid.cost = 'High Development';
        methods.hybrid.matlabRequired = true;
    end
    
    function results = evaluateProtectionMethods(methods, requirements)
        % Evaluate protection methods against specific requirements
        methodNames = fieldnames(methods);
        results = struct();
        
        for i = 1:length(methodNames)
            methodName = methodNames{i};
            method = methods.(methodName);
            
            % Calculate suitability score
            score = calculateSuitabilityScore(method, requirements);
            
            results.(methodName) = struct();
            results.(methodName).method = method;
            results.(methodName).suitabilityScore = score;
            results.(methodName).strengths = identifyStrengths(method, requirements);
            results.(methodName).weaknesses = identifyWeaknesses(method, requirements);
        end
    end
    
    function score = calculateSuitabilityScore(method, requirements)
        % Calculate suitability score based on requirements
        score = 0;
        maxScore = 0;
        
        % Security weight
        if isfield(requirements, 'securityImportance')
            weight = requirements.securityImportance;
            securityScore = getSecurityScore(method.security);
            score = score + (weight * securityScore);
            maxScore = maxScore + weight;
        end
        
        % Performance weight
        if isfield(requirements, 'performanceImportance')
            weight = requirements.performanceImportance;
            performanceScore = getPerformanceScore(method.performance);
            score = score + (weight * performanceScore);
            maxScore = maxScore + weight;
        end
        
        % Complexity weight (inverse scoring)
        if isfield(requirements, 'complexityTolerance')
            weight = requirements.complexityTolerance;
            complexityScore = getComplexityScore(method.complexity);
            score = score + (weight * (1 - complexityScore));
            maxScore = maxScore + weight;
        end
        
        % Normalise score
        if maxScore > 0
            score = score / maxScore;
        end
    end
    
    function score = getSecurityScore(securityLevel)
        % Convert security level to numerical score
        switch securityLevel
            case 'Low', score = 0.2;
            case 'Medium', score = 0.5;
            case 'High', score = 0.8;
            case 'Very High', score = 1.0;
            otherwise, score = 0;
        end
    end
    
    function score = getPerformanceScore(performanceLevel)
        % Convert performance level to numerical score
        switch performanceLevel
            case 'Poor', score = 0.2;
            case 'Fair', score = 0.4;
            case 'Good', score = 0.7;
            case 'Excellent', score = 1.0;
            otherwise, score = 0.5;
        end
    end
    
    function score = getComplexityScore(complexityLevel)
        % Convert complexity level to numerical score
        switch complexityLevel
            case 'Low', score = 0.2;
            case 'Medium', score = 0.5;
            case 'High', score = 0.8;
            case 'Very High', score = 1.0;
            otherwise, score = 0.5;
        end
    end
    
    function strengths = identifyStrengths(method, requirements)
        % Identify method strengths relative to requirements
        strengths = {};
        
        if strcmp(method.security, 'High') || strcmp(method.security, 'Very High')
            strengths{end+1} = 'Strong security protection';
        end
        
        if strcmp(method.performance, 'Good') || strcmp(method.performance, 'Excellent')
            strengths{end+1} = 'Good performance characteristics';
        end
        
        if strcmp(method.complexity, 'Low') || strcmp(method.complexity, 'Medium')
            strengths{end+1} = 'Manageable implementation complexity';
        end
        
        if strcmp(method.portability, 'High')
            strengths{end+1} = 'High cross-platform portability';
        end
    end
    
    function weaknesses = identifyWeaknesses(method, requirements)
        % Identify method weaknesses relative to requirements
        weaknesses = {};
        
        if strcmp(method.security, 'Low') || strcmp(method.security, 'Medium')
            weaknesses{end+1} = 'Limited security protection';
        end
        
        if strcmp(method.complexity, 'High') || strcmp(method.complexity, 'Very High')
            weaknesses{end+1} = 'High implementation complexity';
        end
        
        if ~strcmp(method.cost, 'None')
            weaknesses{end+1} = sprintf('Additional cost: %s', method.cost);
        end
        
        if method.matlabRequired && isfield(requirements, 'standaloneRequired') && requirements.standaloneRequired
            weaknesses{end+1} = 'Requires MATLAB installation';
        end
    end
    
    function comparison = generateComparison(results, requirements)
        % Generate comprehensive comparison matrix
        methodNames = fieldnames(results);
        comparison = struct();
        
        comparison.summary = struct();
        comparison.detailedAnalysis = struct();
        comparison.rankings = struct();
        
        % Generate summary statistics
        scores = cellfun(@(x) results.(x).suitabilityScore, methodNames);
        [sortedScores, sortedIndices] = sort(scores, 'descend');
        
        comparison.rankings.orderedMethods = methodNames(sortedIndices);
        comparison.rankings.scores = sortedScores;
        
        % Generate detailed analysis
        for i = 1:length(methodNames)
            methodName = methodNames{i};
            comparison.detailedAnalysis.(methodName) = results.(methodName);
        end
        
        fprintf('Protection method comparison completed\n');
    end
    
    function recommendations = generateRecommendations(comparison, requirements)
        % Generate specific recommendations based on analysis
        recommendations = struct();
        recommendations.primary = comparison.rankings.orderedMethods{1};
        recommendations.reasoning = {};
        
        % Provide reasoning for primary recommendation
        primaryMethod = comparison.detailedAnalysis.(recommendations.primary);
        recommendations.reasoning{end+1} = sprintf('Highest suitability score: %.2f', primaryMethod.suitabilityScore);
        
        % Add specific strengths
        for strength = primaryMethod.strengths
            recommendations.reasoning{end+1} = strength{1};
        end
        
        % Provide alternative recommendations
        if length(comparison.rankings.orderedMethods) > 1
            recommendations.alternative = comparison.rankings.orderedMethods{2};
            alternativeMethod = comparison.detailedAnalysis.(recommendations.alternative);
            recommendations.alternativeReasoning = sprintf('Alternative option with score: %.2f', alternativeMethod.suitabilityScore);
        end
        
        % Generate implementation guidance
        recommendations.implementationGuidance = generateImplementationGuidance(recommendations.primary);
        
        fprintf('Recommendations generated successfully\n');
    end
    
    function guidance = generateImplementationGuidance(recommendedMethod)
        % Generate specific implementation guidance
        guidance = {};
        
        switch recommendedMethod
            case 'pcode'
                guidance{end+1} = '1. Prepare source code with comprehensive documentation';
                guidance{end+1} = '2. Perform security review of code before conversion';
                guidance{end+1} = '3. Generate P-Code files using pcode command';
                guidance{end+1} = '4. Test P-Code files thoroughly on target systems';
                guidance{end+1} = '5. Implement secure distribution procedures';
                
            case 'mex'
                guidance{end+1} = '1. Convert MATLAB algorithms to C/C++ implementation';
                guidance{end+1} = '2. Optimise C/C++ code for performance';
                guidance{end+1} = '3. Compile MEX files for target platforms';
                guidance{end+1} = '4. Implement comprehensive testing procedures';
                guidance{end+1} = '5. Create platform-specific distribution packages';
                
            case 'compiler'
                guidance{end+1} = '1. Prepare MATLAB code for compilation';
                guidance{end+1} = '2. Configure MATLAB Compiler settings';
                guidance{end+1} = '3. Generate standalone applications';
                guidance{end+1} = '4. Test applications on target systems';
                guidance{end+1} = '5. Create installation packages';
                
            otherwise
                guidance{end+1} = 'Consult method-specific documentation';
        end
    end
end

% Example usage of protection method comparison
requirements = struct();
requirements.securityImportance = 0.8;  % High security importance
requirements.performanceImportance = 0.6;  % Moderate performance importance
requirements.complexityTolerance = 0.4;  % Low complexity tolerance
requirements.standaloneRequired = false;  % MATLAB installation acceptable

% Perform comprehensive comparison
comparisonResults = compareProtectionMethods(requirements);

% Display recommendations
fprintf('\n=== Protection Method Recommendations ===\n');
fprintf('Primary Recommendation: %s\n', comparisonResults.recommendations.primary);
fprintf('Alternative Option: %s\n', comparisonResults.recommendations.alternative);
