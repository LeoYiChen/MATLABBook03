%% lst_complex_pcode.m
% Demonstrating P-Code generation with complex functions
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix02-FAQs/
% Listing label         : lst:complex_pcode
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Original MATLAB function with detailed implementation
function [eigenvalues, eigenvectors] = customEigenSolver(matrix, tolerance)
% Custom eigenvalue solver with proprietary optimisations
% This implementation uses advanced numerical techniques
%
% Inputs:
%   matrix - Square matrix for eigenvalue computation
%   tolerance - Convergence tolerance for iterative methods
%
% Outputs:
%   eigenvalues - Vector of computed eigenvalues
%   eigenvectors - Matrix of corresponding eigenvectors

% Input validation and preprocessing
validateInputs(matrix, tolerance);

% Proprietary preconditioning algorithm
preconditionedMatrix = applyPreconditioning(matrix);

% Advanced iterative eigenvalue computation
[eigenvalues, eigenvectors] = iterativeEigenSolver(preconditionedMatrix, tolerance);

% Post-processing and refinement
[eigenvalues, eigenvectors] = refineResults(eigenvalues, eigenvectors, matrix);

    function validateInputs(A, tol)
        if ~ismatrix(A) || size(A,1) ~= size(A,2)
            error('Input must be a square matrix');
        end
        if ~isscalar(tol) || tol <= 0
            error('Tolerance must be a positive scalar');
        end
    end

    function conditioned = applyPreconditioning(A)
        % Proprietary preconditioning algorithm
        % This would contain valuable intellectual property
        conditioned = A;  % Simplified for demonstration
    end

    function [vals, vecs] = iterativeEigenSolver(A, tol)
        % Advanced iterative method with proprietary enhancements
        [vecs, vals] = eig(A);  % Simplified for demonstration
        vals = diag(vals);
    end

    function [refinedVals, refinedVecs] = refineResults(vals, vecs, originalMatrix)
        % Post-processing refinement algorithm
        refinedVals = vals;
        refinedVecs = vecs;
    end
end

% Generate P-Code to protect the proprietary algorithms
pcode('customEigenSolver.m');
