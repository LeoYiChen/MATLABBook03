%% chapter_AICVIP_workflow_template.m
% Comprehensive MATLAB-Centric Computer Vision Workflow Template
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix02-FAQs/
% Listing label         : chapter_AICVIP_workflow_template
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
%% ====================================================================
%% MATLAB-Centric Computer Vision Workflow Template
%% Comprehensive pipeline from data ingestion to deployment
%% Author: [Your Name]
%% Date: [Current Date]
%% ====================================================================

%% Clear workspace and set up environment
clear; close all; clc;
rng(42); % Set random seed for reproducibility

% Check for required toolboxes
requiredToolboxes = {'Computer Vision Toolbox', 'Image Processing Toolbox', ...
                    'Deep Learning Toolbox', 'Parallel Computing Toolbox'};
for i = 1:length(requiredToolboxes)
    if ~license('test', lower(strrep(requiredToolboxes{i}, ' ', '_')))
        warning('Required toolbox not available: %s', requiredToolboxes{i});
    end
end

%% ====================================================================
%% SECTION 1: DATA INGESTION AND CURATION
%% ====================================================================

fprintf('=== Data Ingestion and Curation ===\n');

% Define data paths
dataPath = fullfile(pwd, 'data');
trainPath = fullfile(dataPath, 'train');
validationPath = fullfile(dataPath, 'validation');
testPath = fullfile(dataPath, 'test');

% Create image datastores for classification
try
    % Primary image datastore
    imds = imageDatastore(trainPath, ...
        'IncludeSubfolders', true, ...
        'LabelSource', 'foldernames');
    
    % Validation datastore
    imdsValidation = imageDatastore(validationPath, ...
        'IncludeSubfolders', true, ...
        'LabelSource', 'foldernames');
    
    % Display dataset statistics
    fprintf('Training images: %d\n', numel(imds.Files));
    fprintf('Validation images: %d\n', numel(imdsValidation.Files));
    fprintf('Number of classes: %d\n', numel(categories(imds.Labels)));
    
    % Class distribution analysis
    labelCount = countEachLabel(imds);
    disp(labelCount);
    
catch ME
    fprintf('Warning: Sample data not found. Creating synthetic dataset...\n');
    
    % Create synthetic data for demonstration
    numClasses = 3;
    numSamplesPerClass = 100;
    imageSize = [224, 224, 3];
    
    % Generate synthetic images and labels
    syntheticData = cell(numClasses * numSamplesPerClass, 1);
    syntheticLabels = categorical(zeros(numClasses * numSamplesPerClass, 1));
    
    for classIdx = 1:numClasses
        for sampleIdx = 1:numSamplesPerClass
            idx = (classIdx - 1) * numSamplesPerClass + sampleIdx;
            % Create synthetic image with class-specific patterns
            syntheticData{idx} = uint8(rand(imageSize) * 255);
            syntheticLabels(idx) = categorical(classIdx);
        end
    end
    
    % Create datastores from synthetic data
    imds = arrayDatastore(syntheticData);
    imds.Labels = syntheticLabels;
    imdsValidation = imds; % Use same for demonstration
end

% Implement stratified data splitting
[imdsTrain, imdsVal] = splitEachLabel(imds, 0.8, 'randomized');

% Data quality checks
fprintf('\n=== Data Quality Assessment ===\n');
sampleImage = readimage(imdsTrain, 1);
fprintf('Sample image size: %s\n', mat2str(size(sampleImage)));
fprintf('Sample image class: %s\n', char(sampleImage.Labels(1)));

%% ====================================================================
%% SECTION 2: PREPROCESSING AND AUGMENTATION
%% ====================================================================

fprintf('\n=== Preprocessing and Augmentation ===\n');

% Define target image size for neural networks
targetSize = [224, 224];

% Basic preprocessing function
preprocessFcn = @(x) imresize(x, targetSize);

% Advanced preprocessing pipeline
function processedImg = advancedPreprocess(img)
    % Resize image
    processedImg = imresize(img, targetSize);
    
    % Convert to grayscale if needed for certain algorithms
    if size(processedImg, 3) == 3
        grayImg = rgb2gray(processedImg);
    else
        grayImg = processedImg;
    end
    
    % Apply CLAHE for contrast enhancement
    processedImg = adapthisteq(grayImg);
    
    % Convert back to RGB for consistency
    if size(processedImg, 3) == 1
        processedImg = cat(3, processedImg, processedImg, processedImg);
    end
    
    % Normalise to [0, 1] range
    processedImg = im2double(processedImg);
end

% Create augmented image datastore for training
augmenter = imageDataAugmenter( ...
    'RandRotation', [-10, 10], ...
    'RandXTranslation', [-20, 20], ...
    'RandYTranslation', [-20, 20], ...
    'RandXScale', [0.9, 1.1], ...
    'RandYScale', [0.9, 1.1], ...
    'RandXReflection', true);

% Apply augmentation to training data
augTrainData = augmentedImageDatastore(targetSize, imdsTrain, ...
    'DataAugmentation', augmenter, ...
    'ColorPreprocessing', 'gray2rgb');

% Preprocessing for validation (no augmentation)
augValData = augmentedImageDatastore(targetSize, imdsVal, ...
    'ColorPreprocessing', 'gray2rgb');

%% ====================================================================
%% SECTION 3: CLASSICAL FEATURE PIPELINES
%% ====================================================================

fprintf('\n=== Classical Feature Extraction ===\n');

% SIFT feature extraction example
function features = extractSIFTFeatures(img)
    % Convert to grayscale
    if size(img, 3) == 3
        grayImg = rgb2gray(img);
    else
        grayImg = img;
    end
    
    % Detect SIFT keypoints and extract features
    points = detectSIFTFeatures(grayImg);
    [features, validPoints] = extractFeatures(grayImg, points);
end

% HOG feature extraction
function hogFeatures = extractHOGFeatures(img)
    % Convert to grayscale
    if size(img, 3) == 3
        grayImg = rgb2gray(img);
    else
        grayImg = img;
    end
    
    % Extract HOG features
    hogFeatures = extractHOGFeatures(grayImg, 'CellSize', [8 8]);
end

% ORB feature extraction
function features = extractORBFeatures(img)
    % Convert to grayscale
    if size(img, 3) == 3
        grayImg = rgb2gray(img);
    else
        grayImg = img;
    end
    
    % Detect ORB keypoints and extract features
    points = detectORBFeatures(grayImg);
    [features, validPoints] = extractFeatures(grayImg, points);
end

% Demonstrate classical features on sample image
sampleImg = readimage(imdsTrain, 1);

try
    % SIFT features
    siftFeatures = extractSIFTFeatures(sampleImg);
    fprintf('SIFT features extracted: %d\n', size(siftFeatures, 1));
    
    % HOG features
    hogFeatures = extractHOGFeatures(sampleImg);
    fprintf('HOG feature length: %d\n', length(hogFeatures));
    
    % ORB features
    orbFeatures = extractORBFeatures(sampleImg);
    fprintf('ORB features extracted: %d\n', size(orbFeatures, 1));
    
catch ME
    fprintf('Classical feature extraction error: %s\n', ME.message);
end

%% ====================================================================
%% SECTION 4: DEEP LEARNING PIPELINES
%% ====================================================================

fprintf('\n=== Deep Learning Pipeline ===\n');

% Check for GPU availability
if canUseGPU()
    fprintf('GPU detected: %s\n', gpuDevice().Name);
    useGPU = true;
else
    fprintf('No GPU detected, using CPU\n');
    useGPU = false;
end

% Load pre-trained network for transfer learning
fprintf('Loading pre-trained ResNet-18...\n');
try
    net = resnet18;
    inputSize = net.Layers(1).InputSize;
    fprintf('Pre-trained network loaded successfully\n');
    
    % Modify network for new classification task
    numClasses = numel(categories(imdsTrain.Labels));
    
    % Replace final layers for transfer learning
    lgraph = layerGraph(net);
    
    % Remove last few layers
    lgraph = removeLayers(lgraph, {'fc1000', 'prob', 'ClassificationLayer_predictions'});
    
    % Add new layers for current task
    newLayers = [
        fullyConnectedLayer(numClasses, 'Name', 'fc_new', ...
            'WeightLearnRateFactor', 10, 'BiasLearnRateFactor', 10)
        softmaxLayer('Name', 'softmax_new')
        classificationLayer('Name', 'classification_new')
    ];
    
    lgraph = addLayers(lgraph, newLayers);
    lgraph = connectLayers(lgraph, 'pool5', 'fc_new');
    
    % Training options
    options = trainingOptions('sgdm', ...
        'MiniBatchSize', 32, ...
        'MaxEpochs', 10, ...
        'InitialLearnRate', 1e-4, ...
        'LearnRateSchedule', 'piecewise', ...
        'LearnRateDropFactor', 0.1, ...
        'LearnRateDropPeriod', 5, ...
        'Shuffle', 'every-epoch', ...
        'ValidationData', augValData, ...
        'ValidationFrequency', 10, ...
        'Verbose', false, ...
        'Plots', 'none', ...
        'ExecutionEnvironment', useGPU ? 'gpu' : 'cpu');
    
    % Train the network
    fprintf('Starting transfer learning training...\n');
    trainedNet = trainNetwork(augTrainData, lgraph, options);
    fprintf('Training completed\n');
    
catch ME
    fprintf('Transfer learning error: %s\n', ME.message);
    fprintf('Creating simple CNN architecture...\n');
    
    % Simple CNN architecture
    layers = [
        imageInputLayer([224 224 3])
        
        convolution2dLayer(3, 32, 'Padding', 'same')
        batchNormalizationLayer
        reluLayer
        maxPooling2dLayer(2, 'Stride', 2)
        
        convolution2dLayer(3, 64, 'Padding', 'same')
        batchNormalizationLayer
        reluLayer
        maxPooling2dLayer(2, 'Stride', 2)
        
        convolution2dLayer(3, 128, 'Padding', 'same')
        batchNormalizationLayer
        reluLayer
        globalAveragePooling2dLayer
        
        fullyConnectedLayer(numClasses)
        softmaxLayer
        classificationLayer
    ];
    
    % Simplified training options
    options = trainingOptions('adam', ...
        'MiniBatchSize', 16, ...
        'MaxEpochs', 5, ...
        'InitialLearnRate', 1e-3, ...
        'Shuffle', 'every-epoch', ...
        'Verbose', false, ...
        'Plots', 'none', ...
        'ExecutionEnvironment', useGPU ? 'gpu' : 'cpu');
    
    try
        trainedNet = trainNetwork(augTrainData, layers, options);
        fprintf('Simple CNN training completed\n');
    catch ME2
        fprintf('CNN training error: %s\n', ME2.message);
        fprintf('Proceeding with pre-trained network for demonstration...\n');
        trainedNet = resnet18; % Use pre-trained for demo
    end
end

%% ====================================================================
%% SECTION 5: EVALUATION AND METRICS
%% ====================================================================

fprintf('\n=== Model Evaluation ===\n');

try
    % Predict on validation set
    [predictedLabels, scores] = classify(trainedNet, augValData);
    trueLabels = imdsVal.Labels;
    
    % Calculate accuracy
    accuracy = mean(predictedLabels == trueLabels);
    fprintf('Classification Accuracy: %.2f%%\n', accuracy * 100);
    
    % Confusion matrix
    confMat = confusionmat(trueLabels, predictedLabels);
    fprintf('Confusion Matrix:\n');
    disp(confMat);
    
    % Per-class metrics
    numClasses = size(confMat, 1);
    precision = zeros(numClasses, 1);
    recall = zeros(numClasses, 1);
    f1Score = zeros(numClasses, 1);
    
    for i = 1:numClasses
        tp = confMat(i, i);
        fp = sum(confMat(:, i)) - tp;
        fn = sum(confMat(i, :)) - tp;
        
        precision(i) = tp / (tp + fp + eps);
        recall(i) = tp / (tp + fn + eps);
        f1Score(i) = 2 * (precision(i) * recall(i)) / (precision(i) + recall(i) + eps);
    end
    
    fprintf('Average Precision: %.3f\n', mean(precision));
    fprintf('Average Recall: %.3f\n', mean(recall));
    fprintf('Average F1-Score: %.3f\n', mean(f1Score));
    
catch ME
    fprintf('Evaluation error: %s\n', ME.message);
end

%% ====================================================================
%% SECTION 6: GPU ACCELERATION DEMONSTRATION
%% ====================================================================

fprintf('\n=== GPU Acceleration Demonstration ===\n');

if useGPU
    % GPU array operations
    fprintf('Demonstrating GPU acceleration...\n');
    
    % Create sample data
    largeMatrix = rand(2000, 2000, 'single');
    
    % CPU timing
    tic;
    resultCPU = largeMatrix * largeMatrix';
    cpuTime = toc;
    fprintf('CPU computation time: %.3f seconds\n', cpuTime);
    
    % GPU timing
    tic;
    gpuMatrix = gpuArray(largeMatrix);
    resultGPU = gpuMatrix * gpuMatrix';
    resultGPU = gather(resultGPU); % Bring back to CPU
    gpuTime = toc;
    fprintf('GPU computation time: %.3f seconds\n', gpuTime);
    fprintf('GPU speedup: %.2fx\n', cpuTime / gpuTime);
    
    % GPU memory info
    gpuInfo = gpuDevice();
    fprintf('GPU memory available: %.1f GB\n', gpuInfo.AvailableMemory / 1e9);
else
    fprintf('GPU not available for acceleration demonstration\n');
end

%% ====================================================================
%% SECTION 7: MODEL DEPLOYMENT PREPARATION
%% ====================================================================

fprintf('\n=== Deployment Preparation ===\n');

try
    % Save trained model
    modelPath = fullfile(pwd, 'trained_model.mat');
    save(modelPath, 'trainedNet', 'targetSize');
    fprintf('Model saved to: %s\n', modelPath);
    
    % Create deployment function
    deploymentFunction = @(img) classify(trainedNet, ...
        imresize(img, targetSize));
    
    % Test deployment function
    testImage = readimage(imdsVal, 1);
    deploymentResult = deploymentFunction(testImage);
    fprintf('Deployment test result: %s\n', char(deploymentResult));
    
    % Performance profiling
    fprintf('Profiling inference performance...\n');
    numTests = 10;
    inferenceTimes = zeros(numTests, 1);
    
    for i = 1:numTests
        tic;
        deploymentFunction(testImage);
        inferenceTimes(i) = toc;
    end
    
    avgInferenceTime = mean(inferenceTimes);
    fprintf('Average inference time: %.3f seconds\n', avgInferenceTime);
    fprintf('Estimated throughput: %.1f images/second\n', 1/avgInferenceTime);
    
catch ME
    fprintf('Deployment preparation error: %s\n', ME.message);
end

%% ====================================================================
%% SECTION 8: COMPREHENSIVE PIPELINE FUNCTION
%% ====================================================================

function results = runCompleteVisionPipeline(dataPath, options)
% Complete computer vision pipeline function
% Inputs:
%   dataPath - Path to image data
%   options - Structure with pipeline options
% Outputs:
%   results - Structure with results and trained models

    if nargin < 2
        options = struct();
    end
    
    % Default options
    if ~isfield(options, 'useGPU'), options.useGPU = canUseGPU(); end
    if ~isfield(options, 'maxEpochs'), options.maxEpochs = 10; end
    if ~isfield(options, 'batchSize'), options.batchSize = 32; end
    if ~isfield(options, 'learningRate'), options.learningRate = 1e-4; end
    
    fprintf('Starting complete vision pipeline...\n');
    
    % Initialize results structure
    results = struct();
    results.timestamp = datetime('now');
    results.options = options;
    
    try
        % Data loading
        fprintf('Loading data...\n');
        imds = imageDatastore(dataPath, 'IncludeSubfolders', true, ...
            'LabelSource', 'foldernames');
        [imdsTrain, imdsVal] = splitEachLabel(imds, 0.8);
        
        % Preprocessing
        fprintf('Setting up preprocessing...\n');
        targetSize = [224, 224];
        augmenter = imageDataAugmenter('RandRotation', [-10, 10], ...
            'RandXReflection', true);
        augTrainData = augmentedImageDatastore(targetSize, imdsTrain, ...
            'DataAugmentation', augmenter);
        augValData = augmentedImageDatastore(targetSize, imdsVal);
        
        % Training
        fprintf('Training model...\n');
        net = resnet18;
        numClasses = numel(categories(imdsTrain.Labels));
        
        lgraph = layerGraph(net);
        lgraph = removeLayers(lgraph, {'fc1000', 'prob', 'ClassificationLayer_predictions'});
        
        newLayers = [
            fullyConnectedLayer(numClasses, 'Name', 'fc_new')
            softmaxLayer('Name', 'softmax_new')
            classificationLayer('Name', 'classification_new')
        ];
        
        lgraph = addLayers(lgraph, newLayers);
        lgraph = connectLayers(lgraph, 'pool5', 'fc_new');
        
        trainingOpts = trainingOptions('sgdm', ...
            'MiniBatchSize', options.batchSize, ...
            'MaxEpochs', options.maxEpochs, ...
            'InitialLearnRate', options.learningRate, ...
            'ValidationData', augValData, ...
            'Verbose', false, ...
            'ExecutionEnvironment', options.useGPU ? 'gpu' : 'cpu');
        
        trainedNet = trainNetwork(augTrainData, lgraph, trainingOpts);
        
        % Evaluation
        fprintf('Evaluating model...\n');
        [predictedLabels, scores] = classify(trainedNet, augValData);
        accuracy = mean(predictedLabels == imdsVal.Labels);
        
        % Store results
        results.trainedNetwork = trainedNet;
        results.accuracy = accuracy;
        results.trainingData = imdsTrain;
        results.validationData = imdsVal;
        results.preprocessingSize = targetSize;
        
        fprintf('Pipeline completed successfully!\n');
        fprintf('Final accuracy: %.2f%%\n', accuracy * 100);
        
    catch ME
        fprintf('Pipeline error: %s\n', ME.message);
        results.error = ME;
    end
end

%% ====================================================================
%% PIPELINE COMPLETION AND SUMMARY
%% ====================================================================

fprintf('\n=== Workflow Template Completed ===\n');
fprintf('This template demonstrates:\n');
fprintf('1. Data ingestion and curation with datastores\n');
fprintf('2. Image preprocessing and augmentation\n');
fprintf('3. Classical feature extraction (SIFT, HOG, ORB)\n');
fprintf('4. Deep learning with transfer learning\n');
fprintf('5. Model evaluation and metrics\n');
fprintf('6. GPU acceleration techniques\n');
fprintf('7. Deployment preparation\n');
fprintf('8. Complete pipeline function\n');
fprintf('\nCustomise this template for your specific computer vision application.\n');

% Clean up GPU memory if used
if useGPU
    reset(gpuDevice());
end

fprintf('\n=== Template execution completed ===\n');
