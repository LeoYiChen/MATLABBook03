%% lst_regression.m
% Linear regression example
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix02-FAQs/
% Listing label         : lst:regression
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
p = polyfit(x,y,1);
yr = polyval(p,xd);
plot(x,y,'ro'); hold on;
plot(xd,yr,'r-'); grid on;
