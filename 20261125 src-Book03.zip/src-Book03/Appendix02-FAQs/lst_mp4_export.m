%% lst_mp4_export.m
% MP4 Animation Export (British English)
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix02-FAQs/
% Listing label         : lst:mp4_export
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% UK-standard MP4 export for rocket jet flame simulation
wind_params = struct('speed', 0.8, 'direction', [0.15, 0.07, 0.03]); % m/s
vid = VideoWriter('3D_Rocket_Jet_Flame.mp4', 'Motion JPEG AVI');
vid.FrameRate = 30; % UK video standard
vid.Quality = 95; open(vid);

figure('Position', [100,100,1920,1080]); % 1080p resolution
for t = 1:ceil(10/0.02) % 10-second animation (0.02s time step)
    [X,Y,Z,intensity,particles] = advanced_3D_flame('rocket_jet', wind_params, 0.02, 800);
    patch(isosurface(X,Y,Z,intensity,0.25), 'FaceColor','orangered', 'EdgeColor','none');
    scatter3(particles(:,1,t), particles(:,2,t), particles(:,3,t), 8, 'yellow', 'filled');
    writeVideo(vid, getframe(gcf)); % Write frame to MP4
end
close(vid); % Finalise video file
