%% lst_validation_preprocessing.m
% Input validation and preprocessing workflow
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix02-FAQs/
% Listing label         : lst:validation_preprocessing
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
function isValid = validateMFileStructure(mFilePath)
% Comprehensive validation of .m file structure for App Designer compatibility
%
% This function ensures the source .m file adheres to App Designer
% architectural requirements before attempting conversion

try
    % Read and parse the source file
    fileContent = fileread(mFilePath);
    
    % Validate file encoding and structure
    if isempty(fileContent)
        error('Source file is empty or unreadable');
    end
    
    % Check for required App Designer class structure
    hasClassDefinition = contains(fileContent, 'classdef');
    hasAppInheritance = contains(fileContent, '< matlab.apps.AppBase');
    
    if ~hasClassDefinition || ~hasAppInheritance
        error('Source file must contain valid App Designer class structure');
    end
    
    % Validate component declarations section
    componentSection = extractComponentSection(fileContent);
    validateComponentDeclarations(componentSection);
    
    % Validate methods and properties sections
    methodsSection = extractMethodsSection(fileContent);
    propertiesSection = extractPropertiesSection(fileContent);
    
    validateCodeStructure(methodsSection, propertiesSection);
    
    % Check for image file dependencies
    imageDependencies = extractImageDependencies(fileContent);
    validateImageAvailability(imageDependencies);
    
    isValid = true;
    fprintf('? Source file validation completed successfully\n');
    
catch ME
    fprintf('? Validation failed: %s\n', ME.message);
    isValid = false;
end

    function componentSection = extractComponentSection(content)
        % Extract component declarations from source code
        classdefPattern = 'classdef\s+\w+\s*<\s*matlab\.apps\.AppBase';
        propertiesPattern = 'properties\s*\(\s*Access\s*=\s*public\s*\)';
        
        classdefMatch = regexp(content, classdefPattern, 'end');
        propertiesMatch = regexp(content, propertiesPattern, 'start');
        
        if isempty(classdefMatch) || isempty(propertiesMatch)
            error('Cannot locate component declaration section');
        end
        
        componentSection = content(classdefMatch(1):propertiesMatch(1)-1);
    end
    
    function validateComponentDeclarations(componentSection)
        % Validate component declarations follow App Designer conventions
        requiredComponents = {'UIFigure', 'GridLayout'};
        
        for component = requiredComponents
            if ~contains(componentSection, component{1})
                warning('Missing recommended component: %s', component{1});
            end
        end
        
        % Check for proper component hierarchy
        figureDeclaration = regexp(componentSection, '\w+\s+matlab\.ui\.Figure', 'match');
        if isempty(figureDeclaration)
            error('UIFigure component declaration not found');
        end
    end
    
    function imageDeps = extractImageDependencies(content)
        % Extract image file dependencies from app code
        imagePatterns = {
            'uiimage\([^)]*[''"]([^''"]+\.(png|jpg|jpeg|gif|bmp))[''"]',
            'uibutton\([^)]*[''"]Icon[''"][^)]*[''"]([^''"]+\.(png|jpg|jpeg|gif|bmp))[''"]',
            'uifigure\([^)]*[''"]Icon[''"][^)]*[''"]([^''"]+\.(png|jpg|jpeg|gif|bmp))[''"]'
        };
        
        imageDeps = {};
        for pattern = imagePatterns
            matches = regexp(content, pattern{1}, 'tokens');
            for match = matches
                imageDeps{end+1} = match{1}{1};
            end
        end
        
        imageDeps = unique(imageDeps);
    end
    
    function validateImageAvailability(imagePaths)
        % Ensure all referenced images are available on MATLAB path
        unavailableImages = {};
        
        for i = 1:length(imagePaths)
            imagePath = imagePaths{i};
            
            % Check if image exists on MATLAB path
            if isempty(which(imagePath))
                unavailableImages{end+1} = imagePath;
            end
        end
        
        if ~isempty(unavailableImages)
            warning('The following images are not on MATLAB path:');
            for img = unavailableImages
                fprintf('  - %s\n', img{1});
            end
            fprintf('Ensure images are accessible before conversion.\n');
        end
    end
end

% Example usage for validation workflow
sourceFile = 'scientificCalculator.m';
if validateMFileStructure(sourceFile)
    fprintf('Proceeding with m2mlapp conversion...\n');
    mlappPath = m2mlapp(sourceFile);
else
    fprintf('Please address validation issues before conversion.\n');
end
