%% Appendix02-FAQs_code_022.m
% Euler's Formula for Complex-Valued AI Signal Analysis
%
% MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications
% Chapter source folder : src-Book03/Appendix02-FAQs/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook03
% Version 1.0.1 | release 2026-11-10 | source snapshot P03-20261111
%
% ----------------------------------------------------------------------
% Visualise Euler's formula on the unit circle (complex plane)
theta = linspace(0, 2*pi, 1000); % Angles from 0 to 2*pi
euler = exp(1i * theta); % Euler's formula (1i = imaginary unit in MATLAB)

% Extract sin/cos components (real = cos(theta), imaginary = sin(theta))
cos_vals = real(euler);
sin_vals = imag(euler);

% Plot unit circle + sin/cos projections
figure;
plot(cos_vals, sin_vals, 'b'); % Unit circle
hold on;
plot(cos_vals, zeros(size(cos_vals)), 'r--', 'DisplayName', 'Cos(theta) (Real Axis)');
plot(zeros(size(sin_vals)), sin_vals, 'g--', 'DisplayName', 'Sin(theta) (Imaginary Axis)');
axis equal; % Ensure circle is not distorted
title('Euler's Formula: Unit Circle (Trigonometry + Complex Numbers)');
xlabel('Real Part (cos(theta))'); ylabel('Imaginary Part (sin(theta))');
legend;
grid on;
