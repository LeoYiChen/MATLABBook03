# VERSION - Appendix02-FAQs

| Field | Value |
| --- | --- |
| Package | `src-Book03/Appendix02-FAQs` |
| Version | 1.0.1 |
| Release date | 2026-11-10 |
| Release stamp | `Book03-src-Appendix02-FAQs-1.0.1-20261110` |
| Source manuscript | `P03-20261111` |
| SHA-256 ledger | `MANIFEST.sha256` |
| Files | 22 |

## Release notes

### 1.0.0 (2026-11-10)

- Initial extraction. 22 code environments (22 `lstlisting`,
  0 `verbatim`) comprising 2,561 lines were removed
  from the printed chapter and deposited here under their listing labels.
- All original `lstlisting` labels were preserved in the manuscript through
  the `\sourcecode` macro, which steps the `lstlisting` counter and re-issues
  the label. No in-text cross-reference was broken.
- Repository URL left as a placeholder pending creation of the public repository.

### 1.0.1 (2026-11-10)

- Public repository URL finalised as `https://github.com/LeoYiChen/MATLABBook03`.
- Repository URL and version stamp updated in every `.m` / `.f` header;
  `MANIFEST.sha256` regenerated after the header update.

## Provenance and compatibility

The code is reproduced verbatim from the manuscript listings; it has not been
rewritten, executed or validated as part of this relocation. Toolbox and
MATLAB-version requirements, where relevant, are stated in the chapter text
and in the comments of the individual files. No toolchain claim is made here.

## Integrity

`MANIFEST.sha256` lists SHA-256 digests for every `.m` / `.f` file. Verify with:

```bash
cd src-Book03/Appendix02-FAQs && sha256sum -c MANIFEST.sha256
```
