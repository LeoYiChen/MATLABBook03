# USER GUIDE - Appendix02-FAQs

Supplementary MATLAB source code for *Frequently Asked Questions (FAQs)*.

## 1. Obtain the code

Clone or download the public repository:

```bash
git clone https://github.com/LeoYiChen/MATLABBook03.git
```

Repository: https://github.com/LeoYiChen/MATLABBook03 (also printed in the book's preface). The book refers to
the relative path `src-Book03/Appendix02-FAQs/`. If you received the code as a
Springer supplementary archive, extract it and keep that folder name intact.

## 2. Locate a specific program

1. In the book, find the *Source code* note. It gives the filename, for example
   `chapter_Introduction_example_01.m`, and the folder `src-Book03/Appendix02-FAQs/`.
2. Open `src-Book03/Appendix02-FAQs/README.md` and search the file table for that
   filename; the table also gives the original listing label and caption.
3. The filename equals the `label` of the former `lstlisting` environment, so
   a label can be converted to a filename by appending `.m`.

Blocks that had no label, and code taken from `verbatim` environments, use
generated names `Appendix02-FAQs_code_NNN.m` or `Appendix02-FAQs_verbatim_NN.m`. Duplicate
labels are disambiguated with `_02`, `_03`, ... suffixes.

## 3. Run the code

1. Start MATLAB and change to this folder:
   `cd('src-Book03/Appendix02-FAQs')`.
2. Open the file and read its header comment; it records the caption, the
   original label, the version stamp and any data dependencies.
3. Run scripts with the file name (without `.m`), for example
   `chapter_Introduction_example_01`. Function files and `classdef` files must
   be called with their documented arguments rather than run directly.
4. Some listings are illustrative fragments extracted from a longer worked
   example and may require variables or data defined earlier in the chapter.
   Consult the surrounding book text.

> The code is supplied as published in the manuscript. It has not been
> re-tested during relocation. If a fragment does not run in isolation, refer
> to the corresponding section of the chapter.

## 4. Verify the download

```bash
cd src-Book03/Appendix02-FAQs && sha256sum -c MANIFEST.sha256
```

Any mismatch means the archive is incomplete or corrupted.

## 5. Version and citation

Version 1.0.1, released 2026-11-10, extracted from manuscript snapshot
`P03-20261111`. When citing the code, cite the book and mention the supplementary
repository and the release stamp recorded in `VERSION.md`.

## 6. Companion documents

- `README.md` - purpose, naming convention and full file table
- `VERSION.md` - release stamp, release notes and provenance
- `MANIFEST.sha256` - integrity ledger
