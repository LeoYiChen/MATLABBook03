# Appendix02-FAQs - Supplementary MATLAB Source Code

| Field | Value |
| --- | --- |
| Book | MATLAB Roadmap to Applications, Volume III: Multidisciplinary Applications |
| Chapter | Frequently Asked Questions (FAQs) |
| Package version | 1.0.1 |
| Release stamp | 2026-11-10 |
| Source manuscript | `P03-20261111` |
| Source chapter file | `P0302main/Appendix02-FAQs/` (included by `P03_20261005.tex`) |
| Code files | 22 (22 `.m`, 0 `.f`) |
| Code lines relocated | 2,561 |

## Why this folder exists

The editor reported that a large volume of programming code was present in the
manuscript and requested that it be moved to a professional repository with the
links supplied as supplementary material. The printed book is subject to a
length target below 1100 pages and to the Springer hard-copy limit of fewer
than 950 print pages. Accordingly, every `lstlisting` (and every MATLAB
`verbatim`) environment in the chapter has been removed from the main body and
deposited here. Only the filename, the listing caption and a reference to this
folder remain in the printed text.

## Naming convention

A file is named after the `label` of the listing it came from:

```latex
\begin{lstlisting}[..., caption={Basic matrix operations ...},
                     label={chapter_Introduction_example_01}]
```

is saved as `chapter_Introduction_example_01.m`.

- Listings without a `label` receive a generated name `Appendix02-FAQs_code_NNN.m`.
- Code held in a `verbatim` environment receives `Appendix02-FAQs_verbatim_NN.m`
  (or `.f` for the single illustrative Fortran 77 block).
- Where two listings shared the same label, the later file carries a numeric
  suffix (`_02`, `_03`, ...) so nothing is overwritten. This is recorded in
  the table below.

Each file begins with a header comment giving the caption, the original label,
this folder, the version stamp and the public repository URL.

## Finding a file from the book

The main text now shows a one-line note of the form:

> **Source code 3.4:** `chapter_ICT_example_01.m` - *caption*
> (supplementary material: `src-Book03/Appendix02-FAQs/`)

The original listing numbers and all `\ref{...}` cross-references are
unchanged, so the in-text reference maps directly to a filename.

## Repository

```
https://github.com/LeoYiChen/MATLABBook03
```

Clone or download `src-Book03/` from this public repository, or use the
Springer supplementary archive. The same address is printed in the preface of
the book. Keep the `src-Book03/` folder name so that the in-text
`src-Book03/Appendix02-FAQs/` paths resolve.

## Companion documents

- `VERSION.md` - version, release stamp and release notes
- `USER-GUIDE.md` - how to download, locate and run the code
- `MANIFEST.sha256` - SHA-256 ledger of every file in this folder

## Files

| Filename | Source listing label | Caption |
| --- | --- | --- |
| `Appendix02-FAQs_code_013.m` | `(generated)` | Complete Implementation of the MATLAB Code Simplifier |
| `Appendix02-FAQs_code_018.m` | `(generated)` | Basic Trigonometric Calculations in MATLAB |
| `Appendix02-FAQs_code_019.m` | `(generated)` | Trigonometry-Based Signal Denoising for AI Preprocessing |
| `Appendix02-FAQs_code_020.m` | `(generated)` | Trigonometry-Driven Image Rotation for Computer Vision AI |
| `Appendix02-FAQs_code_021.m` | `(generated)` | Trigonometric Encoding of Cyclic Features for AI Time-Series Forecasting |
| `Appendix02-FAQs_code_022.m` | `(generated)` | Euler's Formula for Complex-Valued AI Signal Analysis |
| `chapter_AICVIP_workflow_template.m` | `chapter_AICVIP_workflow_template` | Comprehensive MATLAB-Centric Computer Vision Workflow Template |
| `lst_ai_workflow.m` | `lst:ai_workflow` | AI-enhanced development workflow implementation |
| `lst_basic_pcode.m` | `lst:basic_pcode` | Basic P-Code generation examples |
| `lst_complex_pcode.m` | `lst:complex_pcode` | Demonstrating P-Code generation with complex functions |
| `lst_enhanced_security.m` | `lst:enhanced_security` | Example of enhanced P-Code security implementation |
| `lst_flame_func.m` | `lst:flame_func` | Advanced 3D Flame Simulation Function (British English Parameterisation) |
| `lst_m2mlapp_basic.m` | `lst:m2mlapp_basic` | Basic m2mlapp function signature and usage |
| `lst_metadata_generation.m` | `lst:metadata_generation` | Advanced metadata generation and structure creation |
| `lst_modular_pcode.m` | `lst:modular_pcode` | Example of modular project structure with P-Code integration |
| `lst_mp4_export.m` | `lst:mp4_export` | MP4 Animation Export (British English) |
| `lst_protection_comparison.m` | `lst:protection_comparison` | Comprehensive comparison of code protection methods |
| `lst_regression.m` | `lst:regression` | Linear regression example |
| `lst_research_pcode.m` | `lst:research_pcode` | Example of preparing research code for P-Code distribution |
| `lst_spline.m` | `lst:spline` | Spline interpolation example |
| `lst_validation_framework.m` | `lst:validation_framework` | Comprehensive validation framework for conversion workflows |
| `lst_validation_preprocessing.m` | `lst:validation_preprocessing` | Input validation and preprocessing workflow |
